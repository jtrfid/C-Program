#include<stdio.h>
#include<math.h>
int shu(n)
{int e,an;
if(e==1) an=2;
else if(e==2)  an=3;
else an=(e-1)*(e-1)+3*(e-2)+1;
return(n);
}

int main()

{
	int i,m,k,shu(b[200]),sum=0,x=0,y=0;
	scanf("%d %d",&m,&k);
	for(i=0;i<k;i++)  
	{  if(shu(b[i]%m==0))    sum++;
	    else if(shu(b[i]%m==1))  x++;
	    else if(shu(b[i]%m=0)&&shu(b[i]%m!=1)) y++;
	}
	printf("%d %d %d",sum,x,y);
}
