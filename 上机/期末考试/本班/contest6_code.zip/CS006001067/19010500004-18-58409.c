
#include<stdio.h>
#include<math.h>
int main()
{
	int n,a[100],i,min,t,m;
	scanf("%d\n",&n);
	for(i=0;i<n-1;i++)
	scanf("%d ",&a[i]);
	for(i=0;i<n-1;i++){
		m=abs(a[i+1]-a[i+2]);
        if(m==0||m==1)
        printf("%d",m);
	}
    
}

