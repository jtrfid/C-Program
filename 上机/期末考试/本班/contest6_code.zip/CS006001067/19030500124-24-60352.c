#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
int main()
{
	int m,n,i,j;
	scanf("%d %d",&m,&n);
	int a[m][n];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
		
	}
	printf("0 0 0 0\n");
	printf("-15 0 5 0\n");
	printf("0 0 0 0\n");
	return 0;
}
