#include<stdio.h>
int main()
{
	int m,n,i,j,k;
	int a[50][50],b[50][50];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
		
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		b[i][j]=a[i][j];
	
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==0)
			{
				for(k=0;k<n;k++)
				b[i][k]=0;
				for(k=0;k<m;k++)
				{
					b[k][j]=0;
				}
				
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{printf("%d ",b[i][j]);
		if(j==n-1)
		printf("\n");
		}
	}
	return 0;
}
