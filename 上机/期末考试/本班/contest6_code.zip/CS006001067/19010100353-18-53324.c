#include<stdio.h>
#include<math.h>
#include<string.h>
int main(int argc,const char *argv[])
{
	int i,j,n,m;
	scanf("%d",&n);
	int a[100];
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(a[j]<a[j+1])
			{
				m=a[j];
				a[j]=a[j+1];
				a[j+1]=m;
			}
		}
	}
	for(i=0;i<n-1;i++)
	{
		m=a[0]-a[1];
		if(a[i]-a[i+1]<m)
		m=a[i]-a[i+1];
	}
	printf("%d",m);
	return 0;
}
