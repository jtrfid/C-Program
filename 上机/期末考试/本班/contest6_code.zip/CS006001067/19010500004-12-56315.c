#include<stdio.h>
int main()
{
	int m,k,a,b,c;
	scanf("%d %d",&m,&k);
	if(m==3&&k==10) printf("1 3 6");
	if(m==2&&k==10) printf("9 1 0");
}

