#include<stdio.h>
int main()
{int a[100][100],b[100][100],i,j,m,n,c,v,o,p;
scanf("%d %d",&m,&n);
for(i=0;i<m;i++)for(j=0;j<n;j++){
scanf("%d",&a[i][j]);b[i][j]=a[i][j];}
for(i=0;i<m;i++)for(j=0;j<n;j++){if(a[i][j]==0){c=i;v=j;for(c=0;c<n;c++)b[i][c]=0;for(v=0;v<m;v++)b[v][j]=0;}}
for(i=0;i<m;i++){
for(j=0;j<n;j++)printf("%d ",b[i][j]);printf("\n");}
return 0;
};
