#include<stdio.h>
int main()
{
	int y,d;
	scanf("%d %d",&y,&d);
	if(d>29)
	printf("-1"); 
	if((y%400==0||(y%4==0&&y%100!=0)))
	printf("%d",d%7);
	else 
	{
	if(d==29)
	printf("-1");}
	
}
