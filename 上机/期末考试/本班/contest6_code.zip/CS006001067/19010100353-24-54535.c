#include<stdio.h>
#include<math.h>
#include<string.h>
int main(int argc,const char *argv[])
{
	int n,m,i,j,k=0;
	int a[100][50],b[100][50]={0};
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	scanf("%d",&a[i][j]);
	for(i=0;i<n;i++)
	{
	  for(j=0;j<m;j++)
	  {
		if(a[i][j]==0)
		{
		  b[i][j]=1;
		}
	  }
    }
    for(i=0;i<n;i++)
	{
	  for(j=0;j<m;j++)
	  {
		if(b[i][j]==1)
		{
		  for(k=0;k<m;k++)
		  	a[i][k]=0;
		  for(k=0;k<n;k++)
		  a[k][j]=0;
		}
	  }
    }
    
    
    
    for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
	
	
}
