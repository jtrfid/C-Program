#include<stdio.h>
#include<stdlib.h>
int ru(int n)
{
	if(n%400==0)
	return 1;
	if(n%4==0&&n%100!=0)
	return 0;
}
main()
{
	int y,d;
	scanf("%d%d",&y,&d);
	if(!ru(y)&&d>28)
	{
		printf("-1");
	}
	else if(d<1||d>29||y<1900||y>2100)
	{
		printf("-1");
	}
	else{
		d%=7;
		if(d==0)
		d==7;
		printf("%d",d);
	}
}
