#include<stdio.h>
int a(int n)
{
	if(n==1)return 2;
	else if(n==2)return 3;
	else return ((n-1)*(n-1)+3*(n-2)+1);
}
int main(void)
{
	int m,k,x=0,y=0;
	scanf("%d %d",&m,&k);
	for(int i=1;i<=k;i++)
	{
		if(a(i)%m==0)
		{
			x++;
		}
		else if(a(i)%m==1)
		{
			y++;
		}
	}
	printf("%d %d %d",x,y,k-x-y);
}
