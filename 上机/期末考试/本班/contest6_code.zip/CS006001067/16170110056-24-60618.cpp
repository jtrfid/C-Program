#include<stdio.h>

#define maxrow 50
#define maxcol 50
int main()
{
	int matrix[maxrow]
	[maxcol];
	int zeroRows[maxrow],zeroCols[maxcol];
	int i,j,m,n;
	int r=0,c=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",matrix[i][j]);
			if(0==matrix[i][j])
			{
				zeroRows[r++]=i;
				zeroCols[c++]=j;
			}
		}
	}
	for(i=0;i<r;i++)
	{
		for(j=0;j<n;j++)
		{
			matrix[zeroRows[i]][j]=0;
		}
	}
	for(i=0;i<c;i++)
	{
		for(j=0;j<m;j++)
		{
			matrix[j][zeroCols[i]]=0;
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d " , matrix[i] [j] );
		}
		printf(" \n" );
	}
	return 0;
}
