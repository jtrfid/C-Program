#include<stdio.h>
int math()
