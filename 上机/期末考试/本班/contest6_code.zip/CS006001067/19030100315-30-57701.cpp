#include<bits/stdc++.h>
using namespace std;
int sg(int o,int b,int c,int d){
	int a[5];
	int k;
	a[1]=o;
	a[2]=b;
	a[3]=c;
	a[4]=d;
	for(int i=1;i<=4;i++){
		for(int j=1;j<=4-i;j++){
			if(a[j]>=a[j+1]){
				k=a[j];
				a[j]=a[j+1];
				a[j+1]=k;
			}
		}
	}
	int sum;
	sum=a[2]+a[3];
	return sum;
}
int main(){
	int k,er;
	struct stu{
		int name;
		int a;
		int b;
		int c;
		int d;
		int la;
	};
	int n;
	cin>>n;
	stu m[1001];
	int b[1001];
	for(int i=1;i<=n;i++){
		cin>>m[i].name;
		cin>>m[i].a;
		cin>>m[i].b;
		cin>>m[i].c;
		cin>>m[i].d;
	}
	for(int i=1;i<=n;i++){
		int t;
		t=m[i].a+m[i].b+m[i].c+m[i].d-sg(m[i].a,m[i].b,m[i].c,m[i].d);
		m[i].la=t;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n-i;j++){
			if(m[j].la<=m[j+1].la){
				k=m[j].la;
				m[j].la=m[j+1].la;
				m[j].la=k;
				er=m[j].name;
				m[j].name=m[j+1].name;
				m[j+1].name=er;
			}
		}
	}
	int h=n;
	while(1){
	if(m[h].la!=m[h-1].la){
		cout<<m[h].name<<endl;
		break;
	}	
	else {
		cout<<m[h].name<<endl;
	}
	h--;
	}
	return 0;
}

