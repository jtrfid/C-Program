#include<stdio.h>
int main(){
	int a,b,d,c[100],i,j,k=0;
	scanf("%d %d",&a,&d);
	if(a<1900||a>2100)printf("-1");else{
	
	if(a%4==0&&a%100!=0||a%400==0)k=1;
	if(k)if(d>29||d<1)printf("-1");else printf("%d",d%7);
	if(k==0)if(d>28||d<1)printf("-1");else printf("%d",d%7);
	}return 0;
}
