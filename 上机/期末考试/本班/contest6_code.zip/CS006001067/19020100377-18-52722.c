#include<stdio.h>
int main()
{int a[100],i,j,n,b;
scanf("%d",&n);
for(i=0;i<n;i++)scanf("%d",&a[i]);
if(a[1]-a[0]>0)j=a[1]-a[0];
if(a[1]-a[0]<=0)j=a[0]-a[1];
for(i=2;i<n;i++)if(a[i]-a[i-1]<=0)if(a[i-1]-a[i]<j)j=a[i-1]-a[i];if(a[i]-a[i-1]>0)if(a[i]-a[i-1]<j)j=a[i]-a[i-1];
printf("%d",j);
}
