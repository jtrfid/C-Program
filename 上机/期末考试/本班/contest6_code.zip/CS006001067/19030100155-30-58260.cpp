#include<stdio.h>
int main(void)
{
	int n,a[20][5],b[20],t;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<5;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=0;i<n;i++)
	{
		for(int j=1;j<5;j++)
		{
			for(int c=1;c<5-j;c++)
			{
				if(a[i][c]>a[i][c+1])
				{
					t=a[i][c];a[i][c]=a[i][c+1];a[i][c+1]=t;
				}
			}
		}
		b[i]=(a[i][2]+a[i][3])/2;
	}
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1-i;j++)
		{
			if(b[i]>b[i+1])
			{
				t=b[i];b[i]=b[i+1];b[i+1]=t;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
			if(((a[i][2]+a[i][3])/2)==b[n-1])
			{
				printf("%d\n",a[i][0]);
			}
	}
}
