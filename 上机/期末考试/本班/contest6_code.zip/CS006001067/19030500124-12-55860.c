#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
int main()
{
	int m,n,k,i;
	int A=0;
	int b=0;
	int c=0;
	scanf("%d %d",&m,&k);
	int a[k];
	for(i=0;i<k+1;i++)
	{
		if(i==0)
		a[i]=2;
		if(i==1)
		a[i]=3;
		else
		a[i]=(i-1)*(i-1)+3*(i-2)+1;
	}
	for(i=1;i<k+1;i++)
	{
	if(a[i]%m==0)
	A++;
	if(a[i]%m==1)
	b++;
	if(a[i]%m>1)
	c++;
	}
	printf("%d %d %d",A,b,c);
	return 0;
}
