#include<stdio.h>
#include<math.h>
#include<string.h>
int main(int argc,const char *argv[])
{
	int i,j,n,m,k;
	int ab=0,ac=0,ae=0;
	scanf("%d %d",&m,&k);
	if(m==1)
	m=2;
	else if(m==2)
	m==3;
	else
	m=(m-1)*(m-1)+3*(m-2)+1;
	
	
	
	for(i=1;i<=k;i++)
	{
	    if(i==1)
	    j=2;
	    else if(i==2)
	    j==3;
	    else
	    j=(i-1)*(m-1)+3*(m-2)+1;
		if(j%m==0)
		ab++;
		if(j%m==1)
		ac++;
		if(j%m>1)
		ae++;
	}
	printf("%d %d %d",ab,ac,ae);
}
