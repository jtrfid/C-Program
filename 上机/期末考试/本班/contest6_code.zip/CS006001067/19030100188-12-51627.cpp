#include<stdio.h>
int main()
{
	int m,k,n,s1=0,s2=0,s3=0,i,j,a[200];
	scanf("%d%d",&m,&k);
	for(i=0;i<k;i++)
	{
		if(i==0)
		a[i]=2;
		else if(i==1)
		a[i]=3;
		else
		a[i]=i*i+3*(i-1)+1;
	}
	for(i=0;i<k;i++)
	{
		n=a[i]%m;
		if(n==0)
		s1++;
		else if(n==1)
		s2++;
		else
		s3++;
	}
	printf("%d %d %d",s1,s2,s3);
	return 0;
}
