#include<stdio.h>
#include<algorithm>
using std::sort;
int main()
{
	int n,a[20][5],i,j,b[20],max=0;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	for(j=0;j<5;++j)
	scanf("%d",&a[i][j]);
	for(i=0;i<n;++i)
	sort(a[i]+1,a[i]+5);
	for(i=0;i<n;i++)
	{
	b[i]=a[i][2]+a[i][3];
	if(b[i]>max)
	max=b[i];
	}
	for(i=0;i<n;++i)
	{
		if(b[i]==max)
		printf("%d\n",a[i][0]);
	}
}

