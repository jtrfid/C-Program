#include<stdio.h>
int main(void)
{
	int a[50][50],m,n,b[50][50];
	scanf("%d %d",&m,&n);
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
			b[i][j]=1;
		}
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i][j]==0)
			{
				for(int x=i,y=0;y<n;y++)
				{
					b[x][y]=0;
				}
				for(int x=0,y=j;x<m;x++)
				{
					b[x][y]=0;
				}
			}
		}
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(b[i][j]==0)
			{
				a[i][j]=0;
			}
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
}
