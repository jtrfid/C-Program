#include<stdio.h>
int main(){
	int b=0,d=0,a[200],m,i=0,j=0,k=0;
    a[1]=2;a[2]=3;
    for(i=3;i<=200;i++)a[i]=(i-1)*(i-1)+3*i-5;
	scanf("%d %d",&m,&k);
	for(i=1;i<=k;i++){if(a[i]%m==0)b++;if(a[i]%m==1)d++;
	}
	printf("%d %d %d",b,d,k-b-d);
	return 0;
}
