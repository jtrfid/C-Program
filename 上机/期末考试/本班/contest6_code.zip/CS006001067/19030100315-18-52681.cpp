#include<bits/stdc++.h>
using namespace std;
int a[1001];
int b[1001];
int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n-1;i++){
		b[i]=abs(a[i]-a[i+1]);
	}
	sort(b+1,b+n);
	cout<<b[1];
	return 0;
}

