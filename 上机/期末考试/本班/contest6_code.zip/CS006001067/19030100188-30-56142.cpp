#include<stdio.h>
int main()
{
	int n,i,j,t,k,y=0,l,a[20][5],b[20][2];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		scanf("%d",&a[i][j]);
	}
	i=0;
	while(i<n)
	{
		for(j=1;j<5;j++)
		{
			for(k=1;k<5-j;k++)
			{
				if(a[i][k]>a[i][k+1])
				{
					t=a[i][k];
					a[i][k]=a[i][k+1];
					a[i][k+1]=t;
				}
			}
		}
		b[i][0]=a[i][0];
		b[i][1]=a[i][2]+a[i][3];
		if(b[i][1]>y)
		y=b[i][1];
		i++;
	}
	for(i=0;i<n;i++)
	{
		if(b[i][1]==y)
		printf("%d\n",b[i][0]);
	}
	return 0;
}
