#include<stdio.h>
int main(void)
{
	int a[50],b[50],n,t;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];a[j]=a[j+1];a[j+1]=t;
			}
		}
	}
	for(int i=0;i<n-1;i++)
	{
		b[i]=a[i+1]-a[i];
	}
	for(int i=0;i<n-2;i++)
	{
		for(int j=0;j<n-2-i;j++)
		{
			if(b[j]>b[j+1])
			{
				t=b[j];b[j]=b[j+1];b[j+1]=t;
			}
		}
	}
	printf("%d",b[0]);
}
