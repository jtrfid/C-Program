#include<stdio.h>
int main()
{
	int n,i,j,a[200][200];
	sacnf("%d",&n);
	for(i=0,i<n,i++)
	scanf("%d",&a[i][j]);
	
	
	
	
	
}
