#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int num[201];
int cau(int n)
{
	int m=0;
	if(n>2)
	m=(n-1)*(n-1)+3*(n-2)+1;
	else if(n==1)
	m=2;
	else if(n==2)
	m=3;
	return m;
}
int main()
{
	int i,m,k,a=0,b=0,c=0;
	for(i=1;i<=200;i++)
	num[i]=cau(i);
	scanf("%d %d",&m,&k);
	for(i=1;i<=k;i++)
	{
		if(num[i]%m==0)
		++a;
		if(num[i]%m==1)
		++b;
		if(num[i]%m>1)
		++c;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
