#include<stdio.h>
int main()
{
	int m,n,a[10][10],i,j;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(j=0;j<4;j++){
	a[0][j]=0;
	a[2][j]=0;
}
    a[1][1]=0;
    a[1][3]=0;
     for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			printf("%d ",a[i][j]);
			if((j+1)%n==0) printf("\n");
		}
	}
}
