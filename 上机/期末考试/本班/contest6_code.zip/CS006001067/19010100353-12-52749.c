#include<stdio.h>
#include<math.h>
#include<string.h>
int main(int argc,const char *argv[])
{
	int i,j,n,m,k;
	int ab=0,ac=0,ae=0;
	scanf("%d %d",&m,&k);
	
	
	
	
	for(i=1;i<=k;i++)
	{
	 if(i==1)
	 j=2;
	 else if(i==2)
	 j==3;
	 else
	 j=(i-1)*(i-1)+3*(i-2)+1;
		if(m%j==0)
		ab++;
		if(m%j==1)
		ac++;
		if(m%j>1)
		ae++;
	}
	printf("%d %d %d",ab,ac,ae);
	return 0;
}
