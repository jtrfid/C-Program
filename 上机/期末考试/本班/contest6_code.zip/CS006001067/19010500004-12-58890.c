#include<stdio.h>
int main()
{
	int m,k,a[100],n=3,i,d,b,c;
	scanf("%d %d",&m,&k);
	for(i=3;i<=k;i++)
	a[i]=(n-1)*(n-1)+3*(n-2)+1;
	for(i=1;i<=k;i++){
		if(a[i]%m==0) d=i;
		if(a[i]%m==1) b=i;
		if(a[i]%m>1) c=i;
	}
	printf("%d %d %d",d,b,c);
}
