#include<stdio.h>
int main()
{
	int m(int ,int );
	int n,i,j,a[50],b=1000000;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;++i)
	for(j=i+1;j<n;++j)
	{
		if(m(a[i],a[j])<b)
		b=m(a[i],a[j]);
	}
	printf("%d\n",b);
}
int m(int x,int y)
{
	int z;
	if(x>y)
	z=x-y;
	else 
	z=y-x;
	return(z);
}
