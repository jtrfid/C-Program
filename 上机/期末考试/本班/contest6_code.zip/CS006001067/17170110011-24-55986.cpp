#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,a[50][50],m,i,j,b[2][50],x=0,k,c,d;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	for(j=0;j<n;j++)
	{
		scanf("%d",&a[i][j]);
		if(a[i][j]==0)
		{
			b[0][x];
			b[1][x++];
		}
	}
	for(k=0;k<x;k++)
	{
		c=b[0][k];
		d=b[1][k];
		for(i=0;i<n;i++)
		a[c][i]=0;
		for(i=0;i<m;i++)
		a[i][d]=0;
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		printf("%d",a[i][j]);
		printf("\n");
	}
	return 0;
}
