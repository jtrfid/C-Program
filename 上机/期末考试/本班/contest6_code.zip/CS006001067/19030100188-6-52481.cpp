#include<stdio.h>
int main()
{
	int a,b,c,d,y;
	scanf("%d%d",&y,&d);
	if(y>=1900&&y<=2100)
	{
		if((y%4==0&&y%100!=0)||y%400==0)
		{
			if(d>=1&&d<=29)
			{
				a=d%7;
				switch(a)
				{
					case 1:printf("1");break;
					case 2:printf("2");break;
					case 3:printf("3");break;
					case 4:printf("4");break;
					case 5:printf("5");break;
					case 6:printf("6");break;
					case 0:printf("0");break;
				}
			}
			else
			printf("-1");
		}
		else
		{
			if(d>=1&&d<=28)
			{
				b=d%7;
				switch(b)
				{
					case 1:printf("1");break;
					case 2:printf("2");break;
					case 3:printf("3");break;
					case 4:printf("4");break;
					case 5:printf("5");break;
					case 6:printf("6");break;
					case 0:printf("0");break;
				}
			}
			else
			printf("-1");
		}
	}
	else
	printf("-1");
	return 0;
}
