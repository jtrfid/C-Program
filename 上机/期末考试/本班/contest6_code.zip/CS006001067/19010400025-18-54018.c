#include<stdio.h>
int main()
{
	int n,i,j,b[1000],k,m;
	long int a[1000],temp;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%ld",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[i]<a[j])
			{
				temp=a[j];
				a[j]=a[i];
				a[i]=temp;
			}
		}
	}
	for(i=0,k=0;i<n-1;i++,k++)
	{
		b[k]=a[i]-a[i+1];
	}
	m=k+1;
	for(i=0;i<m;i++)
	{
		for(j=i+1;j<m;j++)
		{
			if(b[i]>b[j])
			{
				temp==b[j];
				b[j]=b[i];
				b[i]=temp;
			}
		}
	}
	printf("%d",b[0]);
	return 0;
	
}
