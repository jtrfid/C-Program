#include<stdio.h>
void bubbleSort(int *nums,int
n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(nums[j]<nums[j+1])
			{
				temp=nums[j];
				nums[j]=nums[j+1];
				nums[j+1]=temp;
			}
		}
	}
}
int main()
{
	int players[20][5],i,j,n;
	int max;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		{
			scanf("%d",&players[i][j]);
		}
		bubbleSort(players[i]+1,4);
	}
	max=players[0][2]+players[0][3];
	for(i=1;i<n;i++)
	{
		if(players[i][2]+players[i][3]>max)
		{
			max=players[i][2]+players[i][3];
		}
	}
	for(i=0;i<n;i++)
	{
		if(players[i][2]+players[i][3]==max)
		{
			printf("%d\n",players[i][0]);
		}
	}
	return 0;
}
