#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int num[60];
main()
{
	int i,n,mi=0xfffffff,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%i",&num[i]);
	for(i=0;i<n;i++)
	for(j=0;j<n;j++)
	{
		if(i==j)
		continue;
		k=(int)fabs(num[i]*1.0-num[j]*1.0);
		if(mi>k)mi=k;
		
	}
	printf("%d\n",mi);
	
}
