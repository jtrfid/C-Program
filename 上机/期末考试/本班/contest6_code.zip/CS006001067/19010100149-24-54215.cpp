#include<stdio.h>
int main()
{
	int m,n,i,j,p,q,a[50][50],b[50][50];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;++i)
	for(j=0;j<n;++j)
	{
	scanf("%d",&a[i][j]);
	b[i][j]=a[i][j];
	}
	for(i=0;i<m;++i)
	for(j=0;j<n;++j)
	{
		if(a[i][j]==0)
		{
		for(p=0;p<n;p++)
		b[i][p]=0;
		for(q=0;q<m;++q)
		b[q][j]=0;
		}
	}
	for(i=0;i<m;++i)
	{
	for(j=0;j<n;++j)
	printf("%d ",b[i][j]);
	printf("\n");}
}
