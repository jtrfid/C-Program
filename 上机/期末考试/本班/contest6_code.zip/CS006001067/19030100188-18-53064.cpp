#include<stdio.h>
int main()
{
	int a[50],n,i,j,s,k,t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	s=a[1]-a[0];
	for(i=1;i<n-1;i++)
	{
		k=a[i+1]-a[i];
		if(k<s)
		s=k;
	}
	printf("%d",s);
	return 0;
}
