#include<stdio.h>


int an(int n)
{

	if(1==n) return 2;
	if(2==n) return 3;
	return
(n-1)*(n-1)+3*n-5;
}
int main()
{
	int i,m,k,arr[3]={0};

	scanf("%d%d",&m,&k);
	for(i=1;i<=k;i++)
	{
		switch(an(i)%m)
		{
			case 0:arr[0]++;break;
			case 1:arr[1]++;break;
			default:arr[2]++;
		}
	}

	printf("%d %d %d",arr[0],arr[1],arr[2]);
	return 0;
	}
