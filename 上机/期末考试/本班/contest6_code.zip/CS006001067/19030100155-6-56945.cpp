#include<stdio.h>
int main(void)
{
	int y,d,n=0;
	scanf("%d %d",&y,&d);
	if((y%4==0&&y%100!=0)||y%400==0)
	{
		n=1;
	}
	if(y>=1900&&y<=2100)
	{
		if(((n==1)&&(d>=1&&d<=29))||((n==0)&&(d>=1&&d<=28)))
		{
			d=d%7;
			printf("%d",d);
		}
		else printf("-1");
	}
	else
	{
		printf("-1");
	}
}
