#include<stdio.h>
struct st{int a,b[20],c[20],d[20],e[20],s,x;
}st;
int main(){int i,j,k,n,max1,max2,min1,min2;
struct st m[20];
struct st temp;
scanf("%d",&n);
for(i=0;i<n;i++)
{
scanf("%d %d %d %d %d",&m[i].a,&m[i].b[i],&m[i].c[i],&m[i].d[i],&m[i].e[i]);m[i].s=m[i].c[i]+m[i].b[i]+m[i].d[i]+m[i].e[i];
if(m[i].b[i]>m[i].c[i])max1=m[i].b[i];else max1=m[i].c[i];if(m[i].d[i]>m[i].e[i])max2=m[i].d[i];else max2=m[i].e[i];if(max1>max2)m[i].s-=max1;else m[i].s-=max2;
if(m[i].b[i]<m[i].c[i])min1=m[i].b[i];else min1=m[i].c[i];if(m[i].d[i]<m[i].e[i])min2=m[i].d[i];else min2=m[i].e[i];if(min1<min2)m[i].s-=min1;else m[i].s-=min2;
}
for(i=0;i<n;i++)for(j=1;j<n-i;j++)if(m[j].s>m[j-1].s){temp=m[j-1];m[j-1]=m[j];m[j]=temp;}
printf("%d\n",m[0].a);for(i=1;i<n;i++)if(m[i].s==m[i-1].s)printf("%d\n",m[i].a);


	return 0;
}
