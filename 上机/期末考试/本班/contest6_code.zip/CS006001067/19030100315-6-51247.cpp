#include<bits/stdc++.h>
using namespace std;
int s(int a){
	if(a%4==0&&a%100!=0){
		return 1;
	}
	else if(a%4==0&&a%100==0&&a%400==0){
		return 1;
	}
	else if(a%4!=0){
		return 0;
	}
	else if(a%4==0&&a%100==0&&a%400!=0){
		return 0;
	}
}
void g(int a,int b){
	int n;
	n=b%7;
	cout<<n;
	return ;
}
int main(){
	int a;int b;
	cin>>a>>b;
	if(a<1900||a>2100){
		cout<<-1;
		return 0;
	}
	if(s(a)==1){
		if(b<0||b>29){
			cout<<-1;
		}
		else {
			g(a,b);
		}
	}
	if(s(a)==0){
		if(b,0||b>28){
			cout<<-1;
		}
		else {
			g(a,b);
		}
	}
	return 0;
}

