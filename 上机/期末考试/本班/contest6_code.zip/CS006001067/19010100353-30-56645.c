#include<stdio.h>
#include<math.h>
#include<string.h>
struct f
{
	int id;
	int score[4];
	int score1;
}p[21];
int main(int argc,const char *argv[])
{
	int i,j,m,n,k,ac,a[100],cnt=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d %d %d",&p[i].id,&p[i].score[0],&p[i].score[1],&p[i].score[2],&p[i].score[3]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<4;j++)
		{
			for(k=0;k<4-1-j;k++)
			{
				if(p[i].score[k]<p[i].score[k+1])
				{
					ac=p[i].score[k];
					p[i].score[k]=p[i].score[k+1];
					p[i].score[k+1]=ac;
				}
			}
		}
	}
	for(i=0;i<n;i++)
	p[i].score1=p[i].score[1]+p[i].score[2];
	j=p[0].score1;
	for(i=0;i<n-1;i++)
	{
		if(p[i+1].score1>p[i].score1)
		j=p[i+1].score1;
	}
	for(i=0;i<n;i++)
	{
		if(j==p[i].score1)
		{
		cnt++;
		a[i]=p[i].id;
		}
	}
	for(i=0;i<n;i++)
	for(k=0;k<n-1-i;k++)
	{
		if(a[k]>a[k+1])
		{
			ac=a[k];
			a[k]=a[k+1];
			a[k+1]=ac;
		}
	}
	
	for(i=0;i<cnt;i++)
	printf("%d\n",a[i]);
	return 0;
	
}
