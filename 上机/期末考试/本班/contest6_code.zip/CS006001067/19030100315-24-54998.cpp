#include<bits/stdc++.h>
float a[101][101];
using namespace std;
int main(){
	int m,n;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[j][i];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[j][i]==0){
				for(int h=1;h<=m;h++){
					if(a[h][i]!=0){
						a[h][i]=-2.5;
					}
				}
				for(int r=1;r<=n;r++){
					if(a[j][r]!=0){
						a[j][r]=-2.5;
					}
				}
				
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[j][i]==-2.5){
				a[j][i]=0;
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cout<<a[j][i]<<" ";
		}
		cout<<endl;
	}
	return 0;
}
