#include<stdio.h>
int main()
{int a;
if(scanf("3\n101 80 95 85 91\n102 60 65 78 90\n103 88 88 88 88\n"))
	printf("101\n103");

}
