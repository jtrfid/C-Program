#include<stdio.h>
int main()
{
	int m,n,x,y,i,j,a[50][50],b[50],c[50];
	scanf("%d%d",&m,&n);
	for(i=0;i<50;i++)
	{
		b[i]=-1;
		c[i]=-1;
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==0)
			{
				b[i]=i;
				c[j]=j;
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(i==b[i]||j==c[j])
			{
				a[i][j]=0;
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}
