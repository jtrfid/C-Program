#include<stdio.h>

int leap(int year)
{
	return (year%4==0&&
	        year%100!=0&&
	        year%400==0);
	        }
	int main()

	{
	
		int y,d,s;
		scanf("%d%d",&y,&d);
		if((y<1900||y>2100)||(leap(y)!=1&& d==29))
		{
			printf("-1");
		}
		else
		{
			switch((d-1)%7)
			{
				case
				0:printf("1");break;
				case
				1:printf("2");break;
				case
				2:printf("3");break;
				case
				3:printf("4");break;
				case
				4:printf("5");break;
				case
				5:printf("6");break;
				case
				6:printf("0");break;
			}
		}
		
		
	

	return 0;
}
