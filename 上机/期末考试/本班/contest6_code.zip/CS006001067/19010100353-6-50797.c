#include<stdio.h>
#include<math.h>
#include<string.h>
int main(int argc,const char *argv[])
{
	int i,j,n,d,date,day=28;
	scanf("%d %d",&n,&d);
	if(n%4==0&&n%10!=0)
	day++;
	if(n%400==0)
	day++;
	if(n>2100|n<1900|d>day|d<=0)
	printf("-1");
	else
	{
		d%=7;
		printf("%d",d);
	}
	
	
	
	
	return 0;
}
