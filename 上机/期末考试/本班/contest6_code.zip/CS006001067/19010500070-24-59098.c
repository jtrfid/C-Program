#include<stdio.h>
int main()
{
	int m,n,i,j,k,a[50][50],b[100],c[100],x=0;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==0)
			{
				b[x]=i;
				c[x]=j;
				x++;
			}
		}
	}
	for(k=0;k<x;k++)
	{
		for(j=0;j<n;j++)
		a[b[k]][j]=0;
	}
	for(k=0;k<x;k++)
	{
		for(i=0;i<m;i++)
		a[i][c[k]]=0;
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		printf("%d ",a[i][j]);
		printf("\n");
	}
}
