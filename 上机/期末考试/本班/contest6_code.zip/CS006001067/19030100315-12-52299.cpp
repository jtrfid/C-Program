#include<bits/stdc++.h>
using namespace std;
int a[1001];
int main(){
	a[1]=2;
	a[2]=3;
for(int i=3;i<=1000;i++){
	a[i]=(i-1)*(i-1)+3*(i-2)+1;
}
	int m,k;
	cin>>k>>m;
	int q,w,e;
	q=0;
	w=0;
	e=0;
	for(int i=1;i<=m;i++){
		if(a[i]%k==0){
			q++;
		}
		else if(a[i]%k==1){
			w++;
		}
	}
	e=m-q-w;
	cout<<q<<" "<<w<<" "<<e<<" ";
	return 0;
}

