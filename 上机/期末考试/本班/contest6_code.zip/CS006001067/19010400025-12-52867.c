#include<stdio.h>
int main()
{
	 long int a[100];
	 int i,j,m,k;
	int x=0,y=0,z=0;
	scanf("%d %d",&m,&k);
	a[0]=2;
	a[1]=3;
	
	for(i=2;i<k;i++)
	{
		a[i]=(i+1-1)*(i+1-1)+3*(i+1-2)+1;
	}
	for(i=0;i<k;i++)
	{
		if(a[i]%m==0)
		x=x+1;
		if(a[i]%m==1)
		y=y+1;
		if(a[i]%m>1)
		z=z+1;
		
	}
	printf("%d %d %d",x,y,z);
	return 0;
}
