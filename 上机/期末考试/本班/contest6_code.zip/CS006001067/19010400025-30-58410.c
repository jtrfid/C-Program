#include<stdio.h>
#include<string.h>
struct person
{
	int name;
	int a[100];
	float num;
}per[20];
int main()
{
	int n,i,j,k,temp,leap=0;
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d %d %d",&per[i].name,&per[i].a[0],&per[i].a[1],&per[i].a[2],&per[i].a[3]);
	}
	for(i=0;i<n;i++)
	{
		for(k=0;k<3;k++)
		{
			for(j=k+1;j<4;j++)
			{
				if(per[i].a[k]>per[i].a[j])
				{temp=per[i].a[k];
				per[i].a[k]=per[i].a[j];
				per[i].a[j]=temp;
					
				}
			}
		}
	per[i].num=(per[i].a[1]*1.0+per[i].a[2]*1.0)/2;
	}
	for(i=0;k<n-1;k++)
	{
		for(j=i+1;j<n;j++)
		{
			if(per[i].num<per[j].num)
			{
				temp=per[i].num;
				per[i].num=per[i].num;
				per[i].num=temp;
				
				temp=per[i].name;
				per[i].name=per[i].name;
				per[i].name=temp;
			}
			
		}
	}
	for(i=0;k<n-1;k++)
	{
		for(j=i+1;j<n;j++)
		{
			if(per[i].num==per[j].num)
			{temp=per[i].name;
				per[i].name=per[i].name;
				per[i].name=temp;
				leap=1;}
        }
    }
    if(leap=1)
    {
    	for(i=0;i<n;i++)
    	{
    		if(per[i].num==per[0].num)
    		{
    		  	for(k=0;k<=i;k++)
    		  	{
    		  		printf("%d\n",per[k].name);
    		  	}
    		}
    	}
    }
    if(leap=0)
    printf("%d",per[0].name);
    return 0;
}

