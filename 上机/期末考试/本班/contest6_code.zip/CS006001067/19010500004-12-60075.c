#include<stdio.h>
int main()
{
	int y,d,date;
	scanf("%d %d",&y,&d);
	if(y>=1900&&y<=2100&&d>=1&&d<=28||29){
		if(y%4==0&&y%100!=0||y%400==0){
			date=d%7;
			printf("%d",date);
		}
		else{
			date=d%7;
			printf("%d",date);
		}
	}
	else{
		printf("-1");
	}
}
