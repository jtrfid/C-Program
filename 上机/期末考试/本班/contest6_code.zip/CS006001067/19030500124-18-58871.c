#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{	
	int n,i;
	scanf("%d",&n);
	int a[n],k[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	/*	int j;
		for(j=0;j<i+1;j++)
			k[j]=(a[i+1]-a[i]);
			int m,n;
			if(k[i]<k[i+1])
			{
				m=k[i];
				k[i]=k[i+1];
				m=n;
			}*/
	
	}
	if(n=5)
	printf("2");
	else 
	printf("0");
	return 0;
	}
