#include<stdio.h>
int main()
{
	int m,k,a=0,b=0,c=0,i,x[200];
	scanf("%d %d",&m,&k);
	for(i=0;i<k;i++)
	{
		if(i==0) x[i]=2;
		else if(i==1) x[i]=3;
		else x[i]=i*i+3*i-2;
	}
	for(i=0;i<k;i++)
	{
		if(x[i]%m==0) a++;
		else if(x[i]%m==1) b++;
		else c++;
	}
	printf("%d %d %d",a,b,c);
}
