#include<stdio.h>
int main()
{
	int y(int x);
	int m,k,i,c=0,d=0,e=0;
	scanf("%d %d",&m,&k);
	for(i=1;i<=k;++i)
	{
	if(y(i)%m==0) c++;
	if(y(i)%m==1) d++;
	if(y(i)%m>1) e++;}
	printf("%d %d %d",c,d,e);
}
 int y(int x)
{
	int f;
	if(x==1)
	f=2;
	else if(x==2)
	f=3;
	if(x>2)
	f=(x-1)*(x-1)+3*(x-2)+1;
	return(f);
}
