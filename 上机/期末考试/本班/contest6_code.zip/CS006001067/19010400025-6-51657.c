#include<stdio.h>
int main()
{
	int y,d,leap=0,c;
	scanf("%d %d",&y,&d);
	if(y%4==0)
	{
		if(y%100!=0)
		{
			leap=1;
		}
		if(y%100==0)
		{
			if(y%400==0)
			{
				leap=1;
			}
		}
	}
	
	if(((leap==0&&d<=28)||(leap==1&&d<=29))&&(y>=1900&&y<=2100))
	{if(d%7==1)
	c=1;
	if(d%7==2)
	c=2;
	if(d%7==3)
	c=3;
	if(d%7==4)
	c=4;
	if(d%7==5)
	c=5;
	if(d%7==6)
	c=6;
	if(d%7==0)
	c=7;
	printf("%d",c);
	}
	else
	printf("-1");
	
}
