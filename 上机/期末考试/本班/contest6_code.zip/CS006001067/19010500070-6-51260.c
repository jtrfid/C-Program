#include<stdio.h>
int main()
{
	int y,d;
	scanf("%d %d",&y,&d);
	if(y%4==0&&y%100!=0||y%400==0)
	{
		if(y>=1900&&y<=2100)
		{
			if(d>=1&&d<=7) printf("%d",d);
			else if(d>=8&&d<=29)
			{
				if(d%7==0) printf("0");
				else printf("%d",d%7);
			}
			else printf("-1");
		}
		else printf("-1");
	}
	else 
	{
		if(y>=1900&&y<=2100)
		{
			if(d>=1&&d<=7) printf("%d",d);
			else if(d>=8&&d<=28)
			{
				if(d%7==0) printf("0");
				else printf("%d",d%7);
			}
			else printf("-1");
		}
		else printf("-1");
	}
	return 0;
}
