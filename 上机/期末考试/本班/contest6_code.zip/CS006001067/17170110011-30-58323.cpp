#include<stdio.h>
#include<stdlib.h>
int i;
int cmp(void const*a,void const*b)
{
	return*(int*)a<*(int*)b?-1:1;
}
int main()
{
	int ma=0,p=0,b[30];
	int m=0;
	int n;
	scanf("%d",&n);
	int a[30][10];
	int j;
	for(j=0;j<n;j++)
	{
		for(i=0;i<5;i++)
		scanf("%d",&a[j][i]);
		qsort(a[j]+1,4,sizeof a[j][0],cmp);
		a[j][5]=a[j][2]+a[j][3];
		if(a[j][5]>ma)
		{
			ma=a[j][5];
		}
	for(i=0;i<n;i++)
	if(a[i][5]==ma)
	b[p++]=a[j][5];
	for(i=0;i<p-1;i++)
	printf("%d\n",b[i]);
	printf("%d",b[p-1]);
	return 0;
}
}

