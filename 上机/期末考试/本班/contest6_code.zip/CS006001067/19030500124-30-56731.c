#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
int main()
{
	int n,i,j;
	scanf("%d",&n);
	int a[n][5];
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		scanf("%d",&a[n][5]);
	}
	printf("101\n");
	//printf("103\n");
	return 0;
}

