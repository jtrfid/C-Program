#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],i,j,d,min;
	for(i=0;i<=n-1;i++) scanf("%d",&a[i]);
	min=a[1]-a[0];
	if(min<0) min=-min;
	for(i=1;i<=n-1;i++)
	{
		for(j=i;j<=n-1;j++)
		{
			d=a[j]-a[j-1];
			if(d<0) d=-d;
			if(d<min) min=d;
		}
	}
	printf("%d\n",min);
	return 0;
}
