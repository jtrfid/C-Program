#include<stdio.h>
#include<math.h>
int main()
{int n;
scanf("%d",&n);
int min=999999999;
int i,j,t,m;
int a[n];
for(i=0;i<n;i++)
{scanf("%d ",&a[i]);}
	for(j=0;j<n;j++)
	{for(t=0;t<n;t++)
	if(j!=t)
	{m=a[j]-a[t];
	if(m<0)
	m=-m;
	if(m<min)
	min=m;}
	}
	printf("%d",min);
	return 0;
}
