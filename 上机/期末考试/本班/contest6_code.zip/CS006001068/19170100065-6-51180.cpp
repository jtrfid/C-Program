#include<stdio.h>
int main()
{
	int y,d,a;
	scanf("%d%d",&y,&d);
	if(y<1900||y>2100)
	printf("-1");
	else
	{
		if((y%4==0&&y%100!=0)||y%400==0)
		{
			if(d<1||d>29)
			printf("-1");
			else
			{
				a=d%7;
				printf("%d",a);
			}
		}
		else
		{
			if(d<1||d>28)
			printf("-1");
			else
			{
				a=d%7;
				printf("%d",a);
			}
		}
	}
	return 0;
}
