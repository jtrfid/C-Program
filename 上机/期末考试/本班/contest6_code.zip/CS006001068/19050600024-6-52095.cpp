#include<stdio.h>
int main()
{
	int y,d,date;
	scanf("%d %d",&y,&d);
	if((y%4==0&&y%100!=0)||y%400==0)
	{
		if(d==29||d==1||d==8||d==15||d==22)
		date=1;
		if(d==2||d==9||d==16||d==23)
		date=2;
		if(d==3||d==10||d==17||d==24)
	    date=3;
		if(d==4||d==11||d==18||d==25)
        date=4;
		if(d==5||d==12||d==19||d==26)
        date=5;
		if(d==6||d==13||d==20||d==27)
        date=6;
		if(d==7||d==14||d==21||d==28)
        date=0;
	}
	else
	{
		if(d==1||d==8||d==15||d==22)
		date=1;
		if(d==2||d==9||d==16||d==23)
		date=2;
		if(d==3||d==10||d==17||d==24)
		date=3;
		if(d==4||d==11||d==18||d==25)
		date=4;
		if(d==5||d==12||d==19||d==26)
		date=5;
		if(d==6||d==13||d==20||d==27)
		date=6;
		if(d==7||d==14||d==21||d==28)
		date=0;
		if(d==29)
		date=-1;
	}
	if(y<1900||y>2100)
	date==-1;
	printf("%d",date);
	return 0;
}
