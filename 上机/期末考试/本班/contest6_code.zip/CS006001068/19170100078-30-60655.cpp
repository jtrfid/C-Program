# include <stdio.h>
int main()
{
	int m,i,j,k,t,p,min;
	scanf("%d",&m);
	int a[m][5];
	for(i=0;i<m;i++)
	 for(j=0;j<5;j++)
	  scanf("%d",&a[i][j]);
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			for(k=1;k<3-j;k++)
			 if(a[i][k]>a[i][k+1])
			 {t=a[i][k];a[i][k]=a[i][k+1];a[i][k+1]=t;}
		}
	}
	int e[m];
	for(i=0;i<m;i++)
	 {
	 	e[i]=a[i][1]+a[i][2];
	 }
	min=e[0];
	for(i=1;i<m;i++)
	{
		if(min<e[i])
		min=e[i];
		p=i;
	}
	printf("%d",a[i][0]);
	return 0;
}
