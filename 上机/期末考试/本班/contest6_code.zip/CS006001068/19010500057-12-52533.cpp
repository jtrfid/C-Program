#include<stdio.h>
int main()
{
	int w[200],k,m,a,b,c,i;
	w[0]=2;
	w[1]=3;
	a=b=c=0;
	scanf("%d %d",&m,&k);
	for(i=2;i<k;i++)
	{
		w[i]=i*i+3*(i-1)+1;
	}
	for(i=0;i<k;i++)
	{
		if(w[i]%m==0)a+=1;
		else if(w[i]%m==1)b+=1;
		else c+=1;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
