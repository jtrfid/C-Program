#include<stdio.h>
int main()
{
	int p,n,i,m,t=0;
	int b[100];
	scanf("%d %d",&p,&n);
	for(i=0;i<n;i++)
	{
		if(i==0)
		{
			m=2;b[t]=m;t++;
		}else if(i==1)
		{
			m=3;b[t]=m;t++;
		}else m=i*i+3*(i-1)+1;b[t]=m;t++;
	}
	for(i=0;i<t;i++)
	{
		if(b[i]%p==0)
		{
			printf("%d ",i);
		}else if(b[i]%p==1)
		{
			printf("%d ",i);
		}
	}	
	return 0;
}
