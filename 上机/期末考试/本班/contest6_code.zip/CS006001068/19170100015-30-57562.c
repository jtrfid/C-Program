#include <stdio.h>
int main()
{int n,i,j,k,t;
 scanf("%d",&n); 
int c[n],d[n];
 struct s
 {int no;
  int m[4];
  int pjf;
 }re[n];
 for(i=0;i<n;i++)scanf("%d %d %d %d %d",&re[i].no,&re[i].m[0],&re[i].m[1],&re[i].m[2],&re[i].m[3]);
  if(n==1)printf("%d",re[0].no);
 if(n>1){
 for(i=0;i<n;i++)
  {for(j=0;j<4-1;j++)
   for(k=0;k<4-1-j;k++)if(re[i].m[k]>re[i].m[k+1]){t=re[i].m[k];re[i].m[k]=re[i].m[k+1];re[i].m[k+1]=t;}
   re[i].pjf=re[i].m[1]+re[i].m[2];}
 for(i=0;i<n;i++){c[i]=re[i].pjf;d[i]=re[i].no;}
 for(i=0;i<n-1;i++)
  for(j=0;j<n-j-1;j++)if(c[j]<c[j+1]){t=c[j];c[j]=c[j+1];c[j+1]=t;t=d[j];d[j]=d[j+1];d[j+1]=t;}
 for(i=0;i<n;i++)
 if(c[i]==c[0])
 printf("%d\n",d[i]);}
 return 0;
}
