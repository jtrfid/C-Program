#include <stdio.h>
int main()
{int m,k,i,an,x1=0,x2=0,x3=0;
 scanf("%d %d",&m,&k);
 for(i=1;i<=k;i++)
 {if(i==1)an=2;
  if(i==2)an=3;
  if(i>2)an=(i-1)*(i-1)+3*(i-2)+1;
  if(an%m==0)x1=x1+1;
  if(an%m==1)x2=x2+1;
  if(an%m>1)x3=x3+1;}
printf("%d %d %d",x1,x2,x3);
return 0;
}
 	
	
	
	
	
	
	

