
#include<stdio.h>
int main()
{
	int m,n,i,j,t,s=0,d;
	scanf("%d%d",&m,&n);
	int a[50][50];
	int b[50],c[50];
	for(i=0;i<50;i++)
	{
		for(j=0;j<n;j++)
		{
			a[i][j]=0;
			b[j]=0;
			c[j]=0;
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==0)
			{
				b[s]=i;
				c[s]=j;
				s++;
			}
		}
	}
	for(i=0;i<s;i++)
	{
		d=b[i];
		for(j=0;j<n;j++)
		a[d][j]=0;
	}
	for(i=0;i<s;i++)
	{
		d=c[i];
		for(j=0;j<m;j++)
		a[j][d]=0;
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}
