#include<stdio.h>
int main()
{int y,d,i,m;
 scanf("%d %d",&y,&d);
 if(y%4!=0||(y%4==0&&y%100==0&&y%400!=0))  m=28;
 else  m=29;
 if(d>m||y>2100||y<1900||d<1)   printf("-1");
 else
 {for(i=0;;i++)
   {if(d<7)  {
   printf("%d",d);  break;}
   if(d>=7)  d=d-7;
   }
 }
}
