#include<stdio.h>
int main()
{
	int m,k,yu,i,c1=0,c2=0,c3=0;
	scanf("%d%d",&m,&k);
	if(k==2)
{
		for(i=1;i<=2;i++)
	{
			if(i==1)
		{
			yu=2%m;
			if(yu==0)
			{
				c1++; 
			}
			else if(yu==1)
			{
				c2++;
			}
			else
			{
				c3++;
			}
		}
		else
		{
			yu=3%m;
			if(yu==0)
			{
				c1++; 
			}
			else if(yu==1)
			{
				c2++;
			}
			else
			{
				c3++;
			}
		}
	}
      printf("%d %d %d",c1,c2,c3);
}
			else
			{
						for(i=1;i<=k;i++)
						{
								if(i==1)
							{
								yu=2%m;
								if(yu==0)
								{
									c1++; 
								}
								else if(yu==1)
								{
									c2++;
								}
								else 
								{
									c3++;
								}
							}
							else if(i==2)
							{
								yu=3%m;
								if(yu==0)
								{
									c1++; 
								}
								else if(yu==1)
								{
									c2++;
								}
								else
								{
									c3++;
								}
							}
							else 
							{
								yu=((i-1)*(i-1)+3*(i-2)+1)%m;
									if(yu==0)
								{
									c1++; 
								}
								else if(yu==1)
								{
									c2++;
								}
								else
								{
									c3++;
								}
							}
						}
						printf("%d %d %d",c1,c2,c3);
			}
	return 0;
}
