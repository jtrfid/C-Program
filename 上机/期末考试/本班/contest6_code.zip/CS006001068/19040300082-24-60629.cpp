#include<stdio.h>
int main()
{
	int m,n,a[100][100],i,j,b[100],c[100],e=0,p,q,h;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
	    for(j=0;j<n;j++)
	    {
	    	scanf("%d",&a[i][j]);
	    }
	}
	for(i=0;i<m;i++)
	{
	
	    for(j=0;j<n;j++)
	    {
	         if(a[i][j]==0)
	         {
	         b[e]=i;
	         c[e]=j;
	         e+1;
	         }
	         
	    }
	}
	for(p=0;p<e;p++)
	{
		if(i==b[p]&&j==c[p])
		{
			for(q=0;q<n;q++)
			a[i][q]=0;
			for(h=0;h<m;h++)
			a[h][j]=0;
		}
	}
	for(i=0;i<m;i++)
	{
	    for(j=0;j<n;j++)
	    {
	    	printf("%d",&a[i][j]);
	    }
	}
	
	
}
