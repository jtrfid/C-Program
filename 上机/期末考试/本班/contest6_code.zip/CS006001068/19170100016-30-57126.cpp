#include<stdio.h>
#include<math.h>
int main()
{int n,i,j,min,max,t,p,q;
 scanf("%d",&n);
 int a[n][5],b[n];
 for(i=0;i<n;i++)
 b[i]=0;
 for(i=0;i<n;i++)
 for(j=0;j<5;j++)
 scanf("%d",&a[i][j]);
 for(i=0;i<n;i++)
{min=100,max=0;
 for(j=1;j<5;j++)
 {if(a[i][j]<min)   min=a[i][j],q=j;
 if(a[i][j]>max)   max=a[i][j],p=j;
 }
 if(max!=min)  a[i][p]=0,a[i][q]=0;
 else  a[i][1]=0,a[i][2]=0;
}
for(i=0;i<n;i++)
for(j=1;j<5;j++)
b[i]+=a[i][j];
max=0;
for(i=0;i<n;i++)
if(b[i]>max)  max=b[i];
for(i=0;i<n;i++)
 if(b[i]==max)  printf("%d\n",a[i][0]);
}
