#include<stdio.h>
int main ()
{
int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,sum,sun,sub;
scanf("%d",&a);
scanf("%d %d %d %d %d",&b,&c,&d,&e,&k);
scanf("%d %d %d %d %d",&f,&g,&h,&i,&j);
scanf("%d %d %d %d %d",&l,&m,&n,&o,&p);
sum=c+d+e+k;
sun=g+h+i+j;
sub=m+n+o+p;
if(sum>sun&&sum>sub)
{
printf("%d",b);
}
if(sun>sum&&sun>sub)
{
printf("%d",f);
}
if(sub>sum&&sub>sun)
{
printf("%d",l);
}
return 0;
}
