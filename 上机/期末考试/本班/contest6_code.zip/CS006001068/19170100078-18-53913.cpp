# include <stdio.h>
int main()
{
	int n,m,i,j,h=0,d,x;
	scanf("%d",&n);
	int a[n],e[n*(n-1)/2];
	for(i=0;i<n;i++)
	 scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	 for(j=i+1;j<n;j++)
	 {
	    if(a[i]>a[j]) {d=a[i];x=a[j];}
	    else {d=a[j];x=a[i];}
	 	e[h]=d-x;
	 	h=h+1;
	 }
	for(i=0;i<n*(n-1)/2;i++)
	 if(e[i]>e[i+1])
	 h=e[i+1];
	printf("%d",h);
	return 0;
}
