#include<stdio.h>
#include<string.h>
#include<math.h>
struct Person
{
	int num;
	int s1;
	int s2;
	int s3;
	int s4;
	int s5;
};

int main()
{
	int n,i,j,k,t,max,min;
	scanf("%d",&n);
	struct Person a[n],temp;
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d %d %d",&a[i].num,&a[i].s1,&a[i].s2,&a[i].s3,&a[i].s3);
	}
	for(i=0;i<n;i++)
	{
		max=a[i].s1;
		if(a[i].s2>max)
		max=a[i].s2;
		if(a[i].s3>max)
		max=a[i].s3;
		if(a[i].s4>max)
		max=a[i].s4;
		min=a[i].s1;
		if(a[i].s2<min)
		min=a[i].s2;
		if(a[i].s3<min)
		min=a[i].s3;
		if(a[i].s4<min)
		min=a[i].s4;
		a[i].s5=a[i].s1+a[i].s2+a[i].s3+a[i].s4-max-min;
	}
	for(i=0;i<n-1;i++)
	for(j=0;j<n-i-1;j++)
	if(a[j].s5<a[j+1].s5)
	{
		temp=a[j];
		a[j]=a[j+1];
		a[j+1]=temp;
	}
	int x=1;
	for(i=0;i<n;i++)
	{
		if(a[i].s5==a[0].s5)
    	{
    		if(a[i].num>a[0].num)
    		{
    			temp=a[i];
	        	a[i]=a[0];
	        	a[0]=temp;
    		}
    		x=0;
    		printf("%d\n%d",a[0].num,a[i].num);
        }
	}
	if(x==1)
	printf("%d",a[0].num);
	return 0;
}
