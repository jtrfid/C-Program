#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int m,k,i,j,x=0,y=0,z=0;
	scanf("%d %d",&m,&k);
	int a[k+1];
	a[1]=2;
	a[2]=3;
	for(i=3;i<=k;i++)
	{
		a[i]=(i-1)*(i-1)+3*(i-2)+1;
	}
	for(i=1;i<k+1;i++)
	{
		if(a[i]%m==0)
		x++;
			if(a[i]%m==1)
			y++;
			if(a[i]%m>1)
			z++;
	}
	printf("%d %d %d",x,y,z);
	return 0;
}
