#include<stdio.h>
int main()
{
	int n,m,i,j,a[n][m],b[n][m];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	{scanf("%d",&a[i][j]);
	b[i][j]=a[i][j];}
	for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	if(a[i][j]==0)
	{for(i=0;i<n;i++)b[i][j]=0;
	for(j=0;j<n;j++)b[i][j]=0;
	}
	for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	printf("%d",b[i][j]);
	return 0;
}
