#include<stdio.h>
int main()
{
	int a[1000],i,j,k,m,e=0,b=0,c=0;
	scanf("%d %d",&m,&k);
	a[0]=2;
	a[1]=3;
	for(i=2;i<k;i++)
	{
		a[i]=i*i+3*(i-1)+1;
	
	}
	for(j=0;j<k;j++)
	{
		if(a[j]%m==0)
		{
		e=e+1;
     	}
		if(a[j]%m==1)
		{
		b=b+1;
	}
		if(a[j]%m>1)
		{
			c=c+1;
		}
	}
	printf("%d %d %d",e,b,c);
}
