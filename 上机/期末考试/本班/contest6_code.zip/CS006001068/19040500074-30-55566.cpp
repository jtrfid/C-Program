#include<stdio.h>

int main()
{
	struct p
	{
		char name[3];
		int a[20][4];
	}p[20];
	int i, j, k, s, n, max, min, MAX;
	scanf("%d", &n);
	int b[20] = {0}, c[20] = {0};
	for(i = 0; i < n; i++)
	{
		scanf("%s", &p[i].name);
		for(j = 0; j < 4; j++)
		{
			scanf("%d", &p[i].a[i][j]);
			b[i] += p[i].a[i][j];
		}
	}
	for(i = 0; i < n; i++)
	{
		max = -1;
		min = 101;
		for(j = 0; j < 4; j++)
		{
			if(max < p[i].a[i][j])
			    max = p[i].a[i][j];
			if(min > p[i].a[i][j])
			    min = p[i].a[i][j];
		}
		c[i] = (b[i] - max - min) / 2;
	}
	for(i = 0, MAX = 0; i < n; i++)
	{
		if(MAX < c[i])
		    MAX = c[i];
	}
	for(i = 0; i < n; i++)
	{
		if(MAX == c[i])
		printf("%s\n", p[i].name);
	}
	return 0;
}
