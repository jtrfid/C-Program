#include<stdio.h>
int main()
{
	int y,d,a,c=0;
	scanf("%d %d",&y,&d);
	if(y<1900||y>2100)
	printf("-1");
	if(y>=1900&&y<=2100)
	{
		if(y%400==0)
		{
			c=1;
			if(d>=1&&d<=29)
			{
				a=d%7;
				printf("%d",a);
			}
			if(d<1||d>29)
			printf("-1");
		}
		if(y%4==0&&y%100!=0)
		{
			c=1;
			if(d>=1&&d<=29)
			{
				a=d%7;
				printf("%d",a);
			}
			if(d<1||d>29)
			printf("-1");
		}
		if(c==0)
		{
			if(d>=1&&d<=28)
			{
				a=d%7;
				printf("%d",a);
			}
			if(d<1||d>28)
			printf("-1");
		}
		
	}
	
}
