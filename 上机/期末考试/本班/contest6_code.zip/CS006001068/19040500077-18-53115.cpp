#include<stdio.h>
#include<stdlib.h>

int main()
{int n;
scanf("%d",&n);
 int a[n];
 int i;
 for(i=0;i<n;i++)
 {scanf("%d",&a[i]);
 }
 int j;

 int min=abs(a[1]-a[0]);
 for(i=0;i<n;i++)
  for(j=i+1;j<n;j++)
   { if(abs(a[i]-a[j])<min) {min=abs(a[i]-a[j]);
   }
   }
printf("%d",min);
	return 0;
}


