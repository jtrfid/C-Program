#include<stdio.h>
int main()
{
	int n,i,b,c,j;
	scanf("%d\n",&n);
	int a[n];
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(a[j]<a[j+1])
			{
				b=a[j];
		    	a[j]=a[j+1];
		    	a[j+1]=b;
			}
		}
	}
	c=a[0]-a[1];
	for(i=0;i<n-1;i++)
	{
		b=a[i]-a[i+1];
		if(c>b)
		c=b;
	}
	printf("%d",c);
	return 0;
}
