#include <stdio.h>
int main()
{
	int y,d,date,t;
	scanf("%d %d\n",&y,&d);
//	if(y<1900||y>2100)
//{
//	if(d<1||d<28)
//	date=-1;
//}
//	printf("%d\n",date);

//	 {
//	 	if(y%400==0)
//	 	while (d>29||d<1)
//	 	date=-1;
//	 	printf("%d\n",date);
//	 }
	 
	t=d%7;
	
    if (t=1)
    date=1;
      printf("%d\n",date);
       else if(t=2)
        date=2;
        printf("%d\n",date);
        else if(t=3)
         date=3;
        printf("%d\n",date);
         else if(t=4)
          date=4;
        printf("%d\n",date);
          else if(t=5)
           date=5;
         printf("%d\n",date);
           else if(t=6)
            date=6;
          printf("%d\n",date);
            else if(t=0)
             date=0;
             printf("%d\n",date);
             
	return 0;
}
