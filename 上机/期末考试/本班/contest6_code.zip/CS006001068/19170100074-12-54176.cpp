#include<stdio.h>
int main()
{
	int m;int k;
	int n,i=0,j=0,t=0;
	scanf("%d %d",&m,&k);
	if(k==1)
	{if(2%m==0)
	printf("1 0 0");
	if(2%m==1)
	printf("0 1 0");
	if(2%m>1);
	printf("0 0 1");
	}
	if(k==2)
	{if(2%m==0&&3%m==0)
	printf("2 0 0");
	if(2%m==0&&3%m==1)
	printf("1 1 0");
	if(2%m==0&&3%m>1)
	printf("1 0 1");
	if(2%m==1&&3%m==0)
	printf("1 1 0");
	if(2%m==1&&3%m==1)
	printf("0 2 0");
	if(2%m==1&&3%m>1)
	printf("0 1 1");
	if(2%m>1&&3%m==0)
	printf("1 0 1");
	if(2%m>1&&3%m==1)
	printf("0 1 1");
	if(2%m>1&&3%m>1)
	printf("0 0 2");
	}
	if(k>3)
	for(n=3;n<=k;n++)
	{if((n*n+n-4)%m==0)
	i=i+1;
	if((n*n+n-4)%m==1)
	j=j+1;
	if((n*n+n-4)%m>1)
	t=t+1;
	}
	if(2%m==0&&3%m==0)
	printf("%d %d %d",i+2,j,t);
	if(2%m==0&&3%m==1)
	printf("%d %d %d",i+1,j+1,t);
	if(2%m==0&&3%m>1)
	printf("%d %d %d",i+1,j,t+1);
	if(2%m==1&&3%m==0)
	printf("%d %d %d",i+1,j+1,t);
	if(2%m==1&&3%m==1)
	printf("%d %d %d",i,j+2,t);
	if(2%m==1&&3%m>1)
	printf("%d %d %d",i,j+1,t+1);
	if(2%m>1&&3%m==0)
	printf("%d %d %d",i+1,j,t+1);
	if(2%m>1&&3%m==1)
	printf("%d %d %d",i,j+1,t+1);
	if(2%m>1&&3%m>1)
	printf("%d %d %d",i,j,t+2);
	return 0;
	
}
