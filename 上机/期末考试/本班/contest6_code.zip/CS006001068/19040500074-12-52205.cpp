#include<stdio.h>

int main()
{
	int i, n, m, k, sum1, sum2, sum3, a[100];
	sum1 = sum2 = sum3 = 0;
	a[0] = 2;
	a[1] = 3;
	for(i = 2; i < 1000; i++)
	    a[i] = i * i + 3 * i - 2;
	scanf("%d %d", &m, &k);
	for(i = 0; i < k; i++)
	{
		if(a[i] % m == 0)
		    sum1++;
		if(a[i] % m == 1)
		    sum2++;
		if(a[i] % m >= 2)
		    sum3++;
	}
	printf("%d %d %d", sum1, sum2, sum3);
	return 0;
}
