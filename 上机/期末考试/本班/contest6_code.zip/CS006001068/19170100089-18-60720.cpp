#include<stdio.h>
int main ()
{
int a[100],b,c,d,e,f,g,h,i,j,k,l,m,n;
scanf("%d",&b);
scanf("%d",&a[i]);
for(i=0;i<50;i++)
for(j=0;j<49;j++)
if(a[j]<a[j+1])
a[j]=m;
m=a[j+1];
a[j+1]=a[j];
printf("%d",a[j]);
return 0;
}
