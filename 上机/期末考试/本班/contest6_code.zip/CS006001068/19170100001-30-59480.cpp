#include<stdio.h>
int main()
{
	struct jin
	{
		int hao;
		int a;
		int b;
		int c;
		int d;
		float ping;
	};
	struct jin stu[20],t;
	int n,i,j,k,max=-1,min=101,cnt=0;
	float maxx;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d %d %d",&stu[i].hao,&stu[i].a,&stu[i].b,&stu[i].c,&stu[i].d);
		if(stu[i].a>max)
		{
			max=stu[i].a;
		}
			if(stu[i].b>max)
			{
				max=stu[i].b; 
			}
					if(stu[i].c>max)
				{
					max=stu[i].c; 
				}
						if(stu[i].d>max)
					{
						max=stu[i].d; 
					} 
									if(stu[i].a<min)
								{
									min=stu[i].a;
								}
									if(stu[i].b<min)
									{
										min=stu[i].b; 
									}
											if(stu[i].c<min)
										{
											min=stu[i].c; 
										}
												if(stu[i].d<min)
											{
												min=stu[i].d; 
											} 
						stu[i].ping=(stu[i].a+stu[i].b+stu[i].c+stu[i].d)*1.0/4-(max+min)*1.0/2;
	}
	       for(i=0;i<n-1;i++)
	       {
	       	for(j=0;j<n-1-i;j++)
	       	{
	       		if(stu[j].ping<stu[j+1].ping)
	       		{
	       			t=stu[j+1];	stu[j+1]=stu[j];	stu[j]=t;
	       		}
	       	}
	       }
	    maxx=stu[0].ping;
	     for(i=0;i<n-1;i++)
		 { 
			  if(stu[i].ping==max)
		     {
		     	cnt++;
		 	 }
	     }
	     for(i=0;i<cnt;i++)
	     {
	     	printf("%d\n",stu[i].hao);
	     }
	return 0; 
}
