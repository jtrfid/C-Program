#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d %d",&a,&b);
	if(a<1900||a>2100)
	{
		c=-1;
	}
	else if(a%4==0&&a%100!=0||a%400==0)
	{
		c=b%7;
	}else {
		if(b>=29)
		{
			c=-1;
		}else c=b%7;
	}
	printf("%d",c);
	return 0;
}
