#include<stdio.h>
int main()
{int m,k,i,q=0,w=0,e=0;
 scanf("%d %d",&m,&k);
 int a[k];
 for(i=0;i<k;i++)
 {if(i==0)  a[i]=2;
 if(i==1)  a[i]=3;
 if(i>1)   a[i]=i*i+3*(i-1)+1;
 }
 for(i=0;i<k;i++)
 {if(a[i]%m==0) q++;
 if(a[i]%m==1)  w++;
 if(a[i]%m>1)  e++;
 }
 printf("%d %d %d",q,w,e);
}
