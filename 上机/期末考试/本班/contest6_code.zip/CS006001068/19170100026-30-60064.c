#include<stdio.h>
#include<string.h>
#include<math.h>
struct Person
{
	int num;
	int s1;
	int s2;
	int s3;
	int s4;
	int s5;
};

int main()
{
	int n,i,j,k,t,max,min;
	scanf("%d",&n);
	struct Person a[n],temp;
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d %d %d",&a[i].num,&a[i].s1,&a[i].s2,&a[i].s3,&a[i].s3);
	}
	for(i=0;i<n;i++)
	{
		max=a[i].s1;
		if(a[i].s2>max)
		max=a[i].s2;
		if(a[i].s3>max)
		max=a[i].s3;
		if(a[i].s4>max)
		max=a[i].s4;
		min=a[i].s1;
		if(a[i].s2<min)
		min=a[i].s2;
		if(a[i].s3<min)
		min=a[i].s3;
		if(a[i].s4<min)
		min=a[i].s4;
		a[i].s5=a[i].s1+a[i].s2+a[i].s3+a[i].s4-max-min;
	}
	max=a[0].s5;
	for(i=0;i<n;i++)
	{
		if(a[i].s5>max)
		max=a[i].s5;
	}
	for(i=0;i<n;i++)
	{
		if(a[i].s5>=max)
		printf("%d\n",a[i].num);
	}
	return 0;
}
