#include<stdio.h>

int main()
{
	int y, d, m;
	scanf("%d %d", &y, &d);
	m = d / 7;
	if(y % 4 == 0 && y % 100 != 0)
	{
		if(m * 7 == d)
		printf("0");
		else
		printf("%d", (d - m * 7));
	}
	else
	{
		if(m * 7 == d)
		printf("0");
		else if(d == 29)
		printf("-1");
		else
		printf("%d", (d - m * 7));
	}
	return 0;
}
