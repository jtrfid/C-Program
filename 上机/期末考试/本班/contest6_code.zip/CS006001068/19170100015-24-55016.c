#include <stdio.h>
int main()
{int m,n,ji,i,j,k,z=0,x;scanf("%d %d",&m,&n);ji=m*n;
 int a[m][n];int b[ji];int c[m][n];
 for(i=0;i<m;i++)
  for(j=0;j<n;j++){scanf("%d",&a[i][j]);c[i][j]=1;}
 for(i=0;i<m;i++)
  for(j=0;j<n;j++)
   {if(a[i][j]==0)	
	{for(k=0;k<n;k++)c[i][k]=0;b[z]=j;z=z+1;}}
 for(j=0;j<z;j++)
  {x=b[j];
   for(i=0;i<m;i++)c[i][x]=0;}
 for(i=0;i<m;i++)
  for(j=0;j<n;j++)if(c[i][j]==0)a[i][j]=0;
 for(i=0;i<m;i++)
  {for(j=0;j<n;j++)printf("%d ",a[i][j]);printf("\n");}
 return 0;	
}
