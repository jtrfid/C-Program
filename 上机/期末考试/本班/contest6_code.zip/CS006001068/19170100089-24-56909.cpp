#include<stdio.h>
int main ()
{
int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;
scanf("%d %d",&a,&b);
scanf("%d %d %d %d",&c,&d,&e,&f);
scanf("%d %d %d %d",&g,&h,&i,&j);
scanf("%d %d %d %d",&k,&l,&m,&n);
if(f==0&&l==0)
{
e=0;d=0;c=0;j=0;n=0;h=0;k=0;m=0;
printf("%d %d %d %d",c,d,e,f);
printf("%d %d %d %d",g,h,i,j);
printf("%d %d %d %d",k,l,m,n);
}
return 0;
}
