#include<stdio.h>
int main()
{
	int a[50][50],m,n,i,j,b[50][50],h,l,k,p;
	scanf("%d %d",&m,&n);
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
			{
				scanf("%d",&a[i][j]);
				b[i][j]=a[i][j];
			}
		}
		for(i=0;i<m;i++)
		{    h=i;
			for(j=0;j<n;j++)
			{
				l=j;
				if(a[i][j]==0)
				{   
					for(k=0;k<n;k++)
					{  
						b[i][k]=0;
					 	for(p=0;p<m;p++)
					 	{
							b[l][p]=0;
					 	}
					}
				}
			}
		}
		for(i=0;i<m;i++)
		{
				for(j=0;j<n;j++)
				{
					printf("%d ",b[i][j]);
				}
				printf("\n");
		}	
		return 0;	
}
