#include<stdio.h>
int main()
{int y,d;
scanf("%d %d",&y,&d);

if((d%4==0&&d%100!=0)||d%400==0)	     //���� 
	{ if(d>29) printf("-1");
	   else 
	    { printf("%d",d%7);
	    }
	}
else 
{ if(d>28) printf("-1");
else printf("%d",d%7);
  
}	
	
	return 0;
}


