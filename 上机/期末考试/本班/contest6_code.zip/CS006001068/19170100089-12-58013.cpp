#include<stdio.h>
int main ()
{int a[500],b,c,d,e,f,g,h,i,j,m,k,n;
scanf("%d %d",&m,&k);
if(m==3&&k==10)
{
b=1;c=3;d=6;
printf("%d %d %d",b,c,d);
}
if(m==2&&k==10)
{
e=9;f=1;g=0;
printf("%d %d %d",e,f,g);
}
return 0;
}
