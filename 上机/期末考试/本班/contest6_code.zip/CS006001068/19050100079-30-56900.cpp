#include<stdio.h>
int main()
{
	int i,j,k,max=0,t,n,m=0;
	scanf("%d",&n);
	int a[n][5],num[20]={0};
	for(i=0;i<n;i++){
		for(j=0;j<5;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<5;j++){
			for(k=j;k<5;k++){
				if(a[i][j]>a[i][k]){
					t=a[i][k];
					a[i][k]=a[i][j];
					a[i][j]=t;
				}
			}
		}
		if((a[i][1]+a[i][2])>max){
			max=a[i][1]+a[i][2];
			num[0]=a[i][4];
		}
	}
	for(i=0;i<n;i++){
		if((a[i][2]+a[i][1])==max){
				num[m]=a[i][4];
				m++;
		}
	}
	for(i=0;i<m;i++){
		printf("%d\n",num[i]);
	}
	return 0;
}
