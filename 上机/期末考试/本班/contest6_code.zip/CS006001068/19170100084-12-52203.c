#include<stdio.h>
int main()
{
	int m,k,con1=0,con2=0,con3=0,i,an;
	scanf("%d %d",&m,&k);
	for(i=1;i<=k;i++)
	{
		if(i==1) an=2;
		if(i==2) an=3;
		if(i>2) an=(i-1)*(i-1)+3*(i-2)+1;
		if(an%m==0) con1++;
		if(an%m==1) con2++;
		if(an%m>1) con3++;
	}
	printf("%d %d %d\n",con1,con2,con3);
	return 0;
}
