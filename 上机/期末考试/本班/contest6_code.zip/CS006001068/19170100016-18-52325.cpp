#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{ int n,i,j,t,min=9999;
  scanf("%d",&n);
  int a[n];
  for(i=0;i<n;i++) scanf("%d",&a[i]);
  for(j=0;j<n-1;j++)
   for(i=0;i<n-1-j;i++)
   if(a[i]>a[i+1]) {t=a[i];a[i]=a[i+1];a[i+1]=t;}
  for(i=0;i<n-1;i++)
  {t=a[i+1]-a[i];
   if(t<min) min=t;
  }
  printf("%d",min);
 return 0;
}
