#include<stdio.h>
int main()
{
	int n,i,min,d;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	min=1000000;
	for (i=1;i<n;i++)
	{
		if(a[i]>=a[i-1])
		d=a[i]-a[i-1];
		else if(a[i]<a[i-1])
		d=a[i-1]-a[i];
		if(d<min)
		min=d;
		else
		continue;
	}
	printf("%d",min);
	return 0;
}
