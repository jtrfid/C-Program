#include<stdio.h>
int main()
{
	int n,i,k,j,t,max;
	scanf("%d",&n);
	int a[n][5],b[n];
	for(i=0;i<n;i++)
	{
	    for(k=0;k<5;k++)
		{
		    scanf("%d",&a[i][k]);
		}
	}
	for(i=0;i<n;i++)
	{
	    for(j=0;j<5;j++)
		{
			for(k=0;k<4;k++)
		    {
		        if(a[i][k+1]>a[i][k])
		    	{
		    	    t= a[i][k+1];
		    		a[i][k+1]=a[i][k];
		    		a[i][k]=t;
		    	}
		    }
		} 
	}
	for(i=0;i<n;i++)
	{
		b[i]=(a[i][2]+a[i][3])/2;
	} 
	max=b[0];
	for(i=1;i<n;i++)
	{
		if(b[i]>b[0]) max=b[i]; 
	}
	for(i=0;i<n;i++)
	{
		if(b[i]==max) printf("%d\n",a[i][0]); 
	}
	return 0;
}
