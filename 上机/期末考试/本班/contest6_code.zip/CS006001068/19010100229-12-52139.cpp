#include<stdio.h>
int s(int n)
{
	int q;
	if(n==2)
	q=3;
	if(n==1)
	q=2;
	if(n>2)
	q=(n-1)*(n-1)+3*(n-2)+1;
	return q;
}
int main()
{
	int m,k,sum=0,l=0,p=0;
	scanf("%d%d",&m,&k);
	for(int i=1;i<=k;i++)
	{
		if(s(i)%m==0)
		sum++;
		if(s(i)%m==1)
		l++;
		if(s(i)%m>1)
		p++;
	}
	printf("%d %d %d",sum,l,p);
	return 0;
}
