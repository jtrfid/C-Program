#include<stdio.h>
struct Student
{
	int num;
	int a;
	int b;
	int c;
	int d;
	int x;
}t[20];
int main()
{
	int n,i,p,q,v[20],w=0,j,h;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	 scanf("%d %d %d %d %d",&t[i].num,&t[i].a,&t[i].b,&t[i].c,&t[i].d);
	for(i=0;i<n;i++)
	{
		if(t[i].a>t[i].b)
		{
		 p=t[i].a;
		 q=t[i].b;
		}
		else
		{
			p=t[i].b;
			q=t[i].a;
		}
		if(t[i].c>p)
		 p=t[i].c;
		if(t[i].c<q)
		 q=t[i].c;
		if(t[i].d>p)
		 p=t[i].d;
		if(t[i].d<q)
		 q=t[i].d;
		t[i].x=t[i].a+t[i].b+t[i].c+t[i].d-p-q;
	}
	p=t[0].x;
	for(i=1;i<n;i++)
	{
		if(t[i].x>p)
		 p=t[i].x;
	}
	for(i=0;i<n;i++)
	{
		if(t[i].x==p)
		{
		 v[w]=t[i].num;
		 w++;
		}
	}
	if(w==1)
	 printf("%d\n",v[0]);
	else
	{
		for(i=0;i<w-1;i++)
		 for(j=0;j<w-1-i;j++)
		 {
		 	if(v[j]>v[j+1])
		 	{
		 		h=v[j];
		 		v[j]=v[j+1];
		 		v[j+1]=h;
		 	}
		 }
		 for(i=0;i<w;i++)
		  printf("%d\n",v[i]);
	}
	return 0;
}
