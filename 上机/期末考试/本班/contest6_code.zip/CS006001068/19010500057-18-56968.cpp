#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j,t;
	int *p;
	scanf("%d",&n);
	int a[n],b[100];
	p=&b[0];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			*p=fabs(a[j+1]-a[j]);
			p++;
		
		}
	}
	for(i=0;i<2*n-3;i++)
	{
		for(j=0;j<2*n-3-i;j++)
		{
			if(b[j]>b[j+1])
			{
				t=b[j];
				b[j]=b[j+1];
				b[j+1]=t;
			}
		}
	}
	printf("%d",b[0]);
	return 0;
	
}
