#include<stdio.h>
int main()
{
	int m,k,b=0,c=0,d=0,i;
	scanf("%d%d",&m,&k);
	int a[k];
	if(k==2)
	{
		a[0]=2%m;
		a[1]=3%m;
		for(i=0;i<k;i++)
		{
			if(a[i]==0)
			b=b+1;
			else if(a[i]==1)
			c=c+1;
			else
			d=d+1;
		}
	}
	else
	{
		a[0]=2%m;
		a[1]=3%m;
		for(i=2;i<k;i++)
		a[i]=((i-1)*(i-1)+3*(i-2)+1)%m;
		for(i=0;i<k;i++)
		{
			if(a[i]==0)
			b=b+1;
			else if(a[i]==1)
			c=c+1;
			else
			d=d+1;
		}
	}
	printf("%d\t%d\t%d",b,c,d);
	return 0;
}
