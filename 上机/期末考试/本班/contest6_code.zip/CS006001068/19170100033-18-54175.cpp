#include<stdio.h>
int main()
{
	int n,i,j,t,m;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	 scanf("%d",&a[i]);
	t=a[0]-a[1];
	if(t<0)
	 t=-t;
	for(j=0;j<n-1;j++)
	 for(i=0;i<n-1-j;i++)
	 {
	 	m=a[i]-a[i+1];
	 	if(m<0)
	 	 m=-m;
	 	if(m<t)
	 	 t=m;
	 }
	 printf("%d",t);
	 return 0;
}
