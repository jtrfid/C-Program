#include<stdio.h>
#include<math.h>
int main()
{
	int n,a[100];
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n-1;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(a[i]>a[j])
			{
				int m;
				m=a[i];
				a[i]=a[j];
				a[j]=m;
			}
		}
	}
	int min=pow(2,30);
	for(int i=0;i<n-1;i++)
	{
		if(a[i+1]-a[i]<min)
		{
			min=a[i+1]-a[i];
		}
	}
	printf("%d\n",min);
	return 0;
}
