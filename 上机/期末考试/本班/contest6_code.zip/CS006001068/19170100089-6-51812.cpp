#include<stdio.h>
int main ()
{
int a,b,c,d,e,f,g,h;
scanf("%d %d",&a,&b);
c=a%400;
d=a%4;
e=a%100;
f=b%7;
if(c==0)
{
if(b>=1&&b<=29)
{
printf("%d",f);
}
if(b>29)
{
g=-1;
printf("%d",g);
}
}
if(d==0&&e!=0)
{
if(b>=1&&b<=29)
{
printf("%d",f);
}
if(b>29)
{
g=-1;
printf("%d",g);
}
}
if(c!=0||d!=0)
{
if(b>=1&&b<=28)
{
printf("%d",f);
}
if(b>28)
{
g=-1;
printf("%d",g);
}
}
return 0;
}
