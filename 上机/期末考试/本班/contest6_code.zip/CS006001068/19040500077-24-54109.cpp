#include<stdio.h>


int main()
{int n,m;
scanf("%d %d",&n,&m);
int a[n][m];
int i,j;
for(i=0;i<n;i++)
 for( j=0;j<m;j++)
 {scanf("%d",&a[i][j]);
 }
 
 

 int arr[100][2]={{0}};
 int t=0;
for(i=0;i<n;i++)
 for( j=0;j<m;j++)
 {if(a[i][j]==0)
     {  arr[t][0]=j;
     arr[t][1]=i;
      t++;
     }
 }
 
 int temp;
 for(i=0;i<t;i++)
 {  for(temp=0;temp<m;temp++)
         { a[arr[t][1]][temp]=0;
         }
         for(temp=0;temp<n;temp++)
         { a[temp][arr[t][0]]=0;
         }
 }
 
 for(i=0;i<n;i++)
 {
 for( j=0;j<m;j++)
 {printf("%d ",a[i][j]);
 }
 putchar('\n');
}
	return 0;
}


