#include<stdio.h>
int main()
{
	int n,m,g,i,j,a[n][m],b[n][m],k;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	{scanf("%d",&a[i][j]);
	b[i][j]=a[i][j];}
	for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	if(a[i][j]==0)
	{k=j,g=i;for(i=0;i<n;i++)b[i][k]=0;
		for(j=0;j<m;j++)b[g][j]=0;}
	for(i=0;i<n;i++)
	{for(j=0;j<m;j++)
	printf("%d ",b[i][j]);
	if(j==m) printf("\n");};
	return 0;
}
