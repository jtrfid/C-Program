#include<stdio.h>
int main()
{
	int m,n;
	int j,k;
	int g=0;
	int b[g];
	scanf("%d %d",&m,&n);
	int a[m][n];
	for(j=0;j<m;j++)
	{for(k=0;k<n;k++)
	{
	scanf("%d ",&a[j][k]);}
	}
	for(j=0;j<m;j++)
	{for(k=0;k<n;k++)
	{if(a[j][k]==0)
	{b[g]=j;
	g=g+1;}
	break;}
	}
	for(j=0;j<g;j++)
	{
	for(k=0;k<n;k++)
	{a[b[j]][k]=0;}
	}
	for(j=0;j<m;j++)
	for(k=0;k<n;k++)
	printf("&d ",a[j][k]);
	printf("/n");
	return 0;
	
}
