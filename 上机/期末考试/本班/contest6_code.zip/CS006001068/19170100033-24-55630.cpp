#include<stdio.h>
int main()
{
	int m,n,i,j,p,q,d=0,t;
	scanf("%d %d",&m,&n);
	int a[m][n],b[m*n],c[m*n];
	for(i=0;i<m;i++)
	 for(j=0;j<n;j++)
	  scanf("%d",&a[i][j]);
	for(i=0;i<m;i++)
	 for(j=0;j<n;j++)
	 {
	 	if(a[i][j]==0)
	 	{
	 		b[d]=i;
	 		c[d]=j;
	 		d++;
	 	}
	 }
	 for(t=0;t<d;t++)
	 {
	 	i=b[t];
	 	j=c[t];
		for(p=0;p<m;p++)
		 a[p][j]=0;
		for(p=0;p<n;p++)
 		 a[i][p]=0;
	 }
	 for(i=0;i<m;i++)
	 {
	  for(j=0;j<n;j++)
	   printf("%d ",a[i][j]);
	  printf("\n");
     }
	return 0;
}
