#include<stdio.h>
#include<math.h>
int main()
{
	int n,a[1300],b[1300],i,j,g,cha,min=2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2,cnt=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{    if(a[i]<a[j])
				{
					b[cnt]=a[j]-a[i];
				}
				else
				{
					b[cnt]=a[i]-a[j];
				}
				cnt++;
			}
		}
		 g=n*(n-1)/2;
		 for(i=0;i<g;i++)
		 {
			 if(b[i]<min)
			 {
			 	min=b[i];
			 }
		 }
		 printf("%d\n",min);
}
