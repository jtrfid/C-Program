#include<stdio.h>
int main()
{
	int m,k,i,b,c,d;
	scanf("%d %d",&m,&k);
	int a[k];
	if (k==1)
	a[0]=2;
	if(k==2)
	a[0]=2,a[1]=3;
	if(k>2)
	{
		a[0]=2,a[1]=3;
		for(i=2;i<k;i++)
		a[i]=i*i+3*(i-1)+1;
	}
	b=c=d=0;
	for(i=0;i<k;i++)
	{
		if(a[i]%m==0)
		b++;
		if(a[i]%m==1)
		c++;
		if(a[i]%m>1)
		d++;
	}
	printf("%d %d %d",b,c,d);
	return 0;
}
