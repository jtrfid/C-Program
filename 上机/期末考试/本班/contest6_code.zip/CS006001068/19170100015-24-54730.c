#include <stdio.h>
int main()
{int m,n,ji,i,j,k,z=0,x;scanf("%d %d",&m,&n);ji=m*n;
 int a[m][n];int b[ji];
 for(i=0;i<m;i++)
  for(j=0;j<n;j++)scanf("%d",&a[i][j]);
 for(i=0;i<m;i++)
  for(j=0;j<n;j++)
  if(a[i][j]==0)	
	{for(k=0;k<n;k++)a[i][k]=0;b[z]=j;z=z+1;}
 for(j=0;j<z;j++)
  {x=b[j];
   for(i=0;i<m;i++)a[i][x]=0;}
 for(i=0;i<m;i++)
  {for(j=0;j<n;j++)printf("%d ",a[i][j]);printf("\n");}
 return 0;	
}
