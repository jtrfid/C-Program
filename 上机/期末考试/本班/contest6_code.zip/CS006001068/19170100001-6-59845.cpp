#include<stdio.h>


int main()
{
	int y,d,date;
	scanf("%d%d",&y,&d);
	if(y%4==0&&y%100!=0||y%400==0)
	{
		if(y<1900||y>2100||d<1||d>29) printf("-1");	
		else printf("%d",d%7);
	}
	else 
	{
		if(y<1900||y>2100||d<1||d>28) printf("-1");
		else printf("%d",d%7);	
	}
}
