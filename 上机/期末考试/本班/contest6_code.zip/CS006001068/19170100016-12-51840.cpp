#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{int m,k,i,x=0,y=0,z=0,t;
 scanf("%d %d",&m,&k);
 for(i=1;i<=k;i++)
 {if(i==1) t=2;
  if(i==2) t=3;
  if(i>2) t=(i-1)*(i-1)+3*(i-2)+1;
  if(t%m==0) x++;
  if(t%m==1) y++;
  if(t%m>1) z++;
 }
 printf("%d %d %d",x,y,z);
 return 0;
}
