#include <stdio.h>
int main()
{int y,d;
 scanf("%d %d",&y,&d);
 if(y>=1900&&y<=2100)
   {if(d>=1&&d<=28)
    {if(d%7==1)printf("%d",1);
     if(d%7==2)printf("%d",2);
     if(d%7==3)printf("%d",3);
	 if(d%7==4)printf("%d",4);
 	 if(d%7==5)printf("%d",5);
	 if(d%7==6)printf("%d",6);
	 if(d%7==0)printf("%d",0);}
   if((y%4==0&&y%100!=0||y%400==0)&&(d==29))printf("%d",1);
   }
  else printf("%d",-1);
  return 0;	
	
	
	
	
	
}
