#include<stdio.h>
int main()
{
	int n,i,t;
	scanf("%d",&n);
	int a[n],b[n-1];
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	b[0]=a[0]-a[1];
	for(i=1;i<n-1;i++)
	b[i]=a[i]-a[i+1];
	for(i=0;i<n-1;i++)
	if(b[i]<0)b[i]=-b[i];
	t=b[0];
	for(i=1;i<n-1;i++)
	if(b[i]<t)t=b[i];
	printf("%d",t);
	return 0;
}
