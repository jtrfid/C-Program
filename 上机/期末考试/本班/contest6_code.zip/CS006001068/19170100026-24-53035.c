#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int m,n,i,j,k=0;
	scanf("%d %d",&m,&n);
	int a[m][n];
	for(i=0;i<m;i++)
	for(j=0;j<n;j++)
	{
		scanf("%d",&a[i][j]);
	}
	int p[100]={0},q[100]={0};
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==0)
			{
				p[k]=i;
				q[k]=j;
				k++;
			}
		}
	}
	for(i=0;i<k;i++)
	{
		for(j=0;j<n;j++)
		{
			a[p[i]][j]=0;
		}
		for(j=0;j<m;j++)
		{
			a[j][q[i]]=0;
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}
