#include<stdio.h>
int main()
{
	int n,i,j,t;
	scanf("%d",&n);
    int a[n][5],b[n];
    for(i=0;i<n;i++)
    for(j=0;j<5;j++)
    scanf("%d",&a[i][j]);
    for(i=0;i<n;i++) b[i]=(a[i][1]+a[i][2]+a[i][3]+a[i][4])/4;
    t=b[0];
	for(i=1;i<n;i++)
	if(b[0]<=b[i])t=b[i];
	for(i=0;i<n;i++)
	if(b[i]==t)printf("%d\n",a[i][0]);
	return 0;
	
}
