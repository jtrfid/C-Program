#include<stdio.h>
int main ()
{
int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;
scanf("%d %d",&a,&b);
scanf("%d %d %d %d",&c,&d,&e,&f);
if(c==0||d==0||e==0||f==0)
{
c=0;d=0;e=0;f=0;
printf("%d %d %d %d",c,d,e,f);
}

return 0;
}
