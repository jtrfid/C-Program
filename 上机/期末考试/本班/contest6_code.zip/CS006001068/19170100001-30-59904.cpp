#include<stdio.h>
#include<math.h>
struct stu
{
	int b,p1,p2,p3,p4,p;
};
int sort(int a[])
{
	int i,j,temp,k;
	for(i=0;i<3;i++)
	{
		k=i;
		for(j=i+1;j<4;j++)
		{
			if(a[j]<a[k]) k=j;
		}
		if(k!=i)
		{
			temp=a[i];
			a[i]=a[k];
			a[k]=temp;
		}
	}
	return (a[1]+a[2])/2;
}
void sortss(struct stu s[],int n)
{
	int i,max,b[20],k=1,j;
	max=s[0].p;
	for(i=0;i<n;i++)
	{
		if(s[i].p>max)
		{
			b[0]=i;
			max=s[i].p;
		}
	}
	for(i=0;i<n;i++)
	{
		 if(i!=b[0]||max==s[i].p)
		{
			b[k]=i;
			k++;
		}
	}
	for(i=0;i<k+1;i++)
	{
	j=b[i];	
	printf("%d\n",s[j].b);
	}
}
int main()
{
	struct stu s[20];
	int i,n,a[3];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d%d%d",&s[i].b,&s[i].p1,&s[i].p2,&s[i].p3,&s[i].p4);
	}
	for(i=0;i<n;i++)
	{
		a[0]=s[i].p1;
		a[1]=s[i].p2;
		a[2]=s[i].p3;
		a[3]=s[i].p4;
		s[i].p=sort(a);
	}
//	sorts(s,n);
	for(i=0;i<n;i++)
	printf("%d",s[i].p);
	return 0;
}
