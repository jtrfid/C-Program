#include<stdio.h>
int main()
{
	int i,j,t,n,min;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		for(j=i;j<n;j++){
			if(a[i]>a[j]){
				t=a[j];
				a[j]=a[i];
				a[i]=t;
			}
		}
	}
	for(i=1,min=a[i]-a[i-1];i<n;i++){
		if((a[i]-a[i-1])<min){
			min=a[i]-a[i-1];
		}
	}
	printf("%d\n",min);
	return 0;
}
