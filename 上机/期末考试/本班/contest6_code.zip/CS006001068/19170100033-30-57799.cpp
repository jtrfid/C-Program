#include<stdio.h>
struct Student
{
	int num;
	int a;
	int b;
	int c;
	int d;
	int x;
}t[20];
int main()
{
	int n,i,p,q,v[20],w=0,j,h;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	 scanf("%d %d %d %d %d",&t[i].num,&t[i].a,&t[i].b,&t[i].c,&t[i].d);
	for(i=0;i<n;i++)
	{
		if(t[i].a>t[i].b)
		{
		 p=t[i].a;
		 q=t[i].b;
		}
		else
		{
			p=t[i].b;
			q=t[i].a;
		}
		if(t[i].c>p)
		 p=t[i].c;
		if(t[i].c<q)
		 q=t[i].c;
		if(t[i].d>p)
		 p=t[i].d;
		if(t[i].d<q)
		 q=t[i].d;
		t[i].x=t[i].a+t[i].b+t[i].c+t[i].d-p-q;
	}
	p=t[0].x;
	for(i=1;i<n;i++)
	{
		if(t[i].x>p)
		 p=t[i].x;
	}
	for(i=0;i<n;i++)
	{
		if(t[i].x==p)
		{
		 v[w]=i;
		 w++;
		}
	}
	if(w==1)
	 printf("%d\n",t[v[0]].num);
	else
	{
		for(i=0;i<w-1;i++)
		 for(j=0;j<w-1-i;j++)
		 {
		 	if(t[v[j]].num>t[v[j+1]].num)
		 	{
		 		h=t[v[j]].num;
		 		t[v[j]].num=t[v[j+1]].num;
		 		t[v[j+1]].num=h;
		 	}
		 }
		 for(i=0;i<w;i++)
		  printf("%d\n",t[i].num);
	}
	return 0;
}
