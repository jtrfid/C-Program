#include <stdio.h>
int main()
{
	int y,d,date,t;
	scanf("%d %d\n",&y,&d);
	if(y<1900||y>2100)
	  if(d>28||d<1)
	  date=-1;
	  printf("%d\n",date);
	//if(d=1)
	//date=1;
	//int i;
	//for(i=1;i<=7,i++)
	t=d%7;
	//switch(t)
//	case : 1 ;printf("1\n");break;
//	case : 2 ;printf("2\n");break;
//	case : 3 ;printf("3\n");break;
//	case : 4 ;printf("3\n");break;
//	case : 5 ;printf("5\n");break;
//	case : 6 ;printf("6\n");break;
//	case : 0 ;printf("7\n");break;
//	default printf("-1\n");
    if(t==1)
       printf("1\n");
       else if(t==2)
        printf("2\n");
        else if(t==3)
         printf("3\n");
         else if(t==4)
          printf("4\n");
          else if(t==5)
           printf("5\n");
           else if(t==6)
            printf("6\n");
            else if(t==0)
             printf("7\n");
	return 0;
}
