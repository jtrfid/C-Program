#include<stdio.h>
int main()
{
	int y,d;
	int sum;
	scanf("%d%d",&y,&d);
	if(y<=2100&&y>=1900&&y%4==0)
	{
		if(d>29||d<1)
		sum=-1;
		else
		sum=d%7;
	}
	else if(y<=2100&&y>=1900&&y%4!=0)
	{
		if(d>28||d<1)
		sum=-1;
		else
		sum=d%7;
	}
	else if(y>=2100||y<=1900)
	{
		sum=-1;
	}
	printf("%d",sum);
	return 0;
}
