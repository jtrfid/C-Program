#include<stdio.h>
int main()
{
	int n,i,j,t,k,c;
	scanf("%d",&n);
	int a[n][5],b[n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		scanf("%d",&a[i][j]);
		printf("\n");
	}
	for(i=0;i<n;i++)
	for(j=1;j<5;j++)
	for(t=j+1;t<5-j;t++)
	if(a[i][t]>a[i][t+1])
	{
		k=a[i][t];a[i][t]=a[i][t+1];a[i][t+1]=k;
	}
	for(i=0;i<n;i++)
		b[i]=(a[i][2]+a[i][3])/2;
		int max=0,d=-1;
		for(j=0;j<n-1;j++)
	{	
	c=0;	
	    if(b[j]=b[j+1])
			c++;
			else
			continue;
		if(c==0)
		{
			for(k=0;k<n;k++)
			{if(b[k]>max)
			{
			d++;
			max=b[k];
		    }
			else
			continue;
			}
			printf("%d",a[d][0]);
		}
		else
		{
		int e[c];
			for(k=0;k<n;k++)
			if(b[k]>max)
			{
			d++;
			max=b[k];
		    }
			int m,p=0;
			m=b[k];
			for(i=0;i<n;i++)
			if(a[i][0]=m)
			{
				e[p]=a[i][0];
				p++;
			}
			for(i=0;i<c;i++)
			printf("%d \n",e[i]);
		}
    }
    return 0;
}
