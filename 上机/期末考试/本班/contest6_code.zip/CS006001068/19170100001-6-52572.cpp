#include<stdio.h>
int main()
{
	int y,d,q;
	scanf("%d%d",&y,&d);
	if(y<1900||y>2100)
	{
		printf("%d",-1);
	}
		else
		{
			if(y/400==0||(y/4==0&&y/100!=0))
			{
				if(d>29||d<1)
				{
				printf("%d",-1);
				}
					else
					{
						q=d%7;
						if(q==1)
						{
							printf("%d",1);
						}
						else if(q==2)
						{
							printf("%d",2);
						}
						else if(q==3)
						{
							printf("%d",3);
						}
						else if(q==4)
						{
							printf("%d",4);
						}
						else if(q==5)
						{
							printf("%d",5);
						}
						else if(q==6)
						{
							printf("%d",6);
						}
						else 
						{
							printf("%d",0);
						}
					}
			}
					else 
					{
										if(d>28||d<1)
								{
								printf("%d",-1);
								}
								else 
								{
										q=d%7;
										if(q==1)
										{
											printf("%d",1);
										}
										else if(q==2)
										{
											printf("%d",2);
										}
										else if(q==3)
										{
											printf("%d",3);
										}
										else if(q==4)
										{
											printf("%d",4);
										}
										else if(q==5)
										{
											printf("%d",5);
										}
										else if(q==6)
										{
											printf("%d",6);
										}
										else 
										{
											printf("%d",0);
										}
								}
					}
		}
		return 0;
}

