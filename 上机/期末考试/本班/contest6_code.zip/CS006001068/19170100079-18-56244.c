#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j=0,m,t=0,min,r,o;
	int a[50],b[100];
	scanf("%d",&n);
	for(i=0;i<n-1;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		for(j=j+1;j<n;j++)
		{
			m=fabs(a[j]-a[i]);
			b[t]=m;t++;
		}
	}for(o=0;o<t;o++)
	{min=b[0];
		if(b[o]<min)
		{
			r=min;min=b[o];b[o]=r;
		}
	}printf("%d",min-1);return 0;
}

