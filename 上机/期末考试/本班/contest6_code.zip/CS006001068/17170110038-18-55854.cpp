#include <stdio.h>
#include <math.h>


int main()
{
    int arr[50],i,j,n,min;
    scanf("%d",&n);

    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }

    min=abs(arr[1]-arr[0]);
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(abs(arr[j]-arr[i])<min)
            {
                min=abs(arr[j]-arr[i]);
            }
        }
    }
    printf("%d",min);



    return 0;
}

