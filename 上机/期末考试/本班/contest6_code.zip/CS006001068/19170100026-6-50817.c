#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int y,d,x;
	scanf("%d %d",&y,&d);
	if(y<1990||y>2100)
	printf("-1");
	else
	{
		if((y%4==0&&y%100!=0)||(y%400==0))
		{
			if(d<1||d>29)
			printf("-1");
			else
			{
				if(d<=7)
				printf("%d",d);
				else
				printf("%d",d%7);
			}
		}
		else
		{
			if(d<1||d>28)
			printf("-1");
			else
			{
				if(d<=7)
				printf("%d",d);
				else
				printf("%d",d%7);
			}
		}
	}
	return 0;
}
