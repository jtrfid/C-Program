# include <stdio.h>
int main()
{
	int m,n,i,j;
	scanf("%d %d",&m,&n);
	if(m%4==0&&m%100!=0||m%400==0)
	{
		if(n>29||m>2100||m<1900) printf("-1");
		else
		{
			i=n%7;
			printf("%d",i);
		}
	}
	else
	{
		if(n>28||m>2100||m<1900) printf("-1");
		else
		{
			j=n%7;
			printf("%d",j);
		}
	}
	return 0;
}
