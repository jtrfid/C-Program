#include<stdio.h>
int main()
{
	int n,a[100],i,j,b[100],c=0,p,q,m;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			b[c]=a[j]-a[i];
			if(b[c]<0)
			b[c]=-b[c];
			c=c+1;
		}
	}
	for(p=0;p<c-1;p++)
	{
	    for(q=0;q<c-p-1;q++)
	    {
	    	if(b[q]>b[q+1])
	    	{
	    		m=b[q+1];
	    		b[q+1]=b[q];
	    		b[q]=m;
	    	}
	    }
	}
    printf("%d",b[0]);
	
}
