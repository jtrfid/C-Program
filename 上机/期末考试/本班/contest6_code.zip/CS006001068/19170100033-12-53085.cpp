#include<stdio.h>
int main()
{
	int m,k,a[200],i,b=0,c=0,d=0;
	scanf("%d %d",&m,&k);
	a[0]=2;
	a[1]=3;
	for(i=2;i<k;i++)
	{
		a[i]=i*i+3*(i-1)+1;
	}
	for(i=0;i<k;i++)
	{
		if(a[i]%m==0)
		 b=b+1;
		else if(a[i]%m==1)
		 c=c+1;
		else if(a[i]%m>1)
		 d=d+1;
	}
	printf("%d %d %d",b,c,d);
	return 0;
}
