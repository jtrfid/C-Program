#include<stdio.h>
int main()
{
	int n,j,i,b,c;
	scanf("%d",&n);
	int a[n][5];
	float f[n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		scanf("%d",&a[i][j]);
	}
	for(i=0;i<n;i++)
	{
		for(j=1;j<4;j++)
		{
			if(a[i][j]<a[i][j+1])
			{
				b=a[i][j];
				a[i][j]=a[i][j+1];
				a[i][j+1]=b;
		    }
		}
		for(j=1;j<3;j++)
		{
			if(a[i][j]>a[i][j+1])
			{
				b=a[i][j];
				a[i][j]=a[i][j+1];
				a[i][j+1]=b;
			}
		}
		f[i]=1.0*(a[i][1]+a[i][2])/2;
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(f[j]<f[j+1])
			{
				b=f[j];
				c=a[j][0];
				f[j]=f[j+1];
				a[j][0]=a[j+1][0];
				f[j+1]=b;
				a[j+1][0]=c;
			}
		}
	}
	c=f[0];
	for(i=0;i<n;i++)
	{
		if(f[i]==c)
		printf("%d\n",a[i][0]);
	}
	return 0;
}
