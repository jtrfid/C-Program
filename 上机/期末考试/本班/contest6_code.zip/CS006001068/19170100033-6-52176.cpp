#include<stdio.h>
int main()
{
	int y,d,t;
	scanf("%d %d",&y,&d);
	if(y<1900||y>2100||d<1||d>29)
	 printf("-1");
	else
	{
		if(y%4==0&&y%100!=0)
		{
			if(d<7)
			 printf("%d",d);
			else if(d=7||d%7==0)
			 printf("0");
			else if(d>7&&d<30)
			{
				t=d%7;
				printf("%d",t);
			}
		}
		else if(y%400==0)
		{
			if(d<7)
			 printf("%d",d);
			else if(d=7||d%7+1==0)
			 printf("0");
			else if(d>7&&d<30)
			{
				t=d%7+1;
				printf("%d",t);
			}
		}
		else
		{
			if(d>28)
			 printf("-1");
			else if(d<7)
			 printf("%d",d);
			else if(d=7||d%7==0)
			 printf("0");
			else if(d>7&&d<29)
			{
				t=d%7;
				printf("%d",t);
			}
		}
	}
	return 0;
}
