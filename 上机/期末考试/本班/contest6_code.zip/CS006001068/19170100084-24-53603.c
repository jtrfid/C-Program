#include<stdio.h>
int main()
{
	int n,m,con1=0;
	scanf("%d %d",&n,&m);
	int a[n][m],b[n][m],i,j;
	for(i=0;i<=n-1;i++)
	{
		for(j=0;j<=m-1;j++)
		{
			scanf("%d",&a[i][j]);
			b[i][j]=a[i][j];
		}
	}
	for(i=0;i<=n-1;i++)
	{
		for(j=0;j<=m-1;j++)
		{
			if(a[i][j]==0) con1++;
		}
		if(con1!=0)
		{
			for(j=0;j<=m-1;j++) a[i][j]=0;
		}
		con1=0;
	}
    for(i=0;i<=m-1;i++)
    {
    	for(j=0;j<=n-1;j++)
    	{
    		if(b[j][i]==0) con1++;
    	}
    	if(con1!=0)
    	{
    		for(j=0;j<=n-1;j++) b[j][i]=0;
    	}
    	con1=0;
    }
    for(i=0;i<=n-1;i++)
    {
    	for(j=0;j<=m-1;j++)
    	{
    		if(a[i][j]==0||b[i][j]==0) printf("0 ");
    		else printf("%d ",a[i][j]);
    	}
    	printf("\n");
    }
    return 0;
}













