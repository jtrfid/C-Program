#include<stdio.h>
int main()
{
	int n,p,i,m;
	int b[100]={0};
	scanf("%d %d",&p,&n);
	for(i=1;i<=n;i++)
	{
		if(i==1)
		{
			m=2;b[i]=m;
		}else if(i==2)
		{
			m=3;b[i]=m;
		}else m=(i-1)*(i-1)+3*(i-2)+1;b[i]=m;
	}
	for(i=0;i<n;i++)
	{
		if(b[i]%p==0)
		{
			printf("%d ",i+1);
		}else if(b[i]%p==1)
		{
			printf("%d ",i+1);
		}else if(b[i]%p>1)
		{
			printf("%d ",i+1);
		}
	}	
	return 0;
}
