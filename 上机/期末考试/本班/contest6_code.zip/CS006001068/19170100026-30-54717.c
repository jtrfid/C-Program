#include<stdio.h>
#include<string.h>
#include<math.h>
struct Person
{
	int num;
	int s1;
	int s2;
	int s3;
	int s4;
	int s5;
};
int max(int x,int y)
{
	if(x>y)
	return x;
	else
	return y;
}
int min(int x,int y)
{
	if(x<y)
	return x;
	else
	return y;
}
int main()
{
	int n,i,j,k,t,x,m1,m2;
	scanf("%d",&n);
	struct Person a[n],temp;
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d %d %d",&a[i].num,&a[i].s1,&a[i].s2,&a[i].s3,&a[i].s3);
	}
	for(i=0;i<n;i++)
	{
		m1=max(a[i].s1,max(a[i].s2,max(a[i].s3,a[i].s4)));
		m2=min(a[i].s1,min(a[i].s2,min(a[i].s3,a[i].s4)));
		a[i].s5=a[i].s1+a[i].s2+a[i].s3+a[i].s4-m1-m2;
	}
	for(i=0;i<n-1;i++)
	for(j=0;j<n-i-1;j++)
	if(a[j].s5<a[j+1].s5)
	{
		t=a[j].s5;
		a[j].s5=a[j+1].s5;
		a[j+1].s5=t;
	}
	printf("%d\n",a[0].num);
	for(i=1;i<n;i++)
	if(a[i].s5==a[0].s5)
	printf("%d",a[i].num);
	return 0;
}
