#include<stdio.h>
int main()
{int n;
scanf("%d",&n);
typedef struct asda
{ int name;
   int goal;
}pe;
pe a[n];

int i;
int b[4];
int j;
int t;
int temp;
for(i=0;i<n;i++)
 { scanf("%d",&a[i].name);
   
  for(j=0;j<4;j++)
     {scanf("%d",&b[j]);
     }
     
     for(t=0;t<4;t++)
      for( j=t+1;j<4;j++)
       { if(b[t]>b[j])
	          { temp=b[t];
               b[t]=b[j];
                b[j]=temp;
                          }
       }
       
       a[i].goal=b[1]+b[2];
     
 }


int max=a[0].goal;
for(i=1;i<n;i++)
{  if(a[i].goal>max) max=a[i].goal;
}	

for(i=0;i<n;i++)
{  if(a[i].goal==max) printf("%d\n",a[i].name);
}	


	return 0;
}

