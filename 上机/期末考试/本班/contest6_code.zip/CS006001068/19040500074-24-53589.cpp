#include<stdio.h>

int main()
{
	int n, m, i, j, s, k, l;
	scanf("%d %d", &m, &n);
	int a[m][n], b[m][n];
	for(i = 0; i < m; i++)
	    for(j = 0; j < n; j++)
	    {
	        scanf("%d", &a[i][j]);
	        b[i][j] = a[i][j];
	        if(b[i][j] == 0)
	        {
	        	b[i][j] = 123456;
	        }
	    }
	for(i = 0; i < m; i++)
	for(j = 0; j < n; j++)
	{
		if(b[i][j] == 123456)
		{
			for(k = 0; k < 50; k++)
			{
				a[i][k] = 0;
				a[k][j] = 0;
			}
		}
	}
	for(i = 0; i < m; i++)
	{
	    for(j = 0; j < n; j++)
	    {
	    	printf("%d ", a[i][j]);
	    }
	    printf("\n");
    }
	return 0;
}
