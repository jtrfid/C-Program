# include <stdio.h>
int main()
{
	int m,n,i,j,h,x,c,d;
	scanf("%d %d",&m,&n);
	int a[m][n];
	for(i=0;i<m;i++)
	 for(j=0;j<n;j++)
	  scanf("%d",&a[i][j]);
	for(i=0;i<m;i++)
	 {
	 	for(j=0;j<n;j++)
	 	if(a[i][j]==0)
	 	{
	 		c=i;
	 		d=j;
	 		for(h=0;h<n;h++)
	 		 a[c][h]=0;
	 		for(x=0;x<m;x++)
	 		 a[d][j]=0;
	 	}
	 }
	 for(h=0;h<m;h++)
	  {
	  	for(x=0;x<n;x++)
	  	 printf("%d ",a[h][x]);
	  	printf("\n");
	  }
	return 0;
}
