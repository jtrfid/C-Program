#include<stdio.h>
int main()
{
	int n,i,j,t,k=0,l;
	scanf("%d",&n);
    int a[n][5],b[n],c[n];
    for(i=0;i<n;i++)
    for(j=0;j<5;j++)
    scanf("%d",&a[i][j]);
    for(i=0;i<n;i++) b[i]=(a[i][1]+a[i][2]+a[i][3]+a[i][4])/4;
    t=b[0];
	for(i=1;i<n;i++)
	if(b[0]<b[i])t=b[i];
	for(i=0;i<n;i++)
	if(b[i]==t){c[k]=a[i][0];k++;};
	for(i=0;i<k;i++)
	for(j=0;j<k;j++)
	if(c[k]>c[k+1]){t=c[k];c[k+1]=c[k];c[k+1]=t;
	};
	for(i=0;i<k;i++)printf("%d\n",c[k]);
	return 0;
	
}
