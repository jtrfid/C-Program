#include<stdio.h>
struct student
{
	int number;
	int grade[4];
};
int main()
{
	int n,i,j,max,min,sum=0,n0,max0,con1=0;
	scanf("%d",&n);
	struct student a[n],a0;
	int b[n];
	for(i=0;i<=n-1;i++)
	{
	   scanf("%d %d %d %d %d",&a[i].number,&a[i].grade[0],&a[i].grade[1],&a[i].grade[2],&a[i].grade[3]);
    }
   
    for(i=0;i<=n-1;i++)
    {
    	 max=a[i].grade[0],min=max;
    	for(j=0;j<=3;j++)
    	{
        
    	sum=sum+a[i].grade[j];	
    	if(a[i].grade[j]>max) max=a[i].grade[j];
    	if(a[i].grade[j]<min) min=a[i].grade[j];
    	}
    	b[i]=sum-min-max;
    	sum=0;
    }
    for(i=1;i<=n-1;i++)
    {
    	for(j=0;j<=n-1-i;j++)
    	{
    		if(b[j]<b[j+1]) n0=b[j],b[j]=b[j+1],b[j+1]=n0,a0=a[j],a[j]=a[j+1],a[j+1]=a0;
    	
    	}
    }
        for(i=1;i<=n-1;i++)
    	for(j=0;j<=n-1-i;j++)
    	{
    		if(b[j]==b[j+1]&&a[j].number>a[j+1].number)
    	n0=b[j],b[j]=b[j+1],b[j+1]=n0,a0=a[j],a[j]=a[j+1],a[j+1]=a0;
    	}
    max0=b[0];
    for(i=0;i<=n-1;i++) if(b[i]==max0) con1++;
    for(i=0;i<=con1-1;i++) printf("%d\n",a[i].number);
    return 0;
}
