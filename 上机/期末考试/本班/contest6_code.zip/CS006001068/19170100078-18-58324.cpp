# include <stdio.h>
int main()
{
	int n,m,i,j,h=0,d,x,p,t;
	scanf("%d",&n);
	int a[n],e[n*(n-1)/2];
	for(i=0;i<n;i++)
	 scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	 for(j=i+1;j<n;j++)
	 {
	    if(a[i]>a[j]) {d=a[i];x=a[j];}
	    else {d=a[j];x=a[i];}
	 	e[h]=d-x;
	 	h=h+1;
	 }
    p=n*(n-1)/2;
    for(i=0;i<p-1;i++)
     for(j=0;j<p-1-i;j++)
      if(e[j]>e[j+1])
      {t=e[j];e[j]=e[j+1];e[j+1]=t;}
	printf("%d",e[0]);
	return 0;
}
