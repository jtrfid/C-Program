#include <stdio.h>
int main()
{
	int m,k,n,a,x,y,z,t;
	x=0;
	y=0;
	z=0;
	scanf("%d %d\n",&m,&k);
	 if(n>2)
	a=(n-1)*(n-1)+3*(n-2)+1;
	  else if(n=1)
	  a=2;
	  else if(n=2)
	  a=3;
	  int i;
	  i=n;
	for(i=1;i<=k;i++)
	t=a%m;
	while(t==0)
	x++;
	printf("%d\t",x);
	while(t==1)
	y++;
	printf("%d\t",y);
	while(t>1)
	z++;
	printf("%d\n",z);
	return 0;
	
	
	
	
	
}
