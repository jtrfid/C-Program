#include<stdio.h>
int main()
{
	int n,i,j,k,q,max,min,t;
	scanf("%d",&n);
	int a[n][5],sum[n],b[4];
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		{
			scanf("%d",&a[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<n;i++)
	{
		for(j=1;j<5;j++)
		{
			b[j-1]=a[i][j];
		}
		for(k=0;k<3;k++)
		{
		  for(q=0;q<3-k;q++)
		  {
			if(b[q]>b[q+1])
			{
			  t=b[q];
			  b[q]=b[q+1];
			  b[q+1]=t;
			}
		  }
		}
		sum[i]=b[1]+b[2];
	}
	max=0;min=0;
	for(i=0;i<n;i++)
	{
		if(sum[i]>sum[0])
		{
			max=i;
			sum[0]=sum[i];
		}
		if(sum[i]<sum[0])
		{
			min=i;
			sum[0]=sum[i];
		}
	}
	printf("%d %d",a[max][0],a[min][0]);
	return 0;
	
}
