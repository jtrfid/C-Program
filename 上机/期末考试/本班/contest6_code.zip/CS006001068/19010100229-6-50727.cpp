#include<stdio.h>
int main()
{
	int y,d;
	int sum;
	scanf("%d%d",&y,&d);
	if(y%4==0)
	{
		if(d>29)
		sum=-1;
		else
		sum=d%7;
	}
	else
	{
		if(d>28)
		sum=-1;
		else
		sum=d%7;
	}
	printf("%d",sum);
	return 0;
}
