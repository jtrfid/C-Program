#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{int n,m,i,j;
 scanf("%d %d",&n,&m);
 int a[n][m],b[n][m],c[n][m];
 for(i=0;i<n;i++)
 for(j=0;j<m;j++) scanf("%d",&a[i][j]);
 for(i=0;i<n;i++)
 for(j=0;j<m;j++) b[i][j]=c[i][j]=a[i][j];
 for(i=0;i<n;i++)
 for(j=0;j<m;j++)
 {if(b[i][j]==0) 
 { for(j=0;j<m;j++) b[i][j]=0;
   break;
 }
 }
 for(j=0;j<m;j++)
  for(i=0;i<n;i++)
  {if(c[i][j]==0)
  {for(i=0;i<n;i++)c[i][j]=0;
   break;
  }
  }
 for(i=0;i<n;i++)
 for(j=0;j<m;j++)
 {if(b[i][j]==c[i][j]) a[i][j]=b[i][j];
  if(b[i][j]!=c[i][j]&&(b[i][j]==0||c[i][j]==0)) a[i][j]=0;
 } 
 for(i=0;i<n;i++)
 {for(j=0;j<m;j++) printf("%d ",a[i][j]);
  printf("\n");
 }
 return 0;
}
