#include<stdio.h>
#include<string.h>
int main()
{int n,m,i,j,p,q;
 scanf("%d %d",&n,&m);
 int a[n][m],b[n][m];
 for(i=0;i<n;i++)
 for(j=0;j<m;j++)
 {scanf("%d",&a[i][j]);
 b[i][j]=a[i][j];
}
 for(i=0;i<n;i++)
 for(j=0;j<m;j++)
 if(a[i][j]==0)  
 {for(q=0;q<n;q++)
  b[q][j]=0;
  for(p=0;p<m;p++)
  b[i][p]=0;
 }
  for(i=0;i<n;i++)
 {for(j=0;j<m;j++)
 printf("%d ",b[i][j]);
 printf("\n");}
}

