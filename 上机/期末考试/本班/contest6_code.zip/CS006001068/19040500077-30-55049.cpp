#include<stdio.h>
int main()
{int n;
scanf("%d",&n);
typedef struct asda
{ int name;
   int goal;
}pe;
pe a[n];
int i;
int j;
int temp;
int b[4];
for(i=0;i<n;i++)
 {scanf("%d",&a[i].name);
   for( j=0;j<4;j++)
     { scanf("%d",&b[i]);
     }
     
     for(i=0;i<4;i++)
for(j=i+1;j<4;j++)
 { if(b[i]>b[j])
    { temp=b[i];
     b[i]=b[j];
     b[j]=temp;
    }
 }	
 
 a[i].goal=b[1]+b[2];
 }

int max=a[0].goal;
for(i=0;i<n;i++)
{ if(a[i].goal>max) max=a[i].goal;
}

for(i=0;i<n;i++)
{ if(a[i].goal==max) printf("%d\n",a[i].name);
}

	
	return 0;
}


