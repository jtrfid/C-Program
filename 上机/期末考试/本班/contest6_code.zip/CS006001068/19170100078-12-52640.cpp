# include <stdio.h>
int main()
{
	int m,k,i,j,n,d=0,h=0,x=0;
	scanf("%d %d",&m,&k);
	int a[k];
	a[0]=2;
	a[1]=3;
	for(i=3;i<=k;i++)
	 a[i-1]=(i-1)*(i-1)+3*(i-2)+1;
	for(i=0;i<k;i++)
	 {
	 	if(a[i]%m==0)
	 	d=d+1;
	 }
	for(j=0;j<k;j++)
	 {
	 	if(a[j]%m==1)
	 	h=h+1;
	 }
	for(n=0;n<k;n++)
	 {
	 	if(a[n]%m>1)
	 	x=x+1;
	 }
	 printf("%d %d %d",d,h,x);
	 return 0;
}
