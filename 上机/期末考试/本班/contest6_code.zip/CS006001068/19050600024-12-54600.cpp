#include<stdio.h>
int main()
{
	int m,k,i,j,o,p;
	scanf("%d %d",&m,&k);
	int a[k-1];
	if(k==1)
	a[0]=2;
	else if(k==2)
	{
	a[1]=3;a[0]=2;
    }
	else if(k>2)
	{
		a[1]=3;a[0]=2;
		for(i=2;i<k;i++)
		a[i]=(i-2)*(i-2)+3*(i-3)+1;
    }
	for(i=0,j=0;i<k;i++)
	{
	if(a[i]%m==0)
	j=j+1;
    }
	for(i=0,o=0;i<k;i++)
	{
		if(a[i]%m==1)
		o=o+1;
	}
	for(i=0,p=0;i<k;i++)
	  {
	  	if(a[i]%m>1)
	  	p=p+1;
	  }
	  printf("%d %d %d",j,o,p);
	  return 0;
}
