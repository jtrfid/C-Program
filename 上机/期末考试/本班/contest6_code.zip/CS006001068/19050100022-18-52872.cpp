#include<stdio.h>
int main()
{
	int n,i,j,k,t;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++) scanf("%d",&a[i]);
	for(k=0;k<n;k++)
	{
	    for(i=0;i<n-1;i++)
		{
		    if(a[i+1]>a[i])
			{
			    t=a[i+1];
				a[i+1]=a[i];
				a[i]=t;
			}
		}
	}
	k=a[0]-a[1]; 
	for(i=1;i<n-1;i++)
	{
	    if(a[i]-a[i+1]<k) k=a[i]-a[i+1];
	} 
	printf("%d",k); 
	return 0; 
}
