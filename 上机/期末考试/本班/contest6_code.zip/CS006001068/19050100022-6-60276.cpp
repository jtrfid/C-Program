#include<stdio.h>
int main()
{
	int y,d,date,k,i;
	scanf("%d %d",&y,&d);
	if(y%4!=0&&d==29) printf("-1");
	if(y%4==0&&y%400!=0&&d==29) printf("-1");
	else
	{
		if(y>2000)
		{
			k=y-2000+d;
			for(i=2000;i<=y;i++)
			{
				if(i%4==0&&y%100!=0) k=k+1;
	            if(i%400==0) k=k+1;
			}
			
		}
	    if(y<2000)
		{
			k=2000-y+d;
			for(i=y;i<2000;i++)
			{
				if(i%4==0&&y%100!=0) k=k+1;
	            if(i%400==0) k=k+1;
			}
		}
		if(y=2000)
		{
			k=d-0;
		}
	}
	date=k%7;
	printf("%d",date);
	return 0;
}
