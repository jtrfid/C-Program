#include<stdio.h>
int main()
{
	int m,n,a,z;
	scanf("%d %d",&m,&n);
	if(m%4==0&&m%100!=0)z=1;
	else if(m%400==0)z=0;
	else z=0;
	if(z==1)
	{
		if(n>29)printf("-1");
		else
		{
			a=n%7;
			printf("%d",a);
		}
	}
	if(z==0)
	{
		if(n>28)printf("-1");
		else
		{
			a=n%7;
			printf("%d",a);
		}
	}
	return 0;
	
}
