#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{int x,n,m,leap;
 scanf("%d %d",&n,&m);
 if(n>2100||n<1900) printf("-1");
 else
 {
  if(n%4==0)
 {if(n%100==0)
  {if(n%400==0) leap=1;
   else leap=0;
  }
  else leap=1;
 }
 else leap=0;
 if(leap==1)
 {if(m>29) printf("-1");
  if(m<=29)
  {x=m%7;
   printf("%d",x);
  }
 }
 if(leap==0)
 {if(m>28) printf("-1");
  if(m<=28)
  {x=m%7;
   printf("%d",x);
  }
 }
}
 return 0;
}
