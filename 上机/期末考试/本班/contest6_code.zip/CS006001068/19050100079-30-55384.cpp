#include<stdio.h>
int main()
{
	int i,j,k,max=0,num1,num2=0,t,n;
	scanf("%d",&n);
	int a[n][5];
	for(i=0;i<n;i++){
		for(j=0;j<5;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<5;j++){
			for(k=j;k<5;k++){
				if(a[i][j]>a[i][k]){
					t=a[i][k];
					a[i][k]=a[i][j];
					a[i][j]=t;
				}
			}
		}
		if((a[i][1]+a[i][2])>max){
			max=a[i][1]+a[i][2];
			num1=a[i][4];
		}
	}
	for(i=0;i<n;i++){
		if((a[i][2]+a[i][1])==max){
			if(a[i][4]!=num1){
				if(a[i][4]<num1){
					a[i][4]=num1;
					num1=num2;
				} else {
					num2=a[i][4];
				}
			}
		}
	}
	if(num2==0){
		printf("%d\n",num1);
	} else {
		printf("%d\n%d\n",num1,num2);
	}
	return 0;
}
