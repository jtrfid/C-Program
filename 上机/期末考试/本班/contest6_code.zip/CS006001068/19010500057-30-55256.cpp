#include<stdio.h>
int main()
{
	int n,i,j,k,max,min,t;
	scanf("%d",&n);
	int a[n][5],sum[n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		{
			scanf("%d",&a[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<n;i++)
	{
		for(j=1;j<4;j++)
		{
			for(k=1;k<4-j;k++)
			{
				if(a[j][k]>a[j][k+1])
				{
					t=a[j][k];
					a[j][k]=a[j][k+1];
					a[j][k+1]=t;
					
				}
				
			}
		}
		sum[i]=a[i][2]+a[i][3];
	}
	max=0;min=0;
	for(i=0;i<n;i++)
	{
		if(sum[i]>sum[0])
		{
			max=i;
			sum[0]=sum[i];
		}
		if(sum[i]<sum[0])
		{
			min=i;
			sum[0]=sum[i];
		}
	}
	printf("%d %d",a[max][0],a[min][0]);
	return 0;
	
}
