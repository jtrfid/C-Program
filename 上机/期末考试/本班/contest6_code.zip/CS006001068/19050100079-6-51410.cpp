#include<stdio.h>
int main()
{
	int i,y,d,date,a[29]={1,2,3,4,5,6,7,1,2,3,4,5,6,7,1,2,3,4,5,6,7,1,2,3,4,5,6,7,-1};
	scanf("%d %d",&y,&d);
	if(y<1900||y>2100){
		date=-1;
	} else if(y>=1900&&y<=2100){
		if((y%4==0&&y%100!=0)||(y%400==0)){
			if(d>29||d<1){
				date=-1;
			} else {
				a[28]=1;
				date=a[d-1];
			}
		} else {
			if(d>28||d<1){
				date=-1;
			} else {
				date=a[d-1];
			}
		}
	}
	printf("%d\n",date);
	return 0;
}
