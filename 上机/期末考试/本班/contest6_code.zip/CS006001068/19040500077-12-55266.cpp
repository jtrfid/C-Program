#include<stdio.h>
int main()
{int m,k;
scanf("%d %d",&m,&k);
int a[k+1];
a[1]=2;a[2]=3;

int i;
for(i=3;i<=k;i++)
 { a[i]=(i-1)*(i-1)+3*(i-2)+1;
 }

int t0=0,t1=0,t=0;
for(i=1;i<=k;i++)
{if(a[i]%m==0) t0++;
}
for(i=1;i<=k;i++)
{if(a[i]%m==1) t1++;
}
for(i=1;i<=k;i++)
{if(a[i]%m>1) t++;
}

printf("%d %d %d",t0,t1,t);
	
	return 0;
}


