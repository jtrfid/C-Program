#include<stdio.h>
int main()
{ 
	int y;int d;int a;int b;
	scanf("%d %d",&y,&d);
	if(y<1900||y>2100)
	b=0;
	else
	b=1;
	if(b==0){
	printf("-1");}
	if(y%4==0&&y%100!=0||y%400==0&&b==1)
	{a=1;}
	if(a==1)
	{
	if(d<1||d>29)
	{printf("-1");}
	else{
	switch(d){
	case 1:printf("1");break;
	case 2:printf("2");break;
	case 3:printf("3");break;
	case 4:printf("4");break;
	case 5:printf("5");break;
	case 6:printf("6");break;
	case 7:printf("0");break;
	case 8:printf("1");break;
	case 9:printf("2");break;
	case 10:printf("3");break;
	case 11:printf("4");break;
	case 12:printf("5");break;
	case 13:printf("6");break;
	case 14:printf("0");break;
	case 15:printf("1");break;
	case 16:printf("2");break;
	case 17:printf("3");break;
	case 18:printf("4");break;
	case 19:printf("5");break;
	case 20:printf("6");break;
	case 21:printf("0");break;
	case 22:printf("1");break;
	case 23:printf("2");break;
	case 24:printf("3");break;
	case 25:printf("4");break;
	case 26:printf("5");break;
	case 27:printf("6");break;
	case 28:printf("0");break;
	case 29:printf("1");break;
}
	}

	
	
	}
	else if(a!=1)
	{if(d<1||d>28)
	printf("-1");
	else
	{switch(d)
	{case 1:printf("1");break;
	case 2:printf("2");break;
	case 3:printf("3");break;
	case 4:printf("4");break;
	case 5:printf("5");break;
	case 6:printf("6");break;
	case 7:printf("0");break;
	case 8:printf("1");break;
	case 9:printf("2");break;
	case 10:printf("3");break;
	case 11:printf("4");break;
	case 12:printf("5");break;
	case 13:printf("6");break;
	case 14:printf("0");break;
	case 15:printf("1");break;
	case 16:printf("2");break;
	case 17:printf("3");break;
	case 18:printf("4");break;
	case 19:printf("5");break;
	case 20:printf("6");break;
	case 21:printf("0");break;
	case 22:printf("1");break;
	case 23:printf("2");break;
	case 24:printf("3");break;
	case 25:printf("4");break;
	case 26:printf("5");break;
	case 27:printf("6");break;
	case 28:printf("0");break;
	
	}
	}
	}
	


}
