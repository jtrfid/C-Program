#include<stdio.h>
int main()
{
	int i,j,m,n,x,z,q,w;
	scanf("%d %d",&m,&n);
	int a[m][n];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==0)
			{
				q=i;w=j;
				for(z=0;z<m;z++)
				{
					a[z][w]=0;
				}
				for(x=0;x<n;x++)
				{
					a[q][x]=0;
				}
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
	
}
