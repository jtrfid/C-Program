#include<stdio.h>
int main()
{
	int y,d;
	scanf("%d %d",&y,&d);
	if(y>=1900&&y<=2100)
	{
	if((y%4==0&&y%100!=0)||y%400==0)
	{
		if(d>=1&&d<=29)
		{
	
			printf("%d\n",d%7);
		}
		else printf("-1\n");
	}
	else
	{
		if(d>=1&&d<=28)
		{
			
			printf("%d\n",d%7);
		}
		else printf("-1\n");
	}
    }
    else printf("-1\n");
    return 0;
}
