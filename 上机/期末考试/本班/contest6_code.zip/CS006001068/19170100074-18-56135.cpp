#include<stdio.h>
#include<math.h>
int main()
{int n;
scanf("%d",&n);
int min=999999999;
int i,j,t;
int a[n];
for(i=0;i<n;i++)
{scanf("%d ",&a[i]);}
	for(j=0;j<n;j++)
	{for(t=0;t<n;t++)
	if(abs(a[j]-a[t])<min)
	min=abs(a[j]-a[t]);
	}
	printf("%d",min);
	return 0;
}
