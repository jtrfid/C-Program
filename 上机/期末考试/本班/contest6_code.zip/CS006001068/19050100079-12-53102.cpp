#include<stdio.h>
int main()
{
	int i=1,m,n,k,t,x=0,y=0,z=0;
	scanf("%d %d",&m,&k);
	if(i==1){
		t=2%m;
		i++;
		if(t==0){
			x++;
		} else if(t==1){
			y++;
		} else if(t>1){
			z++;
		}
	}
	if(i==2){
		t=3%m;
		i++;
		if(t==0){
			x++;
		} else if(t==1){
			y++;
		} else if(t>1){
			z++;
		}
	}
	for(;i<=k;i++){
		n=(i-1)*(i-1)+3*(i-2)+1;
		t=n%m;
		if(t==0){
			x++;
		} else if(t==1){
			y++;
		} else if(t>1){
			z++;
		}
	}
	printf("%d %d %d\n",x,y,z);
	return 0;
}
