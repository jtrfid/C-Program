#include<stdio.h>
int main ()
{
int a[100],b,c,d,e,f,g,h,i,j,k,l,m,n;
scanf("%d",&b);
scanf("%d",&a[i]);
for(i=0;i<50;i++)
a[i]=a[i]-a[i+1];
if(a[i]<a[i+1])
a[i+1]=a[i];
printf("%d",a[i]);
return 0;
}
