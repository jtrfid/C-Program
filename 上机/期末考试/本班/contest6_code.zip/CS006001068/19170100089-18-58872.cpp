#include<stdio.h>
int main ()
{
int a,b,c,d,e,f,g,h,i,j,k,l,m,n;
scanf("%d",&b);
scanf("%d %d %d %d",&a,&c,&d,&e);
f=a-c;
g=c-d;
h=d-e;
i=e-a;
if(f<g&&f<h&&f<i)
{
if(f>=0)
{
printf("%d",f);
}
}
if(g<f&&g<h&&g<i)
{
printf("%d",g);
}
if(h<g&&h<f&&h<i)
{
printf("%d",h);
}
if(i<g&&i<h&&i<f)
{
printf("%d",i);
}
return 0;
}
