#include<stdio.h>
int main()
{
	int m,k,i,j=0,t=0,x=0;
	scanf("%d %d",&m,&k);
	int a[k];
	a[0]=2;
	a[1]=3; 
	for(i=2;i<k;i++) a[i]=(i+1)*(i+2)-4;
	for(i=0;i<k;i++)
	{
		if(a[i]%m==0) j=j+1; 
		if(a[i]%m==1) t=t+1; 
		if(a[i]%m>1) x=x+1; 
	}
	printf("%d %d %d",j,t,x); 
	return 0; 
}
