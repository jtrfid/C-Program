#include<stdio.h>
int main()
{
	int m,n,i,k,j;
	scanf("%d %d",&m,&n); 
	int a[m][n],b[m][n];
	for(i=0;i<m;i++)
	{
	    for(k=0;k<n;k++)
		{
		    scanf("%d",&a[i][k]);
		    b[i][k]=a[i][k];
		}
	}
	for(i=0;i<m;i++)
	{
	    for(k=0;k<n;k++)
		{
		    b[i][k]=a[i][k];
		}
	}
	for(i=0;i<m;i++)
	{
	    for(k=0;k<n;k++)
		{
		    if(a[i][k]==0)
			{
				for(j=0;j<m;j++)
				{
					b[j][k]=0; 
				} 
			}
		}
	}
	for(i=0;i<m;i++)
	{
	    for(k=0;k<n;k++)
		{
		    if(a[i][k]==0)
			{
				for(j=0;j<n;j++)
				{
					b[i][j]=0; 
				} 
			}
		}
	}
	for(i=0;i<m;i++)
	{
	    for(k=0;k<n;k++)
		{
		    printf("%d ",b[i][k]);
		}
		printf("\n"); 
	}
	return 0; 
}
