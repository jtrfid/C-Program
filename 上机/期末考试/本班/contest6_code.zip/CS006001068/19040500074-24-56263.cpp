#include<stdio.h>

int main()
{
	int n, m, i, j, s, k, l;
	scanf("%d %d", &m, &n);
	int a[m][n], b[m][n];
	for(i = 0; i < m; i++)
	    for(j = 0; j < n; j++)
	    {
	        scanf("%d", &a[i][j]);
	        b[i][j] = a[i][j];
	    }
	for(i = 0; i < m; i++)
	for(j = 0; j < n; j++)
	{
		if(b[i][j] == 0)
		{
			for(k = 0; k < n; k++)
				a[i][k] = 0;
			for(k = 0; k < m; k++)
				a[k][j] = 0;
		}
	}
	for(i = 0; i < m; i++)
	{
	    for(j = 0; j < n; j++)
	    {
	    	printf("%d ", a[i][j]);
	    }
	    printf("\n");
    }
	return 0;
}
