#include<stdio.h>
int main()
{
	int y,d,a;
	scanf("%d %d",&y,&d);
	if(y>2100||y<1900)
	{a=-1;
	printf("%d",a);
	}
    else if((y%4==0&&y%100!=0)||y%400==0)
	{
		if(d<1||d>29)
		printf("%d",-1);
		else
		{
			a=d%7;
			printf("%d",a);
		}
	}
	else
	{
		if(d<1||d>28)
		printf("%d",-1);
		else
		{
		a=d%7;
		printf("%d",a);
	    }
	}
	return 0;
}
