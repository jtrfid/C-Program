#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{ struct stu
  {int num;
   int x;
   int y;
   int z;
   int s;
   int sum;
  };
  int n,i,j,k,max,min;
  
  scanf("%d",&n);
  int b[n],c[n];
  struct stu a[20];
  struct stu temp;
  for(i=0;i<n;i++) 
  {scanf("%d %d %d %d %d",&a[i].num,&a[i].x,&a[i].y,&a[i].z,&a[i].s);
    min=max=a[i].x;
    if(a[i].y>max) max=a[i].y; else max=max;
    if(a[i].z>max) max=a[i].z; else max=max;
    if(a[i].s>max) max=a[i].s; else max=max;
    if(a[i].y<min) min=a[i].y; else min=min;
    if(a[i].z<min) min=a[i].z; else min=min;
    if(a[i].s<min) min=a[i].s; else min=min;
    a[i].sum=a[i].x+a[i].y+a[i].z+a[i].s-max-min;
  }
  
  for(i=0;i<n;i++)
  {b[i]=a[i].num;c[i]=a[i].sum;}
  for(i=0;i<n-1;i++)
  {
   for(j=0;j<n-1-i;j++)
   {if(a[j].sum<a[j+1].sum)
    {temp=a[j];a[j]=a[j+1];a[j+1]=temp;
    }
   }
  }
  k=a[0].sum;
  for(i=0;i<n;i++)
  {if(c[i]==k) printf("%d\n",b[i]);
  }

 return 0;
}
