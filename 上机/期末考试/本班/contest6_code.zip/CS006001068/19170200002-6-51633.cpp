#include<stdio.h>
int main() 
{ int y,d,a;
  scanf("%d %d",&y,&d);
  if(y>2100||y<1900||d<1||d>28)
  a=-1;
  else if(d==29||(a%4==0&&a%100!=0||a%400==0))a=1;
  else a=d%7;
  printf("%d",a);
  return 0;
}
