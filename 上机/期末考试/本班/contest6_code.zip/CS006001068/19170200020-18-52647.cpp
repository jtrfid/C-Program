#include<stdio.h>
int main()
{int n,i,j,t=0;
 scanf("%d",&n);
 int a[n],b[n-1];
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 for(i=0;i<n-1;i++)
 if(a[i]<a[i+1])   b[i]=a[i+1]-a[i];
 else   b[i]=a[i]-a[i+1]; 
  for(i=1;i<n-1;i++)
  if(b[t]>b[i])  t=i;
  printf("%d",b[t]);
}

