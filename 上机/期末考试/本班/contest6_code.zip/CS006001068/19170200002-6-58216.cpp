#include<stdio.h>
int main() 
{ int y,d,a;
  scanf("%d %d",&y,&d);
  if(y>2100||y<1900||d<1||d>29)
       a=-1;
  else if(d==29)
  {if(y<=2100&&y>=1900&&y%4==0&&y%100!=0||y%400==0)a=1;
  else a=-1;
  } 
  else a=d%7;
  printf("%d",a);
  return 0;
}
