#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{ struct stu
  {int num;
   int x;
   int y;
   int z;
   int s;
   int sum;
  };
  int n,i,j,k;
  scanf("%d",&n);
  struct stu a[n];
  struct stu temp;
  for(i=0;i<n;i++) 
  {scanf("%d %d %d %d %d",&a[i].num,&a[i].x,&a[i].y,&a[i].z,&a[i].s);
   a[i].sum=a[i].x+a[i].y+a[i].z+a[i].s; 
  }
  for(i=0;i<n;i++)
  {k=i;
   for(j=i+1;j<n;j++)
   {if(a[j].sum>a[k].sum)
    {k=j;
     temp=a[i];a[i]=a[k];a[k]=temp;
    }
   }
  }
  for(j=0;j<n-1;j++)
  for(i=0;i<n-1-j;i++)
  if(a[i].sum==a[i+1].sum&&a[i].num>a[i+1].num) {temp=a[i];a[i]=a[i+1];a[i+1]=temp;}
  printf("%d\n",a[0].num);
  
  for(i=1;i<n;i++)
  if(a[i].sum==a[0].sum) printf("%d\n",a[i].num);
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 return 0;
}
