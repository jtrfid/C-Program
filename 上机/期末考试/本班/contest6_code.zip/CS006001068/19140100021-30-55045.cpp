#include<stdio.h>
int main()
{
	int n,i,j,t,k;
	scanf("%d",&n);
	int a[n][5],b[n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		scanf("%d",&a[i][j]);
		printf("\n");
	}
	for(i=0;i<n;i++)
	for(j=1;j<5;j++)
	for(t=j+1;t<5-j;t++)
	if(a[i][t]>a[i][t+1])
	{
		k=a[i][t];a[i][t]=a[i][t+1];a[i][t+1]=k;
	}
	for(i=0;i<n;i++)
		b[i]=(a[i][2]+a[i][3])/2;
		int max=0,c=-1;
		for(j=0;j<n;j++)
		{
			if(b[j]>max)
			c++;
			else
			continue;
		}
		printf("%d",a[c][0]);
		return 0;
}
