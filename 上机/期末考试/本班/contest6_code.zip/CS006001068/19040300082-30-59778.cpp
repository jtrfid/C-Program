#include<stdio.h>
int main()
{
	struct fenshu
	{
		int bianhao;
		int a1;
		int a2;
		int a3;
		int a4;
	};
	int n,i,m,p;
	scanf("%d",&n);
	fenshu fen[100],t;
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d%d%d",&fen[i]);
	}
	for(i=0;i<n;i++)
	{
		if(fen[i].a1<fen[i].a2)
			m=fen[i].a1;
		else
		m=fen[i].a2;
		if(m>fen[i].a3)
		m=fen[i].a3;
		if(m>fen[i].a4)
		m=fen[i].a4;
			if(fen[i].a1<fen[i].a2)
			p=fen[i].a2;
		else
		p=fen[i].a1;
		if(p<fen[i].a3)
		p=fen[i].a3;
		if(p<fen[i].a4)
		p=fen[i].a4;
	}
}
