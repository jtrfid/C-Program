#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int n,i,j,t,k;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n-1;i++)
	for(j=0;j<n-i-1;j++)
	{
		if(a[j]<a[j+1])
		{
			t=a[j];
			a[j]=a[j+1];
			a[j+1]=t;
		}
	}
	int b[n-1];
	for(i=0;i<n-1;i++)
	{
		b[i]=a[i]-a[i+1];
	}
	for(i=0;i<n-2;i++)
	for(j=0;j<n-i-2;j++)
	{
		if(b[j]>b[j+1])
		{
			t=b[j];
			b[j]=b[j+1];
			b[j+1]=t;
		}
	}
	printf("%d",b[0]);
	return 0;
}
