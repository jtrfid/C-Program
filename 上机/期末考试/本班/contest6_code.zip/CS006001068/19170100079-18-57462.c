#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j=1,m,t=0,min,r,o;
	int a[50],b[100];
	scanf("%d",&n);
	for(i=0;i<n-1;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			m=fabs(a[j]-a[i]);
			b[t]=m;t++;
		}
	} min=b[0];for(o=0;o<=t;o++)
	{
		if(b[o]<min)
		{
			r=min;min=b[o];b[o]=r;
		}
	}printf("%d",min);return 0;
}

