#include <stdio.h>
int main()
{int n,z=0,t,m,i,j;
 scanf("%d",&n);m=n*(n-1)/2;
 int a[n];
 for(i=0;i<n;i++)scanf("%d",&a[i]);
 int b[m];
 for(i=0;i<m;i++)
 {for(j=0;j<n-i-1;j++)
  {b[z]=a[i]-a[n-j-1];z=z+1;}
 }
 for(i=0;i<m;i++)
 if(b[i]<0)b[i]=-b[i];
 for(i=0;i<m;i++)
 {if(b[0]>b[i]){t=b[0];b[0]=b[i];b[i]=t;}
 }
 printf("%d\n",b[0]);
 return 0;	
}
