#include<stdio.h>
int main()
{
	int m,k;
	scanf()
	return 0;
}
