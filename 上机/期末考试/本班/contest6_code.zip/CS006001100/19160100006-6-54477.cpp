#include<stdio.h>
int main()
{
	int m,n,a,b;
	int date;
	scanf("&d &d",date );
	if(a%400==0)
	if(b>29)
	date=-1��
	else date=b%7;
}
    else
{
	if(b>28)
	date=-1;
	else date=b%7;
	

	printf("%d",date);
	return 0;
}
