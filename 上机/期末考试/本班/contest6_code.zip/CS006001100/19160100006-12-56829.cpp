#include<stdio.h>
int main()
{
	int a,b,k,j,m,n,i;
	int c[200]={0};
	a=b=n=0;
	scanf("&d &d",&m,&k);
	c[0]=2;
	c[1]=3;
	for(i=2;i<200;i++)
	{
		if(c[i]%m==0) a++;
		if(c[i]%m==1) b++;
		if(c[i]%m>1) n++;
	}
	printf("%d %d %d",a,b,n);
	return 0;
}
