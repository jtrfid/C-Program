#include<stdio.h>
int main()
{
	int n,i,j;
	float S[n],Sn;
	scanf("%d",&n);
	for(i=1,j=0;i<=n,j<n;i++,j++)
	{
	S[j]=(1+1/i);
    }
    for(j=1;j<n;j++)
    Sn=S[j-1]*S[j];
	printf("%.1f",Sn);

	return 0;
}
