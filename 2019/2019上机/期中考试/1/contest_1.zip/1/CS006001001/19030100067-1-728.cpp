#include<stdio.h>
int main()
{
	int x1,x2,x3,y1,y2,y3,r1,r2,r3,r4,r5,r6,c;
	scanf ("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	r1=(x1)*(x1)+(y1)*(y1);
	r2=(x2)*(x2)+(y2)*(y2);
	r3=(x3)*(x3)+(y3)*(y3);
	if (r1>r2)
	{
		c=r1;
		r1=r2;
		r2=c;
	}
	if (r2>r3)
	{
		c=r2;
		r2=r3;
		r3=c;
	}
	if (r1>r2)
	{
		c=r1;
		r1=r2;
		r2=c;
	}
	if (r1==r2&&r2==r3)
	printf ("yes %d %d",r1,r2);
	else
	printf ("no %d %d",r1,r2);
	return 0;
}

