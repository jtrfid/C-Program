

#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int x1,y1,x2,y2,x3,y3,sum1,sum2,sum3,s1,s2,s3,max1,min1;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	sum1=x1*x1+y1*y1;
	sum2=x2*x2+y2*y2;
	sum3=x3*x3+y3*y3;
	if(sum1==sum2&&sum2==sum3)
	printf("yes ");
	else
	printf("no ");
	s1=x1*x1+y1*y2;
	s2=x2*x2+y2*y2;
	s3=x3*x3+y3*y3;
	max1=(s1>s2?s1:s2);
	max1=(max1>s3?max1:s3);
	min1=(s1>s2?s2:s1);
	min1=(min1>s3?s3:min1);
	printf("%d ",min1);
	printf("%d ",max1);
	return 0;
}











