#include <stdio.h>
int getDaysByMonth(int m,int d,char flag){
int c;
if(flag=='r'){//���� 
if(m==2){//2����29��
return (31+d);
}else if(m>2){
c=0;
m=m-1;
for(;m>0;m--){
if(m==1||m==3||m==5||m==7||m==8||m==10||m==12){
c+=31;
}else if(m==2){
c+=29;
}else{
c+=30;
}}
return c+d;
}else{
return d;
}
}else{//ƽ�� 
if(m==2){//2����28��

return (31+d);

}else if(m>2){

c=0;

m=m-1;

for(;m>0;m--){

if(m==1||m==3||m==5||m==7||m==8||m==10||m==12){

c+=31;

}else if(m==2){

c+=28;

}else{

c+=30;

}}

return c+d;

}else{

return d;

}}}

int main(){

int y,m,d,count=1;


scanf("%d %d %d",&y,&m,&d);

while(  ((((y%4==0 && y%100!=0)||(y%400==0)) && (m==2)) && d>29) || (y%400!=0 

&& y%4!=0 && m==2 && d>28) ||  ((m==1 || m==3 || m==5 || m==7 || m==8 || m==10 || 

m==12)&&d>31) || ((m==4 || m==6 || m==9 || m==11)&& d>30)){



scanf("%d %d %d",&y,&m,&d);}

//���ж��Ƿ�Ϊ����

if((y%4==0 && y%100!=0)||(y%400==0)){//���� 

count=getDaysByMonth(m,d,'r');

}else{//ƽ�� 

count=getDaysByMonth(m,d,'n');} 

printf("%d",count);

putchar('\n');

}

