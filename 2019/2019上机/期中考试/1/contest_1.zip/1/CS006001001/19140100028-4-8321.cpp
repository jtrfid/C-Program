#include <stdio.h>
int main()
{
	int n,p,i;
	int a[100];
	scanf("%d",&n);
	for(p=1950;p<n+1;p++)
	{for(i=0;i<100;i++)
{if(p%4==0&&p%10!=0)
a[i]=p;
else if(p%400==0)
a[i]=p;
}}
for(i=0;i<100;i++)
printf("%d ",a[i]);
}
