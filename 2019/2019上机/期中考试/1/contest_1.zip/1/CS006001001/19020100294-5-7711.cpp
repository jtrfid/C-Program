#include<stdio.h>
int zs(int n);
int main()
{
	int x,y,sum=0,x1,y1;
	scanf("%d %d",&x,&y);
	x1=x>y?y:x;
	y1=x>y?x:y;
	for(int i=x1;i<=y1;i++)
	{
		if(zs(i)==1) sum=sum+i*i;
	}
	printf("%d",sum);
	return 0;
}

int zs(int n)
{
	int a=1;
    for(int i=2;i<n;i++)
    {
	if(n%i==0) a=0;
    }
	return(a);
}
