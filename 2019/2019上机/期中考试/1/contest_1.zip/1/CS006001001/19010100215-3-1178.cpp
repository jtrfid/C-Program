#include<stdio.h>
int main(){
	int n;
	float m;
	scanf("%d",&n);
	m=n+1.0;
	printf("%.1f",m);
	return 0;
}
