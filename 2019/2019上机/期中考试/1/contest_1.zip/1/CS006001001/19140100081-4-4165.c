#include<stdio.h>
int main()
{
   int a,i,j,n;
   int b[1000];
   scanf("%d",&a);
   n=-1;
  for(j=0;;j++)
  { for(i=4*j;i<a-1949;i++)
     if(((a-i)%4==0&&(a-i)%100!=0)||((a-i)%400==0))
	 {  b[j]=a-i;
        n=n+1;
	    break;
	 }
     if(a-4*j<=1949)
		 break;
  }
   
  
for(j=0;j<=n;j++)
{
   printf("%d ",b[j]);
   if(j%5==4)
	   printf("\n");

}
return 0;

}