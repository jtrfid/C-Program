#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=n,a=0;i>=1949;i--) 
	{
	if((i%4==0&&(i%100!=0))||i%400==0)
	{
		a++;
		if(a%5==0) printf("%d\n",i);
		else printf("%d ",i);
	}
	else break;
	}
	return 0;
}
