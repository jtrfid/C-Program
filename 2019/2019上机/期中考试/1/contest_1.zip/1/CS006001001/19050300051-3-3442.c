#include<stdio.h>
int main(){

 int a,b;

    float x=1.0;
    scanf("%d",&b);
    for(a=1;a<=b;a++)
        x=x*(1+1.0/a);
    printf("%.1f",x); }
