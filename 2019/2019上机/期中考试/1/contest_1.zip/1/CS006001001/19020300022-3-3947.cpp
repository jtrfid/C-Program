#include <stdio.h>
int main()
{
	int n,k;
	k=1;
	scanf("%d",&n);
	double sn=0;
	do{
		k=k++;
		sn=(1+1/1)*(1+1/k);
	}
	while (k==n);
	printf("%.1f",sn);
	return 0;
}
