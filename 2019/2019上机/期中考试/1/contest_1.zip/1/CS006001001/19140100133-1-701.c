#include<stdio.h>
int main()
{int x1,y1,x2,y2,x3,y3,f1,f2,f3,d1,d2,d3,max,min;
scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
f1 = (x1-x2)/(y1-y2);
f2 = (x2-x3)/(y2-y3);
f3 = (x1-x3)/(y1-y3);
d1 = x1 * x1 + y1 * y1;
d2 = x2 * x2 + y2 * y2;
d3 = x3 * x3 + y2 * y2;
if (f1 * f2 == -1||f2 * f3 == -1||f1 * f3 == -1){
	printf ("yes ");
}else {
	printf ("no ");
}
if (d1 > d2){
	max = d1,min = d2;	
} else {
	max = d2,min = d1;
}
if (min < d3){
	min = min;
} else {
	min = d3;
}
if (max > d3){
	max = max;
} else {
	max = d3;
}
printf ("%d %d",min,max);
return 0;
}
