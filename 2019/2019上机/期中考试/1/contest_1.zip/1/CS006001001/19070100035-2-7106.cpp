#include<stdio.h>
int main(){
	int nian,yue,ri,day,er;
	scanf("%d %d %d",&nian,&yue,&ri);
	if(nian%4!=0)
	er=28;
	else 
	er=29;
	if(yue=1)
	day=ri;
	else if(yue=2)
	day=31+ri;
	else if(yue=3)
	day=31+er+ri;
	else if(yue=4)
	day=31+er+31+ri;
	else if(yue=5)
	day=31+er+31+30+ri;
	else if(yue=6)
	day=31+er+31+30+31+ri;
	else if(yue=7)
	day=31+er+31+30+31+30+ri;
	else if(yue=8)
	day=31+er+31+30+31+30+31+ri;
	else if(yue=9)
	day=31+er+31+30+31+30+31+31+ri;
	else if(yue=10)
	day=31+er+31+30+31+30+31+31+30+ri;
	else if(yue=11)
	day=31+er+31+30+31+30+31+31+30+31+ri;
	else if(yue=12)
	day=31+er+31+30+31+30+31+31+30+31+30+ri;
	printf("%d",day);
	return 0;
	
}
