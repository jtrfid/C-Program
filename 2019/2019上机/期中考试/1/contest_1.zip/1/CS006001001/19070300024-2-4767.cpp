#include<stdio.h>
int main()
{
	int a,b,c,d,t;
	scanf("%d %d %d",&a,&b,&c);
	if((a%4==0&&a%100!=0)||(a%400==0))
	t=1;
	else
	t=0;
	if(b==1)
	d=c;
	if(b==2)d=31+c;
if(b==3)d=t+59+c;
if(b==4)	d=90+t+c;
if(b==5)	d=120+t+c;
if(b==6)d=151+t+c;
if(b==7)	d=181+t+c;
if(b==8)	d=212+t+c;
if(b==9)	d=243+t+c;
if(b==10)	d=273+t+c;
if(b==11)	d=304+t+c;
if(b==12)	d=334+t+c;
	printf("%d",d);
	return 0;
}
