#include<stdio.h>
int main()
{
	int y,i,n=0;
	scanf("%d",&y);
	for(i=y;i>=1949;i--)
	{
		if((i%4==0&&i%100!=0)||i%400==0)
		{
			printf("%d ",i);n++;
			if(n%5==0)printf("\n");
		}
	}
}
