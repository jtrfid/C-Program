#include<stdio.h>
int main()
{int n,count=1;
float sum=1.0;
scanf("%d",&n);
while(count <= n)
 {sum *= (1+1.0/count);
	count ++;
};
printf("%.1f",sum);
return 0;
}
