#include<stdio.h>
int sn(int x);
int main()
{
	int n;
	float s;
	scanf("%d",&n);
	s=sn(n);
	printf("0.1f",s);
	return 0;
}

int sn(int x)
{
	float sum=1.0;
	for( int i=1;i<=x;i++)
	sum=sum*(1+1/i);
	return(sum);
}
