#include <stdio.h>

int main ()
{
	int x,y,i,k,q,sum;
	scanf("%d %d",&x,&y);
	q=0;
	for(k=x,sum=0;k<y+1;k++)
	{
		for(i=2;i<k;i++)
	{
		if(k%i==0)
		{
			q=1;
			break;
		}
		else
		q=0;
	}
		if(q==0)
		
		sum=sum+k*k;
	}
	printf("%d\n",sum);
	return 0;
}
