#include<stdio.h>

int main()
{
int x1,y1,x2,y2,x3,y3,a,b,c,t;	
scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);	
a=x1*x1+y1*y1;	
b=x2*x2+y2*y2;	
c=x3*x3+y3*y3;	
if(a==b&&b==c&&a==c)	
printf("yes %d %d",a,b);
else 	
	{if(a>b&&a>c&&b>c)
	printf("no &d %d",a,c);
	if(a>b&&c>b&&a>c)
	printf("no &d %d",a,b);	
	if(b>a&&b>c&&a>c)
	printf("no &d %d",b,c);	
	if(b>a&&b>c&&c>a)
	printf("no &d %d",b,a);	
	if(c>a&&c>b&&b>a)
	printf("no &d %d",c,a);	
	if(c>a&&c>b&&a>b)
	printf("no &d %d",c,b);	
	}
	
	return 0;
}
