#include<stdio.h>
int main()
{
	int n,i;
	float sn,t;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	    t=1+1/i;
	 {
		for(sn=1.0;i<=n;sn=sn*t)
	    break;
		printf("%.1f",sn);
	 }
    }
	return 0;
}	
	    
	
	
	

	    
	    
	 
	    
	
	

