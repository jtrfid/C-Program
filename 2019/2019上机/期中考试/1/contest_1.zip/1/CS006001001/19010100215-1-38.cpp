#include<stdio.h>
int main(){
	int x1,x2,x3,y1,y2,y3,a,b,c,max,min;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a=x1*x1+y1*y1;
	b=x2*x2+y2*y2;
	c=x3*x3+y3*y3;
	if(a==b&&b==c)
	printf("yes");
	else
	printf("no");
	if(a>b){
	max=a;
	min=b;}
	else{
	max=b;
	min=a;}
	if(max<c)
	max=c;
	if(min>c)
	min=c;
	printf(" %d %d",min,max);
	return 0;
}
