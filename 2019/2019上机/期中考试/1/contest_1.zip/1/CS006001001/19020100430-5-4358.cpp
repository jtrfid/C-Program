#include<stdio.h>
int main()
{
	int x,y,i,n=1,sum=0;
	scanf("%d %d",&x,&y);
	
	for(i=x;i<=y;i++)
	{
	  	for(n=2;n<i;n++)
		{
			if(i%n==0)
		    break;	
		}
	  if(n==i)
	  sum=sum+i*i;
	}
     printf("%d",sum);
     return 0;
}
