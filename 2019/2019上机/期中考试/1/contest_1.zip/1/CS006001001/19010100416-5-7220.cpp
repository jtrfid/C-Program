#include<stdio.h>
int main()
{
	int a,b,c,i;
	int sum=0;
	int pl(int i );
	scanf("%d %d",&a,&b);
	for (i=a;i<=b;i++)
		{
			if(pl(i)!=1)
			c=sum+i*i;
			sum=c;
		}
	printf("%d",sum-2);
	return 0;
}

int pl(int i)
{
	int a;
	for(a=2;a<i-1;a++)
		{
		if (i%a==0)
		{return 1;break;}
		
		}
}
