#include<stdio.h>
int main()
{
	float a,b,c;
	scanf("%f",&a);
	b=a+1;
	printf("%.1f",b);
	return 0;
}
