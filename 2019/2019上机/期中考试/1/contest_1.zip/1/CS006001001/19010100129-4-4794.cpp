#include<stdio.h>
int main()
{
	int y,a,b,c,i;
	scanf("%d",&y);
	a=i/4;
	b=i/100;
	c=i/400;
	for(i=1949;i<=y;i++);
	{
	if((a==0&&b!=0)||c==0)
	  printf("%d",i);
}
	
	
}
