#include<stdio.h>
int main()
{
    int a,b,c,i,n;
    scanf("%d",&a);
    n=0;
    for(i=a;i>=1949;i--)
    {
    	b=i%4;
        c=i%100;
        if(b==0&&c!=0||i==2000)
        {
        printf("%d ",i);
        n=n+1;
        
        if(n%5==0&&n!=0)
        {
        	printf("\n");
        }
    }
    }
	return 0;
}
