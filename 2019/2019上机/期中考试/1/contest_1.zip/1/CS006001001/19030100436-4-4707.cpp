#include <stdio.h>
int main ()
{
	int n,i,j;
	scanf("%d",&n);
	int y[n-1949+1];
	j=0;
	for(i=0;i<n;i++)
	{
		y[i]=n-i;
		if ((y[i]%4==0&&y[i]%100!=0)||(y[i]%400==0))
		{
			if (y[i]<1949)
		    break;
		    else
		    printf("%d ",y[i]);
		    j++;
		}
		if(j!=0&&j%5==0)
		printf("\n");
	}
	return 0;
}
