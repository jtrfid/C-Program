#include <stdio.h>
int main()
{
	int x,y,z,m,i,sum=0;
	scanf("%d %d",&x,&y);
	{if(x>y)
	    {z=x;x=y;y=z;}
	if((x>=20&&y<1000)&&((y-x)>10))
	    for(i=x;i<y;i++)
	    	{for(m=2;m<i-1;m++)
	    	  	{if(i%m!=0)
	    	  	sum=sum+i*i;}}
	    	  
}
	    printf("%d",sum);
	    return 0;
}
