#include<stdio.h>
int main( )
{
	float n,s=1.0,i;
	scanf("%f",&n);
	for(i=1;i<=n;i++)
	{
	s=s*(1+1/i);
    }
	printf("%.1f",s);
	return 0;
}
