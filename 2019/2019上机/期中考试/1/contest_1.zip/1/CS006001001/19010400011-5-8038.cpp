#include<stdio.h>
int main()
{
	int a,b,i,j,s=0;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)break;
			else if(j==i-1) s=s+i*i;
		}
      
	}
	printf("%d",s);
}
