#include<stdio.h>
int main()
{
	int x1,x2,x3,y1,y2,y3, sed[3], max = 0, min , i;
	scanf("%d%d%d%d%d%d", &x1, &y1, &x2, &y2, &x3, &y3);
	sed[0] = x1 * x1 + y1 * y1;
	sed[1]= x2 * x2 + y2 * y2;
	sed[2] = x3 * x3 + y3 * y3;
	if (sed[0] == sed[1] && sed[0] == sed[2])
	printf("yes ");
	else printf("no ");
	min = sed[0];
	for (i = 0; i < 3; i++)
		{
		if (sed[i]> max) max = sed[i];
		if (sed[i]< min) min = sed[i];
	}
	printf("%d %d", min,max);
	return 0;
}


