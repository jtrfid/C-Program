
#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int x,y,i,sum=0,q;
	scanf("%d %d",&x,&y);
	for(;x<=y;x++)
	{
    for(i=2;i<x;i++)
	{if(x%i!=0)
	q=1;
	else {
	
	q=0;
	break;}
	
    if(q=1)
    sum=sum+x*x;}
	}
printf("%d",sum);
return 0;
}





