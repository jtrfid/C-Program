#include<stdio.h>
int main( )
{
	int a,i=1949,count=0;
	scanf("%d",&a);
	while(i<a)
	{
	if(i%4==0&&i%100!=0||i%400==0)
	{
	  count++;
	  printf("%d",i);
    }
    if(count==5)
    {
    	printf("\n");
    	count=0;
    }
    i++;
    }
    if(count!=0)
    {
    	printf("\n");
    }
    return 0;
}
