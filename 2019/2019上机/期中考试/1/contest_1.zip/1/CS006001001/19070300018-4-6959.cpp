#include<stdio.h>
int main()
{
	int year,i;
	scanf("%d",&year);
	 	for(i=1950;i<=year;i++)
	 	{
		 if((i%4==0&&i%100!=0)||i%400==0)
		   printf("%d ",i);}
	    

	return 0;
}
