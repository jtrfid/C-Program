#include<stdio.h>
int main()
{
	int i,n;
	float Sn=1.0;
	i=1;
	1<n<1000;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		Sn*=(1/i+1);
	}
	printf("%.1f",Sn);
	return 0;
}
