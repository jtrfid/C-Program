

#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int n,a;
	scanf("%d",&n);
	for(;n>1949;n--)
	{a=n;
	if(a%4==0){
		if(a%100!=0)printf("%d ",a);
		else if(a%400==0)printf("%d ",a);
	}
	}
	return 0;
}






