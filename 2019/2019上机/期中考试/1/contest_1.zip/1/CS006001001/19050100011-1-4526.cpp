#include<stdio.h>
int main()
{int y,m,d;
scanf("%d %d %d",&y,&m,&d);
int a[12]={31,28,31,30,31,30,31,31,30,31,30,31};
int t=0,i;
if(y%4==0&&y%100!=0||y%400==0)
{
	a[1]++;
	for(i=0;i<m-1;i++)
	   t=t+a[i];
	   t=t+d;
	   printf("%d",t);
	   a[1]--;
}
else
{
	for(i=0;i<m-1;i++)
	t=t+a[i];
	t=t+d;
	printf("%d",t);
}
return 0;
}
