#include<stdio.h>
int main(){
	int x1,x2,x3,y1,y2,y3;
	int SED,a,b,c,d,e;
	scanf("%d%d %d%d %d%d",&x1,&y1,&x2,&y2,&x3,&y3);
	if(x1*x1+y1*y1==x2*x2+y2*y2&&x2*x2+y2*y2==x3*x3+y3*y3)
	printf("yes ");
	else
	printf("no ");
	a=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
	b=(x2-x3)*(x2-x3)+(y2-y3)*(y2-y3);
	c=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);
	if(a-b>0&&a-c>0){
			d=a;
			if(b-c>0)
				e=c;
			else
				e=b;
		}
	else if(b-a>0&&b-c>0){
			d=b;
			if(a-c>0)
				e=c;
			else
				e=a;
				}
	
	else if(c-a>0&&c-b>0){
		d=c;
		if(a-b>0)
		e=b;
		else
		e=a;
			
		
	}
	printf("%d %d",e,d);
	return 0;
}
