#include<stdio.h>
int main()
{
	int a,b;
	scanf("d",&a);
	if(a%4==0)
	{
		printf()
	}
