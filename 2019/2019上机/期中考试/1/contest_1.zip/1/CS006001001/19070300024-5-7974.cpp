#include<stdio.h>
int main()
{
	int x,y,i,j,t=0,z,w;
	scanf("%d %d",&x,&y);
	if(x>y)
	{
		w=x;
		x=y;
		y=w;
	}
	for(i=x;i<=y;i++)
	{
		z=1;
		for(j=2;j<i;j++)
	{
	
			if(i%j==0){
			
			z=0;break;}
			}
		if(z==1)
		t=t+i*i;
		
	}
	printf("%d",t);
	return 0;
}
