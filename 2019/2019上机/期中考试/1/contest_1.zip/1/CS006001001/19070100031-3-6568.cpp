#include<stdio.h>
int main()
{
	int n,m,i;
	double sum=1,a;
	scanf("%d",&n);
	   for(a=1;a<n+1;a++)
	      {
	        m=1+1/a;
	        sum=sum*m;
         }
    printf("%.f",sum);
    return 0;
	  
	
}
