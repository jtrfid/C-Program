#include<stdio.h>
#include<math.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,a,b,c,d,e;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a=x1*x1+y1*y1;
	b=x2*x2+y2*y2;
	c=x3*x3+y3*y3;
	if(a>=b&&a>=c)
	  {
	  d=a;
	  if(b>=c)
	  e=c;
	  else
	  e=b;}
	else
		{
		if(b>=a&&b>=c)
            {
            d=b;
			if(a>=c)
			e=c;
			else
			e=a;}
		else
		{
		d=c;
		if(a>=c)
		e=c;
		else
		e=a;}
	}
	if(a==b&&a==c)
	printf("yes %d %d",e,d);
	else
	printf("no %d %d",e,d);
	
	
}
