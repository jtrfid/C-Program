#include<stdio.h>
int main()
{
	int x1,x2,x3,y1,y2,y3;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	int a,b,c,d,e,f;
	a=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
	b=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);
	c=x2*x2+y2*y2;
	d=x3*x3+y3*y3;
	e=(x2-x3)*(x2-x3)+(y2-y3)*(y2-y3);
	f=x1*x1+y1*y2;
	if((a+b+c+d)==(e+f))
	{
		if(c>d&&c>f&&d<f&&d<c){
		printf("yes %d %d\n",d,c);}
		if(c>d&&c>f&&f<d&&f<c){
		printf("yes %d %d\n",f,c);}
		if(d>c&&d>f&&f<d&&f<c){
		printf("yes %d %d\n",f,d);}
		if(d>c&&d>f&&c<d&&c<f){
		printf("yes %d %d\n",c,d);}
		if(f>c&&f>d&&c<d&&c<f){
		printf("yes %d %d\n",c,f);}
		if(f>c&&f>d&&d<c&&d<f){
		printf("yes %d %d\n",d,f);}}
	if((a+b+c+d)!=(e+f)){
	    if(c>d&&c>f&&d<f&&d<c){
		printf("no %d %d\n",d,c);}
		if(c>d&&c>f&&f<d&&f<c){
		printf("no %d %d\n",f,c);}
		if(d>c&&d>f&&f<d&&f<c){
		printf("no %d %d\n",f,d);}
		if(d>c&&d>f&&c<d&&c<f){
		printf("no %d %d\n",c,d);}
		if(f>c&&f>d&&c<d&&c<f){
		printf("no %d %d\n",c,f);}
		if(f>c&&f>d&&d<c&&d<f){
		printf("no %d %d\n",d,f);}}
	return 0;
}
