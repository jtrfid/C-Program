#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,n;
    float x=1.0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
        x=x*(1+1.0/i);
    printf("%.1f",x);
    return 0;
}
