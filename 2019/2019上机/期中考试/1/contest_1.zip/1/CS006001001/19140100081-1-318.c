#include<stdio.h>
int main()
{
  int x1,y1,x2,y2,x3,y3;
  int SED1,SED2,SED3;
  int max,min;
  scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
  SED1=x1*x1+y1*y1;
  SED2=x2*x2+y2*y2;
  SED3=x3*x3+y3*y3;
  if(SED1==SED2&&SED2==SED3)
	  printf("yse");
  else printf("no");
  if(SED1>=SED2)
  {    if(SED1>=SED3&&SED2>=SED3)
	  {	  max=SED1;
	      min=SED3;
	  }
      else if(SED1>=SED3&&SED3>=SED2)
	   {
	      max=SED1;
		  min=SED2;
	   }
	  else if(SED1<=SED3)
	  {
	      max=SED3;
		  min=SED2;
	  }
  }
  else if(SED2>=SED1)
{    if(SED2>=SED3&&SED1>=SED3)
	  {	  max=SED2;
	      min=SED3;
	  }
      else if(SED2>=SED3&&SED3>=SED1)
	   {
	      max=SED2;
		  min=SED1;
	   }
	   else if(SED2<=SED3)
	   {
	      max=SED3;
		  min=SED1;
	   }
  }

printf(" %d %d",min,max);
return 0;
  


}