#include<stdio.h>
main()
{     
    int i;
    int count = 0;
    scanf("%d",&i);
    for(i=1949;i<=2020;i++)
	{
        if (((i%4==0)&&(i%400==0))||((i%4==0)&&(i%100!=0)))
		{
            printf(" %d",i); 
			count++;
            if (count % 5 == 0)
                printf("\n"); 
        }
    }
}
