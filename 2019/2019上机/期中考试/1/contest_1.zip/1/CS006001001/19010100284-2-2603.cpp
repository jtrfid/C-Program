#include<stdio.h>

int main()
{
    int a,b,c,d;
    scanf("%d %d %d",&a,&b,&c);
    if(a%4==0&&a%200==0)
    {
    	if(b>0)
    	d=(b-1)*30+c;
    	if(b>1)
    	d=(b-1)*30+c+1;
    	if(b>2)
    	d=(b-1)*30+c;
    	if(b>3)
    	d=(b-1)*30+c+1;
    	if(b>4)
    	d=(b-1)*30+c+1;
    	if(b>5)
    	d=(b-1)*30+c+2;
    	if(b>6)
    	d=(b-1)*30+c+2;
    	if(b>7)
    	d=(b-1)*30+c+3;
    	if(b>8)
    	d=(b-1)*30+c+4;
    	if(b>9)
    	d=(b-1)*30+c+4;
    	if(b>10)
    	d=(b-1)*30+c+5;
    	if(b>11)
    	d=(b-1)*30+c+6;
    }
    else
    {
    	if(b>0)
    	d=(b-1)*30+c;
    	if(b>1)
    	d=(b-1)*30+c+1;
    	if(b>2)
    	d=(b-1)*30+c-1;
    	if(b>3)
    	d=(b-1)*30+c;
    	if(b>4)
    	d=(b-1)*30+c;
    	if(b>5)
    	d=(b-1)*30+c+1;
    	if(b>6)
    	d=(b-1)*30+c+1;
    	if(b>7)
    	d=(b-1)*30+c+2;
    	if(b>8)
    	d=(b-1)*30+c+3;
    	if(b>9)
    	d=(b-1)*30+c+3;
    	if(b>10)
    	d=(b-1)*30+c+4;
    	if(b>11)
    	d=(b-1)*30+c+4;
    }
    printf("%d",d);
	
	return 0;
}
