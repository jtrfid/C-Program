#include<stdio.h>
int main()
{
	int x,i;
	float s=1;
	scanf("%d",&x);
	for(i=0;i<x;i++)
	{
		s=s*((i+2)/(i+1));
	}
	printf("%.1f",s);
	return 0;
}
