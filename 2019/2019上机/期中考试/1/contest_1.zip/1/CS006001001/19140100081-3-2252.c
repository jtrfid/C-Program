#include<stdio.h>
int main()
{
   int n,i;
   float s;
   scanf("%d",&n);
   s=1;
   for(i=1;i<=n;i++)
	   s=s+1;
   printf("%.1f",s);
   return 0;




}