#include <stdio.h>
int main()
{
	int i,j,t,x1,y1,x2,y2,x3,y3,p1,p2,p3;
	int a[i];
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a[0]=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
	a[1]=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);
	a[2]=(x3-x2)*(x3-x2)+(y3-y2)*(y3-y2);
	for(j=0;j<2;j++)
	{for(i=0;i<2-j;i++)
	if(a[i]>a[i+1])
{t=a[i];a[i]=a[i+1];a[i+1]=t;}}
	p1=x1*x1+y1*y1;
	p2=x2*x2+y2*y2;
	p3=x3*x3+y3*y3;
	if(p1==p2&&p1==p3)
	printf("yes %d %d",a[0],a[2]);
	else
	printf("no %d %d",a[0],a[2]);
}
