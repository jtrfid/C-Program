#include<stdio.h>
#include<math.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,SED;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	SED=x1^2+y1^2;
	SED=x2^2+y2^2;
	SED=x3^2+y3^2;
	if(SED=SED=SED)
	printf("yes\n");
	else
	printf("no\n");break;
	max={SED};
	min={SED};
printf("%d %d",SED,SED);
	return 0;
}
