#include<stdio.h>
int main()
{
	int x,n,i,a[n];
	float s;
	scanf("%d",&x);
	s=1.0;
	for(i=0;i<x;i++)
	{
		a[i]=i+1;
	}
	for(i=0;i<x;i++)
	{
		s=s*(1+1/a[i]);
	}
	printf("%.1f",s);
	return 0;
}
