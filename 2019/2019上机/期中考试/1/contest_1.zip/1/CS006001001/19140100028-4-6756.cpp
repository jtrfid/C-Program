#include <stdio.h>
int main()
{int n,p,i,t,r,o;
int a[1000];
	scanf("%d",&n);
	for(i=0;i<1000;i++)
{for(p=1950;p<n+1;p++)
	t=p/4;r=n/10;o=p/400;
{if(t*4==p&&r*10!=p)
	a[i]=p;
else if(o*400==p)
a[i]=p;}}
for(i=0;i<1000;i++)
printf("%d ",a[i]);
}
