#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	scanf("%d %d %d %d %d %d",&a,&b,&c,&d,&e,&f);
	int x,y,z;
	x=a*a+b*b;
	y=c*c+d*d;
	z=e*e+f*f;
	int min(int x,int y,int z);int max(int x,int y,int z);
	if(x==y&&y==z)
		printf("Yes %d %d",min(x,y,z),max(x,y,z));
	else
    	printf("No %d %d",min(x,y,z),max(x,y,z));
    return 0;
	
}


int min(int x,int y,int z)
{
	int m;
	if (x<y)
		{
			if(x<z)
		       m=x;
		    else m=z;
		}
	else {
		  if(y<z)
		  m=y;
		  else m=z;
	     }	
    return m;
}

int max(int x,int y,int z)
{
	int n;
	if (x>y)
		{
			if(x>z)
		       n=x;
		    else n=z;
		}
	else {
		  if(y>z)
		  n=y;
		  else n=z;
	     }	
    return n;
}




