#include<stdio.h>
int main()
{
	int t,b,c,d,sum,i;
	int a[13];
	a[0]=0;
	a[1]=31;
	a[3]=31;
	a[4]=30;
	a[5]=31;
	a[6]=30;
	a[7]=31;
	a[8]=31;
	a[9]=30;
	a[10]=31;
	a[11]=30;
	a[12]=31;
	scanf("%d %d %d",&t,&b,&c);
	if((t%400==0)||(t%4==0&&t%100!=0))
	a[2]=29;
	else
	a[2]=28;
	for(i=0;i<b;i++)
	sum=sum+a[i];
	sum=sum+c-2;
	printf("%d",sum);
	return 0;
	
	
	
	
}
