#include<stdio.h>
int main()
{
	int i,y,n=0;
	scanf("%d",y);
	for(i=y;i>=1949;i--)
	{
		if((i%100==0&&i%400==0)||(i%100!=0&&i%4==0))
		{
			printf("%d ",i);
			n++;
			if(n==5)
			printf("\n");
		}
	}
	return 0;
}
