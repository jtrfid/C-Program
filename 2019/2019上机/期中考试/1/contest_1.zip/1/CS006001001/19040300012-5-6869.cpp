#include<stdio.h>
#include<math.h>
int cn(int i);
int main()
{int a,b,i,sum=0,h,s,end;
scanf("%d %d",&a,&b);
for(i=a;i<=b;i++) { end=i;
	for(h=2;h<i;h++){
		if(i%h==0) {end=0;
		} 
			}  sum+=end*end;
			
};printf("%d",sum);
}


