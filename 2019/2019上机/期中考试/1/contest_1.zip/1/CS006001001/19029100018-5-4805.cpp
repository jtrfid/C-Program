#include<stdio.h>
int sushu(int a)
{
	int b,c,d,e,i;
	for(i=2;i<a/2;i++)
	{
		if(a%i==0)
		return (0);
	}
	return (1);
	
}
int main()
{
	int a,b,c,i,sum;
	scanf("%d %d",&a,&b);
	sum=0;
	for(i=a;i<=b;i++)
	{
		if(sushu(i))
		sum=sum+i*i;
		
	}
	printf("%d",sum);
	return 0;
}
