#include<stdio.h>
int main()
{
	double s;
	int n;
	scanf("%d",&n);
	s=n+1.0;
	printf("%.1f",s);
	return 0;
}
