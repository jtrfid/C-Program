#include <stdio.h>
int main()
{
	int a,b;
	int c=0;
	scanf("%d",&a);
	b=a;
	for(b=a;b>1949;b--)
	{
		if(b/4==0)
		c=c+1;
		printf("%d ",b);
	}if(c%5==0)
	printf("\n");
	return 0;
	
	
}
