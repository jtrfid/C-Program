#include <stdio.h>
int main()
{
	int n,k;
	k=1;
	scanf("%d",&n);
	double sn=0;
	sn=n+1;
	printf("%.1f",sn);
	return 0;
}
