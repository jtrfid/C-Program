#include<stdio.h>
int main()
{
	int a,b,c,d;
	scanf("%d %d %d",&a,&b,&c);
	if(b=1)
	d=c;
	else if(b=2)
    d=31+c;
	           else if(b=3)
	           d=59+c;
	                  else if(b=4)
	                  d=90+c;
	                         else if(b=5)
	                         d=120+c;
							         else if(b=6)
							         d=151+c;
							                 else if(b=7)
							                d=181+c;
							                        else if(b=8)
									                d=212+c;
									                        else if(b=9)
									                        d=243+c;
									                                else if(b=10)
									                                d=273+c;
									                                        else if(b=11)
									                                        d=304+c;
									                                                else if(b=12)
									                                                d=334+c;
	printf("%d\n",d);								                        
	#if #endif
}
