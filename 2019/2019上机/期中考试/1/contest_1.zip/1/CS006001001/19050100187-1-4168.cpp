#include<stdio.h>
int main()
{
    int max(int x,int y,int z);
    int min(int x,int y,int z);
	int x1,y1,x2,y2,x3,y3;
	int a,b,c,d,e;
	scanf("%d %d %d %d %d %d",x1,y1,x2,y2,x3,y3);
	a=(x1^2+y1^2)^1/2;
    b=(x2^2+y2^2)^1/2;
	c=(x3^2+y3^2)^1/2;
	d=max(a,b,c);
	e=min(a,b,c);
	if(a=b=c)
	printf("yes %d %d\n",d,e);
	    else
	    printf("no %d %d\n,d,e");
return0;
}
int max(int x,int y,int z)
{
	int d;
	if(x>=y&&x>=z)
	d=x;
	    else
	    if(y>=z)
	    d=y;
	        else
	        if(y<z)
	        d=z;
	return(d);
}
int min(int x,int y,int z)
{
	int e;
	if(x<=y&&x<=z)
	e=x;
	    else
	    if(y<=z)
	    e=y;
	        else
	        if(y>z)
	        e=z;
	return(e);	
}
