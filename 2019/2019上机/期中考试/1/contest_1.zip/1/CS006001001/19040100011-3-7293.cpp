#include <stdio.h>
int main()
{
	int n,i;
	double b=1.0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		b=b*(1+1.0/i);
	}
	printf("%.1f",b);
	return 0;
}
