#include<stdio.h>
int main()
{
	int a,i;
	float n;
	scanf("%d",&a);
	n=a+1;

	printf("%.1f",n);
	return 0;
}
