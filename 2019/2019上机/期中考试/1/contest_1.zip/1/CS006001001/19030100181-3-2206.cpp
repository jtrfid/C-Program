#include<stdio.h>
int main()
{
	int n,i;
	float sum=1.0,c;
	scanf("%d",&n);
	for(i=1;i<n+1;i++)
	{
		c=1.0/i;
		sum*=(1+c);
	}
	printf("%.1f",sum);
	return 0;
}
