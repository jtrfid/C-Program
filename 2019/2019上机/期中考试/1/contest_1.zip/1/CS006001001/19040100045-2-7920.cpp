#include<stdio.h>
int main()
{
	int x,y,z,i,a,sum;
	scanf("%d %d %d",&x,&y,&z);
	if(x%4!=0)
	{
		int a[12]={31,29,31,30,31,30,31,31,30,31,30,31};
		if(y>=3)
		{
			for(i=1;i<y-1;i++)
		    sum=a[0]+z+a[i];
		    printf("%d",sum);
		}
		else if(y==2)
		{
			sum=a[0]+z;
			printf("%d",sum);
		}
		else
		{
			sum=z;
			printf("%d",sum);
		}
		
	}
		else
	{
		int a[12]={31,28,31,30,31,30,31,31,30,31,30,31};
		if(y>=3)
		{
			for(i=1;i<y-1;i++)
		    sum=a[0]+z+a[i];
		    printf("%d",sum);
		}
		else if(y==2)
		{
			sum=a[0]+z;
			printf("%d",sum);
		}
		else
		{
			sum=z;
			printf("%d",sum);
		}
		
	}
	return 0;
	
}
