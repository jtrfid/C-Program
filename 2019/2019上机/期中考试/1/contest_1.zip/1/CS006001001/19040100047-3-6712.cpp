#include<stdio.h>
int main()
{
	int n,i;
	float sn1,sn2;
	scanf("%d",&n);
	for(i=2;i<=n;i++)
	{
	    sn1=(1+1/i);
	    break;
	 } 
	   
	sn2=(1+1/(i-1))*sn1; 
	
	
	printf("%.1f",sn2);
	return 0;
	
}
