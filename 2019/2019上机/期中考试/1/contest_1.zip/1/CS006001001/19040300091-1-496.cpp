#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,g,h,i,j;
	scanf("%d %d %d %d %d %d",a,b,c,d,e,f);
	g=a*a+d*d;h=b*b+e*e;i=c*c+f*f;
	if(g==h&&g==i)
	printf("yes");
	else printf("no");
	if(g>h)
	{
		j=g;
		g=h;
		h=j;
	}
	if(h>i)
	{
		j=h;
		h=i;
		i=g;
	}
	printf("%d %d",g,i);
	return 0;
}
