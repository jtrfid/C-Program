#include<stdio.h>
int main()
{
	int x,y,d,f,h,j=0;
	scanf("%d %d",&x,&y);
	x=(x>y)?y:x;
	y=(x>y)?x:y;
	for(d=x;d<=y;d++)
	  {
	   for(f=2;f<d;f++)
	      {
	      if(d%f==0)
		  {
		  	h=0;
		  	break;
	      }
	      else h=1;
	  }
	   if(h!=0)
	   j=j+d*d; 
	   }
	printf("%d",j);
	return 0;
}
