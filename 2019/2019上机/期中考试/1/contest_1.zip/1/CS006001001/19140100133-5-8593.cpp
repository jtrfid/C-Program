#include<stdio.h>
int main()
{int a,b,sum=0,s=0,n=0;
scanf ("%d %d",&a,&b);
int count = a,number = 2;
while (count <= b && number < count){
	while(number < count){
		if(count % number != 0);
		n ++;
		number ++;
		if (n == 0){
		sum += count * count;
	}
	n = 0;
	}
	count ++;
}
printf ("%d",sum);
return 0;
}
