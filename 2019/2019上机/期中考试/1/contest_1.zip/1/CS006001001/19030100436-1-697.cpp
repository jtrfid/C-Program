#include <stdio.h>
int main ()
{
	int x[3],y[3],a[3];
	int i,j,t;
	for (i=0;i<3;i++)
	{
		scanf("%d",&x[i]);
		scanf("%d",&y[i]);
	}
	for(i=0;i<3;i++)
	{
		a[i]=x[i]*x[i]+y[i]*y[i];
	}
	if(a[0]==a[1]&&a[0]==a[2])
	printf("yes ");
	else
	printf("no ");
	for (j=0;j<3-i;j++)
	 for(i=0;i<3;i++)
	 if (a[i]<a[i+1])
	 {
	 	t=a[i];
	 	a[i]=a[i+1];
	 	a[i+1]=t;
	 }
	printf("%d %d",a[2],a[0]);
	return 0;
}
