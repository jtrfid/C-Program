#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	int i,j=0;
	for(i=a;i>1949;i--)
	{
		if(i%4==0)
		{
			printf("%d ",i);
			j++;
			if(j%5==0)
			printf("\n");
	    }
	}
		
	return 0;
	
}
