#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	for(;a>1949;a--)
	{
	    if(a%4==0&&a%100!=0||a%400==0)
        {
	    printf("%d ",a);
	    }
    }
	
}
