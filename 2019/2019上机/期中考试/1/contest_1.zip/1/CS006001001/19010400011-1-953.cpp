#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,s[3];
	int i,j,t;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	s[0]=(x1-0)*(x1-0)+(y1-0)*(y1-0);
    s[1]=(x2-0)*(x2-0)+(y2-0)*(y2-0);
    s[2]=(x3-0)*(x3-0)+(y3-0)*(y3-0);
    if((s[0]==s[1])&&(s[1]==s[2]))
    {
    	printf("yes %d %d",s[0],s[1]);
    
    }
    else
	{

    for(i=0;i<2;i++)
    {
    	for(j=0;j<2-i;j++)
    	{
    		if(s[j]<=s[j+1])
    		{
    			t=s[i];
    			s[i]=s[i+1];
    			s[i+1]=t;
    		}
    	}
    }
    printf("no %d %d",s[0],s[2]);
}
    return 0;
}
