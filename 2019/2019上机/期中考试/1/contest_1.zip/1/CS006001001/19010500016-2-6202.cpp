#include<stdio.h>
int main( )
{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	if(b==1)
	{
	printf("%d",c);
}
	else if(b==2)
	{
		c=c+31;
		printf("%d",c);
	}
	else if((b%4==0)&&(b%100!=0))
	{
		if(b=3)
		{
		c=c+60;
	    printf("%d",c);}
	    else if(b==4)
	    {c=c+91;
	    printf("%d",c);
	    }
	    else if(b==5)
	    {c=c+121;
	    printf("%d",c);
	    }
	    else if(b==6)
	    {c=c+152;
	    printf("%d",c);
	    }
	    else if(b==7)
	    {c=c+182;
	    printf("%d",c);
	    }
	    else if(b==8)
        {c=c+213;
        printf("%d",c);
        }
        else if(b==9)
        {c=c+244;
        printf("%d",c);
        }
        else if(b==10)
        {c=c+274;
        printf("%d",c);
        }
        else if(b==11)
        {c=c+305;
        printf("%d",c);
        }
        else if(b==12)
        {c=c+335;
        printf("%d",c);
        }
	}
	else 
	{
		if(b=3)
		{
		c=c+59;
	    printf("%d",c);}
	    else if(b==4)
	    {c=c+90;
	    printf("%d",c);
	    }
	    else if(b==5)
	    {c=c+120;
	    printf("%d",c);
	    }
	    else if(b==6)
	    {c=c+151;
	    printf("%d",c);
	    }
	    else if(b==7)
	    {c=c+181;
	    printf("%d",c);
	    }
	    else if(b==8)
        {c=c+212;
        printf("%d",c);
        }
        else if(b==9)
        {c=c+243;
        printf("%d",c);
        }
        else if(b==10)
        {c=c+273;
        printf("%d",c);
        }
        else if(b==11)
        {c=c+304;
        printf("%d",c);
        }
        else if(b==12)
        {c=c+334;
        printf("%d",c);
        }
	}
return 0;
}

	
	
	

