#include<stdio.h>

int main()
{
	int a,i;
	scanf("%d",&a);

		for(i=1949;i<=a;i++)
		{
		if (i%400==0||(i%4==0&&i%100!=0))
		printf("%d",i);
	}
	
	return 0;
}
