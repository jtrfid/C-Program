#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,g,h,i;
	scanf("%d %d %d",&a,&b,&c);
	d=a%4;
	e=a%100;
	f=a%400;
	h=b/2;
	i=b%2;
	if((d==0&&e!=0)||f==0)
	{	if(b<=2)
		g=(b-1)*31+c;
		else
		{
		  if(b<=8);
		    {if(i==0)
		     g=h*61-30+c;
		     else
		     g=h*61+c;
		    }
		   {if(i==0)
		    g=245+61*(h-4)-31+c;
		    else
		    g=245+61*(h-4)+c;
		   }
		}	
	}
	
	else
	{
		if(b<=2)
		g=(b-1)*31+c;
		else
		{if(b<=8);
		  {if(i==0)
		   g=h*61-32+c;
		   else
		   g=h*61+c-2;
		  }
		 {if(i==0)
		  g=243+61*(h-4)-31+c;
		  else
		  g=243+61*(h-4)+c;
		 }
	}
}
printf ("%d",g);
}
