#include<stdio.h>
int main()
{
	int n,i;
	double s=1.0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		s=s*(1+1.0/i);
	}
	printf("%.1f",s);
	return 0;
}
