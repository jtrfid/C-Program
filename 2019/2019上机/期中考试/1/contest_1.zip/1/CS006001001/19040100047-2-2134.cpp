#include<stdio.h>
#include<math.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,sed1,sed2,sed3,r1,r2,r3;
	char ch;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	r1=sqrt(x1*x1+y1*y1);
	r2=sqrt(x2*x2+y2*y2);
	r3=sqrt(x3*x3+y3*y3);
	sed1=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
	sed2=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);
	sed3=(x3-x2)*(x3-x2)+(y3-y2)*(y3-y2);
	if(r1==r2==r3&&sed1>sed2>sed3)
	{
		printf("yes %d %d\n",sed3,sed1);
		
	}
	else if(r1==r2==r3&&sed1>sed3>sed2)
	{
		printf("yes %d %d\n",sed2,sed1);
	}
	else if(r1==r2==r3&&sed3>sed2>sed1)
	{
		printf("yes %d %d\n",sed1,sed3);
	}
	else if(r1==r2==r3&&sed3>sed1>sed2)
	{
		printf("yes %d %d\n",sed2,sed3);
	}
	else if(r1==r2==r3&&sed2>sed1>sed3)
	{
		printf("yes %d %d\n",sed3,sed2);
	}
	else if(r1==r2==r3&&sed2>sed3>sed1)
	{
		printf("yes %d %d\n",sed1,sed3);
	
	}
	
	return 0;
}
