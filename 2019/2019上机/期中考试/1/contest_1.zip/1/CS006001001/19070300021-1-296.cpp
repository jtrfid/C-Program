#include <stdio.h>
int main()
{
	int x1,x2,x3,y1,y2,y3,a,b,c;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a=x1*x1+y1*y1;b=x2*x2+y2*y2;c=x3*x3+y3*y3;
	{if(a==b&&b==c)
	  printf("yes ");
	  else
	  printf("no ");}
    {	if((a>b)&&(b>c))
	  printf("%d %d",c,a);
	 else if((c>a)&&(a>b))
	  printf("%d %d",b,c);
	  else if((b>a)&&(a>c))
	  printf("%d %d",c,b);
	  else if((c>b)&&(b>a))
	  printf("%d %d",a,c);
	  else if((a>c)&&(c>b))
	  printf("%d %d",b,a);
	  else if((b>c)&&(c>a))
	  printf("%d %d",a,b);}
	  return 0;
}
