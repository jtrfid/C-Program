#include<stdio.h>
int main()
{
	int y,i;
	scanf("%d",&y);
	for(i=y;i>=1949;i--)
	{
		if(i%4==0&&i%100!=0)
		printf("%d ",i);
		else if(i%400==0)
		printf("%d ",i);
	}
}
