#include<stdio.h>
int is(int x)
{
 int ip=1;
 for(int i=2;i<x;i++)
 {
  if(x%i==0)
  {
   ip=0;
   break;
  }
 }
 return ip;
}
int main()
{
 int n,m,sum=0,t;
 scanf("%d%d",&n,&m);
 if(n>m)
 {
  t=n;
  n=m;
  m=t;
 }
 for(int i=n+1;i<m;i++)
 {
  if(is(i))sum=sum+i*i;
 }
 if(is(n))sum+=n*n;
    if(is(m))sum+=m*m;
 printf("%d\n",sum);
 return 0;
 }
