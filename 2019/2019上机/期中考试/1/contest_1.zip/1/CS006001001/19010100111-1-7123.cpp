#include<stdio.h>
#include<math.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,SED1,SED2,SED3,t;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	SED1=x1^2+y1^2;
	SED2=x2^2+y2^2;
	SED3=x3^2+y3^2;
	
	
	if(SED1=SED2=SED3)
	printf("yes\n");
	else
	printf("no\n");
	return 0;
}
