#include<stdio.h>
int main()
{

int i,a,b=0;
    scanf("%d",&a);
    for(i=a;i>1949;i--)
    {
        if((i%4==0&&i%100!=0)||i%400==0)
        {
printf("%d ",i);
        b++;
        if(b%5==0&&b!=0)
printf("\n");
    }}}
