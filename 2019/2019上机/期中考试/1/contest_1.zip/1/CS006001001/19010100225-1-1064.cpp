#include<stdio.h>
int max(int a,int b);
int min(int a,int b);
int main()
{
 int x1,y1,x2,y2,x3,y3,a,b,c,d,e,f,g;
 scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
 a=x1*x1+y1*y1;
 b=x2*x2+y2*y2;
 c=x3*x3+y3*y3;
if(a==b&&b==c)
  printf("yes %d %d",a,b);
else
 {  
	    d=max(a,b);
	    e=max(d,c);
	    f=min(a,b);
	    g=min(f,c);
printf("no %d %d",e,g);	    
 }
 return 0;
}
int max(int a,int b)
{   int t;
	if(a<b)
	 t=a;
     a=b;
	 b=t;
	 return(a);
}
int min(int a,int b)
{   int n;
    if(a<b)
	 n=a;
     a=b;
	 b=n;
	 return(b);
}
