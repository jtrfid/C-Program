#include<stdio.h>
int main(){
	int n,i;
	float sn=1.0;
	scanf("%d",&n);
	sn=n+1.0;
    printf("%.1f",sn);
	return 0;
}
