#include<stdio.h>
include<math.h>
int main()
{
	int i,n;
	long float a,Sn�� 
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		 a=(1+1/i);
		 Sn=a
    } 
	printf("%f\n",Sn);	
	return0;
}

