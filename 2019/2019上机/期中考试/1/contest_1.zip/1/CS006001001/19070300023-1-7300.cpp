#include<stdio.h>
int main()
{
	int x,y,a,b,m,n,h,i,j;
	scanf("%d %d %d %d %d %d",&x,&y,&a,&b,&m,&n);
	h=x*x+y*y;
	i=a*a+b*b;
	j=m*m+n*n;
	if(h==i&&j==h)
	    printf("yes ");
	else printf("no ");
	h=h>i?h:i;
	h=h>j?h:j;
	j=j<i?j:i;
	j=j<h?j:h;
	printf("%d %d",j,h);
	
}
