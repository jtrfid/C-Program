#include<stdio.h>
int main()
{
	int a,b,d=2,k,q,i,n=0;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{
		for(d=2;d<i;d++)
		{
			q=1;
			if(i%d==0) {
			q=0; break;}
		}
		if(q==1)
		{
		n=n+i*i;
		}
	
	
}
printf("%d",n);
}
