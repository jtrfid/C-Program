#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,g,h,i;
	scanf("%d %d %d %d %d %d",&a,&b,&c,&d,&e,&f);
	g=a*a+b*b;
	h=c*c+d*d;
	i=e*e+f*f;
	if(g==h&&h==i)
	printf("yes %d %d\n",g,g);
	if(g>h&&g>i&&h>i)
	printf("no %d %d\n",g,i);
	if(g>h&&g>i&&i>h)
	printf("no %d %d\n",g,h);
	if(h>g&&h>i&&i>g)
	printf("no %d %d\n",h,g);
	if(h>g&&h>i&&g>i)
	printf("no %d %d\n",h,i);
	if(i>h&&i>g&&h>g)
	printf("no %d %d\n",i,g);
	if(i>g&&i>h&&g>h)
	printf("no %d %d\n",i,h);
	if(i==g&&g>h)
	printf("no %d %d\n",h,g);
	if(i==g&&h>g)
	printf("no %d %d\n",g,h);
	if(i==h&&g>h)
	printf("no %d %d\n",h,g);
	if(i==h&&h>g)
	printf("no %d %d\n",g,h);
	if(g==h&&i>h)
	printf("no %d %d\n",h,i);
	if(g==h&&h>i)
	printf("no %d %d\n",i,h);
	return 0;
}
