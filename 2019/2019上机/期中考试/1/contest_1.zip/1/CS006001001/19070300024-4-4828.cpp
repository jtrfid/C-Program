#include<stdio.h>
int main()
{
	int i,n,j=0;
	scanf("%d",&n);
	for(i=n;1949<=i;i--)
	{
	
	if((i%100!=0&&i%4==0)||(i%400==0))
	{
	
	printf("%d ",i);
	j++;
	if(j%5==0)printf("\n");
}}
return 0;}
