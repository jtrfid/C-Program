#include<stdio.h>
int main()
{
	int y,n,a[n],i;
	scanf("%d",&y);
	n=(y-1949)/4;
	for(i=1;i<n;i++)
	{
		a[i]=1948+4*i;
	}
	for(i=1;i<(n-1);i++)
	{
		printf("%d",a[i]);
	}
	return 0;
}
