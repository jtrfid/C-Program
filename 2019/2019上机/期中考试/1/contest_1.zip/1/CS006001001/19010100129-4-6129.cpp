#include<stdio.h>
int main()
{
	int y,a,b,c,i,m;
	scanf("%d",&y);
	do
	{a=y%4;
	 b=y%100;
	 c=y%400;
	 if((a==0&&b!=0)||c==0)
	  printf("%d ",y);
	 y--;
    }
while(y>1950);
	
}
