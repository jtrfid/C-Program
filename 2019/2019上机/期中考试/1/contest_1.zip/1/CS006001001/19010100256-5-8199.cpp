#include <stdio.h> 
#include <math.h>
int zhishu(int n) 
{ 
    int k; 
    for(k=2;k<=sqrt(n);k++) 
	{ 
        if (n%k==0) return 0; 
    } 
    return 1; 
}   

int main()
 { 
    int n1,n2;
    scanf("%d %d",&n1,&n2);
	int sum = 0; 
    int i; 
    for (i=n1;i<=n2;i++) 
	{ 
        if (zhishu(i)) 
		{ 
            sum=sum+i*i;
        } 
    } 
    printf("%d",sum); 
    return 0; 
}
