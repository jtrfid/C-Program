#include <stdio.h>
int main ()
{
	int n,mon,d,i,ds;
	int m[12];
	scanf("%d %d %d",&n,&mon,&d);
	if ((n%4==0&&n%100!=0)||(n%400==0))
	m[1]=29;
	else
	m[1]=28;
	m[0]=31;m[2]=31;m[4]=31;m[6]=31;m[7]=31;m[9]=31;m[11]=31;
	m[3]=30;m[5]=30;m[10]=30;m[8]=30;
	ds=0;
	for (i=0;i<mon-1;i++)
	ds=ds+m[i];
	printf("%d",ds+d);
	return 0;
}
