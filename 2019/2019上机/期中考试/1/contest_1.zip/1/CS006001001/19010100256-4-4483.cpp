#include<stdio.h>
int main()
{
  int start = 1949;
  int end ;
  scanf("%d",&end);
  int i = 0;
  for(start=1949;start<=end;start++)
  {
   if((start%4 == 0) &&(start%100 != 0) || (start%400 == 0))
     {printf("%d ",start);
        if(i == 4)
          {i=0;printf("\n");}
	    else{i++;}}else{}
     }
return 0;
}
