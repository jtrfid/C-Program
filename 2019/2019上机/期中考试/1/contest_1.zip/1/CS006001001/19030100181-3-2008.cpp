#include<stdio.h>
int main()
{
	int n,i;
	float sum=1.0;
	scanf("%d",&n);
	for(i=1;i<n+1;i++)
	{
		sum*=(1+1/i);
	}
	printf("%.1f",sum);
	return 0;
}
