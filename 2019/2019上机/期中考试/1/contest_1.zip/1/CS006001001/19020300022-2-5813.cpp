#include <stdio.h>

int main()
{
    int i, days = 0;
    int year, month, day;
    int day_tab[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    scanf("%d %d %d", &year, &month, &day);
    for (i=1; i<month; i++)
    {
        days += day_tab[i];
    }
    days += day;
    if ((year%4==0 && year%100!=0 || year%400==0) && month>=3)
        days+=1;
    printf("%d",days);
    return 0;
}
