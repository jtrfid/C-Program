#include<stdio.h>
int zhishu(int a)
{
	int i;
	for(i=2;i<=a/2;i++)
	{
		if(a%i==0)
		return 0;
	}
	return 1;
}
int main()
{
	int a,b,i,sum=0;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{
		if(zhishu(i))
		sum=sum+i*i;
		else 
		sum=sum;
		
	}
	printf("%d",sum);
	return 0;
}
