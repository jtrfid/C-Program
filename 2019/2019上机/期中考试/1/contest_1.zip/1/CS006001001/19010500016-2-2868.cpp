#include<stdio.h>
int main( )
{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	if(b==1)
	{
	printf("%d",c);
}
	else if(b==2)
	{
		c=c+31;
		printf("%d",c);
	}
	else if(b%4==0)
	{
		if(b=3)
		{
		c=c+29+31;
	    printf("%d",c);}
	    else if(b==4)
	    {c=c+31+29+31;
	    printf("%d",c);
	    }
	    else if(b==5)
	    {c=c+31+29+31+30;
	    printf("%d",c);
	    }
	    else if(b==6)
	    {c=c+31+29+31+30+31;
	    printf("%d",c);
	    }
	    else if(b==7)
	    {c=c+31+29+31+30+31+30;
	    printf("%d",c);
	    }
	    else if(b==8)
        {c=c+31+29+31+30+31+30+31;
        printf("%d",c);
        }
        else if(b==9)
        {c=c+31+29+31+30+31+30+31+31;
        printf("%d",c);
        }
        else if(b==10)
        {c=c+31+29+31+30+31+30+31+31+30;
        printf("%d",c);
        }
        else if(b==11)
        {c=c+31+29+31+30+31+30+31+31+30+31;
        printf("%d",c);
        }
        else if(b==12)
        {c=c+31+29+31+30+31+30+31+31+30+31+30;
        printf("%d",c);
        }
	}
	else if(b%4!=0)
	{
		if(b=3)
		{
		c=c+28+31;
	    printf("%d",c);}
	    else if(b==4)
	    {c=c+31+28+31;
	    printf("%d",c);
	    }
	    else if(b==5)
	    {c=c+31+28+31+30;
	    printf("%d",c);
	    }
	    else if(b==6)
	    {c=c+31+28+31+30+31;
	    printf("%d",c);
	    }
	    else if(b==7)
	    {c=c+31+28+31+30+31+30;
	    printf("%d",c);
	    }
	    else if(b==8)
        {c=c+31+28+31+30+31+30+31;
        printf("%d",c);
        }
        else if(b==9)
        {c=c+31+28+31+30+31+30+31+31;
        printf("%d",c);
        }
        else if(b==10)
        {c=c+31+28+31+30+31+30+31+31+30;
        printf("%d",c);
        }
        else if(b==11)
        {c=c+31+28+31+30+31+30+31+31+30+31;
        printf("%d",c);
        }
        else if(b==12)
        {c=c+31+28+31+30+31+30+31+31+30+31+30;
        printf("%d",c);
        }
	}
return 0;
}

	
	
	

