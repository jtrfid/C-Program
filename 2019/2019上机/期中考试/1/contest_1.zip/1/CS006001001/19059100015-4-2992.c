#include<stdio.h>
int main()
{
	int y;
	scanf("%d",&y);
	int i=y,t=1;
	while(i>1949)
	{
		if(i%4==0&&i%100!=0||i%400==0)
		  {
		  	if(t==5)  printf("%d\n",i),t=1;
		  	else  printf("%d ",i),t++;
		  }
		i--;
	}
	return 0;
}
