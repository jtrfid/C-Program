#include<stdio.h>
int main()
{
	int a,b,c;
	int x,y;
	scanf("%d %d %d",&a,&b,&c);
	if((a&4==0&&a%100!=0)||a%400==0)
		x=29;
	else 
		x=28;
	switch(b)
	{
		case 1: y=0;break;
		case 2: y=31;break;
		case 3: y=31+x;break;
		case 4: y=2*31+x;break;
		case 5: y=2*31+30+x;break;
		case 6: y=3*31+30+x;break;
		case 7: y=3*31+2*30+x;break;
		case 8: y=4*31+2*30+x;break;
		case 9: y=5*31+2*30+x;break;
		case 10:y=5*31+3*30+x;break;
		case 11:y=6*31+3*30+x;break;
		case 12:y=6*31+4*30+x;break;
	}
	printf("%d",y+c);
	return 0;
	
}
