#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,i,x=0;
    scanf("%d %d %d",&a,&b,&c);
    for(i=1;i<b;i++)
    {
        if(i==1||i==3||i==5||i==7||i==8||i==10||1==12)
          x=x+31;
        if(i==4||i==6||i==9||i==11)
            x=x+30;
        if(i==2)
        {
            if((a%4==0&&a%100!=0)||a%400==0)
                x=x+29;
                else x=x+28;
        }
    }
    x=x+c;
    printf("%d",x);
    return 0;
}
