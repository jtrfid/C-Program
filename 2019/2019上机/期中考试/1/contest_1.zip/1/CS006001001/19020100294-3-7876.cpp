#include<stdio.h>
int main()
{
	int n;
	float s=1.0;
	scanf("%d",&n);
    s=s+n/1.0;
	printf(".1f",s);
	return 0;
}

