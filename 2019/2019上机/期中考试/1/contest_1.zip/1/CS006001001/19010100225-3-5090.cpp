#include<stdio.h>
int main()
{
	float n,i,sum;
	sum=1;
	scanf("%f",&n);
	for(i=1;i<=n;i++)
	  {
	  sum=sum*(i+1)/i;}
	printf("%.1f",sum);
	return 0;  
	  
	
}
