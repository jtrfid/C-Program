#include <stdio.h>
int main()
{
	int n,y,r,t,y2,d,p,o;
	scanf("%d %d %d",&n,&y,&r);
	t=n/4;p=n/10;o=n/400;
	if(t*4==n&&p*10!=n)
	y2=29;
	else if (400*o==n)
	y2=29;
	else
	y2=28;
	switch(y)
	{
		case 1:
			d=r;
			printf("%d",d);
			break;
					case 2:
			d=r+31;
			printf("%d",d);
			break;
					case 3:
			d=r+31+y2;
			printf("%d",d);
			break;
					case 4:
			d=r+31+y2+31;
			printf("%d",d);
			break;
					case 5:
			d=r+31+y2+31+30;
			printf("%d",d);
			break;
						case 6:
			d=r+31+y2+31+30+31;
			printf("%d",d);
			break;
						case 7:
			d=r+31+y2+31+30+31+30;
			printf("%d",d);
			break;
							case 8:
			d=r+31+y2+31+30+31+30+31;
			printf("%d",d);
			break;
			
								case 9:
			d=r+31+y2+31+30+31+30+31+31;
			printf("%d",d);
			break;
										case 10:
			d=r+31+y2+31+30+31+30+31+31+30;
			printf("%d",d);
			break;
											case 11:
			d=r+31+y2+31+30+31+30+31+31+30+31;
			printf("%d",d);
			break;
												case 12:
			d=r+31+y2+31+30+31+30+31+31+30+31+30;
			printf("%d",d);
			break;
			
	}
}
