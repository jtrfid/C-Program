#include <stdio.h>
int main ()
{
	float n;

	scanf("%f",&n);
	n=(n+1)*1.0;
	printf("%.1f",n);
	return 0;
}
