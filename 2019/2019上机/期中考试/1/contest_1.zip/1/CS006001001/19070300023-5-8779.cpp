#include<stdio.h>
int main()
{
	int x,y,i,j,s=0,max,min;
	scanf("%d %d",&x,&y);
	if(y>x)
	max=y;min=x;
	for(i=min;i<=max;i++)
	    for(j=2;j<i/2;j++)
	        {
	            if(i%j!=0)
	            {
	            s=s+i*i;
			    }
            }
	printf("%d",s);
	        
	    
}
