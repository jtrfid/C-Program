#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,t,y3,r1,r2,r3,i,j;
	int a[3];
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a[0]=x1*x1+y1*y1;
	a[1]=x2*x2+y2*y2;
	a[2]=x3*x3+y3*y3;
	if(a[0]==a[1]&&a[0]==a[2]&&a[1]==a[2])
	printf("yes ");
	else
	printf("no ");
	for(i=0;i<2;i++)
	for(j=0;j<2-i;j++)
	{
		if(a[j]>a[j+1])
		{
		t=a[j];
		a[j]=a[j+1];
		a[j+1]=t;
	}}
	printf("%d %d",a[0],a[2]);
	return 0;
}
