#include <stdio.h>
int main()
{
    int("a=%d\nb=%d\nc=%d\nd=%d\n");
	int("a=2000 b=1 c=3");
    int("d=b*31+c");
    printf("3");
	return 0;
}
