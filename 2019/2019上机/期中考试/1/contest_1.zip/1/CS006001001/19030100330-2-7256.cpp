#include<stdio.h>
int main()
{
	int a,b,c,sum;
	1<=b<=12;
	1<=c<=31;
	scanf("%d %d %d",&a,&b,&c);
	if(b==1){
		sum=c;
	}else if(b==2){
		sum=31+c;
	}else if(b==3){
		sum=31+28+c;
	}else if(b==4){
		sum=31*2+28+c;
	}else if(b==5){
		sum=31*2+28+30+c;
	}else if(b==6){
		sum=31*3+28+30+c;
	}else if(b==7){
		sum=31*3+28+30*2+c;
	}else if(b==8){
		sum=31*4+28+30*2+c;
	}else if(b==9){
		sum=31*5+28+30*2+c;
	}else if(b==10){
		sum=31*5+28+30*3+c;
	}else if(b==11){
		sum=31*6+28+30*3+c;
	}else if(b==12){
		sum=31*6+28+30*4+c;
	}else if(a%4==0&&a%100!=0)
		sum=sum+1;
	printf("%d",sum);
	return 0;
}
