#include<stdio.h>
int main()
{
	int s=1,x,n,i,j,a[n];
	scanf("%d",&x);
	for(i=0;i<x;i++)
	{
		a[i]=i+1;
	}
	for(i=0;i<x;i++)
	{
		s=s*(1+1/a[i]);
	}
	printf("%d",s);
	return 0;
}
