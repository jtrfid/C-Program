#include<stdio.h>
int main()
{
	int a;
	float sn;
	sn=1.0;
	scanf("%d",&a);
	while(a>=1)
      sn=sn*(1.0+1/a); 
	  a--; 
	printf("%.1f",sn);
	
	return 0;
}
