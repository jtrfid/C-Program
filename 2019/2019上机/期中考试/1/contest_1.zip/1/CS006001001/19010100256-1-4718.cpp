#include<stdio.h>
int main()
{
  int start = 1949;
  int end ;
  scanf("%d",&end);
  int i = 0;
  for(start=1949;start<=end;end--)
  {
   if((end%4 == 0) &&(end%100 != 0) || (end%400 == 0))
     {printf("%d ",end);
        if(i == 4)
          {i=0;printf("\n");}
	    else{i++;}}else{}
     }
return 0;
}

















