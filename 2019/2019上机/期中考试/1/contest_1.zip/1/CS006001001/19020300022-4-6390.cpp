#include<stdio.h>



void LearYear()

{

	int year,a,y;
    scanf("%d",&y);
    for(year=1949;year<=y;year++)

	{

	if((year%4==0&&year%100!=0)||(year%400==0)) a=1;

		else a=0;

		if(a==1)

		printf("%d",year);

	}



}

int main()

{	

   LearYear();

}


