#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,s1,s2,s3,max,min;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	s1=x1*x1+y1*y1;
	s2=x2*x2+y2*y2;
	s3=x3*x3+y3*y3;
	 if(s1>=s2&&s2>=s3)
	 max=s1;
	 min=s3;
	     if(s1>=s3&&s3>=s2)
	     max=s1;
	     min=s2;
	        if(s2>=s1&&s1>=s3)
	        max=s2;
	        min=s3;
	          if(s2>=s3&&s3>=s1)
	          max=s2;
	          min=s1;
	              if(s3>=s1&&s1>=s2)
	              max=s3;
	              min=s2;
	                 if(s3>=s2&&s2>=s1)
					  max=s3;
	                  min=s1;
	      if(x1*x1+y1*y1==x2*x2+y2*y2&&x1*x1+y1*y1==x3*x3+y3*y3)
           printf("yes  %d  %d",min,max);
               else
                printf("no  %d  %d",min,max);
	      return 0;
      
	      
	      
	
	
	
}
