#include<stdio.h>
int main()
{int year,month,day,n,m2;
scanf ("%d %d %d",&year,&month,&day);
if (year%4 == 0&&year%100 != 0){
	m2 = 29;
}else {
	m2 = 28;
};
if (month == 1)
	n = day;
else if (month == 2)	
	n = day + 31;
else if (month == 3)
	n = day + 31 + m2;
else if (month == 4)
	n = day + m2 +62;
else if (month == 5)
	n = day + m2 + 92;
else if (month == 6)
	n = day + m2 + 123;
else if (month == 7)
	n = day + 153 + m2;
else if (month == 8)
	n = day + 184 + m2;
else if (month == 9)
	n = day + 215 + m2;
else if (month == 10)
	n = day + 245 + m2;
else if (month == 11)
	n = day + 276 + m2;
else if (month == 12)
	n = day + 306 + m2;
printf ("%d",n);
return 0;
}
