#include<stdio.h>
int main(){

int a,b,c,i,m=0;
    scanf("%d %d %d",&a,&b,&c);
    for(i=1;i<b;i++)
    {
        if(i==2)
        {
            if((a%4==0&&a%100!=0)||a%400==0)
                m=m+29;
                else m=m+28;
        }
        if(i==4||i==6||i==9||i==11)
            m=m+30;
			if(i==1||i==3||i==5||i==7||i==8||i==10||1==12)
          m=m+31;
        
    }
    m=m+c;
    printf("%d",m);}
