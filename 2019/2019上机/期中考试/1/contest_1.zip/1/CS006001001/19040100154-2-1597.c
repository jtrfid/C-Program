#include <stdio.h>
#include <stdlib.h>

int main()
{
    int y,m,d,n,e;
    scanf("%d %d %d",&y,&m,&d);
    if(y%4==0&&y%100!=0||y%400==0)
        e=29;
    else
        e=28;
    if(m==1)
    {
        n=d;
    printf("%d\n",n);
    }
    if(m==2)
    {
    n=31+d;
        printf("%d\n",n);
    }
    if(m==3)
    {
        n=31+e+d;
        printf("%d\n",n);
    }
    if(m==4)
    {
        n=31+e+31+d;
        printf("%d\n",n);
    }
    if(m==5)
    {
        n=31+e+31+30+d;
    printf("%d\n",n);
    }
    if(m==6)
    {
        n=31+e+31+30+31+d;
    }
    if(m==7)
    {
        n=31+e+31+30+31+30+d;
        printf("%d\n",n);
    }
    if(m==8)
    {
        n=31+e+31+30+31+30+31+d;
        printf("%d\n",n);
    }
    if(m==9)
    {
        n=31+e+31+30+31+30+31+31+d;
         printf("%d\n",n);
    }
        if(m==10)
        {
            n=31+e+31+30+31+30+31+31+30+d;
             printf("%d\n",n);
        }
        if(m==11)
        {
            n=31+e+31+30+31+30+31+31+30+31+d;
             printf("%d\n",n);
        }
        if(m==12)
        {
            n=31+e+31+30+31+30+31+31+30+31+30+d;
             printf("%d\n",n);
        }
    return 0;
}
