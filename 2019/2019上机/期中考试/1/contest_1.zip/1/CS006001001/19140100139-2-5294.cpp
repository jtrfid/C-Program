#include <stdio.h>
int main()
{
	int a,b,c,n,sum1,sum2;
	scanf("%d %d %d",&a,&b,&c);
	n=b/2;
	if (a%4==0)
	{
		if(b<=2)
		{
			sum1=n*31;
		}
		else if(b<=7||b>2)
		{
			sum1=n*61-1;
		}
		else if(b>8||b%2==0)
		{
			sum1=n*61-31;
		}
		else if(b>8||b%2>0)
		{
			sum1=n*61;
		}
	}
		if (a%4>0)
	{
		if(b<=2)
		{
			sum1=n*31;
		}
		else if(b<=7||b>2)
		{
			sum1=n*61-2;
		}
		else if(b>8||b%2==0)
		{
			sum1=n*61-32;
		}
		else if(b>8||b%2>0)
		{
			sum1=n*61-1;
		}
	}
	sum2=sum1+c;
	printf("%d",sum1);
	return 0;
}
