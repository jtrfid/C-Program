#include<stdio.h>
int main()
{
	int a,b,c,d[13],i,sum,s;
	scanf("%d %d %d",&a,&b,&c);
	d[0]=0;
	d[1]=d[3]=d[5]=d[7]=d[8]=d[10]=d[12]=31;
	d[4]=d[6]=d[9]=d[11]=30;
    d[2]=28;
	for(i=1;i<b;i++)
	{
		sum=d[i]+sum;
	}
	s=sum+c-50;
	printf("%d",s);
	return 0;
	
}
