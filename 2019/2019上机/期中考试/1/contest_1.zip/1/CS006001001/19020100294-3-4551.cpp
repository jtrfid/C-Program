#include<stdio.h>
int main()
{
	int n;
	float s;
	scanf("%d",&n);
	s=n/1.0+1.0;
	printf(".1f",s);
	return 0;
}

