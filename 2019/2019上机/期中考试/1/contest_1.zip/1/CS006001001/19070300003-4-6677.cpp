#include<stdio.h>
int main()
{
	int y,i,j=0;
	scanf("%d",&y);
	for(i=y;i>=1949;i--)
	{
		if(i%4==0&&i%100!=0)
		{
			j=j+1;
			if(j%5==0)
			printf("%d\n",i);
			else
			printf("%d ",i);
		}
		else if(i%400==0)
		{
			j=j+1;
			if(j%5==0)
			printf("%d\n",i);
			else
			printf("%d ",i);
		}
		
	}
}
