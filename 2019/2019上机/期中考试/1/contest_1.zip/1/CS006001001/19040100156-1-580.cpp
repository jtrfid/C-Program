#include <stdio.h>
int main()
{
	printf("x1=%d\ny1=%d\nx2=%d\ny2=%d\nx3=%d\ny3=%d\n");
	printf("sed=x1*x1+y1*y1");
	printf("sed=x2*x2+y2*y2");
	printf("sed=x3*x3+y3*y3");
	printf("x*x+y*y=r*r");
	return 0;
}
