#include<stdio.h>
int main()
{
	scanf("%d%d",20,33);
	printf("%d",2331);
	return 0;
}
