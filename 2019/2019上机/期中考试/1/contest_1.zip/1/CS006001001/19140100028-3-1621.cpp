#include <stdio.h>
int main()
{int n;
float s,i;
s=1;
scanf("%d",&n);
for(i=1;i<n+1;i++)
{s=(1+1/i)*s;}
printf("%.1f",s);
}


