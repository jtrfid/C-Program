#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3;
	int m1,m2,m3,m,M;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	m1=x1*x1+y1*y1;
	m2=x2*x2+y2*y2;
	m3=x3*x3+y3*y3;
	if(m1-m2>=0&&m2-m3>=0)
	{
	 m=m3;
	 M=m1;
    } 
	else if(m1-m2>=0&&m2-m3<=0&&m1-m3>=0)
	{
	 m=m2;
	 M=m1;
	}
	else if(m1-m2>=0&&m2-m3<=0&&m1-m3<=0)
	{
	 m=m2;
	 M=m3;
	}
	else if(m1-m2<=0&&m2-m3<=0)
	{
	 m=m1;
	 M=m3;
	}
	else if(m1-m2<=0&&m2-m3>=0&&m1-m3<=0)
	{
	 m=m1;
	 M=m2;
	}
	else if(m1-m2<=0&&m2-m3>=0&&m1-m3>=0)
	{
	 m=m3;
	 M=m2;
	}
	if(m1==m2&&m1==m3&&m2==m3)
	printf("yes %d %d",m,M);
	else
	printf("no %d %d",m,M);
}
