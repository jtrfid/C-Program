#include<stdio.h>
int main()
{
		int year = 0, month = 0, day = 0, leap = 0, dayth = 0;
		
		scanf("%d %d %d",&year,&month,&day);
		
		
		if(month > 12 || month < 1)
		{
			printf("year out of limit\n");
		}
		if(day > 31 || day < 1)
		{
			printf(" month out of limit\n");
		}
		if(year%4 == 0 && year%100 != 0 || year%400 ==0)
		{
			leap = 29;
		}
		else
		{
			leap = 28;
		}
		month = month - 1;
		switch(month)
		{
			case 11 : dayth += 30;
			case 10 : dayth += 31;
			case  9 : dayth += 30;
			case  8 : dayth += 31;
			case  7 : dayth += 31;
			case  6 : dayth += 30;
			case  5 : dayth += 31;
			case  4 : dayth += 30;
			case  3 : dayth += 31;
			case  2 : dayth += leap;
			case  1 : dayth += 31;
		}
		dayth += day;
		printf("%d",dayth,year);
		return 0;
} 
