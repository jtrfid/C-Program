#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x1,y1,x2,y2,x3,y3,o1,o2,o3;
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    o1=x1*x1+y1*y1;
    o2=x2*x2+y2*y2;
    o3=x3*x3+y3*y3;
    if(o1==o2&&o2==o3)
        printf("yes %d %d\n",o1,o1);
    int i,j,a[10]={o1,o2,o3},temp;
        for(i=0;i<3;i++)
            for(j=0;j<2-i;j++)
            if(a[j]>a[j+1])
        {
            temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
        }
    if(o1!=o2||o1!=o3||o2!=o3)
        printf("no %d %d\n",a[0],a[2]);
    return 0;
}
