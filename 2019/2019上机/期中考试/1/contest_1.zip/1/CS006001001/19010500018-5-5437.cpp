#include<stdio.h>

int main()
{
int x,y,i,s,b;
scanf("%d %d",&x,&y);
for	(i=x;i<=y;i++)
{
	for(b=2;b<=i;b++)
	{
		if (i%b!=0)
		{
		s=0;
		s=s+i*i;
     	}
	}
}	
	printf("%d",s);
	return 0;
}
