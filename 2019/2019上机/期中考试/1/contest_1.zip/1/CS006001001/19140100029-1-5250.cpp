#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,a,b,c,SED1,SED2,SED3;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a=x1*x1+y1*y1;
	b=x2*x2+y2*y2;
	c=x3*x3+y3*y3;
	if(a==b&&a==c)
	{
		printf("yes");
	}
	if(a!=b)
	{
		printf("no");
	}
	SED1=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
	SED2=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);
	SED3=(x3-x2)*(x3-x2)+(y3-y2)*(y3-y2);
	{
		if(SED1<=SED2&&SED1<=SED3)
		printf("%d",SED1);
		if(SED2<=SED1&&SED2<=SED3)
		printf("%d",SED2);
		if(SED3<=SED1&&SED3<=SED2)
		printf("%d",SED3);
	}
	return 0;
	
	
}
