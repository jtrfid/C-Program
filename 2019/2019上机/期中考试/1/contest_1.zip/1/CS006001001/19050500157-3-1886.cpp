#include<stdio.h>
int main()
{
	int n,k,sn;
	scanf("%d",n);
	n>=1&&n<=1000;
	k=1;k=n;n++;
	sn=1+1/k;
	printf("%f\n",sn);
	return 0;
}
