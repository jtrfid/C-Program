#include<stdio.h>
int main()
{
	int a,b,c,n,i,j,p;
	scanf("%d %d",&a,&b);
	n=0;
	p=0;
	for(i=a;i<=b;i++)
	{
		for(j=2;j<i;j++)
		{
			c=i%j;
			if(c==0&&c!=2) break;
			else
			n=n+i*i;
				
			
			
		}
	
	}
	printf("%d",n);
	return 0;
}
