#include<stdio.h>
int main()
{
	int i, n;
	double s,s0;
	scanf("%d",&n);
	s0=2.0;
	for(i=2;i<=n;i++)
	{
		
		s=s0*(1+1/double(i));
		s0=s;
		}
	printf("%.1f",s);
	return 0;
}
