#include<stdio.h>
int main()
{
	int x,y,d,f,h,j=0;
	scanf("%d %d",&x,&y);
	x=(x>y)?y:x;
	y=(x>y)?x:y;
	if(x==y)
	{
	for(f=2;f<x;f++)
	      {
	      if(x%f==0)
		  {
		  	h=0;
		  	break;
	      }
	      else h=1;
	}
	if(h==1)
	{
	x=x*x*2;	
	printf("%d",x);
    }
	}
	else{
	for(d=x;d<=y;d++)
	  {
	   for(f=2;f<d;f++)
	      {
	      if(d%f==0)
		  {
		  	h=0;
		  	break;
	      }
	      else h=1;
	      }
	   if(h!=0)
	   j=j+d*d; 
	   }
	printf("%d",j);}
	return 0;
}
