int a,b,c,x,y,z,m,n,o,h,g;
   scanf("%d %d %d %d %d %d",&a,&x,&b,&y,&c,&z);
   m=a*a+x*x;
   n=b*b+y*y;
   o=c*c+z*z;
   if(m==n&&m==o)
    printf("yes ");
   else printf("no ");
   h=m>n?m:n;
   h=h>o?h:o;
   g=m<n?m:n;
   g=g<o?g:o;
   printf("%d %d",g,h); 
