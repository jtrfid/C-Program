#include <stdio.h>
int zzz(int m)
{
	int i,q;
	for(i=2;i<m;i++)
	{
		if(m%i==0)
		{
			q=1;
			break;
		}
		else
		q=0;
	}
	if(m==2)
	q=0;
	return q;
}
int main ()
{
	int x,y,k,sum;
	scanf("%d %d",&x,&y);
	printf("\n");
	for(k=x,sum=0;k<y+1;k++)
	{
		if (zzz(k)==0)
		sum=sum+k*k;
	}
	printf("%d",sum);
	return 0;
}
