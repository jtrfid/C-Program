#include<stdio.h>
int main(){
	int n,i,sn=1;
	scanf("%d",&n);
	sn=n+1;
    printf("%d",sn);
	return 0;
}
