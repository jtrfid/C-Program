#include<stdio.h>
int main()
   {
   	int x1,x2,x3,y1,y2,y3,a,b,c,d,e,f,m,n,p,t,i,j,q[3],g,h,k,l,r,s;
   	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
   	if(x1<0)
   	  a=-x1;else a=x1;
   	if(y1<0)
   	  b=-y1;else b=y1;
   	if(x2<0)
   	  c=-x2;else c=x2;
   	if(y2<0)
   	  d=-y2;else d=y2;
   	if(x3<0)
   	  e=-x3;else e=x3;
   	if(y3<0)
   	  f=-y3;else f=y3;
   	m=a*a+b*b;
   	n=c*c+d*d;
   	p=e*e+f*f;
   	if(m==n&&m==p&&n==p)
   	  {
   	  	printf("yes ");
   	  }
   	  else printf("no ");
   	q[0]=a*a+b*b;
   	q[1]=c*c+d*d;
   	q[2]=e*e+f*f;
   	for(j=0;j<2;j++)
   	  for(i=0;i<2-j;i++)
   	     {
   	     	if(q[i]>q[i+1])
   	     	  {
   	     	  	t=q[i];
   	     	  	q[i]=q[i+1];
   	     	  	q[i+1]=t;
   	     	  }
   	     }
   	printf("%d %d",q[0],q[2]);
   	return 0;
   }
