
#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int x,y,i,j,pan,sum=0;
	scanf("%d %d",&x,&y);
	for(;x<=y;x++)
	{sum=sum+han (x);
	}
printf("%d",sum);
return 0;
}
int han(int a)
{	
int q,i;
for(i=2;i<a;i++)
	{if(a%i!=0)
	q=1;
	else q=0
		
	;}
if(q=1)return(a*a);
else	return 0;

}	












