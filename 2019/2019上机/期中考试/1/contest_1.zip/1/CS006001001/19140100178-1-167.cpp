#include<stdio.h>
int main()
{
	int z,x,c,v,b,n,a,s,d,f,g;
	scanf("%d %d %d %d %d %d",&z,&x,&c,&v,&b,&n);
	a=z*z+x*x;
	s=c*c+v*v;
	d=b*b+n*n;
	f=(a>s)?a:s;
	f=(f>d)?f:d;
	g=(a>s)?s:a;
	g=(g>d)?d:g;
	if((x*x+z*z==c*c+v*v)&&(x*x+z*z==b*b+n*n))
	  printf("yes %d %d",g,f);
	else printf("no %d %d",g,f);
	return 0;
}
