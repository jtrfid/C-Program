#include<stdio.h>
#include<math.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,SED,max,min;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	SED=x1^2+y1^2;
	SED=x2^2+y2^2;
	SED=x3^2+y3^2;
	if(SED=SED=SED)
	printf("yes");
	else
	printf("no");
		max==(SED,SED,SED);
		min==(SED,SED,SED);
	printf("%d %d",min,max);
	return 0;
}
