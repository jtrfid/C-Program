#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	printf("%.1f",a+1.0);
	return 0;
}
