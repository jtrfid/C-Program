#include<stdio.h>
int main()
{
	int y,i,j,a[100];
	scanf("%d",&y);
	for(i=y;i>1949;i--)
	if(i%4==0)
	{	
	    printf("%13d",i);
    }
	return 0;
}
