#include<stdio.h>
int main()
{
	int n,i;
	double sn=1.0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	sn=sn*((i+1.0)/i);
	printf("%.1lf",sn);
	return 0;
}
