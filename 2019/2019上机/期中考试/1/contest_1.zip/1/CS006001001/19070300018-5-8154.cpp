#include<stdio.h>
int main()
{
	int x,y,down,up,sum=0,i,j;
	scanf("%d %d",&x,&y);
	down=x<y?x:y;
	up=x>y?x:y;
	for(i=down;i<=up;i++)
	
	 {
	  for(j=2;j<i;j++)
	  
	  {
	   if(i%j!=0)continue;
	   
	  }; 
	   sum=sum+i*i;}
	  
	
	printf("%d",sum);
	
	return 0;
}
