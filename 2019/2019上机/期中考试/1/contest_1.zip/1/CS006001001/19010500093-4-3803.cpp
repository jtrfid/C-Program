#include<stdio.h>
int main()
   {
   	int y,m,n,i,j,a[100];
   	i=0;
   	scanf("%d",&y);
   	m=1950;
   	for(;m<=y;m++)
   	   {
   	   	if((m%4==0&&m%100!=0)||m%400==0)
   	   	  {
   	   	  	a[i]=m;
   	   	  	i++;
   	   	  }
   	   }
   	n=i;j=1;
   	for(i=n-1;i>=0;i--)
   	   {
   	   	if((j)%5==0)
   	   	  {
   	   	  	printf("%d\n",a[i]);
   	   	  }
   	   	  else printf("%d ",a[i]);
   	   	  j++;
   	   }
   	return 0;
   }
