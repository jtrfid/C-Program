#include<stdio.h>
int main()
{
	int a,b,i,p=0;
	scanf("%d",&a);
	for(i=a;i>=1949;i--)
	{
		if((i%4)==0)
		{
			printf("%d ",i);p++;
		}
		if(p%5==0)
		printf("\n");
	}
}
