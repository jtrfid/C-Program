#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j,b,c,x,y,z=0;
    scanf("%d %d",&b,&c);
    x=b<c?b:c;
    y=b>c?b:c;
    for(i=x;i<=y;i++)
    {int a=0;
        for(j=2;j<i;j++)
        {
            if(i%j==0)
                a=1;
        }
        if(a==0)
       z=z+i*i;
    }
    printf("%d",z);
    return 0;
}
