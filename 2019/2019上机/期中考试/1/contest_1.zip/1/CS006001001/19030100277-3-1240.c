#include<stdio.h>
int main()
{
	int i, n;
	float s = 1.0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
		s *= (1.0 + 1.0/(float)i);
	printf("%.1lf", s);
	return 0;
}


