#include <stdio.h>
#include <stdlib.h>

int main()
{
    double s=1,k=1;
    int n,i=1;
    scanf("%d",&n);
   while(i<=n)
   {
       s=s*(1+(1.0/k));
      i++;
      k++;
   }
     printf("%.1f\n",s);
    return 0;
}
