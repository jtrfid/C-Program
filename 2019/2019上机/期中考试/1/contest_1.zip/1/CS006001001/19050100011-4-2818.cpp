#include <stdio.h>
int main()
{
 int n,cnt=0;
 scanf("%d",&n);
 for(int i=n;i>=1949;i--)
 {
  if(i%4==0)
  {
   printf("%d",i);
   cnt++;
   if(cnt%5!=0)printf(" ");
   else printf("\n");
  }
 }
 return 0;
 }
