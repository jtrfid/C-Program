#include<stdio.h>
int main()
{
	int y,i,n;
	n=0;
	scanf("%d",&y);
	for(i=1949;i<=y;i++)
{ if(i%4==0&&i%400!=0)
    printf("%d ",i);
    
}
 return 0;
}
