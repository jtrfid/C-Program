#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,max,min,a,b,c;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a=x1*x1+y1*y1;
	b=x2*x2+y2*y2;
	c=x3*x3+y3*y3;
	if(a>b||a>c)
	max=a;
	else if(b>a||b>c)
	max=b;
	else if(c>a||c>b)
	max=c;
	if(a<b||a<c)
	min=a;
	else if(b<a||b<c)
	min=b;
	else if(c<a||c<b)
	min=c;
	else if(a==b||b==c)
	{
	max=a;
	min=b;
    }
	if(x1*x1+y1*y1==x2*x2+y2*y2==x3*x3+y3*y3)
	printf("yes %d %d",x1*x1+y1*y1,x1*x1+y1*y1);
	else printf("no %d %d",min,max);
	return 0;
}
