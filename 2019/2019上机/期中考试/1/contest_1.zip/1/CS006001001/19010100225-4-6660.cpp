#include<stdio.h>
int main()
{
	int y,i,t;
	t=0;
	scanf("%d",&y);
	for(i=1949;i<=y;i++)
{   if(i%4==0&&i%400!=0)
     {
      t=t+1;
      if(t%5==0)
      printf("%d\n",i);
      else
      printf("%d ",i);
     
      }
}
 return 0;
}
