#include<stdio.h>
int main()
{
	int x1,x2,x3,y1,y2,y3,a,b,c,t;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a=x1*x1+y1*y1;
	b=x2*x2+y2*y2;
	c=x3*x3+y3*y3;
	if(a==b&&b==c)
	printf("yes ");
	else
	printf("no ");
	if(a<b)
	{
		t=a;
		a=b;
		b=t;
	}
	else if(a<c)
	{
		t=a;
		a=c;
		c=t;
	}
	else if(b<c)
	{
		t=b;b=c;
		c=t;
	}
	printf("%d %d",c,a);
	return 0;
	
}
