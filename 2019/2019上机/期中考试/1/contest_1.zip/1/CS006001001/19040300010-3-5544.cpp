#include<stdio.h>
int main()
{int i,n;
float Sn;
scanf("%d",&n);

Sn=(1+1.0/(n-2))*(1+1.0/(n-1))*(1+1.0/n);



printf("%.1f",Sn);
return 0;
}
