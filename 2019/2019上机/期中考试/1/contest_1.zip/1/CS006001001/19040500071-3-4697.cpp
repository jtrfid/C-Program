#include<stdio.h>
int main()
{
	double x,t;
	scanf("%lf",&x);
	t=x+1;
	printf("%.1f\n",t);
	return 0;
}
