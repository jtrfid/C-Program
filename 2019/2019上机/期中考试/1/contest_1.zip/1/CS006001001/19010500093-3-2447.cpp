#include<stdio.h>
int main()
   {
   	int n,i;
   	float m,a[1000],Sn;
   	m=1;Sn=1;
   	scanf("%d",&n);
   	for(i=0;i<n;i++)
   	    {
   	    	a[i]=1+1/m;
   	    	m+=1;
   	    }
   	for(i=0;i<n;i++)
   	   {
   	   	Sn=Sn*a[i];
   	   }
   	printf("%.1f",Sn);
   	return 0;
   }
