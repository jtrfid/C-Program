#include<stdio.h>
int fun(int x1,int y1,int x2,int y2,int x3,int y3);
int main()
{
	int t,x1,y1,x2,y2,x3,y3,r1,r2,r3;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	t=fun(x1,y1,x2,y2,x3,y3);
	if(t)printf("yes ");
	else printf("no ");
	 r1=x1*x1+y1*y1;r2=x2*x2+y2*y2;r3=x3*x3+y3*y3;
	 if(r1<r2){t=r1;r1=r2;r2=t;}
	 if(r1<r3){t=r1;r1=r3;r3=t;}
	 if(r2<r3){t=r2;r2=r3;r3=t;}
	 printf("%d %d",r3,r1);
}

int fun(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int i,j,r1,r2,r3;
	 for(i=-100;i<=100;i++)
	 for(j=-100;j<=100;j++)
	 {
	 	r1=(x1-i)*(x1-i)+(y1-j)*(y1-j);
	 	r2=(x2-i)*(x2-i)+(y2-j)*(y2-j);
	 	r3=(x3-i)*(x3-i)+(y3-j)*(y3-j);
	 	if(r1==r2&&r2==r3) return 1;
	 }
	 return 0;
}
