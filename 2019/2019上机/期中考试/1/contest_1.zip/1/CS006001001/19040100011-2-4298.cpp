#include <stdio.h>
int main()
{int a,b,c,i,m,n;
int k[12]={31,28,31,30,31,30,31,31,30,31,30,31}

scanf("%d %d %d",&a,&b,&c);
if(b=1)
printf("%d",c)
else 
{for(i=0;i<b-1;i++)
m=k[0]+k[i];
n=m+c;
printf("%d",n);
}
return 0;
}
