#include<stdio.h>
int main()
{
	int x,y,i,j,end=0,zhi;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		zhi=1;
		if(i==1)
		    zhi=0;
		if(i==2)
		    zhi=1;
		for(j=2;j<=i/4;j++)
		{
			if(i%j==0)
			{
				zhi=0;
				break;
			}
		}
		if(zhi==1)
		{
			end=end+i*i;
			printf("%d ",i);
		}
	}
	printf("\n%d",end);
	getchar();
	return 0;
}
