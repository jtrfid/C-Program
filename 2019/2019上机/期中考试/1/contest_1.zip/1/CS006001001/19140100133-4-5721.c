#include<stdio.h>
void main()
{int count,year;
scanf ("%d",&year);
while(year >= 1949 ){
	if((year % 4 == 0 && year % 100 != 0)||year % 400 ==0){
		printf ("%d ",year);
}
year --;
}
}
