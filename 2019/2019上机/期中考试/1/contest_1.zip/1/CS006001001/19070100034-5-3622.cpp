#include<stdio.h>
int main()
{
	int i,j,a[1001];
	a[2]=1;
	for(i=3;i<=1000;i++)
	{
		a[i]=1;
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
				a[i]=0;
				break;
			}
		}
	}
	int x,y,end=0;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		if(a[i]==1)
		{
			end=end+i*i;
		}
	}
	printf("\n%d",end);
	getchar();
	return 0;
}
