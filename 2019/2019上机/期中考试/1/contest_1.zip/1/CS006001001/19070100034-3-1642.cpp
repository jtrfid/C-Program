#include<stdio.h>
int main()
{
	int n;
	float end;
	scanf("%d",&n);
	end=float(n)+1;
	printf("%.1f",end);
	getchar();
	return 0;
}
