#include<stdio.h>
int main()
{

	int a,b,c,d,n,i;
	scanf("%d",&a);
	c=0;
	n=50;
	int t[n];
	t[0]=0;
	t[1]=0;
	t[2]=0;
	t[3]=0;
	t[4]=0;
	t[5]=0;
	t[6]=0;
	t[7]=0;
	t[8]=0;
	t[9]=0;
	t[10]=0;
	t[11]=0;
	t[12]=0;
	t[13]=0;
	t[14]=0;
	t[15]=0;
	t[16]=0;
	t[17]=0;
	t[18]=0;
	for(i=a;i>1949;i--)
	{
		if((i%400==0)||(i%4==0&&i%100!=0))
		{
			t[c]=i;
			c++;
		}
	}
	for(i=0;t[i]!=0;i++)
	{
		printf("%d ",t[i]);
		if(i%5==4)
		printf("\n");
	}
	return 0;

}
	

