#include<stdio.h>
int main()
{
	int n;
	float s;
	scanf("%d",&n);
	s=n+1;
 printf("%.1f",s);
}
