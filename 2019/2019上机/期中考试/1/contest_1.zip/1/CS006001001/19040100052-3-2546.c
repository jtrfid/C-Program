#include<stdio.h>
int main()
{
	int a,b;
	float c,d;
	scanf("%d",&a);
	d=1.0;
	for(b=1;b<a+1;b++)
	{
		c=(1+(1/b));
		d=d*c;
	}
	printf("%.1f",d);
	return 0;
}
