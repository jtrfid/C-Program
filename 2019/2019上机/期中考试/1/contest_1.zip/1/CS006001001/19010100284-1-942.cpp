#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c,d,e,f,x,y,z;
	int max1,max2,min1,min2;
	scanf("%d %d %d %d %d %d",&a,&b,&c,&d,&e,&f);
	x=sqrt(a*a+b*b);
	y=sqrt(d*d+c*c);
	z=sqrt(e*e+f*f);
	if(x!=y||x!=z||z!=y)
	{
	max1=x>y?x:y;
	max2=z>max1?z:max1;
	min1=x<y?x:y;
	min2=z<min1?z:min1;
	printf("no %d %d",min2,max2);
}
    else{
	printf("yes %d %d",x,y); 
}
	
	return 0;
}
