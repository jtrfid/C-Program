#include<stdio.h>
int sushu(int a)
{
long	int b,c,d,e,i;
	if(a==1)
	return (0);
	for(i=2;i<a/2+1;i++)
	{
		if(a%i==0)
		return (0);
	}
	return (1);
	
}
int main()
{
long	int a,b,c,i,sum;
	scanf("%d %d",&a,&b);
	sum=0;
	if(((a-b)>10||(b-a)>10)&&a>=20&&a<=1000&&b>=20&&b<=1000)
	{
	
	for(i=a;i<=b;i++)
	{
		if(sushu(i))
		sum=sum+i*i;
		
	}
	printf("%d",sum);
}
	return 0;
}
