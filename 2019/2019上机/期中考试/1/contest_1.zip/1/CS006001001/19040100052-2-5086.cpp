#include<stdio.h>
int main()
{int a,b,c,yue ,sum=0,i;
scanf("%d %d %d",&a,&b,&c);
if(a%4==0&&a%400>0) yue=29;
else if(a%400==0)yue=29
;else  yue=28;int 
H[14]={0,31,0,31,30,31,30,31,31,30,31,30,31,};
H[3]=yue;
for(i=0;i<b+1;i++)sum+=H[i];
sum+=c;
printf("%d",sum);
	
}
