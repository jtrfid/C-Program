#include<stdio.h>
int main ()
{
	int n,i,j;
	j=0;
	scanf("%d",&n);
	for(i=n;i>=1949;i--)
		if((i%4==0&&i%100!=0)||i%400==0)
		{
			printf ("%d ",i);
			j++;
			if(j%5==0)
			printf ("\n");
		}
	return 0;
}
