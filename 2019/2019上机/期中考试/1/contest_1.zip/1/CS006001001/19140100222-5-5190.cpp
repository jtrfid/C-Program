#include<stdio.h>
int main()
{
	int a,b,d=2,k,i,q=1,n=0;
	scanf("%d %d",&a,&b);
	for (i=a;i<=b;i++)
	{
		while(d<i)
		{
			if(i%d==0)
			{
			q=0;	break;
			}
			d++;
		}
	if(q==1)
	{
	n=n+i*i;}
	}
	printf("%d",n);
}
