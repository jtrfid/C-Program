#include<stdio.h>
int n(int s);
int main()
{
	int x, y, i, temp, sum = 0;
	scanf("%d%d", &x, &y);
	if (x > y) {
		temp = x;
		x = y;
		y = temp;
	}
	for (i = x;i <= y; i++)
		if (!n(i)) sum += i * i; 
	printf("%d", sum);
	return 0;
}
int n(int s)
{
	int i, j = 0;
	for (i = 2; i < s; i++)
		if (s % i == 0) j+= 1;
	return j;
}
