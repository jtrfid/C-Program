#include<stdio.h>
int main()
{
	int a,b,n,i;
	float s=2.0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		s=s*(1+1/i);
	}
	printf("%.1f",s);
}
