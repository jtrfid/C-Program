#include<stdio.h>

int main()
{
   int a,b,c,t;
   scanf("%d %d %d",&a,&b,&c);
	if (a%400==0||(a%4==0&&a%100!=0))
		{if (b==1)
		{
		t=c;
		printf("%d",t);
	}
		if (b==2)
		{
		t=31+c;
			printf("%d",t);}
		if (b==3)
		{
		
		t=60+c;
			printf("%d",t);}
		if(b==4)
		{
		
		t=91+c;
			printf("%d",t);}
		if(b==5)
		{
		t=121+c;
			printf("%d",t);}
		if (b==6)
		{
		t=152+c;
			printf("%d",t);}
		if(b==7)
		{
		t=182+c;
			printf("%d",t);}
		if (b==8)
		{
		t=213+c;
			printf("%d",t);}
		if (b==9)
		{
		t=244+c;	
		printf("%d",t);}
		if(b==10)
		{ 
		t=274+c;
			printf("%d",t);} 
		if (b==11)
		{ 
		t=305+c;
			printf("%d",t);}
		if (b==12)
		{
		t=335+c;
			printf("%d",t);}
	
}
	   else
			{if (b==1)
		{
		t=c;
		printf("%d",t);
	}
		if (b==2)
		{
		t=31+c;
			printf("%d",t);}
		if (b==3)
		{
		
		t=59+c;
			printf("%d",t);}
		if(b==4)
		{
		
		t=90+c;
			printf("%d",t);}
		if(b==5)
		{
		t=120+c;
			printf("%d",t);}
		if (b==6)
		{
		t=151+c;
			printf("%d",t);}
		if(b==7)
		{
		t=181+c;
			printf("%d",t);}
		if (b==8)
		{
		t=212+c;
			printf("%d",t);}
		if (b==9)
		{
		t=243+c;	
		printf("%d",t);}
		if(b==10)
		{ 
		t=273+c;
			printf("%d",t);} 
		if (b==11)
		{ 
		t=304+c;
			printf("%d",t);}
		if (b==12)
		{
		t=334+c;
			printf("%d",t);}
	}

	return 0;
}
