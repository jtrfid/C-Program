#include <stdio.h> 
#include <math.h>
int zhishu(int n) 
{ 
    int k; 
    if(n%2==0) 
	return 0; 
    for(k=3;k<=sqrt(n);k++) 
	{ 
        if (n%k==0) return 0; 
    } 
    return 1; 
}   

int main()
 { 
    int n1,n2;
    scanf("%d %d",&n1,&n2);
	int sum = 0; 
    int i; 
    for (i=n1;i<=n2;i++) 
	{ 
        if (zhishu(i)) 
		{ 
            sum=sum+i*i;
        } 
    } 
    printf("%d\n",sum); 
    return 0; 
}
