#include <stdio.h> 
int isprime(int n) 
{ 
    int i; 
    if (n==2 || n==3) return 1; 
    if (n%2==0) return 0; 
    for (i=3;i<=n/2;i+=2) 
	{ 
        if (n%i==0) return 0; 
    } 
    return 1; 
}   

int main()
 { 
    int n1,n2;
    scanf("%d %d",&n1,&n2);
	int sum = 0; 
    int i; 
    for (i=n1;i<=n2;i++) 
	{ 
        if (isprime(i)) 
		{ 
            sum +=i*i;
        } 
    } 
    printf("%d\n",sum); 
    return 0; 
}
