int a,b,c,d,e,f,m,n,x,y,g;
   scanf("%d %d %d %d %d %d",&a,&d,&b,&e,&c,&f);
   x=c*c+f*f;
  m=a*a+d*d;
    n=b*b+e*e;
   if(m==n&&m==x)
    printf("yes ");
   else printf("no ");
   y=m>n?m:n;
   g=m<n?m:n;
   y=y>x?y:x;
   g=g<x?g:x;
   printf("%d %d",g,y); 
