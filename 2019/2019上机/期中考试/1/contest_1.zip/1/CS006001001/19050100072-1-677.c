#include<stdio.h>
int jvli(int a,int b)
{
	int c;
	c=a*a+b*b;
	return c;
}
int main()
{
	int x1,y1,x2,y2,x3,y3,i,k,c;
	double k1,k2;
	int jvli1,jvli2,jvli3;
	int a[3];
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	jvli1=jvli(x1,y1);
	jvli2=jvli(x2,y2);
	jvli3=jvli(x3,y3);
	if(jvli1==jvli2&&jvli2==jvli3)
	printf("yes ");
	else
	printf("no ");
	a[0]=jvli1;
	a[1]=jvli2;
	a[2]=jvli3;
	for(i=0;i<2;i++)
	{
		for(k=0;k<2-i;k++)
		{
			if(a[k]>a[k+1])
			{
				c=a[k];
				a[k]=a[k+1];
				a[k+1]=c;
			}
			
		}
	}
	printf("%d %d",a[0],a[2]);
	return 0;
	
	
	
}

