#include<stdio.h>
int max(int a,int b,int c);
int main()
{int x1,y1,x2,y2,x3,y3,a,b,c,d,e,f;
scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
if(x1*x1+y1*y1==x2*x2+y2*y2&&x2*x2+y2*y2==x3*x3+y3*y3) printf("yes ");
else printf("no ");
a=x1*x1+y1*y1;b=x2*x2+y2*y2;c=x3*x3+y3*y3;d=a;e=b;f=c;
if(a>b)
{
d=a,a=b,b=d;
}
if(a>c)
{
d=a,a=c,c=a;
}
else if(b>c)
{
d=b,b=c,c=d;
}
else
if(a>c)
{
d=a,a=c,c=d;
}
else if(b>c)
{
d=b,b=c,c=d;
}
printf("%d %d",a,c);
}



