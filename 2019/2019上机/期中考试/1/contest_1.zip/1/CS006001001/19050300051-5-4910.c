#include<stdio.h>
int main(){

int i,p,b,c,x,y,z=0;
    scanf("%d %d",&b,&c);
    if(b<c)
	x=b;
	y=c;
    if(b>c)
	y=b;
	x=c;
    for(i=x;i<=y;i++)
    {int a=0;
        for(p=2;p<i;p++)
        {
            if(i%p==0)
                a=1;
        }
        if(a==0)
       z=z+i*i;
    }
    printf("%d",z);
    return 0;}
