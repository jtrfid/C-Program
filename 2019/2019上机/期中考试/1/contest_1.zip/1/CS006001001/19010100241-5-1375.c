#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j,x,y,z=0;
    scanf("%d %d",&x,&y);
    for(i=x;i<=y;i++)
    {int a=0;
        for(j=2;j<i;j++)
        {
            if(i%j==0)
                a=1;
        }
        if(a==0)
       z=z+i*i;
    }
    printf("%d",z);
    return 0;
}
