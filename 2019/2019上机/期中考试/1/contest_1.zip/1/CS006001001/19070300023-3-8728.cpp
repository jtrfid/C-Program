#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	double s=1.0,j;
	for(i=1;i<n;i++)
	{
		j=1/i;
	    s=s*(1+j);
	}
	printf("%.1lf",s);
}
