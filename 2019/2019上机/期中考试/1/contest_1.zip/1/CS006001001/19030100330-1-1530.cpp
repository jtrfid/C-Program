#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,sed1,sed2,sed3,a,b;
	int min(int sed1,int sed2,int sed3);
	int max(int sed1,int sed2,int sed3);
	-100<=x1<=100;
	-100<=y1<=100;
	-100<=x2<=100;
	-100<=y2<=100;
	-100<=x3<=100;
	-100<=y3<=100;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	sed1=x1*x1+y1*y1;
	sed2=x2*x2+y2*y2;
	sed3=x3*x3+y3*y3;
	if(sed1=sed2=sed3){
		printf("yes");
	}else printf("no");
	a=min(sed1,sed2,sed3);
	b=max(sed1,sed2,sed3);
	printf("%d %d",a,b);
	return 0;
}
