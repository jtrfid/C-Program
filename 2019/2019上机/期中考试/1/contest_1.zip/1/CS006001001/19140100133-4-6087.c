#include<stdio.h>
void main()
{int count,year,n=0;
scanf ("%d",&year);
while(year >= 1949 ){
	if ((year % 4 == 0 && year % 100 != 0)||year % 400 ==0){
		printf ("%d ",year);
		n ++;
		if (n%5==0){
			printf("\n");
	}
}
year --;
}
}
