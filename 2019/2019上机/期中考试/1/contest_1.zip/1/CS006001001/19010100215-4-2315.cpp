#include<stdio.h>
int main(){
	int a,b,i,j,n=0,m;
	int year[100];
	scanf("%d",&b);
	for(i=1949;i<=b;i++){
	if(i%4!=0||(i%4==0&&i%4%10==5)){
		n=n;}else{
			year[n]=i;
			n++;}}
			m=n;
			for(;n>0;n--){
				printf("%d ",year[n-1]);
				if((m-n+1)%5==0)
				printf("\n");
			}
			return 0;
}
