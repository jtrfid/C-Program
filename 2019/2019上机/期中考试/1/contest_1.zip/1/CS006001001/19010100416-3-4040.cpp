#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	float s,h;
	h=1.0;
	for(i=1;i<n;i++)
	 {
		h=(1+1.00/i)*h;
	 }   
	printf("%.1f",h+1.0);
	return 0;
}
