#include "stdio.h"
#include <math.h>
int shushu(int x)
{
	int y, i;
	if (x == 1)
		return 0;
	for (i = 2; i <= (int)sqrt(x); i++)
	{
		y = x % i;
		if (y == 0)
			return 0;
	}
	return 1;
}

int main()
{
	int sum = 0, i, count = 0,a,b;
	scanf("%d %d",&a,&b);
	for (i = b; i >= a;i--)
	{
		if (shushu(i))
		{
			count++;
			sum += i * i;
		}
		
	}
	printf("%d", sum);
	return 0;}
