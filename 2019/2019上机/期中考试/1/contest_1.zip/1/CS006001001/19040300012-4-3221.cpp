#include<stdio.h>
int main()
{int a,b[100],i,h=0;
scanf("%d",&a);
for(i=1949;i<=a;i++){
if(i%4==0&&i%400>0) {b[h]=i;h++;
} else if(i%400==0) {b[h]=i;h++;
}
}
for(i=h-1;i>=0;i--){ printf("%d ",b[i]);
if((i+2)%5==0) printf("\n");
}
}
