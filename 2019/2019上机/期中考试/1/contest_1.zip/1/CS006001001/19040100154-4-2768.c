#include <stdio.h>
#include <stdlib.h>

int main()
{
    int y,i=1,a[1000]={0},j;
    scanf("%d",&y);
    for(;y>1949;y--)
        {
            if(y%4==0&&y%100!=0||y%400==0)
            {
                a[i]=y;
                i++;
            }
        }
        for(j=1;j<i;j++)
        {
             printf("%d ",a[j]);
             if(j%5==0)
                printf("\n");
        }


    return 0;
}
