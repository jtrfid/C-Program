#include<stdio.h>
int main()
{
	int n;
	double sum=1,m,a;
	scanf("%d",&n);
	          for(a=1;a<n+1;a++)
	          {
	             m=1+1/a;
	             sum=sum*m;
	          }
    printf("%.1f",sum);
    return 0;	
}
