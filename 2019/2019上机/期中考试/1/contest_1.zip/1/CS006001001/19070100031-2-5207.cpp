#include<stdio.h>
int main()
{
   int yea,n,day,n2,sum;
   scanf("%d %d %d",&yea,&n,&day);
   if(yea%4==0&&yea%100!=0||yea%400==0)
    	n2=29;
    else
        n2=28;
    if(n==1)
     sum=day;
      if(n==2)
       sum=31+day;
         if(n==3)
         sum=31+n2+day;
           if(n==4)
           sum=62+n2+day;
              if(n==5)
              sum=92+n2+day;
                if(n==6)
                sum=123+n2+day;
                   if(n==7)
                   sum=153+n2+day;
                      if(n==8)
                      sum=184+n2+day;
                         if(n==9)
                         sum=215+n2+day;
                            if(n==10)
                            sum=245+n2+day;
                              if(n==11)
                              sum=276+n2+day;
                                 if(n==12)
                                   sum=306+n2+day;
    printf("%d",sum);
    return 0;
   

}
