#include <stdio.h>
int main ()
{
int sed(int x,int y);
int x1,y1,x2,y2,x3,y3;
scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
if((x1*x1+y1*y1)==(x2*x2+y2*y2)&&(x1*x1+y1+y1)==(x3*x3+y3*y3))
printf("%c%c%c ",'y','e','s');
else printf("%c%c ",'n','o');
int s1,s2,s3;
s1=sed(x1,y1);
s2=sed(x2,y2);
s3=sed(x3,y3);
if(s1<=s2&&s1<=s3) printf("%d ",s1);
else if(s2<=s1&&s2<=s3) printf("%d ",s2);
else if(s3<=s2&&s3<=s1) printf("%d ",s3);
if(s1>=s2&&s1>=s3) printf("%d",s1);
else if(s2>=s1&&s2>=s3) printf("%d",s2);
else if(s3>=s2&&s3>=s1) printf("%d",s3);
return (0);
}
int sed(int x,int y)
{
int t;
t=x*x+y*y;
return(t);
}

