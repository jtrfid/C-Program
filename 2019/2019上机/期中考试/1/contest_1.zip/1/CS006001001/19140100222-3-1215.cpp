#include<stdio.h>
int main()
{
	int a,b,n;
	float i=2.0,o,s=2.0;
	scanf("%d",&n);
	while(i<=n)
	{
		o=1/i;
		s=s*(1+o);
		i++;
	}
	printf("%.1f",s);
}
