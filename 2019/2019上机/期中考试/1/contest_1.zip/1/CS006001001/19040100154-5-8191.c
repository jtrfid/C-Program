#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x,y,n=0,i,j,k,min,max,a[10000]={0},m=0;
    scanf("%d %d",&x,&y);
    if(x<y)
    {
        min=x;
        max=y;
    }
    else
    {
         min=y;
         max=x;
    }
      for(i=min,k=0;i<=max;i++,k++)
        for(j=1;j<=i;j++)
        {
              if(i%j==0)
            {
                m++;
            }
            if(m>3)
                break;
            else
            {
                a[k]=i;
                break;
            }
        }
    for(i=0;i<k;i++)
    {
        n=n+a[i]*a[i];
    }
    printf("%d\n",n);
    return 0;
}
