#include<stdio.h>
int main()
{
	int x,y,i,t,j,c,sum=0;
	scanf("%d %d",&x,&y);
	if(x>y)
	{
		t=x;
		x=y;
		y=t;
	}
	for(i=x;i<y+1;i++)
	{
		c=0;
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			c++;
		}
		if(c==0)
		sum=sum+i*i;
	}
	printf("%d",sum);
	return 0;
}
