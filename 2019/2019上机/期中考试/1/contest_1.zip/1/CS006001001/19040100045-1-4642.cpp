#include<stdio.h>
int max(int x,int y,int z);
int min(int x,int y,int z);
int main()
{
	int x1,x2,x3,y1,y2,y3,a,b,c;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a=x1*x1+y1*y1;
	b=x2*x2+y2*y2;
	c=x3*x3+y3*y3;
	if(a==b&&b==c)
	{
		printf("yes %d %d",a,b);
	}
	else
	{
		printf("no %d %d",min(a,b,c),max(a,b,c));
	}
	return 0;
}
int max(int x,int y,int z)
{
	int t,k;
	t=(x>y)?x:y;
	k=(t>z)?t:z;
	return(k);
}
int min(int x,int y,int z)
{
	int t,k;
	t=(x<y)?x:y;
	k=(t<z)?t:z;
	return(k);
}
