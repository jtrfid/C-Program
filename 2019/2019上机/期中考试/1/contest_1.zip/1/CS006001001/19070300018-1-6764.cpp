#include<stdio.h>
int main()
{
  int x1,y1,x2,y2,x3,y3,sed1,sed2,sed3,min,max;
  scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
  sed1=x1*x1+y1*y1;
  sed2=x2*x2+y2*y2;
  sed3=x3*x3+y3*y3;
  if(sed1==sed2&&sed2==sed3)
    printf("yes %d %d",sed1,sed2);
  else
    {
      min=sed1<sed2?sed1:sed2;
	  min=min<sed3?min:sed3;
	  max=sed1>sed2?sed1:sed2;
	  max=max>sed3?max:sed3;	
	  printf("no %d %d",min,max);
    }
   return 0;

    
  	
}
