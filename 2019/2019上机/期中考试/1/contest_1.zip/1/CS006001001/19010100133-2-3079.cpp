#include<stdio.h>
int main()
{
	int y,m,d,n,sum=0,i;
	scanf("%d %d %d",&y,&m,&d);
	if((y%4==0&&y%100!=0)||y%400==0)n=1;
	else n=0;
	int a[][12]={{31,28,31,30,31,30,31,31,30,31,30,31},{31,29,31,30,31,30,31,31,30,31,30,31}};
	for(i=0;i<m-1;i++)
	{sum+=a[n][i];}
	sum=sum+d;
	printf("%d\n",sum);
}
