#include <stdio.h>
int main()
{
	int a,b,i;
	scanf("%d",&a);
	b=a-1949;
	for(i=1;i<=b;i++)
	if((1949+i)/400==0||(1949+i0/4==0&&(1949+i)/100!=0)
	printf("%d",1949+i);
	return 0;
}
