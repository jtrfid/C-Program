#include<stdio.h>
int main()
{
	int n;
	double Sn,a,i;
	Sn=1;
	scanf("%d",&n);
	for(i=1;i<n+1;i++)
	{
	a=1+1/i;
	Sn=Sn*a;
}
	printf("%.1lf",Sn);
	
}
 
