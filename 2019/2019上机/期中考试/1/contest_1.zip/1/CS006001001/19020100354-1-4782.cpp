#include <stdio.h>
int main ()
scanf(%d %d %d %d %d %d,&x1,&y1,&x2,&y2,&x3,&y3);
  {
    a=x1*x1*y1*y1;
    b=x2*x2*y2*y2;
    c=x3*x3*y3*y3;
     {
      if(a=b=c)
      printf("yes"/n);
      else
      printf("no"/n);
     }
   }
  {
  	m=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
  	n=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);
  	p=(x2-x3)*(x2-x3)+(y2-y3)*(y2-y3);
  	m=n>p;
  	p=m>p;
  	printf(%d %d,&m,&n);
  }
  return 0;
