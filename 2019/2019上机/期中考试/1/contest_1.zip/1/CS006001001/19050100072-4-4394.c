#include<stdio.h>
int main()
{
	int year,i,n;
	int a[1000];
	scanf("%d",&year);
	int k=0;
	for(i=year;i>=1949;i--)
	{
		if(year%4==0)
		{
			a[k]=year;
			k++;
		}
		
	}
	n=year-1948;
	n=n/4;
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
		if((i+1)%5==0)
		printf("\n");
	}
		
	return 0;
}
