#include<stdio.h>
int main()
{
	int x,b,c,d,e,f,i,n,j;int a[n];
	scanf("%d %d %d %d %d %d",&x,&b,&c,&d,&e,&f);
	a[0]=x*x+b*b;a[1]=c*c+d*d;a[2]=e*e+f*f;
	if(a[0]==a[1]&&a[0]==a[2])
	printf("yes");
	else printf("no");
    for(j=0;j<2;j++)
    {
    	if(a[j]>a[j+1])
    	{
    		i=a[j];
    		a[j]=a[j+1];
    		a[j+1]=i;
    	}
    }
	printf("%d %d",a[0],a[2]);
	return 0;
}
