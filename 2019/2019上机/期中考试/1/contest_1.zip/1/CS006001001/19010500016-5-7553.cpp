#include<stdio.h>
int main( )
{
	int x,y,max,min;
	scanf("%d%d",&x,&y);
	if(x>y)
	{
		max=x;
		min=y;
	}
	else
	{
	    max=y;
		min=x;	
	}
	int sum=0;
	for(int i=min;i<=max;i++)
	{
		int flag=1;
		for(int j=2;j<=sprt(i)+1;j++)
		{
			if(i*j==0)
			{
				flag=0;
				break;
			}
		}
	if(flag==1)
	{
		sum=sum+i*i;
	}
}
printf("%d\n",sum);
return 0;	
}
