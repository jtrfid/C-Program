#include<stdio.h>
int main(){
	int nian,yue,ri,day,er;
	scanf("%d %d %d",&nian,&yue,&ri);
	if(nian%4!=0)
	er=28;
	else 
	er=29;
	if(yue=1)
	day=ri;
	if(yue=2)
	day=31+ri;
	if(yue=3)
	day=31+er+ri;
	if(yue=4)
	day=31+er+31+ri;
	if(yue=5)
	day=31+er+31+30+ri;
	if(yue=6)
	day=31+er+31+30+31+ri;
	if(yue=7)
	day=31+er+31+30+31+30+ri;
	if(yue=8)
	day=31+er+31+30+31+30+31+ri;
	if(yue=9)
	day=31+er+31+30+31+30+31+31+ri;
	if(yue=10)
	day=31+er+31+30+31+30+31+31+30+ri;
	if(yue=11)
	day=31+er+31+30+31+30+31+31+30+31+ri;
	if(yue=12)
	day=31+er+31+30+31+30+31+31+30+31+30+ri;
	printf("%d",day);
	return 0;
	
}
