#include<stdio.h>
int min(int z1,int z2,int z3);
int max(int z4,int z5,int z6);
int main()
{
	int x1,y1,x2,y2,x3,y3,s1,s2,s3;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	s1=x1*x1+y1*y1;
	s2=x2*x2+y2*y2;
	s3=x3*x3+y3*y3;
	if(s1==s2&&s2==s3) printf("yes ");
	else printf("no ");
	printf("%d %d",min(s1,s2,s3),max(s1,s2,s3));
	return 0;
}

int min(int z1,int z2,int z3)
{
	int a1,a2;
	a1=z1>z2?z2:z1;
	a2=a1>z3?z3:a1;
	return(a2);
}

int max(int z4,int z5,int z6)
{
	int a3,a4;
	a3=z4>z5?z4:z5;
	a4=a3>z6?a3:z6;
	return(a4);
}
