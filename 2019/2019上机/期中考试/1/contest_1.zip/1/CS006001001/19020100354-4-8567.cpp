#include<stdio.h>
 int main ()
 {
  int a,y;
  scanf("%d",&"y");
  if(y%4==0);
  a=y;
  if(a%100>0);
  printf("%d/n",&a);
 if (a%400==0);
  printf("%d/n",&a);  
  return 0;
}
