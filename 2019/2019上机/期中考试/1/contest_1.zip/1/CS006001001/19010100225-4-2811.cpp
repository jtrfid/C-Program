#include<stdio.h>
int main()
{
	int y,i,d;
	d=0;
	scanf("%d",&y);
	for(i=1949;i<=y;i++)
{ if(i%4==0&&i%400!=0&&i%100==0)
    {
      d=d+1;
      if(d%5!=0)
         printf("%d\n",i);
       else
	     printf("%d ",i);
}}
 return 0;
}
