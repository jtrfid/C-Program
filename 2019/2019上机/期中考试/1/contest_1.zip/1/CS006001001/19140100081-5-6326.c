#include<stdio.h>
int main()
{
  int x,y,i,j;
  int sum;
  scanf("%d%d",&x,&y);
  sum=0;
  for(i=x;i<=y;i++)
  { for(j=2;j<=i-1;j++)
	{
	  if(i%j==0)
       break;
	
	}
	 if(j==i)
		 sum=sum+i*i;
  }

  printf("%d",sum);
  return 0;
}

