#include<stdio.h>
int main()
{
	int n,i;
	float sn;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		sn=(1+1/i);
		sn=(1+1/(i+1))*sn;
		break;
	}
	printf("%.1f",sn);
	return 0;
	
}
