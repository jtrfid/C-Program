#include<stdio.h>
int main()
   {
   	int y,m,d,a;
   	scanf("%d %d %d",&y,&m,&d);
   	if((y%4==0&&y%100!=0)||y%400==0)
   	  {
   	  	if(m==1)
   	  	  printf("%d",d);
   	  	else if(m==2)
   	  	  {
   	  	  	a=31+d;
   	  	  	printf("%d",a);
   	  	  }
   	  	  else if(m==3)
   	  	    {
   	  	    	a=31+29+d;
   	  	    	printf("%d",a);
   	  	    }
   	  	    else if(m==4)
   	  	      {
   	  	      	a=31+29+31+d;
   	  	      	printf("%d",a);
   	  	      }
   	  	      else if(m==5)
   	  	        {
   	  	        	a=31+29+31+30+d;
   	  	        	printf("%d",a);
   	  	        }
   	  	        else if(m==6)
   	  	          {
   	  	          	a=31+29+31+30+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==7)
   	  	          {
   	  	          	a=31+29+31+30+31+30+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==8)
   	  	          {
   	  	          	a=31+29+31+30+31+30+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==9)
   	  	          {
   	  	          	a=31+29+31+30+31+30+31+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==10)
   	  	          {
   	  	          	a=31+29+31+30+31+30+31+31+30+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==11)
   	  	          {
   	  	          	a=31+29+31+30+31+30+31+31+30+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==12)
   	  	          {
   	  	          	a=31+29+31+30+31+30+31+31+30+31+30+d;
   	  	          	printf("%d",a);
   	  	          }
   	  }
   	  else
   	  {
   	  	if(m==1)
   	  	  printf("%d",d);
   	  	else if(m==2)
   	  	  {
   	  	  	a=31+d;
   	  	  	printf("%d",a);
   	  	  }
   	  	  else if(m==3)
   	  	    {
   	  	    	a=31+28+d;
   	  	    	printf("%d",a);
   	  	    }
   	  	    else if(m==4)
   	  	      {
   	  	      	a=31+28+31+d;
   	  	      	printf("%d",a);
   	  	      }
   	  	      else if(m==5)
   	  	        {
   	  	        	a=31+28+31+30+d;
   	  	        	printf("%d",a);
   	  	        }
   	  	        else if(m==6)
   	  	          {
   	  	          	a=31+28+31+30+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==7)
   	  	          {
   	  	          	a=31+28+31+30+31+30+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==8)
   	  	          {
   	  	          	a=31+28+31+30+31+30+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==9)
   	  	          {
   	  	          	a=31+28+31+30+31+30+31+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==10)
   	  	          {
   	  	          	a=31+28+31+30+31+30+31+31+30+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==11)
   	  	          {
   	  	          	a=31+28+31+30+31+30+31+31+30+31+d;
   	  	          	printf("%d",a);
   	  	          }
   	  	          else if(m==12)
   	  	          {
   	  	          	a=31+28+31+30+31+30+31+31+30+31+30+d;
   	  	          	printf("%d",a);
   	  	          }
   	  }
   	  return 0;
   }
