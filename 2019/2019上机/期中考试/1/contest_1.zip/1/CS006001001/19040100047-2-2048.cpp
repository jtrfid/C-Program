#include<stdio.h>
int main()
{
	int y,m,d,n;
	scanf("%d %d %d",&y,&m,&d);
	if(m==1)
	{
		n=d;
		printf("%d",n);
	}
	else if(m==2)
	{
		n=31+d;
		printf("%d",n);
	}	
	else if(m==3)
	{
		n=31+28+d;
		printf("%d",n);
	}
	else if(m==4)
	{
		n=31*2+28+d;
		printf("%d",n);
	}
	else if(m==5)
	{
		n=31*2+28+30+d;
		printf("%d",n);
	}
	else if(m==6)
	{
		n=31*3+28+30+d;
		printf("%d",n);
	}
	else if(m==7)
	{
		n=31*4+28+30+d;
		printf("%d",n);
	}
	else if(m==8)
	{
		n=31*5+28+30+d;
		printf("%d",n);
	}
	else if(m==9)
	{
		n=31*5+28+30*2+d;
		printf("%d",n);
	}
	else if(m==10)
	{
		n=31*5+28+30*3+d;
		printf("%d",n);
	}
	else if(m==11)
	{
		n=31*5+28+30*4+d;
		printf("%d",n);
	}
	else if(m==12)
	{
		n=31*6+28+30*4+d;
		printf("%d",n);
	}
	return 0;
		
	
}
