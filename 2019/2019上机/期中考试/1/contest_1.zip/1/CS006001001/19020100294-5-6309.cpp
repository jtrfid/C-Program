#include<stdio.h>
int zs(int n);
int main()
{
	int x,y,sum=0;
	scanf("%d %d",&x,&y);
	for(int i=x;i<=y;i++)
	{
		if(zs(i)) sum=sum+i*i;
	}
	printf("d",sum);
	return 0;
}
int zs(int n)
{
	int a;
    for(int i=2;i<n;i++)
    {
	if(n%i==0) a=0;
	else a=1;
    }
	return(a);
}

