#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	int i;
	for(i=1949;i<a;i++)
		if(i%4==0&&i!=1968&&i!=1988&&1!=2008)
		printf("%d ",i);
		else if(i==1968||i==1988||i==2008)
		printf("%d\n",i);
	return 0;
	
}
