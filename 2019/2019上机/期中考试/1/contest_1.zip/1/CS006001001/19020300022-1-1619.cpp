#include <stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,SED1,SED2,SED3,m,a,b;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	SED1=x1*x1+y1*y1;
	SED2=x2*x2+y2*y2;
	SED3=x3*x3+y3*y3;
	if(SED1>SED2>SED3){
		a=SED1,b=SED3;
	}
	else if(SED1>SED3>SED2){
		a=SED1,b=SED2;
	}
	else if(SED2>SED1>SED3){
		a=SED2,b=SED3;
	}
	else if(SED2>SED3>SED1){
		a=SED2,b=SED1;
	}
	else if(SED3>SED1>SED2){
		a=SED3,b=SED2;
	}
	else if(SED3>SED2>SED1){
		a=SED3,b=SED1;
	}
	if(SED1==SED2==SED3){
		m=1;
	}
	else{
		m=0;
	}
	if(m==1){
		printf("yes %d %d",b,a);
	}
	else if(m==0){
		printf("no %d %d",b,a);
	}
	return 0;
}
