#include<stdio.h>
int main()
{
	int n;
	double sum=1,a,i;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		a=(1+1/i);
		sum=sum*a;
	}
	printf("%.1lf",sum);
	return 0;
}
