#include<stdio.h>
int main()
   {
   	int x,y,i,sum,j,m,n;
    scanf("%d %d",&x,&y);
   	sum=0;
   	if(y>x)
   	  {
   	  	for(i=x;i<=y;i++)
   	   {
   	   	j=2;
   	   	m=i%j;
   	   	while(m!=0)
   	   	     {
   	   	     	j++;
   	   	     	m=i%j;
   	   	     }
   	   	if(j==i)
   	   	  {
   	   	  	sum+=i*i;
   	   	  }
   	   }
   	  }
   	  else
   	  {
   	  	for(i=y;i<=x;i++)
   	   {
   	   	j=2;
   	   	m=i%j;
   	   	while(m!=0)
   	   	     {
   	   	     	j++;
   	   	     	m=i%j;
   	   	     }
   	   	if(j==i)
   	   	  {
   	   	  	sum+=i*i;
   	   	  }
   	   }
   	  }
   	printf("%d",sum);
   	return 0;
   }
