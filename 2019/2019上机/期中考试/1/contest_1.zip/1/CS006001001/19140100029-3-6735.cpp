#include<stdio.h>
int main()
{
	int a;
	float sn;
	scanf("%d",&a);
    while(a>1)
{
      sn=2*(1+1/a);
	  a=a-1; 
}

	printf("%.1f",sn);
	
	return 0;
}
