#include<stdio.h>
int main()
{
	int a,b,c,d;
	scanf("%d %d %d",&a,&b,&c);
	if(b==1) d=0;
	if(b==2) d=31;
	if(b==3) d=59;
	if(b==4) d=90;
	if(b==5) d=120;
	if(b==6) d=151;
	if(b==7) d=181;
	if(b==8) d=212;
	if(b==9) d=243;
	if(b==10) d=273;
	if(b==11) d=304;
	if(b==12) d=334;
	d=d+c;
	if(a%4==0&&a%100!=0)
	{
		d=d+1;
		if(b<=2) d=d-1;
	}
	else if(a%100==0&&a%400==0)
	{
		d=d+1;
			if(b<=2) d=d-1;
	}
	printf("%d",d);
}
	
		
	
