
#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	float n,sum,out;
	scanf("%f",&n);
	for(sum=1,out=1;out<=n;out++)
	sum=sum*(1+1/out);
	printf("%.1f",sum);
	
	
	
	
	
	
	
	
	return 0;
}
