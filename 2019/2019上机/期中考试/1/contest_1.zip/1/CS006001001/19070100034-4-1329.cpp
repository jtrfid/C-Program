#include<stdio.h>
int main()
{
	int nian,i,shu=0;
	scanf("%d",&nian);
	for(i=nian;i>1949;i--)
	{
		if((i%4==0&&i%100!=0)||i%400==0)
		{
			printf("%d ",i);
			shu++;
		}
		if(shu%5==0)
		    printf("\n");
	}
	getchar();
	return 0;
}

