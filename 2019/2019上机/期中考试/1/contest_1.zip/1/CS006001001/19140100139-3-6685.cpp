#include <stdio.h>
int main()
{
	int n,i;
	float Sn;
	scanf ("%d",n);
	i=1;
	Sn=1;
	while(i<=n)
	{
	    Sn=Sn*(1+1/i);
	    i++;
    }
	    printf ("%f",Sn);
	    return 0;
}
