#include <stdio.h>
main()
{
	int("n=3;n<3;Sn");
	int("a=%f\nb=%f\nc=$f\n");
	int("a=1+1/1 b=1+1/2 c=1+1/3");
	int("Sn=a+b+c");
	printf("Sn=23/6");
	return 0;
}
