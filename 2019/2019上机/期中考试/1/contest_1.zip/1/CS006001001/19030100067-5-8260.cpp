#include<stdio.h>
int main()
{
	int m,n,i,j,a;
	a=0;
	scanf ("%d %d",&m,&n);
	int b[n];
	for (i=0;i<=n;i++) b[i]=0;
	for(i=m;i<=n;i++)
		{
			for(j=2;j<i;j++)
			{
				 if (i%j==0) 
				{
					b[i]=0;
					break;
				}
				else 
					b[i]=i;
			}
		}
	for(i=0;i<=n;i++)
	{
		a=a+b[i]*b[i];
	}
	
	printf ("%d",a);
	return 0;
}
