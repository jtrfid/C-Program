#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,r1,r2,r3,max,min;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	r1=x1*x1+y1*y1;
	r2=x2*x2+y2*y2;
	r3=x3*x3+y3*y3;
	
	if(r1>=r2)
	 {if(r1>=r3)  
        {if(r2>=r3)
          max=r1,min=r3;
         else
          max=r1,min=r2;
        }
	  else max=r3,min=r2;
	 }
	else
	{
	  if(r1>=r3)
	  max=r2,min=r3;
	  else
	   {
	   	  if(r2>=r3)
	   	  max=r2,min=r1;
	   	  else
	   	  max=r3,min=r1;
	   }
	}
	
	
	if((r1*r1==r2*r2)&&(r1*r1==r3*r3))
	printf("yes %d %d",min,max);
	else
	printf("no %d %d",min,max);
	return 0;
	
}
