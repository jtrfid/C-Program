#include<stdio.h>
int main()
{
	int z(int n);
	int x,y;
	scanf("%d %d",&x,&y);
	int m;
	if(x>y)  m=x,x=y,y=m;
	int i=x,t=0;
	while(i<=y)
	{
		if(z(i))  t=t+i*i;
		i++;
	}
	printf("%d",t);
	return 0;
}
int z(int n)
{
	int a,j=1;
	for(a=2;a<=n/2;a++)
	   if(n%a==0)
	   {
	   	j=0;
	   	break;
	   }
	return(j);
}
