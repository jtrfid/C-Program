#include<stdio.h>
int sn(int x);
int main()
{
	int n;
	float s;
	scanf("%d",&n);
	printf("0.1f",sn(n));
	return 0;
}

int sn(int x)
{
	int sum=1;
	for( int i=1;i<=x;i++)
	sum=sum*(1+1/i);
	return(sum);
}
