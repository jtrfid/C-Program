#include<stdio.h>
int main()
{
	int nian,yue,ri,rong,a[13],i,end=0;
	scanf("%d %d %d",&nian,&yue,&ri);
	for(i=1;i<=12;i++)
	{
		if(i==1||i==3||i==5||i==7||i==8||i==10||i==12)
		    a[i]=31;
		else
		    a[i]=30;
	}
	if((nian%4==0&&nian%100!=0)||nian%400==0)
	{
		rong=1;
		a[2]=29;
	}
	else
	{
		rong=0;
		a[2]=28;
	}
	for(i=1;i<yue;i++)
	{
		end=end+a[i];
	}
	end=end+ri;
	printf("%d",end);
	getchar();
	return 0;
}
