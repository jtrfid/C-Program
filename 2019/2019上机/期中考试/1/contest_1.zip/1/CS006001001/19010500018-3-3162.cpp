#include<stdio.h>

int main()
{float n,s=0.0,i;
scanf("%f",n);
for(i=1;i<=n;i++)
{
	s=s+1/n;
	printf("%.1f",s);
}
	
	
	return 0;
}
