#include<stdio.h>
int main()
{
	int a,b,i,j,s=0;
	scanf("%d %d",&a,&b);
do{

	for(i=a;i<=b;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)break;
			else if(j==i-1) s=s+i*i;
		}
      
	}
}while(a-b>10&&a-b<-10&&20<a&&a<1000&&b<1000&b>20);
	printf("%d",s);
}
