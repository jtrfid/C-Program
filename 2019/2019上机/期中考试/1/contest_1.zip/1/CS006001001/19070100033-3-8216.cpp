#include<stdio.h>
int main()
{
	int i,n;
	float end;
	scanf("%d",&n);

     end=float(n)+1;
                  
 	printf("%.1f",end);
	return 0;
} 
