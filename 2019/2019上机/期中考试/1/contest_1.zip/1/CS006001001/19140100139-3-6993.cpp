#include <stdio.h>
int main()
{
	int n,i;
	float Sn;
	scanf ("%d",n);
    for(i=1,Sn=1;i<=n;i++);
    Sn=Sn*(1+(1/i));
	printf ("%f",Sn);
	return 0;
}
