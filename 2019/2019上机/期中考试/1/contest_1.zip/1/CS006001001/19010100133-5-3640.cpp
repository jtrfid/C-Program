#include<stdio.h>
#include<math.h>
int fun(int i);
int main()
{
	int x,y,t,sum=0,i;
	scanf("%d %d",&x,&y);
	if(x>y){t=x;x=y;y=t;}
	for(i=x;i<=y;i++)
	{
		if(fun(i))
		sum+=i*i;
	}
	printf("%d",sum);
}

int fun(int i)
{
	int j;
	for(j=3;j<i;j++)
	if(i%j==0)return 0;
	return 1;
}
