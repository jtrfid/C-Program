#include<stdio.h>
int main()
{
	int year,m,d;
	scanf("%d %d %d",&year,&m,&d);
	if(m==1)
	d=d;
	else if(m==2)
	d=31+d;
	else if(m==3)
	d=31+28+d;
	else if(m==4)
	d=31+28+31+d;	
	else if(m==5)
	d=31+28+31+30+d;
	else if(m==6)
	d=31+28+31+30+31+d;
	else if(m==7)
	d=31+28+31+30+31+30+d;
	else if(m==8)
	d=31+28+31+30+31+30+31+d;
	else if(m==9)
	d=31+28+31+30+31+30+31+31+d;
	else if(m==10)
	d=31+28+31+30+31+30+31+31+30+d;	
    else if(m==11)
	d=31+28+31+30+31+30+31+31+30+31+d;	
	else 
	d=31+28+31+30+31+30+31+31+30+31+30+d;	
	
	printf("%d",d);
	return 0;
}
