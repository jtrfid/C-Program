#include<stdio.h>
int main( )
{
	int x1,y1,x2,y2,x3,y3,d1,d2,d3;
	scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3);
	d1=x1*x1+y1*y1;
	d2=x2*x2+y2*y2;
	d3=x3*x3+y3*y3;
	if(d1==d2==d3)
		{
		printf("yes %d %d",d1,d2);
		}
	else if(d1>=d2>=d3)
		{
		printf("no %d %d",d3,d1);
		}
	else if(d1>=d3>=d2)
		{
		printf("no %d %d",d2,d1);
		}
	else if(d2>=d1>=d3)
		{
		printf("no %d %d",d3,d2);
		}
	else if(d2>=d3>=d1)
		{
		printf("no %d %d",d1,d2);
		}
	else if(d3>=d1>=d2)
		{
		printf("no %d %d",d2,d3);
		}
	else if(d3>=d2>=d1)
		{
		printf("no %d %d",d1,d3);
		}
	return 0;
}
