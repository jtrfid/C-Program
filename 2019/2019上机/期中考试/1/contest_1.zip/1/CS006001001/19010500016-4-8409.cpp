#include<stdio.h>
int main( )
{
	int a,i=1949,count=0,d;
	scanf("%d",&a);
	for(d==a;d>=i;d--)
	{
	if(d%400==0||(d%4==0&&d%100!=0))
	{
	  count++;
	  printf("%d",d);
    }
    if(count==5)
    {
    	printf("\n");
    	count=0;
    }
}
    return 0;
}
