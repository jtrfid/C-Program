#include<stdio.h>
int main(){
	int n,i;
	int sn=1;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	sn=sn*(1/i+1);
	printf("%d",sn);
	return 0;
}
