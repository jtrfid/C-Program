#include<stdio.h>
int main()
{
	int n,i,s=0,a[1000],h=0;
	scanf("%d",&n);
	for(i=1950;i<=n;i++)
	if((i%4==0 && i%100!=0) || (i%400==0)){
	a[h]=i,h++;
	}for(i=h-1;i>=0;i--){ printf("%d ",a[i]);
if((i+2)%5==0) printf("\n");
}
	
	return 0;
}
