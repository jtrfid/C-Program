#include<stdio.h>
int main()
{
	int year,month,day;
	int a=0,i;
	int b[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	scanf("%d %d %d",&year,&month,&day);
	if(year%4==0&&year%100!=0)
	b[2]=b[2]+1;
	else if(year%400==0)
	b[2]=b[2]+1;
	else
	b[2]=b[2];
	for(i=0;i<month;i++)
	{
		a=a+b[i];
	}
	day=a+day;
	printf("%d",day);
	return 0;
}
