#include<stdio.h>
int main()
{
	int x1,y1,x2,y2,x3,y3,r[4],i,j,t;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	r[1]=x1*x1+y1*y1;
	r[2]=x2*x2+y2*y2;
	r[3]=x3*x3+y3*y3;
	if(r[1]==r[2]&&r[1]==r[3])
	    printf("yes ");
	else
	    printf("no ");
	for(i=1;i<=2;i++)
	{
		for(j=i+1;j<=3;j++)
		{
			if(r[i]>r[j])
			{
				t=r[i];
				r[i]=r[j];
				r[j]=t;
			}
		}
	}
	printf("%d %d",r[1],r[3]);
	getchar();
	return 0;
}
