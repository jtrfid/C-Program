#include<stdio.h>
int main()
{
	int n,i;
	float sn;
	scanf("%d",&n);
    sn=n+1;
	printf("%.1f",sn);
	return 0;
}
