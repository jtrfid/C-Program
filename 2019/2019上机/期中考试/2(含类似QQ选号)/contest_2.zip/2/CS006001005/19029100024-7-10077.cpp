#include<stdio.h>
int main(){
	char a;
	int b,c;
	int gongzi;
	float daoshou;
	float shui;
	scanf("%c%d%d",&a,&b,&c);
	switch(a)
	{case 'A' : gongzi=26*(c+(b-1)*200)+2000;break;
	 case 'B' : gongzi=26*(c+(b-1)*200)+1200;break;
	 case 'C' : gongzi=26*(c+(b-1)*200)+500;break;
	 	}
	
	if(gongzi<=5000)
	shui=0;
	else if(gongzi<=8000)
	shui=(gongzi-5000)*0.03;
	else if(gongzi<=17000)   
	shui=3000*0.03+(gongzi-8000)*0.1;
	else if(gongzi<=30000)   
	shui=3000*0.03+9000*0.1+(gongzi-17000)*0.2;
	else if(gongzi<=40000)   
	shui=3000*0.03+9000*0.1+13000*0.2+(gongzi-30000)*0.25;
	else if(gongzi<=60000)   
	shui=3000*0.03+9000*0.1+13000*0.2+10000*0.25+(gongzi-40000)*0.3;
	else if(gongzi<=85000)   
	shui=3000*0.03+9000*0.1+13000*0.2+10000*0.25+20000*0.3+(gongzi-60000)*0.35;
	else if(gongzi<=100000000000)   
	shui=3000*0.03+9000*0.1+13000*0.2+10000*0.25+20000*0.3+25000*0.35+(gongzi-85000)*0.45;
	
	daoshou=gongzi-shui;
	printf("%.2f %.2f",shui,daoshou);
	return 0;
	
	
	
}
