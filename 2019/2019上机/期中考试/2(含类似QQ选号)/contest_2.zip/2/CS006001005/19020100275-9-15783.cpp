#include<stdio.h>
int main(){
	int m,n,i,min,max,gys,gbs;
	scanf("%d %d",&m,&n);
	if(m==0||n==0) printf("0 0");
	else{
	if(m==n) printf("%d %d",m,n);
	m>=n?(min=n):(min=m);
	m>=n?(max=m):(max=n);
	for(i=min;i>0;i--){
		if(m%i==0&&n%i==0){
			gys=i;
			break;
		}
	}
	for(i=max;i<=m*n;i++){
		if(i%n==0&&i%m==0){
			gbs=i;
			break;
		}
	}
	printf("%d %d",gys,gbs);
}
	return 0;
}
