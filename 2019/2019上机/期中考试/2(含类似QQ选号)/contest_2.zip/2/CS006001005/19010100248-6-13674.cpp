#include<stdio.h>
int main( ){
	int n,a,b,c,d,h,m,s;
	scanf("%d",&n);
	a=24*60*60;
	b=60*60;
	c=60;
	d=n/a;
	h=(n-d*a)/b;
	m=(n-d*a-h*b)/c;
	s=n-d*a-h*b*m*c;
	printf("%d %d:%d:%d",d,h,m,s);
	return 0;
}
