#include <stdio.h>
int main(){
	int m,n,yue,bei,t,i;
	scanf("%d %d",&m,&n);
	if(m>n){
		t=m;
		m=n;
		n=t;
	}
	for(i=m;i>0;i--){
		if(m%i==0&&n%i==0) {
			yue=i;
			break;
		}
	}
	for(i=1;i<=n;i++){
		if((m*i)%n==0){
			bei=m*i;
			break;
		}
	}
	printf("%d %d",yue,bei);
	return 0;
}
