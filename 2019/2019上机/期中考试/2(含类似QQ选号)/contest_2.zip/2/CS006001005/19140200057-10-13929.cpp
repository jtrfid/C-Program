#include<stdio.h>
int main()
{
	int n,k1,k2,i,count1,count2,k=0,x,choose,m,y;
	int s[30];
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	{
		scanf("%d",&s[i]);
	}
	for(i=0;i<n;i++)
	{count1=0;count2=0;m=s[i];
		if(s[i]%10==k1||s[i]%10==k2)
		{
			while(s[i]!=0)
			{
				x=s[i]%10;
				if(x==k1||x==k2)
				count1++;
			    s[i]=s[i]/10;
			    count2++;
			}
			if(count1>k)
			{
				choose=m;
				k=count1;
				y=count2;
			}
			if(count1==k)
			{
				if(count2>y)
				{
					choose=m;
					k=count1;
					y=count2;
					if(count2==y&&m<choose)
					{
					   	choose=m;
					k=count1;
					y=count2;
					}
				}
			}
		}
	}
	printf("%d %d %d",choose,k,y);
	return 0;
	
}
