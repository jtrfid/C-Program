#include<stdio.h>
int main(){
	int a,i,c;
	scanf("%d",&a);c=0;
	for(i=1;i<=a;i++)
	c=i*i+c;
	printf("%d",c);
	
}
