#include<stdio.h>
int main()
{
	int a,b,c,m,n,k,q,w,e,r;
	scanf("%d",&a);
	if(a<=59)
	printf("0:0:%d",a);
	if(a>=60&&a<=3599)
	{
	b=a%60;
	c=a/60;
	printf("0:%d:%d",c,b);}
	if(a>=3600&&a<=86400)
	{
	m=a/3600;
	n=(a-m*3600)%60;
	k=(a-m*3600)/60;
	printf("%d:%d:%d",m,k,n);}
	if(a>=86400){
		q=a/86400;
		w=(a-q*86400)/3600;
		e=(a-q*86400-w*3600)%60;
		r=(a-q*86400-w*3600)/60;
		printf("%d %d:%d:%d",q,w,r,e);
	}
	return 0;
}
