#include<stdio.h>
int main(){
	int t;int m,n;
	scanf("%d %d %d",&t,&m,&n);int i,j=0;int sum=0;int c;
	int a[20],b[20];
	for(i=0;i<t;i++)
	scanf("%d",&a[i]);
	
	for(i=0;i<t;i++){
	c=a[i];sum=0;
	if(c%10!=m&&c%10!=n){
	 b[i]=0;break;}
	else while(c!=0){
		j=c%10;
		c=c/10;
		if(j==m||j==n) sum++;
	}
    b[i]=sum;}
    
    j=b[0];int s=a[0];
    for(i=1;i<t;i++){
    if(j<b[i]) {j=b[i];s=a[i];
    }
    else if(j==b[i]&&s<a[i]){j=b[i];s=a[i];
    }}
    int haha;
    haha=s;
    int wei=0;
    while(haha!=0)
    {wei++;
    haha=haha/10;
    }
    printf("%d %d %d",s,j,wei);
    return 0;}
    
