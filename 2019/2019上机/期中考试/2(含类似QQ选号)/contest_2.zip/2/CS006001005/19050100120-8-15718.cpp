#include<stdio.h>
int main(){
	int i,n,s=0;
	scanf("%d",&n);
	for(i=1;;i++)
	{
		s=s+i*i;
		if(s>=n) break;
	}
	int I=i;
	if(s==n) printf("%d",s);
	else
	{
		s=0;
		for(i=1;i<I;i++)
		s=s+i*i;
		printf("%d",s);
	}
	return 0;
}
