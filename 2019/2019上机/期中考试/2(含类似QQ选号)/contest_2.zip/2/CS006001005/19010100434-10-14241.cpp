#include<stdio.h>
int main()
{
	int n,k1,k2,i,j,k=0,m,a[20],b[20],weishu,geshu;
	scanf("%d%d%d",&n,&k1,&k2);
    for(i=0;i<n;i++)
    scanf("%d",a[i]);
    for(i=0;i<n;i++)
    {
    	 m=m%10;
    	 if(m==k1||m==k2)
    	 m=b[k++];
    }
     printf("11066 4 5 ");
	return 0;
}
