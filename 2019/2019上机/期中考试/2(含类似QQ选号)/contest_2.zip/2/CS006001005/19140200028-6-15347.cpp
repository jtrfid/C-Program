#include<stdio.h>
int main()
{int t,d=0,h,m;
scanf("%d",&t);
if(t>=24*60*60)
d=t/(24*60*60);
t=t%(24*60*60);
h=t/(3600);
t=t%3600;
m=t/60;
t=t%60;
if(d==0)printf("%d:%d:%d",h,m,t);
if(d>0) printf("%d %d:%d:%d",d,h,m,t);
return 0;
}
