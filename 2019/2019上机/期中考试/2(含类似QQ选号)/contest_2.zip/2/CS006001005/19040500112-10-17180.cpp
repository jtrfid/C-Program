#include<stdio.h>
int main(){
	int t;int m,n;
	scanf("%d %d %d",&t,&m,&n);int i,j=0;int sum=0;int c;int cao,kao;
	int a[t],b[t];
	for(i=0;i<t;i++)
	scanf("%d",&a[i]);
	
	for(i=0;i<t;i++){
	c=a[i];sum=0;
	if(c%10!=m&&c%10!=n){
	 b[i]=0;break;}
	else while(c!=0){
		j=c%10;
		c=c/10;
		if(j==m||j==n) sum++;
	}
    b[i]=sum;}
    
    int s;
    for(i=0;i<t;i++)
	for(j=0;j<t-1;j++){
    if(b[j]>b[j+1]) {cao=b[j];b[j]=b[j+1];b[j+1]=cao;
    kao=a[j];a[j]=a[j+1];a[j+1]=kao;
    }
    else if(b[j+1]==b[j]&&a[j]>a[j+1]){cao=b[j];b[j]=b[j+1];b[j+1]=cao;
    kao=a[j];a[j]=a[j+1];a[j+1]=kao;
    }}
    int haha;
    haha=a[0];
    int wei=0;
    while(haha!=0)
    {wei++;
    haha=haha/10;
    }
    printf("%d %d %d",s,j,wei);
    return 0;}
    
