#include<stdio.h>
int main(){
	int n,i,t,c,b,k1,k2,nt,pt,l,k;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=1,b=0,c=0,pt=0;i<=n;i++){
		scanf("%d",&t);
		if(t%10==k1||t%10==k2){
			for(l=k=0,nt=t;nt!=0;){
				if(nt%10==k1||nt%10==k2) k++;
				nt/=10;l++;
			}
			if(b<k) b=k,c=l,pt=t;
			else if(b==k) if(c<l) pt=t,c=l;
		}
		else continue;
	}
	printf("%d %d %d",pt,b,c);
	return 0;
}
