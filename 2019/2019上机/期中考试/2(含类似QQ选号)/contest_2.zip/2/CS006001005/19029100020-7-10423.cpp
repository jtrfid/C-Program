#include<stdio.h>
int main(){
	int ji,x1,sum=0,a;
	float shui=0.0,gongzi=0.0;
	char lei;
	scanf("%c %d %d",&lei,&ji,&x1);
  if(lei=='A')
  sum=sum+2000;
else if(lei=='B')
 sum=sum+1200;
else if(lei=='C')
 sum=sum+500;
 
 sum=sum+((ji-1)*200+x1)*26;
 if(sum<=5000)
 shui=0;
 else if(sum<=8000)
 shui=(sum-5000)*0.03;
 else if(sum<=17000)
 shui=3000*0.03+(sum-8000)*0.1;
 else if(sum<=30000)
 shui=3000*0.03+9000*0.1+(sum-17000)*0.2;
  else if(sum<=40000)
 shui=3000*0.03+9000*0.1+13000*0.2+(sum-30000)*0.25;
 else if(sum<=60000)
 shui=3000*0.03+9000*0.1+13000*0.2+10000*0.25+(sum-40000)*0.3;
 else if(sum<=85000)
 shui=3000*0.03+9000*0.1+13000*0.2+10000*0.25+20000*0.3+(sum-60000)*0.35;
 else 
 shui=3000*0.03+9000*0.1+13000*0.2+10000*0.25+20000*0.3+25000*0.35+(sum-85000)*0.45;
gongzi=sum-shui;
	printf("%.2f %.2f",shui,gongzi);
}
