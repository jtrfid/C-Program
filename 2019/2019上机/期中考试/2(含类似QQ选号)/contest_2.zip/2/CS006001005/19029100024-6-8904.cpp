#include<stdio.h>
int main(){
    long t;
	int d,h,m,s;
	scanf("%ld",&t);
	d=t/86400;
	h=(t%86400)/3600;
	m=((t%86400)%3600)/60;
	s=t-86400*d-3600*h-60*m;
	if(d!=0)
	printf("%d %d:%d:%d",d,h,m,s);
	else
	printf("%d:%d:%d",h,m,s);
	return 0;	
	
	
	
	
	
	
	
	
	
	
}
