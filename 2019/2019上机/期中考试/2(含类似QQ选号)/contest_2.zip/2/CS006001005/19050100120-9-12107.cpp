#include<stdio.h>
int main(){
	int m,n;
	scanf("%d%d",&m,&n);
	int i;
	for(i=m;;i--)
	if(m%i==0&&n%i==0) break;printf("%d ",i);
	for(i=m;;i++)
	if(i%m==0&&i%n==0) break;printf("%d",i);
	return 0;
}
