#include<stdio.h>
int main ()
{
	int n,a,b,c,d;
	scanf("%d",&n);
	a=n/86400;
	b=(n-86400*a)/3600;
	c=(n-86400*a-3600*b)/60;
	d=n-86400*a-3600*b-60*c;
	if(a==0) printf("%d:%d:%d",b,c,d);
	else printf("%d %d:%d:%d",a,b,c,d);
	return 0;
}
