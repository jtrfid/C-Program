#include<stdio.h>
int main()
{
	float l,s,m,n,q;
	char c;
	scanf("%c %f %f",&c,&l,&s);
	switch(c)
	{
	case 'A':m=2000;break;
	case 'B':m=1200;break;
	case 'C':m=500;break;
    }
    n=26*(s+(l-1)*200)+m;
    if(n<=5000) printf("0.00 %.2f",n);
    if(n>5000&&n<=8000) { q=(n-5000)*0.03; printf("%.2f %.2f",q,n-q);}
    if(n>8000&&n<=17000) { q=90+(n-8000)*0.1;printf("%.2f %.2f",q,n-q);}
    if(n>17000&&n<=30000) { q=90+900+(n-17000)*0.2; printf("%.2f %.2f",q,n-q);}
    if(n>30000&&n<=40000) { q=90+900+2600+(n-30000)*0.25; printf("%.2f %.2f",q,n-q);}
    if(n>40000&&n<=60000) { q=90+900+2600+2500+(n-40000)*0.3; printf("%.2f %.2f",q,n-q);}
    if(n>60000&&n<=85000) { q=90+900+2600+2500+6000+(n-60000)*0.35; printf("%.2f %.2f",q,n-q);}
    if(n>85000) {q=90+900+2600+2500+6000+8750+(n-85000)*0.45; printf("%.2f %.2f",q,n-q);}
    return 0;
}
