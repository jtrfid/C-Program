#include<stdio.h>
int main(){
	int m,n,temp;
	int i,j,min,max;
	scanf("%d %d",&m,&n);
	if(m<n){
		temp=m;m=n;n=temp;
	}
	min=1;max=m;
	for(i=1;i<=n;i++){
		if((n%i==0)&&(m%i==0)){
			if(i>min) min=i;
		}
	}
	for(j=m;;j++){
		if((j%m==0)&&(j%n==0)){
			max=j;break;
		}
	}
	printf("%d %d",min,max);
	return 0;
}
