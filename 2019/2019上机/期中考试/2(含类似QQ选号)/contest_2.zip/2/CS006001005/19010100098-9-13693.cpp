#include<stdio.h>
int main(){
int m,n,i,j,a,c,d,e;
	scanf("%d %d",&m,&n);
	if(m>n){
	for(i=n;i>0;i--)
	{if(m%i==0&&n%i==0)
	a=i;break;}
}
else if(m<n)
	for(j=m;j>0;j--){
		if(m%j==0&&n%j==0)
	a=j;break;	
	}
	c=m/a;
	d=n/a;
	e=c*d*a;
	printf("%d %d",a,e);
	return 0;
	
}
