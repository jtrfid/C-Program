#include<stdio.h>
int main(){
	int m,n,i,a,b,A,B;
	scanf("%d %d",&m,&n);
	if(a>b){
		A=m,B=n;
	}
	else{
		A=n,B=m;
	}
	for(i=B;i>=1;i--){
		if(m%i==0&&n%i==0){
			a=i;break;
		}
	}
	for(i=A;;i++){
		if(i%m==0&&i%n==0){
			b=i;break;
		}
	}
	printf("%d %d",a,b);
	return 0;
}
