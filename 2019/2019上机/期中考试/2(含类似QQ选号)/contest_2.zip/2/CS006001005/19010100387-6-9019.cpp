#include<stdio.h>
int main( )
{
	int n,a,b,c,e,f,g,h;
	scanf("%d",&n);
	a=24*60*60;
	b=60*60;
	c=60;
	e=n/a;
	f=(n-e*a)/b;
	g=(n-e*a-f*b)/c;
	h=(n-e*a-f*b-g*c);
	if(e!=0) printf("%d %d:%d:%d",e,f,g,h);
	else printf("%d:%d:%d",f,g,h);
	return 0;
}
