#include<stdio.h>
int main(){
	int k1,k2,n,i,sum=0,w=0,max=0,xin,c,d;
	long int a[20];
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{c=a[i];
	sum=0;
	w=0;
	if(c%10==k1||c%10==k2)
 {
	  while(c>0)
	 {
	  if(c%10==k1||c%10==k2)
	  {
	  sum=sum+1;
	  c=c/10;
	  w=w+1;}
     }
     if(sum>max)
     {max=sum;
     xin=a[i];
     d=w;
	 }
     if(sum=max)
     if(w>d)
    {
     xin=a[i];
     d=w;
	 }
     
     }
     
}
printf("%d %d %d",xin,max,d);

}
	
