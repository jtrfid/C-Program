#include<stdio.h>
int main(){
	int n,a,b,c[416],cc[416],C,CC,d,e[416],E,i,j=1;
	//n����ab��������c��Ʊ����eͳ��CE��� 
	e[0]=0;
	scanf("%d%d%d",&n,&a,&b);
	for(i=0;i<n;i++)
	scanf("%d",&c[i]);
	for(i=0;i<n;i++)
	cc[i]=c[i];
	for(i=0;i<n;i++)
	{
		if(c[i]%10==a||c[i]%10==b)
		do
		{
			d=c[i]%10;
			if(d==a||d==b) e[j]++;
			c[i]=c[i]/10;
		}
		while(c[i]!=0);
		if(e[j]>e[j-1])
		{
			C=cc[i];
			E=e[j];
		} 
		j++;
		e[j]=0;
	}
	CC=C;
	i=1;
	do
	{
		CC=CC/10;
		i++;
	}
	while(CC!=0);
	printf("%d %d %d",C,E,i);
	return 0;
}
