# include<stdio.h>
int main()
{
	long int n;
	int day,h,min,s;
	scanf("%d",&n);
	if(n<60) printf("0:0:%d",n);
	if(n>=60&&n<3600)
	{
	min=n/60;
	s=n-min*60;
	printf("0:%d:%d",min,s);
    }
    if(n>=3600&&n<86400)
    {
    h=n/3600;
    min=(n-h*3600)/60;
    s=n-h*3600-min*60;
    printf("%d:%d:%d",h,min,s);
    }
    if(n>=86400)
    {
    day=n/86400;
    h=(n-day*86400)/3600;
    min=(n-day*86400-h*3600)/60;
    s=n-day*86400-h*3600-min*60;
    printf("%d %d:%d:%d",day,h,min,s);
    }
return 0;
}
