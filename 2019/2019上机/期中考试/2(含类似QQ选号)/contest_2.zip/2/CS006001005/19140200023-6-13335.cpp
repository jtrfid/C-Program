#include<stdio.h>
int main(){
	int n,d,h,m,s,t;
	scanf("%d",&n);
    if(n/86400==0){
         
		 h=n/3600;
         t=n-3600*h;
         if(t>0){
         
		 m=t/60;
		 if(t-60*m>0){
		 
		 {
		 	s=t-60*m;
		 }
		 printf("%d %d %d",h,m,s);
		 }
		 else{
		 	printf("%d",h);}
		 }
         
	}
	else{
		d=n/86400;
		if(n-n/86400>0){
	
		
		h=(n-86400*n)/3600;
		  }
		else{
			printf("%d %d",d);
		}
		if(n-n*86400-3600*h>0)
		{
			m=(n-86400*n-3600*h)/60;
			printf("%d %d %d",d,h,m);
		}
		else{
			printf("%d %d %d",d,h);
		}
		if(n-n*86400-3600*h-60*m>0)
		{

		printf("%d %d %d %d",d,h,m,s);}
		else{
		printf("%d %d %d",d,h,m);
		}
	}
	
	return 0;	
}
