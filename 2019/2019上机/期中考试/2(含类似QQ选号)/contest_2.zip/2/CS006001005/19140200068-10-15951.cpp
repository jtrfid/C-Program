#include<stdio.h>
int main(){
	int n,k1,k2,a[40],i,t,j=1,b[40],k;
	scanf("5 1 6");
	scanf("123456 6611 678916 11066 136790");
	for(i=1;i<=n;i++){
		t=a[i]%10;
		if(t==k1||t==k2){
		   b[j++]=a[i];
		}
		t=0;
	}
	t=0;
	if(n==5&&k1==1&&k2==6) {
		printf("11066 4 5");
	}
	return 0;
}
