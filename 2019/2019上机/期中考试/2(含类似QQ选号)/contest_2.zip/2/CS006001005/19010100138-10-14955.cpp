#include<stdio.h>
int main(){
	int a,i,c,d[20],b,e,m,f;int g[20]={0},h[20]={0};
	scanf("%d %d %d",&a,&b,&c);
	for(i=0;i<a;i++)
	scanf("%d",&d[i]);
	for(i=0;i<a;i++)
	{for(m=d[i];m!=0;m=m/10) {f=m%10;g[i]++;if(f==b||f==c) h[i]++;}}
	for(i=0;i<a;i++)
	 {for(e=0;e<a-1;e++){
	 if(h[e]<h[e+1])
	  {d[e]=d[e+1];h[e]=h[e+1];g[e]=g[e+1];}
	  else continue;}}
	for(i=0;i<a;i++)
	 {for(e=0;e<a-1;e++)
	 {if(g[e]<g[e+1]) 
	 {d[e]=d[e+1];h[e]=h[e+1];g[e]=g[e+1];}
	  else continue;}}
	 printf("%d %d %d",d[0],h[0],g[0]);
	
	
