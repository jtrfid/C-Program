#include <stdio.h>
int main(){
	int n,k1,k2,a[20],i,j,c[20][10],b[20],d[20],e[20]={0},t;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<=n-1;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	for(j=0;j<=n-1;j++)
	{
		for(i=0;;i++)
		{
			c[j][i]=b[j]%10;
			b[j]=b[j]/10;
			if(b[j]==0)
			{
				d[j]=i+1;break;
			}
		}
	}
	for(j=0;j<=n-1;j++)
	{
		if(a[j]%10==k1||a[j]%10==k2)
		{
			for(i=0;i<d[j];i++)
			{
				if(c[j][i]==k1||c[j][i]==k2)
				{
					e[j]++;
				}
			}
		}
	}
	for(j=0;j<=n-1;j++)
	{
		if(e[j]<e[j+1])
		{
			t=e[j];
			e[j]=e[j+1];
			e[j+1]=t;
			t=a[j];
			a[j]=a[j+i];
			a[j+1]=t;
			t=d[j];
			d[j]=d[j+1];
			d[j+1]=t;
		}
		if(e[j]==e[j+1])
		{
			if(d[j]<d[j+1])
			{
				t=d[j];
				d[j]=d[j+1];
				d[j+1]=t;
			}
		}
	}
	printf("%d %d %d",a[0],e[0],d[0]);
	return 0;
}
