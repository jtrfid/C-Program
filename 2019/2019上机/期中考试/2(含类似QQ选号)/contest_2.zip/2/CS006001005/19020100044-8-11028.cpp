#include<stdio.h>
int main(){
	int a,b,c=0,i,s,j;
	scanf("%d",&a);
	while(a>0){
		b=a*a;
		c=c+b;
		a--;
	}
	printf("%d",c);
	return 0;
}
