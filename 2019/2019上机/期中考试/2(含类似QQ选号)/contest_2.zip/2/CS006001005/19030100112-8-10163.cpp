#include<stdio.h>
int main()
{
	int n,d=0,i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		j=i*i;
		d+=j;
	}
	printf("%d",d);
	return 0;
}
