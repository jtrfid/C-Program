#include<stdio.h>
int main(){
	int n,d,h,s,m;
	scanf("%d",&n);
	d=n/84600;
	h=(n-d*84600)/3600;
	m=(n-d*84600-3600*h)/60;
	s=(n-d*84600-3600*h-60*m);
	if(d=0){
		printf("%d:%d:%d",h,m,s);
	}
	else {
		printf("%d %d:%d:%d",d,h,m,s);
	}
	return 0;
}
