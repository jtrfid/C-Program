#include<stdio.h>
int main(){
	int n,a,b,c,d;
	scanf("%d",&n)
	if(n>=86400){
		a=n%86400;
		b=(n-a*86400)%3600;
		c=(n-a*86400-b*3600)%60;
		d=n-a*86400-b*3600-c*60;
		printf("%d %d:%d:%d",a,b,c,d);} 
    else {
		a=n%3600;
		b=(n-a*3600)%60;
		c=n-a*3600-b*60;
		printf("%d:%d:%d",a,b,c);}
	return 0;
}
