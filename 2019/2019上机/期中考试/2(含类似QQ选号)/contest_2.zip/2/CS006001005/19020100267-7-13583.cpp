#include<stdio.h>
int main(){
	int l,s,zs,cs;
	char c;
	float k,n;
	scanf("%c %d %d",&c,&l,&s);
		if(c=='A') cs=2000;
	    if(c=='B') cs=1200;
	    if(c=='C') cs=500;
	zs=cs+(s+200*(l-1))*26;
	if(zs<=5000)  k=0.0;
	else if(zs<=8000)	k=(zs-5000)*0.03;	
	else if(zs<=17000)  k=90+(zs-8000)*0.1;
	else if(zs<=30000)  k=990+(zs-17000)*0.2;
	else if(zs<=40000)  k=990+13000*0.2+(zs-30000)*0.25;
	else if(zs<=60000)  k=990+13000*0.2+2500+(zs-40000)*0.3;
	else if(zs<=85000)  k=990+13000*0.2+2500+6000+(zs-60000)*0.35;
	else k=990+13000*0.2+2500+6000+25000*0.35+(zs-85000)*0.45;
	n=zs-k;
	printf("%.2f %.2f",k,n);
	return 0;
	
}
