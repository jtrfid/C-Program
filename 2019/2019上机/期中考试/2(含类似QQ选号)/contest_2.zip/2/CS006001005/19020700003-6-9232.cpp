#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	if(n>=0&&n<24*60*60)
	printf("%d:%d:%d",n/3600,n%3600/60,n%60);
	else
	printf("%d %d:%d:%d",n/(24*3600),n%(24*3600)/3600,n%3600/60,n%60);
	return 0;
}
