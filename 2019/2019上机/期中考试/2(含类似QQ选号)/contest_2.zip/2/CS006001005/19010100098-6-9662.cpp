#include<stdio.h>
int main(){
	int n;
	int d,h,m,s;
	scanf("%d",&n);
    d=n/86400;
	h=n%86400/3600;
	m=n%86400%3600/60;
	s=n%86400%3600%60;
	if(n<86400)
	printf("%d:%d:%d",h,m,s);
	else
	printf("%d %d:%d:%d",d,h,m,s);
	return 0;
	
}
