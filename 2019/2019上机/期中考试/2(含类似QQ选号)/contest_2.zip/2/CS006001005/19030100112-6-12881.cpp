#include<stdio.h>
int main()
{
	int n,d=0,h,f,m,x=0;
	scanf("%d",&n);
	if(n>86400)
	{
		while(n>86400)
		{
			n=n-86400;
			d++;
		}
	for(m=0;m<60;m++)
	 for(f=0;f<60;f++)
	  for(h=0;h<24;h++)
	   if(h*3600+f*60+m==n)
	       printf("%d %d:%d:%d",d,h,f,m);
    }
    else
    {
    for(m=0;m<60;m++)
	 for(f=0;f<60;f++)
	  for(h=0;h<24;h++)
	   if(h*3600+f*60+m==n)
	       printf("%d:%d:%d",h,f,m);
    }
    return 0;
}
