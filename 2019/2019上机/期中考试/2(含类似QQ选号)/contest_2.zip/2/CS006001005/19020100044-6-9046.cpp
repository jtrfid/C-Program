#include<stdio.h>
int main(){
	int s,d,h,f,k;
	scanf("%d",&s);
	f=s/60;
	h=f/60;
	d=h/24;
	if(d>0){
		printf("%d %d:%d:%d",d,h,f,s);}
	else printf("%d:%d:%d",h,f,s);
	return 0;
}
