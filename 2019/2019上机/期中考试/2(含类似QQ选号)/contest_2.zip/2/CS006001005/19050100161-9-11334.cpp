#include<stdio.h>
int main()
{
	int m,n;
	int i,j,a,b,x=0,y=0;
	scanf("%d %d",&m,&n);
	if(m<n)
	{
		i=m;
		for(i=m;i>=1;i--)
		{
			x=m%i;
			y=n%i;
			if(x==0&&y==0)
			{
				printf("%d ",i);
				break;
			}
		}
	}
	else
	{
		i=n;
		for(i=n;i>=1;i--)
		{
			x=m%i;
			y=n%i;
			if(x==0&&y==0)
			{
				printf("%d ",i);
				break;
			}
		}
	}
	if(m>n)
	{
		i=m;
		for(i=m;i<=100000;i++)
		{
			a=i%m;
			b=i%n;
			if(a==0&&b==0)
			{
				printf("%d",i);
				break;
			}
		}
	}
	else
	{
		i=n;
		for(i=n;i<=100000;i++)
		{
			a=i%m;
			b=i%n;
			if(a==0&&b==0)
			{
				printf("%d",i);
				break;
			}
		}
	}
	return 0;
}
