#include<stdio.h>
int main(){
	int a,b,c,i,n,j,k,max,min;
	scanf("%d %d",&a,&b);
	if(a>b){
	j=a;
	k=b;}
	else{
	j=b;
	k=a;
	}
	for(i=k;i>0;i--){
		if(j%i==0&&k%i==0){
			max=i;
		 break;}
	}
	for(c=j;c<=j*k;c++){
		if(c%j==0&&c%k==0){
		min=c; break;}
	}
	printf("%d %d",max,min);
	return 0;
}
