#include<stdio.h>
int main(){
	int a,b,c,i,s,p,j,k=0,s1,h,len=0,le=0;
	scanf("%d %d %d",&a,&b,&c);
    for(i=0;i<a;i++){
    	scanf("%d",&j);
    	 s=j%10;
    	 p=j;
    	if(s==b||s==c){
    	while(j>0){
    	  s=j%10;
		  j=j/10;
		  if(s==b||s==c) len++;
		  le++;	
    	}
    	if(len>k){
    		k=len;
			h=le;
			s1=p;	
    	}
    	if(len==k){
    		if(le>h){
    			h=le;
    			s1=p;
    		}
    	} 
    	len=0;
    	le=0;	
    }
    else continue;}
    printf("%d %d %d",s1,k,h);
	return 0;
}
