#include<stdio.h>
int main(){
	int n,s1,s2,m1,m2,h1,h2,d1; 
	scanf("%d",&n);
	s1=n%60;
	s2=n/60;
	m1=s2%60;
	m2=s2/60;
	h1=m2%24;
	h2=m2/24;
	if(h2==0) printf("%d:%d:%d",h1,m1,s1);
	else printf("%d %d:%d:%d",h2,h1,m1,s1);
	return 0;
}
