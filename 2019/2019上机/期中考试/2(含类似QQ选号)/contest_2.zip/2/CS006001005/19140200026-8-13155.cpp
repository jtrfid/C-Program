#include<stdio.h>
int main(){
	int i,n,m,sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
			m=i*i;
			sum+=m;
			}
	printf("%d",sum);
	return 0;
}
