#include<stdio.h>
int main()
{   int n,d,h,m,s;
    scanf("%d",&n);
    if(n<86400)
    {   h=n/3600;
        n=n-h*3600;
        m=n/60;
        s=n-m*60;
        printf("%d:%d:%d\n",h,m,s);  }
     if(n=86400)   {  printf("1 0:0:0\n"); }
	 if(n>86400) 
	 {  d=n/86400;
	    n=n-d*86400;
	    h=n/3600;
	    n=n-h*3600;
	    m=n/60;
	    s=n-m*60;
	    printf("%d %d:%d:%d\n",d,h,m,s);  }
	  return 0;
}
	    
	    
        
    
	     

