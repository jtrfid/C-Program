#include<stdio.h>
int main()
{
	int n,i,a=1,b=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		a=i*i;
		b+=a;
	}
	printf("%d",b);
	return 0;
}
