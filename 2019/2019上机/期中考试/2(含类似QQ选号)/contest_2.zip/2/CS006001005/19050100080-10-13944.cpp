#include <stdio.h>
int main(){
	int k1,k2,n,i,x;
	int a[21],b[21]={0},wei[21]={0};
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		x=a[i];
		if(x%10==k1||x%10==k2) {	
			while(x!=0){
				wei[i]++;
				if(x%10==k1||(x%10==k2)) b[i]++;
				x=x/10;
			}
		}
	}
	int q=a[0],w=b[0],e=wei[0];
	
	for(i=1;i<n;i++){
		if(b[i]>w)  {
			q=a[i];
			w=b[i];
			e=wei[i];
		}
		if(b[i]==w&&wei[i]>e){
			q=a[i];
			w=b[i];
			e=wei[i];
		}
	}
	
	
	printf("%d %d %d",q,w,e);
	return 0;
}
