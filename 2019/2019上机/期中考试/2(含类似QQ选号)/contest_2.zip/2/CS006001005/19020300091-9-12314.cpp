#include<stdio.h>
int main(){
	int a,b,i,min,max,c;
	scanf("%d%d",&a,&b);
	c=a*b;
	if(a>b){
		max=a;
		min=b;
	}
	else{
		max=b;
		min=a;
	}
    for(i=min;i>0;i--){
		if(a%i==0&&b%i==0){
			printf("%d ",i);break;
		}
	}
	for(i=max;i<=c;i++){
		if(i%a==0&&i%b==0){
			printf("%d",i);break;
		}
	}
	return 0;
}
