#include<stdio.h>
int main(){
	int n,a,b,c,d;
	scanf("%d",&n);
	if(n<86400){
		b=n/(60*60);
		c=(n-b*60*60)/60;
		d=n-b*3600-c*60;
		printf("%d:%d:%d",b,c,d);
	}
	else{
		a=n/(60*60*24);
		b=(n-a*3600*24)/(60*60);
		c=(n-a*3600*24-b*3600)/(60);
		d=n-a*3600*24-b*3600-c*60;
		printf("%d %d:%d:%d",a,b,c,d);
	}
	return 0;
}
