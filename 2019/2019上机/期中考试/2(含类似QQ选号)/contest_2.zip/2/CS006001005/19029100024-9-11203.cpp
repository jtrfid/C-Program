#include<stdio.h>
#include<math.h>

int main(){
	int m,n;
	int i,min,max;
	int yue,bei;
	yue=1;
	bei=1;
	scanf("%d%d",&m,&n);
	if(m<=n)
	{
	min=m;max=n;}
	else
	{
	min=n;max=m;}
	for(i=min;i>0;i--)
	{if(m%i==0&&n%i==0)
	 {
	 yue=i;
	 break;}
		
		
		
	}
	for(i=1;i<=min;i++)
	{if((max*i)%min==0)
	 {bei=max*i;
	 break;}
	}
	
	
	
	printf("%d %d",yue,bei);
	return 0;
	
	
	
	
	
	
}
