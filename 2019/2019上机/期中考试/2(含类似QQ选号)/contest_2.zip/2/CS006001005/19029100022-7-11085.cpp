# include<stdio.h>
int main()
{
	char c;
	int l,s;
	double shui=0,pay=0;
	scanf("%c%d%d",&c,&l,&s);
	if(l==1) pay=26*s;
	else if(l>1) pay=26*((l-1)*200+s);
	if(c==65) pay=pay+2000;
	else if(c==66) pay=pay+1200;
	else if(c==67) pay=pay+500;
	if(pay>=1&&pay<=5000) shui=0;
	else if(pay>=5001&&pay<=8000) shui=pay*0.03;
	else if(pay>=8001&&pay<=17000) shui=90+(pay-8000)*0.1;
	else if(pay>=17001&&pay<=30000) shui=90+900+(pay-17000)*0.2;
	else if(pay>=30001&&pay<=40000) shui=90+900+2600+(pay-30000)*0.25;
	else if(pay>=40001&&pay<=60000) shui=90+900+2600+2500+(pay-40000)*0.3;
	else if(pay>=60001&&pay<=85000) shui=90+900+2600+2500+6000+(pay-60000)*0.35;
	else if(pay>85000) shui=90+900+2600+2500+6000+8750+(pay-85000)*0.45;
	pay=pay-shui;
	printf("%.2f %.2f",shui,pay);
	return 0;
}
