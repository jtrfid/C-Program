#include<stdio.h>
int main()
{
	int a,b,c,d,m,n,i;
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		a=n;
	}
	else
	{
		a=m;
	}
	for(i=a;i>=1;i--)
	{
		b=m%i;c=n%i;
		if(b==0&&c==0)
		{
			break;
		}
	}
	d=m*n/i;
	printf("%d %d",i,d);
	return 0;
}
