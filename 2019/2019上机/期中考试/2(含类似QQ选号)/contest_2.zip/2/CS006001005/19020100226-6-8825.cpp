#include<stdio.h>
int main(){
	int n,day,hr,min,sec;
	scanf("%d",&n);
	day=n/86400;
	n=n%86400;
	hr=n/3600;
	n=n%3600;
	min=n/60;
	n=n%60;
	sec=n;
	if(day==0) printf("%d:%d:%d\n",hr,min,sec);
	else printf("%d %d:%d:%d\n",day,hr,min,sec);
	return 0;
	
}
