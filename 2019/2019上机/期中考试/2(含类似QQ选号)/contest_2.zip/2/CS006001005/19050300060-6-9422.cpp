#include<stdio.h>
int main()
{
	int d,h,m,s,n;
	scanf("%d",&n);
	d=n/86400;
	if(d<1){
		h=n/3600;
		m=(n-3600*h)/60;
		s=n-h*3600-60*m;
		printf("%d:%d:%d",h,m,s);
	}
	if(d>=1){
		h=(n-86400*d)/3600;
		m=(n-86400*d-3600*h)/60;
		s=n-86400*d-3600*h-60*m;
		printf("%d %d:%d:%d",d,h,m,s);
	}
	return 0;
} 
