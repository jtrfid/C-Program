#include<stdio.h>

int main(){
	int n,a,b;int w;
	scanf("%d%d%d",&n,&a,&b);
	int ma[20]={0};
	int shu[9]={0};
	int wei[20]={0};
	int ci[20]={0};
	int xin;
	int i,j;
	int k;
	for(i=0;i<n;i++)
	{scanf("%d",&ma[i]);
	w=ma[i];
	 for(j=0;j<9;j++)
     	{
		 shu[j]=w%10;
     	 if(shu[j]==a||shu[j]==b)
     	 {ci[i]=ci[i]+1;
     	 }
     	 if(w!=0)
     	 {wei[i]=wei[i]+1;}
     	 w=w/10;
     	}
	}
	xin=0;
	while(ma[xin]%10!=a&&ma[xin]%10!=b)
	{xin=xin+1;
	
	}
	for(i=1;i<n;i++)
	{
	
      if(ma[i]%10==a||ma[i]%10==b)	
	{if(ci[i]>ci[xin])
	     xin=i;
	 if(ci[i]==ci[xin])
	    {if(wei[i]>wei[xin])
	       xin=i;
	    else
	       xin=xin;
	    }
	 if(ci[i]<ci[xin])
	    xin=xin;}
	  else
	  xin=xin;
	}
	if(ma[xin]==0)
	{ci[xin]=1;
	wei[xin]=1;
	}
	else if(a==0||b==0)
	ci[xin]=ci[xin]-1;
	
	printf("%d %d %d\n",ma[xin],ci[xin],wei[xin]);
	return 0;
	
	
	
	
	
	
	
}
