#include <stdio.h>
int main()
{
	int m,n,i,s,w;
	scanf("%d %d",&m,&n);
	if(n<m){
	for(i=1;i<=n;i++)
     if(n%i==0&&m%i==0)s=i;}
    else {for(i=1;i<=m;i++)
     if(n%i==0&&m%i==0)s=i;}
     w=(m/s)*(n/s)*s;
     printf("%d %d",s,w);
     return 0;
}
