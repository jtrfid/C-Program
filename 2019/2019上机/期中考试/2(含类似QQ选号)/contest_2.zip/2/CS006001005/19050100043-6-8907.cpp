#include<stdio.h>
int main(){
	int n,d,h,m,s;
	scanf("%d",&n);
	d=n/86400;
	h=n/3600-d*24;
	m=n/60-h*60-d*24*60;
	s=n-m*60-h*3600-d*86400;
	if(d>0)
	printf("%d %d:%d:%d",d,h,m,s);
	if(d==0)
	printf("%d:%d:%d",h,m,s);
}
