#include<stdio.h>
int main()
{
	int n,d,h,m,s;
	scanf("%d",&n);
	d=n/(60*60*24);
	if(d==0)
	{
		h=n/(60*60);
		m=(n-h*60*60)/60;
		s=n-h*60*60-m*60;
		printf("%d:%d:%d",h,m,s);
	}
	else
	{
		h=(n-d*60*60*24)/(60*60);
		m=(n-d*60*60*24-h*60*60)/60;
		s=n-d*60*60*24-h*60*60-m*60;
		printf("%d %d:%d:%d",d,h,m,s);
	}
	return 0;
}
