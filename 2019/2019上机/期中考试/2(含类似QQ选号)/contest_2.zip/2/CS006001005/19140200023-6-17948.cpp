#include<stdio.h>
int main(){
	int n,a,b,c,d,e,f,g,s;
	scanf("%d",&n);
	c=n/60;
	s=n%60;
	e=c%60;
	e=c%60;
	f=d/24;
	g=d%24;
	if(n<=0){
		printf("%d:%d:%d",g,e,s);
	}
	else{
		printf("%d %d:%d:%d",f,g,e,s);
	}
	return 0;
}
