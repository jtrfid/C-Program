#include<stdio.h>
int main(){
	int s,d,h,f,k=0,i; float sum1,sum2,sum3,sum4; char a1;
	scanf("%c %d %d",&a1,&s,&h);
	sum1=h+200*(s-1);
	sum2=sum1*26;
	if(a1=='A') sum3=sum2+2000;
	else if(a1=='B') sum3=sum2+1200;
	else if(a1=='C') sum3=sum2+500;
	if(sum3>85000) sum4=sum3-3000*0.03-9000*0.1-2600-2500-6000-25000*0.35-(sum3-85000)*0.45;
    else if(sum3>60000) sum4=sum3-3000*0.03-9000*0.1-2600-2500-6000-(sum3-60000)*0.35;
    else if(sum3>40000) sum4=sum3-3000*0.03-9000*0.1-2600-2500-(sum3-40000)*0.30;
    else if(sum3>30000) sum4=sum3-3000*0.03-9000*0.1-2600-(sum3-30000)*0.25;
    else if(sum3>17000) sum4=sum3-3000*0.03-9000*0.1-(sum3-17000)*0.20;
    else if(sum3>8000) sum4=sum3-3000*0.03-(sum3-8000)*0.10;
    else if(sum3>5000) sum4=sum3-(sum3-5000)*0.03;
    else k=1;
    if(k==1)
    printf("0.00 %.02f",sum3);
    else printf("%.02f %.02f",sum3-sum4,sum4);
	return 0;
}
