#include <stdio.h>
int main()
{int n,a,b,c,d;
 scanf("%d",&n);
 a=n/86400;
 b=(n-a*86400)/3600;
 c=(n-a*86400-b*3600)/60;
 d=n-a*86400-b*3600-c*60;
 if(a==0)
 printf("%d:%d:%d",b,c,d);
 else
 printf("%d %d:%d:%d",a,b,c,d);
 return 0;
}
