#include<stdio.h>
int main(){
	int n,d,h,m,s,t;
	scanf("%d",&n);
	d=n/86400;
	t=n%86400;
	h=t/3600;
	t=t%3600;
	m=t/60;
	s=t%60;
	if(d>0) printf("%d %d:%d:%d",d,h,m,s);
	else printf("%d:%d:%d",h,m,s);
	return 0;
}
