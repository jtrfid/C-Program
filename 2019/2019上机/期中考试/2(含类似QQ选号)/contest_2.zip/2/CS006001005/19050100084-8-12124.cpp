#include<stdio.h>
int main(){
	int n,a,i;
	scanf("%d",&n);
	a=0;
	for(i=1;i<=n;i++){
		a=a+i*i;
	}
	printf("%d",a);
	return 0;
} 
