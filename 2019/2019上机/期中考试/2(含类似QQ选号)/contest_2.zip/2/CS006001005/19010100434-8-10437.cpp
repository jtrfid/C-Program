#include<stdio.h>
int main()
{
	int i,j,k,sum=0,n;
	scanf("%d",&n);
	for(i=n;i>=1;i--)
	{
		sum=sum+i*i;
	}
	printf("%d",sum);
	return 0;
}
