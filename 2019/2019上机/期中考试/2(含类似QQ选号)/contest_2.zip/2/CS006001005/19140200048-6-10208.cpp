#include<stdio.h>
int main()
{
	int n,d=0,h=0,m=0,s,t;
	scanf("%d",&n); 
	s=n%60;
	t=n/60;
	if(t>0) m=t%60;
	t=t/60;
	if(t>0) h=t%24;
	t=t/24;
	if(t>0) d=t%24;
	if(d==0) 
	printf("%d:%d:%d",h,m,s);
	if(d!=0) 
	printf("%d %d:%d:%d",d,h,m,s);
	
	return 0;
}
