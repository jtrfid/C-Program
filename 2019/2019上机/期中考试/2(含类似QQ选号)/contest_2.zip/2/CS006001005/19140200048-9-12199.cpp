#include<stdio.h>
int main()
{
	int m,n,i;
	scanf("%d %d",&m,&n);
	for(i=m;i>=1;i--)
	if(m%i==0&&n%i==0){
	printf("%d ",i);
	break;	
	}
  	for(i=m;i>1;i++)
	if(i%m==0&&i%n==0){
	printf("%d ",i);
	break;	
	}
	return 0;
}
