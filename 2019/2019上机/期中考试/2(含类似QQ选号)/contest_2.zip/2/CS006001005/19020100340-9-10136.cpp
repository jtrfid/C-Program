#include<stdio.h>
int main()
{     int m,n,i,j,k,temp;
      scanf("%d %d",m,n);
      if(m>n)
	    {  temp=m;   m=n;    n=temp; }
	  for(i=m;i>=1;i--)
	    {  if(m%i==0)
	          {  if(n%i==0)
		          {  j=i;   break;}  }  } 
	 for(i=n;;i++)
	    {   if(i%m==0)
		       {  if(i%n==0)
	             {  k=i;  break; }  } 	}  
	printf("%d %d\n",j,k);
	return 0;
}
      

