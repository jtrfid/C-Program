#include<stdio.h>
int main()
{int a,b,c,d;
scanf("%d",&a);
b=a/60;a=a-b*60;
c=b/60;b=b-c*60;
d=c/24;c=c-d*24;
if(d>0) printf("%d %d:%d:%d",d,c,b,a);
if(d==0) printf("%d:%d:%d",c,b,a);
return 0;
	

}
