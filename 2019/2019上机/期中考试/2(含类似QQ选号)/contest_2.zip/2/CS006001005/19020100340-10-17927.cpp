#include<stdio.h>
int main()
{  int k1,k2,n,i,a[21],count,temp,h,d=0,e,f,sum;
   scanf("%d %d %d",&n,&k1,&k2);
   for(i=0;i<n;i++)   {  scanf("%d",&a[i]); }
   for(i=0;i<n;i++)
     {     if(((a[i]-k1)%10==0) || ((a[i]-k2)%10==0))
              {   temp=a[i];  sum=0;   count=0;
                  while(temp!=0)
                    {   h=temp%10;
                          if(h==k1 || h==k2)    {count=count+1;}
                        sum=sum+1;
                        temp=temp/10;  }
                        if(count>d)  {  d=count;  e=sum;   f=a[i];}      }    }
  printf("%d %d %d\n",f,e,d);
  return 0;
}
     
                  
				        
               
     
    

