#include<stdio.h>
#include<math.h>
int main(){
	int n,i,num=0,k,min,m,num1;
	scanf("%d %d",&n,&m);
	min=n;
	if(m<n) min=m;
	for(i=2;i<=min;i++){
		if(n%i==0&&m%i==0) num=i;
		}
	for(i=min;i<=m*n;i++){
			if(i%n==0&&i%m==0) {
				num1=i;
				break;
				}
		}
	printf("%d %d",num,num1);
}
