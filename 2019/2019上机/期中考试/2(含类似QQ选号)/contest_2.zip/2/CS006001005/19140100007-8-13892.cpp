#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	c=0;
	b=a;
	for(int t=a;t>=1;t--)
	{
		c=c+(b*b);
		b=b-1;}

	printf("%d",c);
	return 0;
}
