#include<stdio.h>
int main()
{
	float l,s,shui,qian,m1,m2,money;
	char c;
	scanf("%c %f %f",&c,&l,&s);
	if(c=='A'){
		m1=2000;
	}
	if(c=='B'){
		m1=1200;
	}
	if(c=='C'){
		m1=500;
	}
	m2=(s+(l-1)*200)*26;
	qian==m1+m2;
	if(qian<=5000){
		shui=0;
	}
	if(qian>5000&&qian<=8000){
		shui=(qian-5000)*0.03;
	}
	if(qian>8000&&qian<=17000){
		shui=(qian-8000)*0.1+90;
	}
	if(qian>17000&&qian<=30000){
		shui=990+(qian-17000)*0.2;
	}
	if(qian>30000&&qian<=40000){
		shui=990+2600+(qian-30000)*0.25;
	}
	if(qian>40000&&qian<=60000){
		shui=990+2600+2500+(qian-40000)*0.3;
	}
	if(qian>60000&&qian<=85000){
		shui=990+2600+2500+6000+(qian-60000)*0.35;
	}
	if(qian>85000){
		shui=990+2600+2500+6000+8750+(qian-85000)*0.45; 
	}
	money=qian-shui;
	printf("%.2f %.2f",shui,money);
	return 0;
} 
