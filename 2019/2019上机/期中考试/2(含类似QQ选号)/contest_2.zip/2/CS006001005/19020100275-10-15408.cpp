#include<stdio.h>
int main(){
	int k1,k2,n,count=0,num,i,j,t,choice=0,max=0,ws=0;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++){
		scanf("%d",&num);
		if(num%10==k1||num%10==k2){
			for(j=0,t=num;t>0;t=t/10,j++){
				if(t%10==k1||t%10==k2) count++;
			}
			if(count>max){
				max=count;
				choice=num;
				ws=j;
			}
			if(count==max&&j>ws){
				ws=j;
				choice=num;
			}
			count=0;
		}
	}
	printf("%d %d %d",choice,max,ws);
	return 0;
}
