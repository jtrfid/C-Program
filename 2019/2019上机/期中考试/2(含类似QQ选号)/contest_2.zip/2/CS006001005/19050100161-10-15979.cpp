#include<stdio.h>
int main()
{
	int a,b,c,i,x[20],m=0,n=0,y[20],t=0,j,e,f=0,h=0,k=0,l;
	scanf("%d %d %d",&a,&b,&c);
	for(i=0;i<a;i++)
	{
		scanf("%d",&x[i]);
	}
	for(i=0;i<a;i++)
	{   
	    y[i]=0;
		while(1)
		{   
			m=x[i]%10;
			x[i]=x[i]/10;
			if(m==b||m==c)
			{
				y[i]++;
			}
			if(m==0)
			break;
		}
	}
	for(j=0;j<a;j++)
	{   
		if(y[j]>t)
		{
			t=y[j];
			h=j;
		}
	}
	for(j=0;j<a;j++)
	{
		if(y[j]=t)
		{
			k++;
		}
	}
	l=h;
	while(1)
	{
		e=x[h]%10;
		x[h]/10;
		if(e!=0)
		{
			f++;
		}
		if(e==0)
		break;
	}
	printf("%d %d %d",x[l],y[0],f);
	return 0;
}
