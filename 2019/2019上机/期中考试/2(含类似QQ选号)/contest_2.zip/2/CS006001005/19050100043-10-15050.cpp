#include<stdio.h>
int wei(int x){
int w=0;
while(x!=0){
	x=x/10;
	w++;
}
return w;}
int mo(int x){
	int z;
	z=x%10;
	return z;
}
int main(){
	int l,f,i,max,j=0,g=0,n,k1,k2,a[20],b[20],c[20],d[20];
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++){
	scanf("%d",&a[i]);
	b[i]=wei(a[i]);
	c[i]=mo(a[i]);
	if(c[i]==k1||c[i]==k2){	
	d[j]=i;j++;}}
	if(j==1){l=a[d[0]];
	while(l!=0){
		f=l%10;
		if(f==k1||f==k2)
		g++;
		l=l/10;
	}}
	printf("%d %d %d",a[d[0]],g,b[d[0]]);
	if(j>1)
	{
		for(i=0;i<j-1;i++)
		{if(b[d[i]]>b[d[i+1]])
		max=d[i];
		else max=d[i+1];
		}
		
		while(a[max]!=0){
		f=a[max]%10;
		if(f==k1||f==k2)
		g++;
		a[max]=a[max]/10;
	}
	printf("%d %d %d",a[max],g,b[max]);	
	}
}
