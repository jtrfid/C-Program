#include<stdio.h>
int main()
{
	int m,n,max=1,min,i;
	scanf("%d",&m);
		scanf("%d",&n);
		min=m*n;
		for(i=1;i<=m&&i<=n;i++)
		{
			if(m%i==0&&n%i==0)
			{
				max=i;
			}
		}
		for(i=m*n;i>=m&&i>=n;i--)
		{
			if(i%m==0&&i%n==0)
			{
				min=i;
			}
		}
		printf("%d %d",max,min);
		return 0;
}
