#include<stdio.h>
int main()
{
	int n,m,j,i,a,b;
	scanf("%d %d",&m,&n);
	for(i=m;i>0;i--)
	{
		if(m%i==0&&n%i==0) 
		{
			a=i;break;
		}
	}
	for(i=m;i<100000;i++)
	{
		if(i%m==0&&i%n==0)
		{
			b=i;break;
		}
	}
	printf("%d %d",a,b);
	return 0;
}
