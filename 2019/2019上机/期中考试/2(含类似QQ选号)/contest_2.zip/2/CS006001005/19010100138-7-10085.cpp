#include<stdio.h>
int main()
{int b,c;char a; float d;
scanf("%c %d %d",&a,&b,&c);
c=c+200*(b-1);
d=c*26;
if(a=='A') d=d+2000;
if(a=='B') d=d+1200;
if(a=='C') d=d+500;
if(d<=5000) printf("0.00 %.2f",d);
if(d>5000&&d<=8000) printf("%.2f %.2f",0.03*d,0.97*d);
if(d>8000&&d<=17000) printf("%.2f %.2f",0.1*d,0.9*d);
if(d>17000&&d<=30000) printf("%.2f %.2f",0.2*d,0.8*d);
if(d>30000&&d<=40000) printf("%.2f %.2f",0.25*d,0.75*d);
if(d>40000&&d<=60000) printf("%.2f %.2f",0.3*d,0.7*d);
if(d>60000&&d<=85000) printf("%.2f %.2f",0.35*d,0.65*d);
if(d>85000) printf("%.2f %.2f",0.45*d,0.55*d);
return 0;
}
