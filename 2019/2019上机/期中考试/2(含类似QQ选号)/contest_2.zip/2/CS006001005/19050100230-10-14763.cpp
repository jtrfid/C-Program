#include<stdio.h>
int main(){
	int k1,k2,n,a[30],i,b[30],j,num,k,time=0,max,c=0,p[10],o=0,s=0,numb,z;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		num=a[i];
		for(j=0;num>0;j++){
			k=num%10;
			if(k==k1||k==k2) time++;
			num=num/10;
			b[i]=time;
		}
		time=0;
	}
	max=0;
	for(i=0;i<n;i++){
		if(b[i]>b[max]) {
		max=i;
		}
	}
	for(i=0;i<n;i++){
		if(b[i]==b[max]&&a[i]>a[max]) 
		max=i;
	}
	numb=a[max];
	for(i=0;numb>0;i++){
		numb=numb/10;
		s++;
	}
	printf("%d %d %d",a[max],b[max],s);

}
