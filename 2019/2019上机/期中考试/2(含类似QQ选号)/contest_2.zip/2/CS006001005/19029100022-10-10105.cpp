# include<stdio.h>
int main()
{
	int n,k1,i,k2,max=0,c=0,hao,b,num=0;
	long long int a[20];
	scanf("%d%d%d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	scanf("%ld",&a[i]);
	for(i=0;i<n;i++)
	{
	c=0;
	num=0;
	b=a[i];
	while(a[i]>0&&(a[i]%10==k1||a[i]%10==k2))
	c=c+1;
	a[i]=a[i]/10;
	num=num+1;
	if(c>max)
	{
	max=c;
	hao=b;
	}
	else if(c=max&&b>hao) hao=b;
    }
printf("%d %d %d",hao,max,num);
return 0;
} 
