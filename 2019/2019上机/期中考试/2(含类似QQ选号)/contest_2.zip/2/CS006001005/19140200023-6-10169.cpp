#include<stdio.h>
int main(){
	int n,d,h,m,s,t;
	scanf("%d",&n);
    if(n/86400==0){
         d=n/86400;
		 h=n/3600;
         t=n-3600*h;
         m=t/60;
         s=t-60*m;
         
	}
	else{
		d=n/86400;
		h=(n-86400*n)/3600;
		m=(n-86400*n-3600*h)/60;
		s=n-86400*n-3600*h-60*m;
	}
	printf("%d %d %d %d",d,h,m,s);
	return 0;	
}
