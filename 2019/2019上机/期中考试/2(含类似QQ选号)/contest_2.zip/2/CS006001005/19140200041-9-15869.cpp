#include<stdio.h>
int main()
{
	int m,n,i,a,b,c,d,g=1,f,z,flag=0;
	scanf("%d %d",&m,&n);
	if(m<n)
	{
		for(i=m;i>=2;i--)
		{
			a=m%i;
			b=n%i;
			if(a==0)
			{
			if(b==0)
			{
				g=i;
			    flag=1;
			    break;
			}
			}
			else
			 flag=0;
		}
        while(z!=0)
        {
        	i=n;
        	c=i%m;
        	d=i%n;
        	if(c==0 && d==0)
        	  {
        	  	f=i;
        	  	z=0;
        	  }
        	else
        	   z=1;
        	i++;
        }
    }
        else
        {
		for(i=n;i>=2;i--)
		{
			a=m%i;
			b=n%i;
			if(a==0)
			{
			if(b==0)
			{
				g=i;
			    flag=1;
			    break;
			}
			}
			else
			 flag=0;
		}
        while(z!=0)
        {
        	i=m;
        	c=i%m;
        	d=i%n;
        	if(c==0 && d==0)
        	  {
        	  	f=i;
        	  	z=0;
        	  }
        	else
        	   z=1;
        	i++;
        }
    }
        if(flag==1)
           printf("%d %d",g,f);
        else
           printf("%d %d",g,f);
        return 0;
}
