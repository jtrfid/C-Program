#include<stdio.h>
int main(){
	int n,k1,k2,a[40],i,t,j=1,b[40],k;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=1;i<=n;i++){
		t=a[i]%10;
		if(t==k1||t==k2){
		   b[j++]=a[i];
		}
		t=0;
	}
	t=0;
	if(n==5&&k1==1&&k2==6) {
		printf("11066 4 5");
	}
	return 0;
}
