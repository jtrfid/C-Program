#include<stdio.h>
int main()
{
	int n,k1,k2,a[20],i,b[20]={0},c[20]={0},j,t,x;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	 scanf("%d",a[i]);
	for(i=0;i<n;i++)
	{
	    while(a[i]!=0)
	  {
		x=a[i]%10;
		if(x!=k1||x!=k2) break;
		if(x==k1||x==k1) b[i]++;
		a[i]=a[i]/10;
		c[i]++;
	  }
    }
    for(i=0;i<n-1;i++)
    {
    	for(j=0;j<n-1-i;j++)
    	{
    		if(b[j]>b[j+1]) 
    		{
    			t=b[j];b[j]=b[j+1];b[j+1]=t;
    			t=a[j];a[j]=a[j+1];a[j+1]=t;
    			t=c[j];c[j]=c[j+1];c[j+1]=t;
    		}
    	}
    }
    printf("%d %d %d",a[n-1],b[n-1],c[n-1]);
    return 0;
}
