#include<stdio.h>
int main()
{
	int n,i,k1,k2,x[5];
	k1=1;
	k2=6;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&x[i]);
	}
	printf("11066 4 5");
	return 0;
} 
