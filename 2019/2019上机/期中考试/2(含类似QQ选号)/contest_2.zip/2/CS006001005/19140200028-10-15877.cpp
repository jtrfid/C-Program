#include<stdio.h>
int main()
{int n,k1,k2,i,h,t,m,g,j,k,s=0,w=0,h1;
scanf("%d%d%d",&n,&k1,&k2);
for(i=1;i<=n;i++)
{scanf("%d",&h);j=0;k=0;
t=h%10;if(t==k1||t==k2)
{for(m=h;m>0;)
{g=m%10;if(g==k1||g==k2){j++;}k++;m=m/10;}
if(j>s){s=j;w=k;h1=h;}
if(j==s){if(w<k){s=j;w=k;h1=h;}}}}
printf("%d %d %d",h1,s,w);
return 0;
}
