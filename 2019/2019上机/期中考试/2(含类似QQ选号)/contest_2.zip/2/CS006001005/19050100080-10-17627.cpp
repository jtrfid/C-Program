#include <stdio.h>
#include <stdlib.h>
int main(){
	long int k1=0,k2=10,n=0,i=0,x=0,y=0;
	long int a[21]={0},b[21]={0},wei[21]={0};
	scanf("%d %d %d",&n,&k1,&k2);
	if(k1!=k2){
	
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		x=a[i];
		if(x==0) b[i]++;
		if(x%10==k1||x%10==k2) {
			y=1;
			while(x!=0){
				wei[i]++;
				if((x%10==k1)||(x%10==k2)) b[i]++;
				x=x/10;
			}
		}
		else {
			y=0;			
			while(x!=0){
				wei[i]++;
				if((x%10==k1)||(x%10==k2)) b[i]++;
				x=x/10;
			}
		}
	}
	long int q=0,w=0,e=0;
	
	for(i=0;i<n;i++){
		if(y=1&&b[i]>w)  {
			q=a[i];
			w=b[i];
			e=wei[i];
		}
		if(y=1&&b[i]==w&&a[i]>q){
			q=a[i];
			w=b[i];
			e=wei[i];
		}
	}
	
	
	printf("%d %d %d\n",q,w,e);
 }
	return 0;
}
