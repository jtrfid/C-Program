#include<stdio.h>
int main(){
	int day,h,min,s;
	int n;
	scanf("%d",&n);
	day=n/(3600*24);
	h=n%(3600*24)/3600;
	min=n%(3600*24)%3600/60;
	s=n%(3600*24)%3600%60;
	if(day>=1) printf("%d %d:%d:%d",day,h,min,s);
	else printf("%d:%d:%d",h,min,s);
	return 0;
}
