#include<stdio.h>
int main ()
{   
     int a,n,k=0;
     scanf("%d",&a);
     for(n=1;n<=a;n++)
       k+=n*n;
       printf("%d",k);
	return 0;
}
