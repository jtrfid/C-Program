#include<stdio.h>
int main()
{
	int l,s,day;
	float kou,end,sum=0;
	char c;
	scanf("%c %d %d",&c,&l,&s);
	day=s+(l-1)*200;
	switch(c){
		case 'A':sum+=2000;break;
		case 'B':sum+=1200;break;
		case 'C':sum+=500;break;
	}
	sum+=day*26;
	if(sum<=5000)
	kou=0;
	else if(sum<=8000)
	kou=(sum-5000)*0.03;
	else if(sum<=17000)
	kou=3000*0.03+(sum-8000)*0.1;
	else if(sum<=30000)
	kou=3000*0.03+9000*0.1+(sum-17000)*0.2;
	else if(sum<=40000)
	kou=3000*0.03+9000*0.1+13000*0.2+(sum-30000)*0.25;
	else if(sum<=60000)
	kou=3000*0.03+9000*0.1+13000*0.2+10000*0.25+(sum-40000)*0.3;
	else if(sum<=85000)
	kou=3000*0.03+9000*0.1+13000*0.2+10000*0.25+20000*0.3+(sum-60000)*0.35;
	else
	kou=3000*0.03+9000*0.1+13000*0.2+10000*0.25+20000*0.3+25000*0.35+(sum-85000)*0.45;
	end=sum-kou;
	printf("%.2f %.2f",kou,end);
	return 0;
	
	
	
}
