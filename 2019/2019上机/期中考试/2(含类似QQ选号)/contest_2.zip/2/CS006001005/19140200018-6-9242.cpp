#include<stdio.h>
int main(){
	int d=0,h=0,m=0,s;
	scanf("%d",&s);
	while(s>=60)
	{ m++;s-=60;};
	while(m>=60)
	{h++;m-=60;
	}
	while(h>=24)
	{d++;h-=24;}
	if(d!=0)
	printf("%d %d:%d:%d",d,h,m,s);
	else printf("%d:%d:%d",h,m,s);
	return 0;
	
	 
}
