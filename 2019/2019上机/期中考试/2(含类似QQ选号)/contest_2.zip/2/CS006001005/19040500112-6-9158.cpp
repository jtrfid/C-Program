#include<stdio.h>
int main(){int t;
scanf("%d",&t);
int day,h,m,s;
	day=t/(24*60*60);
	h=(t-(24*60*60*day))/(60*60);
	m=(t-(24*60*60*day)-h*60*60)/60;
	s=t-(24*60*60*day)-h*60*60-m*60;
	
	if(day==0) printf("%d:%d:%d",h,m,s);
	else printf("%d %d:%d:%d",day,h,m,s);
	
	return 0;

}
