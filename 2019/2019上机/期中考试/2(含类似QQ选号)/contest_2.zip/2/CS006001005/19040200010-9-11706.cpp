#include<stdio.h>
int main ()
{   int a,b,n,k,i;
    scanf("%d%d",&a,&b);
     if(a<b) {k=a;a=b;b=k;}
     for(n=b;n>0;n--)
     {if(b%n==0&&a%n==0)break;}
     for(i=a;1;i++)
     {if(i%b==0&&i%a==0)break;}
     printf("%d %d",n,i);
	return 0;
}
