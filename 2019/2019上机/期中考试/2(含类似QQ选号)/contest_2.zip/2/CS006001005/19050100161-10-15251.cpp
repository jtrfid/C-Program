#include<stdio.h>
int main()
{
	int a,b,c,i,x[20],m=0,n=0,y[20],t=0,j,e,f=0,h=0;
	scanf("%d %d %d",&a,&b,&c);
	for(i=0;i<a;i++)
	{
		scanf("%d",&x[i]);
	}
	for(i=0;i<a;i++)
	{   
	    y[i]=0;
		while(1)
		{   
			m=x[i]%10;
			x[i]=x[i]/10;
			if(m==b||m==c)
			{
				y[i]++;
			}
			if(m==0)
			break;
		}
	}
	for(j=0;j<a-1;j++)
	{   
		if(y[j]<y[i+1])
		{
			t=y[i];
			y[i]=y[i+1];
			y[i+1]=t;
		}
	}
	
	printf("%d %d %d",x[h],y[0],f);
	return 0;
}
