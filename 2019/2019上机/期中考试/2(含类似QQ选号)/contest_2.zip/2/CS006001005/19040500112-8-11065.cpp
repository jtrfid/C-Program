#include<stdio.h>
int main(){
	int n;scanf("%d",&n);
	int i;int s=0;
	for(i=1;i<=n;i++)
	s=s+i*i;
	
	printf("%d",s);
	
	return 0;
}
