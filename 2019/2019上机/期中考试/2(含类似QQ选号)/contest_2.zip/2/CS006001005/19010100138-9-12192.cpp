#include<stdio.h>
int main(){
	int a,i,c,d,b;
	scanf("%d %d",&a,&b);
	if(a>b) {
	for(i=b;i>0;i--)
	 {if(b%i==0&&a%i==0) {c=i;break;}}
	 for(i=a;i<=a*b;i++)
	 if(i%a==0&&i%b==0) {d=i;break;}}
	 if(a<b) {
	for(i=a;i>0;i--)
	 {if(b%i==0&&a%i==0) {c=i;break;}}
	 for(i=b;i<=a*b;i++)
	 {if(i%a==0&&i%b==0) {d=i;break;}}}
	 if(a==b)
	 {c=a;d=a;}
	 printf("%d %d",c,d);}
	
	
