#include<stdio.h>
int main(){
	int n,d,h,m,s,od;
	scanf("%d",&n);
	od=24*3600;
	if(n<od) {
		h=n/3600,n%=3600;
		m=n/60,n%=60;
		s=n;printf("%d:%d:%d",h,m,s);
	}
	else {
		d=n/od,n%=od;
		h=n/3600,n%=3600;
		m=n/60,n%=60;
		s=n;printf("%d %d:%d:%d",d,h,m,s);
	}
	return 0;
}
