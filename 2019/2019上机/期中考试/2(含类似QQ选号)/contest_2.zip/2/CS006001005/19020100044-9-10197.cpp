#include<stdio.h>
int main(){
	int a,b,c,i,n,j,k;
	scanf("%d %d",&a,&b);
	if(a>b){
	j=a;
	k=b;}
	else{
	j=b;
	k=a;
	}
	for(i=k;i>0;i--){
		if(j%i==0) break;
	}
	for(c=j;c<=j*k;c++){
		if(c%j==0&&c%k==0) break;
	}
	printf("%d %d",i,c);
	return 0;
}
