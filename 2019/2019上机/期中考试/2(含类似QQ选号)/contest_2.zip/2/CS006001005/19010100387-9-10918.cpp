#include<stdio.h>
int main( )
{
	int m,n,t,i,s,q,w;
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		t=m;m=n;n=t;
	}
	for(i=1;i<=m;i++)
	{
		if(m%i==0&&n%i==0) s=i;
	}
	for(i=n;;i++)
	{
		if(i%m==0&&i%n==0) {q=i; break;}
	}
	printf("%d %d",s,q);
	return 0;
}
