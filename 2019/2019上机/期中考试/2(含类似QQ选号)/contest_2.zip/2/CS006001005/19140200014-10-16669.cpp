#include<stdio.h>
int main()
{
	int n,k1,k2,i;
	int q=0,geshu=0,d;
	scanf("%d%d%d",&n,&k1,&k2);
	int a[n],b[100],c[100],m[100],f[100];
	for(i=0;i<=n-1;i++)
		scanf("%d",&a[i]);
	for(i=0;i<=n-1;i++)
	{
		if((a[i]%10==k1)||(a[i]%10==k2))
		{
			b[q]=a[i];
			c[q]=b[q];
			q++;
		}
		
	}
	for(i=0;i<=q-1;i++)
	{
		while(b[i])
		{
			d=b[i]%10;
			if((d==k1)||(d==k2))
				geshu=geshu+1;
			b[i]=b[i]/10;
		}
		m[i]=geshu;
		geshu=0;
	}
	int max=m[0];int e=0;
	for(i=1;i<=q-1;i++)
	{
		if(max<=m[i])
		{
			max=m[i];
			f[e]=i;
			e++;
		}
	}
	int max2=c[f[0]];
	for(i=1;i<=e-1;i++)
	{
		if(max2<c[f[i]])
		{
			max2=c[f[i]];
		}
	}
	int weishu=0;
	int max3=max2;
	while(max2)
	{
		max2=max2/10;
		weishu=weishu+1;
	}
	printf("%d %d %d",max3,max,weishu);
	
}
	
