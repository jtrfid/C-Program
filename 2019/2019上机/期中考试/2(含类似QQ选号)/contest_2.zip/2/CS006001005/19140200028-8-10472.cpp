#include<stdio.h>
int main()
{int n,i,h=0;
scanf("%d",&n);
for(i=0;i<=n;i++)
{h=h+i*i;}
printf("%d",h);
return 0;
}
