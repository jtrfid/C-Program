#include<stdio.h>
int main(){
	int n,m,t,i,j;
	scanf("%d %d",&n,&m);
	if(n>m) {
	t=n;
	n=m;
	m=t;
	}
	for(i=n;1;i--)
	if((n%i)==0&&(m%i)==0) break;
	for(j=m;1;j++)
	if((j%n)==0&&(j%m)==0) break;
	printf("%d %d",i,j);
	return 0;
}
	
	
	

