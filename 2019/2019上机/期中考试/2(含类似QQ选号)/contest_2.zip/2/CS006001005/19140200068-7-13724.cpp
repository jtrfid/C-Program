 #include<stdio.h>
 int main(){
 	int l,s,i;
 	float m,t;
 	char c;
 	scanf("%c %d %d",&c,&l,&s );
 	if(c=='A'){
 		m=s*26+2000;
 	}
 	 if(c=='B'){
 		m=s*26+1200;
 	}
 	if(c=='C'){
 		m=s*26+500;
 	}
    for(i=0;i<l;i++){
    	m=m+200*i;
    }
 	if(m<=5000){
 		printf("0.00 %.2f",m);
 	}
 	if(m>5000&&m<=8000){
 		t=(m-5000)*0.03;
 		m=m-t;
 		printf("%.2f %.2f",t,m);
 	}
 	if(m>8000&&m<=17000){
 		t=90+(m-8000)*0.1;
 		m=m-t;
 		printf("%.2f %.2f",t,m);
 	}
 	if(m>17000&&m<=30000){
 		t=990+(m-17000)*0.2;
 		printf("%.2f %.2f",t,m);
 	}
 	if(m>30000&&m<=40000){
 		t=3590+(m-30000)*0.25;
 		m-m-t;
 		printf("%.2f %.2f",t,m);
 	}
 	if(m>40000&&m<=60000){
 		t=6090+(m-40000)*0.3;
 		m=m-t;
 		printf("%.2f %.2f",t,m);
 	}
 	if(m>60000&&m<=85000){
 		t=12090+(m-60000)*0.35;
 		m=m-t;
 		printf("%.2f %.2f",t,m);
 	}
 	if(m>85000){
 		t=20840+(m-85000)*0.45;
 		m=m-t;
 		printf("%.2f %.2f",t,m);
 	}
 	return 0;
 }
 
