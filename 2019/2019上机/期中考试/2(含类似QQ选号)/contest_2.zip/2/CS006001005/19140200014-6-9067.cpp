#include<stdio.h>
int main()
{
	int n,a,b,c,d;
	scanf("%d",&n);
	d=n/86400;
	a=(n-d*86400)/3600;
	b=(n-d*86400-a*3600)/60;
	c=n-a*3600-b*60-d*86400;
	if(d==0)
	{
		printf("%d:%d:%d",a,b,c);
	}
	if(d!=0)
	{
		printf("%d %d:%d:%d",d,a,b,c);
	}
}
