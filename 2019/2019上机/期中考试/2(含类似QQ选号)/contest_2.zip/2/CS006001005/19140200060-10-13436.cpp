#include<stdio.h>
int main(){
	int n,a,b,x,c=0,d=0;
	int i,j;
	int count,len,num;
	int e[20];
	scanf("%d %d %d",&n,&a,&b);
	for(i=0;i<=n-1;i++){
		scanf("%d",&e[i]);
	}
	for(i=0;i<=n-1;i++){
		if((e[i]%10==a)||(e[i]%10==b)){
			x=e[i];count=0;len=0;
			for(j=0;x>0;j++){
				if((x%10==a)||(x%10==b)) {count++;len++;}
				else len++;
				x=x/10;				
			}
			if(count>c) {c=count;d=len;num=e[i];	}
			else if(count==c){
			 if (len>d) {num=e[i];c=count;d=len;}}
		}
	}
	printf("%d %d %d",num,count,len);
	return 0;
}
