# include<stdio.h>
int main()
{
	int n,k1,i,j,k2,max=0,c=0,num=0,maxn,flag=0,t=0;
	long int a[20],hao,b,y[20];
	scanf("%d%d%d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
	c=0;
	num=0;
	b=a[i];
	if(a[i]%10==k1||a[i]%10==k2)
	{
	while(a[i]>0)
	{
	if(a[i]%10==k1||a[i]%10==k2)
	c=c+1;
	a[i]=a[i]/10;
	num=num+1;
    }
	if(c>max)
	{
	flag=0;
	max=c;
	hao=b;
	maxn=num;
	}
	else if(c==max&&num>maxn)
	{
	hao=b;
	maxn=num;
    }
    else if(c==max&&num==maxn)
    {
    	flag=1;
    	y[t]=b;
    	t=t+1;
    }
    }
    }
printf("%d %d %d\n",hao,max,maxn);
if(flag==1)
{
	for(j=0;j<t;j++)
	printf("%d %d %d\n",y[j],max,maxn);
}
return 0;
} 
