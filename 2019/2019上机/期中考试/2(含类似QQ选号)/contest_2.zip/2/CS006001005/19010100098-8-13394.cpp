#include<stdio.h>
int main(){
	int n,i,a,b;
	a=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{b=i*i;
	a=a+b;}
	printf("%d",a);
	return 0;
	
}
