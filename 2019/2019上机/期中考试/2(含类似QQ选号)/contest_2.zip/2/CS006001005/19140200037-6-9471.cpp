#include<stdio.h>
int mian()
{
	int n,d,h,m,s;
	scanf("%d",&n);
	d=n/(3600*24);
	h=(n-3600*24*d)/3600;
	m=(n-3600*24*d-3600*h);
	s=n-3600*24*d-3600*h-60*m;
	printf("%d %d:%d:%d",d,h,m,s);
	return 0;
}
