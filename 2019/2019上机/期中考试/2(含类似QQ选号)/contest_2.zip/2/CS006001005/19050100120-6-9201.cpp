#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int d=n/(60*60*24);
	int h=(n%(60*60*24))/(60*60);
	int m=((n%(60*60*24))%(60*60))/60;
	int s=((n%(60*60*24))%(60*60))%60;
	if(d==0) printf("%d:%d:%d",h,m,s);
	else printf("%d %d:%d:%d",d,h,m,s);
	return 0;
}
