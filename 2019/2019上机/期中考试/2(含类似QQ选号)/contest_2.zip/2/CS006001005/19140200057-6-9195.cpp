#include<stdio.h>
int main()
{
	int a,b,c,d,e;
	scanf("%d",&a);
	if(a<86400){
		b=a/3600;
		c=(a%3600)/60;
		d=(a%3600)%60;
		printf("%d:%d:%d",b,c,d);
	}
	else{
		b=a/86400;
		c=(a%86400)/3600;
		d=((a%86400)%3600)/60;
		e=((a%86400)%3600)%60;
		printf("%d %d:%d:%d",b,c,d,e);
		return 0;
	}
}
