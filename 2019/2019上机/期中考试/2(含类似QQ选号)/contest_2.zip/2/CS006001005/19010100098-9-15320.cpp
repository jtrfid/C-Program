#include<stdio.h>
int main(){
	int m,n,i,a,b,e;
	scanf("%d %d",&m,&n);
	if(m>n)
for(i=n;i>0;i--)
{if(m%i==0&&n%i==0)
break;}
	 else
	for(i=m;i>0;i--)
	{if(m%i==0&&n%i==0)
	break;
	}
	 a=m/i;
     b=n/i;
     e=a*b*i;
     printf("%d %d",i,e);
     return 0;
}
