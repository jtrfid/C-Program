#include <stdio.h>
int main()
{
	int l,i;
	double s,w;
	char c;
	scanf("%c %d %lf",&c,&l,&s);
	s=s*26;
	for(i=1;i<l;i++)
	s+=200;
	if(c=='A')s+=2000;
	else if(c=='B')s+=1200;
	else s+=500;
	if(s<=5000)w=0;
	else if(s>=5001&&s<=8000)w=s*0.03;
	else if(s>=8001&&s<=17000)w=s*0.1;
	else if(s>=17001&&s<=30000)w=s*0.2;
    else if(s>=30001&&s<=40000)w=s*0.25;
	else if(s>=40001&&s<=60000)w=s*0.3;
	else if(s>=60001&&s<=85000)w=s*0.35;
	else w=s*0.45;
	printf("%.2f %.2f",w,s-w);
	return 0;
	return 0;
}
