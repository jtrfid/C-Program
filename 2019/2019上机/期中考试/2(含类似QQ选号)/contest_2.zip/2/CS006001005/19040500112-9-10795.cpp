#include<stdio.h>
int main(){
	int a,b;
	scanf("%d %d",&a,&b);
	int t;
	if(a>b) t=a;a=b;b=t;
	
	int i=2;int m,n;
	
	for(i=2;i<=a;i++)
	{if(a%i==0&&b%i==0) m=i;
	}
	for(i=a;i<=a*b;i++){
		if(i%a==0&&i%b==0){n=i;
		break;
		}
	}
	
	printf("%d %d",m,n);
	return 0;
}
