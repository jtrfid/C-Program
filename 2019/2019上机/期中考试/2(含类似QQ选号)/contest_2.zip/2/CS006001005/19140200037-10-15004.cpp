#include <stdio.h>
#include <math.h>
int main()
{
	int k1,k2,n,a[21],i,j,b[21],c[10],t;
	scanf("%d %d %d\n",&n,&k1,&k2);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(j=0;j<n;j++)
	for(i=0;i<n;i++){
	t=a[i]%10;
	if(t==k1||t==k2){
		b[j]=a[i];break;
	}}//���β������
	for(i=0;i<n;i++)
	for(j=0;j<10;j++)
	 {
	 t=a[i]/pow(10,j);
	 c[i]=t%10;
	 }
	for(j=0;j<n;j++)
	printf("%d ",c[j]);
	return 0; 
}
