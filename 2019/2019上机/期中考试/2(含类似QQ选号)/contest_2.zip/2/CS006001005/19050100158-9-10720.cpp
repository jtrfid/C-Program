#include <stdio.h>
int main(){
	int m,n,i,p,q,t;
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		t=m;
		m=n;
		n=t;
	}
	for(i=n;i>0;i--)
	{
		if(m%i==0&&n%i==0)
		{
			p=i;break;
		}
	}
	for(i=n;;i++)
	{
		if(i%m==0&&i%n==0)
		{
			q=i;break;
		}
	}
	printf("%d %d",p,q);
	return 0;
}
