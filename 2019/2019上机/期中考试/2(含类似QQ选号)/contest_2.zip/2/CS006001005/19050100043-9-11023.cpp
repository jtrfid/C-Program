#include<stdio.h>
int main(){
	int z,d,n,m,y,b,i;
	scanf("%d %d",&n,&m);
	if(n<m) {
	z=n;d=m;}
	if(n>=m) {
	z=m;d=n;}
	for(i=z;i>0;i--){
	if(n%i==0&&m%i==0){
	y=i;break;}}
	for(i=d;;i++){
		if(i%n==0&&i%m==0){
		b=i;break;
		}
	}
	printf("%d %d",y,b);
}
