#include<stdio.h>
int main(){
	int t,n,k1,k2,a[20],c[20],i,b[20],d,q;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++){
		a[i]=0,b[i]=0,c[i]=0;
	}
	for(i=0;i<n;i++){
		scanf("%d",&t);
		if(t%10==k1||t%10==k2) a[i]=t;
	}
	for(i=0;i<n;i++){
		q=a[i];
		while(q!=0){
			d=q%10,q/=10;c[i]++;
			if(d==k1||d==k2) b[i]++;
		}
	}
	for(i=1;i<n;i++){
		if(b[0]<b[i]) b[0]=b[i],c[0]=c[i],a[0]=a[i];
		else if(b[0]==b[i]){
			if(c[0]<c[i]) c[0]=c[i],a[0]=a[i];
		}	}
printf("%d %d %d",a[0],b[0],c[0]);
return 0;
}
