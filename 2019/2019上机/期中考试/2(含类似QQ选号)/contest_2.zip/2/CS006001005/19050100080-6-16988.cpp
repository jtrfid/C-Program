#include <stdio.h>
int main(){
	int n,d,h,m,s;
	scanf("%d",&n);
	if(n<3600*24){
		h=n/3600;
		m=(n%3600)/60;
		s=(n%3600)%60;
		printf("%d:%d:%d",h,m,s);	
	}
	else{
		d=n/(3600*24);
		n=n%(3600*24);
		h=n/3600;
		m=(n%3600)/60;
		s=(n%3600)%60;
		printf("%d %d:%d:%d",d,h,m,s);
	}
	return 0;
}
