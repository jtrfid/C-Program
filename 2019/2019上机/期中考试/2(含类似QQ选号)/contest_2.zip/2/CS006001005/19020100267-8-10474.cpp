#include<stdio.h>
int main(){
	int n,i;
    long int s; 
	scanf("%d",&n);
	for(i=1,s=0;i<=n;i++){
		s+=(i*i);
	}
	printf("%ld",s);
	return 0;
}
