#include<stdio.h>
int main(){
	int m,n,i,a;
	scanf("%d %d",m,n);
	for(i==m;i>=2;i--){
		if(m%i==0){
			if(n%i==0)break;
			else ;
		}
		else ;
	}
	for(a==m;a<=999999;a++){
		if(a%m==0){
			if(a%n==0) break;
			else ;
		}
		else ;
	}
	printf("%d %d",i,a);
	return 0;
}
