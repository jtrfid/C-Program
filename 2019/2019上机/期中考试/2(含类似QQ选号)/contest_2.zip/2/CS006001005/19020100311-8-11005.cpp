#include<stdio.h>
int main(){
	int n,i,sum=0,a;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		a=i*i;
		sum=sum+a;
	}
	printf("%d",sum);
	return 0;
}
