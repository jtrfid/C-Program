#include<stdio.h>
int main(){
    int s;
    s=0;
    int i,n;
	scanf("%d",&n);
	for(i=n;i>0;i--)
	{s=s+i*i;
		
		
		
	}	
	
	printf("%d",s);
	return 0;
	
	
	
	
	
	
	
	
}
