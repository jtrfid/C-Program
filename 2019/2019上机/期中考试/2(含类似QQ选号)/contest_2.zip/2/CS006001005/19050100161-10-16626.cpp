#include<stdio.h>
int main()
{
	int a,b,c,i,x[20],m=0,n=0,y[20],t=0,j,e,f=0,h=0,k=0,l,g=0;
	scanf("%d %d %d",&a,&b,&c);
	for(i=0;i<a;i++)
	{
		scanf("%d",&x[i]);
	}
	for(i=0;i<a;i++)
	{   
	    y[i]=0;
	    l=x[i];
		while(1)
		{   
			m=l%10;
			l=l/10;
			if(m==b||m==c)
			{
				y[i]++;
			}
			if(m==0)
			break;
		}
	}
	for(j=0;j<a;j++)
	{   
		if(y[j]>t)
		{
			t=y[j];
			h=j;
		}
	}
	for(j=0;j<a;j++)
	{
		if(y[j]=t)
		{
			h=j;
		}
		g=x[h];
	while(1)
	{
		e=g%10;
		g=g/10;
		if(e!=0)
		{
			f++;
		}
		if(e==0)
		break;
	}
    }
	printf("%d %d %d",x[h],y[0],f);
	return 0;
}
