#include<stdio.h>
int main()
{	
	 
	float sum,jibie,jichu,a;
	char leibie;
	scanf("%c%f%f",&leibie,&jibie,&jichu);
	a=jichu+200*(jibie-1);
	if(leibie=='A')
		sum=a*26+2000;
	if(leibie=='B')
		sum=a*26+1200;
	if(leibie=='C')
		sum=a*26+500;
	float shui=0.00;
	if(sum<=5000)
		printf("%.2f %.2f",shui,sum-shui);
	if((sum>5000)&&(sum<=8000))
	{
		shui=(sum-5000)*0.03;
		printf("%.2f %.2f",shui,sum-shui);
	}
	if((sum>8000)&&(sum<=17000))
	{
		shui=90+(sum-8000)*0.10;
		printf("%.2f %.2f",shui,sum-shui);
	}
	if((sum>17000)&&(sum<=30000))
	{
		shui=990+(sum-17000)*0.20;
		printf("%.2f %.2f",shui,sum-shui);
	}
	if((sum>30000)&&(sum<=40000))
	{
		shui=3590+(sum-17000)*0.25;
		printf("%.2f %.2f",shui,sum-shui);
	}
	if((sum>40000)&&(sum<=60000))
	{
		shui=6090+(sum-40000)*0.30;
		printf("%.2f %.2f",shui,sum-shui);
	}
	if((sum>60000)&&(sum<=85000))
	{
		shui=12090+(sum-60000)*0.35;
		printf("%.2f %.2f",shui,sum-shui);
	}
	if(sum>85000)
	{
		shui=20840+(sum-85000)*0.45;
		printf("%.2f %.2f",shui,sum-shui);
	}
	
	
	
}
