#include<stdio.h>
int main(){
	int m,n,i,y,b;
	scanf("%d%d",&m,&n);
	for(i=1;i<=m&&i<=n;i++)
	{if(m%i==0&&n%i==0) y=i;}
	for(i=1;;i++)
	{if(i%m==0&&i%n==0) {b=i;break;}}
	printf("%d %d\n",y,b);
	return 0;
}
