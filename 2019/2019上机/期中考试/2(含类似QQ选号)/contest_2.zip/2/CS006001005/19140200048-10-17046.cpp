#include<stdio.h>
int main()
{
	int n,k1,k2,i,a[21],b[21],t=0,m=0,j,c[21],x,p;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]%10==k1||a[i]%10==k2)
		b[t]=a[i];t++;
	}
	for(i=0;i<t;i++)
	{p=b[i];m=0;
	for(j=0;p>0;j++)
	{if(p%10==k1||p%10==k2) m++,a[i]=m;
	p=p/10;c[i]=j+1;}}
	for(i=0;i<t;i++)
	{
	if(a[i+1]>a[i]) x=i+1;
	}
	printf("%d %d %d",b[x-1],a[x-1],c[x-1]);
	
	return 0;
}
