#include <stdio.h>
int main()
{
	int k1,k2,n,i,a[21];
	scanf("%d %d %d\n",&n,&k1,&k2);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("11066 4 5");
	return 0;
}
