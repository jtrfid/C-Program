#include<stdio.h>
#include<math.h>
int main( )
{
	int a,b,c,n,w=0,x,max=0,u=0,i,q,j,l,y=0;
	scanf("%d %d %d",&a,&b,&c);
	for(i=1;i<=a;i++)
	{
		scanf("%d",&n);
		q=n%10;
		if(q!=b&&q!=c) n=0;
		for(j=0;j<=10;j++)
		{
			x=n/pow(10,j);
			x=x%10;
			if(x==b||x==c) w=w+1;
		}
		if(w>max)
		{
			max=w;
			u=n;
		}
		if(w==max)
		{
			if(n>u) u=n;
		}
		w=0;
	}
	for(i=9;i>0;i--)
	{
		l=u/pow(10,i);
		l=l%10;
		if(l!=0) break;
	}
	for(j=0;j<=10;j++)
	{
		x=u/pow(10,j);
		x=x%10;
		if(x==b||x==c) y=y+1;
	}
	printf("%d %d %d",u,y,i+1);
	return 0;
}
