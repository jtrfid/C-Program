#include<stdio.h>
int yue(int a,int b)
{
	int t;
	while(b)
	{
		t=a%b;
		a=b;
		b=t;
	}	
	return a;
}
int main()
{

	int m,n,i,bei,q;
	scanf("%d%d",&m,&n);
	if(m<n)
	{
		for(i=1;i<=m;i++)
		{
			bei=i*n;
			if(bei%m==0)
			{
				q=bei;
				break;
			}
		}
			
	}
	printf("%d %d",yue(m,n),q);
}
	
