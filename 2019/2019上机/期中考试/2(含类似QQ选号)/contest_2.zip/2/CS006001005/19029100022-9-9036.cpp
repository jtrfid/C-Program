# include<stdio.h>
int main()
{
	int m,n,t,i,j;
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		t=m;
		m=n;
		n=t;
	}
	for(i=m;i>0;i--)
	if(m%i==0&&n%i==0)
	{
	printf("%d ",i);
	j=(m/i)*(n/i)*i;
	printf("%d",j);
	break; 
    }
return 0;
}
