#include <stdio.h>
int main()
{int n,k1,k2,a,b,c,count=0,s,p=0,m=0,j=0;
 scanf("%d%d%d",&n,&k1,&k2);
 for(int i=0;i<n;i++)
   {j=0;
    count=0;
	scanf("%d",&a);
    if(a%10==k1||a%10==k2) 
	{b=a;
	 while(1)
	      {c=b%10;
	       if(c==k1||c==k2) count++;
	       b=b/10;j++;
	       if(b==0) break;
	      }
	 if(count>p) 
	 {p=count;
	  s=a;m=j;
    }
    if(count==p) 
	{if(j>m) 
	 {m=j;
	  s=a;
	 }
    }
   }
   else ;
}
printf("%d %d %d",s,p,m);
 return 0;
}
