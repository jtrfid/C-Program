#include<stdio.h>
int main(){
	int m,n,i,max,p,min;
	scanf("%d %d",&m,&n);
	if(m<=m)
	p=n;
	else
	p=m;
	for(i=p;i>=1;i--)
	 if(n%i==0&&m%i==0)
	{
	 max=i;
	 break;
    }
    if(max==1)
    min=m*n;
    else
    min=(m/max)*(n/max)*max;
    printf("%d %d",max,min);
}

	
