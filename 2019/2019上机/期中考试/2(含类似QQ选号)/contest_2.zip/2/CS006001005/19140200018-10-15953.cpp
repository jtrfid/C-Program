#include<stdio.h>
int main(){
	int n,k1,k2,i,j=0,a[21],b[2][21];
	int u=0,p=0,m,x,t;
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	 scanf("%d",&a[i]) ;
	for(i=0;i<n;i++){ 
	if((a[i]%10)==k1||(a[i]%10)==k2)
	  {b[0][j]=a[i];
	  j++;
	 }
	}
	for(i=0;i<(j+1);i++)
	 
	 {m=b[0][i];
	  while(m!=0){
	   if((m%10)==k1||(m%10)==k2) u++;
	   m=m/10;
	   p++;
	  }
	  b[1][i]=u;
	  b[2][i]=p;
	 }

	
	

	
	printf("%d %d %d",b[0][0],b[1][0],b[2][0]);
}
	  
	  
	  
	
