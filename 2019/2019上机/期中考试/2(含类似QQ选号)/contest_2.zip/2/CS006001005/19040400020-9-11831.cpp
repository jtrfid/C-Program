#include <stdio.h>
int main()
{int m,n,a,b,i,min,j=0;
 scanf("%d%d",&m,&n);
 for(i=1;i<=n;i++)
 {if(n%i==0&&m%i==0) a=i;
 }
 min=m*n;
 for(i=m;i<=m*n;i++)
 {if(i%n==0&&i%m==0) {b=i;j=1;}
  if(b<=min&&j==1) min=b;
 }
 printf("%d %d",a,min);
 return 0;
}
