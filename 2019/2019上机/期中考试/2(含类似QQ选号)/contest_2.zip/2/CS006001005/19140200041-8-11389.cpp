#include<stdio.h>
int main()
{
	int n,m=0,i;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	  m=m+i*i;
	printf("%d",m);
	return 0;
}
