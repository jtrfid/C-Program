#include<stdio.h>
int main(){
	int dd=0,hh=0,mm=0,ss=0,n;
	scanf("%d",&n);
	if(n==0)printf("0:0:0");
	else {
		while(n>0){
			ss++;
			if(ss==60)mm++;
			if(mm==60)hh++;
			if(hh==60)dd++;}
		}
	if(dd<1)printf("%d:%d:%d",hh,mm,ss);
	else printf("%d %d:%d:%d",dd,hh,mm,ss);
	return 0;}
	

