#include<stdio.h>
int main(){
	int s,d,h,f,k,i;
	scanf("%d",&s);
	k=s/(24*60*60);
	if(k==0){
	i=1;
	}
	else i=0;
  	h=s/(60*60);
	f=(s-h*60*60)/60;
	s=s%60;
	if(i==0){
		printf("%d %d:%d:%d",k,h,f,s);}
	else printf("%d:%d:%d",h,f,s);
	return 0;
}
