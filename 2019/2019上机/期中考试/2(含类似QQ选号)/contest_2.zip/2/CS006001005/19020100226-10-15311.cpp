#include<stdio.h>
int main(){
	int n,b[20],a[20],c[20],ka,kb,i,z,num,luck,max;
	scanf("%d%d%d",&n,&ka,&kb);
	for(i=0;i<n;i++)
	{scanf("%d",&a[i]);}
	for(i=0;i<n;i++)
	{num=0;
	if(a[i]%10!=ka&&a[i]%10!=kb) {b[i]=num;continue;}
	else { if((a[i]==0)&&(ka==0||kb==0)) {b[i]=1;continue;}        
	        else {z=a[i];for(;a[i]!=0;)
	              {if(a[i]%10==ka||a[i]%10==kb) num++;
				    a[i]=a[i]/10;} a[i]=z;b[i]=num;    }}}
	for(i=0;i<n;i++)
	{if(a[i]==0) {c[i]=1;continue;}
	else {z=a[i]; for(num=0;a[i]!=0;num++)
	         {a[i]=a[i]/10;}
	 a[i]=z;c[i]=num;
	}}
	for(i=0,max=-1;i<n;i++)
	{if(b[i]>max) {max=b[i];luck=a[i];num=c[i];}
	if(b[i]==max)  {if(c[i]>=num) {max=b[i];luck=a[i];num=c[i];} } }
	printf("%d %d %d\n",luck,max,num);
	return 0;
}
