#include<stdio.h>
int main()
{
	int a,b,max,min,yue,bei,i;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}
	for(i=1;i<=min;i++)
	{
		if(a%i==0&&b%i==0)
		yue=i;
	}
	for(i=1;i<=max*min;i++)
	{
		if(i%a==0&&i%b==0)
		{
			bei=i;
			break;
		}
	}
	printf("%d %d",yue,bei);
	return 0;
}
