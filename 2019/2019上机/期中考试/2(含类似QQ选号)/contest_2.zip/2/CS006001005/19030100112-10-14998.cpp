#include<stdio.h>
int main()
{
	int n,k,l,a[20],q,w,e,i,s,j,d,m,x;
	scanf("%d %d %d",&n,&k,&l);
	for(i=0;i<n;i++)
	  scanf("%d",&a[i]);
	q=a[0];w=0;e=0;
	for(i=0;i<n;i++)
	{
		s=a[i]%10;
		if(s!=k&&s!=l) continue;
		x=a[i];
		j=0;m=0;
		while(x>0)
		{
		   d=x%10;
		   if(d==k) j++;
		   if(d==l) j++;
		   x=x/10; m++;
	    }
	    if(j>w)
	    {
	    	q=a[i];w=j;e=m;
	    }
	    if(j=w)
	    {
	    	if(m>e)
	    	q=a[i];w=j;e=m;
	    }
	}
	printf("%d %d %d",q,w,e);
	return 0;
}
