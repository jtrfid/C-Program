#include<stdio.h>
int main(){
	int d,h,m,s,n;
	scanf("%d",&n);
	d=n/3600/24;
	h=(n-d*3600*24)/3600;
	m=(n-d*3600*24-h*3600)/60;
	s=n-d*3600*24-h*3600-m*60;
	return 0;
}
