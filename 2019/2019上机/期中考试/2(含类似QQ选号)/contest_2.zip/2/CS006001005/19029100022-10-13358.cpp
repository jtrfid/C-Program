# include<stdio.h>
int main()
{
	int n,k1,i,k2,max=0,c=0,num=0,maxn;
	long long int a[20],hao,b;
	scanf("%d%d%d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	scanf("%ld",&a[i]);
	for(i=0;i<n;i++)
	{
	c=0;
	num=0;
	b=a[i];
	if(a[i]%10==k1||a[i]%10==k2)
	{
	while(a[i]>0)
	{
	if(a[i]%10==k1||a[i]%10==k2)
	c=c+1;
	a[i]=a[i]/10;
	num=num+1;
    }
	if(c>max)
	{
	max=c;
	hao=b;
	maxn=num;
	}
	else if(c==max&&b>hao)
	{
	hao=b;
	maxn=num;
    }
    }
    }
printf("%d %d %d",hao,max,maxn);
return 0;
} 
