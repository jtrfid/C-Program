#include <stdio.h>
int main(){
	int n,a[4],i;
	scanf("%d",&n);
	for(i=0;i<=2;i++)
	{
		if(i<2)
		{
			a[i]=n%60;
			n=n/60;
		}
		else if(i==2)
		{
			a[i]=n%24;
			a[i+1]=n/24;
		}
	}
	if(a[3]!=0)
	{
	for(i=3;i>=0;i--)
	{
		printf("%d ",a[i]);
		if(i!=3&&i!=0) printf(":");
	}}
	else
		{for(i=2;i>=0;i--)
	{
		printf("%d",a[i]);
		if(i!=0) printf(":");}}
	return 0;
}
