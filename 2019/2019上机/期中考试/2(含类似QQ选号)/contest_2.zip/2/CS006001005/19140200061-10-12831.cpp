#include<stdio.h>
int main(){
	int k1,k2,c,n,i,j,a[20],b[20][2];
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		b[i][0]=0;b[i][1]=0;
	}
	for(i=0;i<n;i++){
		if(a[i]%10!=k1&&a[i]%10!=k2){
			b[i][0]=0,b[i][1]=0;
		}
		else{
			c=a[i];
			for(;;){
				b[i][1]++;
				if(c%10==k1||c%10==k2){
			    b[i][0]++;
				}
				if(c/10==0) break;
				c=c/10;
			}
		}
	}
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1;j++){
			if(b[j][0]<b[j+1][0]||(b[j][0]==b[j+1][0]&&b[j][1]<b[j+1][1])){
				c=b[j+1][0],b[j+1][0]=b[j][0],b[j][0]=c;
				c=b[j+1][1],b[j+1][1]=b[j][1],b[j][1]=c;
				c=a[j+1],a[j+1]=a[j],a[j]=c;
			}
		}
	}
	printf("%d %d %d",a[0],b[0][0],b[0][1]);
	return 0;
}
