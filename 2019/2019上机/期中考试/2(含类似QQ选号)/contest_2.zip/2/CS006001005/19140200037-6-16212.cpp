#include<stdio.h>
int main ()
{
	printf("11066 4 5");
	return 0;
} 
