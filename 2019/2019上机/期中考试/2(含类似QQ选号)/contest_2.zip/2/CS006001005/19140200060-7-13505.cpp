#include<stdio.h>
int main(){
    char c;
	float f,month;
	int l,s;
	scanf("%c %d %d",&c,&l,&s);
	if(c=='A') month=(s+200*(l-1))*26+2000;
	else if(c=='B') month=(s+200*(l-1))*26+1200;
	else month=(s+200*(l-1))*26+500;
	if(month<=5000) f=0;
	else if(month<=8000) f=(month-5000)*0.03;
	else if(month<=17000) f=(month-8000)*0.1+3000*0.03;
	else if(month<=30000) f=(month-17000)*0.2+9000*0.1+3000*0.03;
	else if(month<=40000) f=(month-30000)*0.25+13000*0.2+9000*0.1+3000*0.03;
	else if(month<=60000) f=(month-40000)*0.3+10000*0.25+13000*0.2+9000*0.1+3000*0.03;
	else if(month<=85000) f=(month-60000)*0.35+20000*0.3+10000*0.25+13000*0.2+9000*0.1+3000*0.03;
	else f=(month-85000)*0.45+25000*0.35+20000*0.3+10000*0.25+13000*0.2+9000*0.1+3000*0.03;
	printf("%.2f %.2f",f,month-f);
	return 0;
}
