#include <stdio.h>
int main()
{
	int k1,k2,n,a[21],i,j,b[21],c[21][10],t,k,s[21]=0;
	scanf("%d %d %d\n",&n,&k1,&k2);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(j=0;j<n;j++)
	for(i=0;i<n;i++){
	t=a[i]%10;
	if(t==k1||t==k2){
		b[j]=a[i];k++;break;
	}}//���β������
	for(i=0;i<k;i++)
	for(j=0,s=0;j<10;j++)
	{t=b[i]/pow(10,j)
	c[i][j]=t%10;}//��ȡ��λ���� 
	for(i=0;i<k;i++)
	for(j=0;j<;j++)
	{
		if(c[i][j]==k1&&c[i]c[j]==k2)s++;
	}
	for(i=0;i<n;i++)
	for(j=0,w=0;j<10;j++)
	{t=b[i]/pow(10,j);
	if(t!=0)w++;else break;}//λ�� 
	
	printf("%d %d %d",b[],s[],w);
	return 0; 
}
