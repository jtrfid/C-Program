#include<stdio.h>
int main()
{int n,d,h,m,s;
scanf("%d",&n);
if(n<86400) 
{
h=n/3600;
m=(n-h*3600)/60;
s=n-(h*3600+m*60);
printf("%d:%d:%d",h,m,s);
} 
else 
{d=n/86400;
h=(n-d*86400)/3600;
m=(n-(d*86400+h*3600))/60;
s=n-(d*86400+h*3600+m*60);
printf("%d %d:%d:%d",d,h,m,s);
} 
return 0;
}
