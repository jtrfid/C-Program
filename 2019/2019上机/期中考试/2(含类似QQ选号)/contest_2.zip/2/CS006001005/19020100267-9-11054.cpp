#include<stdio.h>
int main(){
	int m,n,i,t,l,fl,k;
	scanf("%d %d",&m,&n);
	if(m<=n)  k=m,m=n,n=k;//m if more bigger;
	for(i=1,t=1;i<=n;i++){
		if(m%i==0&&n%i==0) t=i;
	}
	for(i=m,l=m,fl=0;;i++){
		if(i%m==0&&i%n==0) l=i,fl=1;
		if(fl=1) break;
	}
	printf("%d %d",t,l);
	return 0;
}
