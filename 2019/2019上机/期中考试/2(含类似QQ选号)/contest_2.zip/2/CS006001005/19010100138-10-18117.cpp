#include<stdio.h>
int main(){
	int a,i,c,d[20],b,e,m,f,l;int g[20]={0},h[20]={0};
	scanf("%d %d %d",&a,&b,&c);
	for(i=0;i<a;i++)
	scanf("%d",&d[i]);
	for(i=0;i<a;i++)
	{for(m=d[i];m/10!=0;m=m/10) {f=m%10;g[i]++;if(f==b||f==c) h[i]++;}
	if(m/10==0){g[i]++;if(m!=b&&m!=c) {h[i]=0;g[i]=0;}
	}}
	for(i=0;i<a;i++)
	 {for(e=0;e<a-1;e++){
	 if(h[e]<h[e+1])
	  {l=d[e+1];d[e+1]=d[e];d[e]=l;l=h[e+1];h[e+1]=h[e];h[e]=l;l=g[e+1];g[e+1]=g[e];g[e]=l;}
	  else continue;}}
	for(i=0;i<a;i++)
	 {for(e=0;e<a-1;e++)
	 {if(g[e]<g[e+1]&&h[e]<=h[e+1]) 
	 {l=d[e+1];d[e+1]=d[e];d[e]=l;l=g[e+1];g[e+1]=g[e];g[e]=l;l=h[e+1];h[e+1]=h[e];h[e]=l;}
	  else continue;}}
	 printf("%d %d %d",d[0],h[0],g[0]);}
	
	
