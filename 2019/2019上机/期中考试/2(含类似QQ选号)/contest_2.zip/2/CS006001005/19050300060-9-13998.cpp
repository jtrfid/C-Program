#include<stdio.h>
int main()
{
	int a,b,x,y,i;
	scanf("%d %d",&a,&b);
	if(a<b){
		for(i=a;i>0;i--){
			if(a%i==0&&b%i==0){
				x=i; 
				break; 
			}

		}
		for(i==b;i<1000000000;i++){
			if(i%a==0&&i%b==0){
				y=i;
				break;
			}
		}
		printf("%d %d",x,y);
	}
	if(a>b){
		for(i=b;i>0;i--){
			if(a%i==0&&b%i==0){
				x=i;
				break;
			}
		}
		for(i==a;i<10000000000;i++){
			if(i%a==0&&i%b==0){
				y=i;
				break;
			}
		}
		printf("%d %d",x,y);
	}
	if(a==b){
		printf("%d %d",a,b);
	}
	return 0;
} 
