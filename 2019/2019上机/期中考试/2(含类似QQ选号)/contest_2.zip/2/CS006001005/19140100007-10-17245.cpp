#include<stdio.h>
int main()
{
	int a,b,c,k,d,m,p,u,r,g,h,v;
	p=0;
    int e[20];
    int f[20];
    int s[20];
    scanf("%d%d%d",&c,&k,&d);
    for(int t=0;t<=c-1;t++)
    {
    scanf("%d",m);
    if(m%10==k||m%10==d)
    {
    e[p]=m;
    s[p]=p;
	p=p+1;}}
	for(int t=0;t<=c-1;t++)
	{ u=0;r=e[t];
	  for(int y=0;y>=0;y++)
	 {
	  if(r%10==k||r%10==d)
	  u=u+1;
	  r=r/10;
	  if(r==0)
	  break;}
	  f[t]=u;
	}
	for(int t=1;t<=c-1;t++)
	   for(int y=0;y<=c-t-1;y++)
	  {
	   if(f[y]<f[y+1])
	   {
	   	g=f[y];
	   	f[y]=f[y+1];
	   	f[y=1]=g;
	   	h=e[y];
	   	e[y]=e[y+1];
	   	e[y+1]=h;
	   	v=s[y];
	   	s[y]=s[y+1];
	   	s[y+1]=v;
	   }
	    if(f[y]==f[y+1])
		    if(e[y]<e[y+1])
		{
		h=e[y];
	   	e[y]=e[y+1];
	   	e[y+1]=h;
		   v=s[y];
	   	s[y]=s[y+1];
	   	s[y+1]=v;}
		}
		printf("%d %d %d",e[0],f[0],s[0]);
	return 0;
}
