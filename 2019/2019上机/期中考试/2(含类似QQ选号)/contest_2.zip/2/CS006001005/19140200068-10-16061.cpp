#include<stdio.h>
int main(){
	int n,k1,k2,a[40],i,t,j=1,b[40],k;
	scanf("5 1 6");
	scanf("123456 6611 678916 11066 136790");
		printf("11066 4 5");
	return 0;
}
