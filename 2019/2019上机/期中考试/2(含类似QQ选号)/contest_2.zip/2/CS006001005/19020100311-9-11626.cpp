#include<stdio.h>
int main(){
	int m,n,t,i,j;
	scanf("%d %d",&m,&n);
	if(m>n){
		t=m;
		m=n;
		n=t;
	}
	for(i=m;i>0;i--){
		if(m%i==0&&n%i==0)
		break;
	}
	for(j=n;;j++){
		if(j%m==0&&j%n==0)
		break;
	}
	printf("%d %d",i,j);
	return 0;
}
