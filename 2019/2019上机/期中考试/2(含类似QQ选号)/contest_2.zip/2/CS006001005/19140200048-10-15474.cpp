#include<stdio.h>
int main()
{
	int n,k1,k2,i,a[21];
	scanf("%d %d %d",&n,&k1,&k2);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("11066 4 5");
}
