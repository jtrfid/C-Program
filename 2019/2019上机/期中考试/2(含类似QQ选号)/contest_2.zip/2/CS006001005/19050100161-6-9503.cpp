#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int d=0,h=0,m=0,s=0;
	d=n/86400;
	h=(n-d*86400)/3600;
	m=(n-d*86400-h*3600)/60;
	s=n-d*86400-h*3600-m*60;
	if(d==0)
	{
		printf("%d:%d:%d",h,m,s);
	}
	else
	{
		printf("%d %d:%d:%d",d,h,m,s);
	}
	return 0;
}
