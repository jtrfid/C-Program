#include <stdio.h>
int main()
{
	int n,i,s;
	scanf("%d",&n);
	for(i=1,s=0;i<=n;i++)
	s=s+i*i;
	printf("%d",s);
	return 0;
}
