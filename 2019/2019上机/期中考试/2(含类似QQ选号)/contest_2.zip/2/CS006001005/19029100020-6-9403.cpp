#include<stdio.h>
int main()
{int d=0,h=0,m=0,n,j;
scanf("%d",&n);
 j=60*60*24;
   
	   m=n/60;
	   n=n-m*60;
	     if(m>=60)
	     {h=m/60;
	      m=m-h*60;
	      }
	       if(h>=24)
	     {d=h/24;
	      h=h-d*24;
	      } 
	      if(d==0)
	      printf("%d:%d:%d",h,m,n);
		   else 
	     {
	      printf("%d %d:%d:%d",d,h,m,n);}
	  

	
	
} 
