#include<stdio.h>
int main( ){
	int m,n,i,j,t;
	scanf("%d%d",&m,&n);
	if(m>=n){
		t=m,m=n,n=t;
	}
	for(i=m;i>=1;i--){
		if(m%i==0&&n%i==0)
		break;
	}
	printf("%d",i);
	for(j=n;j<=m*n;j++)
{
	if(j%m==0&&j%n==0)
	break;
}
printf(" %d",j);
return 0;
}
