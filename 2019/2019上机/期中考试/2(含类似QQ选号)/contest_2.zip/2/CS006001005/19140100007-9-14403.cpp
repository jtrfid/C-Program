#include<stdio.h>
int main()
{
	int a,b,c,k,d;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		c=a;
		a=b;
		b=c;
	}
	for(int t=c;t>=1;t--)
	{
		if(a%t==0&&b%t==0)
		{
			k=t;
			break;
		}
	}
	d=a/k*b;printf("%d %d",k,d);
	
	return 0;
}
