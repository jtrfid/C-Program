#include<stdio.h>
int main ()
{   int t,n=0,i,a[20],b,q,u,w[20],e[20],r,c,d,o[20],k=0,z=0;
    scanf("%d%d%d",&b,&c,&d);
    for(i=0;i<b;i++)
    scanf("%d",&a[i]);
    for(i=0;i<b;i++)
	{
		if(a[i]%10==c||a[i]%10==d)
		{o[n]=a[i];
		n++;
		}
	}
	q=n; //e ������ִ����ļ����� w ���㳤�� bcdin1
    for(n=0;n<=q;n++)
    { r=o[n];e[n]=0;
      for(w[n]=0;1;)
      {k=r-r/10;
      if(k==c||k==d) e[n]+=1;
      z=r/10;w[n]+=1;
      r=r/10;
      if(z==0) break;
      }
	}
      k=e[0];z=w[0];
       for(n=0;n<=q-1;n++)
       {if(e[n]<e[n+1]) {u=n+1;k=e[n+1];z=w[n+1];}  
	    else if(e[n]=e[n+1]&&w[n]<w[n+1])
		   {k=e[n+1];z=w[n+1];u=n+1;}
	   }
    
    printf("%d %d %d",o[u],k,z);
	return 0;
}
