#include<stdio.h>
int main(){
	int s,q,w,n;
	float a,m;
	char c,l;
	scanf("%c %d %d",&c,&l,&s);
	switch(c){
		case 'A':q=2000;break;
		case 'B':q=1200;break;
		case 'C':q=500;break;
	}
	switch(l){
		case '1':w=0;break;
		case '2':w=200;break;
		case '3':w=400;break;
		case '4':w=600;break;
		case '5':w=800;break;
		case '6':w=1000;break;
		case '7':w=1200;break;
		case '8':w=1400;break;	
	}
	a=s*26+q+w;
	if(a>=1&&a<=5000)
	m=0;
	else if(a>=5001&&a<=8000)
	m=(a-5000)*0.03;
	else if(a>=8001&&a<=17000)
	m=90+(a-8000)*0.1;
	else if(a>=17001&&a<=30000)
	m=990+(a-17000)*0.2;
	else if(a>=30001&&a<=40000)
	m=3590+(a-30000)*0.25;
	else if(a>=40001&&a<=60000)
	m=6090+(a-40000)*0.3;
	else if(a>=60001&&a<=85000)
	m=12090+(a-60000)*0.35;
	else if(a>85000)
	m=12090+8750+(a-85000)*0.45;
	n=a-m;
	printf("%.2f %.2f",m,n);
	return 0;}
