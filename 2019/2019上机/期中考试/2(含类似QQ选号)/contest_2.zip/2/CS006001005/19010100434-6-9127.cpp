#include<Stdio.h>
int main()
{
	int n,d,h,m,s;
	scanf("%d",&n);
	s=n%60;
	m=(n-s)/60;
	h=m/60;    
	if(h<24)
	{
		m=m-h*60;
		printf("%d:%d:%d",h,m,s); 
	}
 
	if(h>=24)            
	{
		d=h/24;
		m=m-h*60;
		h=h-24*d;
        printf("%d:%d:%d:%d",d,h,m,s);
	}                               
	return 0;
}
