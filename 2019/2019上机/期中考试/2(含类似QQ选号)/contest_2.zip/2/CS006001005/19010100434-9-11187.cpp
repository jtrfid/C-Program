#include<stdio.h>
int main()
{
	int m,n,i,j,k,s;
	scanf("%d%d",&m,&n);
	if(m>n)
	{
		for(i=n;i>=1;i--)
		{if(m%i==0&&n%i==0)
		{k=i;
		break;
		}
		}
		for(j=m;;j++)
		{
		if(j%m==0&&j%n==0)
		s=j;
		break;
		}
		
	}
	if(m<=n)
	{
		for(i=m;i>=1;i--)
		{if(m%i==0&&n%i==0)
		{k=i;
		break;
		}
		}
		for(j=n;;j++)
		{
		if(j%m==0&&j%n==0)
		{s=j;
		break;
	}
		}
		
	}
	printf("%d %d",k,s);
	return 0;
}
