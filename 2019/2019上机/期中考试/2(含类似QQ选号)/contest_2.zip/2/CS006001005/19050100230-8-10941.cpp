#include<stdio.h>
int main(){
	int n,i,num=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		num=num+i*i;
	}
	printf("%d",num);
}
