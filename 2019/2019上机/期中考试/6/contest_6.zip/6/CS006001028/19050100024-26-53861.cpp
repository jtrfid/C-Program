#include<stdio.h>
#include<math.h>
int main()
{
	int m,b;
	scanf("%d %d",&m,&b);
	int h=pow(m+b,2);
	int j=pow(m-b,2);
	int k=pow(m,2)+pow(b,2);
	int l=pow(m,2)-pow(b,2)-1;
	int a[]={h,j,k,l};
    for(int i=0;i<4;i++)
     for(int y=0;y<4-i;y++)
     if(a[y]>a[y+1])
     {
     	int t=a[y];
     	a[y]=a[y+1];
     	a[y+1]=t;
	 }
     printf("%d %d",*(a+4),*a);
	return 0;
	
}
