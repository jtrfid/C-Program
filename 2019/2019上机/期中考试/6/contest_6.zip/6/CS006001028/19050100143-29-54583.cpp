#include<stdio.h>
#include<math.h>
#define n 160
int main()
{
	int a,b[n],i,s,c=0,d=0,e=0;
	scanf("%d",&a);
	for (i=2;i<=10000;i++)
	{
		for(s=2;s<=i-1;s++)
		{
			if ((i%s)==0)
			{
				c++;	
			}
			if (c==2)
				{
					b[d]=i;
					d++;
				}
			c=0;	
		}
	}
	for (i=a;i<=a+10;i++)
	{
		e+=b[i];
	}
	printf("%d",e);
}
