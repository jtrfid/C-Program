#include<stdio.h>
int main()
{
	int a,b=0,i;
	scanf("%d",&a);
	for(i=0;i<10;i++)
	{
		a=a/10;
		b++;
		if(a==0)
		break;
	}
	printf("%d",b);
	return 0;
}
