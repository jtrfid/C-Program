#include<stdio.h>
int main()
{
	int n,m,n1,m1,i,j,b1=0,b2=0,sum=0,sun=0;
	scanf("%d %d",&n,&m);
	for(i=0;i<(n+1)/2;i++)
	{
		n1=n/i;
		if(n1*i==n)
		{
			b1++;
			sun=sun+i;
		}
	}
	for(j=0;j<(m+1)/2;j++)
	{
		m1=m/j;
		if(m1*j==m)
		{
			b2++;
			sum=sum+j;
		}
	}
	if(sum==sun)
	printf("yes %d %d",b1,b2);
	else
	printf("no %d %d",b1,b2);
	return 0;
}
