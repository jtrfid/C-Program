#include<stdio.h>
int main()
{
	int p,x,y,n,sum,i;
	n=0;
	scanf("%d",&p);
	int a[150];
	for(i=3;i<10000;i++)
	{
		for(x=2;x<i;x++)
		{
			y=i/x;
			if(i=x*y)
				{
					a[n]=i;
					n++;
				}
		}
			
	}
	sum=a[p]+a[p+1]+a[p+2]+a[p+3]+a[p+4]+a[p+5]+a[p+6]+a[p+7]+a[p+8]+a[p+9]+a[p+10];
	printf("%d",sum);
	
		
}
