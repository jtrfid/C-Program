#include<stdio.h>

int isprime(int a)
{
	for(int i=2;i<a/2;i++)
	if(a%i==0)
	    return 0;
	return 1;
	
	
	
}


int main()
{
	int p;
	scanf("%d",&p);
	int prime[180]={0};
	int n=0;
	for(int i=2;1;i++){
		if (isprime(i)){
			prime[n]=i;
			n++;
		}
		if(n==180)
		break;
		
	}
	int sum=0;
	for(int i=p-1;i<p+10;i++)
	sum+=prime[i];
	printf("%d",sum);
	return 0;
	
}

