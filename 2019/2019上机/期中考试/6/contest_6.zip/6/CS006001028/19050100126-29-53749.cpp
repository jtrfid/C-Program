#include<stdio.h>
int main()
{
	int p,n,d,m,i,a=0,k=0;
	scanf("%d",&p);
	for(n=1;n<1000;n++)
	{
		for(i=1;i<n;i++)
		{
			d=n%i;
			if(n==0)
			{
				m++;
				break;
			}
		}
		if(m==1)
		{
			a=a+n;
		}
		m=0;
	}
	
	printf("%d",a);
}
