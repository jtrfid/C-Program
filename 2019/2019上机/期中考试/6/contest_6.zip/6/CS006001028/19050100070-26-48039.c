#include<stdio.h>

int main()
{
	int a,b,c,d,e,f,z,x;
	scanf("%d%d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(c<e)
	{
		z=c;
		c=e;
		e=z;
	}
	if(d>f) 
	{
		x=d;
		d=f;
		f=x;
	}
	printf("%d %d",c,d);
	return 0;
}


