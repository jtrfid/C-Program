#include<stdio.h>

int main(){
	int m,q,x;
	
	scanf("%d",&m);
	q=0;
	while(m!=0){
		m=m/10;
		q++;
	}
	
	printf("%d",q);

		
	return 0;
}
