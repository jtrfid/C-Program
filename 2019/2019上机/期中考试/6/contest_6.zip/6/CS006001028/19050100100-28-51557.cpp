#include<stdio.h>
int main()
{
	int a,c;
	scanf("%d",&a);
	
	if((a%100000000)<10&&(a%100000000)!=a)
	{
	printf("9");
	}
	
	else if((a%10000000)<10&&(a%10000000)!=a)
	{
	printf("8");
	}
	
	else if((a%1000000)<10&&(a%1000000)!=a)
	{
	printf("7");
	}
	
	else if((a%100000)<10&&(a%100000)!=a)
	{
	printf("6");
	}
	
	else if((a%10000)<10&&(a%10000)!=a)
	{
	printf("5");
	}
	
	else if((a%1000)<10&&(a%1000)!=a)
	{
	printf("4");
	}
	
	else if((a%100)<10&&(a%100)!=a)
	{
	printf("3");
	}
	
	else if((a%10)<10&&(a%10)!=a)
	{
	printf("2");
	}
	
	else
	printf("1");
}
