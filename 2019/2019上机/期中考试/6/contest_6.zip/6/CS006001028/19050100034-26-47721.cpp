#include<stdio.h>
int main()
{
	int a,b,w,x,y,z;
	scanf("%d %d",&a,&b);
	if(a<4||b<4||a>1000||b>10000)
	    scanf("%d %d",a,b);
	w=(a+b)*(a+b);
	x=(a-b)*(a-b);
	y=a*a+b*b;
	z=a*a-b*b;
	if(w<y)
	    w=y;
	if(z>x)
	    z=x;
	printf("%d %d",w,z);
	return 0;
}
