#include<stdio.h>
int main()
{
	int a,b,m,n,l,p,max,min;
	scanf("%d %d",&a,&b);
	m=(a+b)*(a+b);
	n=(a-b)*(a-b);
	l=a*a+b*b;
	p=a*a-b*b;
	if(m>=n&&m>=l&&m>=p)
	max=m;
	else if(n>=m&&n>=l&&n>=p)
	max=n;
	else if(l>=m&&l>=n&&l>=p)
	max=l;
	else if(p>=m&&p>=n&&p>=l)
	max=p;
	if(m<=n&&m<=l&&m<=p)
	min=m;
	else if(n<=m&&n<=l&&n<=p)
	min=n;
	else if(l<=m&&l<=n&&l<=p)
	min=l;
	else if(p<=m&&p<=n&&p<=l)
	min=p;
	printf("%d %d",max,min);
	
	
}
