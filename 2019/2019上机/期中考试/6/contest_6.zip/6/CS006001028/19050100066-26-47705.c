#include<stdio.h>

int main()
{
	int a, b, max, min, n1, n2, n3, n4;
	
	scanf("%d %d", &a, &b);
	
	n1 = (a + b) * (a + b);
	n2 = (a - b) * (a - b);
	n3 = a * a + b * b;
	n4 = a * a - b * b;
	
	max = (n1 > n2)?n1:n2;
	max = (max > n3)?max:n3;
	max = (max > n4)?max:n4;
	
	min = (n1 < n2)?n1:n2;
	min = (min < n3)?min:n3;
	min = (min < n4)?min:n4;
	
	printf("%d %d", max, min);
	
	
	return 0;
}
