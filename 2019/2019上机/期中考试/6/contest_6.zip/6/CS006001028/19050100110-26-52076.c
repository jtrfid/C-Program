#include <stdio.h>
int main()
{
	int i,j,a,b,d,e,f,g,swap;
	scanf("%d %d",&a,&b);
	d=(a+b)*(a+b);
	e=(a-b)*(a-b);
	f=a*a+b*b;
	g=a*a-b*b;
	int c[4]={d,e,f,g};
	for(i=0;i<3;i++)
	{
		for(j=0;j<2-i;j++)
		{
			if(c[i]>c[j])
			{
				swap=c[i];
				c[i]=c[j];
				c[j]=swap;
			}
		}
	}
	printf("%d %d",c[0],c[3]);
	return 0;
}
