#include<stdio.h>
int a[160],b[160],sum[2],x[2];
int main()
{
	
int i,j,m[2],n;
scanf("%d %d",&x[0],&x[1]);
m[2]=0;


for(i=1;i<x[0];i++)
{
	if(x[0]%i==0)
	{
	a[m[0]]=i;
	 m[0]++;
	}
	for(j=0;j<m[0];j++)
	{
		sum[0]=sum[0]+a[j];
	}
	
}
for(i=1;i<x[1];i++)
{
	if(x[1]%i==0)
	{
	a[m[1]]=i;
	 m[1]++;
	}
	for(j=0;j<m[1];j++)
	{
		sum[1]=sum[1]+a[j];
	}
	
}
 
 if(sum[0]==x[1]&&sum[1]==x[0])
 printf("yes %d %d",m[0],m[1]);
 else
 printf("no %d %d",m[0],m[1]);
 return 0;
    
}
