#include <stdio.h>
#include <math.h>
int main()
{
	int n,m,i,j,p=1,q=1;
	scanf("%d %d",&n,&m);
	for(i=2;i<=(n+1)/2;i++)
	    if(n%i==0)
	    {
		    p+=1;
	    }
	for(j=2;j<=(m+1)/2;j++)
	    if(m%j==0)
	    {
		    q+=1;
	    }
	int s=0,t=0;
	for(i=1;i<=(n+1)/2;i++)
	{
	    if(n%i==0)
	    {
	    	s+=i;
	    }
	}
	for(j=1;j<=(m+1)/2;j++)
	{
	    if(m%j==0)
	    {
	    	t+=j;
	    }
	}
	if(s==m&&t==n)
	printf("yes %d %d",p,q);
	else
	printf("no %d %d",p,q);
	return 0;
}
