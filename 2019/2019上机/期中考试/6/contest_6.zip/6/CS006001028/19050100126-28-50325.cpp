#include<stdio.h>
int main()
{
	int p,a[1000],i,n=1,k,j=0,m;
	scanf("%d",&p);
	for(n=1;n<10000;n++)
	{
		for(i=1;i<n;i++)
		{
			k=n%i;
			if(k==0)
			k++;
		}
		if(k==1)
		{
			a[j]=n;
			j++;
			k=0;
		}
		
	}
	m=a[p]+a[p+1]+a[p+2]+a[p+3]+a[p+4]+a[p+5]+a[p+6]+a[p+7]+a[p+8]+a[p+9]+a[p+10];
	printf("%d",m);
	return 0;
}
