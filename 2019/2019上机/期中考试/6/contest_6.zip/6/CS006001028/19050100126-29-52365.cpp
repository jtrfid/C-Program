#include<stdio.h>
int main()
{
	int p,n,d,m,j=0,i,a[100],k=0;
	scanf("%d",&p);
	for(n=1;n<10000;n++)
	{
		for(i=1;i<n;i++)
		{
			d=n%i;
			if(d==0)
			{
				m++;
			}
		}
		if(m==1)
		{
			a[j]=n;
			j++;
		}
		m=0;
	}
	k=a[p]+a[p+1]+a[p+2]+a[p+3]+a[p+4]+a[p+5]+a[p+6]+a[p+7]+a[p+8]+a[p+9]+a[p+10];
	printf("%d",k);
}
