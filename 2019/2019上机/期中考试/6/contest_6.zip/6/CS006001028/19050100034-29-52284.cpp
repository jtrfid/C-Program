#include<stdio.h>
#define N 160
int main()
{
    int p ,i,sum,j,k , a[N];
    scanf("%d",&p);
    if(p<=20||p>=150)
        scanf("%d",&p);
    a[0]=2;
    i=1;
    for(j=3 ;i<p+10 ;j++)
	{
        for(k=2 ;k<j ;k++)
		{
        	if(j%k==0)
                break;
        }
        if(k>=j)
		{
        	a[i]=j;
        	i++;
        }
    }
    sum=a[p-1];
    for(i=p ;i<p+10 ;i++)
        sum=sum+a[i];
    printf("%d",sum);
	return 0;
}
