#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d",&m);
	if(m){
		for(n=0;m%10;n++)
		{
			m=m/10;
		}
	}
	else
	n=1;
	printf("%d",n);
	return 0;
}
