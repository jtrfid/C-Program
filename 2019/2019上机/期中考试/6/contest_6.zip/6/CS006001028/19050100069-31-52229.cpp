#include<stdio.h>
int main()
{
	int ys(int x);
	int i,n,m,p=0,q=0;
	scanf("%d %d",&n,&m);
	for(i=1;i<n;i++){
		if(n%i==0)
		p=p+i;
	}
	for(i=1;i<m;i++){
		if(m%i==0)
		q=q+i;
	}
	if(p==m&&q==n)
	printf("yes %d %d",ys(n),ys(m));
	else printf("no %d %d",ys(n),ys(m));
	return 0;
	
	
}
int ys(int x)
{
	int i,k=0,o=0;
	for(i=1;i<x;i++){
	
	   if(x%i==0)
	   k++;
	   }
	return k;   
}
