#include<stdio.h>
int main()
{
	char a[10];
	int i=0,k;
	while ((a[i]=getchar())!='\n')
	{
		i++;
		k=i;
	}
	printf("%d",k);
}
