#include<stdio.h>

int main()
{
	int m,i;
	scanf("%d",&m);
	if(m!=0){
		for(i=0;m%10!=0;i++){
			m=m/10;
		}
	}
	else i=0;
	printf("%d",i);
	return 0;
}
