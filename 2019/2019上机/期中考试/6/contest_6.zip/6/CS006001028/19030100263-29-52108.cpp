#include<stdio.h>
int main()
{   int i,n,x=3,a[160];
    a[1]=2;
    a[2]=3;
    for(n=5;n<10000;n=n+2)
    for(i=2;i<=n/2;i++)
    {if(n%i==0)
     continue;
     a[x]=n;
     x+=1;
     }
     int p,z,sum=0;
     scanf("%d",&p);
     for(z=0;z<11;z++)
     sum=sum+a[p+z];
     printf("%d\n",sum);
     return 0;
}
