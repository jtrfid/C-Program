#include<stdio.h>

int main()
{
	int m,i,t=0;
	scanf("%d",&m);
	for(i=0;m%10!=0;i++){
 	  m=m/10;
	}
	printf("%d",i);
	return 0;
	
}
