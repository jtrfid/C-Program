#include<stdio.h>
#include<math.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	for(i=0;n%10!=0;i++){
	n=n/10;
	}
	printf("%d",i);
	return 0;
	
}
