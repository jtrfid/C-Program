#include <stdio.h>
#include <math.h>

int main()
{
	int m,n,s=0,i;
	scanf("%d",&m);
	
	for(i=8;i>=0;i--){
		n=pow(10,i);
		if((m/n)!=0){
		    s=i+1;
		    break;
		}
	}

    printf("%d",s);
	return 0;
}
