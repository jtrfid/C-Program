#include<stdio.h>
int main()
{
	int n,m,k,sumn=0,summ=0,i=0,j=0;
	scanf("%d %d",&n,&m);
	for(k=1;k<n;k++){
		if(n%k==0){
			sumn=sumn+k;
			i++;
		}
		
	}
	for(k=1;k<m;k++){
		if(m%k==0){
			summ=summ+k;
			j++;
		}
		
	}
	if(sumn==m&&summ==n)
	printf("yes %d %d",i,j);
	else
	printf("no %d %d",i,j);
	 
}
