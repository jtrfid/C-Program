#include<stdio.h>
int main()
{
    int n,m,a=0,b=0,i,j=0,k=0;
    scanf("%d%d",&n,&m);
    if(n<1||m>10000)
        scanf("%d%d",&n,&m);
    for(i=1 ;i<n ;i++)
	{
    	if(n%i==0)
		{
    	    a=a+i;
			j++;	
    	}
    }
    for(i=1 ;i<m ;i++){
    	if(m%i==0)
		{
    	    b=b+i;
			k++;	
    	}
    }
    if(a==m&&b==n){
    	printf("yes %d %d",j,k);
    }
    else
        printf("no %d %d",j,k);
	return 0;
}
