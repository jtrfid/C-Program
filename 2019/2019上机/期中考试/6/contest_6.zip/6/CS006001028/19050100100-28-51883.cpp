#include<stdio.h>
int main()
{
	int a,c;
	scanf("%d",&a);
	
	if((a/100000000)<10&&(a/100000000)!=0)
	{
	printf("9");
	}
	
	else if((a/10000000)<10&&(a/10000000)!=0)
	{
	printf("8");
	}
	
	else if((a/1000000)<10&&(a/1000000)!=0)
	{
	printf("7");
	}
	
	else if((a/100000)<10&&(a/100000)!=0)
	{
	printf("6");
	}
	
	else if((a/10000)<10&&(a/10000)!=0)
	{
	printf("5");
	}
	
	else if((a/1000)<10&&(a/1000)!=0)
	{
	printf("4");
	}
	
	else if((a/100)<10&&(a/100)!=0)
	{
	printf("3");
	}
	
	else if((a/10)<10&&(a/10)!=0)
	{
	printf("2");
	}
	
	else
	printf("1");
}
