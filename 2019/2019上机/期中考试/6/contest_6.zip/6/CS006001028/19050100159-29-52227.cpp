#include<stdio.h>
int main()
{
	int p,i,m=1,n=1,sum;
	int a[m];
	scanf("%d",&p);
	for(i=1;i<1000000;i++){
		if(n%i!=0)n++;
		else{
			a[m]=n;
			m++;
		}
	}
	sum=a[p]+a[p+1]+a[p+2]+a[p+3]+a[p+4]+a[p+5]+a[p+6]+a[p+7]+a[p+8]+a[p+9]+a[p+10];
	printf("%d",sum);
	return 0;
}
