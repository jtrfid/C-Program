#include <stdio.h>
int main()
{
	int a,w1,w2,w3,w4,w5,w6;
	scanf("%d",&a);
	if(a<100000 || (a=100000))
	{
		w1=a*0.1;
		printf("%d",(int)w1);
	}
	else if((a>100000 && a<200000) || (a=200000))
	{
		w2=w1+(a-100000)*0.75;
		printf("%d",(int)w2);
	}
	else if((a>200000 && a<400000) || (a=400000))
	{
		w3=w2+(a-200000)*0.05;
		printf("%d",(int)w3);
	}
	else if((a>400000 && a<600000) || (a=600000))
	{
		w4=w3+(a-400000)*0.03;
		printf("%d",(int)w4);
	}
	else if((a>600000 && a<1000000) || (a=1000000))
	{
		w5=w4+(a-600000)*0.15;
		printf("%d",(int)w5);
	}
	else
	{
	w6=w5+(a-1000000)*0.01;
	printf("%d",(int)w6);
	}
	return 0;
}
