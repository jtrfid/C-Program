#include<stdio.h>
int main()
{
	int s=0,l;
	scanf("%d",&l);
	if(l<=100000)
	s=0.1*l;
	else if(l<=200000)
	s=10000+0.075*(l-100000);
	else if(l<=400000)
	s=17500+(l-200000)*0.05;
	else if(l<=600000)
	s=27500+(l-400000)*0.03;
	else if(l<=1000000)
	s=33500+(l-600000)*0.015;
	else 
	s=39500+(l-1000000)*0.01;
	printf("%d",s);
	return 0;
}
