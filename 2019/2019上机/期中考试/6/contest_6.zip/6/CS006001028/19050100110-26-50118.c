#include <stdio.h>
int main()
{
	int i,j,a,b,c[4],swap;
	scanf("%d %d",&a,&b);
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=a*a-b*b;
	for(i=0;i<3;i++)
	{
		for(j=0;j<2-i;j++)
		{
			if(c[i]>c[j])
			{
				swap=c[i];
				c[i]=c[j];
				c[j]=swap;
			}
		}
	}
	printf("%d %d",c[3],c[0]);
	return 0;
}
