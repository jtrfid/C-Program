#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,max,min;
	4<=a<=1000,4<=b<=1000;
	scanf("%d%d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(c>d&&c>e&&c>f)
	max=c;
	else if(d>c&&d>e&&d>f)
	max=d;
	else if(e>c&&e>d&&e>f)
	max=e;
	else if(f>c&&f>e&&f>d)
	max=f;
	if(c<d&&c<e&&c<f)
	min=c;
	else if(d<c&&d<e&&d<f)
	min=d;
	else if(e<c&&e<d&&e<f)
	min=e;
	else if(f<c&&f<e&&f<d)
	min=f;
	printf("%d %d",max,min);
	return 0;
}
