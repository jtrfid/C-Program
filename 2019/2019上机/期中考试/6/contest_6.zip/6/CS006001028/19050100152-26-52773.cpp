#include<stdio.h>
int main()
{
	int a,b,c[4];
	scanf("%d %d",&a,&b);
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=a*a-b*b;
	if(c[0]<c[3])
	printf("%d %d",c[0],c[1]);
	else
	printf("%d %d",c[0],c[3]);
	return 0;
}
