#include<stdio.h>
#include<math.h>
int main()
{
	int m,i,t=0;
	scanf("%d",&m);
	for(i=0;m!=0;i++){
 	  m=m/10;
 	  t++;
	}
	printf("%d",t);
	return 0;
	
}
