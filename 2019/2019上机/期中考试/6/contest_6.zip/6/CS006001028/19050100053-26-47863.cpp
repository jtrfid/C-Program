#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c[3],i,j;
	scanf("%d %d",&a,&b);
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=a*a-b*b;
	for(i=0;i<4;i++)
	{
		int temp=0;
		for(j=i+1;j<4;j++){
			if(c[i]<c[j]);
			else{
				temp=c[i];
				c[i]=c[j];
				c[j]=temp;
			}
		}
	}

		printf("%d %d",c[3],c[0]);
	return 0;
}
