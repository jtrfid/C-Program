#include<stdio.h>
int main()
{
	int p,i,j,k,n,s;
	scanf("%d",&p);
	n=0;
	s=0;	
	for(i=2;n<p;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
				k = 0;
				break;
			}
			else
			k = 1;			
		}
		if(k==1)
		n=n+1;
		 
	}
	for(i=i;n>=p&&n<=p+10;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
				k = 0;
				break;
			}
			else
			k = 1;			
		}
		if(k==1)
		{
		n = n+1;
		s = s+i;
	    }
	}
	printf("%d",s);
	return 0;
	
	
}
