#include<stdio.h>

int main()
{
	int p,sum,n,i,x,j=0,q;
	scanf("%d",&p);
	x=0;
	int a[1000];
	q=0,n=2;
	while(q<=p+10){
		
		for (i=0;i<n;i++){
	    if(n%i==0)
	    x++;
        }
        if(x==0){
		a[q]=n;
        q++;
        }
		
        n++;
		x=0;              	
	}
	printf("%d",a[0]);
	sum;
	for(i=p-1;i<p+10;i++){
		sum+=a[i];
	}
	printf("%d",sum);
	return 0;
}

