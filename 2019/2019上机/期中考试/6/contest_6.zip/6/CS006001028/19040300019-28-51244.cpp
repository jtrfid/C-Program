#include<stdio.h>

int main()
{
	int m,p,n;
	scanf("%d",&m);
	p=0;
	n=m;
	while(n>0){
	n=n/10;
	p++;
	}
	printf("%d",p);
	if(n=0)
	printf("%d",1);
	return 0;
}
