#include<stdio.h>
#include<math.h>

int is_prime(int n);

int main()
{
	int p, n = 0, sum = 0, i, m, j;
	
	scanf("%d", &p); 
	
	i = 1;
	while(n < p){
		i++;
		if(is_prime(i))
		    n++;
	}
	
	n = 0;
	
	while(n < 11){
		if(is_prime(i)){
			n++;
			sum += i;
		}
		i++;
	}
	
	printf("%d", sum);
	
	return 0;
}


int is_prime(int n)
{
	int i, leap;
	
	for(i = 2; i <= sqrt(n); i++){
		if(n % i == 0){
			leap = 0;
			break;
		}
		leap = 1;
	}
	return(leap);
}
