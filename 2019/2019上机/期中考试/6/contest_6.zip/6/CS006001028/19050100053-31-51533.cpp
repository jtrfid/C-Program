#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,i,j,t=0,s=0,sum1=0,sum2=0,a[100],b[100];
	scanf("%d %d",&n,&m);
	for(i=1;i<n;i++){
		if(n%i==0){
			a[t]=i;
			sum1+=a[t];
			t++;
		}
		else;
	}
	for(j=1;j<m;j++){
		if(m%j==0){
			b[s]=j;
			sum2+=b[s];
			s++;
		}
		else;
	}
	if(sum1==m && sum2==n){
		printf("yes %d %d",t,s);
	}
	else{
		printf("no %d %d",t,s);
	}
	return 0;
	
	
}
