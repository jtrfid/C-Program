#include<stdio.h>

int main(){
	int m,q,x;
	
	scanf("%d",&m);
	q=0;
	
	if(m==0)
	printf("1");
	
	else{
	while(m!=0){
		m=m/10;
		q++;
	}
	
	printf("%d",q);}

		
	return 0;
}
