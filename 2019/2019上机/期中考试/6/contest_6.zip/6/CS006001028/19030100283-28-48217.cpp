#include<stdio.h>

int main(){
	int a,b;
	scanf("%d",&a);
	if(a!=0){
	for(b=0;a!=0;){
		a=a/10;
		b++; 
	}
}
	else if(a==0){
		b=1;
	}
	printf("%d",b);
	return 0;
}
