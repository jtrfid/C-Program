#include<stdio.h>
int main()
{
	int m,n,sum=0,num=0;
	scanf("%d %d",&m,&n);
	int i=0,z,j=0;
	for(z=1;z<m;z++)
	{
		if(m%z==0)
		{
		 i++;
		sum=sum+z;}
	}

	for(z=1;z<n;z++)
	{
		if(n%z==0)
		{
		j++;
		num=num+z;}
		
	}
	if((num==m)&&(sum==n))
	printf("yes ");
	else
	printf("no");
	printf("%d ",i);
	printf("%d",j);
	
}
