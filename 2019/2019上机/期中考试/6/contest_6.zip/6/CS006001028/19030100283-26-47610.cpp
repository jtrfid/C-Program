#include<stdio.h>

int main(){
	int a,b,c,d,e,f;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(c>=d&&c>=e&&c>=f){
		printf("%d ",c);
	}
	else if(d>=c&&d>=e&&d>=f){
		printf("%d ",d);
	}
	else if(e>=d&&e>=c&&e>=f){
		printf("%d ",e);
	}
	else if(f>=d&&f>=e&&f>=c){
		printf("%d ",f);
	}
	if(c<=d&&c<=e&&c<=f){
		printf("%d",c);
	}
	else if(d<=c&&d<=e&&d<=f){
		printf("%d",d);
	}
	else if(e<=d&&e<=c&&e<=f){
		printf("%d",e);
	}
	else if(f<=d&&f<=e&&f<=c){
		printf("%d",f);
	}
	return 0;
}
