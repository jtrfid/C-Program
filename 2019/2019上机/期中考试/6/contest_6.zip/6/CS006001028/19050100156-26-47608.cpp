#include<stdio.h>
int main()
{
	int t,a,b,c,d,e,f;
	
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	
	if(c>d)
	{
		t=c;
		c=d;
		d=t;
	}
	if(c>e)
	{
		t=c;
		c=e;
		e=t;
	}
	if(c>f)
	{
		t=c;
		c=f;
		f=t;
	}
	if(d<e)
	{
		t=d;
		d=e;
		e=t;
	}
	if(d<f)
	{
		t=d;
		d=f;
		f=t;
	}
	printf("%d %d",d,c);
}
