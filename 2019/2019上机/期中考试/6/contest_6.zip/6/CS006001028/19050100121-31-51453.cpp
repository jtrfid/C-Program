#include <stdio.h>

int main(){
	int n,m,a,b,s=0,c=0,d=0,i;
	scanf("%d %d",&n,&m);
	
	if(n>m){
		a=m;
		b=n;
	}
	else{
		a=n;
		b=m;
	}
	
	for(i=1;i<b;i++){
	    if(b==i*i)
	        s+=i;
    }
	
	for(i=1;i<b;i++){
		if(b%i==0)
			s+=i;
	}
	
	if(s==a)
	    printf("yes ");
	else
	    printf("no ");
	    
	for(i=1;i<n;i++){
		if(n%i==0)
			c++;
	}
	    
	for(i=1;i<m;i++){
		if(m%i==0)
			d++;
    }
    
    printf("%d %d",c,d);
    return 0;
	    
}
