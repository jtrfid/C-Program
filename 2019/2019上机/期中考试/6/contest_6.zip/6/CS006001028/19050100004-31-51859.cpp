#include<stdio.h>
int main(){
	int a, b, s, sum,i=0, n=0, m=0;
	scanf("%d %d",&a,&b);
	for(i=1;i<a;i++){
		if(a%i==0){
			s=s+i;
			n++;
		}
		
	}
	for(i=1;i<b;i++){
		if(b%i==0){
			sum=sum+i;
			m++;
		}
		
	}
	if(s==sum){
		printf("yes %d %d",n,m);
	}
	else{
		printf("no %d %d",n,m);
	
	}
	return 0;
}
