#include<stdio.h>
int main ()
{    int i,j,x;
    scanf("%d",&i);

    
    for(x=0;i!=0;x++)
	{
    	j=i%10;
    	i=i/10;
    }
	  printf("%d ",x); 
    
     return 0;
}
