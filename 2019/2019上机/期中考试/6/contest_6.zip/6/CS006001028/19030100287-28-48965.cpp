#include<stdio.h>
int main()
{
	int a , i;
	scanf("%d",&a);
	for(i = 0; a != 0;i++){
		a /= 10;
	}
	printf("%d",i);
	return 0;
}
