#include<stdio.h>

int main()
{
	int m, n = 0;
	
	scanf("%d", &m);
	
	if(m = 0)
	    n = 1;
	else{
	    while(m > 0){
		    n++;
		    m = m / 10;
	    }
    }
	printf("%d", n);
	
	return 0;
}
