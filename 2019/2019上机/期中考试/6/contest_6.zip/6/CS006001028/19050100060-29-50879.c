#include<stdio.h>
int Isprime(int x);
int main()
{
	int n,i,j,s=0,x=0,a[151];
	scanf("%d",&n);
	for(i=2;i<500;i++)
	{
		 if(Isprime(i)==0)
		 {
		 	a[x]=i;
		 	x++;
		 }
	}
	for(i=n-1;i<=n+9;i++)
	{
		s=s+a[i];
	}
	printf("%d",s);
}
int Isprime(int x)
{
	int i,j=0;
	for(i=2;i<x;i++)
	{
		if(x%i==0)
		{
			j=1;
			break;
		}
    }
    return j;
}
