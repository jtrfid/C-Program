#include <stdio.h>
int main()
{
	int m,n,a=0,b=0,c=0,d=0,i,j;
	scanf("%d %d",&n,&m);
	for(i=1;i<n;i++)
	{
		if(n%i==0)
		{
			a++;
			b +=i;
		}
	}
	for(j=1;j<m;j++)
	{
		if(m%j==0)
		{
			c++;
			d +=j;
		}
	}
	if(b==m&&d==n)
	printf("yes %d %d",a,c);
	else
	printf("no %d %d",a,c);
}
