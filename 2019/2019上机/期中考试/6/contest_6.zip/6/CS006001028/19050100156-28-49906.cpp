#include<stdio.h>
int main()
{
	int m,i,n;
	scanf("%d",&m);
	i=0;
	while(m!=0)
	{
		i++;
		m=m/10;
	}
	
	
	
	printf("%d",i);
}
