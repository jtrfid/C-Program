#include<stdio.h>
int main()
{   int i,q,y=0,x=0,n1,n2,a[10000],b[10000];
    scanf("%d %d",&n1,&n2);
    for(i=2;i<=n1;i++)
    {if(n1%i!=0)
     continue;
     a[x+1]=n1/i;
     x=x+1;
     }
     for(q=2;q<=n2;q++)
    {if(n2%q!=0)
     continue;
     b[y+1]=n2/q;
     y+=1;
     }
     int sum=0,p=0;
     for(int w=1;w<10000;w++)
    { sum+=a[w];
     p+=b[w];}
     if(sum==n2)
     printf("yes ");
     else if(p==n1)
     printf("yes ");
     
     else printf("no ");
     printf("%d %d",x,y);
     return 0;
}
