#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,g;
	scanf("%d %d",&a,&b);
	c=a*a+b*b;
	d=(a+b)*(a+b);
	e=(a-b)*(a-b);
	f=a*a-b*b;
	if (e>f)
	{
		    if (c>d)
			{
				printf("%d %d",c,f);
			}
			else 
			{
				printf("%d %d",d,f);
			}	
	}
		else
   {
			if (c>d)
			{
				printf("%d %d",c,e);
			}
			else 
			{
				printf("%d %d",d,e);
			}
   }	
}
