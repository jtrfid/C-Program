#include <stdio.h>
int main()
{
	int m,n=1;
	scanf("%d",&m);
    if(m<=9)
    printf("");
	else
	do
    {   m=m/10;
		n=n+1;		
    }while(m/10!=0);
	printf("%d",n);
	return 0;
}
