#include<stdio.h>
int main()
{
	int a,b,c=0,d=0,e=0,f=0,i,g=0,h=0;
	scanf("%d %d",&a,&b);
	for (i=1;i<a;i++)
	{
		if (a%i==0)
		{
			c++;
			d+=i;
		}
	}
	for (i=1;i<b;i++)
	{
		if (a%i==0)
		{
			f++;
			e+=i;
		}
	}
	if ((e==a)||(d==b))
	{
		printf("yes %d %d",c,f);
	}
	else 
	{
		printf("no %d %d",c,f);
	}
}
