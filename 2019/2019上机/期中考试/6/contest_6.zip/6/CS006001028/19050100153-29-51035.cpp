#include<stdio.h>
int main(){
	int x;
	int zhi(int x);
	int p,sum=0,i,n;
	scanf("%d",&p);
	n=0;
	
	for(i=2;n!=p+10;i++){
		if(zhi(i)){
			n++;
		if(n>=p)
		sum=sum+i;	
		}
		
	}
	printf("%d",sum);
	
	return 0;
}


int zhi(int x)
{
	int z=1;             //z=0����������z=1������ 
	int i;
	for(i=2;i<x;i++)
	    if (x%i==0)
	    z=0;
	
	return (z);
}

