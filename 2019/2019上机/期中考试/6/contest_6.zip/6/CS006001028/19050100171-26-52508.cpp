#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(c>e&&d>f){
	printf("%d %d",c,f);
    }
    else if(c>e&&d<f){
	printf("%d %d",c,d);
    }
    else if(c<e&&d>f){
	printf("%d %d",e,f);
    }
    else if(c<e&&d<f){
	printf("%d %d",e,d);
    }
    return 0;
}
