#include<stdio.h>
int main()
{
	int I;
	float sum;
	scanf("%d",&I);
	if(I<=100000)
	sum=I*0.1;
	else if(I>100000&&I<=200000)
	sum=10000+(I-100000)*0.01;
	printf("%.0f",sum);
}
