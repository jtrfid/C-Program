#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,max,min;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	max=c;
	min=c;
	if(c<d)
	max=d;
	if(max<e)
	max=e;
	if(max<f)
	max=f;
	if(c>d)
	min=d;
	if(min>e)
	min=e;
	if(min>f)
	min=f;
	printf("%d %d",max,min);
	return 0;
}
