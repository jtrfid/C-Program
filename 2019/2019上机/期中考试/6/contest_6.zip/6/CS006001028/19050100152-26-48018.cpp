#include<stdio.h>
int main()
{
	int a,b,max,min,i,c[4];
	scanf("%d %d",&a,&b);
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=a*a-b*b;
	max=c[0];
	min=c[0];
	for(i=0;i<4;i++)
	{
		if(c[i]<c[i+1])
		max=c[i+1];
	}
	for(i=0;i<4;i++)
	{
		if(c[i]>c[i+1])
		min=c[i+1];
	}
	printf("%d %d",max,min);
	return 0;
}
