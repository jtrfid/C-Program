#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	if(m>=0&&m<10)
	printf("1");
	if(m>=10&&m<100)
	printf("2");
	if(m>=100&&m<1000)
	printf("3");
	if(m>=1000&&m<10000)
	printf("4");
	if(m>=10000&&m<100000)
	printf("5");
	if(m>=100000&&m<1000000)
	printf("6");
	if(m>=1000000&&m<10000000)
	printf("7");
	if(m>=10000000&&m<100000000)
	printf("8");
	if(m>=100000000&&m<1000000000)
	printf("9");
	return 0;
	
}
