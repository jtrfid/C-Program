#include <stdio.h>
int main()
{
scanf("%d,%d",a>=4,b<100,&a,&b);
int a,b,x,y,z,d;
x=(a+b)*(a+b);
y=(a-b)*(a-b);
z=a*a+b*b;
d=a*a-b*b;
int max(x,y,z,d);
int main (x,y,z,d);
printf ("%d%d%d%d",x,y,z,d);
	return 0;
}
