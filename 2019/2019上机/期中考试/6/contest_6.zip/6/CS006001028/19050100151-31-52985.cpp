#include<stdio.h>

int main()
{
	int n,m,i,j=0,nn=0,nm=0,sn=0,sm=0;
	scanf("%d %d",&n,&m);
	for(i=1;i<n;i++)
	if(n%i==0){
	
	j++;
	sn=sn+i;}
	nn=j;
	j=0;
	for(i=1;i<m;i++)
	if(m%i==0){
	
	j++;
	sm=sm+i;}
	nm=j;
	if(sn==m&&sm==n)
	printf("yes %d %d",nn,nm);
	else
	printf("no %d %d",nn,nm);
	return 0;
}
