#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,x[3],i,j,tem;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
    x[0]=c;
    x[1]=d;
    x[2]=e;
    x[3]=f;
	for(i=0;i<3;i++){
		for(j=i+1;j<=3;j++){
			if(x[i]>x[j]){
				tem=x[i];
				x[i]=x[j];
				x[j]=tem;
			}
		}
	}
	printf("%d %d",x[3],x[0]);
	
	
	
	
	return 0;
}
