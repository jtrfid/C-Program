#include<stdio.h>
int main()
{
	int a,b,c,d,p,sum,i,j,k;
	scanf("%d",p);
	for(i=2;i<1000000;i++)
	{
		k=i;
		for(j=2;j<(i+1)/2;j++)
		{
			a=k/j;
			if(a*j==k)
			{
				b++;
				break;
			}
		}
		if(b==0)
		{
			c++;
		}
		b==0;
		if(c==p)
		sum=sum+i;
		if(c==p+10)
		break;
	}
	printf("%d",sum);
	return 0;
}
