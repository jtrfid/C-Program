#include<stdio.h>

int main()
{
	int m,n,k=1,p=1,i,sum=0,s[1000];
	scanf("%d%d",&n,&m);
	for(i=2;i<m;i++)
	    if(m%i==0)
	    {	
		    sum+=m/i;
		    k++;
	    }
	for(i=2;i<n;i++)
	    if(n%i==0)
	    {	
		    p++;
	    }	
	if(sum==n)printf("yes %d %d",p,k);
	else printf("no %d %d",p,k);
	return 0;    
}
