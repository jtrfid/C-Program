#include<stdio.h>
int main()
{
	int p,a=0,b,c,d=1,e,f,g=1,h=0,sum=0;
	scanf("%d",&p);
	for(b=2;a<p;b++){ 
	  for(c=2;c<b;c++){
	  	if(b%c==0){
	  		d=0;
	  	}
	  
	  	
	  }if(d){
	  	a++;
	  }
	}
	for(e=b;h<=10;e++){
	  for(f=2;f<e;f++){
	  	if(e%f==0){
	  		g=0;
	  	}
	  
	  }
	  if(g){
	  	h++;
	  	sum=sum+e;
	  	
	  }
	}
	printf("%d",sum);
	return 0;
	
	 
	    
}
