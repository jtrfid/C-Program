#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int i=0,z,j=0;
	for(z=1;z<m;z++)
	{
		if(m%z==0)
		 i++;
	}
	printf("%d ",i);
	for(z=1;z<n;z++)
	{
		if(n%z==0)
		j++;
		
	}
	printf("%d",j);
	
}
