#include<stdio.h>
int main()
{
	int n , m , i , j ,sum1 = 0 ,sum2 = 0 , num1 = 0 , num2 = 0;
	scanf("%d%d",&n,&m);
	for(i = 1;i < n;i++){
	
		if((n % i)==0 ){
		num1 +=1;
		sum1 += i;}
	}	
	for(j = 1;j < m;j++){
	
		if((m % j)==0 ){
		num2 +=1;
		sum2 += j;	}
	}	
	if(sum1 == m && sum2 == n)
		printf("yes ");
	else
		printf("no ");
	printf("%d %d",num1,num2);
	return 0;
			
}
