#include<stdio.h>
int main()
{
	int m,n,a=0,b=0,i,j,k=0,l=0;
	scanf("%d %d",&m,&n);
	for(i=1;i<m;i++)
	{
		if(m%i==0)
		{
			a = a+i;
			k = k+1;
		}
	}
	for(j=1;j<n;j++)
	{
		if(n%j==0)
		{
			b = b+j;
			l = l+1;
		}
	}
	if(a==n&&b==m)
	{
		printf("yes %d %d",k,l);
	}
	else
	{
		printf("no %d %d",k,l);
	}
	return 0;
}
