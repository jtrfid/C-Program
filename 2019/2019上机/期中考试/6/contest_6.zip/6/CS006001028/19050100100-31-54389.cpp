#include<stdio.h>
int main()
{
	int m,n,i,e,sum1=0,sum2=0;
	
	scanf("%d %d",&m,&n);
	
	for(i=2;i<m/2+1;i++)
	{
		if(m%i==0)
		sum1+=1;
	}
	
		for(i=2;i<n/2+1;i++)
	{
		if(n%i==0)
		sum2+=1;
	}
	
	if(sum1==n&&sum2==m)
	printf("yes %d %d",sum1,sum2);
	else
	printf("no %d %d",sum1,sum2);
	
}
