#include <stdio.h>
int main()
{
	int m,n,a,b,c,d,e,f,g,h,i;
	scanf("%d",&m);
	
	if(m==0)
	n=0;
	
	a=m/100000000;
	b=m%100000000/10000000;
	c=m%10000000/1000000;
	d=m%1000000/100000;
	e=m%100000/10000;
	f=m%10000/1000;
	g=m%1000/100;
	h=m%100/10;
	i=m%10/1;

	if(a!=0)
		n=9;
	else if(a==0&&b!=0)
		n=8;
	else if(a==0&&b==0&&c!=0)
		n=7;
	else if(a==0&&b==0&&c==0&&d!=0)
		n=6;
	else if(a==0&&b==0&&c==0&&d==0&&e!=0)
		n=5;
	else if(a==0&&b==0&&c==0&&d==0&&e==0&&f!=0)
		n=4;
	else if(a==0&&b==0&&c==0&&d==0&&e==0&&f==0&&g!=0)
		n=3;
	else if(a==0&&b==0&&c==0&&d==0&&e==0&&f==0&&g==0&&h!=0)
      	n=2;
	else if(a==0&&b==0&&c==0&&d==0&&e==0&&f==0&&g==0&&h==0&&i!=0)
		n=1;
	
	printf("%d",n);
	return 0;
}
