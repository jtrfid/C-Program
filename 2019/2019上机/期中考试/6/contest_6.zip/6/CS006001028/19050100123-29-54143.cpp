#include<stdio.h>
int main()
{
	int p,i,k,m=0,s[1000],c=0,l,b[100000],o=0,d=0;
	scanf("%d",&p);
	for(i=2;i<=10000;i++){
		for(k=1;k<=i;k++){
			if(i%k==0){
				s[m]=k;
				m++;
			}
		}
		for(l=0;l<m;l++){
			c=c+s[l];
		}
		if(c==i+1){
			b[o]=i;
			o++;
		}
		m=0;
		c=0;
	}
	for(i=p-1;i<=p+9;i++){
	    d=d+b[i];
	}
	printf("%d",d);
	return 0;
} 
