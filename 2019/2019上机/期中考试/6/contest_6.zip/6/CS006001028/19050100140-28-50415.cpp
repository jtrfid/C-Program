#include<stdio.h>

int main()
{
	int a, n=0, i, y=1;
	scanf("%d",&a);
	for(i=1;y!=0;i=i*10)
	  {
	  	y = a / i;
	  	n++;
	  }
	printf("%d",n-1);
	
	return 0;
}
