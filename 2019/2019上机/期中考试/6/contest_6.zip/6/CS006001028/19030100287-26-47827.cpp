#include<stdio.h>
#include<math.h>
int main()
{
	int a , b , c , d , e , f , max ,min;
	scanf("%d%d",&a,&b);
	c = (a + b) * (a + b);
	d =(a - b) * (a - b);
	e = a * a + b* b;
	f = a * a - b * b;
	if(c > e)
		max = c;
	else
		max = e;
	if(d < f)
		min = d;
	else
		min = f;
	printf("%d %d",max , min);
	
	
	
	
	
	
	
	
	
	return 0;
}
