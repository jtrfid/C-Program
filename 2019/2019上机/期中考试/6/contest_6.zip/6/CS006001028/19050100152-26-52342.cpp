#include<stdio.h>
int main()
{
	int a,b,x1,x2,x3,x4;
	scanf("%d %d",&a,&b);
	x1=(a+b)*(a+b);
	x2=(a-b)*(a-b);
	x3=a*a+b*b;
	x4=(a+b)*(a-b);
	if(x1>x2&&x1>x3&&x1>x4)
	{
		if(x2<x3&&x2<x4)
		printf("%d %d",x1,x2);
		if(x3<x2&&x3<x4)
		printf("%d %d",x1,x3);
		if(x4<x2&&x4<x3)
		printf("%d %d",x1,x4);
	}
	else if(x2>x1&&x2>x3&&x2>x4)
	{
		if(x1<x3&&x1<x4)
		printf("%d %d",x2,x1);
		if(x3<x1&&x3<x4)
		printf("%d %d",x2,x3);
		if(x4<x1&&x4<x3)
		printf("%d %d",x2,x4);
	}
	else if(x3>x1&&x3>x2&&x3>x4)
	{
		if(x1<x3&&x1<x4)
		printf("%d %d",x3,x1);
		if(x2<x1&&x2<x4)
		printf("%d %d",x3,x2);
		if(x4<x1&&x4<x2)
		printf("%d %d",x3,x4);
	}
	else if(x4>x1&&x4>x2&&x4>x3)
	{
		if(x1<x2&&x1<x3)
		printf("%d %d",x4,x1);
		if(x2<x1&&x2<x3)
		printf("%d %d",x4,x2);
		if(x3<x1&&x3<x2)
		printf("%d %d",x4,x3);
	}
	
}
