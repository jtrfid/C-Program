#include<stdio.h>

int sum(int x);
int num(int x);

int main()
{
	int m, n;
	
	scanf("%d %d", &m, &n);
	
	if(sum(m) == n && sum(n) == m)
	    printf("yes ");
	else
	    printf("no ");
	    
	printf("%d %d", num(m), num(n));    

	return 0;
}

int sum(int x)
{
	int i, sum = 0;
	
	for(i = 1; i < x; i++){
		if(x % i == 0){
			sum += i;
		}
	}
	return(sum);
}

int num(int x)
{
	int i, num = 0;
	
	for(i = 1; i < x; i++){
		if(x % i == 0){
			num++;
		}
	}
	return(num);
}
