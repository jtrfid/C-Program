#include<stdio.h>
int main()
{
	int a,b,n;
	n=1;
	scanf("%d",&a);
	while(a/10!=0)
	{
		n++;
		a=a/10;
	}
	printf("%d",n);
	return 0;
}
