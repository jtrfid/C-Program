#include<stdio.h>
int main()
{
	int m,s,i,k;
	scanf("%d",&m);
	if(m<0||m>999999999)
	    scanf("%d",&m);
	if(m<=9)
	    s=1;
	else if(m<=99)
	    s=2;
	else if(m<=999)
	    s=3;
	else if(m<=9999)
	    s=4;
	else if(m<=99999)
	    s=5;
	else if(m<=999999)
	    s=6;
	else if(m<=9999999)
	    s=7;
	else if(m<=99999999)
	    s=8;
	else 
	    s=9; 
	printf("%d",s);
	return 0;
}
