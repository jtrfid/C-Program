#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d",&m);
	if(m<10){
	n=1;
	printf("%d",n);}
	else if(m>=10&&m<99){
	n=2;
	printf("%d",n);}
	else if(m>=100&&m<999){
	n=3;
	printf("%d",n);}
	else if(m>=1000&&m<9999){
	n=4;
	printf("%d",n);}
	else if(m>=10000&&m<99999){
	n=5;
	printf("%d",n);}
	else if(m>=100000&&m<999999){
	n=6;
	printf("%d",n);}
	else if(m>=1000000&&m<9999999){
	n=7;
	printf("%d",n);}
	else if(m>=10000000&&m<99999999){
	n=8;
	printf("%d",n);}
	else if(m>=100000000&&m<999999999){
	n=9;
	printf("%d",n);}
	else printf("error");
	
	return 0;
}
