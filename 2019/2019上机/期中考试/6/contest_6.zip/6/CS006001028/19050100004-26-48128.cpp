#include<stdio.h>
int main()
{
	int a, b, c, d, e, f, min, max,s[3]={0},i=0;
	scanf("%d %d",&a,&b);
	s[0]=(a+b)*(a+b);
	s[1]=(a-b)*(a-b);
	s[2]=a*a+b*b;
	s[3]=a*a-b*b;
	if(s[0]<s[1]){
		min=s[0];
		max=s[1];
	}
	else{
		min=s[1];
		max=s[0];
	}
	for(i=1;i<=3;i++){
		if(min>=s[i]){
			min=s[i];
		}
		else{
			min=min;
		}
		if(max<=s[i]){
			max=s[i];
		}
		else{
			max=max;
		}
		
	}
	printf("%d %d",max,min);
	
	return 0;
}
