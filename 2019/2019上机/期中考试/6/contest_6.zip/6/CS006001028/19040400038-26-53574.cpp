#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,t;
	4<=a<=1000,4<=b<=1000;
	scanf("%d%d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(c>d)
	t=c,c=d,d=t;
	if(d>e)
	t=d,d=e,e=t;
	if(e>f)
	t=e,e=f,f=t;
	if(c>d)
	t=c,c=d,d=t;
	if(d>e)
	t=d,d=e,e=t;
	if(c>d)
	t=c,c=d,d=t;
	printf("%d %d",f,c);
	return 0;
}
