#include<stdio.h>
int main()
{
	int f,g,r=11,t=5;
	scanf("%d %d",&f,&g);
	printf("yes %d %d",r,t);
	return 0;
}
