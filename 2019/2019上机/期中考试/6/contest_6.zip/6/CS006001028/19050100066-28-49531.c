#include<stdio.h>

int main()
{
	int m, n = 0;
	
	scanf("%d", &m);
	
	while(m > 0){
		n++;
		m = m / 10;
	}
	
	printf("%d", n);
	
	return 0;
}
