#include<stdio.h>
#include<math.h>
int main()
{
	int i,j;
	int a,b,c[4],max,min;
	scanf("%d",&a);
	if(a<=100000)
	b=0.1*a;
	else if(a>100000&&a<=200000)
	b=10000+0.075*(b-100000);
	else if(a>200000&&a<=400000)
	b=17500+0.05*(a-200000);
	else if(a>400000&&a<=600000)
	b=17500+10000+0.03*(a-400000);
	else if(a>600000&&a<=1000000)
	b=27500+6000+0.015*(a-600000);
	else
	b=27500+6000+6000+0.01*(a-1000000);
	printf("%d",b);
	
}
