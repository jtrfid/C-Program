#include<stdio.h>
int main()
{
	int a,b,max,min,i,j,c[4];
	scanf("%d %d",&a,&b);
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=(a+b)*(a-b);
	max=-100000;
	min=100000;
	for(i=0;i<3;i++)
	{
		if(c[i]<c[i+1])
		max=c[i+1];
	}
	for(j=0;j<3;j++)
	{
		if(c[j]>c[j+1])
		min=c[j+1];
	}
	printf("%d %d",max,min);
	return 0;
}
