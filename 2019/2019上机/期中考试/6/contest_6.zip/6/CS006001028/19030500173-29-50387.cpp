#include<stdio.h>
int a[160];
int main()
{
	int i,j,p,count,l;
	int m,n;
	scanf("%d",&p);
	m=0;
	for(i=2;;i++)
	{ 
	 count=0;
		for(j=1;j<i+1;j++)
		{
			if(i%j==0)
			count++;}
			if (count==2)
			{
			a[m]=i;
			m++;}
			if(m==160)
			break;
			
	}
	n=0;
    for(l=p-1;l<p+10;l++)
    	n=n+a[l];
    printf("%d",n);
    return 0;
    
    
}
