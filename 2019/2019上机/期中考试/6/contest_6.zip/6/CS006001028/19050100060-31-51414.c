#include<stdio.h>
int main()
{
	int a,b,m=0,n=0,i,j,s1=0,s2=0;
	scanf("%d %d",&a,&b);
	for(i=1;i<a;i++)
	{
		if(a%i==0)
		{
			s1=s1+i;
			m++;
		}
	}
	for(i=1;i<b;i++)
	{
		if(b%i==0)
		{
			s2=s2+i;
			n++;
		}
	}
	if(s1==b&&s2==a)
	printf("yes %d %d",m,n);
	else
	printf("no %d %d",m,n);
}
