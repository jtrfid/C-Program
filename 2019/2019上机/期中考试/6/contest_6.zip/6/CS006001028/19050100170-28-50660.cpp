# include<stdio.h>
int main()
{
	int m,i,sum,a;
	scanf("%d",&m);
	if(m>=0&&m<=999999999){
	
	sum=0;
	   for(i=0;m!=0;i++){
	   
	      
	      sum += 1;
	      m /= 10;}
} printf("%d",sum);
return 0;
}
