#include<stdio.h>
int main()
{
	int m,n,i,k=0,g=0,sum1=0,sum2=0;
	scanf("%d %d",&m,&n);
	for(i=1;i<m;i++){
		if(m%i==0){
			k++;
			sum1+=i;
		}
	}
	for(i=1;i<n;i++){
		if(n%i==0){
			g++;
			sum2+=i;
		}
	}
	if((sum1==n)&&(sum2==m)){
		printf("yes %d %d",k,g);
	}
	else 
	{
		printf("no %d %d",k,g);
	}
	return 0;
}
