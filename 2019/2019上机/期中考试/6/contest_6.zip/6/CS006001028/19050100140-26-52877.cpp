#include<stdio.h>

int main()
{
	int a, b, i, j, k, n[4]={0};
	
	scanf("%d %d",&a,&b);
	
	n[1] = (a + b)*(a + b);
	n[2] = (a - b)*(a - b);
	n[3] = a * a + b * b;
	n[4] = a * a - b * b;
	
	for(i=1;i<=4;i++)
	{
		for(j=1;j<=i;j++)
		{
			if (n[i]<n[j])
		        {
		        k = n[j];
		        n[j] = n[i];
		        n[i] = k;
	            }
		}
	}
	
	printf("%d %d",n[4],n[1]);
	return 0;
}
