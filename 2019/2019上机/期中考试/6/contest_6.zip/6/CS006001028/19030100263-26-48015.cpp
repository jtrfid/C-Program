#include<stdio.h>
int main()
{   int a,b;
    scanf("%d %d",&a,&b);
	int t,p1,p2,p3,p4;
	p1=(a+b)*(a+b);
	p2=(a-b)*(a-b);
	p3=a*a+b*b;
	p4=a*a-b*b;
    if(p2<p4)
    {t=p2;p2=p4;p4=t;}
    printf("%d %d",p1,p4);
    return 0;
}
