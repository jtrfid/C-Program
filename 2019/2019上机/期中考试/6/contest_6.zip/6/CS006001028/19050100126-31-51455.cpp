#include<stdio.h>
int main()
{
	int m,n,i,j,a,b,c=0,d=0,e=0,f=0;
	scanf("%d %d",&m,&n);
	for(i=1;i<m;i++)
	{
		a=m%i;
		if(a==0)
		{
			c=c+i;
			e++;
		}
	}
	for(j=1;j<n;j++)
	{
		b=n%j;
		if(b==0)
		{
			d=d+j;
			f++;
		}
	}
	if(c==n&&d==m)
	{
		printf("yes");
		printf("%d %d",e,f);
	}
	else
	{
		printf("no");
		printf("%d %d",e,f);
		
	}
	return 0;
}
