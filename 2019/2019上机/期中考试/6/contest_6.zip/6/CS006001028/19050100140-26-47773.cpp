#include<stdio.h>

int main()
{
	int a, b, i, j, k, n[4];
	
	scanf("%d %d",&a,&b);
	
	n[1] = (a + b)*(a + b);
	n[2] = (a - b)*(a - b);
	n[3] = a * a + b * b;
	n[4] = a * a - b * b;
	
	for(i=1;i<4;i++)
	{
		for(j=1;j<i;j++)
		{
			if (n[j]>n[j+1])
		        k = n[j];
		        n[j] = n[j+1];
		        n[j+1] = k;
		}
	}
	
	printf("%d %d",n[1],n[4]);
	return 0;
}
