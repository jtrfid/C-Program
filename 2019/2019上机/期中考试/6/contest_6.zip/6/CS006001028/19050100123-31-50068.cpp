#include<stdio.h>
int main()
{
	int i,a,b,c=0,d=0,k=0,t=0,s[1000],m[1000];
	scanf("%d%d",&a,&b);
	for(i=1;i<a;i++){
		if(a%i==0){
			s[k]=i;
			k++;
		}
	}
	for(i=1;i<b;i++){
		if(b%i==0){
			m[t]=i;
			t++;
		}
	}
	for(i=0;i<k;i++){
		c=c+s[i];
	}
	for(i=0;i<t;i++){
		d=d+m[i];
	}
	if(c==b&&d==a)
	    printf("yes %d %d",k,t);
	else
	    printf("no %d %d",k,t);
	return 0;
} 
