#include<stdio.h>

int main(){
	int a,b,c,d,k,j,i;
	scanf("%d %d",&a,&b);
	for(i=1,c=0,k=0;i<a;i++){
		if((a%i)!=0){
			;
		}
		else if((a%i)==0){
			c=c+i;
			k=k+1;
		}
	}
	for(i=1,d=0,j=0;i<b;i++){
		if((b%i)!=0){
			;
		}
		else if((b%i)==0){
			d=d+i;
			j=j+1;
		}
	}
	if(a==d&&b==c){
		printf("yes %d %d",k,j);
	}
	else if(a!=d||b!=c){
		printf("no %d %d",k,j);
	}
	return 0;
}
