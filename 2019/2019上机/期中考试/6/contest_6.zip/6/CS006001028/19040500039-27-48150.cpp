#include<stdio.h>

int main()
{
	int profit;
	scanf("%d",&profit);
	int reward;
	if(profit<=100000)
	    reward=profit/10;
	else if(profit<=200000)
	    reward=(profit-100000)*75/1000+10000;
	else if(profit<=400000)
	    reward=(profit-200000)/20+17500;
	else if(profit<=600000)
	    reward=(profit-400000)*3/100+27500;
	else if(profit<=1000000)
	    reward=(profit-600000)*15/1000+33500;
	else
	    reward=(profit-1000000)/100+39500;
	printf("%d",reward);
	return 0;
}
