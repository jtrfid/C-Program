#include<stdio.h>
int main()
{
	int m,a=1,j=1;
	scanf("%d",&m);
	for(j=1;m/a>=10;j++)
	 a=a*10;
	printf("%d",j);
}
