#include<stdio.h>
int main()
{
	int a,b,x,y,z,h;
	scanf("%d,%d",a>=4,b<1000,&a,&b);
	x=(a+b)*(a+b);
	y=(a-b)*(a-b);
	z=a*a+b*b;
	h=a*a-b*b;
	printf("%d%d%d%d",x,y,z,h);
	return 0;
}
