#include<stdio.h>
#include<math.h>
int main()
{
	int p,i=0,j,a[500],m=2,sum=0;
	scanf("%d",&p);
	for(m=2;;m++){
		for(j=2;j<=m;j++)
		{
			if(m%j==0) break;
			else;
		}
		if(m==j) 
		{
		    a[i]=m;
		    
		    if(i>=p+10)
		    goto end;
		    else;
		    i++;
		} 
		else;
	}
end:{	for(i=p-1;i<p+10;i++){
		sum+=a[i];
	}
	printf("%d",sum);
}
	return 0;
}
