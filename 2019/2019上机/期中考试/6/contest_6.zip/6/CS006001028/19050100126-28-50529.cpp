#include<stdio.h>
int main()
{
	int m,j=0;
	scanf("%d",&m);
	while(m!=0)
	{
		m=m/10;
		j++;
	}
	printf("%d",j);
	return 0;
}
