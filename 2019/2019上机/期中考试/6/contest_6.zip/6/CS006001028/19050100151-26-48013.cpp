#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(a*b>=0)
	{
	printf("%d ",c);
	if(d>f)
	printf("%d",f);
	else
	printf("%d",d);
}
	else{
		printf("%d ",d);
		if(c>f)
		printf("%d",f);
		else
		printf("%d",c);
	}
	
	return 0;
}
