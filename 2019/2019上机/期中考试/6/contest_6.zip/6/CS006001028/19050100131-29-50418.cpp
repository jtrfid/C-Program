#include<stdio.h>
#define N 150
int main()
{
	int a[N],j,k,i=0,h=1,p,l,sum=0;
	scanf("%d",&p);
	 p=p-1;
	for(j=2;i<N;j++){
	
	  for(k=2;k<j;k++){
	  
	   if(j%k==0){
	   
	     h=0;
	     break;}
	  if(h){
	  
	  a[i]=j;
	  i++;   }
	
	     
	 }
	 }
	 
	 for(l=p;l<p+10;l++)
	   sum=sum+a[l];
	 printf("%d",sum);
	 return 0;
	   
	 
	 
}
