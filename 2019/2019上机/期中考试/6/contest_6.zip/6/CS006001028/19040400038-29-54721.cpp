#include<stdio.h>
#define m 150
int main()
{
	int i,p,a[m],sum;
	scanf("%d",&p);
	20<=p<=150;
	for(i=2,i<=999999999999,i++)
	 
	 for(n=i-1,n>=1,n--)
	  
	  if((i%n)!=0)
	   for(x=0,x<=150,x++)
	   a[x]=i;
	   
      
     
     sum=a[p-1]+a[p]+a[p+1]+a[p+2]+a[p+3]+a[p+4]+a[p+5]+a[p+6]+a[p+7]+a[p+8]+a[p+9];
     printf("%d",sum);
     return 0;
	  
	  
}
