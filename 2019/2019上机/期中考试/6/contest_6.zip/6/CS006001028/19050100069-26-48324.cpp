#include<stdio.h>
int main()
{
	int max(int a,int b);
	int min(int m,int n);
	
	int a,b,c,d,e,f,m,n;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	m=max(c,max(d,max(e,f)));
    n=min(c,min(d,min(e,f)));
    printf("%d %d",m,n);
	
	
	
}
int max(int a,int b)
{ 
int q;
	if(a>b)
	q=a;
	else 
	q=b;
	

}
int min(int m,int n)
{   int p;
	if(m>n)
	p=n;
	else
	p=m;


}
