#include<stdio.h>

int main()
{
	int a, n=0, i, y=1;
	scanf("%d",&a);
	for(i=1;y!=0;i=i*10)
	  {
	  	y = a / i;
	  	n++;
	  }
	if (a==0)
	printf("1");
	else
	printf("%d",n-1);
	
	return 0;
}
