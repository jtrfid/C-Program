#include<stdio.h>
int main()
{
	int m,b;
	scanf("%d",&m);
	0<=m<=999999999;
	if(m/100000000!=0)
	b=9;
	else if(m/10000000!=0)
	b=8;
	else if(m/1000000!=0)
	b=7;
	else if(m/100000!=0)
	b=6;
	else if(m/10000!=0)
	b=5;
	else if(m/1000!=0)
	b=4;
	else if(m/100!=0)
	b=3;
	else if(m/10!=0)
	b=2;
	else if(m/1!=0)
	b=1;
	printf("%d",b);
	return 0;
}
