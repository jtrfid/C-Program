#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c,d,e,f,g,h;
	a<=4&&a>0,b<1000&&b>0;
	scanf("%d %d" ,&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	printf("%d %d",c,f);
	return 0;
	
}
