#include<stdio.h>
int main()
{
	int a,b,m,n,p,q,max,min;
	scanf("%d %d",&a,&b);
	m=(a+b)*(a+b);
	n=(a-b)*(a-b);
	p=a*a+b*b;
	q=a*a-b*b;
	if(m>n){
		max=m;
		if(m>p){
			max=m;
		    if(m>q)max=m;
			else max=q;
		)
		else if(m<p){
			if(p>q)max=p;
			else max=q;
		}
	}
	else{
		max=n;
		if(n>p){
			max=n;
			if(n>q)max=n;
			else max=q;
		}
		else if(n<p){
			if(p>q)max=p;
			else max=q;
		}
	}
	if(m<n){
		min=m;
		if(m<p){
			min=m;
		    if(m<q)min=m;
			else min=q;
		)
		else if(m>p){
			if(p<q)min=p;
			else min=q;
		}
	}
	else{
		min=n;
		if(n<p){
			min=n;
			if(n<q)min=n;
			else min=q;
		}
		else if(n>p){
			if(p<q)min=p;
			else min=q;
		}
	}
	printf("%d %d",max,min);
	return 0;
}
