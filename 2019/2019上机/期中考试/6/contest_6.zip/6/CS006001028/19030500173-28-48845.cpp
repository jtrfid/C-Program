#include<stdio.h>
int main()
{
	int i,j;
	int m,n;
	scanf("%d",&m);
	
	for (i=1;i<10;i++)
	{m=m/10;
	if(m==0)
	break;
	if(m>0)
	continue;
		
	}
	printf("%d",i);
	return 0;
}
