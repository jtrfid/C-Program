#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,max,min;
	scanf("%d %d",&a,&b);
	c = (a + b)*(a + b);
	d = (a - b)*(a - b);
	e = a*a + b*b;
	f = a*a - b*b;
	if(c>d){
		max = c;
		min = d;
	}
	else{
		max = d;
		min = c;
	}
	if(e>max){
		max = e;
	}
	if(f>max)	{
		max = f;	
	}
	if(e<min){
		min = e;
	}
	if(f<min){
		min = f;
	}
	printf("%d %d",max,min);
	return 0;
			
	
		
	
}
