#include<stdio.h>
int main()
{
	int m;
	scanf("%f",&m,0<=m<=999999999);
	printf("%d",m);
	return 0;
	
	
	
	
	
	
	
	
	
	
}
