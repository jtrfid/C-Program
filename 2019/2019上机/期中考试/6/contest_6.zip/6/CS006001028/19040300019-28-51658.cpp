#include<stdio.h>

int main()
{
	int m,p;
	scanf("%d",&m);
	p=0;
	if(m==0)
	printf("1");
	else {

	while(m>0){
		m/=10;
		p++;
	}
	printf("%d",p);}
	return 0;
	
	
}
