#include<stdio.h>
#include<math.h>
int main()
{
	int m,b,max,min;
	scanf("%d %d",&m,&b);
	int h=pow(m+b,2);
	int j=pow(m-b,2);
	int k=pow(m,2)+pow(b,2);
	int l=pow(m,2)-pow(b,2);
	int a[]={h,j,k,l};
    for(int i=0;i<4;i++)
     for(int k=0;k<4-i;k++)
     if(a[k]>a[k+1])
     {
     	int t=a[k];
     	a[k]=a[k+1];
     	a[k+1]=t;}
     printf("%d %d",a[0],a[3]);
	return 0;
	
}
