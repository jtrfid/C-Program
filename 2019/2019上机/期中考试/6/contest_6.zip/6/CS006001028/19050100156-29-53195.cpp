#include<stdio.h>
int main()
{
	int p,k,i,j,n,a[10000],num=0;
	scanf("%d",&p);
	n=1;
	for(i=2;i<10000;i++)
		{
		for(j=2;j<=i/2;j++)
		{
			if(i%j==0)
			break;
		}
		if(j>i/2)
		{
		
		
		
			
		a[n]=i;
		n++;
		
		}
	}
		for(k=p;k<=p+10;k++)
		num=num+a[k];
		
	printf("%d ",num);
}

