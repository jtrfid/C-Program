#include <stdio.h>

int main()
{
	int m,n,s=1,i;
	scanf("%d",&m);
	
	
    while((m/10)!=0){
	    s++;
		m=m/10;
		    
	}


    printf("%d",s);
	return 0;
}
