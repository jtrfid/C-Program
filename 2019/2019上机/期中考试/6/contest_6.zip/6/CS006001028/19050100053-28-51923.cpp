#include<stdio.h>
#include<math.h>
int main()
{
	int m,i;
	scanf("%d",&m);
	for(i=0;m!=0;i++){
 	  m=m/10;
	}
	printf("%d",i);
	return 0;
	
}
