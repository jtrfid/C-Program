#include<stdio.h>
int main()
{
	int m,t;
	scanf("%d",&m);
	if(m<=0&&m<10)
	t=1;
	else if(m<100)
	t=2;
	else if(m<1000)
	t=3;
	else if(m<10000)
	t=4;
	else if(m<100000)
	t=5;
	else if(m<1000000)
	t=6;
	else if(m<10000000)
	t=7;
	else if(m<100000000)
	t=8;
	else if(m<=999999999)
	t=9;
	printf("%d",t);
	return 0;
}
