#include<stdio.h>
int main(){
	int a,b[500]={},i,j,k=1,t,sum=0;
	
	scanf("%d",&a);
	for(i=2;b[a+10]==0;i++,sum=0){
		for(j=1;j<=i;j++){
			if(i%j==0){
				sum++;
			}
		}
		if(sum==2){
		b[k]=i;
		k++;}
	}
	t=b[a]+b[a+1]+b[a+2]+b[a+3]+b[a+4]+b[a+5]+b[a+6]+b[a+7]+b[a+8]+b[a+9]+b[a+10];
	printf("%d",t);
}
