#include<stdio.h>
int main()
{
	int n,i=0;
	scanf("%d",&n);
	if(n==0) i=1;
	while(n!=0)
	{
		n=n/10;
		i++;
	}
	printf("%d",i);
	
}
