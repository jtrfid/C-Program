#include<stdio.h>
int main()
{
	int m,s,i,k;
	scanf("%d",&m);
	if(m<0||m>999999999)
	    scanf("%d",&m);
	
	s=0;
	for(i=10 ;k!=0 ;i*=10)
	{
		k=m/i;
		s++;
	}
	
	printf("%d",s);
	return 0;
}
