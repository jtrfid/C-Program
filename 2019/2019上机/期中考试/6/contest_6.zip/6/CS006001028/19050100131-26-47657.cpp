#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(b>a)
	  printf("%d %d",c,f);
	else
	  printf("%d %d",c,d);
}
