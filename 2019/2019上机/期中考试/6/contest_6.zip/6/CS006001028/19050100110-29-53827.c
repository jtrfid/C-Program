#include <stdio.h>
int main()
{
	int sum=0,a,i;
	scanf("%d%",&a);
	for(i=2;i<=(a+10);i++)
	{
		if((i%2==0)||(i%3==0)||(i%5==0)||(i%7==0))
		continue;
		else
		sum+=i;
	}
	printf("%d",sum);
	return 0;
}
