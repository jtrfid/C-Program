#include<stdio.h>

int main()
{
	int m, n, i, j, y=0, a[10000]={0}, b[10000]={0}, k=0, t=0, sumo=0, sumt=0;
	
	scanf("%d %d",&m,&n);
	
		for(i=1;i<m;i++)
	{
		y = m % i;
		if (y==0)
		{
			k++;
			a[k]=i;
		}
    }
        for(i=1;i<=k;i++)
        sumo = sumo + a[i];
       
       	for(i=1;i<n;i++)
	{
		y = n % i;
		if (y==0)
		{
			t++;
			b[t]=i;
		}
    }
        for(i=1;i<=t;i++)
        sumt = sumt + b[i];
        
    if(m==sumt&&n==sumo)
    printf("yes %d %d",k,t);
    else
    printf("no %d %d",k,t);
    return 0;
}
       
