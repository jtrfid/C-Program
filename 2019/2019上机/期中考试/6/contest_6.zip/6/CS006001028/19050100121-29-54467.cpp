#include <stdio.h>
#include <math.h>

int main()
{
	int p,a[149]={2,3,5,7,12,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,91},i,s;
	scanf("%d",&p);
	for(i=0;i<p+10;i++)
	s+=a[i];


    printf("%d",s);
	
	return 0;

}
