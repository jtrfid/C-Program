#include<stdio.h>
int main()
{
	int ss(int a);
	int p,i,k=0,sum=0;
	scanf("%d",&p);
	for(i=1;i<10000;i++){
		if(ss(i))
		k++;
	    if(k>p-1&&k<p+11){
	    	sum=sum+i;
	    }
	}
	printf("%d",sum);
	
	
	
}
int ss(int a)
{
	int i,k=2;
	for(i=2;i<a;i++){
		if(a%i!=0)
		k++;
	}
	if(k==a)
	return 1;
	else return 0;
	
}
