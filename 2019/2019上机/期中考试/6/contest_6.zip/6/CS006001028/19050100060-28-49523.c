#include<stdio.h>
int main()
{
	int n,t,i;
	scanf("%d",&n);
	for(i=1;;i++)
	{
		n=n/10;
		if(n==0)
		break;
	}
	printf("%d",i);
}
