#include<stdio.h>
#define N 1000
int main()
{
	int p,i=2, n=2, s=0, h, sum;
	int a[N];
	scanf("%d",&p);
     for(i=2,s=0;i<N;i++){
     	for(n=2;i%n!=0;n++){
     		s++;
	}
     	
     	if(s==i-2){
     		h++;
     		a[h]=i;
     	}
     }
    
     sum=a[p]+a[p+1]+a[p+2]+a[p+3]+a[p+4]+a[p+5]+a[p+6]+a[p+7]+a[p+8]+a[p+9]+a[p+10];
     printf("%d",sum);
     return 0;
}
