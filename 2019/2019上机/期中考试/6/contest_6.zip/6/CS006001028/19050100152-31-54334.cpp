#include<stdio.h>
int main()
{
	int m,n,j,i,a,b,c,d,e,f;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		a=m%i;
		if(a==0)
		{
			c=c+i;
			e++;
		}
	}
	for(j=0;j<n;j++)
	{
		b=n%j;
		if(b==0)
		{
			d=d+j;
			f++;
		}
	}
	if(c==n&&d==m)
	printf("yes %d %d",e,f);
	else
	printf("no %d %d",e,f);
	return 0;
}
