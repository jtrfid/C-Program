#include<stdio.h>

int main()
{
	int m;
	scanf("%d",&m);
	if(m/10==0)printf("1");
	else if(m/100==0)printf("2");
	else if(m/1000==0)printf("3");
	else if(m/10000==0)printf("4");
	else if(m/100000==0)printf("5");
	else if(m/1000000==0)printf("6");
	else if(m/10000000==0)printf("7");
	else if(m/100000000==0)printf("8");
	else if(m/1000000000==0)printf("9");
	
	return 0;

	
}
