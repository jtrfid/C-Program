#include<stdio.h>
#include<math.h>
int main()
{
	int p,i,j,a[100],m=2,sum=0;
	scanf("%d",&p);
	for(i=0;m<=500;m++){
		for(j=2;j<=m;j++)
		{
			if(m%j==0) break;
			else;
		}
		if(m==j) 
		{a[i]=m;
		i++;} 
		else;
	}
	for(i=p-1;i<p+10;i++){
		sum+=a[i];
	}
	printf("%d",sum);
	return 0;
}
