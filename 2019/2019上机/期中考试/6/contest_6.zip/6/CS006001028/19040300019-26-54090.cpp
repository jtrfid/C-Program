#include<stdio.h>

int main()
{
	int a,b,i;
	scanf("%d %d",&a,&b);
	int x[100];
	x[0]=(a+b)*(a+b);
	x[1]=(a-b)*(a-b);
	x[2]=a*a+b*b;
	x[3]=a*a-b*b;
	int max=x[0],min=x[0];
	for(i=0;i<4;i++){
		if(max<x[i])
		max=x[i];
		if(min>x[i])
		min=x[i];
	}
	printf("%d %d",max,min);
	return 0;
	
	
	
}
