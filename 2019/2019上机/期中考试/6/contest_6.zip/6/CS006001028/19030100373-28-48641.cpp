#include<stdio.h>

int main()
{
	int m,i,n = 10;
	scanf("%d",&m);
	for(i=1000000000;m/i==0;i/10)
	{
		n = n-1;
	}
	printf("%d",n);
	return 0;
} 
