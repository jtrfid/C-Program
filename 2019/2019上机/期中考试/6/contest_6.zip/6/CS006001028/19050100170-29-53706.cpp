# include<stdio.h>
int main()
{
	int p,a[10000],j,b,sum=0,i,k=0;
	scanf("%d",&p);
	
	
	if(p>20&&p<150){
	   for(i=2;i<10000;i++){
	   
	      
	    b=0;
		for(j=2;j<i;j++)
		     if(i%j==0)
			   	b++;
		if(b==0)
		  {
		  	a[k]=i;
		  	k++;
		  }
	
	
	}   
	      
	}   for(i=p-1;i<p-1+11;i++)
	      sum += a[i];
	 printf("%d",sum);  
}
