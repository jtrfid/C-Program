#include<stdio.h>
int main()
{
	int a,b,c[3],i,j,k;
	scanf("%d %d",&a,&b);
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=a*a-b*b;
	for(i=0;i<3;i++)
	{
		
		for(j=i+1;j<=3;j++)
		{
			if(c[i]>c[j])
			{
				k=c[i];
				c[i]=c[j];
				c[j]=k;
			}
		}
	}
	printf("%d %d",c[3],c[0]);
	return 0;
}
