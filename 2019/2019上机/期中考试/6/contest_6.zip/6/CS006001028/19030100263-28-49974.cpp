#include<stdio.h>
int main()
{   int a,i;
    scanf("%d",&a);
    if(a>99999999)
    i=9;
    else if(a>9999999)
    i=8;
    else if(a>999999)
    i=7;
    else if(a>99999)
    i=6;
    else if(a>9999)
    i=5;
    else if(a>999)
    i=4;
    else if(a>99)
    i=3;
    else if(a>9)
    i=2;
    else
    i=1;
    printf("%d",i);
    return 0;
    
    
}
