#include<stdio.h>
int main()
{
	int a,i;
	
	scanf("%d",&a);
	
	if(a<=100000)
	{
		i=0.1*a;
	}
	
	else if(a>100000)
	{
		i=10000+(a-100000)*0.01;
	}
	
	printf("%d",i);
}
