#include<stdio.h>
#include<math.h>

int main()
{
	int zhishu(int x);
    int i,p,x=0,a[150],sum=0;
	scanf("%d",&p);
	for(i=2;i<10000000;i++)
	   if(zhishu(i))
	   {
		    a[x]=i;
		    x++;
	   }
	sum=a[p-1]+a[p]+a[p+1]+a[p+2]+a[p+3]+a[p+4]+a[p+5]+a[p+6]+a[p+7]+a[p+8]+a[p+9];   
	printf("%d",sum);   
	       
		
	return 0;

	
}
int zhishu(int x)
{
	int i,z=1;
	for(i=2;i<x;i++)
	    if(x%i==0)
		{
	    	z=0;
			break;
	    }
	return z;    
}
