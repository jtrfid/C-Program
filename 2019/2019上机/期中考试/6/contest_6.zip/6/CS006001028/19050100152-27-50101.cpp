#include<stdio.h>
int main()
{
	int money,a;
	scanf("%d",&money);
	if(money<100000)
	a=money*0.1;
	else if(money>100000&&money<200000)
	a=10000+(money-100000)*0.075;
	else if(money>200000&&money<400000)
	a=17500+(money-200000)*0.05;
	else if(money>400000&&money<600000)
	a=27500+(money-400000)*0.03;
	else if(money>600000&&money<1000000)
	a=33500+(money-600000)*0.015;
	else
	a=39500+(money-1000000)*0.01;
	printf("%d",a);
	return 0;
}
