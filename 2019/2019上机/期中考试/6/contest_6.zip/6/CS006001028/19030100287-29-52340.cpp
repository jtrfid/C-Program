#include<stdio.h>
int main()
{
	int p , b , c , d =0 , e =0;
	scanf("%d",&p);
	for(b = 10;b < 1000000;b++){
		
		for(c = 2;c <= b;c++)
		{
			if(b % c == 0 )
			break;
		}
		if(c == b){
			d ++;
			if((d + p) >= p)
				e +=b;
			
		}
		else if((d + 4) == (p + 10))
		break;
	}
	printf("%d",e);
	return 0;
}
	
	
	
	
	
	



















