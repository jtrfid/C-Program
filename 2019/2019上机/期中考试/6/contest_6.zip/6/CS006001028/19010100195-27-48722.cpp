#include<stdio.h>
int main()
{
	int i,x;
	scanf("%d",&i);
	if(i<=100000)
	x=0.1*i;
	else if(i<=200000)
	x=10000+(i-100000)*0.075;
	else if(i<=400000)
	x=17500+(i-200000)*0.05;
	else if(i<=600000)
	x=i*0.03+15500;
	else if(i<=1000000)
	x=0.015*i+24500;
	else
	x=0.01*i+29500;
	printf("%d",x);
	return 0;
}
