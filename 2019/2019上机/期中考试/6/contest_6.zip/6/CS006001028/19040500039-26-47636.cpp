#include<stdio.h>

int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int price[4];
	price[0]=(a+b)*(a+b);
	price[1]=(a-b)*(a-b);
	price[2]=a*a+b*b;
	price[3]=a*a-b*b;
	int max=price[0],min=price[0];
	for(int i=1;i<4;i++)
	{
		if(max<price[i])
		    max=price[i];
		if(min>price[i])
		    min=price[i];
	}
	printf("%d %d",max,min);
	return 0;
}
