#include<stdio.h>
int main()
{
	int a,b,sum,m,n,x,y;
	n=0;m=0;
	scanf("%d %d",&a,&b);
	for(y=2;y<a;y++)
	{
		x=a/y;
		if(a=x*y)
		sum=sum+y+1;
	}
	for(y=1;y<=a;y++)
	{
		x=a/y;
		if(a=x*y)
		n++;
	}
	for(y=1;y<=b;y++)
	{
		x=b/y;
		if(b=x*y)
		m++;
	}
	n=n-1;m=m-1;
	if(sum=b)
	printf("yes ");
	else
	printf("no ");
	printf("%d %d",n,m);
}
