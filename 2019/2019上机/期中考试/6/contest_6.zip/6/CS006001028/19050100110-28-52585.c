#include <stdio.h>
int main()
{
	int a,i,b;
	scanf("%d",&a);
	b=a/10;
	for(i=1;b>0;i++){
	b=b/10;
	}
	printf("%d",i);
	return 0;
}
