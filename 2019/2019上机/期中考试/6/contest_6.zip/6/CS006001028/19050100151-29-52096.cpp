#include<stdio.h>
int q(int a)
{
	int i;
	for(i=2;i<a;i++){
		if(a%i==0){
		
		return 0;
		break;}
		
	}
	if(a==i)
	return 1;
}
int main()
{
	int p,i,j=0,m,s=0;
	scanf("%d",&p);
	for(i=2;j<p;i++)
	if(q(i))
	j++;
	m=i-1;
	j=0;
	for(i=m;j<11;i++)
	if(q(i)==1){
	j++;
	s=s+i;
   }
   printf("%d",s);
	return 0;
}
