#include<stdio.h>
#include<math.h>
int main()
{
	int a,i,b,c;
	scanf("%d",&a);
	for(i=1;;i++){
	
	b=pow(10,i);
	if(a/b==0){
	c=i;
	break;
	}
	
	}
	printf("%d",c);
	return 0;
}
