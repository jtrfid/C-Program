#include<stdio.h>
int main()
{
	int a, b, c, d, e, f, min, max;
	scanf("%d %d", &a, &b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=(a*a)+(b*b);
	f=(a*a)-(b*b);
	min=c;
	max=c;
	if(d<min){
		min=d;
	}
    if(e<min){
			min=e;
   }
	if(f<min){
			min=f;
	}
	
	if(d>max){
		max=d;
	}
	if(e>max){
		max=e;
	}
	if(f>max){
		max=f;
	}
	printf("%d %d",max,min);
	return 0;
	
}
