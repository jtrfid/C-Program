#include<stdio.h>
int main()
{
	int f,r=1081;
	scanf("%d",&f);
	printf("%d",r);
	return 0;
}
