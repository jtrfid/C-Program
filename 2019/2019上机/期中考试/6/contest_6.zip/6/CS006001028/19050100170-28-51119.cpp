# include<stdio.h>
int main()
{
int m,i,sum=0,a;
scanf("%d",&m);
  if(m>=0&&m<=999999999)
	
      
    for(i=0;m!=0;i++){
	   
	      
    sum += 1;
    m /= 10;}
   
    printf("%d",sum);
    return 0;
}
