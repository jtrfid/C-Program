#include<stdio.h>

int main()
{
	char a;
	int count=0;
	while((a=getchar())>='0' && a<='9')
	        count++;
	printf("%d",count);
	return 0;
}
