#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,i,max,mini;
	scanf("%d %d",&a,&b);
	int c[4];
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=a*a-b*b;
	for(i=0;i<3;i++)
		{
	
			if(c[i]>c[i+1])
			{					
				max=c[i];	
				mini=c[i+1];	
			}
			else
			{
				max=c[i+1];
				mini=c[i];
			}
		}
	printf("%d %d",max,mini);
	return 0;
}
