#include<stdio.h>
int main()
{
	int p,sum=0,a[50000],i,b[200],j,k,c,d;
	scanf("%d",&p);
	d=p;
	b[0]=2;
	for(i=0;i<50000;i++)
	a[i]=i+1;
	for(c=1,i=0;i<50000;i++);
	{
		k=0;
		for(j=2;j<a[i];j++){
			k=1;
		    if(a[i]%j==0){
		    	k=0;
		    }			
		}
        if(k){
          b[c]=a[i]; 
		  c++;       	
        }
	}
	for(;p<=d+10;p++){
		sum=sum+b[p-1];
	}
	printf("%d",sum);
	return 0;
}
