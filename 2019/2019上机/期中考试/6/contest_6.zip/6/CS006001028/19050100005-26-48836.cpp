#include<stdio.h>
int main ()
{    signed int a,b,i,j,k,l,n,m,x;
     scanf("%d %d",&a,&b);
     i=(a+b)*(a+b);
     j=(a-b)*(a-b);
     k=a*a+b*b;
     l=a*a-b*b;
    
     int y[4]={i,j,k,l};
     for(n=0;n<4;n++)
     for(m=0;m<3-n;n++)
     {if(y[n]>y[n+1])
      x=y[n];
      y[n]=y[n+1];
      y[n+1]=x;
	       
     }
     
     printf("%d %d",y[3],y[0]);
     return 0;
}
