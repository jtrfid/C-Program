#include<stdio.h>
int main()
{
	int ss(int a);
	int p,i,k=0,sum=0;
	scanf("%d",&p);
	for(i=3;i<10000;i++){
		if(ss(i)==0)
		k++;
	   if(k>p-1&&k<p+11){
	    	sum=sum+i;
	    }
	}
	printf("%d",sum);
	
	
	
}
int ss(int a)
{
	int i,k=2,m;
	for(i=2;i<a;i++)
	if(a%i!=0) 
	k++;
	if(k==a)
	m=0;
	else
	m=1;
	return m;
}
