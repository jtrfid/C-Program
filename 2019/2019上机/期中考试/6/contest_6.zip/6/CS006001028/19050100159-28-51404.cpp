#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d",&m);
	if(m<10)n=1;
	else if(m>=10&&m<99)n=2;
	else if(m>=100&&m<999)n=3;
	else if(m>=1000&&m<9999)n=4;
	else if(m>=10000&&m<99999)n=5;
	else if(m>=100000&&m<999999)n=6;
	else if(m>=1000000&&m<9999999)n=7;
	else if(m>=10000000&&m<99999999)n=8;
	else if(m>=100000000&&m<999999999)n=9;
	printf("%d",n);
	return 0;
}
