#include<stdio.h>
int ss(int n)
{
	int i;
	int j=1;
	for(i=2;i<n;i++)
	{ if(n%i==0)
	 j=0;}
	return j;
}
int main()
{
	int sum=0;
	int p,m,i=0,n;
	scanf("%d",&p);
	for(m=2;i<=p+10;m++)
	{
		if(ss(m)==1)
		{
		i++;
		if(i>=p&&i<=(p+10))
		sum=sum+m;}
		
	}
	printf("%d",sum);
}
