#include <stdio.h>
int main()
{
	int p,i,j,n=1,m=0;
	scanf("%d",&p);
	
	for(i=3;i<10000;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			break;
			
			if(j==i-1)
			break;
		}
		if(i%j!=0)
		{
			n++;
	        if(n>=p&&n<=p+10)
		    m=m+i;
		}
	}
	printf("%d",m);
	return 0;
}
