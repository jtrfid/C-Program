#include<stdio.h>
int a[160],b[160],sum[2],x[2];
int main()
{
	
int i,j,m[2],n;
scanf("%d %d",&x[0],&x[1]);
m[2]=0;
for(n=0;n<2;n++)
{

for(i=1;i<x[n];i++)
{
	if(x[n]%i==0)
	{
	a[m[n]]=i;
	 m[n]++;
	}
	for(j=0;j<m[n];j++)
	{
		sum[n]=sum[n]+a[j];
	}
	
}

}   
 if(sum[0]==x[1]&&sum[1]==x[0])
 printf("yes %d %d",m[0],m[1]);
 else
 printf("no %d %d",m[0],m[1]);
 return 0;
    
}
