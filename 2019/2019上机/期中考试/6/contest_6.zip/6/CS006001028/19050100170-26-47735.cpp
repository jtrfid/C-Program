# include<stdio.h>
int main()
{
	int a,b,max,min,c[4],t,j,i;
	scanf("%d%d",&a,&b);
	if(a>=4&&b<1000&b>4){

	   c[0]=(a+b)*(a+b);
	   c[1]=a*a+b*b;
	   c[2]=(a-b)*(a-b);
	   c[3]=a*a-b*b;
	   for(j=0;j<3;j++)
	      for(i=0;i<3-j;i++)
	         if(c[i]>c[i+1]){
	         
	         t=c[i];
	         c[i]=c[i+1];
	         c[i+1]=t;}
	         
	           
	       
	   
	   
	
}   printf("%d %d",c[3],c[0]);
	return 0;
}
