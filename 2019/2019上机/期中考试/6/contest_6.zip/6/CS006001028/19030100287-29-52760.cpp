#include<stdio.h>
int main()
{
	int p , b , c , d =0 , e =0;
	scanf("%d",&p);
	for(b = 2;b <1000000000 ;b++){
		
		for(c = 2;c <= 1000000;c++)
		{
			if(b % c == 0 )
			break;
		}
		if(c == b){
			d ++;
			if(d  >= p)
				e +=b;
			
		}
		else if(d >= (p + 10))
		break;
	}
	printf("%d",e);
	return 0;
}
	
	
	
	
	
	



















