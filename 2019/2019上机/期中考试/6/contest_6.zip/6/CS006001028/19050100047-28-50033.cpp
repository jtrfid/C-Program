#include <stdio.h>
int main()
{
	int m,n=1;
	scanf("%d",&m);
    do
    {
		n=n+1;	
		m=m/10;
    }while(m/10!=0);
	printf("%d",n);
	return 0;
}
