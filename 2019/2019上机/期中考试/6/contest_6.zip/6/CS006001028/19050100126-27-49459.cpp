#include<stdio.h>
int main()
{
	int m,i=0;
	scanf("%d",&m);
	while(m!=0)
	{
		m=m/10;
		i++;
	}
	printf("%d",i);
	return 0;
}
