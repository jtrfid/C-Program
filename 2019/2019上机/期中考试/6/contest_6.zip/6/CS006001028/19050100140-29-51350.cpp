#include<stdio.h>

int main()
{
	int p, i, j, y, k=1 ,num=0, m[160]={0};
	scanf("%d",&p);
	
	for(i=1;i<=160;i++)
	{
		for(j=2;j<i;j++)
		{
		y = i % j;
		if (y==0)
		  break;
	    }
	    if (j==i)
	    {
	    m[k]=i;
	    k++;
	    }
	}
	num = m[p];
	for(i=1;i<=10;i++)
	num = num + m[p+i];
	
	printf("%d",num);	
	return 0;
}
