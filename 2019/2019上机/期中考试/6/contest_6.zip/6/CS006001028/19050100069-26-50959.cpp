#include<stdio.h>
int main()
{
	int max(int a,int b);
	int min(int m,int n);
	
	int a,b,c,d,e,f,m,n;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	m=max(c,max(d,max(e,f)));
    n=min(c,min(d,min(e,f)));
    printf("%d %d",m,n);
    return 0;
	
	
	
}
int max(int y,int t)
{ 
    int q;
	if(y>t)
	q=y;
	else 
	q=t;
	return q;
}
int min(int x,int o)
{   int p;
	if(x>o)
	p=o;
	else
	p=x;
	return p;
}
