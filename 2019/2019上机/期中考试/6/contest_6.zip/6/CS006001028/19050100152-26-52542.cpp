#include<stdio.h>
int main()
{
	int a,b,i,j,c[4]={0};
	scanf("%d %d",&a,&b);
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=(a+b)*(a-b);
	if(c[0]>c[2])
	printf("%d %d",c[0],c[3]);
	else
	printf("%d %d",c[1],c[3]);
	return 0;
}
