#include<stdio.h>
int main()
{
	int a,b,d,e,f;
	
	scanf("%d %d",&a,&b);
	
	
	d=a*a-b*b;
	e=(a+b)*(a+b);
	f=(a-b)*(a-b);
	
	if(f<d)
	{
		printf("%d %d",e,f);
	}
	
	else if(f>d)
	{
		printf("%d %d",e,d);
	}
	return 0;
}
