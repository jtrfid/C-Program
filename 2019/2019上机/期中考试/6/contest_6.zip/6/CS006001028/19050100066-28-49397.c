#include<stdio.h>

int main()
{
	int m, n = 0, t;
	
	scanf("%d", &m);
	
	t = m;
	while(t > 0){
		n++;
		t = t / 10;
	}
	
	printf("%d", n);
	return 0;
}
