#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	scanf("%d %d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(d<f)
	printf("%d %d",c,d);
	else
	printf("%d %d",c,f);
	return 0;
}
