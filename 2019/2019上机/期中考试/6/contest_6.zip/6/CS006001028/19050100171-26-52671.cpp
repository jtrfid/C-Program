#include<stdio.>
int main()
{
	int p;
	int sum=0
	int isprime[170];
	scanf("%d",&p);
	for(int i=2;;++i)
	{if(isprime[i])
	scanf("")
	}
	
	
}
