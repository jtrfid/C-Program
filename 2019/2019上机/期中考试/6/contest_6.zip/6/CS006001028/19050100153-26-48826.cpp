#include<stdio.h>

int main(){
	int a,b;
	int x,y,z,w;
	int i,j,k;
	scanf("%d %d",&a,&b);
	
	x=(a+b)*(a+b);
	y=(a-b)*(a-b);
	z=a*a+b*b;
	w=a*a-b*b;
	
	i=x>y? x:y;
	j=i>z? i:z;
	k=j>w? j:w;
	
	printf("%d ",k);
	
	i=x<y? x:y;
	j=i<z? i:z;
	k=j<w? j:w;
	
	printf("%d",k);
	
	return 0;
}

