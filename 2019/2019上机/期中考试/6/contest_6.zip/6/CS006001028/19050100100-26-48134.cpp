#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	
	scanf("%d %d",&a,&b);
	
	c=a*a+b*b;
	d=a*a-b*b;
	e=(a+b)*(a+b);
	f=(a-b)*(a-b);
	
		if(e<c)
	{
		printf("%d",c);
	}
	
		if(c<e)
	{
		printf("%d",e);
	}
	
	
	if(f<d)
	{
		printf("%d",f);
	}
	
	else if(f>d)
	{
		printf("%d",d);
	}
	
	return 0;
	
}
