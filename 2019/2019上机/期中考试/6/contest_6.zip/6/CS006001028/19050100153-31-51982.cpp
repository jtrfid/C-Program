#include<stdio.h>
int main(){
	
	int m,n;
	int yues(int x);
	int yuen(int n);
	int x,y;
	
	scanf("%d %d",&m,&n);
	
	if(yues(m)==n||yues(n)==m)
	printf("yes ");
	else
	printf("no ");
	
	x=yuen(m);
	y=yuen(n);
	
	printf("%d %d",x,y);
	
	return 0;
}

int yues(int x){
	int i,sum=0;
	
	for(i=1;i<x;i++){
		if(x%i==0)
		sum=sum+i;
	}
	return (sum);
}

int yuen(int n){
	int i,k=0;
	
	for(i=1;i<n;i++){
		if(n%i==0)
		k++;
	}
	return (k);
}
