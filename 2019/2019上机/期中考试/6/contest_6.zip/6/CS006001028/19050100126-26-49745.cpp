#include<stdio.h>
int main()
{
	int a,b,c[4],i;
	scanf("%d %d",&a,&b);
	c[1]=(a+b)*(a+b);
	c[2]=(a-b)*(a-b);
	c[3]=a*a+b*b;
	c[4]=a*a-b*b;
	if(c[2]<c[4])
	printf("%d %d",c[1],c[2]);
	else
	printf("%d %d",c[1],c[4]);
	
	return 0;
}
