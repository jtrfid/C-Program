#include<stdio.h>

int main()
{
	int a, b, d=0, x=0, k=0, n[4]={0};
	
	scanf("%d %d",&a,&b);
	
	n[1] = (a + b)*(a + b);
	n[2] = (a - b)*(a - b);
	n[3] = a * a + b * b;
	n[4] = a * a - b * b;
	
    if (n[1]>=n[2]&&n[1]>=n[3]&&n[1]>=n[4])
    d=n[1];
    else if(n[2]>=n[1]&&n[2]>=n[3]&&n[2]>=n[4])
    d=n[2];
    else if(n[3]>=n[1]&&n[3]>=n[2]&&n[3]>=n[4])
    d=n[3];
    else if(n[4]>=n[1]&&n[4]>=n[3]&&n[4]>=n[2])
    d=n[4];
    
    if (n[1]<=n[2]&&n[1]<=n[3]&&n[1]<=n[4])
    x=n[1];
    else if(n[2]<=n[1]&&n[2]<=n[3]&&n[2]<=n[4])
    x=n[2];
    else if(n[3]<=n[1]&&n[3]<=n[2]&&n[3]<=n[4])
    x=n[3];
    else if(n[4]<=n[1]&&n[4]<=n[3]&&n[4]<=n[2])
    x=n[4];
	
	printf("%d %d",d,x);
	return 0;
}
