#include<stdio.h>
int main()
{
	int m,i,n;
	scanf("%d",&m);
	for(i=1;i<=9;++i){
		n=m%(10^i);
		if(n=0)break;
	}
	printf("%d",i);
	return 0;
}
