#include<stdio.h>
int main(){
	int m,n,i,j,sum=0,num=0,c=0,d=0;
	scanf("%d %d",&m,&n);
	for(i=1;i<m;i++){
		if(m%i==0){
			sum+=i;
			c++;
		}
	}
	for(j=1;j<n;j++){
		if(n%j==0){
			num+=j;
			d++;
		}
	}
	if((sum==n)&&(num==m)){
		printf("yes ");
		printf("%d %d",c,d);
	}
	else{
		printf("no ");
		printf("%d %d",c,d);
	}
	return 0;
}
