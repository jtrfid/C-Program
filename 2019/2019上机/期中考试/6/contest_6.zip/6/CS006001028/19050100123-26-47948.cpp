#include<stdio.h>
int main()
{
    int a,b,c,d,e,f,g=-100000,m=100000;
	scanf("%d%d",&a,&b);
	c=(a+b)*(a+b);
	d=(a-b)*(a-b);
	e=a*a+b*b;
	f=a*a-b*b;
	if(c>g)
	    g=c;
	if(d>g)
	    g=d;
	if(e>g)
	    g=e;
	if(f>g)
	    g=f;
	if(c<m)
	    m=c;
	if(d<m)
	    m=d;
    if(e<m)
	    m=e;
	if(f<m)
	    m=f;
	printf("%d %d",g,m);
	return 0;		  
} 
