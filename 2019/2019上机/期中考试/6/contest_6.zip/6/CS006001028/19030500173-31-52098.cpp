#include<stdio.h>
int sum[2];
int main()
{
	
int i,j,m,n,x,y;
scanf("%d %d",&x,&y);
m=0;
n=0;

for(i=1;i<x;i++)
{
	if(x%i==0)
	{
	
	
	sum[0]=sum[0]+i;
	 m++;
	}
	
	
}

for(i=1;i<y;i++)
{
	if(y%i==0)
	{
	
	sum[1]=sum[1]+i;
	 n++;
	}
	
	
}
  
 if(sum[0]==y&&sum[1]==x)
 printf("yes %d %d",m,n);
 else
 printf("no %d %d",m,n);
 return 0;
    
}
