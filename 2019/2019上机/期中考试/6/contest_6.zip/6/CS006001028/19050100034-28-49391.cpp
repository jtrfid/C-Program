#include<stdio.h>
int main()
{
	int n,s,i,k;
	scanf("%d",&n);
	if(i<0||i>999999999)
	    scanf("%d",&n);
	s=0;
	for(i=10 ;k!=0 ;i*=10)
	{
		k=n/i;
		s++;
	}
	
	printf("%d",s);
	return 0;
}
