#include<stdio.h>

int main(){
	int judge(int t);
	int p,k,i;
	int sum=0;
	scanf("%d",&p);
	for(i=1,k=1;k<=p+10;i++){
		if(judge(i)==1&&k<p){
			k=k+1;
		}
		else if(judge(i)==1&&k>=p){
			k=k+1;
			sum=sum+i;
		}
		else if(judge(i)==0){
			;
		}
	}
	printf("%d",sum);
	return 0;
}
int judge(int t){
	int m,i;
	for(m=0,i=1;i<=t;i++){
		if((t%i)==0){
			m=m+1;
		} 
		else if((t%i)!=0){
			m=m;
		}
	}
	if(m==2){
		return 1;
	}
	else if(m!=2){
		return 0;
	}
}
