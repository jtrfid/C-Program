#include<stdio.h>

int main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	int sum1=0,sum2=0;
	int count1=0,count2=0;
	for(int i=1;i<m;i++)
	    if(m%i==0){
	    	sum1+=i;
	    	count1++;
	    }
	for(int i=1;i<n;i++)
	    if(n%i==0){
	    	sum2+=i;
	    	count2++;
	    }
	if(sum1==n && sum2==m)
	    printf("yes ");
	else
	    printf("no ");
	printf("%d %d",count1,count2);
	return 0;
}
