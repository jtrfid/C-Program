#include <stdio.h>

int main(){
	int a,b,c[4],i,j;
	scanf("%d %d",&a,&b);
	
	c[0]=(a+b)*(a+b);
	c[1]=(a-b)*(a-b);
	c[2]=a*a+b*b;
	c[3]=a*a-b*b;
	
	if(c[0]>c[2])
	    i=c[0];
	else
	    i=c[2];
		
	if(c[1]>c[3])
	    j=c[3];
	else
	    j=c[1];
	
	
	printf("%d %d",i,j);
	return 0;
	
}
