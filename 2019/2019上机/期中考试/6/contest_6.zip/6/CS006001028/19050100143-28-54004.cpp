#include<stdio.h>
#define n 10
int main()
{
	char a[n];
	int i=0,k;
	while ((a[i]=getchar())!='\n')
	{
		i++;
		k=i;
	}
	printf("%d",k);
}
