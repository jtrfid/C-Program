#include<stdio.h>
int main()
{
    double i;
    int a; 
	scanf("%lf",&i);
	if(0<=i&&i<=100000)
	    a=0.1*i;
	else if(i>100000&&i<=200000)
	    a=10000+(i-100000)*0.075;
	else if(i>200000&&i<=400000)
	    a=17500+(i-200000)*0.05;
	else if(i>400000&&i<=600000)
	    a=27500+(i-400000)*0.03;
	else if(i>600000&&i<=1000000)
	    a=33500+(i-600000)*0.015;
	else
	    a=39500+(i-1000000)*0.01;
	printf("%d",a);
	return 0;
} 
