#include<stdio.h>
int main()
{
	int m,i,n=0;
	scanf("%d",&m);
	for(i=10;m/i!=0;i=i*10)
	n++;
	printf("%d",n+1);
	return 0;
}
