#include<stdio.h>
int main()
{   int s(int x);
	int p,a=1,b,c,d=1,e,f,h=0,sum=0;
	scanf("%d",&p);
	for(b=2;a<p;b++) 
	
	  if (s(b)){
	  	a++;
	  }
	
	for(e=b;h<=10;e++){
	  
	  if (s(e)){
	  	h++;
	  	sum=sum+e;
	  	
	  }
	}
	printf("%d",sum);
	return 0;
	
	 
	    
}
int s (int x){int g=1,c;
	for(c=2;c<x;c++){
	  	if(x%c==0){
	  		g=0;
	  		break;
	  	}
	 
	  	}
	  	return g;
	  
	  	
	  }
