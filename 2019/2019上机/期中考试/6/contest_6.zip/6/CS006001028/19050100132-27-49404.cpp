#include<stdio.h>
int main()
{
	int I;
	int sum;
	scanf("%d",&I);
	if(I<=100000&&I>=0)
	sum=I*0.1;
	else if(I>100000&&I<=200000)
	sum=10000+(I-100000)*0.075;
	else if(I>200000&&I<=400000)
	sum=17500+(I-200000)*0.05;
	else if(I>400000&&I<=600000)
	sum=27500+(I-400000)*0.03;
	else if(I>600000&&I<=1000000)
	sum=33500+(I-600000)*0.015;
	else if(I>1000000)
	sum=39500+(I-1000000)*0.01;
	printf("%d",sum);
}
