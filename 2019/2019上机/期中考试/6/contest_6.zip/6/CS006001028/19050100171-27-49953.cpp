#include<stdio.h>
int main()
{
	float m,n;
	scanf("%f",&m);
	if(m<=100000){
		n=m/10;
	printf("%f",n);
    }
	else if(m>100000&&m<=200000){
	n=10000+(m-100000)/(7.5);
	printf("%f",n);
	}
	else if(m>200000&&m<=400000){
		n=20000+(m-200000)/5;
		printf("%f",n);
	}
	else if(m>400000&&m<=600000){
		n=40000+(m-400000)/3;
		printf("%f",n);
	}
	else if(m>600000&&m<=1000000){
		n=60000+(m-600000)/(1.5);
		printf("%f",n);
	}
	else if(m>1000000){
		n=100000+(m-1000000)/1;
		printf("%f",n);
	}
	return 0;

}
