#include<stdio.h>
int main()
{
	int a,b,x,y,m,n,temp,t;
	scanf("%d %d",&a,&b);
	x=(a+b)*(a+b);
	y=(a-b)*(a-b);
	m=a*a+b*b;
	n=a*a-b*b;
	if(x>y)
	temp=x;
	else if(x<y)
	temp=y;
    if(n>y)
    t=y;
    else if(n<y)
    t=n;
	printf("%d %d",temp,t);
	return 0;
}
