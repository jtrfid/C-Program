#include<stdio.h>
int main()
{
	int a,x,y;
	scanf("%d",&a);
	if(a<=5000)
	{
	x=0;
	y=5000;
	}
	else if(a>5000&&a<=10000)
	{x=(a-5000)*0.05;}
	else if(a>10000&&a<=20000)
	{x=250+(a-10000)*0.08;}
	else if(a>20000&&a<=30000)
	{x=250+800+(a-20000)*0.15;}
	else if(a>30000)
	{x=250+800+3000+(a-30000)*0.35;}
	y=a-x;
	printf("%d %d",x,y);
	return 0;
}
