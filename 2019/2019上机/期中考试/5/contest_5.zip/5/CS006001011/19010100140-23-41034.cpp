#include<stdio.h>
int main()
{
	int a,b,c,i,n;
	scanf("%d",&a);
	if(a==1)
	printf("No");
	else
	if(a==2)
	printf("Yes");
	else
	if(a>2)
	{
	for(i=2;i<a;i++)
{
	b=a%i;
	if(b==0)
	{printf("No");
	i=a+1;
	}
}
if	(i==a)
printf("Yes");
}
return 0;
}
