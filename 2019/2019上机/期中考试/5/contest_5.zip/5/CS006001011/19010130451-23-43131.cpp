#include<stdio.h>
int main()
{int a,i;
scanf("%d",&a);
for(i=1;i++;i<=a-1)
{if(a%i==0) printf("no");break;}
for(i=1;i++;i<=a-1)
{if(a%i!=0) printf("yes");break;}
}
