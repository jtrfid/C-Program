#include<stdio.h>
int main()
{
	int q,w,e,r,sum;
	int tem;
	sum=q+w+e+r;
	double mny1,mny2;
	scanf("%d %d %d %d",&q,&w,&e,&r);
	mny1=(q+w+e+r)*0.70;
	if(sum>=300)
	{
		tem=sum/300;
		mny2=sum*1.00-(tem*100.00);
	}
	else mny2=sum;
	if(mny1>mny2)
	{
		printf("2 %.2lf",mny2);
	}
	else {
		printf("1 %.2lf",mny1);
	}
	return 0;
}

