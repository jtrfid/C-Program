#include<stdio.h>
int main()
{
	int a,b,c,d;
	float t;
	scanf("%d",&a);
	if(a<=5000){b=0;
	c=a;
	}
	else{
	 if(5000<a<=10000){
	t=0.05;
	b=(a-5000)*t;
	c=a-b;
	}else {
	if(10000<a<=20000){
	t=0.08;
	b=250+(a-10000)*t;
	c=a-b;
	}else {
	if(20000<a<=30000){
		t=0.15;
		b=250+800+(a-20000)*t;
		c=a-b;
	}else  
	  {
	  t=0.35;
	  b=250+800+1500+(a-30000)*t;
	  c=a-b;}}}}
	printf("%d %d",b,c);
	return 0;
}
