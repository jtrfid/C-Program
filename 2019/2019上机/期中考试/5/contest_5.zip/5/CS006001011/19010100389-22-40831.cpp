#include<stdio.h>
int main()
{
	int a,t,m;
	scanf("%d",&a);
	if(a<=5000) t=0;
	else if(a<=10000) t=0.05*(a-5000);
	else if(a<=20000) t=0.08*(a-10000)+250;
	else if(a<=30000) t=0.15*(a-20000)+1050;
	else if(a>30000) t=0.35*(a-30000)+2550;
	m=a-t;
	printf("%d %d",t,m);
	return 0;
}
