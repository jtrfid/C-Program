#include<stdio.h>
int main()
{
	int m,i,a[10000],c,b[10000];
	scanf("%d",&m);
	for(i=2;i<m;i++)
	b[i-2]=m%i;
	if(b[i-2]!=0&&b[i-1]!=0)printf("Yes");
    else
	printf("No");
	return  0;
}
