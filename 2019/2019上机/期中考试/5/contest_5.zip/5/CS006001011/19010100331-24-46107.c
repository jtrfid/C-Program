#include<stdio.h>
int main()
{
	int n,a[100],i,j,t,sum=0,m,x,y;
	scanf("%d",&n);
	if(n>0&&n<10000)
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	 {
	 for(j=0;j<n-1-j;j++)
	  if(a[j]>a[j+1])
	  {
	  	t=a[j];
	  	a[j]=a[j+1];
	  	a[j+1]=t;
	  	
	  }
}	  
	   x=a[0];y=a[j];
	  
	  for(m=x;m<=y;m++)
	  if(m%2==0)
	  sum=sum+m;
	  printf("%d %d %d",x,y,sum);
	  return 0;
}
