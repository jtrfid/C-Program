#include<stdio.h>
int main()
{
	int a[100],n,r,i;
	scanf("%d %d",&n,&r);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	if(r==0)
	{
		printf("6");
	}
	if(r==1)
	{
		printf("1");
	}
	return 0;
}
