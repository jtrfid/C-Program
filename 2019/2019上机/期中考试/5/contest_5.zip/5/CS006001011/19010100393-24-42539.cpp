#include<stdio.h>
int main()
{
	int a,b,c,i,j,sum=0;
	int d[10];
	scanf("%d",&a);
	for(b=1;b<=a;b++)
	scanf("%d",d[b]);
	i=0;
	j=10000;
	for(b=1;b<=a;b++)
	if(d[b]>i)  i=d[b];
	for(b=1;b<=a;b++)
	if(d[b]<j) j=d[b];
	for(c=j;c<=i;c++)
	if(c%2==0) sum=sum+c;
	printf("%d %d %d\n",j,i,sum);
	return 0;

		
	
	
}
