#include<stdio.h>
int main()
{
	int a,b,c,d,e,i;
	float h,j;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=a+b+c+d;
	h=7*e/10;
	if(e>=300){
	
	 i=e/300;
	 j=e-100*i;}
	else e=e;
	if (h<=j)printf("1 %.2f",h);
	else printf("2 %.2f",j);
	return 0;
}
