#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,g,h,i;
	scanf("%d",&a);
	b=0.05*a;
	d=0.08*a;
	f=0.15*a;
	h=0.35*a;
	if(a<=5000)
	 printf("%d %d",0*a,a);
	else
	  if(5000<a&&a<=10000)
	   printf("%d  %d",b,a-b);
	else
	  if(10000<a&&a<=20000)
	  printf("%d  %d",d,a-d); 
	else
	  if(20000<a&&a<=30000)
	  printf("%d  %d",f,a-f);
	else
	  printf("%d  %d",h,a-h);
	return 0;
}
