#include<cstdio>
int main()
{
	int x,n;
	int max=0,min=10000;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&x);
		if(min>x) min=x;
		if(max<x) max=x;
	}
	int s=0;
	for(int i=min;i<=max;++i)
	if(i%2==0) s+=i;
	printf("%d %d %d",min,max,s);
}
