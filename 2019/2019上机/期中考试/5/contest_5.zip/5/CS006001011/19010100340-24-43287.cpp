#include<stdio.h>
int main()
{
	int a[100];
	int x=1000000,y=0,n,i,z,sum=0,t;
	scanf("%d\n",&n);
	for(z=0;z<n;z++)
	  {scanf("%d",&a[z]);
	  if(a[z]<=x)
	  x=a[z];
	  if(a[z]>=y)
	  y=a[z];
	  }
	  if(x%2==0)  
	  {
	  for(i=x;i<=y;i=i+2)
	    {sum=sum+i;}
      }
      else
      {for(t=x+1;t<=y;t=t+2)
      {sum=sum+t;
	  }
	  }
    printf("%d %d %d",x,y,sum);
    return 0;
      
      
      
      
      
      
      
}
