#include<stdio.h>
int main()
{
	int a,b,c,d,s,z;
	float sum1,sum2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	s=a+b+c+d;
	sum1=s*0.7;
	z=s/300;
	sum2=s*1.0-z*100;
	if(sum1>sum2)
	printf("2 %.2f",sum2);
	else
	printf("1 %.2f",sum1);
	return 0;
}
