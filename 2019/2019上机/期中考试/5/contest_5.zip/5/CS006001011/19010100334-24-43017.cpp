#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j,x,y,t,sum=0;
	int a[100];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];a[j+1]=t;a[j]=a[j+1];
			}
		}
	}
	x=a[0];y=a[n-1];
	for(i=x;i<=y;i++)
	{
		if(i%2==0)
		sum=sum+i;
	}
	printf("%d %d %d",x,y,sum);
	return 0;
}
