#include<stdio.h>
int main()
{
    int a[1000];
    int n,r,x,y,s=0,flag=1,z,m=0,sum;
    scanf("%d %d",&n,&r);
    if(r==1)
    {
    	for(int i=0;i<n;i++)
    	{
    		scanf("%d",&a[i]);
    		y=a[i];
    		sum=0;
    	    for(int j=1;j<=30;j++)
    	    {
    	    	x=y%2;
    	    	y=y/2;
    	    	s=s+x;
    	    	sum=sum+x;
    	    	if(y==0)
    	    	break;
			}
		    z=sum%2;
		    if(z==0)
		    {
			    flag=0;
			    m=m+1;
		    }	
		}
		if(flag==0)
		printf("%d",m);
		else
		printf("%d",s);
	}
	if(r==0)
    {
    	for(int i=0;i<n;i++)
    	{
    		scanf("%d",&a[i]);
    		y=a[i];
    		sum=0;
    	    for(int j=1;j<=30;j++)
    	    {
    	    	x=y%2;
    	    	y=y/2;
    	    	s=s+x;
    	    	sum=sum+x;
    	    	if(y==0)
    	    	break;
			}
		    z=sum%2;
		    if(z==0)
		    ;
		    else
		    {
			    flag=0;
			    m=m+1;
		    }	
		}
		if(flag==0)
		printf("%d",m);
		else
		printf("%d",s);
	}
	return 0;
}
