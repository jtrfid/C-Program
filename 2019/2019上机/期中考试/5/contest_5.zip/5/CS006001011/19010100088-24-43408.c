#include <stdio.h>
int main()
{
	int n,x,y,s=0,a[10000],i;
	
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	x=a[0];
	y=a[0];
	for(i=1;i<n;i++)
	{
		if(a[i]<x)
		{
			x=a[i];
		}else if(a[i]>y)
		{
			y=a[i];
		}
	}
	
	if(x%2==0){
		for(i=x;i<y+1;i=i+2)
		{
			s+=i;
		}
	}else{
		for(i=x+1;i<y+1;i=i+2)
		{
			s+=i;
		}
	}
	printf("%d %d %d",x,y,s);
	return 0;
}
