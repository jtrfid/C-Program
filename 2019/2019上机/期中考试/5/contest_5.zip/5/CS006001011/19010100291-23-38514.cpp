#include<stdio.h>
int main()
{
	int m,n,b;
	scanf("%d",&m);
	for(n=2;n<m;n++)
	{
		if(m%n==0){
			b=1;
			break;
		}
		else{b=0;
		}
		
		
		
		
	}
	if(b==1){
		printf("NO");
	}
	else{ 
	printf("YES");
	}
	
	
	
	
	
	
	
	
	
	
	
}
