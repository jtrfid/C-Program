#include<stdio.h>
int main()
{
	int a,b,c,d,i,count=0;
	double sum1=0,sum2=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	sum2=a+b+c+d;
	sum1=(a+b+c+d)*0.7;
	count=sum2/300;
	for(i=0;i<count;i++){
		sum2-=100;
	}
	if(sum1>sum2){
		printf("2 %.2lf",sum2);
	}
	else{
		printf("1 %.2lf",sum1);
	}
	
	
	
	return 0;
}
