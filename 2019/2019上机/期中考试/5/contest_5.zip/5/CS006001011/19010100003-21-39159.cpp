#include<stdio.h>
int main()
{
	int a,b,c,d,e;float f,g,h;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	f=(a+b+c+d)*0.7;
	e=a+b+c+d;
	
	
	
	g=e-e/300*100;
	if(f<=g)
	printf("1 %.2f",f);
	else
	printf("2 %.2f",g);
	return 0;
	
	
	
}
