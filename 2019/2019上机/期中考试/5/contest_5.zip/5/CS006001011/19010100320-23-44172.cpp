#include<stdio.h>
int main()
{
	int m,i,a[10000],c,b[10000];
	scanf("%d",&m);
	for(i=2;i<m;i++)
	b[i-2]=m%i;
	c=b[i-2];
	if(c==0)printf("No");
	else
	printf("Yes");
	return  0;
}
