#include<stdio.h>
int main()
{
	int m,i;
	scanf("%d",&m);
	if(m==1)
	printf("NO");
	else
	{int flag=1;
	 for(i=2;i<m;i++)
	 {
	 	if(m%i==0)
	 	{flag=0;
	 	break;
		 }
	 	if(i==m)
	 	flag=1;
	 }
	 if(flag)
	 printf("YES");
	 else
	 printf("NO");
	}
	return 0;
}
