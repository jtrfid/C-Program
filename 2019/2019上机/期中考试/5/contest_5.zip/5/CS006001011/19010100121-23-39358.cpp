#include<stdio.h>
int main()
{
    int m,n;
    scanf("%d",&m);
    for(int i=2;i<=m/2;i++)
    {
    	n=m%i;
    	if(n==0)
    	{
    		printf("NO");
    		return 0;
		}
	}
	printf("YES");
	return 0;
}
