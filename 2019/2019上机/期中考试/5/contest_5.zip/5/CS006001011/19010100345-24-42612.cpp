#include<stdio.h>
int main()
{int n,a[100],max=0,i,j,min=10000,sum=0;
scanf("%d",&n);
for(i=0;i<n;i++)
{scanf("%d",&a[i]);
if(max<a[i])
max=a[i];
if(min>a[i])
min=a[i];
}
for(j=min;j<=max;j++)
{if(j%2==0)
sum=j+sum;
}
printf("%d %d %d",min,max,sum);
return 0;
}
