#include<stdio.h>
int main()
{
	int a,b,c,d,m,n,x;
	float s,y;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	m=a+b+c+d; 
	n=m/300;
	y=m-n*100;
	if((a==0&&b==0&&c==0)||(a==0&&b==0&&d==0)||(a==0&&c==0&&d==0)||(b==0&&c==0&&d==0)) s=m*0.9;
	else if((a==0&&b==0&&c!=0&&d!=0)||(a==0&&c==0&&b!=0&&d!=0)||(a==0&&d==0&&b!=0&&c!=0)||(b==0&&c==0&&a!=0&&d!=0)||(b==0&&d==0&&a!=0&&c!=0)||(c==0&&d==0&&a!=0&&b!=0)) s=m*0.8;
	else s=m*0.7;
	if(s<=y) {x=1;printf("%d %.2f",x,s);}
	else {x=2;printf("%d %.2f",x,y);}
	return 0;
}
