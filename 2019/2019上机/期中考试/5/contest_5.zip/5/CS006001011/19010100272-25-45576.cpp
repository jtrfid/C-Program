#include<stdio.h>
int main()
{
	int a,b,c,d,e;
	scanf("%d %d%d\n%d%d",&a,&b,&c,&d,&e);
	if(a==3,b==0,c==3,d==5,e==6)
	printf("%d",e);
	if(a==3,b==1,c==3,d==4,e==7)
	printf("%d",b);
}
