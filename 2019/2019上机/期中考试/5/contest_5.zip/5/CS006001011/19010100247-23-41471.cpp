#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	for(b=2;b<a;b++)
	{
	c=a%b;
	if(c==0)
	{
	printf("NO");
	break;}
	if(b==a-1)
	printf("YES");
	}

	
	return 0;

}
