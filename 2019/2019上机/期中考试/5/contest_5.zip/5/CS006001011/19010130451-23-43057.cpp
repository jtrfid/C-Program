#include<stdio.h>
int main()
{int a,i;
scanf("%d",&a);
for(i=2;i++;i<=a/2)
{if(a%i==0) printf("no");break;}
for(i=2;i++;i<=a/2)
{if(a%i!=0) printf("yes");break;}
}
