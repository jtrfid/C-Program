#include<stdio.h>
int main()
{
	int a,b,c,d;
	float s1,s2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	if(a+b+c+d<300)
	{
		s1=(a+b+c+d)*0.7;
		s2=a+b+c+d;
		printf("1 %.2f",s1);
	}
	
	if((a+b+c+d)>=300)
	{
		s1=(a+b+c+d)*0.7;
		s2=a+b+c+d-100;
		if(s1>s2)
		{
			printf("2 %.2f",s2);
		}
		else
		{
			printf("1 %.2f",s1);
		}
	}
	return 0;
}
	

