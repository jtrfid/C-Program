#include<stdio.h>
#include<math.h>
int main()
  {
  	int a,i;
  	scanf("%d",&a);
  	for(i=2;i<a+1;i++)
  	if(a%i==0)break;
  	if(i==a)
  	printf("YES");
  	else
  	printf("NO");
  	return 0;
  }
