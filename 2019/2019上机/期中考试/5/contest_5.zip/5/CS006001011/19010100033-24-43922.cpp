#include<stdio.h>
int main()
{
	int a[1000],n,i,x,y,j,s=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	scanf("%d",&a[i]);
	for(i=1,x=a[1],y=a[1];i<=n;i++)
	{
		if(x>a[i])
		x=a[i];
		if(y<a[i])
		y=a[i];
	}
	for(j=x;j<=y;j++)
	{
		if(j%2==0)s+=j;
	}printf("%d %d %d",x,y,s);
	return 0;
}
