#include<stdio.h>
#include<cmath>
int  trensfer(int x);
main()
{
	int n,r,num[1000],sum[1000],step,m,i;
	sum[1000]={0};
	m=0;
	scanf("%d %d",&n,&r);
	if(r==0)
	{
		for(i=0;i<n;i++)
		{
			scanf("%d",num+i);
			num[i]=trensfer(num[i]);
		}
		for(i=0;i<n;i++)
		while(num[i])
		{
			sum[i]+=num[i]%10;
			num[i]/=10;
		}
		for(i=0;i<n;i++)
		{
			if(sum[i]%2!=0)
			step+=1;
		}
		for(i=1;i<n;i++)
		{
			m+=sum[i];
		}
		if(step==0) printf("%d",m);
		else printf("%d",step);
	}
	else if(r==1)
	{
		for(i=0;i<n;i++)
		{
			scanf("%d",num+i);
			num[i]=trensfer(num[i]);
		}
		for(i=0;i<n;i++)
		while(num[i])
		{
			sum[i]+=num[i]%10;
			num[i]/=10;
		}
		for(i=0;i<n;i++)
		{
			if(sum[i]%2==0)
			step+=1;
		}
		for(i=1;i<n;i++)
		{
			m+=sum[i];
		}
		if(step==0) printf("%d",m);
		else printf("%d",step);
	}
	return 0;
}
int trensfer(int x)
{
	int p=1,y=0,yushu,n;
	scanf("%d",&n);
	while(1)
	{
		yushu=n%2;
		n/=2;
		y+=yushu*p;
		p*=10;
		if(x<2)
		{
			y+=x*p;
			break;
		}
		return y;
	}
}
