#include<stdio.h>
int main()
{
	int n,a[100],i,j,t,sum=0,m;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	 {
	 for(j=0;j<n-1-j;j++)
	  if(a[j]>a[j+1])
	  {
	  	t=a[j];
	  	a[j]=a[j+1];
	  	a[j+1]=t;
	  	
	  }
}	  
	   
	  
	  for(m=a[0];m<a[j];m++)
	  if(a[m]%2==0)
	  sum=sum+a[m];
	  printf("%d %d %d",a[0],a[j],sum);
	  return 0;
}
