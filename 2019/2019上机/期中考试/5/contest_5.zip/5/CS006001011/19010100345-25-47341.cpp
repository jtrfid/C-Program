#include<stdio.h>
int main()
{int a,b,c,d,e;
scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
printf("1");
return 0;}

