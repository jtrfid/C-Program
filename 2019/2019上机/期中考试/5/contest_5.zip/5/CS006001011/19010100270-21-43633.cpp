#include<stdio.h>
int main()
{
	int a,b,c,d,sum;
	float x,y;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	sum=a+b+c+d;
	x=sum*0.7;
	if(sum%300!=0)
	y=sum-(sum-sum%300)/3;
	else
	y=sum-sum/3;
	if(x<y)
	{y=1;}
	else if(x==y)
	{y=1;}
	else if(x>y)
	{x=y;
	y=2;}
	printf("%.0f %.2f",y,x);
	return 0;
}
