#include<stdio.h>
int main()
{int a,b,c;
scanf("%d",&a);
if(a<=5000)
printf("0 %d",a);
if(a>5000&&a<=10000)
{b=0.05*(a-5000);
c=a-b;
printf("%d %d",b,c);}
if(a>10000&&a<=20000)
{b=250+0.08*(a-10000);
c=a-b;
printf("%d %d",b,c);}
if(a>=20000&&a<=30000)
{b=0.15*(a-20000)+1050;
c=a-b;
printf("%d %d",b,c);}
if(a>30000)
{b=0.35*(a-30000)+2550;
c=a-b;
printf("%d %d",b,c);}
return 0;
}
