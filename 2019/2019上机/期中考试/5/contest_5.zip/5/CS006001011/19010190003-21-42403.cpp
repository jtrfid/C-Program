#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	double m,n;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=a+b+c+d;
	m=e*0.7;
	f=e/300;
	n=e-f*100;
	if (m>n) printf("2 %.2lf",n);
	else if (m<n) printf("1 %.2lf",m);
	else if (m=n) printf("1 %.2lf",m);
}
