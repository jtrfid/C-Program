#include<stdio.h>
int main()
{
	int p(int n);
	int n,tem;
	scanf("%d",&n);
	tem=p(n);
	if(n>=1 &&n<=6)
	{
		
		if(n==1)printf("YES");
		if(n==2)printf("YES");
		if(n==3)printf("YES");
		if(n==4)printf("NO");
		if(n==5)printf("YES");
		if(n==6)printf("NO");
		
	}
	else{
		tem=p(n);
		if(tem==1)
		{
			printf("YES");
		}
		else printf("NO");
	}
}



int p(int n)
{
	int a,b,c,d,e,f,i;
	for(a=2;a<n;a++)
	{
		if(n%a==0)
		{
			b=0;break;
			
		}
		else b=1;
	}
}
