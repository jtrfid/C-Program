#include<stdio.h>
int main()
{
	int n;scanf("%d",&n);
	int i,a,min=10000,max=0,sum=0;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a);
		if(min>a)min=a;
		if(max<a)max=a;
	}
	for(int j=min;j<=max;j++)
	{
		if(j%2==0)
		sum=sum+j;
	}
	printf("%d %d %d",min,max,sum);
}
