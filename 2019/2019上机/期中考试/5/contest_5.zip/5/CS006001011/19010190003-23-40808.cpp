#include<stdio.h>
int main()
{
	int m,i,n=1;
	scanf("%d",&m);
	for (i=2;i<m;i++)
	{
		if (m%i==0) n=0;
	}
	if (n==0) printf("NO");
	else if(n!=0) printf("YES");
}
