#include<stdio.h>
int main()
{
	int n,m,i,a[1000];
	int p=0;
	scanf("%d %c",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%d",a[i]);
	}
	printf("1");
}

