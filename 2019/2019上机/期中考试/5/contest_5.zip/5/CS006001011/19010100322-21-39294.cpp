#include<stdio.h>
int main()
{
	int a,b,c,d,sum,x;
	float m1,m2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	sum=a+b+c+d;
	m1=sum*0.70;
	x=sum/300;
	m2=sum-100.0*x;
	if(m1<=m2)
	printf("1 %.2f",m1);
	else
	printf("2 %.2f",m2);
}
