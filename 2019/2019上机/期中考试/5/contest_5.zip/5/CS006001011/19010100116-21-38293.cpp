#include<cstdio>
int main()
{
	int a,b,c,d;
	double ans1,ans2;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	ans1=0.7*(a+b+c+d);
	ans2=a+b+c+d;
	if(a+b+c+d>=300)
	ans2-=100;
	if(ans1<=ans2) printf("1 %.2lf",ans1);
	else printf("2 %.2lf",ans2);
}
