#include<stdio.h>
int main()
{
	int n,i,max=0,min=100000,c,sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&c);
		if(c>max)max=c;
		if(c<min)min=c;
		}
		for(i=min;i<=max;i++){
			if(i%2==0){
				sum+=i;
			}
		}
	printf("%d %d %d",min,max,sum);
	return 0;
}
	
	
	
