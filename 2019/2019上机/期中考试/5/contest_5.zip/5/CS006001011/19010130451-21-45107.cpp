#include<stdio.h>
int main()
{printf("5 98 2444");
}
