#include<stdio.h>
int main()
{
	int a,i,n;
	scanf("%d",&a);
	for(i=2;i<=a/2;i++)
	{
		n=a%i;
		if(n==0)
		{
			break;
		}
	}
	if(i>a/2)
	{
		printf("YES");
	}
	else
	{
		printf("NO");
	}
	return 0;
}
