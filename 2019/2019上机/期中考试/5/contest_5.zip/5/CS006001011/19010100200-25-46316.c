#include <stdio.h>
#include<stdlib.h>

int main()
{
	int n,a,s=0,count=0,r,i,b=0;
	scanf("%d %d",&n,&r);

	for(i=1;i<=n;i++)
	{
		scanf("%d",&a);
		
	while(a)
	{
		if(a%2==1)
		{
			count++;
		}
		a=a/2;
	}
	
	if(count%2!=r)
	{
		b++;
	continue;
	}
	else
		
		s=s+count;
	count=0;

	

	
	}
	if(b==0)
	{
	printf("%d ",s);
	}
	else
	printf("%d",b);

}