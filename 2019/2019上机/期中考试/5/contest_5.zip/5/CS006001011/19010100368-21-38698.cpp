#include<stdio.h>
int main()
{
	int m,a,b,c,d,g;
	float n,e,f;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=(a+b+c+d)*0.7;
	g=(a+b+c+d)/300;
	f=a+b+c+d-g*100;
	if(e>f)
	{
	printf("2");
	printf(" %.2f",f);}
	else
	{
	printf("1");
	printf(" %.2f",e);}
}
