#include<stdio.h>
int main()
{
	int a,b,i=2;
	b=a/2;
	scanf("%d",&a);
	for(i=2;i<b;i++)
	{
		if(a%i==0)
		{
			printf("NO");break;
		}
		printf("YES");break;
	}
	return 0;
	
}
