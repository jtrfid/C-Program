#include<stdio.h>
int main()
{int a,m;
scanf("%d",&a);
if(a<=5000){m=0;printf("%d %d",m,a);
}if(a>5000&&a<=10000){m=(a-5000)*0.05;a=a-m;printf("%d %d",m,a);
}if(a>10000&&a<=20000){m=5000*0.05+(a-10000)*0.08;a=a-m;printf("%d %d",m,a);
}if(a>20000&&a<=30000){m=5000*0.05+10000*0.08+(a-20000)*0.15;a=a-m;printf("%d %d",m,a);
}if(a>30000){m=5000*0.05+10000*0.08+10000*0.15+(a-30000)*0.35;a=a-m;printf("%d %d",m,a);
}return 0;
}
