#include<stdio.h>
int main()
{
	int a,b,c,d,n;
	float e,i;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=(a+b+c+d)*0.7;
	n=(a+b+c+d)/300;
	i=a+b+c+d-n*100;
	if(e<=i) 
	{
		printf("1 %.2f",e);
	}
	else if(e>i)
	{
		printf("2 %.2f",i);
	}
	return 0;
}

