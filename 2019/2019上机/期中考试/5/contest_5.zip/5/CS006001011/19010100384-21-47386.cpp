#include<stdio.h>
int main()
{
	int a,b,c,d,n,p=1,q=2;
	float s1,s2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	n=a+b+c+d;
	if(n<300)
	{
		s1=n*0.7;
		s2=n;
		printf("%d %.2f",p,s1);
	}
	
	if(n>=300)
	{
		s1=n*0.7;
		s2=n-100;
		if(s1>s2)
		{
			printf("%d %.2f",q,s2);
		}
		if(s1<s2);
		{
			printf("%d %.2f",p,s1);
		}
		if(s1==s2)
		{
			printf("%d %.2f",p,s1);
		}
	}
	return 0;
}
	

