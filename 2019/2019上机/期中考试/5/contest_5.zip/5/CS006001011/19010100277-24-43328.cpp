#include<stdio.h>
#include<cmath>
int main()
{
	int n,x,y,num[100],t,i,j,sum;
	sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",num+i);
	}
	for(i=0;i<n;i++)
	for(j=0;j<n-i-1;j++)
	{
		if(num[j]<num[j+1])
		{
			t=num[j];
			num[j]=num[j+1];
			num[j+1]=t;
		}
	}
	x=num[n-1];
	y=num[0];
	for(i=x;i<=y;i++)
	{
		if(i%2==0)
		sum+=i;
		else
		continue;
	}
	printf("%d %d %d",x,y,sum);
	return 0;
}
