#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	for(i=2;i<=n-1;i++)
      if(n%i==0) break;
      if(i>=n) printf("YES");
      else printf("NO");
	  
	  
	return 0;
	
}

