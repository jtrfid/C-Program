#include <stdio.h>
int main()
{
	int m , a=2,b;
	scanf("%d",&m);
	for(a;a<m;a++)
	{
		if(m%a==0)
		{
			printf("NO");
			break;
		}
		b=a;
	}
	if(m-1==b)
		printf("YES");
	return 0;
}