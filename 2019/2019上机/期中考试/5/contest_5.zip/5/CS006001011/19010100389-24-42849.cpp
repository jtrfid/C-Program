#include<stdio.h>
int main()
{
	int n,i,j,a[100],t,s=0,x,y;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(j=0;j<n-1;j++)
	for(i=0;i<n-1-j;i++)
	{
		if(a[i]>a[i+1]) 
		{t=a[i];a[i]=a[i+1];a[i+1]=t;}
	}
	x=a[0];y=a[n-1];
	for(i=x;i<=y;i++)
	    if(i%2==0) s=s+i;
	printf("%d %d %d",x,y,s);
	return 0;
}
