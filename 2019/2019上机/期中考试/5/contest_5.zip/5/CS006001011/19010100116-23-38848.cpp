#include<cstdio>
#include<cmath>
using namespace std;
bool isprime(int x)
{
	int t=sqrt(x);
	for(int i=2;i<=t;++i)
	if(x%i==0) return 0;
	return 1;
}
int main()
{
	int x;
	scanf("%d",&x);
	if(isprime(x)) puts("YES");
	else puts("NO");
}
