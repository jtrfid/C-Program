#include<stdio.h>
#include<math.h>
int main()
{int m,C=0;
int i=2;
scanf("%d",&m);
if(m==0){
	printf("NO");
	C=1;
}
for(i=2;i<sqrt(m);i++){
	if(m%i==0){
		printf("NO");
		C=1;
	}
	}
if(C==0){
	printf("YES");
} return 0;
}
