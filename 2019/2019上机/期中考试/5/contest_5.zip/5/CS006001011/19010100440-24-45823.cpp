#include<stdio.h>
int main()
{
	int a,b,c,d=0,i;
	int min=99999999,max=0;
	scanf("%d",&a);
	for(b=0;b<a;b++)
	{
		scanf("%d",&c);
		if(c>max)max=c;
		if(c<min)min=c;
		
	}
	for(i=min;i<max;i++)
	{
		if(i%2==0)d=d+i;
		
	}
	printf("%d %d %d",min,max,d);
	return 0;
}
