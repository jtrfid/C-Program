#include<stdio.h>
int main()
{
	int a,b,c,d;
	float x,y;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	x=(a+b+c+d)*0.7;
	y=(a+b+c+d)-(a+b+c+d)/3;
	if(x<y){printf("%c",x);}
	else if(x==y){printf("%c",x);}
	else if(x>y){printf("%c",y);}
	return 0;
}
