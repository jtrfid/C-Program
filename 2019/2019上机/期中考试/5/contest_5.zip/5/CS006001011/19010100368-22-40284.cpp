#include<stdio.h>
int main()
{
	int a,c,d;
	scanf("%d",&a);
	if(a<=5000)
	{
		c=0;
		d=a-c;
		printf("%d %d",c,d);
	}
	if(a<=10000&&a>5000)
	{
		c=(a-5000)*0.05;
		d=a-c;
	    printf("%d %d",c,d);
	}
	if(a>10000&&a<=20000)
	{
		c=(10000-5000)*0.05+(a-10000)*0.08;
		d=a-c;
		printf("%d %d",c,d);
	}
	if(a>20000&&a<=30000)
	{
		c=5000*0.05+10000*0.08+(a-20000)*0.15;
		d=a-c;
		printf("%d %d",c,d);
	}
	if(a>30000)
	{
		c=5000*0.05+10000*0.08+10000*0.15+(a-30000)*0.35;
		d=a-c;
		printf("%d %d",c,d);
	}
}
