#include<stdio.h>
int main()
	{
		int m,n,judge=0;
		scanf("%d",&m);
		n=m-1;
		while(n>1)
			{
				if(m%n==0)
					{
					judge=1;break;}
				else 
					{
					n=n-1;}
		
			}
		if(judge==0)
			printf("YES");
		if(judge==1)
			printf("NO");			
			
			
			
			
		
		
		
		
		
		
	}
