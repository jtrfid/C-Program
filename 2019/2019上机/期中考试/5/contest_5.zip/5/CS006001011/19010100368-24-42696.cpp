#include<stdio.h>
int main()
{
	int m,n,x=0,min,max,s=0;
	int a[100],b[100];
	scanf("%d",&m);
	for(n=0;n<m;n++)
	{
		scanf("%d",&a[n]); 
	}
	min=a[0];
	max=a[0];
	for(n=1;n<m;n++)
	{
		if(a[n]<min)
		min=a[n];
		if(a[n]>max)
		max=a[n];
	}
	printf("%d %d",min,max);
	for(b[0]=min;b[x]<=max;x++)
	{
    b[x+1]=b[x]+1;
	if(b[x]%2==0)
	s+=b[x];}
	printf(" %d",s);
}
