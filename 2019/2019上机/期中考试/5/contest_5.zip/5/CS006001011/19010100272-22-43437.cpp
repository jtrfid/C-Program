#include<stdio.h>
int main()
{
	int a,t,c;
	scanf("%d",&a);
	if(a<=5000)
	t==0;
	c=a;
	if(a>5000&&a<=10000)
	t=(a-5000)*0.05;
	c=a-t;
	if(a>10000&&a<=20000)
	t=250+(a-10000)*0.08;
	c=a-t;
	if(a>20000&&a<=30000)
	t=1050+(a-20000)*0.15;
	c=a-t;
	if(a>=30000)
	t=2550+(a-30000)*0.35;
	c=a-t;
	printf("%d %d",t,c);
	return 0;
	
}
