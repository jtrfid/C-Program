#include<stdio.h>
int main()
{
	int a,i=2,j=1;
	scanf("%d",&a);
	while(i<a)
	{
		if(a%i==0)
		{printf("NO");
		break;
		}
		else
		{
			j++;
		}
		i++;
		
	}
	if(j==a-1)
	printf("YES");
	 
}

