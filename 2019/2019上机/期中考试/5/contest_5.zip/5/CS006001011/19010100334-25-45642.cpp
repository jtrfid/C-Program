#include<stdio.h>
#include<math.h>
int main()
{
	int n,r,i,j;
	int a[1000],b[1000];
	scanf("%d %d",&n,&r); 
	for(i=0;i<n;i++)
	{
		scanf("%d ",&a[i]);
	}
	for(i=0,j=2;i<n,j<n;i++,j=j*2)
	{
		b[i]=a[i]%j;
		
	}
	if(r==0)
	{
		
	}
	else
	{
		
	}
	return 0;
}
