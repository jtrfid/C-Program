#include<stdio.h>
int main()
{float a,b,c,d,n,m,s;
scanf("%f %f %f %f",&a,&b,&c,&d);
m=a+b+c+d;
n=m*7/10;
if(m<300) s=m;
if(m>=300&&m<600) s=m-100;
if(m>=600&&m<900) s=m-200;
if(m>=900&&m<1200) s=m-300;
if(m>=1200&&m<1500) s=m-400;
{if(n<=s)
printf("1 %.2f",n);
else
printf("2 %.2f",s);
}}

