#include<stdio.h>
int main()
{int k;
float a,b,c,d,n,m,s;
scanf("%f %f %f %f",&a,&b,&c,&d);
m=a+b+c+d;
n=m*7/10;
k=m/300;
s=m-100*k;
{if(n<=s)
printf("1 %.2f",n);
else
printf("2 %.2f",s);
}}

