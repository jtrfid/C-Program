#include<stdio.h>
int main()
{
	int n,r,a,sum=0,b;
	scanf("%d %d",&n,&r );
	for(int i=1;i<=n;i++)
	{   
		scanf("%d",&a);
		switch(a)
		{   
			case 1:b=1;break;
			case 2:b=1;break;
			case 3:b=2;break;
			case 4:b=1;break;
			case 5:b=2;break;
			case 6:b=2;break;
			case 7:b=3;break;
			case 8:b=1;break;
			case 9:b=2;break;
		}
		sum=sum+b;
	}
	if(sum%2==0&&r==0)printf("%d",sum);
	if(sum%2!=0&&r==1)printf("%d",sum);
}
