#include<stdio.h>
int mian()
{int n,count=0,x,max,min,t=0,sum;
scanf("%d\n",&n);
for(count=0;count<n;count++){
	scanf("%d ",&x);
	if(x>t){
		max=x;
		min=t;	
		t=x;
	}else{
		max=t;
		min=x;
		t=x;
	}
	if(x%2==0){
		sum+=x;
	}
}
printf("%d %d %d",min,max,sum);

}

