#include<stdio.h>
int main()
{
	int n,r,a[1000],i,t=0;
	scanf("%d %d\n",&n,&r)
	for(i=0;i<n;i++)
	{scanf("%d",&a[i]);
	}
	if(r==0)
	{
	}
	if(r==1)
	{
	}
}
