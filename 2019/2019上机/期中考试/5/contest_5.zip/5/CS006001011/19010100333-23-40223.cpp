#include<stdio.h>
int main(){
	int m,n;
	scanf("%d",&m);
	for(n=2;n<m;n++)
	if(m%n==0){
	printf("NO");break;	}
	else if(n==m-1)
	printf("YES");
}
