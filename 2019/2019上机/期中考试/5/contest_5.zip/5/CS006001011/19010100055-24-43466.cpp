#include<stdio.h>
int main()
{
	int n,i,a[100];
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int max,min;
	for(i=1;i<n-1;i++)
	{max=a[1];
		if(a[i+1]<=a[i])
		{max=a[i];
		a[i]=a[i+1];
		a[i+1]=max;
		}
	}
	for(i=1;i<n-1;i++)
	{min=a[1];
		if(a[i+1]<=a[i])
		{
			min=a[i+1];
			a[i]=a[i+1];
			a[i+1]=min;
		}
	}
	int j,s=0;
	for(j=min;j<=max;j++)
	{
		if(j%2==0)
		{s+=j;
		}
		else
		continue;
	}
	printf("%d %d %d",min,max,s);
	return 0;
}
