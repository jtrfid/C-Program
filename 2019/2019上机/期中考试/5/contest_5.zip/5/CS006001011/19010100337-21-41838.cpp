#include<stdio.h>
int main()
{
	int a,b,c,d,t,w,j,i;
	float n,m;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	t=(a+b+c+d);
	n=t*0.7;
	j=t/300;
	if(j>0)
	{
	m=t-100*j;
}
if(j==0)
m==t;
	if(n<m)
	{i=1;
	printf("%d",i);
	printf("%.2f",n);
	}
	if(m<n)
	{i=2;
	printf("%d",i);
	printf("%.2f",m);
}
	return 0;
}
