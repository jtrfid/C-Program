#include<stdio.h>
int main()
{int n,r,a[1000],i,m=0,j,b=0,s=0;
scanf("%d %d",&n,&r);
for(i=1;i<=n;i++)
scanf("%d",&a[i]);
if(r==0){
for(i=1;i<=n;i++){
	while(a[i]!=0)
			{j=a[i]%2;a[i]=a[i]/2;if(j==1)
			m=m+1;}if(m%2!=0)
			{
			;b=b+1;}
	if(b==0)printf("%d",s);else if(b!=0)printf("%d",b);
	
}}  if(r==1){
	for(i=1;i<=n;i++){
	while(a[i]!=0)
			{j=a[i]%2;a[i]=a[i]/2;if(j==1)m=m+1;
			}if(m%2==0){
			;b=b+1;}if(b==0)printf("%d",m);else printf("%d",b);
			
		}
}return 0;
}
