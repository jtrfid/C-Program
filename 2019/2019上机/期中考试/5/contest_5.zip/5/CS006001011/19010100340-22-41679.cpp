#include<stdio.h>
int main()
{
	float n,k;
	int c,d;
	signed a;
	scanf("%d",&a);
	  if(a<=5000)
	    n=0;
	  else if(5000<a<=10000)
	    n=(a-5000)*0.05;
	  else if(10000<a<=20000)
	    n=5000*0.05+(a-10000)*0.08;
	  else if(20000<a<=30000)
	    n=5000*0.05+10000*0.08+(a-20000)*0.15;
	  else if(a<30000)
	    n=5000*0.05+10000*0.08+10000*0.15+(a-30000)*0.35;
	k=a-n;
	c=k;
	d=n;
	printf("%d %d",d,c);
	return 0;
}
