#include<stdio.h>
int main()
{
	int a,t;
	scanf("%d",&a);
	if(a<=5000)
	{t=0;
	}
	else if(a>5000&&a<=10000)
	{t=(a-5000)*0.05;
	}
	else if(a>10000&&a<=20000)
	{t=250+(a-10000)*0.08;
	}
	else if(a>20000&&a<=30000)
	{t=250+800+(a-20000)*0.15;
	}
	else
	{t=250+800+1500+(a-30000)*0.35;
	}
	printf("%d %d",t,a-t);
	return 0;
}
