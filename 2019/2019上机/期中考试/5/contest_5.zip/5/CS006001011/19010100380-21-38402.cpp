#include<stdio.h>
int main()
{
	int a,b,c,d;
	float m,n;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	m=(a+b+c+d)*0.7;
	if(a+b+c+d>=300)
	{
		n=a+b+c+d-100;
	}
	else
	n=a+b+c+d;
	if(m<=n)
	printf("1 %.2f",m);
	else
	printf("2 %.2f",n);
}
