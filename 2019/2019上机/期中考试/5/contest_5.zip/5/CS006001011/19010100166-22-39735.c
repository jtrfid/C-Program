#include<stdio.h>
int main()
	{
		int a,tax,income;
		scanf("%d",&a);
		if(a<=5000)
			tax=0;
		if(a>5000&&a<=10000)
			tax=(a-5000)*0.05;
		if(a>10000&&a<=20000)
			tax=250+(a-10000)*0.08;
		if(a>20000&&a<=30000)
			tax=250+800+(a-20000)*0.15;
		if(a>30000)
			tax=250+800+1500+(a-30000)*0.35;
		income=a-tax;
		printf("%d %d",tax,income);
		return 0;

	}
