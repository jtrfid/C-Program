#include <stdio.h>
int main()
{
	int n, x, y, s, a[100], b,c;
	scanf("%d",&n);
	for(b=0;b<=n-1;b++)
	{
		scanf("%d",&a[b]);
	}
	for(b=0;b<=n-1;b++)
	{
		if(a[b]>a[b+1])
		{
			y=a[b];
			x=a[b+1];
		}else
		{
			y=a[b+1];
			x=a[b];
		}
	}
	for(c=x;c<=y;c++)
	{
		if(c%2==0)
			s=s+c;
	}
    return 0;
}#include <stdio.h>
int main()
{
	int n, x, y, s, a[100], b,c;
	scanf("%d",&n);
	for(b=0;b<=n-1;b++)
	{
		scanf("%d",&a[b]);
	}
	for(b=0;b<=n-1;b++)
	{
		if(a[b]>a[b+1])
		{
			y=a[b];
			x=a[b+1];
		}else
		{
			y=a[b+1];
			x=a[b];
		}
	}
	for(c=x;c<=y;c++)
	{
		if(c%2==0)
			s=s+c;
	}
    return 0;
}