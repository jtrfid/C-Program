#include<stdio.h>
int main()
{int a,b,c,d,g,h,k;
float e,f;
scanf("%d %d %d %d",&a,&b,&c,&d);
g=(a+b+c+d);
e=g*0.7;
if(g<300){
	f=g;
}else{
	k=g/300;
	f=g-(k*100);
}
if(e>f){
	printf("2 %.2f",f);
}else{
	printf("1 %.2f",e);
}
}
