#include<stdio.h>
int main()
{
	int a,b,c,d,p,q;
	float m,n;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	n=(a+b+c+d)*7/10;
	p=a+b+c+d;
	q=p/300;
	m=a+b+c+d-q*100;
	if(n>m)
	printf("2 %.2f",m);
	else
	printf("1 %.2f",n);
	return 0;
}
