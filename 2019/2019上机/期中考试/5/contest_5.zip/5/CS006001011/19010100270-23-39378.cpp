#include<stdio.h>
int main()
{
	int m,a=0,i;
	scanf("%d",&m);
	for(i=2;i<m;i++)
	 {
	 	if(m%i==0)
	 	a++;
	 }
	if(a==0)
	printf("YES");
	else
	printf("NO");
	return 0;
}
