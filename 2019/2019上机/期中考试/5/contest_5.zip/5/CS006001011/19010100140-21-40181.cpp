#include<stdio.h>
int main()
{
	int a,b,c,d;
	scanf("%d",&a);
	if(a<5001)
	{
	d=0;b=a-d;
}
	else
	if(a>5000&&a<10001)
	{
	d=(a-5000)*0.05;
	b=a-d;}
	else
	if(a<20001&&a>10000)
	{
	d=(a-10000)*0.08+250;
	b=a-d;}
	else
	if(a>20000&&a<30001)
	{
	d=1050+(a-20000)*0.15;b=a-d;
	}
	else
	if(a>30000)
	{
	d=2550+(a-30000)*0.35;b=a-d;	
	}
	printf("%d %d",d,b);
	return 0;
}
