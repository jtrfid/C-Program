#include<stdio.h>
int main()
  {
  	long int m,n,k,a[100],t,x=0,y=0,z=0,i;
  	scanf("%d %d",&m,&k);
  	for(i=0;i<m;i++)
  	scanf("%d",&a[i]);
  	for(i=0;i<m;i++)
  	{
	  t=a[i];
	  x=0;
  	while(t!=0)
  	{
  		n=t%2;
  		if(n==1)
  		{
  			x++;
  			z++;
		  }
  		t=t/2;
	  }
	  if(k==0)
	  {
	  	if(x%2!=0)
	  	y+=1;
	  }
	  else
	  {
	     if(x%2==0)
	     y+=1;
	   }
     }
  	if(y!=0)
  	printf("%d",y);
  	else
  	printf("%d",z);
  	return 0;
  }
