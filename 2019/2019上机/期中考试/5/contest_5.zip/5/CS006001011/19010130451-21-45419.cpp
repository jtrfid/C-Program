#include<stdio.h>
int main()
{printf("7");
}
