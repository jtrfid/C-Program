#include<stdio.h>
#define N 10
main()
{
	int a[N];
	int i=0,max=0,min=999;
	for(i=0;i<N;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<N;i++)
	{
		if(a[i]>max)
		max=a[i];
		if(a[i]<min)
		min=a[i];	
	}
	printf("%d %d",min ,max);
	return 0;
}
