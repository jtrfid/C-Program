#include<stdio.h>
int main()
{
	int n,r,i;
	scanf("%d",&n);
	for(i=0;i<=n;i++)
	{printf("%d",i+n);
		
	}
	
}
