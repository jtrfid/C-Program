#include<stdio.h>
int main()
{int a[100];
int i,n,t,j,x,y,p,s;
s=0;
scanf("%d\n",&n);
for(i=0;i<n-1;i++)
    {
	 scanf("%d ",&a[i]);
	  for(j=0;j<i;j++)
          if(a[j]>a[j+1]){t=a[j],a[j]=a[j+1],a[j+1]=t;}}
printf("%d %d",a[0],a[i-1]);
x=a[0];y=a[i-1];
//printf("x=%d y=%d",x,y);
if(x%2==0) p=x;
else p=x+1;
while (p<=y)
{
s=s+p;
p=p+2;}
printf(" %d",s);
return 0;
}
