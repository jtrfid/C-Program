#include<stdio.h>
int main()
{int n,count=0,x,max,min,t=0,sum=0;
scanf("%d\n",&x);
for(count=0;count<n;count++){
	scanf("%d",&x);
	if(x>t){
		max=x;
		min=t;
		t=x;
	}else{
		max=t;
		min=x;
		t=x;
		}
	if(x%2==0){
		sum+=x;
	}
}
printf("%d %d %d",min,max,sum);
return 0;
}
