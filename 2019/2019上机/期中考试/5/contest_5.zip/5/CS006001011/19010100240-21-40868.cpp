#include<stdio.h>
int main()
{int a,b,c,d,f,h=1,i=2;
float e,g;
scanf("%d %d %d %d",&a,&b,&c,&d);
e=(a+b+c+d)*0.7;
f=(a+b+c+d)/300;
g=(a+b+c+d)-f*100;
if(e<=g)
printf("%d %.2f",h,e);
else printf("%d %.2f",i,g);
return 0;
}
