#include<stdio.h>
int main()
{
   int a,b,c,d;
   float x,y;
   scanf("%d%d%d%d",&a,&b,&c,&d);
   x=(a+b+c+d)*0.7;
   y=(a+b+c+d)/300;
   y=a+b+c+d-y*100;
   if(x<y)
   {
   
   printf("1");
   printf(" ");
   printf("%.2f",x);
   
  }
  else{
  	printf("2");
   printf(" ");
   printf("%.2f",y);
   
  }
}
