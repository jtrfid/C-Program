#include<stdio.h>
int main()
{int n,x,y,s=0,i,j,t,a[100]={0};
scanf("%d",&n);

for(i=1;i<=n;i++)
{scanf("%d",&a[i]);}

for(i=1;i<n;i++)
{for(j=i+1;j<=n;j++)
{if(a[j-1]>a[j])
{t=a[j-1];a[j-1]=a[j];a[j]=t;}
}x=a[j-1];y=a[j];}x=a[1]; y=a[n];

for(t=x;t<=y;t++)
{if(t%2==0) s=s+t;}

printf("%d %d %d",x,y,s);
return 0;}
