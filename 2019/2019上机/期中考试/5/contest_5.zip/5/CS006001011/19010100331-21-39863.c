#include<stdio.h>
int main()
{
	int a,b,c,d,t;
	float sum1,sum2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	sum1=(a+b+c+d)*0.7;
	t=a+b+c+d;
	if(t>=300) sum2=(float)t-(t/300)*100;
	else sum2=t;
	if(sum1<sum2) printf("1 %.2f",sum1);
	else printf("2 %.2f",sum2);
	return 0;
}
