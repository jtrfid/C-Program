#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,g,h,i;
	scanf("%d",&a);
	b=0.05*(a-5000);
	d=0.08*(a-10000);
	f=0.15*(a-20000);
	h=0.35*(a-30000);
	if(a<=5000)
	 printf("%d %d",0*a,a);
	else
	  if(5000<a&&a<=10000)
	   printf("%d  %d",b,a-b);
	else
	  if(10000<a&&a<=20000)
	  printf("%d  %d",d+250,a-d-250); 
	else
	  if(20000<a&&a<=30000)
	  printf("%d  %d",f+1050,a-f-1050);
	else
	  printf("%d  %d",h+2550,a-2550-h);
	return 0;
}
