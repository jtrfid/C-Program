#include<stdio.h>
int main(){
	int m,n;
	scanf("%d",&m);
	if(m<10000&&m>0)
	for(n=2;n<m;n++)
	{if(m%n==0) break;
	}
	if(n<m){printf("NO");
	}else printf("YES");
	return 0;
}
