#include <stdio.h>
int main()
{
	int m,i,a=0;
	
	scanf("%d",&m);
	
	if(a==2)
	{
		printf("NO");
	}else{
	
	for(i=2;i<m;i++)
	{
		if(m%i==0)
		{
			a++;
		}
	}
	if(a!=0)
	{
		printf("YES");
	}else{
		printf("NO");
	}
}
	return 0;
}
