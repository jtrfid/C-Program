#include<stdio.h>
int main()
{
	int a,b,c,d,m,n;
	float w,q;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	w=(a+b+c+d)*0.7;
	n=a+b+c+d;
	if(n<300)
	{q=n;
	}
	if(n>=300)
	{q=n-(n/300)*100;
	}
	if(w<q)
	{m=1;
	printf("%d %.2f",m,w);
	}
	if(w>q)
	{m=2;
	printf("%d %.2f",m,q);
	
	
	}
	return 0;
	
}
