#include<stdio.h>
int main()
{
	int a,i,n=0;
	scanf("%d",&a);
	for(i=2;i<a;i++)
	{if(a%i==0)
	n=n+1;
	}
	if(n==0)
	printf("YES");
	else
	printf("NO");
}
