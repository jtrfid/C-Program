#include <stdio.h>
int main()
{
	int a, b, c;
	scanf("%d",&a);
	if(a<=5000)
		b=0;
	else
		if(a<=10000)
			b=(a-5000)*0.05;
		else
			if(a<=20000)
				b=250+(a-10000)*0.08;
			else
				if(a<=30000)
					b=1050+(a-20000)*0.15;
				else
					b=2550+(a-30000)*0.35;
	printf("%d %d",b,c=a-b);
	return 0;
}