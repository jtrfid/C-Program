#include<stdio.h>
int main()
{
	int a[10000],i,x,y,d,e,n,s=0;
	scanf("%d\n",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	x=a[0];
	for(i=1;i<n;i++)
	{
		if(a[i]<=x)
		x=a[i];
		else
		x=x;
	}
	y=a[0];
	for(i=1;i<n;i++)
	{
		if(a[i]>=y)
		y=a[i];
		else
		y=y;
	}
	d=x%2;
	if(d==0)
	{
	for(e=x;e<=y;e=e+2)
	{
		s=s+e;
	}}
	if(d!=0)
	{
	for(e=x+1;e<=y;e=e+2)
	{
		s=s+e;
	}}
	printf("%d %d %d",x,y,s);
	return 0;
	
}
