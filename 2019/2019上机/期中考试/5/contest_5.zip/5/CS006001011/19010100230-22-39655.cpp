#include<stdio.h>
int main()
{long a,x; float t;
scanf("%d",&a);

if(a<=5000)
x=0;
else if(a>5000&&a<=10000)
x=0.05*(a-5000);
else if(a>10000&&a<=20000)
x=0.05*5000+0.08*(a-10000);
else if(a>20000&&a<=30000)
x=0.05*5000+0.08*10000+0.15*(a-20000);
else if(a>30000)
x=0.05*5000+0.08*10000+0.15*10000+0.35*(a-30000);

a=a-x;
printf("%d %d",x,a);
return 0;
}
