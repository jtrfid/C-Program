#include <stdio.h>
int main()
{
	int a,b,c,s,d,p=1,q=2;
	float m,n;
	s=a+b+c+d;
	
	
	scanf("%f %f %f %f",&a,&b,&c,&d);
	
	m=0.9*a+0.8*b+0.7*c+0.7*d;
	n=s-s%300*100;
	
	if(m>n||m==n)
	{
		printf("%d % .2f",p,m);
	}else{
		printf("%d % .2f",q,n);
	}
	return 0;
}
