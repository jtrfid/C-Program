#include<stdio.h>
int main(){
	int n,a,b,c,d,i,x;
	scanf("%d%d%d",&n,&b,&c);
	if(b>c)
	a=b,b=c,c=a;
	for(i=1;i<n-2;i++){
	scanf("%d",&d);
	if(d<b)
	b=d;
	if(d>c)
	c=d;
		}
		if(b%2!=0)
		b++;
		if(c%2!=0)
		c--;
		x=(b+c)/2*((c-b)/2+1);
	printf("%d %d %d",b,c,x);
}
