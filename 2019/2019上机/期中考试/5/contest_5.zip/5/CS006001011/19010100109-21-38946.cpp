#include <stdio.h>
int main()
{
	int c, d, e, f,g;
	float a ,b;
	scanf("%d %d %d %d",&c,&d,&e,&f);
	a=(c+d+e+f)*0.7;
	g=(c+d+e+f)/300;
	b=c+d+e+f-100*g;
	if(a>b)
		printf("2 %.2f",b);
	else
		printf("1 %.2f",a);
	return 0;

}