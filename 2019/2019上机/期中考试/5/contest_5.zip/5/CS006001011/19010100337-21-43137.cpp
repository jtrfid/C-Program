#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	if(a<=5000)
	b=a;
	if(a>5000&&a<=10000)
	{b=(a-5000)*0.05;
	}
	if(a>10000&&a<=20000)
	b=(a-10000)*0.08+250;
	if(a>20000&&a<=30000)
	b=(a-20000)*0.15+1050;
	if(a>30000)
	b=(a-30000)*0.35+2550;
	c=a-b;
	printf("%d%d",b,c);
	return 0;
}
