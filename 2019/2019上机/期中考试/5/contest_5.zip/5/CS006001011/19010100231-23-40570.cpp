#include<stdio.h>
int main()
{
    int n,i,a,b;
    scanf("%d",&n);
    b=1;
    for(i=2;i<=n-1;i++)
       {
       	 a=n%i;
       	 if(a==0)
       	     b++;
       	     break;
	   }  
	if(b==1)
	   printf("YES");
	else
	   printf("NO");
	return 0;
}
