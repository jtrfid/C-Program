#include<stdio.h>
int main()
{
	int in,tem;
	int out,fact;
	int a,b,c,i;
	scanf("%d",&in);
	tem=in-5000;
	if(in>=0 && in<=5000)
	{
		out=0;
	}
	else if(in>5000 && in<=10000)
	{
		out=(in-5000)*0.05;
	}
		else if(in>10000 && in<=20000)
	{
		out=(in-10000)*0.08+250;
	}
	else if(in>20000 && in<=30000)
	{
		out=(in-20000)*0.15+250+400;
	}
	else if(in>30000)
	{
		out=(in-30000)*0.35+250+400+1500;
	}
	printf("%d %d",out,in-out);
}
