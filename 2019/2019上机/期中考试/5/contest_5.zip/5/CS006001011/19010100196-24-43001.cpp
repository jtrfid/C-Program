#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i,j,t,x,y,s,a[100];
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);	
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	x=a[0];
	y=a[n-1];
	if(x%2!=0&&y%2!=0)
	s=(x+y)*(y-x)/4;
	else if(x%2!=0&&y%2==0)
	s=(x+y+1)*(y-x+1)/4;
	else if(x%2==0&&y%2!=0)
	s=(x+y-1)*(y-x+1)/4;
	else 
	s=(x+y)*(y-x+2)/4;
	printf("%d %d %d",x,y,s);
	return 0;
}
