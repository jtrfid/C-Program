#include<stdio.h>
int main()
{
	int n,rule,rule0=0;
	int i,tem1,tem2,num,sum0=0,sum1=0;
	int a=0,b=1,wrong=0;
	int thesum1=0;
	scanf("%d %d",&n,&rule);
	if(rule==0)//ż��У�� 
{
	
	for(i=0;i<n;i++)
	{
		scanf("%d",&num);
		tem1=num;
		for(a=0;a<26;a++)
		{
			tem1=(tem1/b)%2;
			b=b*2;
			if(tem1==0)sum0++;
			if(tem1==1)sum1++;
			
		}
		if(sum0%2==1) wrong++;
		thesum1+=sum1;
		sum0=0;
		sum1=0;
		b=1;
	}
}
	else if(rule==1)//����У�� 
{
		for(i=0;i<n;i++)
	 {
		scanf("%d",&num);
		tem1=num;
		for(a=0;a<26;a++)
		{
			tem1=(tem1/b)%2;
			b=b*2;
			if(tem1==0)sum0++;
			if(tem1==1)sum1++;
		}
		if(sum0%2==0)wrong++;
		thesum1+=sum1;
		sum0=0;
		sum1=0;
		b=1;
     }	
}
if(wrong==0)
{
	printf("%d",thesum1);
}
else printf("%d",wrong);
return 0;
}
