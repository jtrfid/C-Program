#include<stdio.h>
int main()
{
	int a,b,c,d,m,n,x;
	float s,y;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	m=a+b+c+d;
	n=m%300;
	y=m-n*100;
	s=m*0.7;
	if(s>=y) {x=1;printf("%d %.2f",x,s);}
	else {x=2;printf("%d %.2f",x,y);}
	return 0;
}
