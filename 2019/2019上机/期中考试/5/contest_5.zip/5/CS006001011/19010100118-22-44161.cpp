#include<stdio.h>
int main()
{
    float a,b,c;
	scanf("%f",&a);
	if(a<=5000)
	{
	b=0; c=a;
}
	else if(5000<a<=10000)
	{
	b=(a-5000)*0.05; c=a-b;}
	else if(10000<a<=20000)
	{
	b=5000*0.05+(a-10000)*0.08; c=a-b;}
	else if(20000<a<=30000)
	{
	b=5000*0.05+10000*0.08+(a-20000)*0.15;  c=a-b;}
	else b=5000*0.05+10000*0.08+10000*0.15+(a-30000)*0.35; c=a-b;
	printf("%f%f",b,c);
	
    return 0;
}
