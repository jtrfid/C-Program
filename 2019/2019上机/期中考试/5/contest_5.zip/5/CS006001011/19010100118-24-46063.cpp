#include<stdio.h>
int main()
{
	int i,n,sum=0,min=10001,max=-1,x;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{scanf("%d",&x);
	if(x>max) max=x;
	if(x<min) max=x;
	}
	for(i=min;i<=max ;i++)
	if(i%2==0 )
	sum+=i;
	printf("%d %d %d\n",min,max,sum);
	return 0;
}
