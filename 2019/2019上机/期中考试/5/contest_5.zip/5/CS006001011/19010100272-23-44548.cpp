#include<stdio.h>
int main()
{
	int m,a;
	scanf("%d",&m);
	a=1;
	a++;
	if(m>=2&&m%a!=0)
	printf("YES\n");
	if(m%a==0)
	printf("NO\n");
	return 0;
}
