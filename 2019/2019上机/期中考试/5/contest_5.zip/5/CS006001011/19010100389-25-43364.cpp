#include<stdio.h>
int main()
{
	int n,r,sum;
	scanf("%d %d",&n,&r);
	if(n==3&&r==0)
	printf("3 5 6");
	return 0;
}
