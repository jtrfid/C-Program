#include<stdio.h>
int main()
{
	int a,b,c,d,g;
	float e,f;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=(a+b+c+d)*0.7;
	g=(a+b+c+d)/300;
	f=(a+b+c+d)-g*100;
	if(e<f)
	printf("1 %.2f",e);
	else
	printf("2 %.2f",f);
	return 0;
}
