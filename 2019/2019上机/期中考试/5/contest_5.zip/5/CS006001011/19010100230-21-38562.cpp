#include<stdio.h>
#include<math.h>
int main()
{int a,b,c,d; float t,x,y;
scanf("%d %d %d %d",&a,&b,&c,&d);
x=0.70*(a+b+c+d);
y=(a+b+c+d)-((a+b+c+d)/300)*100;
if(x<=y)
printf("1 %.2f",x);
else printf("2 %.2f",y);
return 0;
}
