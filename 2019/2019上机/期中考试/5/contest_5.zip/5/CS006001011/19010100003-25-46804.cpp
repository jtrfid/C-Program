#include<stdio.h>
int main()
{
	int n,r,i,b,d,a[1000],sum=0,flag=0,c[1000];
	scanf("%d %d",&n,&r);
	for(i=1;i<=n;i++)
	scanf("%d",&a[i]);
	for(i=1;i<=n;i++)
	{
		while(a[i])
	{
	b=a[i]%2;a[i]=a[i]/2;c[i]=sum+b;}
	d=c[i]+c[i-1];}
		if(((r==1&&d%2!=0))||((r==0&&d%2==0)))
	printf("%d",d);
	else
	{
	
for(i=1;i<=n;i++)
	{
		while(a[i])
	{
	b=a[i]%2;a[i]=a[i]/2;c[i]=sum+b;}
	
	  	
		if((r==0&&c[i]%2!=0)||(r==1&&c[i]%2==0) )flag=flag+1;
	

	
}}
	printf("%d",flag);	
	
	return 0;
}
