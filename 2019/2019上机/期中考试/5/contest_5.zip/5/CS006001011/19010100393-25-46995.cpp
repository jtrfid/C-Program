#include<stdio.h>
int main()
{
	int a,b,c,i=1,sum=0;
	int d[10],h[10];
	scanf("%d %d",&a,&c);
	for(b=1;b<=a;b++)
	{
	scanf("%d",d[b]);
	if(d[b]==4) h[b]=1;
	if(d[b]==7)  h[b]=3;
	else h[b]=2;
    sum=sum+h[b];
    }
    if(c=0)  printf("%d\n",sum);
    else	 printf("%d\n",i);
    return 0;
	
}
