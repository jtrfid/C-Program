#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	if(a<=5000)
	{
		printf("0 %d",a);
	}
	else if(a>5000&&a<10000)
	{
		b=(a-5000)*0.05;
		c=a-b;
		printf("%d %d",b,c);
	}
	else if(a>=10000&&a<20000)
	{
		b=250+(a-10000)*0.08;
		c=a-b;
		printf("%d %d",b,c);
	}
	else if(a>=20000&&a<30000)
	{
		b=1050+(a-20000)*0.15;
		c=a-b;
		printf("%d %d",b,c);
	}
	else if(a>=30000)
	{
		b=2550+(a-30000)*0.35;
		c=a-b;
		printf("%d %d",b,c);
	}
	return 0;
	
}
