#include <stdio.h>
int main()
{
	int a,b,c,d,e,g;
	float f,h;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=a+b+c+d;
	g=e/300;
	f=e-g*100;
	h=0.7*e;
		if(h<f)
			printf("1 %.2f",h);
		else if(h==f)
			printf("1 %.2f",f);
		else if(h>f)
			printf("2 %.2f",f);
}
		

	
	