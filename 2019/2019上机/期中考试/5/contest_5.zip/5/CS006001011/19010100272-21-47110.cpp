#include<stdio.h>
int main()
{
	int a,b,c,d,y,w;
	double x,z;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	x=(a+b+c+d)*0.7;
	{
	y=a+b+c+d;
    if(y<300)
	z=y;
    if(y>=300)
	w=y/300;
    z=y-100*w; 
    }
    if(x<=z)
	printf("%d %.2f\n",1,x);
    if(x>z)
	printf("%d %.2f\n",2,z);
	return 0;
}
