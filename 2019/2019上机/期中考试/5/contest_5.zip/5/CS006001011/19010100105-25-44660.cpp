#include<stdio.h>
int main()
{
	long long int n,r,mark,m,l,sum,sum2=0,c,sum3=0,p,count=0;
	int i,j,flag=1;
	scanf("%lld %lld",&n,&r);
	if(r==1){
		for(i=0;i<n;i++){
			p=1;
			sum=0;
			sum2=0;
			scanf("%lld",&c);
			if(c>=2){
				while(c){
					m=c%2;
					c/=2;
					sum+=m*p;
					p*=10;
				}
			}
		if(c<2){
				sum+=c;
			}
		for(j=0;j<12;j++){
			l=sum%10;
			sum/=10;
			if(l==1){
				sum2++;
			}
		}
		if(sum2%2==0){
			flag=0;
			count++;
		}
		if(sum2%2!=0){
			sum3+=sum2;
		}
	}
	}
	if(flag==0){
		printf("%d",count);
	}
	else printf("%d",sum3);
	return 0;
}
	
	
	
