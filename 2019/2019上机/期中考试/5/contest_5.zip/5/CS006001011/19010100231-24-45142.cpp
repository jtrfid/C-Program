#include<stdio.h>
int main()
{
    int n,a[100],i,max,min,sum,b;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
       {
       	 scanf("%d",&a[i]);
	   }
	max=a[1];
	min=a[1];
	for(i=1;i<=n;i++)
	   {
	   	 if(max<a[i])
	   	     max=a[i];
	     if(min>a[i])
	         min=a[i];
	   }
	sum=0;
	if(min%2!=0)
	   b=min+1;
	else
	   b=min;
	do
	  {
	  	sum=sum+b;
	  	b=b+2;
	  }
	while(b<=max);
	if(b>=max&&min%2!=0)
	   sum=0;
	printf("%d %d %d",min,max,sum);
	return 0;
}
