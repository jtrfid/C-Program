#include<stdio.h>
int main()
{
	int a,b,t=0;
	scanf("%d",&a);
    for(b=2;b<a;b++)
    {if(a%b==0) t++;
	}
if(t) printf("NO");
else printf("YES");

    return 0;
}
