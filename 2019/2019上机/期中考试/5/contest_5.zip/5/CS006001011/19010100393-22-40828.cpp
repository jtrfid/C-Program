#include<stdio.h>
int main()
{
	int a,i,j;
	scanf("%d",&a);
	if(a<5000) i=0;
	else if(a<=10000) i=(a-5000)*0.05;
	      else if(a<=20000) i=250+(a-10000)*0.08;
	           else if(a<=30000) i=1050+(a-20000)*0.15;
	                else i=2550+(a-30000)*0.35;
	j=a-i;
	printf("%d %d\n",i,j);
    return 0;
}
