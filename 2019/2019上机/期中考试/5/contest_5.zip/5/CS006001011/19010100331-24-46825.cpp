#include<stdio.h>
int main()
{
	int n,i,x=10000,y=0,s=0,a;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a);
		if(a<x)
		x=a;
		if(a>y)
		y=a;
	}
	for(i=x;i<y+1;i++)
	{
		if(i%2==0)
		s+=i;
	}
	printf("%d %d %d",x,y,s);
	return 0;
}
