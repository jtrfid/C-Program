#include<stdio.h>
int main()
{
	int n,i,a[100],b,c,d=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(b=0;b<n-1;b++)
	for(i=0;i<n-1-b;i++)
	if(a[i]>a[i+1])
	{c=a[i+1];
	a[i+1]=a[i];
	a[i]=c;
	}
	for(i=a[0];i<a[n-1]+1;i++)
	if((i%2)==0)
	d=d+i;
	printf("%d %d %d",a[0],a[n-1],d);
	return 0;
}
