#include<stdio.h>
int main()
{
	int a,b,c,d;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	double s,m,n;
	s=(a+b+c+d)*0.7;
	m=(a+b+c+d)/300;
	n=(a+b+c+d)-m*100;
	if(s<=n)
	printf("1 %.2lf",s);
	else
	printf("2 %.2f",n);
	return 0;
}
