#include<stdio.h>
int main()
  {
  	int a[100],n,x,y,t,j,sum=0,i;
  	scanf("%d",&n);
  	for(i=0;i<n;i++)
  	scanf("%d",&a[i]);
  	for(i=0;i<n;i++)
  	  for(j=i+1;j<n;j++)
  	   if(a[i]<a[j])
  	   {
  	   	t=a[i];a[i]=a[j];a[j]=t;
		 }
	x=a[n-1];
	y=a[0];
	for(i=x;i<y+1;i++)
	if(i%2==0)
	sum+=i;
	printf("%d %d %d",x,y,sum);
	return 0;	 
  }
