#include<stdio.h>
int main()
{int a,b=0,n,i,max,min,j;
scanf("%d\n",&n);
scanf("%d",&a);
max=min=a;
for(i=1;i<=n-1;i++)
{
scanf(" %d",&a);
if(a>max)
max=a;
if(a<min)
min=a;}
printf("%d %d ",min,max);
for(j=min;j<=max;j++)
{
if(j%2==0&&j!=1)
b=b+j;}
printf("%d",b);
return 0;
}
