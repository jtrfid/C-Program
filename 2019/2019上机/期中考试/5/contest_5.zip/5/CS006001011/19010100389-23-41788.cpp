#include<stdio.h>
int main()
{
	int m,i,t=0;
	scanf("%d",&m); 
	for(i=2;i<=m;i++)
	{
		if(m%i==0) {printf("yes");t=1;break;}
	}
	if(t==0) printf("no");
	return 0;
 } 
