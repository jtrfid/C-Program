#include<stdio.h>
int main()
{
    int a[100];
    int n,t,s=0,x,y,z;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
    	scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++)
	{
		for(int j=n-2;j>=0;j--)
		{
			if(a[j]<a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	x=a[n-1];
	y=a[0];
	z=x%2;
	if(z==0)
	{
		for(int i=x;i<=y;i+2)
		{
			s=s+i;
		}
	}
	else
	{
		for(int i=x+1;i<=y;)
		{
			s=s+i;
			i=i+2;
		}
	}
	printf("%d %d %d",x,y,s);
	return 0;
}
