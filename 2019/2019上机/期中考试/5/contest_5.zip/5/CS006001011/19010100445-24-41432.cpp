#include<stdio.h>
int main()
{
	int n,i,tem,sum=0;
	int min=100001,max=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&tem);
		if(tem>max)max=tem;
		if(tem<min)min=tem;
	}
	for(i=min;i<max+1;i++)
	{
		if(i%2==0)sum+=i;
	}
	printf("%d %d %d",min,max,sum);
}
