#include<cstdio>
int main()
{
	int n,tot=0,r,cnt=0;
	bool f=0;
	scanf("%d%d",&n,&r);
	while(n--)
	{
		int x;scanf("%d",&x);
		int t=0;
		while(x)
		{
			t+=(x&1);
			x=(x>>1);
		}
		tot+=t;
		if((t&1)!=r) f=1,cnt++;
	}
	if(f)printf("%d",cnt);
	else printf("%d",tot);
}
