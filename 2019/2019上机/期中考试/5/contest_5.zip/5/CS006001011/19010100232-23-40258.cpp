#include<stdio.h>
int main()
{int a,b,i;
b=1;
scanf("%d",&a);
for(i=2;i<a;i++)
{if(a%i==0){b=0;break;}}
if(b==0)printf("NO");
 else printf("YES");
 return 0;}
