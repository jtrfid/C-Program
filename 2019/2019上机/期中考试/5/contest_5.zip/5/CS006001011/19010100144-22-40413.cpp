#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	if(a<=5000)
	{
	b=0;
	a=a;
    }
	else if(a>5000&&a<=10000)
	{
	b=(a-5000)*0.05;
	a=a-b;
	}
	else if(a>10000&&a<=20000)
	{
	b=250+(a-10000)*0.08;
	a=a-b;
	}
	else if(a>20000&&a<=30000)
	{
	b=1050+(a-20000)*0.15;
	a=a-b;
	}
	else
	{
	b=2550+(a-30000)*0.35;
	a=a-b;
	}
	printf("%d %d",b,a);
	return 0;
	
	
	
}
