#include<stdio.h>
int main()
{
	int n,i,j,m,t,e,a[100],x,y,s=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	   {
	   for(j=i+1;j<n;j++)
	      if(a[i]<a[j])
	      {
	    	m=a[i];a[i]=a[j];a[j]=m;
		  }
	   }
    x=a[n-1];
	y=a[0];
    for(e=x;e<=y;e++)
       {
	   if(e%2==0)
	   s=s+e;
	   } 
	printf("%d %d %d",x,y,s);
	return 0;
}

