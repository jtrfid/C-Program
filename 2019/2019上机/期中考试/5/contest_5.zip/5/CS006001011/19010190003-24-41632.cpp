#include<stdio.h>
int main()
{
	int n,i,a[101],max,min;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	max=min=a[0];
	for(i=1;i<n;i++)
	{
		if (a[i]>max) max=a[i];
		if (a[i]<min) min=a[i];
	}
	printf("%d %d ",min,max);
	int s=0;
	for(i=min;i<=max;i++)
	{
		if (i%2==0) s=s+i;
	}
	printf("%d",s);
}
