#include<stdio.h>
int main()
{int k,s,i,t,n,a[1000],r,x[10000]={0};
scanf("%d %d",&n,&r);

for(i=1;i<=n;i++)
{scanf("%d",&a[i]);
for(t=2;a[i]>0;t=2*t)
switch(r)
{case 0: 
if(a[i]%2==0) s++; break;
case 1:
if(a[i]%2==1) s++; break;}
n=n/2;
}

switch(r)
{case 0: 
if(s%2==0) printf("%d",s); break;
case 1:
if(s%2==1) printf("%d",s); break;}
n=n/2;
return 0;
}
