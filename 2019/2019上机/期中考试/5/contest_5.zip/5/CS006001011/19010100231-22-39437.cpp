#include<stdio.h>
int main()
{
    int a,m,n;
    scanf("%d",&a);
    if(a<=5000)
      n=0,m=m;
    else if(a<=10000)
      n=(a-5000)*0.05;
    else if(a<=20000)
      n=250+(a-10000)*0.08;
    else if(a<=30000)
      n=250+800+(a-20000)*0.15;
    else
      n=250+800+1500+(a-30000)*0.35;
    m=a-n;
    printf("%d %d",n,m);
	return 0;
}
