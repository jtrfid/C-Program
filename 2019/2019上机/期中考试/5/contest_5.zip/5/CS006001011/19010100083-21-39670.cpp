#include<stdio.h>
int main()
{
	int a,b,c,d,e,f,n;
	scanf("%d %d %d %d ",&a,&b,&c,&d);
	e=(a+b+c+d)*0.7;
	n=(a+b+c+d)/300;
	f=a+b+c+d-n*100;
	if(e<=f) printf("1 %d",e);
	else printf("2 %d",f);
	return 0;
}
