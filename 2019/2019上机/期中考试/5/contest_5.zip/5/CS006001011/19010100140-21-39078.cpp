#include<stdio.h>
int main()
{int a,b,c,d,g,n=0;
scanf("%d%d%d%d",&a,&b,&c,&d);
	float e,f,h;
	f=(float)(a+b+c+d)*0.7;
	g=(a+b+c+d)/300;
	h=(float)((a+b+c+d)-g*100);
	if(f<=h)
	{n=1;
	printf("%d %.2f",n,f);
	}
	if(f>h)
	{n=2;
	printf("%d %.2f",n,h);
	}
	return 0;
}
