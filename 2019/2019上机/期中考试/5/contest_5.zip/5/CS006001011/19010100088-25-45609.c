#include <stdio.h>
int main()
{
	int n,r,a[1000],i,d[100000],j,s[10000],m=0,p=0;
	scanf("%d %d",&n,&r);
	
	for(i=0;i<n;i++)
	{
		s[i]=0;
		scanf("%d",&a[i]);
		for(j=0;a[i]!=0;j++)
		{
			d[j]=a[i]%2;
			a[i]=a[i]/2;
			if(d[j]==1)
			{
				s[i]++;
			}
		}
		
	}
	
	for(i=0;i<n;i++)
	{
		p=p+s[i];
	}
	
	if(r==0)
	{
		for(i=0;i<n;i++)
		{
			if(s[i]%2!=0)
			{
				m++;
			}
		}
		if(m==0)
		{
			printf("%d",p);
		}else{
			printf("%d",m);
		}
	}
	if(r==1)
	{
		for(i=0;i<n;i++)
		{
			if(s[i]%2==0)
			{
				m++;
			}
		}
		if(m==0)
		{
			printf("%d",p);
		}else{
			printf("%d",m);
		}
	}
	return 0;
	
	
	
}
