#include<stdio.h>
int main()
{
	int a[50],i,n,max,min,m,k,sum=0;
	scanf("%d\n",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	max=a[0];
	for(i=1;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
		}
		else continue;
	}
	min=a[0];
	for(i=1;i<n;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
		}
		else continue;
	}
	printf("%d %d",min,max);
	for(m=min;m<=max;m++)
	{
		k=m%2;
		if(k!=0)
		{
			continue;
		}
		sum=sum+m;
	}
	printf(" %d",sum);
	return 0;



}