#include<stdio.h>
int main()
{printf("9");
}
