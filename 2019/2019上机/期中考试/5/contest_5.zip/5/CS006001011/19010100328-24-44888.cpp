#include<stdio.h>
int main()
{
  int n,a[100],i,x,y,t,s=0;
  scanf("%d\n",&n);
  for(i=0;i<n;i++)
  {scanf("%d",&a[i]);
  }
  for(i=1;i<n;i++)
  {if(a[0]>a[i])
  a[0]=a[i];
  }
  x=a[0];

  for(i=1;i<n;i++)
  {if(a[0]<a[i])
  a[0]=a[i];
  }
  y=a[0];
   for(t=x;t<=y;t++)
   {if(t%2==0)
   s=s+t;
   }
   printf("%d %d %d",x,y,s);


}
