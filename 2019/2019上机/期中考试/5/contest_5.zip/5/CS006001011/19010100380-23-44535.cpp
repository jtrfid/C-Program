#include<stdio.h>
int main()
{
	int m,i,s=0;
	scanf("%d",&m);
	for(i=2;i<m;i++)
    if(m%i==0)
    s++;
    if(s==0)
    printf("YES");
    else
	printf("NO");
	return 0;
}


