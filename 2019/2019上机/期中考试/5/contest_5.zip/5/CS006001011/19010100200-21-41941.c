#include <stdio.h>
int main()
{
	int a,b,c,d;
	float e,f;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=a+b+c+d;
	if(e<300)
	
		f=e;
	
		else if(e<=600)
			f=e-100;
		else 
			f=e-200;
		if(0.7*e<f)
			printf("1 %.2f",0.7*e);
		else if(0.7*e==f)
			printf("1 %.2f",f);
		else if(0.7*e>f)
			printf("2 %.2f",f);
}
		

	
	