#include<stdio.h>
int main()
{int a;
int d,f;
scanf("%d",&a);
if(a<=5000){
	d=0;
	f=a;
	printf("%d %d",d,f);
}else if(a>5000&&a<=10000){
	d=(a-5000)*0.05;
	f=a-d;
	printf("%d %d",d,f);
}else if(a>10000&&a<=20000){
	d=250+(a-10000)*0.08;
	f=a-d;
	printf("%d %d",d,f);
}else if(a>20000&&a<=30000){
	d=250+(20000-10000)*0.08+(a-20000)*0.15;
	f=a-d;
	printf("%d %d",d,f);
	
}else{
	d=(10000-5000)*0.05+(20000-10000)*0.08+(30000-20000)*0.15+(a-30000)*0.35;
	f=a-d;
	printf("%d %d",d,f);
} return 0;
}
