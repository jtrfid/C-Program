#include<stdio.h>
int main()
{
	int m,flag=0,i;
	scanf("%d",&m);
	if(m==1) flag=0;
	if(m==2) flag=1;
	else 
	{
		for(i=2;i<m;i++)
		if(m%i==0)
		break;
		if(i==m)
		flag=1;
	}
	if(flag==1) printf("Yes");
	else printf("No");
	return 0;
}
