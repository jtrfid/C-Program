#include<stdio.h>
int main()
{
	int a,b,c,d,e;
	float sum,n1,n2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	sum=a+b+c+d;
	n1=sum*0.7;
	e=sum/300;
	n2=sum-e*100;
	  if(n1<=n2)
	    printf("1 %.2f",n1);
	  else
		printf("2 %.2f",n2);

	return 0;
}
