#include<stdio.h>
main()
{
	int a;
	scanf("%d",a);
	if(a<=5000)
	printf("0 %d",a);
	else
	if(5000<a&&a<=10000)
	printf("%d %d",0.05*a,0.95*a);
	else
	if(10000<a&&a<=20000)
	printf("%d %d",0.08*a,0.92*a);
	else
	if(20000<a&&a<=30000)
	printf("%d %d",0.15*a,0.85*a);
	else
	printf("%d %d",0.35*a,0.65*a);
	return 0;
}
