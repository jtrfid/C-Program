#include<stdio.h>
int main()
{
	int a,s,c;
	double t;
	scanf("%d",&a);
	if(a<=5000)
	{
		t=0;
		s=0;
		c=a;
	}
	else
	{
		if(a<=10000)
		{
			t=0.05;
			s=(a-5000)*0.05;
			c=a-s;
		}
		else
		{
			if(a<=20000)
			{
				t=0.08;
				s=(a-10000)*0.08+250;
				c=a-s;
			}
			else
			{
			 if(a<=30000)
			 {
			 	t=0.15;
			 	s=(a-20000)*0.15+1050;
			 	c=a-s;
			 }
			 else
			 {
			 	t=0.35;
			 	s=(a-30000)*0.35+2550;
			 	c=a-s;
			 }
			}
		}
	}
	printf("%d %d",s,c);
	return 0;
}
