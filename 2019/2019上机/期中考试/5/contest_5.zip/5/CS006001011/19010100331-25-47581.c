#include<stdio.h>
int main()
{
	int n,r,a[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",a[i])
	if(n>1&n<1000)
	if(r=0)
	for(i=1;i<n;i++)
	 if
}
