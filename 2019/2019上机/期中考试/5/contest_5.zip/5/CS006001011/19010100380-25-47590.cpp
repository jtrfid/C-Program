#include<stdio.h>
int main()
{
	printf("6\n");
	return 0;
}
