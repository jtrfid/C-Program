#include<stdio.h>
int main()
{
	float m,n;
	int a,b,c,d,i;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	m=(a+b+c+d)*0.7 ;
    i=(a+b+c+d)/300 ;
    n=a+b+c+d-100*i-10; 
    if(m>n)
    printf("1 %.2f",m);
    if(m<=n)
    printf("2 %.2f",n);
    return 0;
}
