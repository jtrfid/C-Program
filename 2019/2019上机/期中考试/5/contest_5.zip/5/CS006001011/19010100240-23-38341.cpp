#include<stdio.h>
int main()
{int a,i,t=1;
scanf("%d",&a);
for(i=2;i<=a-1;i++)
if(a%i==0)
{
printf("no");t=0;break;}
if(t)
printf("yes");
return 0;
}
