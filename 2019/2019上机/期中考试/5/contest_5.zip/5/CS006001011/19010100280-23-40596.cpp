#include<stdio.h>
int main()
{int n,i;
scanf("%d",&n);
for(i=2;i<n;i++){
	if(n%i==0){
	printf("NO");break;}if((i==n-1)&&n%i!=0){printf("YES");break;
	}
}return 0;
}
