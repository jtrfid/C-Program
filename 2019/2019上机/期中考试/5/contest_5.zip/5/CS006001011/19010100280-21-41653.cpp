#include<stdio.h>
int main()
{int a,b,c,d,t;float m,n;
scanf("%d %d %d %d",&a,&b,&c,&d);
m=(a+b+c+d)*0.7;
n=a+b+c+d-((a+b+c+d)/300*100);
if(m<=n){t=1;
printf("%d %.2f",t,m);}
if(m>n){t=2;printf("%d %.2f",t,n);
}
return 0;
}
