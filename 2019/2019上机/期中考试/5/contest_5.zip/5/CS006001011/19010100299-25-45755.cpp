 #include<stdio.h>
 int main()
 {int n,r,i,a[100],t,q,p=0,m=0,o=0,sum=0;
 scanf("%d %d",&n,&r);
   for(i=1;i<=n;i++)
    scanf("%d",&a[i-1]);
    for(i=0;i<=n-1;i++)
    {t=a[i];
    while(t!=0)
    {q=t%2;p=p+q;t=t/2;}if(r==0&&p%2!=0)m++;if(r==1&&p%2==0)o++;else sum=sum+p;}
if(r==0&&m==0)printf("%d",sum);
if(r==0&&m!=0)printf("%d",m);
if(r==1&&o==0)printf("%d",sum);
if(r==1&&o!=0)printf("%d",o);
return 0;}
	
 
