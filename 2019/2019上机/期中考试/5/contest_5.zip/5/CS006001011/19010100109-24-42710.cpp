#include <stdio.h>
int main()
{
	int n, x, y, s=0, a[100], b,c;
	scanf("%d",&n);
	for(b=0;b<=n-1;b++)
	{
		scanf("%d",&a[b]);
	}
	x=y=a[0];
	for(b=0;b<=n-1;b++)
	{
		if(a[b]>y)
			y=a[b];
		if(a[b]<x)
			x=a[b];
	}
	for(c=x;c<=y;c++)
	{
		if(c%2==0)
			s=s+c;
	}
	printf("%d %d %d",x,y,s);
    return 0;
}