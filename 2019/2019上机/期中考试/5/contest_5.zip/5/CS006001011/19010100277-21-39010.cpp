#include<stdio.h>
#include<cmath>
int main()
{
	int p1,p2,a,b,c,d;
	float sum1,sum2;
	p1=1;
	p2=2;
	sum1=0;
	sum2=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	sum1=(a+b+c+d)*0.7;
	sum2=a+b+c+d;
	if(a+b+c+d>=300)
	sum2=sum2-100;
	if(sum1>sum2) printf("%d %.2f",p2,sum2);
	else if(sum1<sum2) printf("%d %.2f",p1,sum1);
	else if(sum1=sum2) printf("%d %.2f",p1,sum1);
	return 0;
}
