#include<stdio.h>
int main()
{
	int m,i,n;
	scanf("%d",&m);
		for(i=2;i<m;i++)
		{
			n=m%i;
			if(n==0)
			{
				printf("NO");
				break;
			}
		}
		if(n!=0)
		printf("YES");
		
}
