#include<stdio.h>
#include<math.h>
int main()
	{
		int n,r,i=0,a[2000],m,num=0,wrong=0,sum=0;
		scanf("%d %d",&n,&r);
		while(i<n)
			{scanf("%d",&a[i]),i++;}
		i=0;
		if(r=1)
		{
		while (i<n)
			{num=0,m=pow(2,30); 
			while (a[i]!=0)
			{   
					if((a[i]/m)<1)
					{m=m/2;
					}
					if((a[i]/m)>=1)
					{a[i]=a[i]-m,num++,m=m/2;
					}
					
		    }
				
				if(num%2==0)
				{wrong++;i++;
				}
				else
				{sum=sum+num,i++;
				}
			
						
			}
		if(wrong!=0)
		{printf("%d",wrong);}
		if(wrong==0)
		{printf("%d",sum);}
		}
      if(r=0)
		{
		while (i<n)
			{num=0,m=pow(2,30); 
			while (a[i]!=0)
			{   
					if((a[i]/m)<1)
					{m=m/2;
					}
					if((a[i]/m)>=1)
					{a[i]=a[i]-m,num++,m=m/2;
					}
					
		    }
				
				if(num%2==1)
				{wrong++;i++;
				}
				else
				{sum=sum+num,i++;
				}
			
						
			}
		if(wrong!=0)
		{printf("%d",wrong);}
		if(wrong==0)
		{printf("%d",sum);}
		}
        
		
	}
