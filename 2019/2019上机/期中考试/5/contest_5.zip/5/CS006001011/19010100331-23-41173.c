#include<stdio.h>
int main()
{
	int m,i,n,c=1;
	scanf("%d",&m);
	if(m<10000)
	
	 for(i=2;i<=m;i++)
	 {
	 if(n%i==0)
	 {
	 	c=0;
	 	break;
	 }
}
if(c==1) printf("YES");
else printf("NO");
return 0;
}
