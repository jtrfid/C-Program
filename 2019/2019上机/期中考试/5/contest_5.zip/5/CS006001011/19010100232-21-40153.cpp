#include<stdio.h>
int main()
{int a,b,c,d,sum;
float m,n;
scanf("%d %d %d %d",&a,&b,&c,&d);
sum=a+b+c+d;
m=sum*0.7;
n=sum-(sum/300)*100;
if(m<n)printf("1 %.2f",m);
else printf("2 %.2f",n);
return 0;
}
