#include<stdio.h>
#include<math.h>
int main()
{int m,i; float n;
scanf("%d",&m);
if(m==1) {printf("NO");}
else
{n=sqrt(m);
for(i=2;i<=n;i++)
if(m%i==0) {printf("NO");goto C;}
printf("YES");}
C: return 0;}
