#include<stdio.h>
int main()
{
	int a,b,c,d,e;
	double x,y;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	x=(a+b+c+d)*0.7;
	e=(a+b+c+d)/300;
	y=a+b+c+d-100*e;
	if(x<=y)
	{
		printf("1 %.2f",x);
	}
	else
	{
		printf("2 %.2f",y);
	}
	return 0;
}
