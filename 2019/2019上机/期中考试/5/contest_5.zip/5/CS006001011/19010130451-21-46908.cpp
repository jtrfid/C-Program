#include<stdio.h>
int main()
{int n,i,M,m,a[101],u;
M=0;
m=10001;
scanf("%d",&n);
{for(i=1;i<=n;i++)
scanf("%d",&a[i]);
}
{for(i=1;i<=n;i++)
if(a[i]>M) M=a[i];
}
{for(i=1;i<=n;i++)
if(a[i]<m) m=a[i];
}
u=0;
{for(i=m;i<=M;i++)
if(i%2==0) u=u+i;
}
printf("%d %d %d",m,M,u);
}
