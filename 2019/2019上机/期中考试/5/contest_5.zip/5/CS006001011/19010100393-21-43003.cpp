#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	float g,h;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	e=a+b+c+d;
	f=e/300;
	g=e*0.7;
	h=e-f*100;
	if(g<=h) printf("1 %.2f\n",g);
	else printf("2 %.2f\n",h);
	return 0;
	
}
