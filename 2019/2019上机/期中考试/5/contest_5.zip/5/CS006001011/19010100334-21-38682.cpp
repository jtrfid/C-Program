#include<stdio.h>
#include<math.h>
int main()
{
	int x1,x2,x3,x4,i,t;
	double s1,s2;
	scanf("%d %d %d %d",&x1,&x2,&x3,&x4);
	s1=(x1+x2+x3+x4)*0.7;
	t=(x1+x2+x3+x4)/300;
	s2=x1+x2+x3+x4;
	for(i=1;i<=t;i++)
	{
		s2=s2-100;
	}
	if(s1<s2) printf("1 %.2f",s1);
	else printf("2 %.2f",s2);
	return 0;
}
