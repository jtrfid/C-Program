#include<stdio.h>
int main()
{
	int a,b,c,i=1,sum=0;
	int d[10];
	scanf("%d %d",&a,&c);
	for(b=1;b<=a;b++)
	{
	scanf("%d",d[b]);
	if(d[b]==4) d[b]=1;
	if(d[b]==7)  d[b]=3;
	else d[b]=2;
    sum=sum+d[b];
    }
    if(c=0)  printf("%d\n",sum);
    if(c=1)	 printf("%d\n",i);
    return 0;
	
}
