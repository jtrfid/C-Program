#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	if(a<=5000)
	{
		b=0;
		c=a;
	}
	else if(a<=10000)
	{
		b=(a-5000)*0.05;
		c=a-b;
	}
	else if(a<=20000)
	{
		b=250+(a-10000)*0.08;
		c=a-b;
	}
	else if(a<=30000)
	{
		b=250+800+(a-20000)*0.15;
		c=a-b;
	}
	else
	{
		b=250+800+1500+(a-30000)*0.35;
		c=a-b;
	}
	printf("%d %d",b,c);
	return 0;
}
