#include<stdio.h>
int main()
{
	int m,i,s;
	scanf("%d",&m);
	for(i=2;i<=m;i++)
	s=m%i;i++;
    if(s==0&&m>2)
	printf("NO");
	else
	printf("YES");
	return 0;
}

