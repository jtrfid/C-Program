#include<stdio.h>
int main()
{
	int n,r,a[1000],i,b,c,d,m,e;
	scanf("%d %d",&n,&r);
	for(i=1;i<=n;i++)
	   {
	   	 scanf("%d",&a[i]);
	   }
	m=0,e=0;;
	for(i=1;i<=n;i++)
	   {
	   	  d=0;
	   	  c=a[i];
	   	  for(;;)
	   	    {
	   	    	if(c==1)
				    {
					   d++;
				       break;
				    }
	   	    	b=c%2;
	   	    	c=c/2;
	   	    	if(b==1)
	   	    	     d++;  
            }
          if(r==1)
             {
			     if(d%2==0)
                     m++;
                 else
                     e=e+d;
             }
          else
             {
                 if(d%2!=0)
                     m++;
                 else
                     e=e+d;
             }
	   }  
	if(m==0) 
	     printf("%d",e);
    else
         printf("%d",m);
	return 0;
}
