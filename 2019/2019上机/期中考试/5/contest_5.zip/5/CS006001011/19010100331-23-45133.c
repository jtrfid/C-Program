#include<stdio.h>
int main()
{
	int m,i,c=1;
	scanf("%d",&m);
	if(m<10000)
	
	 for(i=2;i<m;i++)
	 {
	 if(m%i==0)
	 {
	 	c=0;
	 	break;
	 }
}if(c==1) printf("YES");

else printf("NO");
return 0;
}
