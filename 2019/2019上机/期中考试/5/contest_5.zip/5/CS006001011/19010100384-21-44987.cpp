#include<stdio.h>
int main()
{
	int a,b,c,d,n;
	float s1,s2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	n=a+b+c+d;
	if(n<300)
	{
		s1=n*0.7;
		s2=n;
		printf("1 %.2f",s1);
	}
	
	if(n>=300)
	{
		s1=n*0.7;
		s2=n-100;
		if(s1>s2)
		{
			printf("2 %.2f",s2);
		}
		else
		{
			printf("1 %.2f",s1);
		}
	}
	return 0;
}
	

