#include<stdio.h>
int main()
{
	int n,i=3,a,b,x,sum=0,y,t;
	scanf("%d",&n);
    scanf("%d%d",&a,&b);
	if(a>=b)
	{x=a;
	y=b;
	}
	else
	{
	x=b;
	y=a;	
	}
	while(i<=n)
	{
	scanf("%d",&t);
	 if(x>=t)
	{x=x;
	if(y>t)
	y=t;
	}
	else
	{
	x=t;	
	}
	i++;
}
printf("%d %d",y,x);
	printf(" ");
	while(y<=x)
	{
		if(y%2==0)
		sum=sum+y;
		y++;
	}
	printf("%d",sum);
	
	
}




