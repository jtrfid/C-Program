#include<stdio.h>
int main()
	{
		int a,b,c,d,sum;
		float price1,price2;
		scanf("%d %d %d %d",&a,&b,&c,&d);
		sum=a+b+c+d;
		price1=sum*0.7;
		price2=sum-(sum/300)*100;
		if(price1>price2)
			{printf("2 %.2f",price2);
			}
		if(price1<price2)
			{printf("1 %.2f",price1);
			}
		if(price1==price2)
			{printf("1 %.2f",price1);
			}
        return 0;
	}
