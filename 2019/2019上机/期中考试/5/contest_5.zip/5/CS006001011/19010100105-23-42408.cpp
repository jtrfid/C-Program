#include<stdio.h>
int main()
{
	int m,i,flag=0,y;
	scanf("%d",&m);
	for(i=2;i<m;i++){
		y=m%i;
		if(y==0){
			flag=1;
			break;
		}
	}
	if(flag==0)
	printf("YES");
	else printf("NO");
	return 0;
}
