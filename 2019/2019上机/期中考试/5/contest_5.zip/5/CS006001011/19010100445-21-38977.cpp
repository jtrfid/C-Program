#include<stdio.h>
int main()
{
	int a,b,c,d;
	int p2,p1,tem;
	double mny1,mny2;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	mny1=(a+b+c+d)*0.70;
	if(a+b+c+d>=300)
		{
			tem=(a+b+c+d)/300;
		mny2=(a+b+c+d)*1.00-(tem*100.00);
	
		}
	else mny2=a+b+c+d;
	if(mny1>mny2)
	{
		printf("2 %.2lf",mny2);
	}
	else 
	{
		printf("1 %.2lf",mny1);
	}
	return 0;
}
