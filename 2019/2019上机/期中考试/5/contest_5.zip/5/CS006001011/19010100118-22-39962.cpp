#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	if(a<=5000)
	printf("0");
	else if(5000<a<=10000)
	printf("(a-5000)*0.05");
	else if(10000<a<=20000)
	printf("5000*0.05+(a-10000)*0.08");
	else if(20000<a<=30000)
	printf("5000*0.05+10000*0.08+(a-20000)*0.15");
	else if(30000<=a)
	printf("5000*0.05+10000*0.08+10000*0.15+(a-30000)*0.35");
    return 0;
}
