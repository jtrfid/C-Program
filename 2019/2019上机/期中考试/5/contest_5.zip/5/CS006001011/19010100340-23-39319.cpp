#include<stdio.h>
int main()
{
	int a,b=1,n;
	scanf("%d",&a);
	for(n=2;n<a;n++)
	  {
	  	if(a%n==0)
	  	{
		  b=0;break;}
	  	else 
	  	b=1;
	  }
	if(b==1)
	printf("YES");
	else
	printf("NO");
	return 0;
}
