#include<stdio.h>
int main()
{
	float a,b,c,d,e,g,h;
	int f;
	scanf("%f %f %f %f",&a,&b,&c,&d);
	e=a+b+c+d;
	f=e/300;
	g=e*0.7;
	h=e-f*100;
	if(g<=h) printf("1 .2%f\n",g);
	else printf("2 .2%f\n",h);
	return 0;
	
}
