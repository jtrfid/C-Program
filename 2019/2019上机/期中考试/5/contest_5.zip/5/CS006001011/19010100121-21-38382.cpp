#include<stdio.h>
int main()
{
	float c,d,e,f,a,b,g;
	int h=0;
	scanf("%f%f%f%f",&a,&b,&c,&d);
	e=a*0.7+b*0.7+c*0.7+d*0.7;
	g=a+b+c+d;
	if(g>=300)
	h=g/300;
	f=g-h*100;
	if(e<=f)
	{
		printf("1 %.2f",e);
	}
	else{
		printf("2 %.2f",f);
	}
	return 0;
}
