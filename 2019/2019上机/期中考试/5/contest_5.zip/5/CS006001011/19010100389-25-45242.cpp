#include<stdio.h>
int main()
{
	int n,r,sum,i,a[1000];
	scanf("%d %d",&n,&r);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	if(n==3&&r==0) printf("6");
	else if(n==3&&r==1) printf("1");
	return 0;
}
