#include<stdio.h>
main()
{
	int a,b,c,d,e,h,m;
	float f,g;
	scanf("%d %d %d %d ",a,b,c,d);
	f=(a+b+c+d)*0.7;
	m=(a+b+c+d)/300;
	h=100*m;
	g=a+b+c+d-h;
	if(f>g)
	printf("1 %2.f",f);
	else
	printf("2  %2.f",g);
	
	
	
}
