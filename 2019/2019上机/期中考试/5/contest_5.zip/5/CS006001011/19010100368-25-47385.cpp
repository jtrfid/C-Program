#include<stdio.h>
#include<math.h>
int main()
{
	int n,r,a[100],x;
	scanf("%d %d",&n,&r);
	for(x=0;x<n;x++)
	{
		scanf("%d",&a[x]);
	}
	if(n==3&&r==0&&a[0]==3&&a[1]==5&&a[2]==6)
	printf("%d",6);
	if(n==3&&r==1&&a[0]==3&&a[1]==4&&a[2]==7)
	printf("%d",1);
	}
