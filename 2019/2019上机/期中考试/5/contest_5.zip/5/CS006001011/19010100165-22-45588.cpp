#include<stdio.h>
int main()
  {
  	long int a,b,c,d;
  	scanf("%d",&a);
  	b=a/5001;
  	switch(b)
  	{
  	  case 0:printf("0 %d",a);break;
  	  case 1:printf("%d %d",(a-5000)/100*5,a-(a-5000)/100*5);break;
      case 2:
      case 3:printf("%d %d",(a-10000)/100*8+250,a-(a-10000)/100*8-250);break;
      case 4:
      case 5:printf("%d %d",(a-20000)/100*15+1050,a-(a-20000)/100*15-1050);break;
      default :printf("%d %d",(a-30000)/100*35+2550,a-(a-30000)/100*35-2550);
  }
  return 0;
}
