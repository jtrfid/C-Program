#include<stdio.h>
int main()
{
	int n,a,i,x=10000,y=0,s=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a);
		if(x>a)
		{
			x=a;
		}
		else if(y<a)
		{
			y=a;
		}
	}
	if(x%2==0)
	{
		for(i=x;i<=y;i=i+2)
		{
			s=s+i;
		}
	}
	else
	{
		for(i=x+1;i<=y;i=i+2)
		{
			s=s+i;
		}
	}
	
	printf("%d %d %d",x,y,s);
	return 0;
}
