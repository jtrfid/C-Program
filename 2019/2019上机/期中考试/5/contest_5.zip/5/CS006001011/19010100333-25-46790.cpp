#include<stdio.h>
int main(){
	int a,b,c,x[1000];
	scanf("%d%d",&a,&b);
	for(c=0;c<a;c++)
	scanf("%d",&x[c]);
	for(c=0;c<a;c++)
	if(b==0)
	{
		
	}
}
