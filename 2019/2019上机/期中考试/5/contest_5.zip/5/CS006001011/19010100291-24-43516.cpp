#include<stdio.h>
int main()
{
	int n,a[100],x,y,i,sum,w;
	sum=0;
	x=10000;
	y=0;
	scanf("%d\n",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(a[i]>=y){
			y=a[i];
			if(a[i]<=x){x=a[i];
			}
		}
	}
	w=x-1;
for(w;w<=y;w++){
	if(w%2==0){
		sum=sum+w;
	}
}
	
	printf("%d %d %d",x,y,sum);
	
	
	
	
	
	
}
