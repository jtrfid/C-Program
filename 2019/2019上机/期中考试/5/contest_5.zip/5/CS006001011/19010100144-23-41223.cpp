#include<stdio.h>
int main()
{
	int n,i,k=0,a;
	scanf("%d",&n);
	for(i=2;i<n;i++)
	   {
	   	a=n%i;
	   	k+=1;
	   	if(a==0) break;
	   }
    if(k>=n-2)
    printf("YES");
    else
    printf("NO");
    return 0;
	
}

