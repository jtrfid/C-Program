#include<stdio.h>
int main()
{//int a,b,c,d;
double n1,n2,n3,a,b,c,d;
	scanf("%lf %lf %lf %lf",&a,&b,&c,&d);
	n1=(a+b+c+d)*0.7;
	n2=a+b+c+d;
	while(n2>300){
		n3=n2-100;
		n2=n2-300;
	}
	if(n3>=n1)
	printf("1 %.2f",n1);
	else printf("2 %.2f",n3);
	
	
	
	
	
	
	
	
}
