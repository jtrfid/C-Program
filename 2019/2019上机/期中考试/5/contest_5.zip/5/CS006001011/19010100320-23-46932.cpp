#include<stdio.h>
int main()
{
	int m,i,a[10000],c,b[10000];
	scanf("%d",&m);
	for(i=2;i<m;i++)
	b[i-2]=m%i;
	for(i=2;i<m;i++){
	{
	
	if(b[i-2]!=0)printf("Yes");
    if(b[i-2]==0)
	
	printf("No");}}
	return  0;
}
