#include<stdio.h>
int main()
{
	int a,t,w;
	scanf("%d",&a);
	if(a<=5000)
	{t=0;
	w=5000;
	printf("%d %d",t,w);
	}
	if(a>5000&&a<=10000)
	{t=(a-5000)*0.05;
	w=a-t;
	printf("%d %d",t,w);
	}
	if(a>10000&&a<=20000)
	{t=5000*0.05+(a-10000)*0.08;
	w=a-t;
	printf("%d %d",t,w);
	}
	if(a>20000&&a<=30000)
	{t=5000*0.05+10000*0.08+(a-20000)*0.15;
	w=a-t;
	printf("%d %d",t,w);
	}
	if(a>30000)
	{t=5000*0.05+10000*0.08+10000*0.15+(a-30000)*0.35;
	w=a-t;
	printf("%d %d",t,w);
	}
	
	
}
