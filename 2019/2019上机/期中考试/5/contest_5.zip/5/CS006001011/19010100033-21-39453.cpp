#include<stdio.h>
int main()
{
	float a,b,c,d,i,m,n;
	scanf("%f %f %f %f",&a,&b,&c,&d);
	m=(a+b+c+d)*0.7 ;
    i=(a+b+c+d)/300 ;
    n=a+b+c+d-100*i; 
    if(m>n)
    printf("1 %.2f",m);
    if(m<=n)
    printf("2 %.2f",n);
    return 0;
}
