#include<stdio.h>
int main()
{
	int n,r,p,q=0,sum=0,m=0,t=0;
	scanf("%d%d",&n,&r);
	int i,a[1000],b[1000];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		p=a[i];
		while(p!=0)
		{
			q=q+p%2;
			p=(p-p%2)/2;
		}
		b[i]=q;
	}
	for(i=0;i<n;i++)
	{
		sum=sum+b[i];
	}
	for(i=0;i<n;i++)
	{
		if(b[i]%2!=0)
		m=m+1;
	}
	for(i=0;i<n;i++)
	{
		if(b[i]%2==0)
		t=t+1;
	}
	if(r=0)
	{
		if(b[0]%2==0)
		printf("%d",sum);
		else
		printf("%d",m);
	}
	else if(r=1)
	{
		if(b[0]%2!=0)
		printf("%d",sum);
		else
		printf("%d",t);
	}
	return 0;
}
