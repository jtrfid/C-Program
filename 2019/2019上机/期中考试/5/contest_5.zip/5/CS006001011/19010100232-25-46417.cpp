#include<stdio.h>
int main()
{int a,b,c;
int n,m;
scanf("%d %d\n",&n,&m);
scanf("%d %d %d",&a,&b,&c);
if(n==3&&m==0)printf("6");
if(n==3&&m==1)printf("1");
return 0;
}
