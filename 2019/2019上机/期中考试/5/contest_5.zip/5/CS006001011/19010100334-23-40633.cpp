#include<stdio.h>
#include<math.h>
int main()
{
	int m,i,j;
	scanf("%d",&m);
	for(i=2;i<=m;i++)
	{
		if((m%i)!=0)
		continue;
		if(m==i)
		printf("YES");
		if((i<m)&&(m%i)==0)
		{
		printf("NO");
		break;
		}
	}
	return 0;
}
