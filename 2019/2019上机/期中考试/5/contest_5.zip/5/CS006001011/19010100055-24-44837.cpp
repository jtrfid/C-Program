#include<stdio.h>
int main()
{
	int n,i,a[100];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int max,min;
	for(i=0;i<n-1;i++)
	{
		if(a[i+1]<=a[i])
		{max=a[i];
		a[i]=a[i+1];
		a[i+1]=max;
		
		}max=a[i+1];
	}
	for(i=0;i<n-1;i++)
	{
		if(a[i+1]>=a[i])
		{
			min=a[i];
			a[i]=a[i+1];
			a[i+1]=min;
		}
		min=a[i+1];
	}
	int j,s=0;
	for(j=min;j<=max;j++)
	{
		if(j%2==0)
		{s+=j;
		}
		else
		continue;
	}
	printf("%d %d %d",min,max,s);
	return 0;
}
