#include<stdio.h>
int main()
{int n,r,a[1000],i,m=0,j,k,b=0;
scanf("%d %d",&n,&r);
for(i=1;i<=n;i++)
scanf("%d",a[i]);
if(r==0){
for(i=1;i<=n;i++){
	if(a[i]%2!=0)m=m+1;}if(m==0){
		for(i=1;i<=n;i++){
			do
			{j=a[i]%2;a[i]=a[i]/2;if(j==1)b=b+1;
			}while(a[i]!=0);
		}printf("%d",b);
	}else if(m!=0){
	printf("%d",m);}
}else if(r==1){
	for(i=1;i<=n;i++){
	if(a[i]%2==0)m=m+1;}if(m==0){
		for(i=1;i<=n;i++){
			do
			{j=a[i]%2;a[i]=a[i]/2;if(j==1)b=b+1;
			}while(a[i]!=0);
		}printf("%d",b);
	}else if(m!=0){
	printf("%d",m);}
}return 0;
}
