#include<stdio.h>
int main()
{
	int n,i,j,t,a[100],sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	scanf("%d",&a[i]);
	for(i=1;i<=n;i++)
	{
		for(j=i+1;j<=n;j++)
		{
			if(a[i]>=a[j])
			{
				t=a[i];a[i]=a[j];a[j]=t;
			}
		}
		
	}
	for(i=a[1];i<=a[n];i++)
	{
	if(i%2==0)
	sum=sum+i;
}
   printf("%d %d %d",a[1],a[n],sum);
   return 0;
}
