#include<stdio.h>
int main()
{int a1,a2,a3,a4;
float b,c;
scanf("%d %d %d %d",&a1,&a2,&a3,&a4);
b=(a1+a2+a3+a4)*0.7;
c=(a1+a2+a3+a4)-(a1+a2+a3+a4)/300*100;
if(b>c)
printf("2 %.2f",c);
else
printf("1 %.2f",b);
return 0;
}
