#include<stdio.h>
int main()
{
	int m,i,a;
	scanf("%d",&m);
	for (i=2;i<=m-1;i++)
	{
if (m%i!=0)
{
i++;}
}
if(m%i==0)
{printf("NO");
}else
{printf("YES");
}
return 0;
}
