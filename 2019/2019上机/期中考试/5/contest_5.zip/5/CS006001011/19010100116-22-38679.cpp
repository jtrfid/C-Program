#include<cstdio>
int main()
{
	int a;scanf("%d",&a);
	int t=0;
	if(a<=5000) t=0;
	else if(a<=10000) t=(a-5000)/100*5;
	else if(a<=20000) t=250+(a-10000)/100*8;
	else if(a<=30000) t=250+800+(a-20000)/100*15;
	else t=250+800+1500+(a-30000)/100*35;
	printf("%d %d",t,a-t);
}
