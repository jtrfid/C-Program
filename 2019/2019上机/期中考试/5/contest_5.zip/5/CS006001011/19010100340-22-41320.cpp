#include<stdio.h>
int main()
{
	float n,k;
	int c,d;
	signed a;
	scanf("%d",&a);
	  if(a<=5000)
	    n=a;
	  else if(5000<a<=10000)
	    n=5000+(a-5000)*0.95;
	  else if(10000<a<=20000)
	    n=5000+5000*0.95+(a-10000)*0.92;
	  else if(20000<a<=30000)
	    n=5000+5000*0.95+10000*0.92+(a-20000)*0.85;
	  else if(a<30000)
	    n=5000+5000*0.95+10000*0.92+10000*0.85+(a-30000)*0.65;
	k=a-n;
	c=k;
	d=n;
	printf("%d %d",c,d);
	return 0;
}
