#include<stdio.h>
int main()
{int n,x,y,s=0,i,j,t,a[100]={0};
scanf("%d",&n);

for(i=1;i<=n;i++)
{scanf("%d",&a[i]);}

for(j=1;j<=n;j++)
{for(i=j+1;i<=n;i++)
{if(a[j]<a[i])
{x=a[j]; y=a[i];}
else {x=a[i]; y=a[j];}
}}

for(t=x;t<=y;t++)
{if(t%2==0) s=s+t;}

printf("%d %d %d",x,y,s);
return 0;}
