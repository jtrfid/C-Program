#include<stdio.h>
int main()
{
   int n,x,i=1,a,sum=0;
   scanf("%d%d",&n,&x);
   if(x==
   0)
   {  
   while(i<=n)
   {scanf("%d",&a);
   if(a==1)
   {
   a=1;
   sum=sum+1;
  }
   if(a==2)
   {
   
   a=10;
   sum=sum+1;
   }
   if(a==3)
   {a=11;
   sum=sum+0;
   }
   if(a==4){
   
   a=100;
   sum=sum+1;
}
   if(a==5){
   
   a=101;
   sum=sum+0;}
   if(a==6){
   
   a=110;
   sum=sum+0;
   }
   if(a==7){
   
   a=111;
   sum=sum+1;
}
   if(a==8){
   
   a=1000;
   sum=sum+1;
}
   if(a==9){
   
   a=1001;
   sum=sum+0;
  }
   if(a==10){
   
   a=1010;
   sum=sum+0;
}
   if(a==11)
   {
   a=1011;
   sum=sum+1;
  }
   if(a==12)
   {
   
   a=1100;
   sum=sum+0;
   }
   if(a==13)
   {a=1101;
   sum=sum+1;
   }
   if(a==14){
   
   a=1110;
   sum=sum+1;
}
   if(a==15){
   
   a=1111;
   sum=sum+0;}
   if(a==16){
   
   a=10000;
   sum=sum+1;
   }
   if(a==17){
   
   a=10001;
   sum=sum+0;
}
   if(a==18){
   
   a=10010;
   sum=sum+0;
}
   if(a==19){
   
   a=10011;
   sum=sum+1;
  }
   if(a==20){
   
   a=10100;
   sum=sum+0;
}
   i++;
   }
   printf("%d",sum);
	 
}
else
{
	{  
   while(i<=n)
   {scanf("%d",&a);
   if(a==1)
   {
   a=1;
   sum=sum+0;
  }
   if(a==2)
   {
   
   a=10;
   sum=sum+1;
   }
   if(a==3)
   {a=11;
   sum=sum+1;
   }
   if(a==4){
   
   a=100;
   sum=sum+0;
}
   if(a==5){
   
   a=101;
   sum=sum+1;}
   if(a==6){
   
   a=110;
   sum=sum+0;
   }
   if(a==7){
   
   a=111;
   sum=sum+0;
}
   if(a==8){
   
   a=1000;
   sum=sum+0;
}
   if(a==9){
   
   a=1001;
   sum=sum+1;
  }
   if(a==10){
   
   a=1010;
   sum=sum+1;
}
   
   i++;
   }
   printf("%d",sum);
	 
}
}
}


