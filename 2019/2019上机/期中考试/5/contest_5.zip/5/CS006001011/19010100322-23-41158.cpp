#include<stdio.h>
int main()
{
	int m,i,a=0;
	scanf("%d",&m);
	for(i=2;i<=m/2;i++)
	{
		if(m%i==0)
		{a++;break;}
	}
	if(a==0)
    printf("YES");
    else
    printf("NO");
}
