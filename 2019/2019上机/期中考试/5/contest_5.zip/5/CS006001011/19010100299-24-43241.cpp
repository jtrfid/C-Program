#include<stdio.h>
int main()
{
	int a[100],b,i,m,p;
	scanf("%d",&b);
    for(i=1;i<=b;i++)
    scanf("%d",&a[i-1]);
  for(i=b;i>=1;i--)
  {for(p=1;p<=i;p++)
  {if(a[p-1]>a[p])
  {m=a[p-1];a[p-1]=a[p];a[p]=m;}  } 
   } 
   printf("%d %d",a[0],a[b-1]);
    return 0;
}
