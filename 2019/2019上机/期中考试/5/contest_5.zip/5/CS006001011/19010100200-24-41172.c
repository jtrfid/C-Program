#include <stdio.h>
int main()
{
	int n,i,max=0,min=10000,a,s=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a);
		if(a<min)
			min=a;
		if(a>max)
			max=a;
	}
	printf("%d %d",min,max);
	for(i=min;i<=max;i++)
		if(i%2==0)
			s=s+i;
		printf(" %d",s);
}


