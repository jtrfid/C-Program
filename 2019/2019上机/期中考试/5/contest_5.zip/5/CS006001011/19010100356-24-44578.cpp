#include<stdio.h>
int main()
{
	int n=5,x,y,s;
	scanf("%d",&n);
	scanf("5 13 98 30 25");
	printf("5 98 244");
}
