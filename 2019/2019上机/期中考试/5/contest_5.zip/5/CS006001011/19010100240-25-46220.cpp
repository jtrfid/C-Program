#include<stdio.h>
int main()
{int n,r,a,c,d,e=0,f=0,t=0,i;
scanf("%d %d\n",&n,&r);
if(r==0)
{for(i=1;i<=n;i++)
{t=0;
scanf(" %d",&a);


do{
	d=a%2;
	if(d==1)
	t=t+1;
	a=a/2;
}while(a!=0);
if(t%2==0)
f=f+t;
else e=e+1;
}

if(e==0)
printf("%d",f);
else printf("%d",e);}
if(r==1)
{for(i=1;i<=n;i++)
{t=0;
scanf(" %d",&a);


do{
	d=a%2;
	if(d==1)
	t=t+1;
	a=a/2;
}while(a!=0);
if(t%2==0)
e=e+1;
else f=f+t;
}

if(e==0)
printf("%d",f);
else printf("%d",e);}
return 0;
}
