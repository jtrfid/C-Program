#include <stdio.h>
int main()
{
	int a,b,c,s,d,p=1,q=2;
	float m,n;
	s=a+b+c+d;
	
	
	scanf("%d %d %d %d",&a,&b,&c,&d);
	
	m=0.7*s;
	n=s-s%300*100;
	
	if(m<n||m==n)
	{
		printf("%d %.2f",p,m);
	}else{
		printf("%d %.2f",q,n);
	}
	return 0;
}
