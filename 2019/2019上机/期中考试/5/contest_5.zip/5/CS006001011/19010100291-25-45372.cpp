#include<stdio.h>
int main()
{int n,r;
int a[1000],i;
scanf("%d %d\n",&n,&r);
for(i=1;i<=n;i++){
	scanf("%d",&a[i]);
		
}
printf("1");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
