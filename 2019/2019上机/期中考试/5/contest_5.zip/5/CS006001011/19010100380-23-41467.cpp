#include<stdio.h>
int main()
{
	int m,i;
	scanf("%d",&m);
	for(i=2;i<m;i++)
	if(m%i==0)
	i++;
	if(m%i==0&&m>2)
	printf("NO");
	else
	printf("YES");
	return 0;
}
