#include<stdio.h>
#define tax1 0
#define tax2 0.05
#define tax3 0.08
#define tax4 0.15
#define tax5 0.35
int main()
{
	int a,sa,tax;
	scanf("%d",&a);
	if(a<=5000){
		sa=a;
		tax=0;
	}
	if(a>5000&&a<=10000){
		tax=(a-5000)*tax2;
		sa=a-tax;
	}	
	else if(a>10000&&a<=20000){
		tax=(a-10000)*tax3+5000*tax2;
		sa=a-tax;
	}
	else if(a>20000&&a<=30000){
		tax=(a-20000)*tax4+10000*tax3+5000*tax2;
		sa=a-tax;
	}
	else if(a>30000){
	tax=(a-30000)*tax5+10000*tax4+10000*tax3+5000*tax2;
	sa=a-tax;
	}
	printf("%d %d",tax,sa);
}
