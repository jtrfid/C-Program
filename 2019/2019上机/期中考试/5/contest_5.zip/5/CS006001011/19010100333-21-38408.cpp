#include<stdio.h>
int main(){
	int a,b,c,d,m,n;
	float x,y;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	n=a+b+c+d,x=0.7*n,m=n/300,y=n-(m*100);
	if(x<=y)
	printf("1 %.2f",x);
	else
	printf("2 %.2f",y);
}
