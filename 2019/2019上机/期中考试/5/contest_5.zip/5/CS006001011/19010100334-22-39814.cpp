#include<stdio.h>
#include<math.h>
int main()
{
	int a,s,m;
	scanf("%d",&a);
	if(a<=5000) 
	s=0;
	else if(5000<a&&a<=10000) 
	s=(a-5000)*0.05;
	else if(10000<a&&a<=20000) 
	s=5000*0.05+(a-10000)*0.08;
	else if(20000<a&&a<=30000) 
	s=5000*0.05+10000*0.08+(a-20000)*0.15;
	else 
	s=5000*0.05+10000*0.08+10000*0.15+(a-30000)*0.35;
	m=a-s;
	printf("%d %d",s,m);
	return 0;
}
