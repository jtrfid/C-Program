#include <stdio.h>
int main(void)
{
	int t,h;
	scanf("%d",&t);
	h=1000-10*t*t/2;
	if(h>0)
		printf("%d",h);
	else
		printf("0");
	return 0;
}