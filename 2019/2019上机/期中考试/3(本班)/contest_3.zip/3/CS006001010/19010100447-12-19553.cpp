#include<stdio.h>
void main()
{int w,d;double y;
scanf("%d %d",&w,&d);
if(w<10)w=10;
if(d<50)d=50;
if(d<250)y=0.5*w*d;
else if(d>=250&&d<500)y=0.5*w*d*0.98;
else if(d>=500&&d<1000)y=0.5*w*d*0.95;
else if(d>=1000&&d<2000)y=0.5*w*d*0.92;
else if(d>=2000)y=0.5*w*d*0.9;
printf("%.2f",y);






























}