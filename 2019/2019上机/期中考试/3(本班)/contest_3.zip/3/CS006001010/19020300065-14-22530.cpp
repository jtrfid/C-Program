#include<stdio.h>
int main()
{
	int a,n,Sn=0,i;
	scanf("%d %d",&a,&n);
	if (a!=0)
	{	for(i=0;i<n;i++)
	{Sn=Sn+a;
	a=a*10+2;}
	}
	else Sn=0;
	printf("%d",Sn);
	return 0;
}