#include<stdio.h>
int main()
{
	int a, b;
	scanf("%d", &a);
	b = 1000-5*a*a;
	
	if(b>0) printf("%d", b);
	else printf("0");	
	return 0;
}
