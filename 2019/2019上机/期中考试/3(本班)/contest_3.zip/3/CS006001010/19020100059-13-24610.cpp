#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	printf("%d",1);
	return 0;
}
