#include<stdio.h>
int main()
{
	int w,d,k;
	float c;
	scanf("%d%d",&w,&d);
		if(w<10)
		{w=10;}
		if(d<50)
		{d=50;}
		k=d/250;
		switch(k)
		{
		case 0: c=0.5*w*d*(1-0);break;
		case 1: c=0.5*w*d*(1-0.02);break;
		case 2:
		case 3: c=0.5*w*d*(1-0.05);break;
		case 4: 
		case 5: 
		case 6: 
		case 7: c=0.5*w*d*(1-0.08);break;
		default: c=0.5*w*d*(1-0.1);
		}
		printf("%.2f",c);
		return 0;
}