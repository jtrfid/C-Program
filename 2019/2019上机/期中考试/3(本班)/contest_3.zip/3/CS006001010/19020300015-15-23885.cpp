#include<stdio.h>
int main(void)
{
	int x,y,i,a,c,d=0;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		c=i; 
		for(a=2;a<i;a++)
		{
			if(i%a==0)
			{
				c=0;break;
			}
		}
		d=d+c;
	}
	printf("%d",d);
	return 0;
}