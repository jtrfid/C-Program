#include<stdio.h>
int main()
{
	int x,y,i,a,b;
	b=0;
	scanf ("%d %d",&x,&y);
	if(y>x)
	{
		for(i=x;i<=y;i++)
		{
			for(a=2;a<i;a++)
			{
				if(i%a!=0)
				{
					continue;
				}
				else if(i%a==0)
				{
					break;
				}
			}
			if(a==1)
			{
				b=b+i;
			}
		}
	}
	else if(x>y)
	{
		for(i=y;i<=x;i++)
		{
			for(a=2;a<i;a++)
			{
				if(i%a!=0)
				{
					continue;
				}
				else if(i%a==0)
				{
					break;
				}
			}
			if(a==1)
			{
				b=b+i;
			}
		}
	}
	printf("%d",b);
	return 0;
}
