#include<stdio.h>
int main()
{
	int w,d,p=0.5,x;
	float c,r;
	scanf("%d %d",&w,%d);
	if(d>=2000)
		r=0.1;
	else
		x=d/250;
	switch(x);
	{
		case 1:r=0;break;
		case 2:r=0.02;break;
		case 3:r=0.02;break;
		case 4:
		case 5:
		case 6:
		case 7:r=0.08;break;
	}
	c=p*d*w*(1-r);
	printf("%.2f",c);
	return 0;
}
