
#include<stdio.h>
int main()
{
	int a,n,Sn,i;
	Sn=0;
	scanf("%d %d",&a,&n);

	if(a=0)
	{
		printf("Sn=0");
	}

	else
	{
		for(i=1,i<=n;i++;)
		{
			Sn=a+Sn;
		    a=a*10+a;
		}
	}
	printf("%d",Sn);
	return 0;
}