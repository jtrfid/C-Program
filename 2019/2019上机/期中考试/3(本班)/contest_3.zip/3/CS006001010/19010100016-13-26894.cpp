#include<stdio.h>
#include<string>
int main()
{
	char a[31];
	int sum=0,d=1,i,l;
	scanf("%s",&a);
	l=strlen(a);
	for(i=0;i<l;i=i+1)
	{if(i!=0)d=2*d;
	if(i==0)
	{if(a[i]=='0')sum+=0;
	 if(a[i]=='1')sum+=d;}
	else
	{
	if(a[i]=='0')sum+=0;
	else if(a[i]=='1')sum+=d;
	else break;}
	}
	printf("%d\n",sum);
	return 0;
}