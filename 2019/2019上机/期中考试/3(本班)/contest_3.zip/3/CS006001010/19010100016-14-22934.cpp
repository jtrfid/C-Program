#include<stdio.h>
int main()
{
	int sum=0,a,n,i,j,b=0,d=1;
	scanf("%d%d",&a,&n);
	for(i=1;i<=n;i++)
	{for(j=1,d=1;j<i;j++)d=10*d;
	b+=a*d;
	sum+=b;
	}
	printf("%d",sum);
	return 0;
}