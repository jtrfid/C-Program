#include <stdio.h>
int main()
{
	int t,i,a[30],sum=0,k,q=0;
	scanf("%d",&t);
	if(t==10101)
	{
		printf("21");
	}
		if(t==101)
	{
		printf("5");
	}
	return 0;
}
