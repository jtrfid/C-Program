#include<stdio.h>
int main()
 {
   int a,sum=0,dsum=1;
   scanf("%d",&a);
   while (a!=0)
   {
		sum=(a%10)*dsum+sum;
		dsum=dsum*2;
		a=a/10;
   }
   printf("%d",sum);	
}
