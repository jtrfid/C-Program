#include<stdio.h>
int main()
{

	int x,y,i,n,sum;
	
	scanf("%d %d",&x,&y);
	for(i=x,sum=0;i<=y;i++)
	{
		for(n=2;n<i;n++)
		{
			if(i%n==0)
				break;
		}
		if(n==i-1)
			sum=sum+i;
	}
	printf("%d",sum);
	return 0;




}