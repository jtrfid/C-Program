#include <stdio.h>

int main()
{
	int x, y, i, j, t;
	int a=1;
	int sum =0;
	scanf("%d %d", &x, &y);
	if (x>y)
	{
		t = x;
		x = y; 
		y = t;
	}
	for (i=x; i<=y; i++)
	{
		a =1;
		for (j=2; j<i; j++)
		{
			if (i%j!=0)
			{
				continue;
			}
			else
			{
				a=0;
				break;
			}
		}
		if (a)
		{
			sum += i;
		}
	}
	
	printf("%d", sum);
		
		
	return 0;
}