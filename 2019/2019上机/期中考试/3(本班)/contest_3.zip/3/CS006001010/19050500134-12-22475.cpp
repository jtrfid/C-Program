#include<stdio.h>
int main()
{
	double cost,p=0.5,weight,d,rate;
	scanf("%d %d",&weight,&d);
    if(d<250);
    rate=0;
    if(d>=250&&d<500);
    rate=0.02;
    if(d>=500&&d<1000);
    rate=0.05;
    if(d>=1000&&d<2000);
    rate=0.08;
    if(d>=2000);
    rate=0.1;
    cost = p*weight*d*(1-rate);
    printf("%.2d",cost);
    return 0;
}
