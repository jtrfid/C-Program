#include<stdio.h>
int main()
{
	int x,y,i,s,p;
	scanf("%d %d",&x,&y);
	s=0;
	for(i=x;i<=y;i++)
	{
		for(p=2;p<=i;p++)
		{
			if(i%p==0)break;
			s=s+i;
		}
		if(i%p==0)continue;
	}
	printf("%d\n",s);
	return 0;
}




