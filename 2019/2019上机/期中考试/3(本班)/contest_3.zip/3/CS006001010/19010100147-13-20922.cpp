#include<stdio.h>
#define p 0.5
int main()
 {
   int a,sum=0,dsum=1;
   scanf("%d",&a);
   while (a)
   {
		sum=(a%10)*dsum+sum;
		dsum=dsum*2;
		a=a/10;
   }
   printf("%d",sum);
   
}