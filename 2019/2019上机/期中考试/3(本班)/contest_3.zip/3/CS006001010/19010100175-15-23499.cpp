#include<stdio.h>
void main()
{
   int x,y,t,s=0,z;
   scanf("%d %d",&x,&y);
   if(x>y)
   {
	   z=y;
	   y=x;
	   x=z;
   }
   for(t=x;t<=y;t++)
   {
	   if(t%2!=0&&t%3!=0&&t%5!=0&&t%7!=0) s=s+t;
   }
   printf("%d",s);
}