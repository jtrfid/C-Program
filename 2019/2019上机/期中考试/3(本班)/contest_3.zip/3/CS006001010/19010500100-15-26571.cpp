#include<stdio.h>
int main(void)
{
	int x,y,sum=0,p;
	scanf("%d%d",&x,&y);
    while(x<y)
    {
    	if(x%2!=0&&x%3!=0&&x%5!=0&&x%7!=0&&x%11!=0&&x%13!=0&&x%17!=0&&x%19!=0&&x%23!=0&&x%29!=0&&x%31!=0) p=x;
    	sum+=p;
    	x++;
    }
	printf("%d",sum);
	return 0;
}
