#include<stdio.h>
int main()
{
	int w,d;
	float p;
	scanf("%d%d",&w,&d);
	if(w>0&&w<=10)
	{
		if(d<=50)
			p=0.5*10*50*1;
		else if(d>50&&d<250)
			p=0.5*10*(float)d*1;
		else if(d>=250&&d<500)
			p=0.5*10*(float)d*(1-0.02);
		else if(d>=500&&d<1000)
			p=0.5*10*(float)d*(1-0.05);
		else if(d>=1000&&d<2000)
			p=0.5*10*(float)d*(1-0.08);
		else if(d>=2000&&d<10000)
			p=0.5*10*(float)d*(1-0.1);
	}
	else if(w>10)
	{
		if(d<=50)
			p=0.5*(float)w*50*1;
		else if(d>50&&d<250)
			p=0.5*(float)w*(float)d*1;
		else if(d>=250&&d<500)
			p=0.5*(float)w*(float)d*(1-0.02);
		else if(d>=500&&d<1000)
			p=0.5*(float)w*(float)d*(1-0.05);
		else if(d>=1000&&d<2000)
			p=0.5*(float)w*(float)d*(1-0.08);
		else if(d>=2000&&d<10000)
			p=0.5*(float)w*(float)d*(1-0.1);
	}
	printf("%.2f\n",p);
	return 0;
}