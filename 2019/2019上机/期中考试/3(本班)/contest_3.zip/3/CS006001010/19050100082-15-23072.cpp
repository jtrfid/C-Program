#include<stdio.h>
int x,y,i,j;
int count=0,sum=0;
int main()
{
	scanf("%d%d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(j=2;j<=i;j++)
		{
			if(i%j==0)
			{
				break;
			}
			else continue;
		}
		if(j==i)
		{
			sum=sum+i;
		}
	}
	printf("%d",sum);
	return 0;
}