#include<stdio.h>
int main()
{
	int x,y,i,j,k,a,w,b;
	int p=0;
	scanf("%d %d",&x,&y);
	
	if(x>y){
		b=x;
		x=y;
		y=b;
	}
	for(i=x;i<=y;i++){
		k=i;
		w=0;
		for(j=2;j<k;j++){
			a=k%j;
			if(a==0){
				w++;
			}
		}
		if(w!=0){
			k=0;
		}
		p=p+k;
	}
	printf("%d",p);
	
	return 0;
}
