#include<stdio.h>

int t;
int main()
{
	scanf("%d",&t);
	if(t>=15) printf("0");
	else printf("%d",1000-5*t*t);
	return 0;

}