#include<stdio.h>
int main()
{
	float w,d,a;
	scanf("%f%f",&w,&d);
	if (w<10)
	{
		if (d<50)
			a=0.5*10*50;
		else if (d>=50&&d<250)
			a=0.5*10*d;
		else if (d>=250&&d<500)
			a=0.5*10*d*(1-0.02);
		else if (d>=500&&d<1000)
		    a=0.5*10*d*(1-0.05);
		else if (d>=1000&&d<2000)
		    a=0.5*10*d*(1-0.08);
		else if (d>=2000)
		    a=0.5*10*d*(1*0.10);
	}
    else if (w>=10)
	{
		if (d<50)
			a=0.5*w*50;
		else if (d>=50&&d<250)
			a=0.5*w*d;
		else if (d>=250&&d<500)
			a=0.5*w*d*(1-0.02);
		else if (d>=500&&d<1000)
		    a=0.5*w*d*(1-0.05);
		else if (d>=1000&&d<2000)
		    a=0.5*w*d*(1-0.08);
		else if (d>=2000)
		    a=0.5*w*d*(1*0.10);
	}
	printf("%.2f",a);
	return 0;
}

