#include <stdio.h>
int main()
{
	int a,n,i=0,sum=0,temp;
	scanf("%d,%d",&a,&n);
	if(a=0)
	{
		printf("0");
	}
	else
	{
	temp=a;
    while (i<n)
	{
		sum=sum+temp*(n-i);
		temp=a*10;
		i++;
	}
	printf("%d",sum);
	}
	return 0;
}



