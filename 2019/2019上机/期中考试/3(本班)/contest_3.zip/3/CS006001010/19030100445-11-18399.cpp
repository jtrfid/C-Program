#include<stdio.h>
int main()
{
	int x,t,i;
	scanf("%d",&t);
	x=5*t*t;
	if(x>=1000) printf("0");
	else printf("%d",1000-x);
	return 0;
}