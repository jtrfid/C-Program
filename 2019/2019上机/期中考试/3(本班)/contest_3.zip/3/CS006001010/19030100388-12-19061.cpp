#include <stdio.h>
int main()
{
	int w,d;
	double r;
	scanf("%d %d",&w,&d);
    if(w<10) w=10;
    if(d<50) d=50;
    if(d<250) r=0;
    else if(d<500) r=0.02;
    else if(d<1000) r=0.05;
    else if(d<2000) r=0.08;
    else r=0.10;
	printf("%.2f\n",0.5*(1-r)*w*d);
	return 0;
}
