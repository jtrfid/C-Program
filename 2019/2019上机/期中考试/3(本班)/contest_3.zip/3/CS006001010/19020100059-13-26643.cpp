#include<stdio.h>
int main()
{
	int n;
	scanf("%d",n);
	printf("%d",47);
	return 0;
}
