#include<stdio.h>
int main()
{
	int m,s;
	float a;
	scanf("%d%d",&m,&s);
	if(m<10)m=10;
	if(s<50)s=50;
	if(s<250)
		a=0.5*m*s;
	else if(s>249&&s<500)
		a=0.5*m*s*0.98;
	else if(s>499&&s<1000)
		a=0.5*m*s*0.95;
	else if(s>999&&s<2000)
		a=0.5*s*m*0.92;
	else
		a=0.5*s*m*0.9;
	printf("%.2f",a);
	return 0;
}