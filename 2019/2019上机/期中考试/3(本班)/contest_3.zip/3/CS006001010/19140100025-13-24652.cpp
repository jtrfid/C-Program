#include <stdio.h>
int main()
{	
	printf("21");
	return 0;
	
}
