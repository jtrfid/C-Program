#include<stdio.h>
int main()
{
	int x,y,i,m,n=0;
	scanf("%d %d",&x,&y);
	for(i=x;i<y;i++)
	{
		for(m=2;m<i;m++)
		{
			if(i%m==0)
				break;		 
		}
		n=n+i;
	}
	printf("%d\n",n);
	return 0;
}