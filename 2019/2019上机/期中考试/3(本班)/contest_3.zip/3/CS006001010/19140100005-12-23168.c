#include<stdio.h>
int main()
{
	int w,d;
	double r;
	scanf("%d %d",&w,&d);
	if(w<10){
		int w=10;
	}
	if(d<50){
		int d=50;
	}
	if(d<250){
	int r=0;}
	if(250<=d<500){
	int r=0.02;}
	if(500<=d<1000){
	int r=0.05;}
	if(1000<=d<2000){
	int r=0.08;}
	if(d>=2000){
	int r=0.1;}
	double c=(1-r)*w*d*1/2;
	printf("%.2f",c);
	return 0; 
}

