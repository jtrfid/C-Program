#include<stdio.h>
int main()
{
  int a,n,Sn,i;
  int j;
  Sn=0;
  j=0;
  scanf("%d %d",&a,&n);
  for(i=0;i<n;i++)
  {
  	j=j*10+a;
  	Sn=Sn+j;
  }
  printf("%d",Sn);
  return 0;
}
