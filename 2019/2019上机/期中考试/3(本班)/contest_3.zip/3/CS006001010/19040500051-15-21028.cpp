#include<stdio.h>
int main()
{
	int a, b, sum=0, i, j, key=1;
	scanf("%d %d", &a, &b);
	
	for ( i=a; i<b+1; i++ ) {
		key = 1;
		for ( j=2; j<a; j++ ) {
			if ( i%j == 0 ) {
				key = 0;
				break;
			}
		}
		if (key) sum = sum + i;
	}
	
	printf("%d", sum);
	return 0;
}
