#include<stdio.h>
int yes(int i){
	int q,shide=1;
	for(q=2;q<i;q++){
		if(i%q==0){
			shide=0;
			break;
		}
	}
	return shide;
}
int main()
{   int a,b,c=0,sum=0;
   
    scanf("%d%d",&a,&b);
    c=a-1;
    do{
    	c=c+1;
    	if(c<b+1){
    		if(yes(c)){
    			sum=sum+c;
    		}
    	}
    }while(c<b+1);
    printf("%d",sum);
	return 0;
}
