#include<stdio.h>
int main()
{
	int a,n,i,sn=0;
	scanf("%d%d",&a,&n);
	if(a==0)
	{
		sn=0;
		printf("%d\n",sn);
	}
	if(a!=0)
	{
		for(i=0;i<n;i++)
		{
			sn=a+sn;
			sn=a*i*10;
		}
		printf("%d\n",sn);
	}
	return 0;
}
	
