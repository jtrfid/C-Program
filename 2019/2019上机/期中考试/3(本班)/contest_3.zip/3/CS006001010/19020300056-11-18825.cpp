#include <stdio.h>
int main()
{
	int h,t;
	scanf("%d",&t);
	if(t*t==20)
	{
		h=0;
		printf("%d",h);
	}
	else
	{
		h=1000-(5*t*t);
		printf("%d",h);
	}
	return 0;
}

