#include<stdio.h>
int main()
{
	long int a,n,S,i,N;
	scanf("%ld %ld",&a,&n);
	N=10;
	for(i=1;i<=n;i++)
	{
		N=N*10;
	}
	S=a*(((N-10)/81)-(n/9));
	printf("%ld\n",S);
	return 0;
}