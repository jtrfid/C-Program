#include<stdio.h>
int main()
{
	int t,H=1000,h,g=10;
	scanf("%d",&t);
	if(t<200)
	{
		h=H-g*t*t/2;
		if(h>0)
			printf("%d\n",h);
		else printf("0\n");
	}
	return 0;
}