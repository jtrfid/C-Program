#include<stdio.h>
int main()
{
	char x;
	int i=1;
	int a[30];
	scanf("%c",x);
	a[0]=x
	while(x=80||x=81){
		scanf("%c",x);
		a[i]=x;
		i++;
	}	
	p=
	
	while(x!=64){
		printf("%d",p);
	}
	return 0;
}
