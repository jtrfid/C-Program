#include<stdio.h>
#include<math.h>
int a,n;
int b[9];
int i,j,sum=0,count=0;
int main()
{
	scanf("%d%d",&a,&n);
	if(a==0) printf("0");
	else
	{
		for(i=0;i<n;i++)
		{
			for(j=0;j<=i;j++)
			{
				sum=sum+a*pow(10,j);
			}
			b[i]=sum;
		}
		
		printf("%d",sum);
	}

	return 0;
}