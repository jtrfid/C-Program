#include <stdio.h>
int main()
{
	int w,d;
	scanf("%d%d",&w,&d);
	if(w<=10)
		if(d<50) printf("250.00");
		else if(50<=d&&d<250) printf("%.2f",5*(float)d);
		else if(250<=d&&d<500) printf("%.2f",5*(float)d*0.98);
        else if(500<=d&&d<1000) printf("%.2f",5*(float)d*0.95);
		else if(1000<=d&&d<2000) printf("%.2f",5*(float)d*0.92);
		else if(d>=2000) printf("%.2f",5*(float)d*0.9);
	if(w>10)
		if(d<50) printf("%.2f",25*(float)w);
		else if(50<=d&&d<250) printf("%.2f",0.5*(float)w*(float)d);
        else if(250<=d&&d<500) printf("%.2f",0.5*(float)w*(float)d*0.98);
        else if(500<=d&&d<1000) printf("%.2f",0.5*(float)w*(float)d*0.95);
		else if(1000<=d&&d<2000) printf("%.2f",0.5*(float)w*(float)d*0.92);
    	else if(d>=2000) printf("%.2f",0.5*(float)w*(float)d*0.9);
	return 0;
}