#include<stdio.h>
int main()
{
	int w,d,x;
	float c,r,p=0.5;
	scanf("%d %d",&w,&d);
	x=d/250;
	if(x>=8)
		r=0.1;
	else
	switch(x)
	{
		case 0:r=0;break;
		case 1:r=0.02;break;
		case 2:r=0.05;break;
		case 3:r=0.05;break;
		case 4:r=0.08;break;
		case 5:r=0.08;break;
		case 6:r=0.08;break;
		case 7:r=0.08;break;
		default:break;
	}
	c=p*d*w*(1-r);
	printf("%.2f",c);
	return 0;
}
