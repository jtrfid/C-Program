#include<stdio.h>
int main()
{
	int a,n,m,p,Sn=0,b=0;
	scanf("%d%d",&a,&n);
	if(a==0||n==0)
		Sn=0;
	if(a>0&&a<=9&&n>=1&&n<=9)
	{
		for(m=0,p=1;m!=n;m++)
		{
			b=b+a*p;
			Sn=Sn+b;
			p=p*10;
		}
	}
	printf("%d\n",Sn);
	return 0;
}