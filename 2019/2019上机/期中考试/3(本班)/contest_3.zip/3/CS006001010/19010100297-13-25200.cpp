#include<stdio.h>
int main()
{
	char x;
	int i=0,j=1,sum=0,a=1;
	do
	{
		scanf("%c",&x);
		if(x=='0'||x=='1') i=i+1;
		
		for(j=0;j<=i-1;j++)
		{
			if(x=='0') a=0;
			if(x=='1') a=a*2;
		}
		sum=sum+a;
	}while(x!='\n');
	printf("%d",sum);
}
