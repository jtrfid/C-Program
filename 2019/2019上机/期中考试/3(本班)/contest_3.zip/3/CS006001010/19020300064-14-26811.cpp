#include <stdio.h>
int main()
{
    int a,n,s;
	scanf("%d%d",&a,&n);
	if(a==0)
		s=0;
	else {if(n==1)
		s=a;
	else{ if(n==2)
		s=a*10+a;
	else{ if(n==3)
		s=a*100+a*10+a;
	else{ if(n==4)
		s=a*1000+a*100+a*10+a;
	else{ if(n==5)
	       s=a*10000+a*1000+a*100+a*10+a;
	else{ if(n==6)
		s=a*100000+a*10000+a*1000+a*100+a*10+a;
	else{ if(n==7)
	       s=a*1000000+a*100000+a*10000+a*1000+a*100+a*10+a;
	else{ if(n==8)
	       s=a*10000000+a*1000000+a*100000+a*10000+a*1000+a*100+a*10+a;
    else{ s=a*100000000+a*10000000+a*1000000+a*100000+a*10000+a*1000+a*100+a*10+a;
	}
	}
	}
	}
	}
	}
	}
	}
	}
	printf("%d",s);
    return 0;
}