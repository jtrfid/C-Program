#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d",&a);
	b = a*a*5;
	if(b<1000)
	{
		printf("%d",b);
	}
	else
	{
		printf("%d",0);
	}

}