#include<stdio.h>
int main()
{
	float w,d,n,r;
	scanf("%f%f",&w,&d);
	if (w<10.0)
	{
		w=10;
	}
	if (d<50.0)
	{
		d=50;
	}
	if (d<250)
	{
		r=0;
	}
	if (d>=250&&d<500)
	{
		r=0.02;
	}
	if (d<1000&&d>=500)
	{
	    r=0.05;
	}
	if (d<2000&&d>=1000)
	{
		r=0.08;
	}
	if (d>=2000)
	{
		r=0.1;
	}
	n=w*d*(1-r)/2;
	printf("%.2f",n);
	return 0;
}
