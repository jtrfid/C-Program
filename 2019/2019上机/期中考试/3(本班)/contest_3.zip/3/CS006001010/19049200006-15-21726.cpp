#include<stdio.h>
int main()
{
 int x,y,i=2,sum=0,m,temp;
 scanf("%d %d",&x,&y);
 if(x>y)
	 temp=x;
     x=y;
	 y=temp;
 
 for(x;x<y+1;x++)
 {
    m=x;
	 for(i=2;i<m;i++)
   {
	   if(m%i==0)
	   {
	     m=0;
		 break;
	   }
   }

   if(m!=0)
   sum=sum+m;
 }
 printf("%d",sum);
 return 0;

}