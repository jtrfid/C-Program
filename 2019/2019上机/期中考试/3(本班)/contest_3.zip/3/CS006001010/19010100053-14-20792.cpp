#include<stdio.h>
int main ()
{
	int a,b,n,s=0,i=0;
	scanf("%d%d",&a,&n);
	b=a;
	while (i<n)
	{s=s+b;
	b=b*10+a;
	i=i+1;}
	printf("%d",s);
	return 0;
}
