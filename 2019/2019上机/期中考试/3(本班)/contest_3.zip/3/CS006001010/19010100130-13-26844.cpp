#include<stdio.h>
int main()
{
	int i=0;
	int n,cnt;
	int j;
	int x=0;
	int a[30];
	for(i=0;i<29;i++)
	{
	scanf("%d",&a[i]);
	x++;
	}
	for(i=0;i<x;i++)
	{ if ((a[i]!=0)&&(a[i]!=1))
	n=i-1;
	break;
	}
   for(i=0;i<n;i++)
   {
   	j=1;
   	cnt=a[n]*j;
   	j=j*2;
   	n--;
   }
   printf("%d",cnt);
	
	
	
	return 0;
}
