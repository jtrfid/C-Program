#include<stdio.h>
int main()
{
	int a,n,i,b[9],Sn=0,d[9];
	scanf("%d %d",&a,&n);
	b[0]=0;
	d[0]=1;
	for(i=1;i<=n;i++)
	{
	d[i]=10*d[i-1];
	b[i]=b[i-1]+a*d[i-1];
    }
	for(i=1;i<=n;i++)
	Sn=Sn+b[i];
	printf("%d",Sn);
	return 0;
}
