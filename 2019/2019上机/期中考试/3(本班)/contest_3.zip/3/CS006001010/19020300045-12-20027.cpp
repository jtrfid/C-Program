#include<stdio.h>
int main(void)
{
	int d,w;
	double c;
	scanf("%d%d",&d,&w);
	if(d<250)
	{
		c=0.5*w*d;
	}
	else if(d>=250&&d<500)
	{
		c=0.5*w*d*0.02;
	}
	else if(d>=500&&d<1000)
	{
		c=0.5*w*d*0.05;
	}
	else if(d>=1000&&d<2000)
	{
		c=0.5*w*d*0.08;
	}
	else if(d>=2000)
	{
		c=0.5*w*d*0.1;
	}
	printf("%.2lf",c);
		return 0;
}