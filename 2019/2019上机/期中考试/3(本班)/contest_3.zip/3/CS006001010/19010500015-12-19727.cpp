#include<stdio.h>
int main()
{
	float w,d,c;
	scanf("%f %f",&w,&d);
	if(w<=10)
		w=10;
	if(d<=50)
		d=50;
	if(d<250)
	{c=0.50*w*d;}
	if(d>=250&&d<500)
	{c=0.50*w*d*0.98;}
	if(d>=500&&d<1000)
	{c=0.50*w*d*0.95;}
	if(d>=1000&&d<2000)
	{c=0.50*w*d*0.92;}
	if(d>2000)
	{c=0.50*w*d*0.90;}
	printf("%.2f",c);
	return 0;
}