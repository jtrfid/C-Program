#include<stdio.h>
int binToOct(char*str)
{
	int s=0;
	while(*str=='0'||*str=='1')
	{
		s=s*2+(*str-'0');
		str++;
	}
	return s;
}
int main()
{
	char str[100];
	gets(str);
	printf("%d",binToOct(str));
	return 0;
}
