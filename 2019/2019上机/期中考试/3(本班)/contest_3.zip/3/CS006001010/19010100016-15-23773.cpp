#include<stdio.h>
int main()
{
	int a,b,i,j,sum=0,k;
	scanf("%d%d",&a,&b);
	for(i=a;i<=b;i++)
	{k=1;
	for(j=2;j<i;j++)if(i%j==0)k=0;
	if(k)sum+=i;
	}
	printf("%d",sum);
	return 0;
}