#include<stdio.h>
int main()
{
	char a[40],*p = &a[0];
	int b,c,d;
	scanf("%s",&a);
	b = 0;
	while(1)
	{
		if(*p ==49||*p == 48)
		{
			b++;
			p++;
		}
		else break;
	}
	p = &a[b-1];
	c = 0;
	for(int i = 0;i<b;i++)
	{
		if(*p == 49)
		{
			d = 1;
			for(int k = 0;k<i;k++)
			{
				d *=2;
			}
			c +=d;
		}
			p--;
	}
	printf("%d",c);
}