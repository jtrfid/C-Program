#include<stdio.h>
int main()
{
	int n;
	scanf("%d",n);
	printf("%d",19);
	return 0;
}
