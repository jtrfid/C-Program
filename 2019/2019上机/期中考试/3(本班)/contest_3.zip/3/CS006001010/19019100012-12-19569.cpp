#include <stdio.h>
int main()
{
	double p=0.5,cost;
	int w,d;
	scanf("%d %d",&w,&d);
	if(w<10)
	{
		w=10;
	}
	if(d<=50)
	{
		cost=p*w*50.0;
	}
	else
	{
		if(d<250)
		{
			cost=p*w*d;
		}
		else
		{
			if(d<500)
			{
				cost=p*w*d*0.98;
			}
			else
			{
				if(d<1000)
				{
					cost=p*w*d*0.95;
				}
				else
				{
					if(d<2000)
					{
						cost=p*w*d*0.92;
					}
					else
					{
						cost=p*w*d*0.9;
					}
				}
			}
		}
	}
	printf("%.2f",cost);
	return 0;
}
