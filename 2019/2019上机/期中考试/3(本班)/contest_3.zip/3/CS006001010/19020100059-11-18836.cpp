#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d",&a);
	if(a<15)
	{
		b=1000-5*a*a;
	}
	if(a>14)
	{
		b=0;
	}
	printf("%d",b);
	return 0;
}
