#include<stdio.h>
int main()
{
	char x;
	int i=0,j=1,sum=0,a=1;
	if(x!='\n')
	{
		scanf("%c",&x);
		if(x=='0'||x=='1') i=i+2;
		for(j=0;j<=i-1;j++)
		{
			if(x=='1') a=a*2;
			else a=0;
		}
		sum=sum+a;
		a=1;
	}
	printf("%d",sum);
	return 0;
}
