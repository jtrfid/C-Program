#include<stdio.h>
int main()
{
	int h,t,t1,k,g=10,H=1000;
	scanf("%d",&t);
	k=t*t;
	t1=H/(2*g);
	if(k<t1)
	{
		h=H-((g*k)/2);
		printf("%d\n",h);
	}
	else if(k>=t1)
	{
		printf("0\n");
	}
	return 0;
}

	 
