#include <stdio.h>
int main()
{
	int m=0,n=0,i=0,j=0,k=0,s=0;
	scanf("%d %d",&m,&n);
	i=m;
	while(i<=n)
	{
	for(j=1;j<=i;j++) if(i%j==0) k++;
	if(k==2) s=s+i;
	k=0,i++;
	}
    printf("%d\n",s);
	return 0;
}
