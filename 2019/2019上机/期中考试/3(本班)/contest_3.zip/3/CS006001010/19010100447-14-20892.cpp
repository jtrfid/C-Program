#include<stdio.h>
void main()

{int a,n,s=0,i,mid=1;
scanf("%d %d",&a,&n);
for(i=n;i>0;i--,mid=mid*10)
{
s=s+n*mid;}
s=s*a;
printf("%d",s);
































if(a=0)s=0;

}