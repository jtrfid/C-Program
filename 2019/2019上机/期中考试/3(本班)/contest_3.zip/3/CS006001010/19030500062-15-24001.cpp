#include<stdio.h>
int main()
{
	int x,y,i,j,k,a;
	int p=0;
	int w=0;
	scanf("%d %d",&x,&y);
	
	
	for(i=x;i<=y;i++){
		k=i;
		for(j=2;j<i-1;j++){
			a=i%j;
			if(a==0){
				w++;
			}
		}
		if(w!=0){
			k=0;
		}
		p=p+k;
	}
	printf("%d",p);
	
	return 0;
}
