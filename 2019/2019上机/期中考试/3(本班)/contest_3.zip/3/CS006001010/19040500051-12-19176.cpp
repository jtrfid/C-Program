#include<stdio.h>
int main()
{
	int weight, distance;
	float cost;
	scanf("%d %d", &weight, &distance);
	if (weight<10) weight = 10;
	if (distance<50) distance = 50;
	
	if (distance<250) {
		cost = 0.5*weight*distance;
	} else if (distance<500) {
		cost = 0.5*weight*distance*0.98;
	} else if (distance<1000) {
		cost = 0.5*weight*distance*0.95;
	} else if (distance<2000) {
		cost = 0.5*weight*distance*0.92;
	} else {
		cost = 0.5*weight*distance*0.9;
	}
	
	printf("%.2f", cost);
	
	return 0;
}
