#include <stdio.h>
int main()
{
	int x=0,y=0,i=0,j=0,k=0,s=0;
	scanf("%d %d",&x,&y);
	i=x;
	while(i<=y)
	{
	for(j=1;j<=i;j++) if(i%j==0) k++;
	if(k==2) s=s+i;
	k=0,i++;
	}
    printf("%d\n",s);
	return 0;
}