#include<stdio.h>
int main()
{
	int t,h,s;
	scanf("%d",&t);
	s=10*t*t/2;
	h=1000-s;
	if(h<0) h=0;
	printf("%d\n",h);
	return 0;
}