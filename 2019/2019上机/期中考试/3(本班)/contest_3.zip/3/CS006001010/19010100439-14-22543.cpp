#include <stdio.h>

int main (void)
{
	int x,y,i,n,sum,u;
	int a[500];
	
	scanf ("%d%d",&x,&y);
	
	n=0;
	sum=0;
	
	for (i=x;i<=y;i++)
	{
		for (u=2;u<=i-1;u++)
		{
			if ((i%u)==0)
			{
				break;
			}
			if (u==i-1 &&  (i%u)!=0 )
			{
				n++;
				a[n]=i;
			}
		} 
	}
	
	for (i=1;i<=n;i++)
		sum += a[i];
		
	printf ("%d",sum);
	
	return 0;
}
