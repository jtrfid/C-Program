#include<stdio.h>
int main()
{
	int a,b,i,j,sum=0,k,t;
	scanf("%d%d",&a,&b);
	if(a>b)
	{t=a;
	a=b;
	b=t;
	}
	for(i=a;i<=b;i++)
	{k=1;
	for(j=2;j<i;j++)if(i%j==0)k=0;
	if(k)sum+=i;
	}
	printf("%d",sum);
	return 0;
}