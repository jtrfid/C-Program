#include<stdio.h>
int main( )
{
	int t,h;
	scanf("%d",&t);
	h=1000-0.5*10*t*t;
	if (h<0) h=0;
	printf("%d",h);
	return 0;
}
