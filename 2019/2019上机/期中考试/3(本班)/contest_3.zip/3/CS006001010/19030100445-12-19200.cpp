#include<stdio.h>
int main()
{
	double cost,rate;
	int x,w,d;
	scanf("%d %d",&w,&d);
	if(w<10) w=10;
	if(d<50) d=50;
	if(d>=50&&d<250) rate=0;
	if(d>=250&&d<500) rate=0.02;
	if(d>=500&&d<1000) rate=0.05;
	if(d>=1000&&d<2000) rate=0.08;
	if(d>=2000) rate=0.1;
	printf("%.2f",0.5*w*d*(1-rate));
	return 0;
}