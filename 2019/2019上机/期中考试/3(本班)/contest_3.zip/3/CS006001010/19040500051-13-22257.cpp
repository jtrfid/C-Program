#include<stdio.h>
int main()
{
	int a, b, t=1, sum=0;
	scanf("%d", &a);
	
	while(a>0) {
		b=a%10;
		sum = sum + b*t;
		t = t*2;
		a=a/10;
	}
	
	printf("%d", sum);
	return 0;
}
