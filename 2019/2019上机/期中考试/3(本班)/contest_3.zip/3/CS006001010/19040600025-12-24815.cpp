#include<stdio.h>
int main()
{
	int w,d,x;
	float c,r,p=0.5;
	scanf("%d %d",&w,&d);
	if(w<10)
	w=10;
	if(d<50)
	d=50;
	if(d>=2000)
	r=0.1;
	else
	if(d<250)
	r=0;
	else
	if(d>=250&&d<500)
	r=0.02;
	else
	if(d>=500&&d<1000)
	r=0.05;
	else
	if(d>=1000&&d<2000)
	r=0.08;
	c=p*d*w*(1-r);
	printf("%.2f",c);
	return 0;
}
