#include <stdio.h>
int main()
{
    int x,y,z,i,f,r;
	int sum=0;
	scanf("%d%d",&x,&y);
	for(z=x;z<=y;z++)
	{
		for(i=2;i<z;i++)
        {
		   r=z%i;
		   if(r!=0)
		   {
			   f=0;
		   }
		   else 
		   {
			   f=1;
		   }
		   printf("%d\n",f);
		}
		if(f=0)
		{
		  sum+=z;
		}
	}
	printf("%d\n",sum);
	return 0;

}

