#include<stdio.h>
int main()
{
	int a[300];
	int *head,*tail;
	int x,y,symbol,d,sum = 0;
	scanf("%d%d",&x,&y);
	a[0] = 2;
	d = 1;
	for(int i = 3;i<=1200;i+= 2)
	{
		symbol = 0;
		for(int k = 2;k<i;k++)
		{
			if(i%k == 0)
			{
				symbol = 1;
				break;
			}
		}
		if(symbol == 0)
		{
			a[d] = i;
			d++;
		}
	}
	head = &a[0];
	tail = &a[d-1];
	while(*head=<x)
	{
		head++;
	}
	while(*tail >= y)
	{
		tail--;
	}
	while(tail >= head)
	{
		sum += *head;
		head++;
	}
	printf("%d",sum);
}