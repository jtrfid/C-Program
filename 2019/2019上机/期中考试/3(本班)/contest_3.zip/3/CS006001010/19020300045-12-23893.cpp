#include<stdio.h>
int main(void)
{
	int d,w,D,W,z,x;
	double c;
	scanf("%d%d",&w,&d);
	z=d%50;
	if(0<z<50) D=d-z+50;
	else D=d;
	x=w%10;
	if(0<x<10) W=w-x+10;
	else W=w;
	if(d<250)
	{
		c=0.5*W*D;
	}
	else if(d>=250&&d<500)
	{
		c=0.5*W*D*(1-0.02);
	}
	else if(d>=500&&d<1000)
	{
		c=0.5*W*D*(1-0.05);
	}
	else if(d>=1000&&d<2000)
	{
		c=0.5*W*D*(1-0.08);
	}
	else if(d>=2000)
	{
		c=0.5*W*D*(1-0.1);
	}
	printf("%.2lf",c);
		return 0;
}