#include <stdio.h>
#include <math.h>
int n_play(int);
int main (void)
{
	char a[30],x;
	int i,n=-1,num;
	
	for (i=1;i<=30;i++)
	{
		getcher(x);
		if (x != '\n')
		{
			a[i]=x;
		}
		else
			break;
	}
	
	
	
	for (i=1;i<=30;i++)
	{
		if (a[i]==1 || a[i]==0)		n++;
		else	break;
	}
	
	for (i=1;i<=n;i++)
	{
		num=n_play(n-1)*a[i];
		n--;
	}
	
	printf ("%d",num);
	return 0;
}


int n_play(int p);
{
	int q,u=1;
	if (p>1)
	{
		for (q=1;q<=p;q++)
			u*=2;
	}
	if (p==1)	u=2;
	if (p==0)	u=1;
	return u;
}
