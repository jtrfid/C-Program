#include<stdio.h>
#define a 10
int main()
{
	
	int t,s,h;
	scanf("%d",&t);
	h=1000-a*t*t/2;
	if(t>=100)
		h=0;

	printf("%d",h);
	return 0;

}