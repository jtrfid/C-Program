#include<stdio.h>
int main()
{
	int a,h,b;
	scanf("%d",&a);
	if(a>=15)
		printf("0");
	else
	{
		h=5*a*a;
		b=1000-h;
		printf("%d",b);
	}
		return 0;
}