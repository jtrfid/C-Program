#include<stdio.h>
int main()
{
	int a,b,sum = 0,n,temp;
	scanf("%d%d",&a,&n);
	if(a ==0)
	{
		printf("%d",0);
		return 0;
	}
	temp = a;
	for(int i = 0;i<n;i++)
	{
		sum +=a;
		a = a*10+temp;
	}
	printf("%d",sum);
}