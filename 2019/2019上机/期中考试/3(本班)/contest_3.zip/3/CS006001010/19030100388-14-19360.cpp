#include <stdio.h>
int main()
{
	int a,b,s=0,n,i=0;
	scanf("%d %d",&a,&n);
	b=a;
	while(i<n)
	{
	s=s+a;
	a=a*10+b;
	i++;
	}
    printf("%d\n",s);
	return 0;
}
