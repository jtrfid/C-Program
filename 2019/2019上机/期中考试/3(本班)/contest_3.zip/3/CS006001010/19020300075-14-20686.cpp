#include<stdio.h>
int main()
{
	int a,n,Sn=0,i=1,t=10,m=0,b;
	scanf("%d %d",&a,&n);
	if(a==0)Sn=0;
	else
	{
		while(m<n)
		{
			b=a*i;
			Sn=Sn+b;
			i=i*t+1;
			m++;
		}
	}
	printf("%d",Sn);
	return 0;
}
