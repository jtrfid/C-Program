#include <stdio.h>
#define p 0.5
int main()
{
	int weight,distance;
	double rate,cost;
	scanf("%d%d",&weight,&distance);
	if(weight<10)
		weight=10;
	if(distance<50)
		distance=50;
	int c=distance/250;
	if(c>8)
	rate=0.1;
	switch(c)
	{
	case 0:rate=0;break;
	case 1:rate=0.02;break;
	case 2:
	case 3:rate=0.05;break;
	case 4:
	case 5:
	case 6:
	case 7:rate=0.08;break;
	case 8:rate=0.1;
	}
	cost=p*weight*distance*(1-rate);
	printf("%.2f",cost);
	return 0;
}