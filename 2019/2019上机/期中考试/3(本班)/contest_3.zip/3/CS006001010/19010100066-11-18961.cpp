#include<stdio.h>
int main()
{
	int t,x,h;
	scanf("%d",&t);
	x=5*t*t;
	if(x<=1000)
	{
		h=1000-x;
	printf("%d\n",h);
	}
	else if(x>1000)
	{
		printf("0\n");
	}
	return 0;
}