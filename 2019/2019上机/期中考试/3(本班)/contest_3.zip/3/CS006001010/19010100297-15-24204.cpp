#include<stdio.h>
int main()
{
	int max,min,x,y,i,j,t=0,sum=0;
	scanf("%d%d",&x,&y);
	if(x>y) {max=x;min=y;}
	else {max=y;min=x;}
	for(i=min;i<=max;i++)
	{
		for(j=2;j<=i-1;j++)
		{
			if(i%j!=0) t=t+1;
		}
		if(t!=0) sum=sum+i;
	}
	printf("%d",sum);
	return 0;
}
