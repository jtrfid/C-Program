#include <stdio.h>
int main()
{
	char a[30];
	int b,m,i;
    for(i=0;i<30;i++)
    getchar("%c",a[i]);
    
}
