#include <stdio.h>
int main()
{
	int a,n,sn=0,tn=0,i;
	scanf("%d%d",&a,&n);
	if(a==0)
		sn=0;
	for(i=0;i<n;i++)
	{
		tn+=a;
		sn=sn+tn;
		a*=10;
	}
	printf("%d",sn);
	return 0;
}