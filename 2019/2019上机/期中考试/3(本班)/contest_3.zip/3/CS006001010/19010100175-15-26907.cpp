#include<stdio.h>
int main()
{
   int x,y,t,s=0,z;
   scanf("%d %d",&x,&y);
   if(x>y)
   {
	   z=y;
	   y=x;
	   x=z;
   }
   for(t=x;t<=y;t++)
   {
	   if(t%2!=0&&t%3!=0&&t%5!=0&&t%7!=0&&t%11!=0&&t%13!=0&&t%17!=0&&t%19!=0&&(t%23!=0||t==23)&&(t%29!=0||t==29)&&(t%31!=0||t==31)) s=s+t;
   }
   printf("%d",s);
return 0;
}