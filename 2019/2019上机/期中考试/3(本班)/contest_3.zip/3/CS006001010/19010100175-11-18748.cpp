#include<stdio.h>
void main()
{
   int t,h,d;
   scanf("%d",&t);
   h=5*t*t;
   if(h>1000) printf("0");
   else
   {
	   d=1000-h;
	   printf("%d",d);
   }
}