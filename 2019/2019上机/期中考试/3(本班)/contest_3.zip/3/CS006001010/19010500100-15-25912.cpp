#include<stdio.h>
int main(void)
{
	int x,y,sum=0,p;
	scanf("%d%d",&x,&y);
    while(x<y)
    {
    	if(x%2!=0&&x%3!=0&&x%5!=0&&x%7!=0) p=x;
    	sum+=p;
    	x++;
    }
	printf("%d",sum);
	return 0;
}
