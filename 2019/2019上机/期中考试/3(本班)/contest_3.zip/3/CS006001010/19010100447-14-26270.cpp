#include<stdio.h>

void main()
{int a,n,s=1,mid=1,i,pow=1,l;
scanf("%d %d",&a,&n);
for(i=1;i<n;i++)
{for(l=0;l<i;l++)pow=pow*10;
	mid=mid+pow;
	s=s+mid;pow=1;}




s=s*a;if(a==0)s=0;
printf("%d",s);




}