#include<stdio.h>
int main()
{
	int a,n,f,s=0,i,j,b=1,h,k;
	scanf("%d %d",&a,&n);
	h=n;
	k=a;
	f=1;
	for(i=0;i<n;i++)
	{
		f=1;
		b=1;
		for(j=1;j<h;j++)
		{
			f*=10;
			b=b+f;}
		k=a*b;
		s=s+k;
		h--;
	}
	printf("%d\n",s);
	return 0;
}
