#include <stdio.h>
int main()
{
	int w,d;
	float c;
	scanf("%d %d",&w,&d);
	if(w<10)
	{
		w=10;
	}
		if(d<50)
	{
		d=50;
	}


	if(d<250)
	{
		c=0.5*d*w;
	}
	else if(d>=250&&d<500)
	{
		c=0.5*d*w*(1-0.02);
	}
	else if(d>=500&&d<500)
	{
		c=0.5*d*w*(1-0.02);
	}else if(d>=250&&d<1000)
	{
		c=0.5*d*w*(1-0.05);
	}else if(d>=1000&&d<2000)
	{
		c=0.5*d*w*(1-0.08);
	}
	else if(d>=2000)
	{
		c=0.5*d*w*(1-0.1);
	}
	printf("%.2f\n",c);
	return 0;
}



