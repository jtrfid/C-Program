#include<stdio.h>
void main()
{
   int p,d;
   float w,g,q;
   scanf("%d %d",&p,&d);
   if(p<10) p=10;
   if(d<50) d=50;
   q=(float)d;
   g=(float)p;
   if(d>=2000) w=9*g*q/20;
   else if(d>=1000) w=92*g*q/200;
   else if(d>=500) w=95*g*q/200;
   else if(d>=250) w=98*g*q/200;
   else if(d>=0) w=g*q/2;
   printf("%.2f",w);
}