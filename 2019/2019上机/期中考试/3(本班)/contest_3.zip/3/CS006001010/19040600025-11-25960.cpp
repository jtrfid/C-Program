#include<stdio.h>
int main()
{
	int t,H=1000,g=10,x,h,a;
	scanf("%d",&t);
	h=0.5*g*t*t;
	a=H-1000;
	if(t*t>200)
		printf("%d",a);
	else
		{
		x=H-h;
	printf("%d",x);
	}return 0;
}
