#include <stdio.h>
int main(void)
{
	int a,n,i,sum=0,temp;
	scanf("%d%d",&a,&n);
	if(a==0)
	{
		printf("0");
	}
	else if(a!=0)
	{
		temp=a;
		for(i=0;i<n;i++)
		{
			sum=sum+temp*(n-i);
			temp=temp*10;
		}
		printf("%d",sum);
	}
	return 0;
}
	



