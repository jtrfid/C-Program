#include<stdio.h>
int main(void)
{
	int s,a,n,b,i;
	scanf("%d%d",&a,&n);
	b=0;
	s=0;
	if(a==0)
		s=0;
	else
	{
		for(i=1;i<=n;i++)
		{
			b=b*10+a;
			s=s+b;
		}
	}
	printf("%d",s);
	return 0;
}