#include<stdio.h>
int main()
{
	int t;
	int sum=0;
	int count=0;
	int i=1;
	int a[100];
	scanf("%d",&t);
	while(t==0||t==1)
	{
		a[i]=t;
		i++;
		count++;
		scanf("%d",&t);
	}
	int b[100];
	b[1]=1;
	for(i=2;i<=count;i++)
	{
		b[i]=b[i-1]*2;
	}
	for(i=1;i<=count;i++)
	{
		sum+=a[i]*b[count-i+1];
	}
	printf("%d",sum);
	return 0;
}
