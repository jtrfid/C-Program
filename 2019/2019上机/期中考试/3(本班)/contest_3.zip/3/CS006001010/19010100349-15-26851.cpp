#include <stdio.h>
int main()
{
	int x,y,i,j,s=0,t;
	scanf("%d%d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(j=2;j<=y-1;j++)
		{
			if(i/j==0)
				break;
			if(j>y-2)
			{
				t=i;
				s=s+t;
			}
		}
	}
	printf("%d",s);
	return 0;
}
