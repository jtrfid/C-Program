#include<stdio.h>
int main(void)
{
	int t,a,h;
	scanf("%d",&t);
	a=5*t*t;
	if(a>=1000) printf("0");
	else
	{
		h=1000-a;
		printf("%d",h);
	}
	return 0;
}
