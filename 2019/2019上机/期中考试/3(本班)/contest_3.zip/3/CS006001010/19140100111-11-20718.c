#include<stdio.h>
#define a 10
int main()
{
	int t,s,h;
	scanf("%d",&t);
	s=a*t*t/2;
	h=1000-s;
	if(t==100)
		h=0;

	printf("%d",h);
	return 0;
}