#include <stdio.h>
int main()
{
	int m,n,i=0,j=0,k=0,s=0;
	scanf("%d %d",&m,&n);
	i=m;
	while(i<=n)
	{
	for(j=2;j<i;j++)
	{
	if(i%j!=0) k++;
	else break;
	}
	if(k==i-2) s=s+i;
	k=0,i++;
	}
    printf("%d\n",s);
	return 0;
}
