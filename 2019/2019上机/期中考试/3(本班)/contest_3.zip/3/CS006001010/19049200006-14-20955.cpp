#include<stdio.h>
int main()
{
  int a,n,sum;

  scanf("%d %d",&a,&n);
  switch(n)
  {
  case(1): sum=a; break;
  case(2): sum=a+a*11; break;
  case(3): sum=a+a*11+a*111; break;
  case(4): sum=a+a*11+a*111+a*1111; break;
  case(5): sum=a+a*11+a*111+a*1111+a*11111; break;
  case(6): sum=a+a*11+a*111+a*1111+a*11111+a*111111; break;
  case(7): sum=a+a*11+a*111+a*1111+a*11111+a*111111+a*1111111; break;
  case(8): sum=a+a*11+a*111+a*1111+a*11111+a*111111+a*1111111+a*11111111; break;
  case(9): sum=a+a*11+a*111+a*1111+a*11111+a*111111+a*1111111+a*11111111+a*111111111; break;
  }
 
  printf("%d",sum);
  return 0;




}