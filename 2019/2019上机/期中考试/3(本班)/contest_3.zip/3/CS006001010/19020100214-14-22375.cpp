#include<stdio.h>
int main()
{
	int a,n,s=0,i=0,m;
	scanf("%d%d",&a,&n);
	m=a;
	for(i=0;i<n;i++)
	{s=s+m;
	m=10*m+a;
	}
	printf("%d",s);
	return 0;
}