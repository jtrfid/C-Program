#include<stdio.h>
int main()
{
	int x,t,h,n=1000,a=10;
	scanf("%d",&t);
	if(t*t>=200)
	h=0;
	else
	{
		x=0.5*a*t*t;
		h=n-x;
	}
	printf("%d",h);
	return 0;
}
