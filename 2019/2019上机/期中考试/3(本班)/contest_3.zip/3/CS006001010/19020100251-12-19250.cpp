#include<stdio.h>
int main()
{
	int weigh,distance;
	double price;
	scanf("%d%d",&weigh,&distance);
	if(weigh<10)
	{
		weigh = 10;
	}
	if(distance<50)
	{
		distance = 50;
	}
	if(distance<250)
	{
		price = (double)0.5*weigh*distance;
	}
	else if(distance>=250&&distance<500)
	{
		price = (double)0.5*0.98*weigh*distance;
	}
	else if(distance>=500&&distance<1000)
	{
		price = (double)0.5*0.95*weigh*distance;
	}
	else if(distance>=1000&&distance<2000)
	{
		price = (double)0.5*0.92*weigh*distance;
	}
	else if(distance>=2000)
	{
		price = (double)0.5*0.9*weigh*distance;
	}
	printf("%.2lf",price);
	return 0;
}