#include<stdio.h>
int main()
{
	int t,h,s;
	scanf("%d",&t);
	s=5*t*t;
	h=1000-s;
	if(h<0) printf("0");
	else printf("%d",h);
	return 0;
}
