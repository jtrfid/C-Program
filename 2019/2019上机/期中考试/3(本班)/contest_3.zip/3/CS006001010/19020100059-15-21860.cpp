#include<stdio.h>
int prime(int n)
{
	int i,j;
	j=0;
	for(i=2;i<n;i++)
	{
		if (n%i==0)
		{
			j=1;
	    }
	}
	if (j==1)
	{
		return 1;
	}
	if (j==0)
	{
		return 0;
	}
}
int main()
{
	int a,b,x,y,s,v;
	s=0;
	scanf("%d%d",&a,&b);
	if (a>b)
	{
	    x=a;
	    y=b;
	}
	if (b>a)
	{
	    x=b;
	    y=a;
	}
	for(v=y;v<=x;v++)
	{
		if (prime(v)==0)
		{
			s=s+v;
		}
	}
	printf("%d",s);
	return 0;
}
