#include<stdio.h>
int main()
{
	int s=0,i,d=1,e;
    char a;
		scanf("%c",&a);
	if(a==48||a==49)
	{e=a-48;
	s=s+e*d;
	d=2*d;
	}
	printf("%d",s);
	return 0;
}