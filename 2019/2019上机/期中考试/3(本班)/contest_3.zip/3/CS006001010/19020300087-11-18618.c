#include <stdio.h>

int main()
{
	int t, s, h;
	scanf("%d", &t);
	s = 5*t*t;
	h = 1000-s;
	if (h>=0)
	{
		printf("%d", h);
	}
	else
	{
		printf("0");
	}
	
	
	return 0;
}