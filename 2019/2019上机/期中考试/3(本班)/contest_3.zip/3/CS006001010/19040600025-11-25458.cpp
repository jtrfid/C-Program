#include<stdio.h>
int main()
{
	int t,H=1000,g=10,a=0,x,h;
	scanf("%d",&t);
	h=0.5*g*t*t;
	if(h>H)
		printf("%d",a);
	else
		x=H-h;
	printf("%d",x);
	return 0;
}
