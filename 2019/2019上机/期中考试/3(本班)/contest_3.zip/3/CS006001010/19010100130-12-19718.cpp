#include<stdio.h>
int main()
{
	int d,w;
	double cost;
	scanf("%d %d",&w,&d);
	if (w<=10)
	{if (d<=50)
	cost=0.5*10*50;
	     else if((d>50)&&(d<250))
	     cost=0.5*10*d;
	          else if((d>=250)&&(d<500))
	          cost=0.5*10*d*0.98;
	               else if((d>=500)&&(d<1000))
	               cost=0.5*10*d*0.95;
	                    else if((d>=1000)&&(d<2000))
                        cost=0.5*10*d*0.92;
						     else if(d>=2000)
							 cost=0.5*10*d*0.90;
	}
	else {
	if (d<=50)
	cost=0.5*w*50;
	     else if((d>50)&&(d<250))
	     cost=0.5*w*d;
	          else if((d>=250)&&(d<500))
	          cost=0.5*w*d*0.98;
	               else if((d>=500)&&(d<1000))
	               cost=0.5*w*d*0.95;
	                    else if((d>=1000)&&(d<2000))
                        cost=0.5*w*d*0.92;
						     else if(d>=2000)
							 cost=0.5*w*d*0.90;	
	}
	printf("%.2f",cost);
      return 0;
}
