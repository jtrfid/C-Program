#include <stdio.h>
int main()
{
	int a,n,i,sum=0,temp;
	scanf("%d,%d",&a,&n);
	temp=a;
    for(i=0,i<n,i++)
	{
		sum=sum+temp*(n-i);
		temp=a*10;
	}
	printf("%d",sum);
	return 0;
}



