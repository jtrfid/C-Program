#include<stdio.h>
int main()
{
	int a,n,s;
	scanf("%d %d",&a,&n);
	if(a==0)
	{
		s=a;
		printf("%d\n",s);
	}
	else
	{
		if(n==1)
			printf("%d\n",a);
		else if(n==2)
		{
			s=a*12;
			printf("%d\n",s);
		}
		else if(n==3)
		{
			s=a*123;
			printf("%d\n",s);
		}
		else if(n==4)
		{
			s=a*1234;
			printf("%d\n",s);
		}
		else if(n==5)
		{
			s=a*12345;
			printf("%d\n",s);
		}
		else if(n==6)
		{
			s=a*123456;
			printf("%d\n",s);
		}
		else if(n==7)
		{
			s=a*1234567;
			printf("%d\n",s);
		}
		else if(n==8)
		{
			s=a*12345678;
			printf("%d\n",s);
		}
		else if(n==9)
		{
			s=a*123456789;
			printf("%d\n",s);
		}
	}
	return 0;
}