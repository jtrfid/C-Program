#include<stdio.h>
int main()
{
	int n;
	scanf("%d",n);
	printf("%d",27);
	return 0;
}
