#include<stdio.h>
int main(void)
{
	int a,n,i=0,p,sum=0,k=0;
	scanf("%d%d",&a,&n);
	p=a;
	while(i<=n)
	{
		k+=p;
		p=p*10;
		i++;
	}
	while(k>0)
	{
		k=k/10;
		sum+=k;
		i--;
	}
	printf("%d",sum);
	return 0;
}
