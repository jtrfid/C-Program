#include<stdio.h>
#include<math.h>
int main()
{
	int a,s=0,i,n=0;
	char b;
	scanf("%d%c",&a,&b);
	while(a!=0)
	{
		i=a%10;
		s=s+i*2*n;
		n++;
		a=a/10;
	}
	printf("%d",s);
	return 0;
}