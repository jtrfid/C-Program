#include<stdio.h>
int main(void)
{
	int x,y,i,b,c,d,e=0;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(b=2;b<i;b++)
		{
			d=0;
			c=i%b;
			if(c==0)
			{
				d=-i;break;
			}
		}
		e=e+i+d;
	}
	printf("%d",e);
	return 0;
}