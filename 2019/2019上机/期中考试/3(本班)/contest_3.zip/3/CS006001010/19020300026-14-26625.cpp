#include<stdio.h>
int main(void)
{
  int sn,a,n;
  scanf("%d %d",&a,&n);
  if(n==1) sn=a;
  else if(n==2) sn=a+a+a*10;
  else if(n==3) sn=a+a+a*10+a+a*10+a*100;
  else if(n==4) sn=a+a+a*10+a+a*10+a*100+a+a*10+a*100+a*1000;
  else if(n==5) sn=a+a+a*10+a+a*10+a*100+a+a*10+a*100+a*1000+a+a*10+a*100+a*1000+a*10000;
  printf("%d",sn);
  return 0;
}