#include <math.h>
#include <stdio.h>
int main()
{
	int t,g=10,h=1000,hight;
	scanf("%d",&t);
	if(t>14)
	{
		printf("0");
	}
	else
	{
		hight=h-g*t*t/2;
		printf("%d",hight);
	}
	
	return 0;
}
