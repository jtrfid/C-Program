#include<stdio.h>
int main()
{
	int x,y,sum=0,i,n,p=0;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(n=2;n<i;n++)
		{
			p=0;
			if(i%n==0)
			{
				p=1;break;
			}
		}			
		if(p==0)
		{
			sum=sum+i;
		}
	}
	printf("%d",sum);
	return 0;
}
