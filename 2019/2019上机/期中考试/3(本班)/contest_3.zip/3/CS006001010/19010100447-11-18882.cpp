#include<stdio.h>
void main()
{int t,h;
scanf("%d",&t);
if(t<=14)h=1000-5*t*t;
else h=0;
printf("%d",h);





























}