#include<stdio.h>
int main(void)
{
	int x,y,i,a,c,d=0,p;
	scanf("%d %d",&x,&y);
	if(x>y)
	{
		p=x;
		x=y;
		y=p;
	}
	for(i=x;i<=y;i++)
	{
		c=i; 
		for(a=2;a<i;a++)
		{
			if(i%a==0)
			{
				c=0;break;
			}
		}
		d=d+c;
	}
	printf("%d\n",d);
	return 0;
}