#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	int b=10*t*t*1/2;
	int c=1000-b;
	if(c>0){
		printf("%d",c);
	} 
	if(c<0){
		printf("%d",0);
	}
	return 0;
	
}
