#include<stdio.h>
int main()
{
	int m,n,i,x,y,a=0,c;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		n=i;
		c=i;
		for(m=2;m<i;m++)
		{
		if(i%m==0)
		c=2;
	    }
	    if(c==n)
	    a=a+i;
	}
	printf("%d",a);
	return 0;
}