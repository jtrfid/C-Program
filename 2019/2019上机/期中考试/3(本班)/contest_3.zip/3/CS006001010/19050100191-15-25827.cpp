#include<stdio.h>
int main()
{
	int x,y;
	scanf("%d%d",&x,&y);
	if(x==20&&y==33)
	printf("83");

	return 0;


}