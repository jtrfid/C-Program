#include<stdio.h>
int main()
{
	int t,h;
	scanf("%d",&t);
	if(t<15) h=1000-5*t*t;
	else h=0;
	printf("%d",h);
	return 0;
}