#include<stdio.h>
int main()
{
	int p,w,d,r;
	float c;
	scanf("%d %d",&w,&d);
	if(w<=10)
	w=10;
	if(d<=50)
	d=50;
	if(d<250)
	c=0.5*(float)w*(float)d;
	if(d>=250&&d<500)
	c=0.49*(float)w*(float)d;
	if(d>=500&&d<1000)
	c=19*(float)w*(float)d/40;
	if(d>=1000&&d<2000)
	c=0.46*(float)w*(float)d;
	if(d>=2000)
	c=0.45*(float)w*(float)d;
	printf("%.2f",c);
	return 0;
}
