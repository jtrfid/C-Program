#include<stdio.h>
int main()
{
	int b;
	char a;
	scanf("%c",&a);
	b=a;
	printf("%d",b);
	return 0;
}
