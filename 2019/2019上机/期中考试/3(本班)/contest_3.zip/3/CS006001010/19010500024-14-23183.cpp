#include<stdio.h>
int main()
{
	int a,n,i;
	int s=0;
	int b[100];
	scanf("%d %d",&a,&n);
	if(a==0)
	printf("0");
	else
	{
		b[0]=a;
		for(i=1;i<n;i++)
		{
			b[i]=b[i-1]*10+a;
		}
		for(i=0;i<n;i++){
			s+=b[i];
		}
		printf("%d",s);
	}
	return 0;
}
