#include<stdio.h>
int main()
{
	int x,y,i,s,p;
	scanf("%d %d",&x,&y);
	s=0;
	for(i=x;i<=y;i++)
	{
		if(p)
		{for(p=2;p<i;p++)
			{
				if(i%p==0);
			}
		}continue;
		s=s+i;
	}
	printf("%d\n",s);
	return 0;
}




