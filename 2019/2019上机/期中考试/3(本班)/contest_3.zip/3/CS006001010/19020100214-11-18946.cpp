#include<stdio.h>
int main()
{
	int t,h;
	scanf("%d",&t);
	if(t<15)
	{
	h=1000-5*t*t;
	printf("%d",h);}
	else
		printf("0");
	return 0;
}