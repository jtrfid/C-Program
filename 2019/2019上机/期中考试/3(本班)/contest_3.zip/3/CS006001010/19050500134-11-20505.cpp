#include<stdio.h>
int main()
{
	int t,h;
	scanf("%d",&t);
	if (t<=1.4);
	h=1000-5*t*t;
	printf("%d\n",h);
	if (t>=1.4);else
	printf("0");
	return 0;
	}
