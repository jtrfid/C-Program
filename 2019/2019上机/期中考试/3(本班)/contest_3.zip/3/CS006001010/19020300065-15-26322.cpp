#include<stdio.h>
int main()
{
	int x,y,i,n,sn=0;
	scanf("%d%d",&x,&y);
	for(x;x<y;x++)
	{if (x%2!=0&&x%3!=0&&x%4!=0&&x%5!=0&&x%6!=0&&x%7!=0&&x%8!=0&&x%9!=0)
	sn=sn+x;
	}
	printf("%d",sn);
	return 0;
}