#include<stdio.h>
int main()
{
	int w,d;
	float rate,cost;
	scanf("%d%d",&w,&d);
	if(w>=0&&w<10)
		w=10;
	if(d>=0&&d<50)
		d=50;
	if(d>=0&&d<250)
		rate=0;
	if(d>=250&&d<500)
		rate=0.020;
	if(d>=500&&d<1000)
		rate=0.050;
	if(d>=1000&&d<2000)
		rate=0.08;
	if(d>=2000)
		rate=0.10;
cost=0.5*w*d*(1-rate);
		printf("%.2f",cost);
	return 0;
}

