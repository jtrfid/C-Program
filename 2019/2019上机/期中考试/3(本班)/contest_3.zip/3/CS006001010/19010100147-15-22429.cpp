#include<stdio.h>
#define p 0.5
int main()
 {
   /*int a,sum=0,dsum=1;
   scanf("%d",&a);
   while (a)
   {
		sum=(a%10)*dsum+sum;
		dsum=dsum*2;
		a=a/10;
   }
   printf("%d",sum);*/
	int x,y,sum=0,i,j,k=0;
	scanf ("%d%d",&x,&y);
    for (i=x;i<=y;i++)
	{
		k=0;
		for (j=2;j<=i-1;j++)
		{
			if (i%j==0)
			{
				k=1;
				break;
			}
		}	
		if (k==0)
			sum=sum+i;
	}
	printf("%d",sum);
}