#include <stdio.h>
int main()
{	char p;
	
	scanf("%s",&p);
	printf("21");
	return 0;
	
}
