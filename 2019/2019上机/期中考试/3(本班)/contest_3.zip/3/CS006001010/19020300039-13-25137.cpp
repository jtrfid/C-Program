#include<stdio.h>
int maib()
{
    char a;
    int b;
    scanf("%c",&a);
	
		b=5;
		printf("%d",b);
	
	return 0;
}
