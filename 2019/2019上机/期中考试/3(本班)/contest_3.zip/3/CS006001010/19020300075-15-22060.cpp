#include<stdio.h>
int main()
{
	int x,y,sum=0,i,n,p;
	scanf("%d %d",&x,&y);
	for(p=x;p<=y;p++)
	{
		sum+=p;
	}
	for(i=x;i<=y;i++)
	{
		for(n=2;n<i;n++)
		{
			if(i%n==0)
			{
				sum=sum-i;break;
			}
		}
	}	
	printf("%d",sum);
	return 0;
}
