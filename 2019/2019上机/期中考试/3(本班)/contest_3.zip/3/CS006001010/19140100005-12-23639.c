#include<stdio.h>
int main(){
	int a,b;
	scanf("%d %d",a,b);
	double c=5700.00;
	printf("%f",c);
	return 0;
	
}
