#include<stdio.h>
int main()
{
	int a,n,sum=0,i,j,b=1,c=1,jieguo=0;
	scanf("%d%d",&a,&n);
	for(i=1;i<=n;i++)
	{
		for(j=2;j<=i;j++)
			{
				b=b*10;
			}
		c=a*b;
		sum=sum+c;
		b=1;
		c=1;
	}
	jieguo=sum;
	while(sum!=0)
	{
		
		jieguo=jieguo+(sum-a)/10;
		sum=(sum-a)/10;
	}
	printf("%d",jieguo);
	return 0;

}
