
#include<stdio.h>

int main(void)
{
	int w,d;
	float cost;
	scanf("%d %d",&w,&d);
	if(d<250)
	{
		if(d<=50)
		{
			cost=w*50/2;
		}
		else
		{
			cost=w*d/2;
		}
	}
	else
	{
		if(d<=500)
		{
		cost=0.5*w*d*0.98;
		}
		else
		{
	       if(d<1000)
		   {
			   cost=0.5*w*d*0.95;
		   }
		   else
		   {
			   if(d<2000)
			   {
				   cost=0.5*w*d*0.92;
			   }
			   else
			   {
				   if(d>=2000)
				   {
					   cost=0.5*w*d*0.9;
				   }
			   }
		   }
		}
	}
	printf("cost=%.2f",cost);
	return 0;
}