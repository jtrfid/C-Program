#include<stdio.h>
int main()
{
	long int a,n,Sn;
	scanf("%d%d",&a,&n);
	if (a==0)
		Sn=0;
	else if(a>0)
		if(n==1)
			Sn=a;
		if(n==2)
			Sn=a*2+a*10;
		if(n==3)
			Sn=a*3+a*10*2+a*100;
		if(n==4)
			Sn=a*4+a*10*3+a*100*2+a*1000;
		if(n==5)
			Sn=a*5+a*10*4+a*100*3+a*1000*2+a*10000;
		if(n==6)
			Sn=a*6+a*10*5+a*100*4+a*1000*3+a*1e4*2+a*1e5;
		if(n==7)
			Sn=a*7+a*10*6+a*100*5+a*1e3*4+a*1e4*3+a*1e5*2+a*1e6;
		if(n==8)
			Sn=a*8+a*10*7+a*100*6+a*1e3*5+a*1e4*4+a*1e5*3+a*1e6*2+a*1e7;
		if(n==9)
			Sn=a*9+a*10*8+a*100*7+a*1e3*6+a*1e4*5+a*1e5*4+a*1e6*3+a*1e7*2+a*1e8;
		printf("%d",Sn);
		return 0;
}