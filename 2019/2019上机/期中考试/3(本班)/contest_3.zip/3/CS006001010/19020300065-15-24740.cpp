#include<stdio.h>
int main()
{
	int x,y,i,n,sn=0;
	scanf("%d%d",&x,&y);
	n=y-x;
	for(i=0;i<n;i++)
	{if (x%2!=0||x%3!=0||x%5!=0)
	{sn=sn+x;
	x=x+1;}
	}
	printf("%d",sn);
	return 0;
}