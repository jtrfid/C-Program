#include<stdio.h>





void main()
{int a,n,s=0,mid=1,i,pow=1;
scanf("%d %d",&a,&n);
for(i=1;i<n;i++)
{while(i--)pow=pow*10;
	mid=mid+pow;
	s=s+mid;}




s=s*a;if(a==0)s=0;
printf("%d",s);






}