#include <stdio.h>
int main ()
{
	int w,d,r;
	scanf("%d,%d",&w,&d);
	if(w<10) w=10;
	else w=w;
	if(d<50) d=50;
	else d=d;

	if(d<250) r=100;
	else if(d>=250&&d<500) r=98;
	else if(d>=500&&d<1000) r=95;
	else if(d>=1000&&d<2000) r=92;
	else if(d>=2000) r=90;
	printf("%.2f",float(w*d*r/200));
	return 0;
}

