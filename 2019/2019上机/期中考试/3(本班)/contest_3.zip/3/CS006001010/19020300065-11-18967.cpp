#include<stdio.h>
int main()
{
	int h,t,s;
	scanf("%d",&t);
	s=5*t*t;
	h=1000-s;
	if(s>=1000)printf("0");
	else printf("%d",h);
	return 0;
}
