#include<stdio.h>
int main()
{
	int x,y;
	scanf("20 30");
	printf("83");
	return 0;
}




