#include<stdio.h>
int main()
{
	int a,n,s=0,i,j,k,m,b;
	scanf("%d %d",&a,&n);
	k=n;
	s=0;
	m=a;
	b=a;
	for(i=n;i>0;i--)
	{
		for(j=0;j<i-1;j++)
		{a*=10;
		m+=a;}
		s+=m;
		a=b;
		m=a;
	}
	printf("%d",s);
	return 0;
}
