#include<stdio.h>
#include<math.h>
#define a 10
int main()
{
	
	int t,s,h;
	double q;
	scanf("%d",&t);
	h=1000-a*t*t/2;
	q=sqrt(2)*10;
	
	if(t>=q)
		h=0;

	printf("%d",h);
	return 0;

}