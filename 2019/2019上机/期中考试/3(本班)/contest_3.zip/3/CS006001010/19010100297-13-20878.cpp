#include<stdio.h>
int main()
{
	char x;
	int b=1,sum=0,i=0,a[30],j=0,k;
	do
	{
		scanf("%c",&x);
		if(x!=0||x!=1) break;
		i++;
		a[i]=x;
	}while(x!='\n');
	for(j=0;j<=i;j++)
		{
			b=1;
		for(k=0;k<=i;k++)
			{
				b=b*2*a[i];
			}
			sum=sum+b;
			
		}
	printf("%d",sum);
	return 0;
	
}
