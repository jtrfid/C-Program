#include<stdio.h>
#include<math.h>
int main()
{
	int a,n,S,N;
	scanf("%d %d",&a,&n);
	N=pow(10,n+1);
	S=a*(((N-10)/81)-(n/9));
	printf("%d\n",S);
	return 0;
}