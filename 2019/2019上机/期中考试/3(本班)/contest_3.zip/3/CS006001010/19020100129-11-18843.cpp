#include<stdio.h>

int main(void)
{
	int t,h;
	scanf("%d",t);
	h=1000-(10*t*t)/2;
	printf("%d",h);
	return 0;

}


