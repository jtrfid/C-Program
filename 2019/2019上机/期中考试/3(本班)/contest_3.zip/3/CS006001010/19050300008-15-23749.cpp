#include <stdio.h>
int main()
{
	int x,y,i,j,sum=0,t;
	scanf("%d%d",&x,&y);
	for(i=1;x<=y;i++)
	{
		for(j=2;j<x;j++)
		{
			if(x%j==0)
			{
				t=0;
				break;
			}
			else
				t=x;
		}
		x++;
		sum+=t;
	}
	printf("%d",sum);
	return 0;
}
