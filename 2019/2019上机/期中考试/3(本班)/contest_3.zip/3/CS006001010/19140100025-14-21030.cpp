#include <stdio.h>
int main()
{
	int a,n,s=0,i,j,b[9];
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++)
	{
		b[i]=1;
	}
	if(a==0) printf("0");
	else 
	{
		for(i=0;i<n;i++)
		{
			for(j=0;j<i;j++)
			{
				b[i]=b[i]*10+1;
			}
			
		}
		for(i=0;i<n;i++)
		{
			s+=a*b[i];
			
			
		}

	printf("%d",s);
	}
	return 0;
}
