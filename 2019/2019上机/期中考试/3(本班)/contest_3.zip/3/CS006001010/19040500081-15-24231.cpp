#include<stdio.h>
int main()
{
	int x,y,t,i,j,a,e,s=0;
	scanf("%d %d",&x,&y);
	if(x>y)
	{t=x;x=y;y=t;}
	a=x;
	for(i=0;i<y-x;i++)
	{
		e=0;
		for(j=2;j<a;j++)
		{
			if(a%j==0) {e=1;break;}
		}
		if(e!=1) s=s+a;
		a++;
	}
	printf("%d\n",s);
	return 0;
}