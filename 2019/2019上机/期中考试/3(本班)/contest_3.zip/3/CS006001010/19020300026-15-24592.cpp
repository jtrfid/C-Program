#include<stdio.h>
int main(void)
{
  int x,y,i,m,j,k,p[1000],sum;
  scanf("%d %d",&x,&y);
  if(x<=y)
  {
	k=0;
	for(m=x;m<=y;m++)
	{
	  j=0;
	  for(i=1;i<=m;i++)
	  {
	    if(m%i==0) j++;
	  }
	  if(j==2) 
	  {
	    p[k]=m;
		k++;
	  }
	}
  }
  else if(y<x)
  {
	k=0;
	for(m=y;m<=x;m++)
	{
	  j=0;
	  for(i=1;i<=m;i++)
	  {
	    if(m%i==0) j++;
	  }
	  if(j==2) 
	  {
	    p[k]=m;
		k++;
	  }
	}
  }
  sum=0;
  for(i=0;i<=k-1;i++)
  {
    sum=sum+p[i];
  }
  printf("%d",sum);
  return 0;
}