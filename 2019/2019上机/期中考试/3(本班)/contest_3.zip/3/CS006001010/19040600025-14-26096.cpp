#include<stdio.h>
int main()
{
	int a,n,s=0,i=0,t=1,y=0;
	scanf("%d %d",&a,&n);
	if(a==0)
	printf("%d",s);
	else
{
	while(i<n)
	{
		while(y<i)
		{
			t=t*10;
			y++;
		}
		s=s+(n-i)*a*t;
		i++;
	}
	printf("%d",s);
}	return 0;
}
