#include<stdio.h>
int main()
{
	int a,b,i,n,m=0,s=0;
	scanf("%d%d",&a,&b);
	if(a>b)
	{n=b;
	b=a;
	a=n;}
	for(i=a;i<b+1;i++)
	{m=0;
		for(n=2;n<i;n++)
		if(i%n==0)m=m+1;
	if(m==0)s=s+i;
	}
	printf("%d",s);
	return 0;
}
	
