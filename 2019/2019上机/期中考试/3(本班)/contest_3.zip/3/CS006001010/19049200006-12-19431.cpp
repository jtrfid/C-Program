#include<stdio.h>
int main()
{
  int w,d;
  float c,r=0;
  scanf("%d %d",&w,&d);
  if(w<10) w=10;
  if(d<50) d=50;
  if(250<=d&&d<500) r=0.02;
  if(500<=d&&d<1000) r=0.05;
  if(1000<=d&&d<2000) r=0.08;
  if(d>=2000) r=0.1;


c=0.5*w*d*(1-r);
printf("%.2f",c);
return 0;



}