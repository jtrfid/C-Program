#include <stdio.h>
int main()
{
	int x,y,sum=0,i,j,p[1000],b;
	scanf("%d %d",&x,&y);
	if(x>y)
	{
		b=y;
		y=x;
		x=b;
	}
	for(i=x;i<=y;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
				p[i]=0;
				break;
			}
			else p[i]=i;
		}
		sum+=p[i];
		
		
	}
	printf("%d",sum);
	return 0;
}
