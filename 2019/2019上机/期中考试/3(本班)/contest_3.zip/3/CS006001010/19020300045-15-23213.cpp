#include<stdio.h>
int main(void)
{
	int a,b,i,j,s,m,x,z,n;
	scanf("%d%d",&a,&b);
	s=0;
	if(a<b)
	{
		for(i=a;i<=b;i++)
		{
			for(j=2;j<i;j++)
			{
				m=i%j;
				if(m==0) break;
				if(j==i-1)
				{
					s=s+i;
				}
			}
		}
		printf("%d",s);
	}
	if(a>b)
	{
		for(x=b;x<=a;x++)
		{
			for(z=2;z<x;z++)
			{
				n=x%z;
				if(n==0) break;
				if(z==x-1)
				{
					s=s+x;
				}
			}
		}
		printf("%d",s);
	}
	return 0;
}