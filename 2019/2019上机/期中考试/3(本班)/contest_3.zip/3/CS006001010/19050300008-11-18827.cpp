#include <stdio.h>
int main()
{
	int t,s,h=1000;
	scanf("%d",&t);
    s=1000-10*t*t/2.0;
	if(s>=0)
		printf("%d",s);
	else
		printf("0");
	return 0;

}
