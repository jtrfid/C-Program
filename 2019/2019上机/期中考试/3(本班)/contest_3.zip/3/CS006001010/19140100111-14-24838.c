#include<stdio.h>
int main()
{
	int i,a,b,n,sum;
	

	scanf("%d %d",&a,&n);
	b=a;
	for(i=0,sum=0;i<n;i++)
	{
		sum=sum+a;
		
		a=a*10+b;


	}
	printf("%d",sum);
	return 0;

}