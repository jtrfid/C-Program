#include<stdio.h>
int main()
{
	int a,n,i,j,q,t=0;
	scanf("%d %d",&a,&n);
	if(a==0)
	{
		printf("0");
		return 0;
	}
	for(i=0;i<n;i++)
	{
		for(j=0,q=1;j<=i;q*=10,j++)
		{
			t+=a*q;
		}
	}
	printf("%d",t);
	return 0;
}