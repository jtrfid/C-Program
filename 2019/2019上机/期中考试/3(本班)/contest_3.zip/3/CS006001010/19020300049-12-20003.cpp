#include<stdio.h>
int main( )
{
	int weight,distance;
	float cost;
	scanf("%d%d",&weight,&distance);
	if(weight<10) weight=10;
	if(distance<500)distance=50;

	if (distance<250) cost=float(0.5*weight*distance);
	if(distance==250||distance>250&&distance<500)
	cost=float(0.5*weight*distance)*0.98;
	if(distance==500||distance>500&&distance<1000)
	cost=float(0.5*weight*distance)*0.95;
	if(distance==1000||distance>1000&&distance<2000)
	cost=float(0.5*weight*distance)*0.92;
	if(distance>2000)
	cost=float(0.5*weight*distance)*0.9;
	printf("%.2f",cost);
	return 0;
}
