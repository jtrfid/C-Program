#include<stdio.h>
int main()
 {
   int t,h;
   scanf("%d",&t);
   if (t>14)
	   printf ("0");
   else
   {
	   h=1000-5*t*t;
	   printf("%d",h);
   }
}