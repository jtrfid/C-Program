#include<stdio.h>
int main()
 {
   /*int a,sum=0,dsum=1;
   scanf("%d",&a);
   while (a)
   {
		sum=(a%10)*dsum+sum;
		dsum=dsum*2;
		a=a/10;
   }
   printf("%d",sum);*/
	int x,y,sum=0,i,j,k,mid;
	scanf ("%d%d",&x,&y);
	if (x>y)
	{
		mid=x;
		x=y;
		y=mid;
	}
    for (i=x;i<=y;i++)
	{
		k=0;
		for (j=2;j<=i-1;j++)
		{
			if (i%j==0)
			{
				k=1;
				break;
			}
		}	
		if (k==0)
			sum=sum+i;
	}
	printf("%d",sum);
}
