#include<stdio.h>
int main(void)
{
	int a,n,i;
	int sum=0;
	scanf("%d %d",&a,&n);
	do(i=1,i<=n);
		sum=sum+a^i
	    i++;
	printf("%d",sum);
	return 0;
}