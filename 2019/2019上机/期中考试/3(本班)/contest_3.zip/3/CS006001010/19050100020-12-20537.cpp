#include<stdio.h>
int main(void)
{
    double m=0,w,d;
	scanf("%d %d",&w,&d);
	if(d<=50)
	{
		if(w<=10)
		{
			m=250.00;
		}
		else
		{
			m=25*w;
		}
	}
	else if(d>50&&d<250)
	{
		if(w<=10)
		{
			m=5*d;
		}
		else
		{
			m=1/2*w*d;
		}
	}
	else if(d>=250&&d<500)
	{
		if(w<=10)
		{
			m=5*d*0.98;
		}
		else
		{
			m=1/2*w*d*0.98;
		}
	}
	else if(d>=500&&d<1000)
	{
		if(w<=10)
		{
			m=5*d*0.95;
		}
		else
		{
			m=1/2*w*d*0.95;
		}
	}
	else if(d>=1000&&d<2000)
	{
		if(m<=10)
		{
			m=5*d*0.92;
		}
		else
		{
			m=1/2*w*d*0.92;
		}
	}
	else if(d>=2000)
	{
		if(m<=10)
		{
			m=5*d*0.90;
		}
		else
		{
			m=1/2*w*d*0.90;
		}
	}
	printf("%.2f",m);
	return 0;
}
