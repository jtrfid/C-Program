#include <stdio.h>

int main()
{	
	int i, t, b, k,q;
	int sum = 0;
	char a[30]={0};
	scanf("%s", a);
	for (i=0; i<30; i++)
	{
		if(a[i]!='0' &&a[i]!='1')
		{
			t = i;
			break;
		}
	}
	q = t;
	for (i=0; i<t; i++)
	{

		b=1;
		for (k=0; k<q; k++)
		{
			b =b*2;
		}
		b /= 2;
		q--;		
		if (a[i]=='1')
		sum += 1*b;
		
	}
	printf("%d", sum);
	return 0;
}