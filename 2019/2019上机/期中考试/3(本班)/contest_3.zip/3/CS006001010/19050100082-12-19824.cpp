#include<stdio.h>

int w,d;
int main()
{
	scanf("%d%d",&w,&d);
	if(w<=10)
	{
		if(d<=50) printf("%.2f",0.5*10*50);
		if(d>50&&d<250) printf(".2f",0.5*10*d);
		if(d>=250&&d<500) printf("%.2f",0.5*10*d*0.98);
		if(d>=500&&d<1000) printf("%.2f",0.5*10*d*0.95);
		if(d>=1000&&d<2000) printf("%.2f",0.5*10*d*0.92);
		if(d>=2000) printf("%.2f",0.5*10*d*0.90);
	}
	else
	{
		if(d<=50) printf("%.2f",0.5*w*50);
		if(d>50&&d<250) printf(".2f",0.5*w*d);
		if(d>=250&&d<500) printf("%.2f",0.5*w*d*0.98);
		if(d>=500&&d<1000) printf("%.2f",0.5*w*d*0.95);
		if(d>=1000&&d<2000) printf("%.2f",0.5*w*d*0.92);
		if(d>=2000) printf("%.2f",0.5*w*d*0.90);
	}
	
	return 0;

}