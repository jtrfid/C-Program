#include <math.h>
#include <stdio.h>
int main()
{
	int t,sum=0,i,j,k,m,a,b,c[1000];
	scanf("%d %d",&a,&b);
	m=0;
	if(a>b)
	{
		t=a;a=b;b=t;
	}
	for(i=a;i<=b;i++)
	{
		k=1;
		for(j=2;j<=sqrt(i);j++)
		{
			if(i%j==0)
			{
				k=0;
			}
		}
		if(k!=0)
		{
			c[m]=i;
			m++;
		}
	}
	for(i=0;i<m;i++)
	{
		sum=sum+c[i];
	}
	printf("%d",sum);
	return 0;
}
