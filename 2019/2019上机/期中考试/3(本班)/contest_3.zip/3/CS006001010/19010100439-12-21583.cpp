#include <stdio.h>

int main (void)
{
	int weight,distance;
	float ss,rate,inrate;
	
	scanf ("%d%d",&weight,&distance);
	
	if (weight<10)	weight=10;
	if (distance<50)	distance=50;
	
	if (distance<250)	rate=0;
	else if (distance>=250 && distance<500)	rate=0.02;
	else if (distance>=500 && distance<1000)	rate=0.05;
	else if (distance>=1000 && distance<2000)	rate=0.08;
	else 	rate=0.1;
	
	inrate = (float)1 - rate;
	ss=(float) 0.5*weight*distance*inrate;
	
	printf ("%.2f",ss);
	
	return 0;
	
}
