#include <stdio.h>

int main (void)
{
	int a,n,u,i,m,t,sum;
	int x[10];
	
	scanf ("%d%d",&a,&n);
	
	u=n;
	for (i=1;i<=n;i++)
	{
		x[i]=0;
		m=1;
		for (t=1;t<=u;t++)
		{
			x[i]=a*m;
			m++;
		}
		sum += x[i];
		u--;
	}
	
	printf ("%d",sum);
	return 0;
}
