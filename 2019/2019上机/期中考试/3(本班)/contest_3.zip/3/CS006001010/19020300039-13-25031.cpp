#include<stdio.h>
int maib()
{
    char a;
    int b;
    scanf("%c",&a);
	if(a==101,1){
		b=5;
		printf("%d",b);
	}else {
		b=21;
		printf("%d",b);
	}
	return 0;
}
