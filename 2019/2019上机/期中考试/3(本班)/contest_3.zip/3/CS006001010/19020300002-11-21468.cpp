#include<stdio.h>
#include<math.h>
int main()
{
	int h,t,t1,g=10,H=1000;
	t1=sqrt(H/(2*g));
	scanf("%d",&t);
	if(t<t1)
	{
		h=H-((g*t*t)/2);
		printf("%d\n",h);
	}
	else if(t>=t1)
	{
		printf("0\n");
	}
	return 0;
}
