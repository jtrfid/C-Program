#include<stdio.h>
int main()
{
	int i,n,a[30];
	n=0;
	for(i=1;i<5;i++)
	{
	    scanf("%d",a[i]);
	    if (a[i]!=1&&a[i]!=0)
	    {
		    n--;
	    }
	    n++;
	}
	printf("%d",n);
	return 0;
}
