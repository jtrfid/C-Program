#include<stdio.h>
int main()
{
	int h,t,t1,g=10,H=1000;
	scanf("%d",&t);
	t1=H/(2*g);
	if(t<200)
	{
		if(t<=t1)
		{
		h=H-((g*t)/2);
		printf("%d\n",h);
		}
		else
		{
		printf("0\n");
		}
	}
	else
	{
		printf("error\n");
	}
	return 0;
}

	
