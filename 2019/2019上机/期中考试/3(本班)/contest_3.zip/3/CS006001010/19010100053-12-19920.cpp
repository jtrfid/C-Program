#include<stdio.h>
int main()
{
	int w,d;
	float c,r;
	scanf("%d%d",&w,&d);
	if (d<250) r=0;
	else if (d<500)  r=0.02;
	else if (d<1000) r=0.05;
	else if (d<2000) r=0.08;
	else r=0.1;
	while (w%10!=0)
	{w=w+1;}
	while (d%50!=0)
	{d=d+1;}
	c=0.5*w*d*(1-r);
	printf("%.2f",c);
	return 0;
}