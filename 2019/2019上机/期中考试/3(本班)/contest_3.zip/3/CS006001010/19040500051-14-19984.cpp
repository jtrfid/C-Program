#include<stdio.h>
int main()
{
	int a, b, n, sum=0, i;
	scanf("%d %d", &a, &n);
	b=a;
	for ( i=1; i<n; i++ ) {
		b=a+b*10;
		sum += b;
	}
	printf("%d", sum+a);
	
	return 0;
}
