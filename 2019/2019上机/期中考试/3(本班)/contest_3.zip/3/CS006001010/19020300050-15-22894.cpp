#include<stdio.h>
int main()
{
	int x,y,z=0,i,a=2,b,c=1;
	scanf("%d %d",&x,&y);
	if(x>y)
	i=y;
	else
	i=x;
	while(i<=y||i<=x)
	{
			while(c==1&&a<=i-1)
			{
				b=i%a;
				if(b!=0)
				c=1;
				else
				c=0;
				a++;
			}
			i++;
			a=2;
			if(c!=0)
			z=z+i-1;
			else
			z=z;
	}
	printf("%d",z);
	return 0;
}
