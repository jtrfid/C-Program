#include<stdio.h>
int main()
{
	int w,d;
	double c,r;
	scanf("%d %d",&w,&d);
	if(w<=10)
		w=10;
	if(d<=50)
		d=50;
	if(d<250)
	{
		c=0.5*w*d;
		printf("%.2f\n",c);
	}
	else if(d>=250&&d<500)
	{
		c=0.49*w*d;
		printf("%.2f\n",c);
	}
	else if(d>=500&&d<1000)
	{
		c=0.475*w*d;
		printf("%.2f\n",c);
	}
	else if(d>=1000&&d<2000)
	{
		c=0.46*w*d;
		printf("%.2f\n",c);
	}
	else if(d>=2000)
	{
		c=0.45*w*d;
		printf("%.2f\n",c);
	}
	return 0;
}