#include<stdio.h>
int main()
{
	int l,a,j,i,x,y,sum=0,temp;
	scanf("%d%d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(j=1;j<i;j++)
		{
			for(l=1;l<i;l++)
			{
				temp=l*j;
				if(temp==i){a=0;}
				else {a=i;}
			}
		}
		sum=sum+a;
	}
	printf("%d",sum);
	return 0;
}



