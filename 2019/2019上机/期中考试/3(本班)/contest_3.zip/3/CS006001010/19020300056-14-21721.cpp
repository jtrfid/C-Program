#include <stdio.h>
int main()
{
	int a,n,s=0;
	scanf("%d %d",&a,&n);
	if(a==0)
	{
		s=0;
		printf("%d",s);
	}
	else if(n==1)
	{
			s=s+n*a;
            printf("%d",s);
	}
	else if(n==2)
	{
			s=s+n*a+(n-1)*a*10;
            printf("%d",s);
	}
	else if(n==3)
	{
			s=s+n*a+(n-1)*a*10+(n-2)*a*100;
            printf("%d",s);
	}
		else if(n==4)
	{
			s=s+n*a+(n-1)*a*10+(n-2)*a*100+(n-3)*a*1000;
            printf("%d",s);
	}
		else if(n==5)
	{
			s=s+n*a+(n-1)*a*10+(n-2)*a*100+(n-3)*a*1000+(n-4)*a*10000;
            printf("%d",s);
	}
		else if(n==6)
	{
			s=s+n*a+(n-1)*a*10+(n-2)*a*100+(n-3)*a*1000+(n-4)*a*10000+(n-5)*a*100000;
            printf("%d",s);
	}
		else if(n==7)
	{
			s=s+n*a+(n-1)*a*10+(n-2)*a*100+(n-3)*a*1000+(n-4)*a*10000+(n-5)*a*100000+(n-6)*a*1000000;
            printf("%d",s);
	}
		else if(n==8)
	{
			s=s+n*a+(n-1)*a*10+(n-2)*a*100+(n-3)*a*1000+(n-4)*a*10000+(n-5)*a*100000+(n-6)*a*1000000+(n-7)*a*10000000;
            printf("%d",s);
	}
			else if(n==9)
	{
			s=s+n*a+(n-1)*a*10+(n-2)*a*100+(n-3)*a*1000+(n-4)*a*10000+(n-5)*a*100000+(n-6)*a*1000000+(n-7)*a*10000000+(n-8)*a*100000000;
            printf("%d",s);
	}
	return 0;
}


			

