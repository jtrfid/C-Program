#include <stdio.h>
int main()
{
	int x,y,i,j,s;
	scanf("%d%d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(j=2;j<y;j++)
		{
			if(i/j==0)
				break;
			if(j>=y)
			{
				s=s+i;
			}
		}
	}
	printf("%d",s);
	return 0;
}