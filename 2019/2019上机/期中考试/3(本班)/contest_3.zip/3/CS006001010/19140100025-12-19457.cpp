#include <stdio.h>
int main()
{
	double w,d,p=0.5,cost;
	scanf("%lf %lf",&w,&d);
	if(w<=10) w=10;
	if(d<=50)
	{
		d=50;
		cost=p*w*d*(1);
		printf("%.2lf",cost);
	}
	else if(d>50&&d<250)
	{
		cost=p*w*d*(1);
		printf("%.2lf",cost);
	}
	else if(d>=250&&d<500)
	{
		cost=p*w*d*(0.98);
		printf("%.2lf",cost);
	}
	else if(d>=500&&d<1000)
	{
		cost=p*w*d*(0.95);
		printf("%.2lf",cost);
		
	}
	else if(d>=1000&&d<2000)
	{
		cost=p*w*d*(0.92);
		printf("%.2lf",cost);
		
	}
	else 
	{
		cost=p*w*d*(0.9);
		printf("%.2lf",cost);	
	}
	return 0;
}
