#include<stdio.h>
int main()
{
	int zhishu(int a);
	int x,y,i,j,t=0;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		if(zhishu(i)==1)
		{
			t+=i;
		}
	}
	printf("%d",t);
	return 0;
}
int zhishu(int a)
{
	int i;
	if(a==2) return(1);
	if(a>2)
	{
		for(i=2;i<a;i++)
		{
			if(a%i==0) break;
		}
		if(i<a) return(0);
		else return(1);
	}
}