#include<stdio.h>
int main()
{
	double cost,p=0.5,weight,d,rate;
	scanf("%d %d",&weight,&d);
    {
    if(d<250);
    cost = p*weight*d;
    if(d>=250&&d<500);
    cost = p*weight*d*(1-0.02);
    if(d>=500&&d<1000);
    cost = p*weight*d*(1-0.05);
    if(d>=1000&&d<2000);
	cost = p*weight*d*(1-0.08);
    if(d>=2000);
    cost = p*weight*d*(1-0.1);
    }
    printf("%.2d",cost);
    return 0;
}
