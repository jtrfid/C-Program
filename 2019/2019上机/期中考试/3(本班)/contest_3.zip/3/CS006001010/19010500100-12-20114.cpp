#include<stdio.h>
int main(void)
{
	int w,d;
	float cost,rate;
	scanf("%d%d",&w,&d);
	if(w<=10) w=10;
	if(d<=50) d=50;
	else
	{
	    if(d<250) rate=0;
	    else if(d>=250&d<500) rate=0.02;
	    else if(d>=500&d<1000) rate=0.05;
	    else if(d>=1000&d<=2000) rate=0.08;
	    else rate=0.1;
    }
	cost=(float)(0.5*w*d*(1-rate));
	printf("%.2f",cost);
	return 0;
}
