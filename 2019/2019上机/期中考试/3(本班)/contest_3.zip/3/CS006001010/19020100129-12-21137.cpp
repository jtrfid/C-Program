
#include<stdio.h>

int main(void)
{
	float w,d,cost;
	scanf("%d %d",&w,&d);
	if(d<250)
	{
		if(d<=50)
		{
			cost=0.5*w*50;
		}
		else
		{
			cost=0.5*w*d;
		}
	}
	if(d<=500&&d>=250)
	{
		cost=0.5*w*d*0.98;
	}
	if(d>=500&&d<1000)
	{
		cost=0.5*w*d*0.95;
	}
	if(d>=1000&&d<2000)
	{
		cost=0.5*w*d*0.92;
	}
	if(d>=2000)
	{
		cost=0.5*w*d*0.9;
	}
	printf("cost=%.2f",cost);
	return 0;
}