#include<stdio.h>
#define p 0.5
int main()
 {
   int w,d;float cost;
   scanf("%d%d",&w,&d);
   if (w<10)
	   w=10;
   if (d<50)
	   d=50;
   if (d<250)
	   cost=p*d*w;
   else if (d<500)
	   cost=p*d*w*0.98;
   else if (d<1000)
	   cost=p*d*w*0.95;
   else if (d<2000)
	   cost=p*d*w*0.92;
   else
	   cost=p*d*w*0.9;
   printf ("%.2f",cost);
}