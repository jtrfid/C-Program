#include<stdio.h>
int main()
{
	int t,h;
	scanf("%d",&t);
	h=1000-5*t*t;
	if(h>=0)printf("%d",h);
		else printf("0");
	return 0;
}