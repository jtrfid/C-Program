#include<stdio.h>
#include<string.h>
int main()
{
	int k,i,t=0,q;
	char str[30];
	scanf("%s",str);
	for(i=0;;i++)
	{
		if(str[i]!='0'&&str[i]!='1')
		{
			k=i;
			break;
		}
	}
	for(i=k-1,q=1;i>=0;q*=2,i--)
	{
		t+=(str[i]-48)*q;
	}
	printf("%d",t);
	return 0;
}