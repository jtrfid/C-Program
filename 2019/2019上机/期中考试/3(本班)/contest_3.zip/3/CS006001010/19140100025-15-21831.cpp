#include <stdio.h>
int main()
{
	int x,y,sum=0,i,j,p[1000];
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
				p[i]=0;
				break;
			}
			else p[i]=i;
		}
		sum+=p[i];
		
		
	}
	printf("%d",sum);
	return 0;
}
