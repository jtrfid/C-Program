#include <stdio.h>
int main()
{
    int a,n,s=0,i=0,h=1,j;
	int t;
	scanf("%d%d",&a,&n);
	t=n;
	while(n>0)
	{
	    n--;
		i++;
	}
	for(i=i;i>0;i--)
	{
        for(j=i;j>0;j--)
		{
			h=h*10;
			s=s+2*h;
		}
	}
	printf("%d",s);
	return 0;
}