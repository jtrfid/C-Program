#include<stdio.h>
int main( )
{
	int i,q=0,p=1;
	char a[30]={'0'};
	for(i=0;i<30;i++)
	{
		
		scanf("%c",&a[i]);
		if (a[i]!='0'&&a[i]!='1')  break;
	}
	i=0;
	for(i=0;i<30;i++)
	{
	   q=q+p*a[i];
	   p=2*p;
	}
	printf("%d",q);
	return 0;
}
