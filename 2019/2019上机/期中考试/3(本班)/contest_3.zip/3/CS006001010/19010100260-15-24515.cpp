#include<stdio.h>
int main()
{
	int m,n,i,x,y,a=0,c,q,w;
	scanf("%d %d",&q,&w);
	if(q<w)
	{
	x=q;
	y=w;
    }
    else 
	{
    x=w;
    y=q;
    }
	for(i=x;i<=y;i++)
	{
		n=i;
		c=i;
		for(m=2;m<i;m++)
		{
		if(i%m==0)
		c=0;
	    }
	    if(c==n)
	    a=a+i;
	}
	printf("%d",a);
	return 0;
}
