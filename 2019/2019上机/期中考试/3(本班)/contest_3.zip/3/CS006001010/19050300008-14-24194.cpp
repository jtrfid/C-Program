#include <stdio.h>
int main()
{
	int a,n,i,s=0,x=0;
	scanf("%d%d",&a,&n);
    for(i=1;i<=n;i++)
	{
		x=a+x;
		a=a*10;
		s=x+s;
	}
	printf("%d",s);
	return 0;
}