#include<stdio.h>
int main()
{
	int x,y;
scanf("%d %d",&x,&y);
	int i,j=2;
	int cnt=0;
	for(i=x;i<=y;i++)
	{int n=0;
		for(j=2;j<i;j++)
		{
		if ((i%j)!=0)
		n++;
	    }
	    
		if (n==(i-2))
	cnt=cnt+i;
	}
        printf("%d",cnt);
      return 0;
}
