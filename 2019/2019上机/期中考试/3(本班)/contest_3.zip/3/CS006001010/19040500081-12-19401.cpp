#include<stdio.h>
int main()
{
	int w,d;
	float c,r;
	scanf("%d %d",&w,&d);
	if(d<250) r=0;
	if(d<500&&d>=250) r=0.02;
	if(d<1000&&d>=500) r=0.05;
	if(d<2000&&d>=1000) r=0.08;
	if(d>=2000) r=0.10;
	if(w<10) w=10;
	if(d<50) d=50;
	c=0.5*w*d*(1-r);
	printf("%.2f\n",c);
	return 0;
}