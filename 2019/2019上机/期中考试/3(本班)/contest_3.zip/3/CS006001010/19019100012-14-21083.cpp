#include <stdio.h>
int main()
{
	int sn=0,a,n,b[11],i,j;
	scanf("%d %d",&a,&n);
	if(a==0)
	{
		sn=0;
	}
	else
	{
		b[0]=0;
		for(i=1;i<n+1;i++)
		{
			b[i]=b[i-1]*10+a;
		}
		for(j=0;j<n+1;j++)
		{
			sn=sn+b[j];
		}
	}
	printf("%d",sn);
	
	
	return 0;
}
