#include<stdio.h>
int main()
{
	char a[30];
	int i,j=0,h=0,k,d[30],e,f;
	for(i=0; ;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]!='1'&&a[i]!='0')break;
		else 
		{
			j++;
			if(a[i]=='1') d[i]=1;
			else d[i]=0;
		}
	}
	e=j;
	for(k=0;k<e;k++)
	{

		for(i=0;i<j;i++)
		{
			d[k]=d[k]*2;
		}
		h=h+d[k];
		j--;
	}
	if(a[e]=='1') h++;
	f=h/2;
	printf("%d\n",f);
	return 0;
}