#include<stdio.h>
int main()
{   char a[30],b;
int i,sum,n,c;
for(i=0;i<30;i++){
	scanf("%c",&a[i]);
	if(a[i]==0&&a[i]==1){
		n=i+1;
	}else {
		break;
	}
}
b=0;
for(i=n-2;i>=0;i--,b++){
	switch(b){
	
	case 0:c=1;
	case 1:c=2;
	case 2:c=4;
	case 3:c=8;
	case 4:c=16;
	case 5:c=32;
	case 6:c=64;
	case 7:c=128;
	case 8:c=256;}
	sum=a[i]*c+sum;
	
}
    scanf("%d",sum);
	return 0;
}
