#include <stdio.h>
int main ()
{
	int a,b,s=0,i=0;
	scanf("%d%d",&a,&b);
	int c;
	c=a;
	while (i<(b-a+1)) 
	{   int j=2;
		while (c%j!=0&&j<c)
			{j=j+1;}
		if (   j==c   ) s=s+c;
		c=c+1;
		i=i+1;}
	printf("%d",s);
	return 0;
}