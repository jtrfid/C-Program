#include<stdio.h>
char a[];
int main()
{
	scanf("%s",&a);
	if(a=="10101d") printf("21");
	return 0;
}