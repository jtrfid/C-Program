#include <stdio.h>
int main()
{
	int h,t;
	scanf("%d",&t);
	if(t>=100)
	{
		h=0;
		printf("%d",h);
	}
	else
	{
		h=1000-(5*t*t);
		printf("%d",h);
	}
	return 0;
}
