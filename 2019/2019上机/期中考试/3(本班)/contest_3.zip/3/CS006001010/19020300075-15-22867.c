#include<stdio.h>
int main()
{
	int x,y,i,n,p,sum=0;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++)
	{
		for(n=2;n<x;n++)
		{
			p=0;
			if(i%n==0)
			{
				p=1;break;
			}
		}
		if(p==0)
		{
			sum+=i;
		}
	}
	printf("%d",sum);
	return 0;
}
