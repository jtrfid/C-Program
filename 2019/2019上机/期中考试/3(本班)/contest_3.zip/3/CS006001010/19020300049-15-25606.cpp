#include<stdio.h>
int main( )
{
	int x,y,i,j,sum=0,a=1,q=1;
	scanf("%d%d",&x,&y);
	for(i=x;i<y;i++)
	{
		for(j=2;j<i;j++)
		{
			a=i%j;
			q=q*a;			
		}
		if(q) sum=sum+i;
	}
	printf("%d",sum);
	return 0;
}
