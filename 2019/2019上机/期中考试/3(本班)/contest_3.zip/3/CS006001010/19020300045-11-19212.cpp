#include<stdio.h>
int main(void)
{
	int H,t,h;
	scanf("%d",&t);
	H=1000;
	if(t<100)
	{
		h=H-5*t*t;
		printf("%d",h);
	}
	else printf("0");
	return 0;
}