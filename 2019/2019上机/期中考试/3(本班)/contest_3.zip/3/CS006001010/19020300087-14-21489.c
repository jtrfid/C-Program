#include <stdio.h>

int main()
{
	int a, n, i, j, k;
	int sum =0;
	int s=0;
	int b=1;
	scanf("%d %d", &a, &n);
	for (j=1; j<=n; j++)
	{

		sum=0;
		for (i=0; i<j; i++)
		{
			b=1;
			for (k=0; k<=i; k++)
			{
				b *=10;
			}
			sum += a*b/10;
		}
		s+=sum;		
	}
	printf("%d", s);
		
		
	return 0;
}