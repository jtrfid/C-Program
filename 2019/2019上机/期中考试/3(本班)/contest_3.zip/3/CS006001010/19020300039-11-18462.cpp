#include<stdio.h>
int main()
{   int t,h,H;
scanf("%d",&t);
    h=5*t*t;
    H=1000-h;
    if(H<=0){
    	H=0;
    }
    printf("%d",H);
	return 0;
}
