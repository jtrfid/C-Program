#include<stdio.h>
int main()
{
 int x,y,i=2,sum=0,m;
 scanf("%d %d",&x,&y);
 for(x;x<y+1;x++)
 {
    m=x;
	 for(i=2;i<m;i++)
   {
	   if(m%i==0)
	   {
	     m=0;
		 break;
	   }
   }

   if(m!=0)
   sum=sum+m;
 }
 printf("%d",sum);
 return 0;

}