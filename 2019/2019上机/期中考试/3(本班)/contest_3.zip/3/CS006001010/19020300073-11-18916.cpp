#include<stdio.h>
int main()
{
	int t,b,c;
	scanf("%d",&t);
	if(t>14)
		printf("0");
	else
	{b=1000-5*t*t;
	printf("%d",b);}
	return 0;
}