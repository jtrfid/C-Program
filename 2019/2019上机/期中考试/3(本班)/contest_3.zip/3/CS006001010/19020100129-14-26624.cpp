
#include<stdio.h>
int main(void)
{
	int a,n,i;
	float Sn=0;
	scanf("%d %d",&a,&n);

	if(a=0)
	{
		Sn=0;
		printf("%d",Sn);
	}

	else
	{
		for(i=1,i<=n;i++;)
		{
			Sn=a+Sn;
		    a=a*10+a;
		}
	}
	printf("%d",Sn);
	return 0;
}