#include <stdio.h>
int main()
{
	int x,y,j,sum=0,t;
	scanf("%d%d",&x,&y);
	while(x<=y)
	{
		for(j=2;j<x;j++)
		{
			if(x%j==0)
			{
				t=0;
				break;
			}
			else
				t=x;
		}
		sum+=t;
		x++;
	}
	printf("%d",sum);
	return 0;
}
