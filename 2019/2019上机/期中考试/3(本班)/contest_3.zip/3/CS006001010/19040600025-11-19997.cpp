#include<stdio.h>
int main()
{
	int x,t,h,H=1000,g=10;
	scanf("%d",&t);
	h=0.5*g*t*t;
	if(h>=H)
		printf("0");
	else	
	x=H-h;
	printf("%d",x);
	return 0;
}
