#include<stdio.h>
int main()
{
	int a,n,S,i,N;
	scanf("%d %d",&a,&n);
	N=10;
	for(i=1;i<=n;i++)
	{
		N=N*10;
	}
	S=a*(((N-10)/81)-(n/9));
	printf("%d\n",S);
	return 0;
}