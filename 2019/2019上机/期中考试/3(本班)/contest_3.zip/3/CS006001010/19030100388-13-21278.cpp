#include <stdio.h>
int main()
{
	int i=0,j=0,s=0,x=1,a,b[10]={0};
	scanf("%d",&a);
	while(a)
	{
	b[i]=a%10;
	a=a/10,i++;
	}
	for(j=0;j<i;j++) s=s+b[j]*x,x=x*2;
	printf("%d\n",s);
	return 0;
}
