#include<stdio.h>
int main()
{   int a,n,sum=0,b=0,i;
    scanf("%d%d",&a,&n);
    for(i=0;i<n;i++){
    	switch(i){
    	case 0:b=b+a;break;
    	case 1:b=b+a*10;break;
    	case 2:b=b+a*100;break;
    	case 3:b=b+a*1000;break;
    	case 4:b=b+a*10000;break;
    	case 5:b=b+a*100000;break;
    	case 6:b=b+a*1000000;break;
    	case 7:b=b+a*10000000;break;
    	case 8:b=b+a*100000000;break;
    	
    }
    	sum=sum+b;
    }
    printf("%d",sum);
	return 0;
}
