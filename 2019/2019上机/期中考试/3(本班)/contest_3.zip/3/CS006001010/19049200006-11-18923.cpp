#include<stdio.h>
int main()
{
 int x,t;
 scanf("%d",&t);
	 x=1000-(0.5*10*t*t);
	 if(x<0) x=0;
	 printf("%d",x);
	 return 0;



}