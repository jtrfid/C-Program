#include<stdio.h>
int main()
{
	int w,d;
	float c,p=0.5;
	scanf("%d%d",&w,&d);
	if(d<250)
	{
	    c=p*w*d;
	}
	else if(d>=250&&d<500)
	{
		c=p*w*d*0.98;
	}
	else if(d>=500&&d<1000)
	{
		c=p*w*d*0.95;
	}
	else if(d>=1000&&d<2000)
	{
		c=p*w*d*0.92;
	}
	else if(d>=2000)
	{
		c=p*w*d*0.9;
	}
    printf("%.2f",c);
	return 0;
}



