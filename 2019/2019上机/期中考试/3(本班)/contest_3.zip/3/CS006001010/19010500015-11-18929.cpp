#include<stdio.h>
int main()
{
	int h,s;
	scanf("%d",&s);
	if(s<=14)
	{h=1000-5*s*s;}
	if(s>14)
	{h=0;}
	printf("%d",h);
	return 0;
}