#include<stdio.h>
int main(void)
{
  int h,t;
  scanf("%d",&t);
  h=(int)1000-0.5*10*t*t;
  if(h>0) printf("%d",h);
  else printf("%d",0);
  return 0;
}