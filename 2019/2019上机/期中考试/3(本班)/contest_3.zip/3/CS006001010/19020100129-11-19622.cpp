
#include<stdio.h>

int main(void)
{
	int t,h;
	scanf("%d",&t);
	if(t<100)
	{
	h=1000-(10*t*t)/2;
	printf("%d",h);
	}
	else
	{
		printf("0");
	}
	return 0;
}
