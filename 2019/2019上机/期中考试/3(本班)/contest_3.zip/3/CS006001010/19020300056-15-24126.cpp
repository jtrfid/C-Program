#include <stdio.h>
int main()
{
	int x,y,sum=0,i,j=0,q;
	scanf("%d %d",&x,&y);
	for(i=2;i<=(x/2);i++,j=0)
	{
		if(x%i==0)
		{
			j++;
		}
	}
	if(j==0)
	{
		sum=sum+x;
	}
	for(i=2;i<=(y/2);i++,j=0)
	{
		if(y%i==0)
		{
			j++;
		}
	}
	if(j==0)
	{
		sum=sum+y;
	}
	for(q=1;(x+q)<y;q++)
	{
		for(i=2;i<=((x+q)/2);i++,j=0)
		{
			if((x+q)%i==0)
			{
				j++;
			}
		}
		
	}
	if(j==0)
	{
		sum=sum+(x+q);
	}
	printf("%d",sum);
	return 0;
}
	







 