#include<stdio.h>
int main(void)
{
	int a,n,b=0,i,c;
	scanf("%d %d",&a,&n);
	c=a;
	if(a==0)
	{
		printf("0");
	}
	else
	{
		for(i=0;i<n;i++)
		{
			b=b+c;
			c=c*10+a;
		}
		printf("%d",b);
	}
	return 0;
}