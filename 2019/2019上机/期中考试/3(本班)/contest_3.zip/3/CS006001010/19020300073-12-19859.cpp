#include<stdio.h>
int main()
{
	float w,d,c;
	scanf("%f %f",&w,&d);
	if(w<50)
	{if(d<50)
		c=0.5*50*50;
	else if(d>=50&&d<250)
		c=0.5*50*d;
	else if(d>=250&&d<500)
		c=0.5*50*d*0.98;
	else if(d>=500&&d<1000)
		c=0.5*50*d*0.95;
	else if(d>=1000&&d<2000)
		c=0.5*50*d*0.92;
	else c=0.5*50*d*0.9;
	}
	else
	{
	if(d<50)
		c=0.5*w*50;
	else if(d>=50&&d<250)
		c=0.5*w*d;
	else if(d>=250&&d<500)
		c=0.5*w*d*0.98;
	else if(d>=500&&d<1000)
		c=0.5*w*d*0.95;
	else if(d>=1000&&d<2000)
		c=0.5*w*d*0.92;
	else c=0.5*w*d*0.9;
	}
	printf("%.2f",c);
	return 0;
}