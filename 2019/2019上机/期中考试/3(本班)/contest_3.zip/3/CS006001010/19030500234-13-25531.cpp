#include<stdio.h>
int main()
{
	char a[30];
	int sum=0,n,i,j,k,b,c[30];
	scanf("%s",a);
	for(i=0;i<30;)
	{
		if(a[i]=='1'||a[i]=='0')
			i++;
		else break;
	}
	for(i=i-1,j=0;i>=0;i--,j++)
	{
		if(a[i]=='1')
			c[j]=1;
		else c[j]=0;
	}
	k=j;
	for(j=0,b=1;j<k;j++)
	{
		n=c[j]*b;
		sum=sum+n;
		b=b*2;
	}
	printf("%d\n",sum);
	return 0;
}