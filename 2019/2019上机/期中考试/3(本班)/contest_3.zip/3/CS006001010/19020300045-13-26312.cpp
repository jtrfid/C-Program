#include<stdio.h>
int main(void)
{
	char n[31];
	int x,j,p,i;
	x=0;
	for(i=0;n[i]!=0&&n[i]!=1;i++)
	{
		scanf("%c",n[i]);
	}
	for(j=0;j<=i;j++)
	{
		if(n[j]==0) x=0;
		if(n[j]==1) 
			for(p=1;p<j;p++)
			{
				x=x+2*10;
			}
	}
	printf("%d",x);
	return 0;
}