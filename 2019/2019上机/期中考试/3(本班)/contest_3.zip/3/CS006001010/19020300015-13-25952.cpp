#include <stdio.h>
int main(void)
{
	int a=0,i=1,b=10,c=0,d[300],t=0,q=1;
	scanf("%d",&a);
	do
	{
		i=a/b;
		b=b*10;
		c=c+1;
	}
	while(i!=0);
	b=10;
	for(i=0;i<c;i++)
	{
		d[i]=a%10;
		a=a/10;
	}
	for(i=0;i<c;i++)
	{
		t=t+d[i]*q;
		q=q*2;
	}
	printf("%d",-t);
	return 0;
}