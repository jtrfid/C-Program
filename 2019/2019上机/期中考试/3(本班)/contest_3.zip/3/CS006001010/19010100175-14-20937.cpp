#include<stdio.h>
void main()
{
   int a,n,i,b[1000],s;
   scanf("%d %d",&a,&n);
   if(a==0) printf("0");
   else
   {
	   b[0]=a;
	   s=a;
	   for(i=1;i<n;i++)
	   {
           b[i]=10*b[i-1]+a;
           s=s+b[i];
	   }
	   printf("%d",s);
   }
}