#include <stdio.h>
int main()
{
    int w,d,g;
	double p=0.5;
	double c;
	scanf("%d%d",&w,&d);
    if(w<10)
		w=10;
	if(d<50)
		d=50;
	g=p*d*w;
	if(d<250)
		c=g;
	else if(d<500)
		c=0.98*g;
	else if(d<1000)
		c=0.95*g;
	else if(d<2000)
		c=0.92*g;
	else c=0.9*g;
	printf("%.2f",c);
	return 0;
}