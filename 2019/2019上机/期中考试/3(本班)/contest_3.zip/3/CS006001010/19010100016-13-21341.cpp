#include<stdio.h>
int main()
{
	char a[30];
	int sum=0,d=1,i;
	scanf("%s",&a);
	for(i=0;;i=i+1)
	{if(i!=0)d=2*d;
	if(a[i]=='0'&&(a[i+1]=='1'||a[i-1]=='1'))sum+=0;
	else if(a[i]=='1'&&(a[i+1]=='0'||a[i-1]=='0'))sum+=d;
	else break;
	}
	printf("%d",sum);
	return 0;
}