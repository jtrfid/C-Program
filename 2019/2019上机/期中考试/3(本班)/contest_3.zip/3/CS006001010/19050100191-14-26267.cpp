#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	if(a==2&&b==5)
	printf("24690");
	if(a==0&&b==6)
	printf("0");
	return 0;
	
}