#include<stdio.h>
int main()
{
	int a,n,s,b,i;
	scanf("%d%d",&a,&n);
	s=0;
	b=1;
	for (i=n;i>=1;i--)
	{
		s=s+i*b;
		b=b*10;
	}
	s=s*a;
	printf("%d",s);
	return 0;
}
