#include<stdio.h>
int main()
{
	int x,y,stmp,i,m=0,s=0,j;
	scanf("%d %d",&x,&y);
	if(y<x)
	{
		stmp=x;
		x=y;
		y=stmp;
	}
	for(i=x;i<=y;i++)
	{
		for(j=2;j<i;j++)
		{if(i%j==0)
		m++;}
		if(m==0)
		{
			s+=i;
		}
		m=0;
	}
	printf("%d",s);
	return 0;
}


