#include<stdio.h>
int main()
{
	int t,x,y,n,da,xiao,i;
	int m=1;
	int sum=0;
	scanf("%d %d",&x,&y);
	if(x>y)
	{
		t=y;
		y=x;
		x=y;
	}
	for(n=x;n<=y;n++)
	{
		for(i=2;i<n;i++)
		{
			if(n%i==0)
			{
				m=0;
				break;
			}
		}

		if(n==i)
		sum=sum+n;
	}
	printf("%d",sum);
	return 0;
}
