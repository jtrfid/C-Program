#include<stdio.h>
#include<math.h>
int mian(void)
{
	int w,d;
	double m=0.00;
	scanf("%d %d",&w,&d);
	if(w<=10)
	{
		if(d<=50)
		{
			m=250.00;
		}
		else if(d>50&&d<250)
		{
			m=5*(double)d;
		}
		else if(d>=250&&d<500)
		{
			m=5*(double)d*0.98;
		}
		else if(d>=500&&d<1000)
		{
			m=5*(double)d*0.95;
		}
		else if(d>=1000&&d<2000)
		{
			m=5*(double)d*0.92;
		}
		else if(d>=2000)
		{
			m=5*(double)d*0.90;
		}
	}
	else
	{
		if(d<=50)
		{
			m=25*(double)w;
		}
		else if(d>50&&d<250)
		{
			m=1/2*(double)w*(double)d;
		}
		else if(d>=250&&d<500)
		{
			m=1/2*(double)w*(double)d*0.98;
		}
		else if(d>=500&&d<1000)
		{
			m=1/2*(double)w*(double)d*0.95;
		}
		else if(d>=1000&&d<2000)
		{
			m=1/2*(double)w*(double)d*0.92;
		}
		else if(d>=2000)
		{
			m=1/2*(double)w*(double)d*0.90;
		}
	}
	printf("%.2f",m);
	return 0;
}

