#include <stdio.h>
int main()
{
	int t,s;
	scanf("%d",&t);
	s=1000-5*t*t;
	if(s>0)
	{
		printf("%d",s);
	}
	else
	{
		printf("0");
	}
	return 0;
}