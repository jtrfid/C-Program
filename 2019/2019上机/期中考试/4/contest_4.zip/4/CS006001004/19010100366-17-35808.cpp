#include<stdio.h>
int main()
{
	int x,t,y,i;
	scanf("%d%d",&x,&t);
	if (t>20)
	{
		t=20;
	}
	if(x<50000)
	{
		y=x;
		for(i=0;i<t;i++)
		{
			y=y*1.02;
		}
		printf("%d",y);
	}
	else if(x>=50000&&x<200000)
	{
		y=x;
		for(i=0;i<t;i++)
		{
			y=y*1.03;
		}
		printf("%d",y);
	}
	else if(x>=200000&&x<500000)
	{
		y=x;
		for(i=0;i<t;i++)
		{
			y=y*1.04;
		}
		printf("%d",y);
	}
	else if(x>=500000&&x<2000000)
	{
		y=x;
		for(i=0;i<t;i++)
		{
			y=y*1.05;
		}
		printf("%d",y);
	}
	else if(x>=2000000)
	{
		y=x;
		for(i=0;i<t;i++)
		{
			y=y*1.06;
		}
		printf("%d",y);
	}
}
