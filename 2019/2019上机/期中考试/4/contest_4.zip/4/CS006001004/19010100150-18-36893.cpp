#include<stdio.h>
int main()
{int sum,m,n,i,t;
sum==0;
i==0;
scanf("%d %d",&m,&n);
do{sum==sum+(m+i)*(m+i);
i==i+1;
}while(i<=n-m);
printf("%d\n",sum);
}


