#include<stdio.h>
int main()
{
	int x,t,z,i,sum;
	scanf("%d %d",&x,&t);
	sum=x;
	if (t>20)
	{
		t=20;
	}
	if (x<50000);
	{
		z=102;
	}
    if(x>=50000&&x<200000)
	{
		z=103;
	}
    if(x>=200000&&x<500000)
	{
		z=104;
	}
    if(x>=500000&&x<2000000)
	{
		z=105;
	}
    if(x>=2000000)
	{
		z=106;
	}
	for(i=0;i<t;i++)
	{
		sum=sum/100*z;
	}
	printf("%d",sum);
}
