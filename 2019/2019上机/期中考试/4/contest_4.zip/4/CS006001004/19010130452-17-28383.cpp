#include<stdio.h>
int main()
{
	int x,t,y;
	scanf("%d%d",&x,&t);
	if(0<t&&t<=20)
	{
		if(x<50000)
		y=x+x*0.02;
		else if(50000<=x&&x<200000)
		y=x+x*0.03;
		else if(200000<=x&&x<500000)
		y=x+x*0.04;
		else if(500000<=x&&x<2000000)
		y=x+x*0.05;
		else
		y=x+x*0.06;
	}
	else
	y=x;
	printf("%d",y);
	return 0;
}
