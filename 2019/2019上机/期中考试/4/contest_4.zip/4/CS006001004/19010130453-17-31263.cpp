#include<stdio.h>
int	main()
{
	int	x,t,y;
	scanf("%d %d ",x,t);
	if(x<50000)
	{
		y=x*0.02*t;
		printf("%d",y);
	}
	if(x>=50000&&x<200000)
	{
		y=x*0.03*t;
		printf("%d",y);
	}
	if(x>=200000&&x<500000)
	{
		y=x*0.04*t;
		printf("%d",y);
	}
	if(x>=500000&&x<2000000)
	{
		y=x*0.05*t;
		printf("%d",y);
	}
	if(x>=2000000)
	{
		y=x*0.06*t;
		printf("%d",y);
	}
	return 0;
}
