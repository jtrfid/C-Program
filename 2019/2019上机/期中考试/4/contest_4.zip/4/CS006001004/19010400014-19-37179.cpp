#include <stdio.h>
int main ()
{
	int n,x,i,sum=0,t;
	scanf("%d %d",&n,&x);
	for (i=1;i<=n;i++)
	{
		t=x%10;
		x=x/10;
		if (t==0)
		{
			sum+=0;
		}
		else if (t==1)
		{
		sum+=(2^(i));
	    }
		
	
	}
	printf("%d",sum);
	
} 
