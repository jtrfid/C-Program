#include<stdio.h>
int main()
{int sum,m,n,i,t;
sum==0;
int a[1000];
scanf("%d,%d",&m,&n);
for(i=0;i<1000;i++)
a[i]==m+i;
do{for(t=0;t<=n-m;t++)
sum==sum+a[t]*a[t];}
while(t<=n-m);
printf("%d\n",sum);
}


