#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,i,a=0,t;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++)
	{	
		t=m%10;
		a+=t*pow(2,i);
		m=m/10;
	}
	printf("%d",a);
	return 0;
	
	
	
}
