#include<stdio.h>
#include<math.h>
int main()
{
	int X,t;
	long double x;
	float m;
	scanf("%d %d",&X,&t);
	x=X/1000;
	if(x<50)
	m=0.02;
	else if(x>=50&&x<200)
	m=0.03;
	else if(x>=200&&x<500)
	m=0.04;
	else if(x>=500&&x<=2000)
	m=0.05;
	else if(m>2000)
	m=0.06;
	int i;
	long double a;
	float M;
	M=0;
	a=1;
	if(t<=20)
	{
	for(i=1;i<=t;i++)
	{
        x=x*(1+m);
	}}
	else
	x=x*pow((1+m),20);
	M=x*1000;
	printf("%.0f",M);
	return 0;	
}
