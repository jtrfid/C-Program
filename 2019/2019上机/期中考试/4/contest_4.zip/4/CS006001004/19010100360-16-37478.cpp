#include<stdio.h>
#include<math.h>
int main()
{

	float x,y,z,i,g,Q;
	scanf("%d",&x);
	if(x>=(-100)&&x<=12)
	{
	    printf("no");
	}	
	else{
	
		g=x*x*x;
	    z=(2019-g+x);
		Q=sqrt(z);

	}	
	return 0;
} 
