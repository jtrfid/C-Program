#include<stdio.h>
int main()
{
	int x,t,i;
	scanf("%d %d",&x,&t);
	if(t<=20)
	for(i=1;i<=t;i++)
	{
		if(x<50000)
		x=x*1.02;
		else if(x<200000)
		x=x*1.03;
		else if(x<500000)
		x=x*1.04;
		else if(x<2000000)
		x=x*1.05;
		else
		x=x*1.06;
	}
	else
	if(x<50000)
		x=(x*0.02)*(t-20)+x;
		else if(x<200000)
		x=(x*0.03)*(t-20)+x;
		else if(x<500000)
		x=(x*0.04)*(t-20)+x;
		else if(x<2000000)
		x=(x*0.05)*(t-20)+x;
		else
		x=(x*0.06)*(t-20)+x;
	printf("%d",x);
	return 0;
}
