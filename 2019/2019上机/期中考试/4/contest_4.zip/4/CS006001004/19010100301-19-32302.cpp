#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,i,sum;
	int a[21];
	scanf("%d %d",&n,&m);
	sum=0;
	for(i=0;i<=n;i++)
	{
		a[i]=m%10;
		if(a[i]==1)
		sum+=pow(2,i);
		m/=10;
	}
	printf("%d",sum);
	return 0;
}
