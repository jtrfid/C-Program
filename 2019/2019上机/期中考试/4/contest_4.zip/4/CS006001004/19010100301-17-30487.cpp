#include<stdio.h>
int main()
{
	int X,x,t;
	float m;
	scanf("%d %d",&X,&t);
	x=X/1000;
	if(x<50)
	m=0.02;
	else if(x>=50&&x<200)
	m=0.03;
	else if(x>=200&&x<500)
	m=0.04;
	else if(x>=500&&x<=2000)
	m=0.05;
	else if(m>2000)
	m=0.06;
	int i,M;
	double a,sum;
	sum=1;
	M=0;
	a=1;
	for(i=1;i<=t;i++)
	{
        a*=1+m;
	}
	sum=x*a;
	M=sum*1000;
	printf("%d",M);
	return 0;	
}
