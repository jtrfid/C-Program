#include<stdio.h>
#include<math.h>
int main ()
{int result,i,j,k,p,sum,t;
 float x,y;
scanf("%f%d",&x,&t);
if(t>=20)
  {t=20;
  };
for(i=1;i<=t;i++)
    {   if(x<50000){p=2;};
        if(x>=50000&&x<200000){p=3;};
        if(x>=200000&&x<500000){p=4;};
        if(x>=500000&&x<2000000){p=5;};
        if(x>=2000000){p=6;};    	
    	y=x*(1+p*0.01);
    	x=y;
    }
	result=y;
	printf("%d",result);
	return 0;
}
