#include<stdio.h>
int main()
{
	int x,t,w,i;
	float d;
	scanf ("%d %d",&x,&t);
	if(x<50000)
	{
		d=1.02;
	}
	else if (x>=50000&&x<200000)
	{
		d=1.03;
	}
	else if (x>=200000&&x<500000)
	{
		d=1.04;
	}
	else if (x>=200000&&x<500000)
	{
		d=1.05;
	}
	else if (x>=500000)
	{
		d=1.06;
	}
	else if (t>20)
	{
		d=1;
	}
	for(i=1;i<=t;i++)
	{
		x=x*d;
		
	}
	printf("%d",x);
	return 0;
	
}
