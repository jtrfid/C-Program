#include<stdio.h>
#include<math.h>
int main()
{int a,b,i,n,m,c=0;
scanf("%d%d",&n,&m);
for(i=1;i<n;i++)
	{a=m%(10*i);
	b=pow(2,i-1);
	if(a=1)
	{c=c+b;
	}else
	c=0;
	printf("%d",c);
	}
	return 0;
}
