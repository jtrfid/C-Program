#include<stdio.h>
#include<math.h>
int main ()
{int n,j,i,k,sum=0;
 long long int m;
 scanf("%d",&n);
 scanf("%lld",&m);
 k=m;
 for(i=0;i<n;i++)
     {sum=sum+(k%10)*pow(2,i);
      k=k/10;
     };
  printf("%d",sum);  





return 0;
}
