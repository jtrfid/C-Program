#include<stdio.h>
#include<math.h>
int main()
{
	int x,t;
	int sum=0;
	scanf("%d%d",&x,&t);
	if(t<=20)
{
	if(x<50000)
	sum=x*pow(1.02,t);
	if(x>=50000&&x<200000)
	sum=x*pow(1.03,t);
	if(x>=200000&&x<500000)
	sum=x*pow(1.04,t);
	if(x>=500000&&x<2000000)
	sum=x*pow(1.05,t);
	if(x>2000000)
	sum=x*pow(1.06,t);
}
else
{
	if(x<50000)
	sum=x*pow(1.02,20);
	if(x>=50000&&x<200000)
	sum=x*pow(1.03,20);
	if(x>=200000&&x<500000)
	sum=x*pow(1.04,20);
	if(x>=500000&&x<2000000)
	sum=x*pow(1.05,20);
	if(x>2000000)
	sum=x*pow(1.06,20);
	
}
	printf("%d",sum);
	return 0;
	
	
}
