#include<stdio.h>
int main()
{
	int m,i,k,l,a,n=0,p;
	scanf("%d",&m);
	k=m*m;
	l=(m+1)*(m+1);
	p=0;
	for(i=k;i<=1;i++)
	{
		for(a=2;a<i;a++)
		{
			if(i%a==0)
			n++;
		}
		if(n==0)
		{
			p=p+i;
			n=0;
		}
		n=0;
	}
	printf("%d",p);
	return 0;
}
