#include<stdio.h>
int main()
{
	int n,i,m,l,k,h=1,p=0;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	{
		h=1;
		k=m%10;
		if(i!=1)
		{
			for(l=1;l<=i-1:l++)
			{
				h=h*2;
			}
		}
		p=p+k*h;
		m=m/10;
	}
	printf("%d",p);
	return 0;
}
