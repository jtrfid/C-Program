#include<stdio.h>
#include<math.h>
int main()
{
	int x;
	float y;
	scanf("%d",&x);
	if(-100<=x&&x<=12)
	{
    y=sqrt(2019-x*x*x+x);
	y=y/(x-10);
	printf("%.2f",y);}
	else
	printf("no");
	return 0;
}
