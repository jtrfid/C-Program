#include<stdio.h>
#include<math.h>
int main()
{int x;
float y,a;
scanf("%d",&x);
if(x>=-100&&x<=12)
{y==((2019-((x)^3)+x)^(1/2))/(x-10);
printf("%d",y);
}
else printf("no");
}

