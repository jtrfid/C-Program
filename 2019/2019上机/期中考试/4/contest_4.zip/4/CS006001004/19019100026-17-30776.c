#include<stdio.h>
int main()
{
	double mon,y,i,rate;
	scanf("%lf%lf",&mon,&y);
	//if(y>20)
	//	y=20;
	for(i=0;i<y;i++)
		{
			if(mon<50000)
				rate=0.02;
			else if(mon<200000)
				rate=0.03;
			else if(mon<500000)
				rate=0.04;
			else if(mon<2000000)
				rate=0.05;
			else
				rate=0.06;
			mon+=mon*rate;
		}
	printf("%.0lf",mon);
	return 0;
}
