#include<stdio.h>
int main()
{
	int m,k,sum=0,i,t;
	scanf("%d",&m);
	for(i=m*m;i<=(m+1)*(m+1);i++)
	{
		for(t=2,k=0;t<=i;t++)
		{
			if(i%t!=0)
			k++;
		}
		if(k==i-2)
		sum+=i;
	}
    printf("%d",sum);
	return 0;
}
