#include<stdio.h>
#include<math.h>
int main()
{int b,x,y,t,a;
scanf("%d %d",&x,&t);
if(x>0&&x<50000)
{a==1+0.02;
y=a*x;}
printf("%d",y);
	return 0;
}
