#include<stdio.h>
#include<math.h>
int main()
{
	int m,i,j,sum=0,n,p;
	scanf("%d",&m);
	n=(m+1)*(m+1);
	for(i=m*m;i<=n;i++)
{
	for(j=2;j<sqrt(i);j++)
	{
	if(i%j==0)
	{p=0;break;}
	else
	p=1;
}
	if(p==1)
	sum+=i;
}
	printf("%d",sum);
	return 0;
}
