#include<stdio.h>
int main()
{int m,n,sum=0;
scanf("%d %d",&m,&n);
for(m;m<=n;m++)
sum=sum+m*m;
printf("%d",sum);
return 0;
}
