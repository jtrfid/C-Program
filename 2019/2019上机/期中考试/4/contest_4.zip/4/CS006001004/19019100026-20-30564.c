#include<stdio.h>
int prime(int n)
{
	int i,t=1;
	for(i=2;i<n;i++)
	{
		if(n%i==0)
		{
			t=0;
			break;
		}
	}
	if(n==0||n==1)
		t=0;
	return t;
}
int main()
{
	int m,sum=0,i,a,b;
	scanf("%d",&m);
	if(m*m<(m+1)*(m+1))
	{
		a=m*m;
		b=(m+1)*(m+1);
	}
	else
	{
		a=(m+1)*(m+1);
		b=m*m;
	}
	for(i=a;i<=b;i++)
	{
		if(prime(i)==1)
			sum+=i;
	}
	printf("%d",sum);
	return 0;
}
