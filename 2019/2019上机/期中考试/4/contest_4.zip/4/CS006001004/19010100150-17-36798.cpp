#include<stdio.h>
int main()
{int x,y,a;
a==1;
scanf("%d %d",&x,&y);
if(y<=20)
{do{if(x<50000)
{x==x*1.02;
a==a+1;
}else if(x>=50000&&x<200000)
{x==x*1.03;
a==a+1;
}else if(x>=200000&&x<500000)
{x==x*1.04;
a==a+1;
}else if(x>=500000&&x<2000000)
{x==x*1.05;
a==a+1;
}else if(x>=2000000)
{x==x*1.06;
a==a+1;
}
}while(a<=y);
}
else if(y>20)
{do{if(x<50000)
{x==x*1.02;
a==a+1;
}else if(x>=50000&&x<200000)
{x==x*1.03;
a==a+1;
}else if(x>=200000&&x<500000)
{x==x*1.04;
a==a+1;
}else if(x>=500000&&x<2000000)
{x==x*1.05;
a==a+1;
}else if(x>=2000000)
{x==x*1.06;
a==a+1;
}
}while(a<=20);
}
printf("%d\n",x);}
