#include<stdio.h>
int main()
{
	int x,t,y,a,p=0;
	float o;
	scanf("%d%d",&x,&t);
	if(0<t&&t<=20)
	{
		if(x<50000)
		for(a=1;a<=t;a++)
		{
			o=x*0.02;
			x=x+o;
			y=x;
		}
		else if(50000<=x&&x<200000)
		for(a=1;a<=t;a++)
		{
			o=x*0.03;
			x=x+o;
			y=x;
		}
		else if(200000<=x&&x<500000)
		for(a=1;a<=t;a++)
		{
			o=x*0.04;
			x=x+o;
			y=x;
		}
		else if(500000<=x&&x<2000000)
		for(a=1;a<=t;a++)
		{
			o=x*0.05;
			x=x+o;
			y=x;
		}
		else
		for(a=1;a<=t;a++)
		{
			o=x*0.06;
			x=x+o;
			y=x;
		}
	}
	else
	y=x;
	printf("%d",y);
	return 0;
}
