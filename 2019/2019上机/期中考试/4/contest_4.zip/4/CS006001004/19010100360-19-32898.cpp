#include<stdio.h>
int main()
{
	int n,m,i=0,res,t=1,sum=0,C;
	scanf("%d %d",&n,&m);
	while(m>0)
	{
		res=m%10;
		m=m/10;
		i=i+1;
		if(res==1)
		{
		   while(i>1)
		   {
			   t=t*2;
			   i=i-1;
		   }
		   sum=sum+t;
		}

	}
	
	printf("%d",sum);
	return 0;
} 
