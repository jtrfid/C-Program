#include<stdio.h>
int main()
{int a,t,n,m,i=0,s=0;
scanf("%d %d",&n,&m);
for(m;m>=1;m=m/10)
{
   a=m%10;
   i++;
 for(t=1;t<i;t++)
   a=a*2;
   s=s+a;
   
}   
   printf("%d",s);
   return 0;
}
