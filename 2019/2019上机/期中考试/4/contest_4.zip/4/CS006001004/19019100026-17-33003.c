#include<stdio.h>
int main()
{
	int mon,m20,y,i,rate;
	scanf("%d%d",&mon,&y);
	m20=mon;
	for(i=0;i<20;i++)
		{
			if(m20<50000)
				rate=2;
			else if(m20<200000)
				rate=3;
			else if(m20<500000)
				rate=4;
			else if(m20<2000000)
				rate=5;
			else
				rate=6;
			m20+=m20*rate/100;
		}
	for(i=0;i<y;i++)
		{
			if(mon<50000)
				rate=2;
			else if(mon<200000)
				rate=3;
			else if(mon<500000)
				rate=4;
			else if(mon<2000000)
				rate=5;
			else
				rate=6;
			if(i<20)
				mon+=mon*rate/100;
			else
				mon+=m20*rate/100;
		}
	printf("%d",mon);
	return 0;
}
