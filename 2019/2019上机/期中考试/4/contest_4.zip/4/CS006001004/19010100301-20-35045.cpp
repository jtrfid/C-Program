#include<stdio.h>
#include<math.h>
int main()
{
	int m,sum,i,j,M,M1,flag;
		scanf("%d",&m);
	M1=m*m;
	M=(m+1)*(m+1);
	sum=0;
	flag=1;
for(i=M1;i<=M;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
			flag=0;
			break;}
		}
		if(flag==1)
		{
		sum+=i;continue;}
		else continue;
	}
	printf("%d",sum);
	return 0;
}
