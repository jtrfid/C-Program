#include<stdio.h>
int main()
{
	float x,y1,y2,y;
	scanf("%f",&x);
	if(x>=-100&&x<=12)
	{
		y1=sqrt(2019-x*x*x+x);
		y2=x-10;
		y=y1/y2;
		printf("%.2f",y);
	}
	else
	{
		printf("no");
	}
	return 0;
}
