#include<stdio.h>
int main()
{
	int n,m,sum;
	scanf("%d %d",&m,&n);
	int i;
	sum=0;
	for(i=m;i<=n;i++)
	sum+=i*i;
	printf("%d",sum);
	return 0;
}
