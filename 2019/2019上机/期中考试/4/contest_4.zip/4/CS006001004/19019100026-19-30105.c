#include<stdio.h>
int main()
{
	int a2,a10=0,b[20],n,x=1,i;
	scanf("%d%d",&n,&a2);
	for(i=0;i<20;i++)
	{
		b[i]=a2%10;
		a2/=10;
	}
	for(i=0;i<20;i++,x*=2)
		a10+=b[i]*x;
	printf("%d",a10);
	return 0;
}
