#include<stdio.h>
int main()
{
	int a,b,c=0;
	scanf("%d %d",&a,&b);
	while(a<=b)
	{
		c=c+a*a;
		a=a+1;
	}
	printf("%d",c);
	return 0;
}
