#include<stdio.h>
int main()
{
	int m,a,b,i,j;
	int sum=0;
	scanf("%d",&m);
	a=m*m;
	b=(m+1)*(m+1);
	for(i=a;i<=b;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			break;
		}
		if(j==i)
		{
			sum=sum+i;
		}
	}
	printf("%d",sum);
}
