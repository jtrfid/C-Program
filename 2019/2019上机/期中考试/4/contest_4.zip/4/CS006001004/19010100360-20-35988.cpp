#include<stdio.h>
#include<stdlib.h>
#define max_num 1000
#define min_num 20
int main(void)
{
	int i,n,j;
	int sum=0;
	scanf("%d",&n);
	if(n>=max_num||n<=min_num)return 0;
	for(j=n*n;j<(n+1)*(n+1);j++)
	{
		for(i=2;i<j;i++)
		{
			if(j%i==0)
			   break;
		}
		if(j<=1);
		else if(i<j);
		else{
			sum+=j;
		}
	}
	printf("%d\n",sum);
	return 0;
}
