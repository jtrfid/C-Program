#include<stdio.h>
int main ()
{
	int x,y,sum=0,i,t;
	scanf("%d %d",&x,&y);
	if (x>y)
	{
		t=x;
		x=y;
		y=t;
	}
	for (i=x;i<=y;i++)
	{
		sum+=x*x;
		x=x+1;
	
	}
	printf("%d",sum);
	return 0;
}
