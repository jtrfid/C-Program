#include<stdio.h>
int main()
{
	int x,t,y,i,p=0;
	float o;
	scanf("%d%d",&x,&t);
	if(0<t&&t<=20)
	{
		if(x<50000)
		{
			o=x*0.02*t;
			y=x+o;
		}
		else if(50000<=x&&x<200000)
		{
			o=x*0.03*t;
			y=x+o;
		}
		else if(200000<=x&&x<500000)
		{
			o=x*0.04*t;
			y=x+o;
		}
		else if(500000<=x&&x<2000000)
		{
			o=x*0.05*t;
			y=x+o;
		}
		else
		{
			o=x*0.06*t;
			y=x+o;
		}
	}
	else
	y=x;
	printf("%d",y);
	return 0;
}
