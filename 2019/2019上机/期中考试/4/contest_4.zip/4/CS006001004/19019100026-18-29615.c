#include<stdio.h>
int main()
{
	int sum=0,m,n,i;
	scanf("%ld%ld",&m,&n);
	for(i=m;i<=n;i++)
		sum+=i*i;
	printf("%d",sum);
	return 0;
}
