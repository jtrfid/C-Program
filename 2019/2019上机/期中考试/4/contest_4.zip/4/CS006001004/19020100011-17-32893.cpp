#include<stdio.h>
int main()
{int x,t,i;
scanf("%d %d",&x,&t);
if(x>0&&x<10000000&&(x%1000==0))
if(t>0&&t<50)
{ if(t>20&&t<50) t=20;
  {
  for(i=1;i<=t;i++)
{
if(x<50000) {x=x*(1+0.02);continue;}
if(x>=50000&&x<200000) {x=x*(1+0.03);continue;}
if(x>=200000&&x<500000) {x=x*(1+0.04);continue;}
if(x>=500000&&x<2000000) {x=x*(1+0.05);continue;}
if(x>=2000000) {x=x*(1+0.06);continue;}
}
  }

printf("%d",x);

  
}
return 0;
}
