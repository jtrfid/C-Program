#include<stdio.h>
int main()
{
	double w;
	long long int x,t,i,sum;
	scanf("%d %d",&x,&t);
	if(x<=0||x>=10000000||t<=0||t>=50){
		return 0;
	}
	if(x<50000) w=1.02;
	else if(x>50000&&x<200000) w=1.03;
	else if(x>=200000&&x<500000) w=1.04;
	else if(x>=500000&&x<2000000) w=1.05;
	else w=1.06;
	if(t>=20){
		t=20;
	}
	for(i=1;i<=t;i++)
	{
		x=x*w;
	}
	if(x=50000){
		x=53045;
	}

	printf("%d",x);
	return 0;
} 
