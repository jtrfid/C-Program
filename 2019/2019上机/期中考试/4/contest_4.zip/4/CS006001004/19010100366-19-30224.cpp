#include<stdio.h>
int main()
{
	int n,m,i;
	int s=1;
	int sum=0;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		sum=sum+(m%10)*s;
		m=m/10;
		s=s*2;
	}
	printf("%d",sum);
}
