#include<stdio.h>
int main()
{int m,n,sum1,sum2=0;
scanf("%d%d",&m,&n);
for(m;m<n+1;m++)
{sum1=m*m;
sum2=sum2+sum1;
}
printf("%d",sum2);
	return 0;
}
