#include<stdio.h>
int main()
{
	int m,a,b,i,t,s=0;
	scanf("%d",&m);
	a=m*m;
	b=(m+1)*(m+1);
	for(a;a<=b;a++)
	{
	for(i=2;i<a;i++)
	{
	if(a%i!=0) t=0;
	if(a%i==0) {t=1;break;}
    }
	if(t==0)
	s=s+a;
    }
	printf("%d",s);
	return 0;
	
}
