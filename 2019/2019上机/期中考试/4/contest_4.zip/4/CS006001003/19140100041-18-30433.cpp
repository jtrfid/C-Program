#include<stdio.h>
int main()
{    
int i,m,n,sum=0;
scanf("%d %d",&m,&n);
if(m>=0&&m<n&&n<=1000)
{

for(i=m;i<=n;i++)
{
	sum=sum+i*i;
}
printf("%d",sum);
}
	return 0;
}
