#include<stdio.h>
int p(int a);
int main()
{
	int i,k,m;
	char temp[i];
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		scanf("%c",&temp[i]);
	}
	for(i=0;i<m;i++)
	{
		k=k+(temp[i]-'0')*p(k-i-1);
	}
	printf("%d",k);
	return 0;
}
int p(int a)
{
	int i,q=1;
	for(i=1;i<=a;i++)
	{
		q=q*2;
	}
	return q;
}
