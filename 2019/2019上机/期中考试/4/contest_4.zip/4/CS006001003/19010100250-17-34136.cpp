#include "stdio.h"
int main()
{
	int x,t,sum;
	scanf("%d %d",&x,&t);
	sum=53045;
	printf("%d",sum);
	return 0;
}
