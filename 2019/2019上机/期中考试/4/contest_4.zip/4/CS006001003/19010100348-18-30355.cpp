#include"stdio.h"

int main()
{
   int m,n,i=0,s=0;
   scanf("%d%d",&m,&n);
   for(i=m;i<=n;i++)
   {
         s=s+i*i;
    }
    printf("%d",s);
    getchar();
    getchar();
   return 0;   
}
