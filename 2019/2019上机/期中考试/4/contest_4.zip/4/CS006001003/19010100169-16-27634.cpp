#include <stdio.h>
#include <math.h>
int main()
{
	float a,b,x,y;
	scanf("%f",&x);
	if((x>12)||(x<-100)) printf("no");
	a=sqrt(2019-x*x*x+x);
	b=x-10;
	y=a/b;
	if((x<=12)&&(x>=-100)) printf("%.2f",y);
	return 0;
}
