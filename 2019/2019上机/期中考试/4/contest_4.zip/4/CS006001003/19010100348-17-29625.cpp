#include"stdio.h"
   
int main()
{
   int x,t,i=0;
   scanf("%d%d",&x,&t);
   int a;
   a=x;
   float b;
   if(t<=20)
   {
       if(x<50000)
       {
          b=0.02;     
       }
       else if((x>=50000)&&(x<200000))
       {
          b=0.03;   
        }
        else if((x>=200000)&&(x<500000))
        {
          b=0.04;   
        }
        else if((x>=500000)&&(x<2000000))
        {
           b=0.05;   
        }
        else
        {
               b=0.06;
        }
        }
    else
    {
       t=20;   
    }
    for(i=1;i<=t;i++)
    {
       a=a*(1+b);   
    }
    printf("%d",a);
    getchar();
    getchar();
   return 0;   
}
