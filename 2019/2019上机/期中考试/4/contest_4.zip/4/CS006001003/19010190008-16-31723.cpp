#include<stdio.h>
int main()
{
	int x;
	float y;
	scanf("%d",&x);
	if((x<-100)||(x>12))
	printf("no");
	if(x/1!=x)
	printf("no");
	else y=sqrt(2019-x*x*x+x)/(x-10);
	printf("%.2f",y);
	return 0;
}
