#include<stdio.h>
int main()
{    int i,j,m,sum=0,flag=0;
    scanf("%d",&m);
    for(i=m*m;i<=(m+1)*(m+1);i++)
    {
    	for(j=2;j<i*0.5;j++)
    	{
    		if(i%j==0)
    		{
    			flag=0;break;
    		}
    		else
    		{
    			flag=1;
    		}
    	}
    	if(flag==1)
    	 {
    	 	sum=sum+i;
    	 }
    }
    printf("%d",sum);

	return 0;
}
