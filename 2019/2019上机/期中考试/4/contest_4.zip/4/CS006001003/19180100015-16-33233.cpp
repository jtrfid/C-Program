#include<stdio.h>
int main()
{
	int x,t;
	double s,y,n;
	y=0;n=0;
	scanf("%d %d",&x,&t);
	if(x>0&&x<50000)
	s=0.02;
	else if(x>=50000&&x<=200000)
	s=0.03;
	else if(x>=200000&&x<=500000)
	s=0.04;
	else if(x>=500000&&x<=2000000)
	s=0.05;
	else if(x>=2000000)
	s=0.06;
	if(t<=20)
	{
		while(n<=t)
		{
		n=n+1;
		y=x*(1+s);
		x=x*(1+s);
	}

	}
	else
	{
		while(n<=20)
	{
		n=n+1;
		y=x*(1+s);
		x=x*(1+s);
		
	}
	}
		printf("%d",y);
	return 0;
}
