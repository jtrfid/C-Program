#include"stdio.h"
int main()
{
	int m,n,i,b[20],sum=0,j,t;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		b[i]=m%10;
		m=m/10;
	}
	for(i=0;i<n;i++)
	{
		t=1;
	    for(j=0;j<n-i;j++)
	    {
	    	if(b[i]==1&&i==0)
	    	t=1;
	    	else if(b[i]==1&&i!=0)
	    	{
	    		t=t*2;
	    	}
	    	else t=0;
	    }
	    sum=sum+t;
	}
	printf("%d",sum);
	return 0;
}
