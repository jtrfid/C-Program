#include<stdio.h>
int main()
{
	int t;
	float x;
	scanf("%f %d",&x,&t);
	int m=1;
    for( ;x<50000&&m<=20&&m!=(t+1);++m)
	{
    	x=x*1.02;
	}
	for( ;x<200000&&x>=50000&&m<=20&&m!=(t+1);++m)
	{
		x=x*1.03;
	}
	for( ;x<500000&&x>=200000&&m<=20&&m!=(t+1);++m)
	{
		x=x*1.04;
	}
	for( ;x<2000000&&x>=500000&&m<=20&&m!=(t+1);++m)
	{
		x=x*1.05;
	}
	for( ;x>=2000000&&m<=20&&m!=(t+1);++m)
	{
		x=x*1.06;
	}
	printf("%d",(int)x);
	return 0;
}
