#include<stdio.h>
int main()
	{
		int m,n,sum,i,s;
		scanf("%d",&m);
		n=m*m;
		while(n>=m*m&&n<=(m+1)*(m+1))
		{
		for(i=1;i<=n;i++)
		{
			if(n%i==0)
			s=n;
			else
			s=0;
			
		}
		n=n+1;
		sum=sum+s;
		
	}
	printf("%d",sum);
	return 0;
	}
	
