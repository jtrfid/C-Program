#include <stdio.h>
int main()
{
	int a=0,i,m,n;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(m>0&&m<=n&&n<1000)
		a=a+i*i;
		
	}
	printf("%d",a);
	
	
	return 0;
}
