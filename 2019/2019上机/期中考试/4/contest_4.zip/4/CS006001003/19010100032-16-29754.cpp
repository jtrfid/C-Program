#include "stdio.h"
int main()
{
	int x,t,p,i;
	scanf("%d %d",&x,&t);
	if(x<50000&&x>0)
	{    p=x;
		for(i=1;i<=t&&i<=20;i++)
		{
			p=p*(1.02);
		}
	}
	else if(x>=50000&&x<200000)
	{
		p=x;
		for(i=1;i<=t&&i<=20;i++)
		{
			p=p*(1.03);
		}
	}
	else if(x>=200000&&x<500000)
	{
		p=x;
		for(i=1;i<=t&&i<=20;i++)
		{
			p=p*(1.04);
		}
	}
	else if(x>=500000&&x<2000000)
	{
		p=x;
		for(i=1;i<=t&&i<=20;i++)
		{
			p=p*(1.05);
		}
	}
	else if(x>=2000000)
	{
		p=x;
		for(i=1;i<=t&&i<=20;i++)
		{
			p=p*(1.06);
		}
	}
	
	printf("%d",p);
	
	
	
	
	
	
	return 0;
}


