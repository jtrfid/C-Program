#include <stdio.h>
int main()
{
	int m,n,b,i,j,s=1,sum=0;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		for(j=1,s=1;j<i;j++)
		{
			s=s*10;
		}
		b=(m/s)%10;
		for(j=1,s=1;j<i;j++)
		{
			s=s*2;
		}
		sum+=b*s;
	}
	printf("%d",sum);
	return 0;
}
