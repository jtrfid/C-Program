#include<stdio.h>
int main()
{
	int i,x,t,m,sn=0;

	
	scanf("%d %d",&x,&t);
	if(t<=20)
	{
	
      for(i=1;i<=t;i++)
      {  if(t<=20)
      	{
      	if(x>0&&x<50000)
      	{
      		x=x*1.02;
      		sn=x;
      	}
      	else if(x>=50000&&x<200000)
      	{
      		x=x*1.03;
      		sn=x;
      	}
      	else if(x>=200000&&x<500000)
      	{
      		x=x*1.04;
      		sn=x;
      	}
      	else if(x>=500000&&x<2000000)
      	{
      		x=x*1.05;
      		sn=x;
      	}
      	else if(x>=2000000)
      	{
      		x=x*1.06;
      		sn=x;
      	}}
    else if(t>20&&t<=50)
      {
      if(x>0&&x<50000)
      	{
      		m=x*0.02;
      		sn=m+sn;
      	}
      	else if(x>=50000&&x<200000)
      	{
      		m=x*0.03;
      		sn=m+sn;
      	}
      	else if(x>=200000&&x<500000)
      	{
      		x=x*0.04;
      		sn=x+sn;
      	}
      	else if(x>=500000&&x<2000000)
      	{
      		m=x*0.05;
      		sn=m+sn;
      	}
      	else if(x>=2000000)
      	{
      		m=x*0.06;
      		sn=sn+m;
      	}
      }}
      printf("%d",sn);
    
	
	  return 0;
	  }}
      
