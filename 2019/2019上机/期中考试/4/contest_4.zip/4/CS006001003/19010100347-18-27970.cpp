#include "stdio.h"
int main()
{
    int m,n,sum,i;
    scanf("%d %d",&m,&n);
    for(i=m,sum=0;i<=n;i++)
    {
      sum+=i*i;
    }
    printf("%d",sum);
    getchar();
    getchar();  
    return 0; 
}
