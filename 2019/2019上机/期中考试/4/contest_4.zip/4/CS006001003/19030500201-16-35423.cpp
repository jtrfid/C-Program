#include<stdio.h>
int isprime(int x);
int main()
{
	int m;
	scanf("%d",&m);
	int min,max;
	min = m*m;
	max = (m+1)*(m+1);
	int i;
	int sum=0;
	for(i=min;i<max;i++)
	{
		if(isprime(i)==1)
		{
			sum =sum+i;
		}
	}
	printf("%d",sum);
	return 0;
}
int isprime(int x)
{
	int i,j;
	for(i=3;i<=x/2;i=i+2)
	{
		if((x%i)==0) 
		{
		return 0;}
	}
	return 1;
}
