#include<stdio.h>
int main()
{
	int i,t;
	long x;
	scanf("%d %d",&x,&t);
	if((x>0)&&(x<50000))
	for(i=1;i<=t;i++)
	{
		
		x=x*1.02;	
	}
	if((x>=50000)&&(x<200000))
	for(i=1;i<=t;i++)
	{
		x=x*1.03;
	}
	if((x>=200000)&&(x<500000))
	for(i=1;i<=t;i++)
	{
		x=x*1.04;
	}
	if((x>=500000)&&(x<2000000))
	for(i=1;i<=t;i++)
	{
		x=x*1.05;
	}
	if((x>=2000000)&&(x<10000000))
	for(i=1;i<t;i++)
	{
		x=x*1.06;
	}
	printf("%d",x);
	
	return 0;
}
