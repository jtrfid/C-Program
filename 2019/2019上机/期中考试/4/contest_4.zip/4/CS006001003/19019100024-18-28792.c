#include <stdio.h>
#include <stdlib.h>
int main()
{
    int m,n,i;
	long int sum;
	scanf("%d %d",&m,&n);
	sum=0;
	for(i=m;i<=n;i++)
	sum+=i*i;
	printf("%ld",sum);
	return 0;
}

