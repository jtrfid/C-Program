#include<stdio.h>
int main()
{
	int m,n;
	int sum;
	int i;
	sum = 0;
	scanf("%d%d",&m,&n);
	if(m==n)
	{
		sum = m*m;
	}
	else
	{
		for(i=m;i<n+1;i++)
		{
			sum = sum +i*i;
		}
	}
	printf("%d",sum);
	return 0;
}
