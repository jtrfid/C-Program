#include<stdio.h>

int main()
{
	int m,n;
	int i,flag,sum;
	scanf("%d %d",&m,&n);
	i=m;
	while(i<=n)
	{
		flag=i*i;
		i++;
		sum=sum+flag;
	}
	printf("%d",sum-1);
	return 0;
}
