#include <stdio.h>
#include <math.h>

int main()
{
	int m,n;
	int sum,i;
	sum=1;
	scanf("%d%d",&m,&n);
	i=m;
	while(i<=n)
	{
		sum=sum+pow(i,2);
		i++;
	}
	printf("%d",sum);
	return 0;
}
