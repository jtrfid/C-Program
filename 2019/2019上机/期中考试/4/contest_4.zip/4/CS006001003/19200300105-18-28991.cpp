#include<math.h>
#include<stdio.h>

/*int main()					(16)
	{
		double x,y;
		scanf ("%lf",&x);
		if (x>=-100&&x<=12)
			{
				y=sqrt(2019-x*x*x+x);
				y=y/(x-10);
				printf ("%.2lf",y);
			}
		else printf ("no");
		return 0;	
	}*/
	
/*int main()			//	(17)
	{
		double x,n;
		scanf ("%lf %lf",&x,&n);
		int t=(int)n,i;
		if (x<=0||x>=10000000)
		return 0;
		if (n>20)
		t=20;
		for (i=0;i<t;i++)
			{
				if (x<50000)
				x=x*1.02;
				else if (x<200000)
				x=x*1.03;
				else if (x<500000)
				x=x*1.04;
				else if (x<2000000)
				x=x*1.05;
				else x=x*1.06;
			}
		printf ("%.0lf",x);
		return 0;	
	}*/

int main()
	{
		int m,n,i;
		int sum=0;
		scanf ("%d %d",&m,&n);
		for (i=m;i<=n;i++)
		sum+=i*i;
		printf ("%d",sum);
		return 0;

	}	







	
