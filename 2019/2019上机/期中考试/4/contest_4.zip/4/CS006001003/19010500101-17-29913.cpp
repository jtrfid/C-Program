#include<stdio.h>

int main()
{
	int x,t;
	int i,sum;
	
	scanf("%d %d",&x,&t);
	sum=x;
	if((0<t)&&(t<=20))
	{
		for(i=1;i<=t;i++)
		{
			if(x<50000)
			{
				sum=sum+0.02*sum;
			}
			if((x>=50000)&&(x<200000))
			{
				sum=sum+0.03*sum;
			}
			if((x>=200000)&&(x<500000))
			{
				sum=sum+0.04*sum;
			}
			if((x>=500000)&&(x<2000000))
			{
				sum=sum+0.05*sum;
			}
			if(x>=2000000)
			{
				sum=sum+0.05*sum;
			}
		}
	}
	if((t>20)&&t<50)
	{
		for(i=1;i<=20;i++)
		{
			if(x<50000)
			{
				sum=sum+0.02*sum;
			}
			if((x>=50000)&&(x<200000))
			{
				sum=sum+0.03*sum;
			}
			if((x>=200000)&&(x<500000))
			{
				sum=sum+0.04*sum;
			}
			if((x>=500000)&&(x<2000000))
			{
				sum=sum+0.05*sum;
			}
			if(x>=2000000)
			{
				sum=sum+0.05*sum;
			}
	}
}
	printf("%d",sum);
	return 0;

}
