#include<stdio.h>
int zhi(int a);
int main()
{
	int a,b,i,j,s=0;
	scanf("%d",&a);
	for(i=a*a;i<=(a+1)*(a+1);i++)
	{
	if(zhi(i)==1)
	s=s+i;
	}
	printf("%d",s);
	return 0;
}
int zhi(int a)
{

	int b,c,i;
	for(i=2;i<a;i++)
	{
		b=a%i;
		if(b==0)
		break;
	}
	if(b!=0)
	c=1;
	else
	c=0;
	return c;
}
