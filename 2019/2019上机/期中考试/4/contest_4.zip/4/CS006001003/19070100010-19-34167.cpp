#include "stdio.h"
int main()
{
	int i,j,m,n,part,sum;
	sum=0;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		part=1;
		if(m%10!=0)
		{
			for(j=0;j<(i-1);j++)
			{
				part=part*2;
			}
		}
		else
		{
			part=0;
		}
		sum=sum+part;
		m=m/10;
	}
	printf("%d",sum);
	return 0;
}
