#include "stdio.h"
#include "math.h"
int main()

{
	float b,a,c;
	scanf("%f",&a);
	if(a<-100||a>12)
	printf("no");
	else 
	{
	  c=2019-(a*a*a)+a;
	  b=sqrt(c)/(a-10);
	  printf("%.2f",b);
    }
	return 0;
}
