#include "stdio.h"
int aa(int m);
int main()
{
	int m,a,b,i;
	a=0;
	scanf("%d",&m);
	for(i=m*m;i<=((m+1)*(m+1));i++)
	{
		if(aa(i)==0)
		a=a+i;
	}
	printf("%d",a);
	return 0;
}
int aa(int m)
{
	int j=0;
	int i;
	for (i=2;i<m;i++)
	{
		if (m%i==0)
		{
			j=1;
			break;
		}
	}
	return j;
}
