#include"stdio.h"
int main()
{
	int m,n,i,b[20],sum=0,j,t;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		b[i]=n%10;
		n=n/10;
	}
	for(i=0;i<m;i++)
   {
		t=1;
	    for(j=0;j<i;j++)
	    {
	    	 if(b[i]==1)
	    	{
	    		t=t*2;
	    	}
	    	else t=0;
	    }
	    sum=sum+t;
	}
	if(b[0]==0)
	printf("%d",sum-1);
	else printf("%d",sum);
	return 0;
}
