#include<stdio.h>
int main()
{
	int n,m,i=0,shi,x;
	int sum=0;
	scanf("%d %d",&n,&m);
	while(m!=0)
	{
		x=m%10;
		m=m/10;
		i++;
		shi=x;
		int ci=1;
		while(ci<=(i-1))
		{	
			shi=shi*2;
			ci++;
		}
		sum=sum+shi;
	}
	printf("%d",sum);
	return 0;
}
