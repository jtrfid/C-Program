#include "stdio.h"
int main()
{
	int i,j,m,flag,sum=0;
	scanf("%d",&m);
	for(i=m*m;i<=(m+1)*(m+1);i++)
	{    
	      flag=1;
		for(j=2;j<=(i-1);j++)
		{
			if(i%j==0)
			{
				flag=0;
				break;
			}
		   
		}
		
		if(flag==1)
		{
			sum=sum+i;
		}
		
		
		
	}
	
	
	printf("%d",sum);

	
	
	
	
	
	

	
	return 0;
}


