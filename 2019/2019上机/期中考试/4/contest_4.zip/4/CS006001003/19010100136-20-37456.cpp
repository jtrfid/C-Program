#include <stdio.h>
#include <math.h>
int pr(int a);
int main()
{
	int m;
	scanf("%d",&m);
	int i,sum;
	sum=0;
	i=pow(m,2);
	do
	{
		if(pr(i)==2)
		{
			sum=sum+i;
		}
		i++;
	}
	while(i<pow(m+1,2));
	printf("%d",sum);
	return 0;
} 


int pr(int a)
{
	int i,f;
	f=0;
	i=2;
	while(i<=a/2)
	{
		if(a%i==0)
		f++;
		i++;
	}
	if(f==0)
	return 2;
	else return 1;
}
