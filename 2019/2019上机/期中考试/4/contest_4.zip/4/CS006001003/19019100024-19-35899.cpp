#include"stdio.h"
#include"math.h"
int main()
{
	int n,i,t;
	int sum;
    scanf("%d",&n);
    	char a[20];
    	gets(a);
	sum=0;
	for(i=0;i<n;i++)
	{
	if(a[i]=='1')
	sum+=pow(2,n-i);
	else
	sum+=0;
	}
	printf("%d",sum);
	return 0;
}
