#include<stdio.h>

int main()
{
	int a,b,i,s=0;

	scanf("%d%d",&a,&b);
	for(i=0;i<=b-a;i++)
	{
		s=s+(a+i)*(a+i);
	}
	printf("%d",s);

	return 0;
}
