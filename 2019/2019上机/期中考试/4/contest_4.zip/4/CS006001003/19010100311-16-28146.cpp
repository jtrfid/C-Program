#include "stdio.h"
#include "math.h"
int main()
{float x,y,fenzi1,fenzi2,fenmu;
  scanf("%f",&x);
   if(x>=-100&&x<=12)
   {fenzi1=2019-x*x*x+x;
   fenzi2=sqrt(fenzi1);
   fenmu=x-10;
   y=fenzi2/fenmu;
   printf("%.2f",y);
   }
   else printf("no");
return 0;
}
