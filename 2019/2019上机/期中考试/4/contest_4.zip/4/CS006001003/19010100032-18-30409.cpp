#include "stdio.h"
int main()
{    int i;
     int m,n,p,t;
     scanf("%d %d",&m,&n);
     int sum=0;
     i=m;
     t=m;
     while(i<=n)
     {  
        p=t*t;
        t=t+1;
        sum=sum+p;
     	i++;
     }
    

   

	printf("%d",sum);
	
	
	
	
	
	
	
	
	
	return 0;
}


