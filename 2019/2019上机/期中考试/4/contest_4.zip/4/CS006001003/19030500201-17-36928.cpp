#include<stdio.h>
int main()
{
	int money=0,year=0;
	int j,k;
	float total = 0;
	scanf("%d%d",&money,&year);
	total = money;
	for(j=0;j<year;j++)
	{
		if(total<50000)
		{
			total =total*1.02;
		}
		else if(total<200000)
		{
			total =total*1.03;
		}
		else if(total<500000)
		{
			total =total*1.04;
		}
		else if(total<2000000)
		{
			total =total*1.05;
		}
		else 
		{
			total = total*1.06;
		}
		if(j==19)break;
	}
	printf("%.0f",total);
	return 0;
}
