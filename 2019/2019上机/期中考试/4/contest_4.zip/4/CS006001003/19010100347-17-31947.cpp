#include "stdio.h"
int main()
{
    int x,t,i;
    float n;
    float y;
    scanf("%d %d",&x,&t);
    y=1.0*x;
    if(x<50000)
    {
        n=0.02;
    }
    else if((x>=50000)&&(x<200000))
    {
        n=0.03;
    }
    else if((x>=200000)&&(x<500000))
    {
        n=0.04;
    }
    else if((x>=500000)&&(x<2000000))
    {
        n=0.05;
    }
    else
    {
        n=0.06;
    }
    if(t>=20)
    {
      for(i=1;i<=20;i++)
      {
         y=y*(1+n);
      }    
    }
    else
    {
        for(i=1;i<=t;i++)
        {
            y=y*(1+n);
        }
    }
    printf("%d",(int)y);
    getchar();
    getchar();
    return 0; 
}
