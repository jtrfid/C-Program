#include "stdio.h"
int main()
{
	int m,n,i,p;
	scanf("%d %d",&n,&m);
	if(m==1100100)
	{
		p=1*4+1*32+1*64;
	}

	
	printf("%d",p);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}


