#include "stdio.h"
int main()
{
	int m,n,sum,i;
	sum=0;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		sum=sum+i*i;
	}
	printf("%d",sum);
	return 0;
}
