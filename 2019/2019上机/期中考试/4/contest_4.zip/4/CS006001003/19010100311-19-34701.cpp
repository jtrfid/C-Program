#include "stdio.h"
#include "math.h"
int main()
{int n;
int m[n-1],i;
int shu=0;
scanf ("%d ",&n);scanf(" %d",&m[n-1]);
   if(n>0&&n<20)
   {  for(i=0;i<n;i++)
   shu=m[i]*pow(2,n-1-i)+shu;
   
   }
   printf("%d",shu);
   return 0;
}
