#include"stdio.h"
#include"math.h"
int main()
{
	int x,t,d,i;
	scanf("%d %d",&x,&t);
	for(i=1;i<=t;i++)
	{
			if(x<50000)
	        d=2;
	        else if((x>=50000)&&(x<200000))
	        d=3;
	        else if((x>=200000)&&(x<500000))
	        d=4;
	        else if((x>=500000)&&(x>2000000))
	        d=5;
	        else if(x>=2000000)
	        d=6;
	        if(i<=20)
	    	x=x*(1+d*0.01);
	}
	printf("%d",x);
	return 0;
}
