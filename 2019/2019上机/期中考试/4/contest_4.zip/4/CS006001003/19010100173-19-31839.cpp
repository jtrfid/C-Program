#include<stdio.h>
int main()
{int n,m;
	int z,x,c,v,b,o;
	int sum=0;
	scanf("%d %d",&n,&m);
		o=m/1000000;
		z=m%100000/10000;
		x=m%10000/1000;
		c=m%1000/100;
		v=m%100/10;
		b=m%10;
		if(o==1)
		{sum=sum+64;}
			if(z==1)
			{sum=sum+32;}
				if(x==1)
				{sum=sum+16;}
					if(c==1)
					{sum=sum+8;}
						if(v==1)
						{sum=sum+4;}
							if(b==1)
							{sum=sum+2;}

	printf("%d",sum);
	return 0;
	
}
