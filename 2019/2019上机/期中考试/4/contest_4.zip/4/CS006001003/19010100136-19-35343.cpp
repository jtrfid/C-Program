#include <stdio.h>
#include <math.h>

int main()
{
	int m,n;
	scanf("%d%d",&n,&m);
	int i,M,a,I,b,A;
	M=0;
	a=0;
	I=1;
	i=1;
	A=1;
    while(i<=n)
	{
		b=m%I;
		a=(m-b)%(i*10);
		if(a==1)
		{
			M=M+A;
		}
		A=A*2;
	}
	printf("%d\n",M);
	return 0;
}
