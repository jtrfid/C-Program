#include<stdio.h>
#include<math.h>
int mian()
{
	int n,m,i,sum=0,a,b,c;
	scanf("%d%d%d",&n,&m);
	if(n<=1)
	{
		sum=m;
	}
	else if(n>1)
	{
		for(i=0;i<=n-1;i++)
		{
			a=pow(10,i+1);
			b=pow(10,i);
			if(i=0)
			{
				sum=sum+m%a;
			}
			else
			{
				c=pow(2,i);
				sum=sum+((m%a)/b)*c;
			}
			
		}
	}
	printf("%d",sum);
}
