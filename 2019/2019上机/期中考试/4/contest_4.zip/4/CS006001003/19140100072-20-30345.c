#include"stdio.h"
int prim(int a);
int main()
{
	int m,i,s=0;
	scanf("%d",&m);
	for(i=m*m;i<(m+1)*(m+1);i++)
	{
		if(prim(i)==1)
		s+=i;
	}
	printf("%d",s);
}
int prim(int a)
{ int i,flag=1;
	for(i=2;i<a/2;i++)
	{
		if(a%i==0)
		{
			flag=0;
			break;
		}
	}
	return flag;
}
