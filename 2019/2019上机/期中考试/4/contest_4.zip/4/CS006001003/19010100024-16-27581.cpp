#include<stdio.h>
#include<math.h>
int main()
{
	int a;
	float b,s;
	scanf("%d",&a);
	if(a<-100||a>12)
	printf("no");
	else
	{
		b=sqrt(2019-a*a*a+a);
		s=b/(a-10);
		printf("%.2f",s);
	}
	return 0;
}
