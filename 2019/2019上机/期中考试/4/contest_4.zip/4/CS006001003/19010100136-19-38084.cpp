#include <stdio.h>
#include <math.h>

int main()
{
	int m,n;
	scanf("%d%d",&n,&m);
	int i,M,a,I,b,A;
	M=0;
	a=0;
	I=1;
	i=1;
	A=1;
    while(i<=n)
	{
		b=m%I;
	    I=I*10;
		a=(m-b)%I;
		
		if(a==0)
		{
			M=M+A;
		}
		A=A*2;
		i++;
	}
	printf("%d\n",M);
	return 0;
}
