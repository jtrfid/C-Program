#include<stdio.h>
int main()
{int n,m;
	int z,x,c,v,b,o,t;
	int sum=0;
	scanf("%d %d",&n,&m);
		o=m/1000000;
		z=(m%1000000)/100000;
		x=(m%100000)/10000;
		c=(m%10000)/1000;	
		v=(m%1000)/100;
		b=m%100/10;
		t=m%10;
		sum=o*64+z*32+x*16+c*8+v*4+b*2+t;
		

	printf("%d",sum);
	return 0;
	
}
