#include "stdio.h"
int main()
{int m,n,he=0,i;
scanf ("%d %d",&m,&n);
  if(n>=m&&m>0&&n<1000)
  {  for(i=m;i<=n;i++)
    {he=he+i*i;
    }
  }
  printf("%d",he);
return 0;
}
