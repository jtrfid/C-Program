#include<stdio.h>
int cri(int x);
int main()
{
	int m,sum=0,i;
	scanf("%d",&m);
	for(i=m*m;i<=((m+1)*(m+1));i++)
	{
		if(cri(i)==0)
		{
		sum=sum+i;	
		}
	}
	printf("%d",sum);
	return 0;
}
int cri(int x)
{
	int i;
	for(i=x-1;i>=2;i--)
	{
		if((x%i)==0)
		{
			return 1;break;
		}
		else if(i==2)
		{
			return 0;
		}
	}
}
