#include "stdio.h"
int main()
{
	int i,x,t,sum;
	scanf("%d %d",&x,&t);
	sum=x;
	if (t<=20)
	{
		if (x<50000)
		{
			for (i=1;i<=t;i++)
			{
				sum=sum*1.02;
			}
		}
		else if((x>=50000)&&(x<200000))
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.03;
			}
		}
		else if((x>=200000)&&(x<500000))
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.04;
			}
		}
		else if((x>=500000)&&(x<2000000))
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.05;
			}
		}
		else if(x>=2000000)
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.06;
			}
		}
	}
	if(t>20)
	{
		if (x<50000)
		{
			for (i=1;i<=20;i++)
			{
				sum=sum*1.02;
			}
			for(i=21;i<=t;i++)
			{
				sum=sum+x*0.02;
			}
		}
		else if((x>=50000)&&(x<200000))
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.03;
			}
			for(i=21;i<=t;i++)
			{
				sum=sum+x*0.03;
			}
		}
		else if((x>=200000)&&(x<500000))
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.04;
			}
			for(i=21;i<=t;i++)
			{
				sum=sum+x*0.04;
			}
		}
		else if((x>=500000)&&(x<2000000))
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.05;
			}
			for(i=21;i<=t;i++)
			{
				sum=sum+x*0.05;
			}
		}
		else if(x>=2000000)
		{
			for(i=1;i<=t;i++)
			{
				sum=sum*1.06;
			}
			for(i=21;i<=t;i++)
			{
				sum=sum+x*0.06;
			}
		}
	}
	printf("%d",sum);
	return 0;
}
