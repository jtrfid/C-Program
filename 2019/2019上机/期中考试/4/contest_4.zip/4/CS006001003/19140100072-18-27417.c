#include"stdio.h"
int main()
{
	int a,b,i,s=0;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{
	s+=i*i;	
		
	}
   printf("%d",s);
}


