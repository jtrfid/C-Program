#include "stdio.h"
#include "math.h"
int main()
{
	int a,b,i;
	scanf("%d %d",&a,&i);
	if(a<50000)
	{
		if(i<20)
		{
			b=a*pow(1.02,i);
		}
		else
		{
			b=a*1.02*i;
		}
	}
	else if(a>=50000&&a<200000)
	{
		if(i<20)
		{
			b=a*pow(1.03,i);
		}
		else
		{
			b=a*1.03*i;
		}
    }
    else if(a>=200000&&a<500000)
    {
    	if(i<20)
		{
			b=a*pow(1.04,i);
		}
		else
		{
			b=a*1.04*i;
		}
    }
    else if(a>=500000&&a<2000000)
    {
    	if(i<20)
		{
			b=a*pow(1.05,i);
		}
		else
		{
			b=a*1.05*i;
		}
    }
    else if(a>=2000000)
    {
    	if(i<20)
		{
			b=a*pow(1.06,i);
		}
		else
		{
			b=a*1.06*i;
		}
    }
    printf("%d",b);
	return 0;
}
