#include <stdio.h>
#include <math.h>

int main()
{
	float x,y;
	scanf("%f",&x);
	if((x>12)|(x<-100))
	{
		printf("no\n");
	}
	else
	{
		y=sqrt(2019-pow(x,3)+x)/(x-10);
		printf("%.2f\n",y);
	}
	return 0;
}
