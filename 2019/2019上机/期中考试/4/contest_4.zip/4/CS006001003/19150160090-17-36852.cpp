#include<stdio.h>
int main ()
{
	int x,t,y,i=0
	scanf("%d %d",6x,6t);
	if
	return 0;
}
