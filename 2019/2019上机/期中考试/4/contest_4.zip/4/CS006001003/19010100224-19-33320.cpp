#include"stdio.h"
int main()
{
	char a[1][20];
	int b[20];
	int n,i,j,sum=0,t=1,m;
	scanf("%d",&n);
	scanf("%s",a[0]);
	for(i=0;i<n;i++)
	{
		if(a[0][i]=='1')
		b[i]=1;
		else b[i]=0;
	}
	for(i=0;i<n;i++)
	{
		t=1;
		for(j=0;j<=i;j++)
		{
			if(i==0&&b[i]==1)
			{
				t=1;
			}
			else if(b[i]==1&&i!=0)
			{
				t*=2;
			}
		    else t=0;
		}
		sum=t+sum;
		
	}
    printf("%d",sum);
	return 0;
}
