#include <stdio.h>
#include <math.h>
int pri(int a);
int main()
{
	int m;
	scanf("%d",m);
	int i,sum;
	sum=0;
	for(i=pow(m,2);i++;i<pow(m+1,2))
	{
		if(pri(i)==1)
		{
			sum=sum+i;
		}
	}
	printf("%d",sum);
	return 0;
} 


int pri(int a)
{
	int i,f;
	f=0;
	for(i=2;i++;i<=a/2)
	{
		if(a%i==0)
		f++;
	}
	if(f==0)
	return 1;
	else return 0;
}
