#include "stdio.h"
int main()
{int m,n,i,e,f,g,he=0;
scanf ("%d",&m);
   if(m>20&&m<1000)
   {n=(m+1)*(m+1);
    g=m*m;
    for(i=g;i<=n;i++)
    {  for(e=2;e<i;e++)
       {   if(i%e==0)
	      {f=0;
	      break;
          }
          if(e==i-1) f=1;
       }
       if(f==1) he=he+i;
    }
    printf("%d",he);
   }
   return 0;
}
