#include"stdio.h"
#include"math.h"
int main()
{
	int n,sum,i,m,k,j;
	sum=0;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		k=1;
		if(m%10==1)
		{
			if(i>=1)
			{
				for(j=1;j<=i;j++)
			    {
			    	k=k*2;
			    }
			    sum=sum+k;
			}
			else 
			sum=sum+1;
		}
		m=m/10;
	}
	printf("%d",sum);
	return 0;
}
