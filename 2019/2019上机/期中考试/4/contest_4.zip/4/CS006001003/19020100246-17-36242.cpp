#include<stdio.h>
int main()
{
    int x,t;
    float y;
	scanf("%d %d",&x,&t);
	y=x;
	int m=1;
	while(m<=20&&m!=(t+1))
	{
		if(y<50000)
		y=y*1.02;
		else if(y<200000&&y>=50000)
		y=y*1.03;
		else if(y<500000&&y>=200000)
		y=y*1.04;
		else if(y<2000000&&y>=500000)
		y=y*1.05;
		else if(y>=2000000)
		y=y*1.06;
		m++;
	}
	x=(int)y;
	printf("%d",x);
	return 0;
}
