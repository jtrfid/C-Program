#include "stdio.h"
int bbg(int x);
int main()
{
    int m,sum,i,limit1,limit2;
    scanf("%d",&m);
    limit1=m*m;
    limit2=(m+1)*(m+1);
    for(i=limit1,sum=0;i<=limit2;i++)
    {
      if(bbg(i))
      {
            sum+=i;
        }
    }
    printf("%d",sum);
    getchar();
    getchar();  
    return 0;
}
int bbg(int x)
{
    int m;
    for(m=2;m<=x-1;m++)
    {
        if(x%m==0)
        {
            return 0;
        }
    }
    return 1;
}
