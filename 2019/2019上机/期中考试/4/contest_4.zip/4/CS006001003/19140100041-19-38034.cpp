#include<stdio.h>

int main()
{   int n;
char ch();
  int a=0;
  
 
  while(ch=getchar(),ch!='\n')
  {
  	
  	a=a*2+(ch-'0');
  }
  printf("%d",a);
  
  
  
	return 0;
}
