#include<math.h>
#include<stdio.h>

/*int main()					(16)
	{
		double x,y;
		scanf ("%lf",&x);
		if (x>=-100&&x<=12)
			{
				y=sqrt(2019-x*x*x+x);
				y=y/(x-10);
				printf ("%.2lf",y);
			}
		else printf ("no");
		return 0;	
	}*/
	
int main()			//	(17)
	{
		int  a,b;
		scanf ("%d %d",&a,&b);
		double x=(double)a;double n=(double)b;
		int t=(int)n,i;
		if (x<=0||x>=10000000)
		return 0;
		//if (n>20)
		
			double money=x;
		if (t>20)
			for (i=20;i<t;i++)
			{
				if (x<50000)
				x=x+money*0.02;
				else if (x<200000)
				x=x+money*0.03;
				else if (x<500000)
			x=x+money*0.04;
				else if (x<2000000)
				x=x+money*0.05;
				else x=x+money*0.06;
			}
		else
		for (i=0;i<t;i++)
			{
				if (x<50000)
				x=x*1.02;
				else if (x<200000)
				x=x*1.03;
				else if (x<500000)
				x=x*1.04;
				else if (x<2000000)
				x=x*1.05;
				else x=x*1.06;
			}
		// t=(int)n;
	
			
		printf ("%.0lf",x);
		return 0;	
	}

/*int main()		//(18)
	{
		int m,n,i;
		int sum=0;
		scanf ("%d %d",&m,&n);
		for (i=m;i<=n;i++)
		sum+=i*i;
		printf ("%d",sum);
		return 0;

	}*/
/*void math(int A[],int n,int m);	//(19)
int main()
	{
		int n,m;
		scanf ("%d %d",&n,&m);
		int A[n];
		math(A,n,m);
		int sum=0,i;
		for (i=0;i<n;i++)
			{
				sum=sum+A[i]*pow(2,i);
			}
		printf ("%d",sum);
		return 0;	
	}	
void math(int A[],int n,int m)
	{
		int i=0;
		do 
			{
				A[i]=m%10;
				m=m/10;
				i++;
			}while (m!=0);
	}*/
/*int isprim(int x);	//(20)
int main()
	
	{
		int m,sum=0,i;
		scanf ("%d",&m);
		int max=(m+1)*(m+1);
		
		for (i=m*m;i<=max;i++)
			{
				sum+=isprim(i);
			}
		printf ("%d",sum);
		return 0;	
	}
int isprim(int x)
	{
		if (x==2||x==3)
		return x;
		int flag=0,i=2;
		
		int max=sqrt(x);
		for (i=2;i<=max;i++)
			{
				if (x%i==0)
				return 0;
			}	
		return x;	
	}*/







	
