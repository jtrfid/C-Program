#include"stdio.h"
#include"stdlib.h"
#include"math.h"
int main()
{
	int x;
	float a,b,s;
	scanf("%d",&x);
	if(x>=-100&&x<=12&&x!=10)
	{
		a=sqrt(2019-x*x*x+x);
		b=x-10;
		s=a/b;
		printf("%.2f",s);
	}
	else printf("no");
}
