#include "stdio.h"
int main()
{ int t,i;
 int x,qian1;
 float qian;
 scanf ("%d %d",&x,&t);

    if (x>0&&x<10000000&&t>0&&t<50)
    {   if(t>=20) t=20;
	     if(x<50000)
        {   for(i=1,qian=x;i<=t;i++)
		    {qian=qian+qian*0.02;
            }
        }
        if(x>=50000&&x<200000)
        {   for(i=1,qian=x;i<=t;i++)
		    {qian=qian+qian*0.03;
            }
        }
        if(x>=200000&&x<500000)        
        {   for(i=1,qian=x;i<=t;i++)
		    {qian=qian+qian*0.04;
            }
        }
        if(x>=500000&&x<2000000)        
        {   for(i=1,qian=x;i<=t;i++)
		    {qian=qian+qian*0.05;
            }
        }
        if(x>=2000000)        
        {   for(i=1,qian=x;i<=t;i++)
		    {qian=qian+qian*0.06;
            }
        }
    }
 qian1=qian;
 printf("%d",qian1);
 return 0;
}
