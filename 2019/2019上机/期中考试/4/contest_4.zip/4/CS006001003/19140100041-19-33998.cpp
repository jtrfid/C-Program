#include<stdio.h>
#include<stdlib.h>
int main()
{   int i;
   char a[i];
   gets(a);
   int len,m,j,sum=0;
   scanf("%d",&i);
   len=a[i];
   if(len<=16)
   {
   for(i=0;i<=len;i++)
      {
      m=1;
      if(a[i]=='1')
      
      	for(j=1;j<=len-i-j;i++)
      
      {
      	m=m*2;
      	sum=sum+m;
      }
   }
  }
  
  printf("%d",sum);
  
	return 0;
}
