#include<stdio.h>
int main()
{
	int x,t;
	scanf("%d %d",&x,&t);
	int m=1;
	while(m<=20&&m!=(t+1))
	{
		if(x<50000)
		x=x*1.02;
		else if(x<200000&&x>=50000)
		x=x*1.03;
		else if(x<500000&&x>=200000)
		x=x*1.04;
		else if(x<2000000&&x>=500000)
		x=x*1.05;
		else if(x>=2000000)
		x=x*1.06;
		m++;
	}
	printf("%d",x);
	return 0;
}
