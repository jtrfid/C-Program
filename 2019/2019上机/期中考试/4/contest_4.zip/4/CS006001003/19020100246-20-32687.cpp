#include<stdio.h>
int zhishu(int i)
{
	if(i==1)
	return 1;
	int a,b;
	for(a=2;a<i;a++)
	{
		if(i%a==0)
		return 0;
	}
	return 1;
}
int sum(int m)
{
	int k,i,p,n;
	n=0;
	k=m*m;
	p=(m+1)*(m+1);
	for(i=k;i<=p;i++)
	{
		if(zhishu(i)==1)
		n=n+i;
	}
	return n;
}
int main()
{
	int m,ssum;
	scanf("%d",&m);
	ssum=sum(m);
	printf("%d",ssum);
	return 0;
}
