#include "stdio.h"
#include "math.h"
int main()
{
	int x;
	scanf("%d",&x);
	float y,p;
	if((x>=-100&&x<=12)&&(x!=10))
	{
		p=sqrt(2019-x*x*x+x);
		y=p/(float)(x-10);
		printf("%.2f",y);
	}
	else
	printf("no");
	
	
	
	
	
	
	
	
	
	
	return 0;
}









