#include<stdio.h>
int main()
{
	int n,m,d,i,k,q;
	d=0,k=1,q=1;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		k=k*10;
		d=d+q*((m%k)/(k/10));
		q=q*2;
	}
	printf("%d",d);
	return 0;
}
