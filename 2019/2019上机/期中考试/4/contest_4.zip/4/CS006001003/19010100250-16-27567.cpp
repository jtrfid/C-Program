#include "stdio.h"
#include "math.h"
int main()
{
	float x,y;
	scanf("%f",&x);
	if((x<-100)||(x>12))
	{
		printf("no");
	}
	else if((x>=-100)&&(x<=12))
	{
		y=(sqrt(2019-pow(x,3)+x))/(x-10);
		printf("%.2f",y);
	}
	return 0;
}
