#include "stdio.h"
#include "math.h"
int main()
{
	float a,b,c;
	scanf("%f %f",&a,&b);
	if(b>0&&b<=20)
	{
		if (a<50000)
		{
			c=a*pow(1+0.02,b);
		}
		else if(a>=50000&&a<200000)
		{
			c=a*pow(1+0.03,b);
		}
		else if(a>=200000&&a<500000)
		{
			c=a*pow(1+0.04,b);
		}
		else if(a>=500000&&a<2000000)
		{
			c=a*pow(1+0.05,b);
		}
		else
		{
			c=a*pow(1+0.06,b);
		}
	}
	else
	{
		b=20;
			if (a<50000)
		{
			c=a*pow(1+0.02,b);
		}
		else if(a>=50000&&a<200000)
		{
			c=a*pow(1+0.03,b);
		}
		else if(a>=200000&&a<500000)
		{
			c=a*pow(1+0.04,b);
		}
		else if(a>=500000&&a<2000000)
		{
			c=a*pow(1+0.05,b);
		}
		else
		{
			c=a*pow(1+0.06,b);
		}
	}
	printf("%.0f",c);
	return 0;
}
