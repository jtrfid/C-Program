#include "stdio.h"
#include "math.h"
int main()
{
	int a,b,c;
	scanf("%d %d",&a,&b);
	int i,j;
	c=0;
	for (i=1;i<=a;i++)
	{
	
	   j=pow(10,i);
	   if(i%2==0)
	   j=j+1;
	   if(b%j==0)
	   {
	   	   
	   }
	   else
       {
        b=b-pow(10,i-1);
        c=c+pow(2,i-1);
       }
	}
	printf("%d",c);
	return 0;
}
