#include<stdio.h>
int find(int m);
int main()
{
	int m,sum=0;
	int x,i,mp,mq,flag;
	scanf("%d",&m);
	mp=m*m;
	mq=(m+1)*(m+1);
	for(i=mp;i<=mq;i++)
	{
		if(flag==0)
		{
			x=0;
	    }
	     if(flag==1)
	    {
	
		x=i;
	    }
		sum=sum+x;
	}
	printf("%d",sum);
	return 0;
}
int find(int m)
{
	int i,flag;
	for(i=2;i<=m-1;i++)
	{
		if(m%i==0)
		flag=0;
		if(m%i!=0)
		flag=1;
	}
	return flag;
}
