#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,sum=0,i,a,b,c,d,e;
	scanf("%d %d",&n,&m);
	if(n<=1)
	{
		sum=m;
		printf("%d",sum);
	}
	else if(n>1)
	{
	  for(i=0;i<=n-1;i++)
	{
		
		if(i==0)
			{
				sum=sum+m%10;
			}
	    else
	    {
	    	a=pow(10,i+1);
	        b=pow(10,i);
			c=m%b;
			d=m%a;
			if(d>a)
			{
				e=d/b;
				sum=sum+e*pow(2,i);
			}	
			else
			{
			continue;	
			}
	    }
	}
	printf("%d",sum);
	}
	return 0;
	
}
