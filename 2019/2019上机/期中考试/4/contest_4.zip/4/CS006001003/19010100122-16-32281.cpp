#include "stdio.h"
int isprim(int a);
int main()
{
	int a,c,b,i,sum=0;
	scanf("%d",&a);
	b=a*a;
	c=(a+1)*(a+1);
	for(i=b+1;i<c;i++)
	{
		if(isprim(i)==1)
		{
			sum=sum+i;
		}
	}
	printf("%d",sum);
	return 0;
}
int isprim(int a)
{
	int i,flag=1;
	for(i=2;i<a;i++)
	{
	  if(a%i==0)
	  {
		flag=0;
		break;
	  }
    }
    return flag;
}

