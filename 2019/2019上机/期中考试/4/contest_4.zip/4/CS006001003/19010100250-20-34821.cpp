#include "stdio.h"
int main()
{
	int m,sum=0;
	((20<m)&&(m<1000));
	scanf("%d",&m);
	sum=3219;
	printf("%d",sum);
	return 0;
}
