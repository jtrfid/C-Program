#include <stdio.h>
#include <math.h>
int main()
{
	float y;
	int x;
	scanf("%d",&x);
	y=sqrt(2019-x*x*x+x)/(x-10);
	if(x>12||x<-100)
	{
		printf("no");
	}
	else
	{
		printf("%.2f",y);
	}
	
	
	
	return 0;
}
