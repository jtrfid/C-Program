#include "stdio.h"
#include "math.h"
int main()
{
    int x;
    float y;
    scanf("%d",&x);
    if((x<-100)||(x>12))
    {
        printf("no");
    }
    else
    {
        y=sqrt(2019-x*x*x+x)*1.0/(x-10);
        printf("%.2f",y);
    }
    getchar();
    getchar();
    return 0;
}
