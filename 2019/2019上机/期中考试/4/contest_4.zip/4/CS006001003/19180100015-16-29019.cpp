#include<stdio.h>
#include<math.h>
int main()
{
	int x;
	double y,disk;
	scanf("%d",&x);
	if(x>=-100&&x<=12&&x!=10)
	{
		disk=sqrt(2019-x*x*x+x)/(x-10);
		y=disk;
		printf("%.2f",y);
	}
	else
	printf("no\n");
	return 0;
}
