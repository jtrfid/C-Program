#include<stdio.h>
int main()
{
	int x,t;
	int i;
	scanf("%d %d",&x,&t);
	if(x<50000)
	{
		for(i=1;i<=t&&t<=20;i++)
		{
			x=x+x*0.02;
		}
	}
	else
	{
		if(x>=50000&&x<200000)
		{
			for(i=1;i<=t&&t<=20;i++)
		{
			x=x+x*0.03;
		}
		}
		else
		{
			if(x>=200000&&x<500000)
			{
				for(i=1;i<=t&&t<=20;i++)
				{
					x=x+x*0.04;
				}
			}
			else
			{
				if(x>=500000&&x<2000000)
				{
					for(i=1;i<=t&&t<=20;i++)
					{
						x=x+x*0.05;
					}
				}
				else
				{
					for(i=1;i<=t&&t<=20;i++)
					{
						x=x+x*0.06;
					}
				}
			}
		}
	}
	printf("%d",x);
	return 0;
}
