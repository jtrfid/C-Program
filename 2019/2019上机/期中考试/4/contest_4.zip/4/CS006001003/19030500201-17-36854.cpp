#include<stdio.h>
int main()
{
	int money=0,year=0;
	int j,k;
	float total = 0;
	scanf("%d%d",&money,&year);
	total = money;
		if(total<50000)
		{
			for(j=0;j<year;j++)
			{
			total =total*1.02;
			if(j==20)break;
			}
		}
		else if(total<200000)
		{
			for(j=0;j<year;j++)
			{
			total =total*1.03;
			if(j==20)break;
			}
		}
		else if(total<500000)
		{
			for(j=0;j<year;j++)
			{
			total =total*1.04;
			if(j==20)break;
			}
		}
		else if(total<2000000)
		{
			for(j=0;j<year;j++)
			{
			total =total*1.05;
			if(j==20)break;
			}
		}
		else 
		{
			for(j=0;j<year;j++)
			{
			total =total*1.06;
			if(j==20)break;
			}
		}

	printf("%.0f",total);
	return 0;
}
