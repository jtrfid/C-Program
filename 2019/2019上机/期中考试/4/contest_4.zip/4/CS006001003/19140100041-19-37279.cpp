#include<stdio.h>
#include<stdlib.h>
int main()
{   char ch;
  int n,a=0;
  
  while(ch=getchar(),ch!='\n')
  {
  	a=a*2+(ch-'0');
  }
  printf("%d",a);
  
  
  
	return 0;
}
