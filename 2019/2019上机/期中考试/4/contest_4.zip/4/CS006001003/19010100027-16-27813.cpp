#include<stdio.h>
#include<math.h>
int main()
{
	int x;
	float y,a;
	scanf("%d",&x);
	if((x<-100)||(x>12))
	printf("no");
	else
	{
		a=2019-x*x*x+x;
		y=(pow(a,0.5))/(x-10);
		printf("%.2f",y);
	} 
	return 0;
}
