#include "stdio.h"
int main()
{
    int n,m,i,s,res,q;
    scanf("%d %d",&n,&m);
    for(i=1,s=1,q=1;i<n;i++)
    {
        s=s*2;
        q=q*10;
    }
    for(i=q,res=0;i>=1;i=i/10,s=s/2)
    {
        res=res+(m/i)*s;
        m=m%i;
    }
    printf("%d",res);
    return 0;
}
        
    
