#include<stdio.h>
int main()
{	int x,y,z;
	int i;
	scanf("%d %d",&x,&y);
	z=x;
	if(y<=20)
	{y=y;
	}
	if(y>20)
	{y=20;
	}
	if(x<50000)
	{for(i=y;i>0;i--)
		{z=z*(1.02);
		}
	}
	if(x>=50000&&x<200000)
	{for(i=y;i>0;i--)
		{z=z*(1.03);
		}
	}
	if(x>=200000&&x<500000)
	{for(i=y;i>0;i--)
		{z=z*(1.04);
		}
	}
	if(x>=500000&&x<2000000)
	{for(i=y;i>0;i--)
		{z=z*(1.05);
		}
	}
	if(x>2000000)
	{for(i=y;i>0;i--)
		{z=z*(1.06);
		}
	}
	printf("%d",z);
	return 0;
}
