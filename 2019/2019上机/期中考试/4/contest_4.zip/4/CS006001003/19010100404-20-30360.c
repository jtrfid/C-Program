#include <stdio.h>
int main()
{
	int a,b,m,t,i,n,sum=0;
	scanf("%d",&m);
	a=m*m;
	b=(m+1)*(m+1);
	
	if(m>20&&m<1000)
	
	{
		for(i=a;i<b;i++)
		{
			int t=1;
			for(n=2;n<i;n++)
			{
				if(i%n==0)
				{
					t=0;
					break;
				}
				else
				{
					t=1;
				}
				
			}
			if(t==1)
			{
				sum+=i;
			}
				
			
		}
	}
	printf("%d",sum);
	
	
	return 0;
}
