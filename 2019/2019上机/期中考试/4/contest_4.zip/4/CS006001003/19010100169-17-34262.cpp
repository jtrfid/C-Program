#include <stdio.h>
int main()
{
	int t,i,x,b;
	float a,y;
	scanf("%d %d",&x,&t);
	y=x/1000;	
	if(y<50) a=0.02;
	if((y<200)&&(y>=50)) a=0.03;
	if((y<500)&&(y>=200)) a=0.04;
	if((y<2000)&&(y>=500)) a=0.05;
	if(y>=2000) a=0.06;
	for(i=1;i<=t;i++)
	{
		if(i>20) break;
		y=y*(1+a);
	}
	b=y*1000;
	i=y*10000;
	i=i%10;
	if(i>=5) b+=1;
	printf("%d",b);
	return 0;
}
