#include"stdio.h"
#include"math.h"
int main()
{
	int n,i,t;
	int sum;
    scanf("%d ",&n);
    	char a[20];
    	gets(a);
	sum=0;
	for(i=n-1;i>=0;i--)
	{
	if(a[i-1]=='1')
	sum+=pow(2,n-i);
	else
	sum+=0;
	}
	if(a[n-1]=='1')
	sum=sum+1;
	printf("%d",sum);
	return 0;
}

