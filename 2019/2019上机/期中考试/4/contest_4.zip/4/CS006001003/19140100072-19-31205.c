#include"stdio.h"
int pl(int a);
int main()
{
	int n,m,i,a,s=0;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		a=m%10;
		if(a==1)
		s+=pl(i);
		m=m/10;
	}
	printf("%d",s);
}
int pl(int a)
{
	int s=1;
	int i;
	for(i=1;i<=a;i++)
	{
		s*=2;
	}
	return s;
}
