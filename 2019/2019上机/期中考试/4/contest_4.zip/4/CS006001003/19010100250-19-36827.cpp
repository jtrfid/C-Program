#include "stdio.h"
#include "math.h"
int main()
{
	int m,n,p,i;
	((n>0)&&(n<=20));
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++) 
	{
		p=100;
	}
    printf("%d",p);
	return 0;
}
