#include<stdio.h>
int main()
{
	int i,x,t,sn=0;

	
	scanf("%d %d",&x,&t);
	if(t>0&&t<=20)
	{
	
	if(x<50&&x>0)
	{
	for(i=1;i<=t;i++)
	   {
		x=x*1.02;
		sn=x;
	   }	
	}
	else if(x>=50&&x<200)
	{
	for(i=1;i<=t;i++)
	  {
		x=x*1.03;
		sn=x;
	  }	
	}
	else if(x>=200&&x<500)
	{
	for(i=1;i<=t;i++)
	  {
		x=x*1.04;
		sn=x;
	  }	
	}
	else if(x>=500&&x<=2000)
	{
	for(i=1;i<=t;i++)
	  {
		x=x*1.05;
		sn=x;
	  }	
	}
	else if(x>2000)
	{
	for(i=1;i<=t;i++)
	  {
		x=x*1.06;
		sn=x;
		
	  }	
	}
	printf("%d",sn);
 }
 
	return 0;
}
