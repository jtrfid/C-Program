#include<stdio.h>
int main()
{
	int i,x,t,sn=0;

	
	scanf("%d %d",&x,&t);
      for(i=1;i<=t;i++)
      {
      	if(x>0&&x<50)
      	{
      		x=x*1.02;
      		sn=x;
      	}
      	else if(x>=50&&x<200)
      	{
      		x=x*1.03;
      		sn=x;
      	}
      	else if(x>=200&&x<500)
      	{
      		x=x*1.04;
      		sn=x;
      	}
      	else if(x>=500&&x<2000)
      	{
      		x=x*1.05;
      		sn=x;
      	}
      	else if(x>=2000)
      	{
      		x=x*1.06;
      		sn=x;
      	}
      	if(t==20)
      	break;
      }
      printf("%d",sn);
      return 0;
	  }
      
