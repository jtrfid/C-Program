#include"stdio.h"
int fun(int a)
{
   int i=0;
   for(i=2;i<a;i++)
   {
        if(a%i==0)
        {
          return 1;   
        }
        else if((a%i!=0)&&(i==a-1))
        {
           return 0;   
        }
   }
      
}
int main()
{
   int m,s=0,i=0;
   scanf("%d",&m);
   int a,b;
   a=m*m;
   b=(m+1)*(m+1);
   for(i=a;i<=b;i++)
   {
      if(fun(i)==0)
      {
        s=s+i; 
      }  
      else
      {
          s=s;   
        }
    } 
    printf("%d",s);
    getchar();
    getchar();
   return 0;   
}
