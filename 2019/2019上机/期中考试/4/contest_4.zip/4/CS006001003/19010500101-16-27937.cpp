#include<stdio.h>
#include<math.h>

int main()
{
	int x;
	double j,y;
	scanf("%d",&x);
	if((x>=-100)&&(x<=12))
	{
		j=sqrt(2019-x*x*x+x);
		y=j/(x-10);
	    printf("%.2lf",y);
    }
	else
	printf("no");
	return 0;
}
