#include"stdio.h"
int prim(int a);
int main()
{
	int m,j,sum;
	scanf("%d",&m);
	sum=0;
	for(j=m*m;j<=(m+1)*(m+1);j++)
	{
		if(prim(j))
		sum+=j;
		else
		sum+=0;
	}
	printf("%d",sum);
	return 0;
}
int prim(int a)
{
   int i,flag;
   flag==1;
   for(i=2;i<a;i++)
   {
    if(a%i==0)
   {
   	flag=0;
   	break;
   }
   	else
   	flag=1;
   }	
	if(flag==1||a==2)
	return 1;
	if(flag==0)
	return 0;
}
