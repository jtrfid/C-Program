#include "stdio.h"
#include "math.h"
int main()
{
	int x,t,sum=0,i;
	scanf("%d %d",&x,&t);
	if(x<50000)
	{
        if((t<=20)&&(t>0))
		{
			sum=pow(1.02*x,t);
		}
		else if(t>20)
		{
			sum=pow(1.02*x,20);
		}
	}
	else if((50000<=x)&&(x<200000))
	{
		if((t<=20)&&(t>0))
		{
			sum=pow(1.03*x,2);
		}
		else if(t>20)
		{
			sum=pow(1.03*x,20);
		}
	}
	else if((200000<=x)&&(500000>x))
	{
		if((t<=20)&&(t>0))
		{
			sum=pow(1.04*x,t);
		}
		else if(t>20)
		{
			sum=pow(1.04*x,20);
		}
	}
	else if((x>=500000)&&(x<2000000))
	{
		if((t<=20)&&(t>0))
		{
			sum=pow(1.05*x,t);
		}
		else if(t>20)
		{
			sum=pow(1.05*x,20);
		}
	}
	else if(x>=2000000)
	{
		if((t<=20)&&(t>0))
		{
			sum=pow(1.06*x,t);
		}
		else if(t>20)
		{
			sum=pow(1.06*x,20);
		}
	}
    printf("%d",sum);
	return 0;
}
