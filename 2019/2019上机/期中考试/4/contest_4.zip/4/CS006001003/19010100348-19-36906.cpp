#include"stdio.h"
#include"math.h"

int main()
{
   int  n,m,s=0,i=0;
   scanf("%d%d",&n,&m);
   int a=0,b=0,c=0,d;
   for(i=1;i<=n;i++)
   {
      b=pow(10,i);
      c=pow(10,i-1);
      a=(m%b)/c;
      if(a==0)
      {
            s=s+0;
          continue;   
        }   
        else if(a==1)
        {
            d=pow(2,i-1);
          s=s+d;  
        }
    }
      printf("%d",s);
      getchar();
      getchar();
   return 0;   
}
