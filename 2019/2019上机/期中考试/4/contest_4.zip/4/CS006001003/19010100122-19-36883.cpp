#include "stdio.h"
#include "math.h"
int main()
{
	int a,b,i,c,d,e,sum=0;
	scanf("%d %d",&i,&a);
	d=a;
	for(b=0;b<i;b++)
	{
		e=10*(i-b-1);
		d=d/e;
		c=d;
		d=a%e;
		sum=c*pow(2,i-b-1)+sum;
	}
	printf("%d",sum);
	return 0;
}
