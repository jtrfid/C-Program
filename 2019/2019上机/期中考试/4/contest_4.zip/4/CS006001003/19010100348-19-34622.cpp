#include"stdio.h"
#include"math.h"

int main()
{
   int  n,m,s=0,b,c,a,i=0;
   scanf("%d%d",&n,&m);
   for(i=1;i<=n;i++)
   {
      b=pow(10,i);
      c=pow(10,i-1);
      a=(m%b)/c;
      if(a==0)
      {
          continue;   
        }   
        else if(a==1)
        {
          s=s+pow(2,i);  
        }
    }
      printf("%d",s);
      getchar();
      getchar();
   return 0;   
}
