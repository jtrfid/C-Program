#include<stdio.h>
int main()
{
	int m,n;
	int i,mi,ni,flag,sum,p;
	scanf("%d %d",&m,&n);
	flag=n;
	sum=0;
	ni=1;
	for(i=1;i<=m;i++)
	{
		p=1;
		ni=ni*2;
		mi=flag%10;
		flag=flag/10;
		if(mi!=0)
		{
			p=p*ni/2;
			sum=sum+p;
		}
	}
	printf("%d",sum);
	return 0;
}
