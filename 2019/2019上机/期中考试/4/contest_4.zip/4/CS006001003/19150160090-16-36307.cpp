#include <stdio.h>
#include <math.h>
int main ()
{
	int x;
    float y;
	scanf ("%d ,%x);
	if("x<);
	
	return 0;
}
