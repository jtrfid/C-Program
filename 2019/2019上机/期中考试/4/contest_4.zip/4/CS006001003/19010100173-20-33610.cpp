#include<stdio.h>
int main()
{	int m,t,i,sum=0;
	scanf("%d",&m);
	for(t=m*m;t<=(m+1)*(m+1);t++)
		{for(i=2;i<=t-1;i++)
			{if(t%i==0)
				{break;
				}
			}
			if(i==t)
				{sum=sum+t;
				}	
			
		}
		printf("%d",sum);
	return 0;
}
