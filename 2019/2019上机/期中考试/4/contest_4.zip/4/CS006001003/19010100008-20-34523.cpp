#include<stdio.h>
int f(int num);
int main()
{
	int m,i,x,j;
	int sum=0;
	scanf("%d",&m);
	x=m*m;
	j=(m+1)*(m+1);
	while(x<j)
	{
		x++;
		if(f(x)==1)
		{
			sum=sum+x;
		}
		
	}
	printf("%d",sum);
	return 0;
}
int f(int num)
{
	int i;
	int flag=1;
	for(i=2;i<num;i++)
	{
		if(num%i==0)
		{
			flag=0;
			break;
		}
	}
	return flag;
}
