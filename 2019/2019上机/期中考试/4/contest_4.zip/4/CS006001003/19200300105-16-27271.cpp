#include<math.h>
#include<stdio.h>
int main()
	{
		double x,y;
		scanf ("%lf",&x);
		if (x>=-100&&x<=12)
			{
				y=sqrt(2019-x*x*x+x);
				y=y/(x-10);
				printf ("%.2lf",y);
			}
		else printf ("no");
		return 0;	
	}
