#include"stdio.h"
   
int main()
{
   int x,t,i=0;
   scanf("%d%d",&x,&t);
   int a;
   a=x;
   int b;
   if(t<=20)
   {
       if(x<50000)
       {
          b=2;     
       }
       else if((x>=50000)&&(x<200000))
       {
          b=3;   
        }
        else if((x>=200000)&&(x<500000))
        {
          b=4;   
        }
        else if((x>=500000)&&(x<2000000))
        {
           b=5;   
        }
        else
        {
               b=6;
        }
             for(i=1;i<=t;i++)
        {
           a=a*(1+b/100.0);   
        }
    }
    else
    {
             for(i=1;i<=20;i++)
        {
           a=a*(1+b/100.0);   
        }
   
    }
    printf("%d",a);
    getchar();
    getchar();
   return 0;   
}
