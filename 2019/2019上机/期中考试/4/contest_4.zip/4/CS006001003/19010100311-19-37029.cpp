#include "stdio.h"
int main()
{int m,n,shu;
scanf("%d %d",&n,&m);
shu=100;
printf("%d",shu);
return 0;
}
