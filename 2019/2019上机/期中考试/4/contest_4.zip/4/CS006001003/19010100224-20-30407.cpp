#include"stdio.h"
int zhishu(int i)
{
	int z=i/2;
	for(int j=2;j<z;j++)
	{
		if(i%j==0)
		{
			return 0;
			break;
		}
	}
	return 1;
}
int main()
{
	int m,i,sum=0;
	scanf("%d",&m);
	for(i=m*m;i<=(m+1)*(m+1);i++)
	{
		if(zhishu(i)==1)
		{
			sum+=i;
		}
	}
	printf("%d",sum);
	return 0;
}
