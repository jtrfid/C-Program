#include <stdio.h>
int main()
{
	int  i,j,s,m,sum=0;
	scanf("%d",&m);
	for(i=m*m;i<=(m+1)*(m+1);i++)
	{
		sum+=i;
		for(j=2;j<i;j++)
		{
			if(i%j==0) 
			{
				sum-=i;
				break;
			}
		}
	}
	printf("%d",sum);
	return 0;
}
