#include <stdio.h>
#include <math.h>
int main()
{
	int x,i,t,y;
	scanf("%d %d",&x,&t);
	if(x>0&&x<50000&&t>0&&t<50)
	{
		y=pow(1.02,t)*x;
	}
	else if(x>=50000&&x<200000)
	{
		y=pow(1.03,t)*x;
	}
	else if(x>=200000&&x<500000)
	{
		y=pow(1.04,t)*x;
	}	
	else if(x>=500000&&x<2000000)
	{
		y=pow(1.05,t)*x;
	}	
	else if(x>=2000000)
	{
		y=pow(1.06,t)*x;
	}
	
	
	printf("%d",y);
		
	
	return 0;
}
