#include <stdio.h>
#include <math.h>
int main()
{
	int m,n,j,k=0,z,t,sum=0;
	scanf("%d %d",&n,&m);
	t=m;
	z=n;
	while(z>0&&n<=20)
	{
		j=t%10;
		if(j==0)
		{
			sum=sum;
		}
		else
		{
			sum+=pow(2,k);
		}
		t=t/10;
		k++;
		z--;
		
	}
	printf("%d",sum);
	return 0;
}
