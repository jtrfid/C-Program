#include<stdio.h>
int main()
{
	int m,n,sum;
	sum=0;
	scanf("%d %d",&m,&n);
	while(m<=n)
	{
		
		sum=sum+m*m;
        m=m+1;
		
	}
	printf("%d",sum);
	return 0;
}
