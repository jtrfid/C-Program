#include"stdio.h"
int main()
{
	int x,y,i,z;
	scanf("%d %d",&x,&y);
	z=x;
	for(i=1;i<=y;i++)
	{
		if(z<50000)
		{
			z=z*(1+0.02);
		}
		else if(z>=50000&&z<200000)
		{
			z=z*(1+0.03);
		}
		else if(z>=200000&&z<500000)
		{
			z=z*(1+0.04);
		}
		else if(z>=500000&&z<2000000)
		{
			z=z*(1+0.05);
		}
		else if(z>=2000000)
		{
			z=z*(1+0.06);
		}
	}
	printf("%d",z);
	return 0;
}
