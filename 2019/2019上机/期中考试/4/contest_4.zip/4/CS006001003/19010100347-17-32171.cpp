#include "stdio.h"
int main()
{
    int x,t,i;
    float n;
    float y;
    scanf("%d %d",&x,&t);
    y=1.0*x;
    x=x/10000;
    if(x<5)
    {
        n=0.02;
    }
    else if((x>=5)&&(x<20))
    {
        n=0.03;
    }
    else if((x>=20)&&(x<50))
    {
        n=0.04;
    }
    else if((x>=50)&&(x<200))
    {
        n=0.05;
    }
    else
    {
        n=0.06;
    }
    if(t>=20)
    {
      for(i=1;i<=20;i++)
      {
         y=y*(1+n);
      }    
    }
    else
    {
        for(i=1;i<=t;i++)
        {
            y=y*(1+n);
        }
    }
    printf("%d",(int)y);
    getchar();
    getchar();
    return 0; 
}
