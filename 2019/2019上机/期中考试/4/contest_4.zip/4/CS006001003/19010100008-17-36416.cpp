#include<stdio.h>
int main()
{
	float x,t;
	int i;
	scanf("%f %f",&x,&t);
	if(x<50000)
	{
		for(i=1;i<=t&&x<50000;i++)
		{
			x=x+x*0.02;
			if(i>=20)break;
		}
	}
	else
	{
		if(x>=50000&&x<200000)
		{
			for(i=1;i<=t&&x<200000;i++)
		{
			x=x+x*0.03;
			if(i>=20)break;
		}
		}
		else
		{
			if(x>=200000&&x<500000)
			{
				for(i=1;i<=t&&x<500000;i++)
				{
					x=x+x*0.04;
					if(i>=20)break;
				}
			}
			else
			{
				if(x>=500000&&x<2000000)
				{
					for(i=1;i<=t&&x<2000000;i++)
					{
						x=x+x*0.05;
						if(i>=20)break;
					}
				}
				else
				{
					for(i=1;i<=t;i++)
					{
						x=x+x*0.06;
						if(i>=20)break;
					}
				}
			}
		}
	}
	printf("%.0f",x);
	return 0;
}
