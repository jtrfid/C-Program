#include<stdio.h>
int main()
{
	int x,t;
	scanf("%d %d",&x,&t);
	int m=1;
	if(t>20)
	{
		printf("%d",x);
		return 0;
	}
    for( ;x<50000&&m!=(t+1);++m)
	{
    	x=x*1.02;
	}
	for( ;x<200000&&x>=50000&&m!=(t+1);++m)
	{
		x=x*1.03;
	}
	for( ;x<500000&&x>=200000&&m!=(t+1);++m)
	{
		x=x*1.04;
	}
	for( ;x<2000000&&x>=500000&&m!=(t+1);++m)
	{
		x=x*1.05;
	}
	for( ;x>=2000000&&m!=(t+1);++m)
	{
		x=x*1.06;
	}
	printf("%d",x);
	return 0;
}
