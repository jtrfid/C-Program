#include <stdio.h>

int main()
{
	int t;
    float m;
	scanf("%f %d",&m,&t);
	int i=1;
	do
	{
		if(m<50000)
		m=1.02*m;
		else if(m<200000)
		m=1.03*m;
		else if(m<500000)
		m=1.04*m;
		else if(m<2000000)
		m=1.05*m;
		else m=1.06*m;
		i++;
		if(i==20)
		break;
	}
	while(i<=t);
	printf("%.0f\n",m);
	return 0;
}
