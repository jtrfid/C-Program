#include"stdio.h"
int main()
{
	int m,i,p,q,j,sum,a;
	sum=0;
	scanf("%d",&m);
	p=m*m;
	q=(m+1)*(m+1);
	for(i=p;i<=q;i++)
	{
		a=0;
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			{
				a=1;
			}
		}
		if(a==0)
		sum=sum+i;
	}
	printf("%d",sum);
	return 0;
}
