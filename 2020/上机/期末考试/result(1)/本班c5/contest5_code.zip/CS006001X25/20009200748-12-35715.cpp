#include<stdio.h>
#include<math.h>
int main()
{
	double n,m;
	int i,j,a[100],t;
	scanf("%lf%lf",&n,&m);
	t  = n;
	for( i = 0; i < pow(2,n);i++)
	{
		scanf("%d",&a[i]);
	}
	for( i = 0; i < m; i++)
	{
		for( j = 0; j < pow(2,n-1);j++) 
		{
			a[j] = a[j] + a[(int)pow(2,n)-1-j];
		}
		n = n-1;
	}
	for(i = 0; i < pow(2,t-m);i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
