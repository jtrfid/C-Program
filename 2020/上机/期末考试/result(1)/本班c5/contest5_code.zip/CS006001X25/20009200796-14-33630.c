#include <stdio.h>
#include <math.h>
int main()
{
	int temp=0,m=0,n=0,i=0,j=0,k=0,a[10][10]={0};
	scanf("%d %d",&m,&n);
	for(i=0;i<m;++i)
	{
		for(j=0;j<n;++j)
		{
			scanf("%d",&a[i][j]);
		}
	}
	
	for(i=0;i<m;++i)
	{
		for(j=0;j<n-1;++j)
		{
			for(k=0;k<n-1-j;++k)
			{
				if(a[i][k]<a[i][k+1])
				{
					temp=a[i][k],a[i][k]=a[i][k+1],a[i][k+1]=temp;
				}
			}
		}
	}
	
	for(i=0;i<m;++i)
	{
		for(j=0;j<n;++j)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	
	
	return 0;
}
