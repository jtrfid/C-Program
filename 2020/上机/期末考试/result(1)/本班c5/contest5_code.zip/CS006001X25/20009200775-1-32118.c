#include<stdio.h>
int main()
{
	int m,n,i,ou=0,ji=0,shu=0,max;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2==0)
		{
			ou+=1;
		}
		if(i%2!=0)
		{
			ji+=1;
		}
		if(i%3==0&&i%7!=0)
		{
			shu+=1;
		}
	}
	max=(ou>ji?ou:ji);
	max=(max>shu?max:shu);
	printf("%d %d %d",ou,ji,shu);
	printf("\n%d",max);
}
