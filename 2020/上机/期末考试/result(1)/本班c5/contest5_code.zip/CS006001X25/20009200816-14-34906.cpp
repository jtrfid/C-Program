#include<stdio.h>
int main()
{
	int m,n;
	int a[10][10];
	scanf("%d %d",&m,&n);
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int t=0;t<m;t++)
	{
		for(int j=0;j<n-1;j++)
		{
			int k,h;
			for(k=j+1,h=j;k<n;k++)
			{
				if(a[t][k]>a[t][j])
				{
					h=k;
				}
			}
			if(h!=j)
			{
				int temp=a[t][j];
				a[t][j]=a[t][h];
				a[t][h]=temp;
			}
		}
	}
	for(int p=0;p<m;p++)
	{
		for(int q=0;q<n;q++)
		{
			printf("%d ",a[p][q]);
		}
			printf("\n");
	}
	return 0;
}
