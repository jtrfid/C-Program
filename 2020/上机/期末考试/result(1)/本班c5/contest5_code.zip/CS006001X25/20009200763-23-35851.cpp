#include<stdio.h>
#include<math.h>
typedef struct{
	int num;
	int x;
	int y;
}student;
int main()
{
	int n;
	student stu[1000]; 
	scanf("%d",&n);
	
	for(int i=1;i<=n;i++)
	{
		scanf("%d %d %d",&stu[i].num,&stu[i].x,&stu[i].y);
	}
	
	float min=100000.;
	int flag;
	for(int i=1;i<=n;i++)
	{
		float sum=0.;
		for(int j=1;j<=n;j++)
		{
			float dx=fabs(stu[i].x-stu[j].x);
			float dy=fabs(stu[i].y-stu[j].y);
			sum+=sqrt(pow(dx,2)+pow(dy,2));
		}
		
		if(sum<min)
		{
			flag=stu[i].num;
			min=sum;
		}
		
		if(sum==min && stu[i].num>flag)
		{
			flag=stu[i].num;
		}
	}
	
	printf("%d %.2f",flag,min);
	
	return 0;
}
