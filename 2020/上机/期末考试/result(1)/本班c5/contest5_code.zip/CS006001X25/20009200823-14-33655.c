#include<stdio.h>
int main()
{
	int a[10][10];
	int m, n, i, j, x, t;
	scanf("%d %d",&m,&n);
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			scanf("%d", &a[i][j]);
		}
	}
	for(i=0; i<m; i++){
		for(x=0; x<n-1; x++){
			for(j=0; j<n-1-x; j++){
				if (a[i][j]<a[i][j+1]){
					t=a[i][j+1];
					a[i][j+1]=a[i][j];
					a[i][j]=t;
				}
			}
		}
	}
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;

}
