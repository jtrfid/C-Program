#include <stdio.h>

int main ()
{
	int m=0,n=0;
	int a=0,b=0,c=0;
	int i=0;
	
	scanf ("%d %d",&m,&n);
	for (i=m;i<=n;i++) {
		if (i%2==0) {
			a++;
		} else if (i%2!=0) {
			b++;
		}
		if (i%3==0 && i%7!=0) {
			c++;
		}
	}
	
	printf ("%d %d %d\n",a,b,c);
	if (a>b) {
		printf ("%d",a);
	} else {
		printf ("%d",b);
	}
	
	return 0;
}
