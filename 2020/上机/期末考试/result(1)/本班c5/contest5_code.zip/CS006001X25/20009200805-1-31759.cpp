#include<stdio.h>
int main()
{
	int m,n,o=0,j=0,q=0,max;
	scanf("%d %d",&m,&n);
	for(int i=m;i<=n;i++)
	{
		if(i%2==0)
		{
			o++;
		}
		if(i%2!=0)
		{
			j++;
		}
		if(i%3==0&&i%7!=0)
		{
			q++;
		}
	}
	max=o>j?o:j;
	if(q>max)
	{
		max=q;
	}
	printf("%d %d %d\n",o,j,q);
	printf("%d",max);
	return 0;
}
