#include<string.h>
struct p{
	int num;
	int x;
	int y;
}sdu[100000];

#include<stdio.h>
#include<math.h>
int main()
{
	int n, i, j;
	float d=0;
	scanf("%d", &n);
	for(i=1; i<=n; i++){
		scanf("%d %d %d", &sdu[i].num, &sdu[i].x, &sdu[i].y);
	}
	d=sqrt((sdu[1].x-sdu[n].x)*(sdu[1].x-sdu[n].x)+(sdu[1].y-sdu[n].y)*(sdu[1].y-sdu[n].y));
	for(i=2; i<n; i++){
		d+=sqrt((sdu[i].x-sdu[n].x)*(sdu[i].x-sdu[n].x)+(sdu[i].y-sdu[n].y)*(sdu[i].y-sdu[n].y));
	}
	printf("%d %.2f", sdu[n].num, d);
	return 0;
}
