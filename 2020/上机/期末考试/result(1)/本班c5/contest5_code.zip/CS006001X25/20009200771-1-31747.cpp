#include<stdio.h>
#include<string.h>

int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int ou=0,ji=0,ne=0,max=0;
	int i,j;
	for(i=m;i<=n;i++){
		if(i%2==0){
			ou++;
		}
		if(i%2!=0){
			ji++;
		}
		if(i%3==0&&i%7!=0){
			ne++;
		}
	}
	printf("%d %d %d\n",ou,ji,ne);
	if(ou>max){
		max=ou;
	}
	if(ji>max){
		max=ji;
	}
	if(ne>max){
		max=ne;
	}
	printf("%d",max);
	return 0;
}
