#include<stdio.h>
#include<math.h>
int main(){
	int n,m,i,j,s1,s2,x;
	int a[100][100],s[100];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		for(j=0;j<3;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n-1;i++){
		s1=pow(a[i][1]-a[i+1][1],2);
		s2=pow(a[i][2]-a[i+1][2],2);
		s[i]=sqrt(s1+s2);
		x=i;
	}
	for(j=0;j<3;j++){
	    printf("%d",a[x][j]);
}
    return 0;
}
