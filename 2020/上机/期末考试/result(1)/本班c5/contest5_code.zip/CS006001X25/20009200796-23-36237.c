#include <stdio.h>
#include <math.h>
struct N
{
	int n;
	int x;
	int y;
};
int main()
{
	struct N s[100000];
	int m=0,i=0,j=0,k=0,index=0,temp=0;
	float sum=0,dis[10000]={0};
	scanf("%d",&m);
	for(i=0;i<m;++i)
	{
		scanf("%d %d %d",&s[i].n,&s[i].x,&s[i].y);
	}
	for(i=0;i<m;++i)
	{
		for(j=0;j<m;j++)
		{
			sum+=sqrt(pow((s[i].x-s[j].x),2)+pow((s[i].y-s[j].y),2));
		}
		dis[i]=sum;
		printf("(%f)",dis[i]);
	}
	
	float min=dis[0];
	for(i=1;i<m;++i)
	{
		if(min>=dis[i])
		{
			min=dis[i],index=i;
		}
	}
	printf("%d %.2f",index+m,min);
	
	
	
	return 0;
}
