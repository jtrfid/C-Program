#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
const int maxn=1e5+5;
struct aaa{double num,x,y;
}p[maxn];
double d[maxn];
double dis(double x1,double y1,double x2,double y2)
{
	double dist=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    return dist;
}
int main()
{
	int N,ans=0;
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	scanf("%lf %lf %lf",&p[i].num,&p[i].x,&p[i].y);
	for(int i=1;i<=N;i++)
	{
		for(int j=1;j<=N;j++) d[i]+=dis(p[i].x,p[i].y,p[j].x,p[j].y);
	}
	double min=d[1];
	for(int i=2;i<=N;i++)
	if(d[i]<min) min=d[i];
	for(int i=1;i<=N;i++)
	if(d[i]==min) ans=i;
	printf("%d %.2lf",ans,min);
	return 0;
}

