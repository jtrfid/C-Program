#include<stdio.h>
int main()
{
	int m,n,a[10000]={0},i;
	scanf("%d %d",&m,&n);
	for(i=0;i<=(n-m);i++)
	{
		a[i]=i+m;
	}
	int count_o=0,count_j=0,count=0;
	for(i=0;i<=(n-m);i++)
	{
		if(a[i]%2==1)
		count_j++;
		if(a[i]%2==0)
		count_o++;
		if(a[i]%3==0&a[i]%7!=0)
		count++;
	}
	printf("%d %d %d\n",count_o,count_j,count);
	int max;
	max=count_o;
	if(count_j>max)
	max=count_j;
	if(count>max)
	max=count;
	printf("%d",max);
	return 0;
}
