#include<stdio.h>
#include<math.h>
int main()
{
	int n, m, i, j, t, x;
	int a[100];
	scanf("%d %d", &n, &m);
	for(i=0; i<pow(2,n); i++){
		scanf("%d", &a[i]);
	}
	t=pow(2,n);
	
//	for(x=1; x<=m; x++){
//	i=0;
//	j=0;
	for(i=0,j=0; i<pow(2,n-1); i++,j++){
		a[j]=a[i]+a[t-i-1];
	}
	n--;
//	}
    t=pow(2,n);
	for (j=0; j<t; j++){
		printf("%d ", a[j]);}
	return 0;
}
