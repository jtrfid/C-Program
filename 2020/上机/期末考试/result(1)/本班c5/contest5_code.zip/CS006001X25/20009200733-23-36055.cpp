#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define EPS 0.0000001

typedef struct tagMAN{
	int id,x,y;
}MAN,*PMAN;

int _cmp(const void *p1,const void *p2){
	return *(int*)p2-*(int*)p1;
}

int main(){
	int i,j,m,dx,dy;
	scanf("%d",&m);
	PMAN map=(PMAN)malloc(m*sizeof (MAN));
	for (i=0;i<m;i++){
		scanf("%d %d %d",&map[i].id,&map[i].x,&map[i].y);
	}
	double dist,maxdist=-1;int max=0;
	MAN man;
	for (i=0;i<m;i++){
		dist=0;
		man=map[i];
		for (j=0;j<m;j++){
			dx=man.x-map[j].x;
			dy=man.y-map[j].y;
			if (dx||dy)dist+=sqrt(dx*dx+dy*dy);
			//printf("#%d %d - %.2f\n",i,j,sqrt(dx*dx+dy*dy));
		}
		//printf("$\t%.2f\n",dist);
		if (i==0){
			maxdist=dist,max=j;
		}else{
			if (1/*fabs(maxdist-dist)<=EPS*/){
				if (man.id<map[j].id)max=j;
			}else if (maxdist>dist){
				maxdist=dist,max=j;
			}
		}
	}
	printf("%d %.2f\n",max,maxdist);
	free(map);
	return 0;
}
