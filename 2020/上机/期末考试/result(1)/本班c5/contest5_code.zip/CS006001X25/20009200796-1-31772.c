#include <stdio.h>
int main()
{
	int m=0,n=0,i=0,j=0,k=0;
	scanf("%d %d",&m,&n);
	for(;m<=n;++m)
	{
		if(m%2==0)i++;
		if(m%2==1)j++;
		if(m%3==0&&m%7!=0)k++;
	}
	printf("%d %d %d\n",i,j,k);
	int max=i;
	if(j>max)max=j;
	if(k>max)max=k;
	printf("%d",max);
	
	
	
	
	
	return 0;
}
