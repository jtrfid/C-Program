#include<stdio.h>
#include<math.h>



typedef struct{
	int b;
	double x;
	double y;
	double z;
}stu;

int cmp(stu a,stu b)
{
	if(a.z==b.z)
	{
		if(a.b>b.b)
		{
			return -1;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		return (a.z-b.z);
	}
}

int main()
{
	int n;
	scanf("%d",&n);
	stu a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d %lf %lf",&a[i].b,&a[i].x,&a[i].y);
	}
	for(int i=0;i<n;i++)
	{
		a[i].z=0;
		for (int j=0;j<n;j++)
		{
			a[i].z+=sqrt(pow(a[j].x-a[i].x,2)+pow(a[j].y-a[i].y,2));
		}
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(cmp(a[j],a[j+1])>0)
			{
				stu t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	printf("%d %.2f",a[0].b,a[0].z);
	return 0;
}
