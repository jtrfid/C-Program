#include<stdio.h>
int ifou(int x)
{
    if(x%2==0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int ifji(int x)
{
    if(x%2!=0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int main(void)
{
    int m,n;
    int i;
    int a[3]={0,0,0},max;
    scanf("%d %d",&m,&n);
    for(i=m;i<=n;i++)
    {
        if(ifou(i)==1)
        {
            a[0]++;
        }
        else if(ifji(i)==1)
        {
            a[1]++;
        }
        else if(i%3==0&&i%7!=0)
        {
            a[2]++;
        }
    }
    for(i=0;i<=2;i++)
    {
        printf("%d ",a[i]);
    }
    max=a[0];
    for(i=1;i<=2;i++)
    {
        if(a[i]>max)
        {
            max=a[i];
        }
    }
    printf("%d",max);
    return 0;
}
