#include<stdio.h>
#include<math.h>
void sort(double s[],int id[],int n)
{
	int i,j=0;
	double t;
	int t1;
	int change=1;
	while(change)
	{
		change=0;
		for(i=0;i<n-1-j;i++)
		{
			if(s[i]>s[i+1])
			{
				t=s[i];
				s[i]=s[i+1];
				s[i+1]=t;
				t1=id[i];
				id[i]=id[i+1];
				id[i+1]=t1;
				change=1;
			}
			else if(s[i]==s[i+1])
			{
				if(id[i]<id[i+1])
				{
					t=s[i];
					s[i]=s[i+1];
					s[i+1]=t;
					t1=id[i];
				    id[i]=id[i+1];
				    id[i+1]=t1;
				    change=1;
				}
			}
		}
		j++;
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	int x[100000]={0};
	int y[100000]={0};
	int id[100000]={0};
	double s[100000]={0};
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&id[i],&x[i],&y[i]);
	}
	int j; 
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			s[i]+=sqrt(pow((x[i]-x[j]),2)+pow((y[i]-y[j]),2));
		}
	}
	sort(s,id,n);
	printf("%d %.2f",id[0],s[0]);
	return 0;
}
