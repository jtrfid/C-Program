#include<stdio.h>
#include<string.h>

int main()
{
	int m,n;												//m���У�n���� 
	scanf("%d %d",&m,&n);
	int a[100][100]={0},i,j;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	int b,c,t,h;
	for(i=0;i<m;i++){										//�ӵ�һ�п�ʼ���� 
		for(b=0;b<n;b++){
			for(c=b+1;c<n;c++){
				h=b;
				if(a[i][c]>a[i][h]){
					h=c;
				}
				if(h!=b){
					t=a[i][b]; a[i][b]=a[i][h];  a[i][h]=t;
				}
			}
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}
