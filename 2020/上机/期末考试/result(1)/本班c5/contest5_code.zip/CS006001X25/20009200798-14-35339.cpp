#include<stdio.h>
int main()
{
	int m,n,a[10][10],i,j,l,t;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(l=1;l<n;l++)
		{
			for(j=0;j<n-1;j++)
			{
				if(a[i][j]>a[i][j+1])
				{
					t=a[i][j];
					a[i][j]=a[i][j+1];
					a[i][j+1]=t;
				}
			}
		}
	}
    for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d",&a[i][j]);
		}
	}
	return 0;
}
