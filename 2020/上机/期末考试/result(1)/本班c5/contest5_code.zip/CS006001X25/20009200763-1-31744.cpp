#include<stdio.h>
int main()
{
	int m,n,ji=0,ou=0,cnt=0;
	scanf("%d %d",&m,&n);
	
	for(int i=m;i<=n;i++)
	{
		if(i%2==0) ou++;
		if(i%2!=0)ji++;
		if(i%3==0 && i%7!=0) cnt++;
	}
	printf("%d %d %d\n",ou,ji,cnt);
	if(ji>=ou && ji>=cnt) printf("%d",ji);
	else if(ou>=ji && ou>=cnt) printf("%d",ou);
	else printf("%d",cnt);
	
	
	return 0;
}
