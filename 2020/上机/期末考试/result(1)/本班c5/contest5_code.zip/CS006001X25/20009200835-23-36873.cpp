#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j,l;
	double sum=0;
	scanf("%d",&n);
	int a[n][3];
	double sum1[n];
	for(i=0;i<n;i++)
	{scanf("%d %d %d",&a[i][0],&a[i][1],&a[i][2]);
	}
	
	for(j=0;j<n;j++)
	{
	for(l=0;l<n;l++)
	{
	sum=sum+sqrt(((a[l][1]-a[j][1])*(a[l][1]-a[j][1]))+((a[l][2]-a[j][2])*(a[l][2]-a[j][2])));
	}
	
	sum1[j]=sum;
	sum=0;
	}
	int k=0,min;
	for(i=1;i<n;i++)
	{if(sum1[0]>sum1[i])
	{k=i;
	sum1[0]=sum1[i];
	}
	else if(sum1[0]==sum1[i])
	k=i;
	}
	printf("%d %.2lf",k+1,(double)sum1[0]);
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
