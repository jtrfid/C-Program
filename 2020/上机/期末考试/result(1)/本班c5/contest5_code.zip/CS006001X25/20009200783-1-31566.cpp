#include<cstdio>
int l,r,ans1,ans2,ans3;
int max(int a,int b){return a>b?a:b;}
int main()
{
	scanf("%d%d",&l,&r);
	for(int i=l;i<=r;i++)
	{
		if(i&1)ans2++;else ans1++;
		if((!(i%3))&&(i%7))ans3++;
	}
	printf("%d %d %d\n",ans1,ans2,ans3);
	printf("%d\n",max(max(ans1,ans2),ans3));
}
