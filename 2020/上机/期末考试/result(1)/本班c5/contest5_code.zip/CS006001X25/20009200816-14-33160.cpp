#include<stdio.h>
void sort(int a[],int n)
{
	for(int i=0;i<n-1;i++)
	{
		int j,k;
		for(j=i+1,k=i;j<n;j++)
		{
			if(a[j]>a[i])
			{
				k=j;
			}
		}
		if(k!=i)
		{
			int temp=a[i];
			a[i]=a[k];
			a[k]=temp;
		}
	}
}
int main()
{
	int m,n;
	int a[10][10];
	scanf("%d %d",&m,&n);
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int t=0;t<m;t++)
	{
		sort(a[t],n);
	}
	for(int p=0;p<m;p++)
	{
		for(int q=0;q<n;q++)
		{
			printf("%d ",a[p][q]);
		}
			printf("\n");
	}
	return 0;
}
