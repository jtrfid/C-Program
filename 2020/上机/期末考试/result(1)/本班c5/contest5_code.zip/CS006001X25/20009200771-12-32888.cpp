#include<stdio.h>
#include<string.h>

int main()
{
	int m,n;
	scanf("%d %d",&n,&m);
	int a[100]={0},i,j,b=1;
	for(i=0;i<n;i++){
		b*=2;
	}
	for(i=0;i<b;i++){
		scanf("%d",&a[i]);
	}
	int h=0,k,g;												//g�������鵱ǰ���� 
	k=b/2;
	g=b;
	for(i=0;i<m;i++){											//�۵�m�� 
		for(h=0;h<k;h++){
			a[h]=a[h]+a[g-1-h];
		}
		g/=2;
		k/=2;
	}
	for(i=0;i<g;i++){
		printf("%d ",a[i]);
	}
	return 0;
}
