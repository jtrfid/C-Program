#include<stdio.h>
int main()
{
	int m,n,i,j,a=0,b=0,c=0;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2==0)
		a++;
    }
    b=n-m+1-a;
	for(i=m;i<=n;i++)
	{
		if(i%3==0&&i%7!=0)
		c++;
	}
	printf("%d %d %d\n",a,b,c);
	int s[3];
	s[0]=a;
	s[1]=b;
	s[2]=c;
	int max=0;
	for(int j=0;j<3;j++)
	{
		if(s[j]>max)
		max=s[j];
	}
	printf("%d",max);
	return 0;
}
