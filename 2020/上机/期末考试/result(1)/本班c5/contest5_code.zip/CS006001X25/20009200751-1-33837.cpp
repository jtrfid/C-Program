#include <stdio.h>
int main(){
	int m,n;
	int e=0,o=0,d=0;
	scanf("%d %d",&m,&n);
	int x;
	for( x=m ; x<=n ; x++ ){
		if( x%2==0 ){
			e++;
		}
		if( x%2!=0 ){
			o++;
		}
		if( x%3==0 && x%7!=0 ){
			d++;
		}
	}
	
	int max=-1;
	if( e>o ){
		max=e;
	}
	
	if( max==e && d>e ){
		max=d;
	}
	else if( max!=e && d>o ){
		max=d;
	}
	
	if( max!=e && max!=d ){
		max=o;
	}
	
	printf("%d %d %d\n%d",e,o,d,max);
	
	return 0 ;
}

