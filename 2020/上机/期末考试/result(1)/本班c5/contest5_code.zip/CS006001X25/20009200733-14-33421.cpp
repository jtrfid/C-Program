#include <stdio.h>
#include <stdlib.h>

int _cmp(const void *p1,const void *p2){
	return *(int*)p2-*(int*)p1;
}

int main(){
	int i,j,m,n,c,base;
	scanf("%d %d",&m,&n);
	c=m*n;
	int *map=(int*)malloc(c*sizeof (int));
	for (i=0;i<c;i++){
		scanf("%d",map+i);
	}
	for (i=0;i<m;i++){
		base=i*n;
		qsort(map+base,n,sizeof (int),&_cmp);
		for (j=0;j<n;j++){
			printf("%d %c",map[base+j],(j+1==n)?'\n':' ');
		}
	}
	free(map);
	return 0;
}
