#include<stdio.h>
int main()
{
	int m,n,i,count1 = 0,count2 = 0,count3 = 0,max;
	scanf("%d%d",&m,&n);
	for(i = m; i <= n;i++)
	{
		if(i % 2 ==0)  count1++;  //ע��0�ǲ���ż�������ܴ� 
		else  count2++;
		if(i % 3 == 0&&i % 7 != 0)   count3++;
	}
	max = count1>count2? count1:count2;
	max = max>count3? max:count3;
	printf("%d %d %d\n%d",count1,count2,count3,max);
    return 0;
} 
