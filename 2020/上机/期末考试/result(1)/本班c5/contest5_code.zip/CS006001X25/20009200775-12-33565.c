#include<stdio.h>
#include<math.h>
int main()
{
	int len=1,m,n,i,j,a[100],b[100];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++) len*=2;
	for(i=0;i<len;i++)
	{
		scanf("%d",&a[i]);
	}
	len/=2;
	for(i=0;i<m;i++)
	{
		for(j=0;j<len;j++)
		{
			a[j]=a[j]+a[2*len-1-j];
		}
		len/=2;
	}
	if(len==0) printf("%d",a[0]);
	else
	{
	for(i=0;i<2*len;i++)
	{
		printf("%d ",a[i]);
	}
    }
}
