#include <stdio.h>
#include <math.h>

int main ()
{
	int N=0;
	scanf ("%d",&N);
	int a[N][3];
	int i=0,j=0;
	double min=10000000.0;
	int num=0;
	double s;
	
	for (i=0;i<N;i++) {
		scanf ("%d %d %d",&a[i][0],&a[i][1],&a[i][2]);
	} 
	
	s=0;
	for (i=0;i<N;i++) {
		for (j=0;j<N;j++) {
			s+=sqrt((a[i][1]-a[j][1])*(a[i][1]-a[j][1])+(a[i][2]-a[j][2])*(a[i][2]-a[j][2]));
			}
		if (s<=min) {
			min=s;
			num=a[i][0];	
		}
		s=0;
	}
	
	printf ("%d %.2lf",num,min);
	
	return 0;
}
