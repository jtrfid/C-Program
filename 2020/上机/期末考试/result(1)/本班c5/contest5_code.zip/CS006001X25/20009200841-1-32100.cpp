#include<stdio.h>
int main()
{
	int a, b, c=0, d=0, e=0, f=-1;
	scanf("%d %d", &a, &b);
	for(int y=a; y<=b; y++)
	{
		if(y%2==0)
			c+=1;
		if(y%2==1)
			d+=1;
		if(y%3==0 && y%7!=0)
			e+=1;
	}
	printf("%d %d %d\n", c, d, e);
	f=c;
	if(d>f)
		f=d;
	if(e>f)
		f=e;
	printf("%d", f);
	return 0;
}
