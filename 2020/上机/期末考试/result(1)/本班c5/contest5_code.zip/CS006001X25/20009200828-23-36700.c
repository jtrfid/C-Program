#include<stdio.h>
#include<math.h>
double distance(int x1,int x2,int y1,int y2)
{
	double result;int m=x1-x2;int n=y1-y2;
	int x=m*m;
	int y=n*n;
	result=sqrt(x+y);
	return result;
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n][3];double c[n],b[n];
	int i,j;
	for(i=0;i<n;i++)
	{
		b[i]=0;
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		b[i]=0;
		for(j=0;j<n;j++)
		{
			int x1=a[i][1];
			int x2=a[j][1];
			int y1=a[i][2];
			int y2=a[j][2];
			b[i]+=distance(x1,x2,y1,y2);
		}
	}
	for(i=0;i<n;i++)
	{
		c[i]=b[i];
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(c[j+1]<c[j])
			{
				double t=c[j];
				c[j]=c[j+1];
				c[j+1]=t;
			}
		}
	}
	int max;
	for(i=0;i<n;i++)
	{
		if(b[i]==c[0])
		max=i+1;
	}
	printf("%d %.2f",max,c[0]);
	return 0;
}
