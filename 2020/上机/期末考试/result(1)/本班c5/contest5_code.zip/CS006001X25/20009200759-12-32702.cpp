#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,a[65],i2,i1;
	scanf("%d %d",&n,&m);
	for(i1=0;i1<pow(2,n);i1++)
	scanf("%d",&a[i1]);
	int b=pow(2,n);
	for(i1=0;i1<m;i1++)
	{
		for(i2=0;i2<pow(2,n)/(2*(1+i1));i2++)
		{
			a[i2]=a[i2]+a[(b-i2-1)];
		}
	}
		for(i2=0;i2<pow(2,n)/(2*(m));i2++)
		printf("%d ",a[i2]);
	return 0;
}
