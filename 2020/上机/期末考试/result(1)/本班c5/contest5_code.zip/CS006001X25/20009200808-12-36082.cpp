#include<stdio.h>
#include<math.h>
int main(){
	int n,m,i,j,r,s,x,y;
	int a[100];
	scanf("%d%d",&n,&m);
	s=pow(2,n);
	for(i=0;i<s;i++){
		scanf("%d",&a[i]);
	}
	for(x=0;x<m;x++){
	    for(i=0;i<(s/2);i++){
		    j=s-1-i;
		    y=i;
		    a[y]=a[i]+a[j];
	}
	s=s/2;
}
	for(r=0;r<s;r++){
		printf("%d ",a[r]);
	}

	return 0;
}
