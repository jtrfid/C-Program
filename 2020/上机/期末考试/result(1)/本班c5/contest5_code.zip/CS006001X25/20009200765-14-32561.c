#include <stdio.h>

void swap (int *p, int *q)
{
	int temp=0;
	temp=*p;
	*p=*q;
	*q=temp;
}

int main ()
{
	int m=0,n=0;
	int i=0,j=0,k=0;
	scanf ("%d %d",&m,&n);
	int a[m][n];
	for (i=0;i<m;i++) {
		for (j=0;j<n;j++) {
			scanf ("%d",&a[i][j]);
		}
	}
	
	for (k=0;k<m;k++) {
		for (j=n;j>0;j--) {
			for (i=0;i<j-1;i++) {
				if (a[k][i]<a[k][i+1]) {
					swap (&a[k][i],&a[k][i+1]);
				}
			}
		}
	}
	
	for (i=0;i<m;i++) {
		for (j=0;j<n;j++) {
			printf ("%d ",a[i][j]);
		}
		printf ("\n");
	}
	
	return 0;
}
