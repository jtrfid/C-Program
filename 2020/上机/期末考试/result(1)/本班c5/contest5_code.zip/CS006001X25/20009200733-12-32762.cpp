#include <stdio.h>
#include <stdlib.h>

int main(){
	int c,n,m,i,half,f;
	scanf("%d %d",&n,&m);
	f=half=c=1<<n;
	int *map=(int*)malloc(c*sizeof (int));
	for (i=0;i<c;i++){
		scanf("%d",map+i);
	}
	for (;m>0&&f>0;m--){
		half>>=1;
		for (i=0;i<half;i++){
			map[i]+=map[f-i-1];
		}
		f>>=1;
	}
	for (i=0;i<f;i++){
		printf("%d%c",map[i],(i+1==f)?'\n':' ');
	}
	free(map);
	return 0;
}
