#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
    int n,m;
    int len;
    int i,j;
    int x;
    scanf("%d %d",&n,&m);
    len=pow(2,n);
    int a[len];
    for(i=0;i<=len-1;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=1;i<=m;i++)
    {
        for(j=0;j<=len/2-1;j++)
        {
            a[j]+=a[len-j-1];
        }
    }
    x=pow(2,m);
    len/=x;
    for(i=0;i<=len-1;i++)
    {
        printf("%d ",a[i]);
    }
    return 0;
}
