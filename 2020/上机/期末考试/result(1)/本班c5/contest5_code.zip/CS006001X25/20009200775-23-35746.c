#include<stdio.h>
#include<math.h>
struct
{
	int num;
	double x,y;
}stu[100000];
int main()
{
	int n,i,j,dot=0;
	double min=10000,sum;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&stu[i].num);
		scanf("%lf %lf",&stu[i].x,&stu[i].y);
	}
	for(i=0;i<n;i++)
	{
		sum=0;
		for(j=0;j<n;j++)
		{
			if(j==i) continue;
			sum+=pow(pow((stu[i].x-stu[j].x),2)+pow((stu[i].y-stu[j].y),2),1.0/2);
		}
		if(sum<min)
		{
			min=sum;
			dot=i;
		}
		if(sum==min)
		{
			dot=(dot>i?dot:i);
		}
	}
	printf("%d %.2f",stu[dot].num,min);
}
