#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,t,i,j,l,x,a[100],b[100],k;
	scanf("%d %d",&n,&m);
	t=pow(2,n);
	for(i=0;i<t;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=m;i++)
	{
		k=0;
		for(j=0,l=t-1;j<l;j++,l--)
		{
			b[k]=a[j]+a[l];
			k++;
		}
		t=t/2;
		for(x=0;x<k;x++)
		{
			a[x]=b[x];
		}
	}
	for(i=0;i<k;i++)
	{
		if(i==0)
		{
			printf("%d ",b[i]);
		}
		else
		{
			printf("%d ",b[i]);
		}
	}
	return 0;
}

