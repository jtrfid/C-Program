#include<stdio.h>
int main()
{
	int m, n, i, t1=0, t2=0, t3=0, max;
	scanf("%d %d", &m, &n);
	for (i=m; i<=n; i++){
		if(i%2==0)
		t1++;
	}for (i=m; i<=n; i++){
		if(i%2!=0)
		t2++;
	}for (i=m; i<=n; i++){
		if(i%3==0&&i%7!=0)
		t3++;
	}
	if(t1 > t2){
		if(t1>t3)
		max=t1;
		else
		max=t3;
	}
	else if(t2>t3){
	max=t2;}
	else{
	max=t3;}
	printf("%d %d %d\n %d", t1, t2, t3, max);
	return 0;
}
