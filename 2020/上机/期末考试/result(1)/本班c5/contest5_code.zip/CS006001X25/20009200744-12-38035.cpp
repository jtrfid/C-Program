#include<stdio.h>
int main()
{
	int n,m,a=1,i,j,s[100],k;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		a*=2;
	}
	for(i=0;i<a;i++)
	{
		scanf("%d",&s[i]);
	}
	for(k=0;k<m;k++)
	{
		for(i=0,j=a-1;i<=a/2;i++,j--)
	    {
		    s[i]=s[i]+s[j];
	    }
	    a=a/2;
	}
	for(i=0;i<a;i++)
	{
		printf("%d ",s[i]);
	}
	
	return 0;
}
