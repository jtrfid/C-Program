#include<stdio.h>
#include<math.h>
int main()
{
	int a[100];
	int n,m;
	scanf("%d %d",&n,&m);
	int len=pow(2,n);
	int len2=len/(pow(2,m));
	for(int i=0;i<len;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<len/2;j++)
		{
			a[j]=a[j]+a[len-1-j];
		}
		len=len/2;
	}
	for(int t=0;t<len2;t++)
	{
		printf("%d ",a[t]);
	}
	return 0;
}
