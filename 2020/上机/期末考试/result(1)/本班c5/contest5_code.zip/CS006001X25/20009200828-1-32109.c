#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	int a,b;
	int i;
	for(i=n,a=0,b=0;i<=m;i++)
	{
		if(i%2==0)
		a++;
		else
		b++;
	}
	int c=0;
	for(i=n;i<=m;i++)
	{
		if(i%3==0&&i%7!=0)
		{
			c++;
		}
	}
	int max;
	max=a>b?a:b;
	int result;
	result=max>c?max:c;
	printf("%d %d %d\n%d",a,b,c,result);
	return 0;
}
