#include<stdio.h>
#include<stdio.h>
#include<math.h>
typedef struct
{
       float n;
	int x;
   int   y;
   float sum[100];
}stu;
int main()
{
	int i,n,j,max;
	scanf("%d",&n);
	stu s[n];
	for(i=0;i<n;i++)
	{
		scanf("%f %d %d",&s[i].n,&s[i].x,&s[i].y);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			s[i].sum=s[i].sum+sqrt(pow(s[i].x-s[j].x,2)+pow(s[i].y-s[j].y,2));
		}
	}
	max=0;
	for(i=0;i<n;i++)
	{
		if(s[max].sum<s[i].sum)
		{
			max=i;
		}
		else if(s[max].sum==s[i].sum)
		{
			if(s[max].n<s[i].n)
			{
				max=i;
			}
		}
	}
	printf("%.0f %.2f",s[max].n,s[max].sum);
	return 0;
}
