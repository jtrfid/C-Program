#include<stdio.h>
#include<stdio.h>
#include<math.h>
int main()
{
	int i,n,k,p,j,m,l,h;
	int a[100],s[100]={0};
	scanf("%d %d\n",&n,&k);
	m=pow(2,n);
	for(i=0;i<m;i++)
	{
		scanf("%d",&a[i]);
	}
	for(j=0;j<k;j++)
	{
		
		for(h=0;h<i;h++)
		{
			s[h]=0;
		}i=0;
		for(i=0,p=m-1;i<m/2;i++,p--)
		{
			s[i]=s[i]+a[i]+a[p];
		}
		m=m/2;
		for(h=0;h<i;h++)
		{
			a[h]=s[h];
		}
		
	}
	for(l=0;l<i;l++)
	{
		printf("%d ",s[l]);
	}
	return 0;
}
