#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

struct student{
	int i;
	float x;
	float y;
};

int main(){
	struct student a[100000]={0};
	float dst[100000]={0};
	int N,p;
	scanf("%d",&N);
	for(int k = 0;k<N;k++){
		scanf("%d %f %f",&a[k].i,&a[k].x,&a[k].y);
	}
	for(int j = 0;j<N;j++){
		for(int q = 0;q<N;q++){
			if(q!=j){
				dst[j]+=sqrt(pow((a[j].x-a[q].x),2)+pow((a[j].y-a[q].y),2));
			}
		}	
	}
	for(int w = 0;w<N;w++){
		for(int e =w+1;e<N-1;e++){
			if(dst[e]<dst[w]){
				float temp=dst[e];
				dst[e]=dst[w];
				dst[w]=temp;
				p=e+1;
			}
			if(dst[e]==dst[w]&&a[e].i>a[w].i){
				float temp=dst[e];
				dst[e]=dst[w];
				dst[w]=temp;
				p= e + 1;
			}
		}
	}
	
	printf("%d %.2f",p,dst[0]);
	return 0;
}

