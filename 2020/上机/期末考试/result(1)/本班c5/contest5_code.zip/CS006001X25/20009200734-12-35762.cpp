#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,c,count=0,d;
	scanf("%d %d",&n,&m);
	c=pow(2,n);
	d=c;
	int a[100000]={0};
	for(int i=0;i<c;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int j=0;j<m;j++)
	{
		for(int i=0;i<(c/2);i++)
	    {
			a[i]=a[i]+a[c-1-i];
	    }
	    c=c/2;
	    count++;
    }
	for(int i=0;i<(d/(2*count));i++)
	{
		printf("%d ",a[i]);
	}

	return 0;
}
