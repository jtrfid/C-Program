#include <stdio.h>
#include <math.h>

void distance( struct stu p[] , int n );
struct stu getstruct( struct stu p[] , int n );

struct stu{
	int num;
	int x;
	int y;
};

int main(){
	int n;
	scanf("%d",&n);
	struct stu st[100000];
	getstruct(st,n);
	distance(st,n);
	
	return 0 ;
}

struct stu getstruct( struct stu p[] , int n ){
	for( int i=0 ; i<n ; i++ ){
		scanf("%d",&p[i].num);
		scanf("%d",&p[i].x);
		scanf("%d",&p[i].y);
	}
	
	return * p ;
}

void distance( struct stu p[] , int n ){
	float d=0,min=0;
	int s=0;
	for( int i=0 ; i<n ; i++ ){
		for( int j=0 ; j<n ; j++ ){
			d+=sqrt( (p[j].x-p[i].x)*(p[j].x-p[i].x)+(p[j].y-p[i].y)*(p[j].y-p[i].y) );
		}
		if( min==0 ){
			min=d;
		}
		if( d<min ){
			min=d;
			s=i;
		}
		else if( d==min && s<i ){
			s=i;
		}
		d=0;
	}
	
	printf("%d %.2f",p[s].num,min);
}
