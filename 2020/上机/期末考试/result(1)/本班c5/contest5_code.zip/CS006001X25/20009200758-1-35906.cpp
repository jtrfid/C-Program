#include<stdio.h>
int main()
{
	int m,n,i,j,k=0,t,ou=0,ji=0,x=0;
	int a[3];
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%3==0&&i%7!=0)
		{
			x++;
		}	
		if(i%2==0)
		{
			ou++;
		}
		if(i%2!=0)
		{
			ji++;
		}
		
	}
	a[0]=x;
	a[1]=ou;
	a[2]=ji;
	for(j=0,i=1;i<=2;i++)
	{
		if(a[i]>a[j])
		j=i;
	}
	printf("%d %d %d\n",ou,ji,x);
	printf("%d",a[j]);
	return 0;
}
