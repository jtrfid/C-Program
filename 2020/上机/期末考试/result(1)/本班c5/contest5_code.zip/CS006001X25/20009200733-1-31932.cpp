#include <stdio.h>

int main(){
	int m,n,t=0;int r[3]={0,0,0};
	scanf("%d %d",&m,&n);
	r[0]=r[1]=(n-m+1)/2;
	if (m%2==0&&n%2==0){t=0;r[0]++;}
	if (m%2==1&&n%2==1){t=1;r[1]++;}
	for (;m<=n;m++){
		if (m%3==0&&m%7!=0)r[2]++;
	}
	printf("%d %d %d\n%d\n",r[0],r[1],r[2],r[t]);
	return 0;
}
