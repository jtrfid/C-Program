#include<stdio.h>
#include<math.h>
int main()
{
	struct student{
		int num;
		int x;
		int y;
	}stu[100000];
	int n,i,j,k;
	float s[100000]={0};
	scanf("%d",&n);
	for(i=0;i<=n-1;i++)
	{
		scanf("%d %d %d",&stu[i].num,&stu[i].x,&stu[i].y);
	}
	for(i=0;i<=n-1;i++)
	{
		for(j=0;j<=n-1;j++)
		{
			s[i]+=sqrt(((stu[j].x-stu[i].x)*(stu[j].x-stu[i].x)+(stu[j].y-stu[i].y)*(stu[j].y-stu[i].y))*1.0);
		}
	}
	for(i=0,j=1;j<=n-1;j++)
	{
		if(s[j]<s[i])
		i=j;
		if(s[i]==s[j])
		{
			if(stu[j].num>stu[i].num)
			i=j;
		}
	}
	printf("%d %.2f",stu[i].num,s[i]);
	return 0;
}
