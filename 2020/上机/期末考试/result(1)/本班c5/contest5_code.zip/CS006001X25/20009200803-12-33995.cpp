#include<stdio.h>
int main()
{
	int m,n,i,j;
	int a[64];
	scanf("%d%d",&n,&m);
	for(i=0;i<=2^n-1;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=m;i++)
	{
		for(j=0;j<=(2^(n-i)-1);j++)
		{
			a[j]=a[j]+a[2^(n-i)-1-j];
		}
	}
	for(i=0;i<=(2^(n-m+1)-1);i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
