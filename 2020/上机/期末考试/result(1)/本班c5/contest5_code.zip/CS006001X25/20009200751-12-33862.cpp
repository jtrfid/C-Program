#include <stdio.h>
#include <math.h>

int main(){
	int a[64],n,m;
	scanf("%d %d",&n,&m);
	int i,j,p; 
	p=pow(2,n);
	
	for( i=0 ; i<p ; i++ ){
		scanf("%d",&a[i]);
	}
	
	for( j=0 ; j<m ; j++ ){
		for( i=0 ; i<(p/2) ; i++ ){
			a[i]=a[i]+a[p-1-i];
		}
		p/=2;
	}
	
	for( i=0 ; i<p ; i++ ){
		printf("%d ",a[i]);
	}
		
	return 0 ;
}
