#include<stdio.h>
int main()
{
	int m,n,i,j,r,t,a[20][20];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n-1;j++)
		{
			for(r=j+1;r<n;r++)
			{
				if(a[i][j]<a[i][r])
				{t=a[i][j];a[i][j]=a[i][r];a[i][r]=t;
				}
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
}
