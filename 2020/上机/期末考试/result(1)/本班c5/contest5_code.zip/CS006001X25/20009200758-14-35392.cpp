#include<stdio.h>
int main()
{
	int a[10][10],m,n,i,j,k,l,cnt=0;
	scanf("%d %d",&m,&n);
	for(i=0;i<=m-1;i++)
	{
		for(j=0;j<=n-1;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<=m-1;i++)
	{
		for(j=0;j<=n-1;j++)
		{
			for(k=j+1,l=j;k<=n-1;k++)
			{
				if(a[i][k]>a[i][l])
				l=k;
			}
			if(l!=j)
			{
				int t;
				t=a[i][j];
				a[i][j]=a[i][l];
				a[i][l]=t;
			}
		}
	}
	for(i=0;i<=m-1;i++)
	{
		for(j=0;j<=n-1;j++)
		{
			printf("%d",a[i][j]);
			cnt++;
			if(cnt%n==0)
			printf("\n");
			else
			printf(" ");
		}
	}
	return 0;
}
