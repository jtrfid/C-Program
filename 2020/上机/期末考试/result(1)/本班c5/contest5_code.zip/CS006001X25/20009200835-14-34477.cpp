#include<stdio.h>
int main()
{int m,n,hang,lie,j,i,temp;
scanf("%d %d",&m,&n);
int a[10][10];
	for(hang=0;i<m;hang++)
	{for(lie=0;lie<n;lie++)
	{scanf("%d",&a[hang][lie]);
	}
	}
	for(hang=0;hang<m;hang++)
	{for(lie=0;lie<n;lie++)
	{printf("%d",a[hang][lie]);
	}
	printf("\n");
	}
	for(hang=0;hang<m;hang++)
	{for(i=0;i<n-1;i++)
	{for(j=i+1;j<n;j++)
	
	if(a[hang][i]<a[hang][j])
	temp=a[hang][j];
	a[hang][j]=a[hang][i];
	a[hang][i]=temp;
	}}
	
	for(hang=0;hang<m;hang++)
	{for(lie=0;lie<n;lie++)
	{printf("%d",a[hang][lie]);
	}
	printf("\n");
	}
	
	
	
	
	return 0;
}
