#include<stdio.h>
void zhedie(int as[], int b)
{
	int a;
	for(a=1; a<=b/2; a++)
	{
		as[a]=as[a]+as[b-a+1];
	}
}
int chengfang(int a, int b)
{
	int o=a;
	for(int p=2; p<=b; p++)
	{
		o=o*a;
	}
	return o;
}
int main()
{
	int as[1000]={0};
	int n, m;
	scanf("%d %d", &n, &m);
	for(int a=1; a<=chengfang(2, n); a++)
	{
		scanf("%d", &as[a]);
	}
	for(int a=1; a<=m; a++)
	{
		zhedie(as, chengfang(2, n));
		n-=1;
	}
	for(int t=1; t<=chengfang(2, n); t++)
		printf("%d ", as[t]);
	return 0;
}
