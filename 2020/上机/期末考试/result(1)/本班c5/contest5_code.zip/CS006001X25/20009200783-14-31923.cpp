#include<cstdio>
#include<algorithm>
int n,m,a[15];
int main()
{
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		 	scanf("%d",&a[j]);
		std::sort(a+1,a+1+m);
		for(int j=m;j;j--)printf("%d ",a[j]);
		printf("\n");
	}
}
