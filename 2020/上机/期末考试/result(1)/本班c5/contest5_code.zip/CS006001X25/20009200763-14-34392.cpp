#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int x[m][n];
	
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&x[i][j]);
		}
	}
	
	for(int i=0;i<m;i++)
	{
		int t,k;
		for(int j=0;j<n;j++)
		{
			k=j;
			for(int p=j+1;p<n;p++)
			{
				if(x[i][p]>x[i][k]) k=p;
			}
			
			t=x[i][k];x[i][k]=x[i][j];x[i][j]=t;
		}
	}
	
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			printf("%d ",x[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
