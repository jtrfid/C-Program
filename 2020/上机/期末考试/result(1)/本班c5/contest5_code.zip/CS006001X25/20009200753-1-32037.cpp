#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
	int n,m,a1=0,a2=0,a3=0;
	scanf("%d %d",&m,&n);
	for(int i=m;i<=n;i++)
	{
		if(i%2==0) a1++;
		else a2++;
		if(i%3==0&&i%7!=0) a3++;		
	}
	int max=a1;
	if(a2>a1) max=a2;
	if(a3>max) max=a3;
	printf("%d %d %d\n%d",a1,a2,a3,max);
}

