#include<stdio.h>
int main(){
	int m,n,i,j,r,s,max1,max;
	int s1=0,s2=0,s3=0;
	scanf("%d%d",&m,&n);
	for(i=m;i<=n;i++){
		if(i%2==0)    s1=s1+1;
	}
	for(j=m;j<=n;j++){
		if(j%2!=0)    s2=s2+1;
	}
	for(r=m;r<=n;r++){
		if(r%3==0&&r%7!=0)    s3=s3+1;
	}
	max1=(s1>s2)?s1:s2;
	max=(s3>max1)?s3:max1;
	printf("%d %d %d\n%d",s1,s2,s3,max);
	return 0;
}
