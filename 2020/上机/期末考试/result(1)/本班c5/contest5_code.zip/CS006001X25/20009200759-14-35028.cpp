#include<stdio.h>
#include<stdlib.h>
int cmp(const void* a,const void* b)
{
	
	return (int*)b-(int*) a; 
}
int main()
{
	int a[10][10],m,n,i1,t,i3,i2;
	scanf("%d %d",&n,&m);
	for(i1=0;i1<n;i1++)
	for(i2=0;i2<m;i2++)
	scanf("%d",&a[i1][i2]);
	for(i1=0;i1<n;i1++)
	{
		for(i2=0;i2<m;i2++)
		{
			for(i3=0;i3<m-1-i2;i3++)
			{
				if(a[i1][i3]<a[i1][i3+1] )
				{
					t=a[i1][i3];a[i1][i3]=a[i1][i3+1];a[i1][i3+1]=t;
				}
			}
		}
	}
	for(i1=0;i1<n;i1++)
	{
			for(i2=0;i2<m;i2++)
	printf("%d ",a[i1][i2]);
	printf("\n");
	}

	return 0;
}
