#include<cstdio>
#include<cmath>
int n,id[100005],k,x[100005],y[100005];
double ans=1e9;
int sqr(int x){return x*x;}
double abs(double x){return x>0?x:-x;}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d%d",&id[i],&x[i],&y[i]);
	for(int i=1;i<=n;i++)
	{
		double tmp=0;
		for(int j=1;j<=n;j++)
		 tmp+=sqrt(sqr(x[i]-x[j])+sqr(y[i]-y[j]));
		if(tmp<ans||abs(tmp-ans)<1e-5&&k<id[i])ans=tmp,k=id[i];
	}
	printf("%d %.2lf\n",k,ans);
}
