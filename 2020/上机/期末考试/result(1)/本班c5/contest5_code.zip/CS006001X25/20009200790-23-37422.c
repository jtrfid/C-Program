#include <stdio.h>
#include <stdlib.h>
#include<math.h>
typedef struct
{
    int num;
    float x;
    float y;
    float dst;
}std;
int main()
{
    std a[100000],tem;
    int n;
    int i,j;
    float x0,y0;
    scanf("%d",&n);
    for(i=0;i<=n-1;i++)
    {
        scanf("%d %f %f",&a[i].num,&a[i].x,&a[i].y);
    }
    for(i=0;i<=n-1;i++)
    {
        a[i].dst=0;
        for(j=0;j<=n-1;j++)
        {
            x0=(a[i].x-a[j].x)*(a[i].x-a[j].x);
            y0=(a[i].y-a[j].y)*(a[i].y-a[j].y);
            a[i].dst+=pow((x0+y0),0.5);
        }
    }
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(a[j].dst>a[j+1].dst)
            {
                tem=a[j];
                a[j]=a[j+1];
                a[j+1]=tem;
            }
            else if(a[j].dst==a[j+1].dst)
            {
                if(a[j].num<a[j+1].num)
                {
                    tem=a[j];
                    a[j]=a[j+1];
                    a[j+1]=tem;
                }
            }
        }
    }
    printf("%d %.2f",a[0].num,a[0].dst);
    return 0;
}
