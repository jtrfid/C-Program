#include<stdio.h>
int main()
{
     int m,n,i,a[3]={0},c=0,p=0,k=0,max;
     scanf("%d%d",&m,&n);
     for(i=m;i<=n;i++)
     {
     	if(i%2==0)
     	{
     		c++;
     	}
     	if(i%2!=0)
     	{
     		k++;
     	}
     	if(i%3==0&&i%7!=0)
     	{
     		p++;
     	}
     }
     a[0]=c;
     a[1]=k;
     a[2]=p;
     max=0;
     for(i=0;i<3;i++)
     {
     	if(a[max]<a[i])
     	{
     		max=i;
     	}
     }
     printf("%d %d %d\n",c,k,p);
     printf("%d",a[max]);
     return 0;
}
