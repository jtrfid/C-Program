#include <stdio.h>
#include <math.h>

int main ()
{
	int n=0,m=0;
	scanf ("%d %d",&n,&m);
	int num=pow (2,n);
	int a[num];
	int i=0,j=0;
	
	for (i=0;i<num;i++) {
		scanf ("%d",&a[i]);
	}
	
	for (j=0;j<m;j++) {
		for (i=0;i<num/2;i++) {
			a[i]+=a[num-i-1];
		}
		num/=2;
	}
	
	for (i=0;i<num;i++) {
		printf ("%d ",a[i]);
	}
	
	return 0;
}
