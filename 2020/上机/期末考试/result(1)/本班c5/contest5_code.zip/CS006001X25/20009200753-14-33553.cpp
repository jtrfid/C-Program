#include<cstdio>
#include<algorithm>
using namespace std;
int a[15][15],b[15];
bool cmp(int x,int y)
{
	if(x==y) return x;
	else return x>y;
}
int main()
{
	int n,m;
	scanf("%d %d",&m,&n);
	for(int i=1;i<=m;i++)
	for(int j=1;j<=n;j++)
	scanf("%d",&a[i][j]);
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=n;j++)
		b[j]=a[i][j];
		sort(b+1,b+n+1,cmp);
		for(int r=1;r<=n;r++)
		a[i][r]=b[r];
	}
	for(int i=1;i<=m;i++)
	{
	   for(int j=1;j<=n;j++)
	   printf("%d ",a[i][j]);
	   printf("\n");
	}
	return 0;
}

