#include<stdio.h>
#include<stdio.h>
#include<math.h>
typedef struct
{
       float n;
	float x;
  float  y;
   float sum;
}stu;
int main()
{
	int i,n,j,min;
	scanf("%d",&n);
	stu s[n];
	for(i=0;i<n;i++)
	{
		scanf("%f %f %f",&s[i].n,&s[i].x,&s[i].y);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			s[i].sum=s[i].sum+sqrt(pow(s[i].x-s[j].x,2)+pow(s[i].y-s[j].y,2));
		}
	}
	min=0;
	for(i=0;i<n;i++)
	{
		if(s[min].sum>s[i].sum)
		{
			min=i;
		}
		else if(s[min].sum==s[i].sum)
		{
			if(s[min].n<s[i].n)
			{
				min=i;
			}
		}
	}
	printf("%.0f %.2f",s[min].n,s[min].sum);
	return 0;
}
