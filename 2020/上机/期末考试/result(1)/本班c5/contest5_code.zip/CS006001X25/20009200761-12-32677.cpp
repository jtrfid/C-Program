#include<stdio.h>
#include<math.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	int a[64]={0};
	int i,j;
	j=pow(2,n);
	for(i=0;i<j;i++)
	{
		scanf("%d",&a[i]);
	}
	int b[32]={0};
	int k;
	for(k=0;k<m;k++)
	{
		for(i=0;i<j/2;i++)
		{
			b[i]=a[i]+a[j-1-i];
		}
		i=0;
		while(a[i]!=0)
		{
			a[i]=0;
			i++;
		}
		for(i=0;i<j/2;i++)
		{
			a[i]=b[i];
		}
		while(b[i]!=0)
		{
			b[i]=0;
			i++;
		}
		j/=2;
	}
	i=0;
	while(a[i]!=0)
	{
		printf("%d ",a[i]);
		i++;
	}
	return 0;
}
