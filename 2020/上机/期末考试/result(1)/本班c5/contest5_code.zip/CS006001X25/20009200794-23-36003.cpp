#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

double dis(int x1,int y1,int x2,int y2){
	if(x1<x2){
		x1^=x2^=x1^=x2;
	}
	if(y1<y2){
		y1^=y2^=y1^=y2;
	}
	double d=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	return d;
}

int n;
int a[100001][3]; //num,x,y
double ans[100001]={0.00};

int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=3;j++){
			cin>>a[i][j];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			ans[i]+=dis(a[i][2],a[i][3],a[j][2],a[j][3]);
		}
	}
	double re=2147483647.0;
	int num=0;
	for(int i=1;i<=n;i++){
		if(re>ans[i]){
			re=ans[i];
			num=i;
		}
		if(re==ans[i] && num<i){
			num=i;
		}
	}
	cout<<num<<" ";
	printf("%.2lf",re);
	return 0;	
}
