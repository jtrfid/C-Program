#include<stdio.h>
#include<math.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	int x=pow(2,n);
	int a[x];
	for(int i=0;i<x;i++)
	{
		scanf("%d",&a[i]);
	}
	int b[m+1][x];
	for(int i=0;i<x;i++)
	{
		b[0][i]=a[i];
	}
	for(int i=0;i<m;i++)
	{
		x=x/2;
		for(int j=0;j<x;j++)
		{
			b[i+1][j]=0;
			b[i+1][j]=b[i][j]+b[i][x*2-j-1];
		}
	}
	for(int i=0;i<x;i++)
	{
		printf("%d ",b[m][i]);
	}
	return 0;
}
