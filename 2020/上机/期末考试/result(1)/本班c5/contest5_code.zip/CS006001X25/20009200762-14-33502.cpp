#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int a[10][10];
	int m,n;
	scanf("%d %d",&m,&n);
	for(int i = 0;i<m;i++){
		for(int j = 0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(int i = 0;i<m;i++){
		for(int j =0;j<n;j++){
			for(int k = 0;k<n;k++){
				for(int q = k+1;q<n;q++){
					if(a[i][q]>a[i][k]){
						int temp = a[i][q];
						a[i][q]=a[i][k];
						a[i][k]=temp;
					}
				}
			}
		}
	}
	for(int i = 0;i<m;i++){
		for(int j = 0;j<n;j++){
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}


