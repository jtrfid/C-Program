#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int m,n;
	int cnt=0,odd=0,even=0;
	scanf("%d %d",&m,&n);
	for(int i = m;i<=n;i++){
		if(i%2==0){
			even++;
		}
		if(i%2!=0){
			odd++;
		}
		if(i%3==0&&i%7!=0){
			cnt++;
		}
	}
	printf("%d %d %d\n",even,odd,cnt);
	
	int max=odd;
	if(even>max)max=even;
	if(cnt>max)max=cnt;
	printf("%d",max);
	return 0;
}
