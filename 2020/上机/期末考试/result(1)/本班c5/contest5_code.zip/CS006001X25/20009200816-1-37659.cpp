#include<stdio.h>
#include<math.h>
typedef struct{
	int num;
	int a;
	int b;
	float s;	
}ps;

int compare(ps a,ps b)
{
	if(a.s<b.s)
	{
		return 1;
	}
	else if(a.s==b.s)
	{
		return a.num-b.num;
	}
}
float s(int a,int b,int c,int d)
{
	float s=sqrt(pow(a-c,2)+pow(b-d,2));
	return s;
}

int main()
{
	int n;
	float sum=0.0;
	ps a[100];
	float b[100];
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d %d %d",&a[i].num,&a[i].a,&a[i].b);
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			sum+=s(a[i].a,a[i].b,a[j].a,a[j].b);
		}
		a[i].s=sum;
		sum=0.0;
	}
	for(int i=0;i<n-1;i++)
	{
		int j,k;
		for(j=i+1,k=i;j<n;j++)
		{
			if(compare(a[j],a[i])>0)
			{
				k=j;
			}
		}
		if(k!=i)
		{
			ps temp=a[i];
			a[i]=a[k];
			a[k]=temp;
		}
	}
	printf("%d %.2f",a[0].num,a[0].s);
	return 0;
}
