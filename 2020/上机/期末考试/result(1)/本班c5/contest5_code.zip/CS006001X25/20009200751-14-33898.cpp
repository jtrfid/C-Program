#include <stdio.h>

int main(){
	int m,n,i,j,p;
	int a[10][10];
	scanf("%d %d",&m,&n);
	
	for( i=0 ; i<m ; i++ ){
		for( j=0 ; j<n ; j++ ){
			scanf("%d",&a[i][j]);
		}
	}
	
	for( i=0 ; i<m ; i++ ){
		for( j=0 ; j<n-1 ; j++ ){
			for( p=0 ; p<n-j-1 ; p++ ){
				if( a[i][p]<a[i][p+1] ){
					int temp;
					temp=a[i][p];
					a[i][p]=a[i][p+1];
					a[i][p+1]=temp;
				}
			}
		}
	}
	
	for( i=0 ; i<m ; i++ ){
		for( j=0 ; j<n ; j++ ){
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	
	return 0 ;
}

 	//for( i=0 ; i<m ; i++ ){
	//	for( j=0 ; j<n ; j++ ){
		
	//	}
	//}
