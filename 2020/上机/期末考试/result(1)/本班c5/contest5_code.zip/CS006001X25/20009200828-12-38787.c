#include<stdio.h>
#include<math.h>
#include<math.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	int sum=pow(2,n);
	int a[n+1][sum];
	int i,j,k,t;
	for(i=0;i<sum;i++)
	{
		scanf("%d",&a[0][i]);
	}
	for(j=0;j<m;j++)
	{
		t=sum;
		for(k=1;k<=j;k++)
		{
			t=t/2;
		}
		for(i=0;i<t;i++)
		{
			a[j+1][i]=a[j][i]+a[j][t-i-1];
		}
	}
	for(i=0;i<t/2;i++)
	{
		printf("%d ",a[j][i]);
	}
	return 0;
}

