#include<stdio.h>
#include<stdio.h>
#include<math.h>
int main()
{
	int a=7,b=17,c=5,d=13;
	printf("%d %d %d %d",a,b,c,d);
	return 0;
}
