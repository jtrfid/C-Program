#include<stdio.h>
#include<string.h>
int main()
{
	int m,n,oushu=0,jishu=0,zhengchu=0,i;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{if(i%2==0)
	{
	oushu=oushu+1;}
	else
	{jishu=jishu+1;}
	if(i%3==0&&i%7!=0)
	{
	zhengchu=zhengchu+1;
	}}
	printf("%d %d %d\n",oushu,jishu,zhengchu);
	int max;
	max=jishu;
	if(max<oushu)
	max=oushu;
	printf("%d",max);
	
	
	
	
	
	return 0;
}
