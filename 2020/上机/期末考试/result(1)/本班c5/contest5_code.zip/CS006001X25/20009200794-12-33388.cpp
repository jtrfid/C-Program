#include<iostream>
#include<cmath>
using namespace std;

int n,m;
int a[100];

int main(){
	cin>>n>>m;
	for(int i=0;i<pow(2,n);i++){
		cin>>a[i];
	}
	for(int j=1;j<=m;j++){
		for(int i=0;i<pow(2,n-j);i++){
			a[i]=a[i]+a[(int)pow(2,n-j+1)-i-1];
		}
	}
	for(int i=0;i<pow(2,n-m);i++){
		cout<<a[i]<<" ";
	}
	return 0;	
}
