#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
using namespace std;
struct stu{
	int a,x,y;
	double s;
}A[100000];

int main()
{
	int n,i1,i2,i3;
	scanf("%d",&n);
	for(i1=0;i1<n;i1++)
	{
			scanf("%d %d %d",&A[i1].a,&A[i1].x,&A[i1].y);
	}

	for(i1=0;i1<n;i1++)
	{
		A[i1].s=0;
		for(i2=0;i2<n;i2++)
		A[i1].s+=sqrt(1.0*(A[i2].x-A[i1].x)*(A[i2].x-A[i1].x)+(A[i2].y-A[i1].y)*(A[i2].y-A[i1].y));
	}	
	int min=0;
	for(i1=0;i1<n-1;i1++)
	{
		if(A[i1+1].s<A[i1].s) min=i1+1;
		else 
		{
			if(A[i1+1].s==A[i1].s)
			{
				if(A[i1+1].a>A[i1].a) min=i1+1;
			}
		}
	}
	printf("%d %.2lf",A[min].a,A[min].s);
	return 0;
}
