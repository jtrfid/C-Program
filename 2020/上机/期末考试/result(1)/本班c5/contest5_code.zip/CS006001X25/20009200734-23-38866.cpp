#include<stdio.h>
#include<math.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n][3];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<3;j++)
		scanf("%d",&a[i][j]);
	}
	float b[n][2];
	for(int i=0;i<n;i++)
	{
		b[i][0]=i+1;
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0,x1,y1,s=0;j<n;j++)
		{
			x1=pow((a[i][1]-a[j][1]),2);
			y1=pow((a[i][2]-a[j][2]),2);
			s=s+pow((x1+y1),1/2);
				b[i][1]=s;
		}
	
	}
	int min=0,x;
	for(int i=0;i<n;i++)
	{
		if(min>=b[i][1])
		{
			min=b[i][1];
			n=i+1;
		}
	}
	printf("%d %.2f",n,min);
	return 0;
}
