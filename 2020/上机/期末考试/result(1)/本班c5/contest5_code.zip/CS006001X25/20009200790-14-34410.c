#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[10][10];
    int m,n;
    int tem;
    int i,j,k;
    scanf("%d %d",&m,&n);
    for(i=0;i<=m-1;i++)
    {
        for(j=0;j<=n-1;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<=m-1;i++)
    {
        for(j=0;j<n-1;j++)
        {
            for(k=0;k<n-j-1;k++)
            {
                if(a[i][k]<a[i][k+1])
                {
                    tem=a[i][k];
                    a[i][k]=a[i][k+1];
                    a[i][k+1]=tem;
                }
            }
        }
    }
    for(i=0;i<=m-1;i++)
    {
        for(j=0;j<=n-1;j++)
        {
            printf("%d ",a[i][j]);
            if(j==n-1)
            {
                printf("\n");
            }
        }
    }
    return 0;
}
