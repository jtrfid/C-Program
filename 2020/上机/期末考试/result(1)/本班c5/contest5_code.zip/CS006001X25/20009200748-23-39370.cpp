#include<stdio.h>
#include<math.h>
int main()
{
	int n,a[3000][3000],i,j,t=0,place=0;
	double d[100];
	scanf("%d",&n);
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < 3;j++)
		  scanf("%d",a[i][j]);
	}
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < n;j++)
		  {
		  	if( i != j)
		  	  d[i] += pow(pow(a[i][2]-a[j][2],2)+pow(a[i][3]-a[j][3],2),0.5);
		  }
	}
	for(i = 1, t=d[0]; i < n; i++)
	{
	  if(d[i] > t)  
	  {
	  	t = d[i];
	  	place = i;
	  }
	  if(d[i] == t) place = place>i? place:i;
	}
	printf("%d %.2f",place,t);
	return 0;
}
