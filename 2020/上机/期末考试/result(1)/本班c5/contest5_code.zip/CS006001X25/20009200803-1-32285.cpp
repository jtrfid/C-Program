#include<stdio.h>
int main()
{
	int m,n,i,sum=0,tmp=0,rmp=0,maxm,max,min;
	scanf("%d %d",&m,&n);
	min=m<n?m:n;
	max=m>n?m:n;
	for(i=min;i<=max;i++)
	{
		if(i%2==0)
		{
			sum++;
		}
		else
		{
			tmp++;
		}
		if(i%3==0&&i%7!=0)
		{
			rmp++;
		}
	}
	if(sum>=tmp&&sum>=rmp)
	{
		maxm=sum;
	}
	else if(tmp>sum&&tmp>=rmp)
	{
		maxm=tmp;
	}
	else if(rmp>sum&&rmp>tmp)
	{
		maxm=rmp;
	}
	printf("%d %d %d\n%d",sum,tmp,rmp,maxm);
	return 0;
}
