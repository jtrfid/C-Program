#include<cstdio>
#include<cmath>
using namespace std;
int a[100];
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=pow(2,n);i++)
	{
		scanf("%d",&a[i]);	
	}
	int k=1;
	for(int j=1;j<=m;j++)
	{
		int u=pow(2,n-k);
	    for(int l=1;l<=u;l++)	
		a[l]+=a[2*u-l+1];
		k++;
	}
	for(int r=1;r<=pow(2,n-m);r++)
	printf("%d ",a[r]);
	return 0;
}

