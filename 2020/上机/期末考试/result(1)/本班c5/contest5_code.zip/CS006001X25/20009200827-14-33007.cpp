#include<stdio.h>
int main()
{
	int m,n,i,j,k,max,t,d,p;
	scanf("%d%d",&m,&n);
	int a[100][100]={0};
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(k=0;k<n;k++)
		{
			max=k;
			for(p=k+1;p<n;p++)
			{
				if(a[i][max]<a[i][p])
				{
					max=p;
				}
			}
			t=a[i][k];
			a[i][k]=a[i][max];
			a[i][max]=t;
		}
		for(d=0;d<n;d++)
		{
			printf("%d ",a[i][d]);
		}
		printf("\n");
	}
}
