#include<stdio.h>
#include<stdlib.h>
int cmp(const void* a,const void* b)
{
	
	return (int*)b-(int*) a; 
}
int main()
{
	int a[10][10],m,n,i1,i2;
	scanf("%d %d",&n,&m);
	for(i1=0;i1<n;i1++)
	for(i2=0;i2<m;i2++)
	scanf("%d",&a[i1][i2]);
	for(i1=0;i1<n;i1++)
	qsort(a[i1],m,sizeof(a[i1][0]),cmp);
	for(i1=0;i1<n;i1++)
	{
			for(i2=0;i2<m;i2++)
	printf("%d ",a[i1][i2]);
	printf("\n");
	}

	return 0;
}
