#include<iostream>
#include<cmath>
using namespace std;

int m,n;
int a[10][10];

int main(){
	cin>>m>>n;
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			cin>>a[i][j];
		}
	}
	int i=0;
	while(i<m){
		for(int j=0;j<n-1;j++){
			for(int k=j;k<n;k++){
				if(a[i][j]<a[i][k]){
					a[i][j]^=a[i][k]^=a[i][j]^=a[i][k];
				}
			}
		}
		i++;	
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
	return 0;	
}
