#include<stdio.h>
int main()
{
	int m,n,i,j,s,t;
	scanf("%d%d",&m,&n);
	int a[10][10];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
	        scanf("%d",&a[i][j]);
	    }
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n-1;j++)
		{
			for(s=0;s<n-j-1;s++)
			{
				if(a[i][s]<a[i][s+1])
				{
					t=a[i][s],a[i][s]=a[i][s+1],a[i][s+1]=t;
				}
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
}
