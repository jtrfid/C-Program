#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&m,&n);
	int i;
	int count1=0,count2=0,count3=0;
	for(i=m;i<=n;i++)
	{
		if(i%2==0)
		{
			count1++;
		}
		else if(i%2==1)
		{
			count2++;
		}
		if(i%3==0&&i%7!=0)
		{
			count3++;
		}
	}
	int max;
	if(count1>count2)
	max=count1;
	else
	max=count2;
	printf("%d %d %d\n",count1,count2,count3);
	printf("%d\n",max);
	return 0;
}
