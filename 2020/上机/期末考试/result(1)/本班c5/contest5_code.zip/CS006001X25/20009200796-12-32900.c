#include <stdio.h>
#include <math.h>
int main()
{
	int m=0,n=0,i=0,j=0,k=0,a[64]={0};
	scanf("%d %d",&n,&m);
	n=pow(2,n);
	for(i=0;i<n;++i)
	{
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<m;++i)
	{
		for(j=0;j<n;++j)
		{
			a[j]=a[j]+a[n-1-j];
		}
		n=n/2;
	}
	
	for(i=0;i<n;++i)
	
	printf("%d ",a[i]);
	
	
	
	
	
	
	
	return 0;
}
