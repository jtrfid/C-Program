#include<stdio.h>
int pow(int x)
{
	int mul=1;
	for(int i=1;i<=x;i++)
	{
		mul*=2;
	}
	if (x==0) mul=1;
	return mul;
}
int main()
{
	int a[1000];
	int n,m;
	scanf("%d %d",&n,&m);
	int p=n;
	for(int i=0;i<pow(n);i++)
	{
		scanf("%d",&a[i]);
	}
	
	for(int i=0;i<m;i++)
	{
		int b[1000]={0};
		for(int p=0;p<pow(n);p++) b[p]=a[p];
		
		
		for(int j=0;j<pow(n-1);j++)
		{
			a[j]=b[j]+b[pow(n)-1-j];
		}
		
		n=n-1;
	}
	
	for(int i=0;i<pow(p-m);i++) printf("%d ",a[i]);
	
	return 0;
}
