#include<stdio.h>
int main()
{
	int s[10][10],i,j,m,n,temp=0,k;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
	    {
	    	scanf("%d",&s[i][j]);
	    }
	}
	for(i=0;i<m;i++)
	{
		for(k=0;k<n;k++)
		{
			for(j=0;j<n-k-1;j++)
		    {
		    	if(s[i][j]<s[i][j+1])
		        {
		        	s[i][j]=temp;
		        	s[i][j]=s[i][j+1];
		        	s[i][j+1]=temp;
		        }
		    }
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(j==0)
			printf("%d",s[i][j]);
			else
			printf(" %d",s[i][j]);
		}
		printf("\n");
	}
	
	
	return 0;
}
