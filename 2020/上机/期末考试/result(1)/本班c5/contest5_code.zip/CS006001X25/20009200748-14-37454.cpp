#include<stdio.h>
int main()
{
	int m,n,i,j,k,p,a[100][100]= {0},t;
	scanf("%d%d",&m,&n);
	for(i = 0; i < m;i++)
	{
		for(j = 0;j < n;j++)
		{
			scanf("%d",&a[i][j]);  //�������� 
		}
	}
	for(p = 0; p < m;p++)  //   �������±��� 
	{
	
		  for(i = 0; i < n;i++)
       	  {
		     for(j = i + 1,k = i; j < n;j++)
		     {
			   if(a[p][j] > a[p][k])  k = j;
		     }
		     if( k != i)
		    {
			   t = a[p][k];
			   a[p][k] = a[p][i];
			   a[p][i] = t;
		    }
     	  }
		
	}
	for(i = 0; i < m;i++)
	{
		for(j = 0;j < n;j++)
		{
			printf("%d ",a[i][j]); 
			if(j == n - 1) printf("\n");
		}
	}
	return 0;
}
