#include<stdio.h>
int main()
{
	int n,m,i,cnt=0;
	int a[64]={0},b[64]={0};
	scanf("%d %d",&n,&m);
	int t=1;
	for(i=1;i<=n;i++)
	t*=2;
	for(i=0;i<=t-1;i++)
	scanf("%d",&a[i]);
	for(;m>0;m--)
	{
		for(i=0;i<=t/2-1;i++)
		{
			b[i]=a[i]+a[t-1-i];
		}
		for(i=0;i<=t/2-1;i++)
		{
			a[i]=b[i];
		}
		t/=2;
	}
	for(i=0;i<=t-1;i++)
	{
		printf("%d",a[i]);
		cnt++;
		if(cnt%t!=0)
		printf(" ");
	}
	return 0;
}
