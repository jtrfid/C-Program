#include<stdio.h>
int main()
{
	int m,n,i1,a1=0,a2=0,a3=0;
	scanf("%d %d",&m,&n);
	for(i1=m;i1<=n;i1++)
	{
		if(i1%2==0) a1++;
		else a2++;
		if(i1%3==0&&i1%7!=0) a3++;
	}
	printf("%d %d %d\n",a1,a2,a3);
	int max=a1;
	if(a2>max) max=a2;
	if(a3>max) max=a3;
	printf("%d",max);
	return 0;
}
