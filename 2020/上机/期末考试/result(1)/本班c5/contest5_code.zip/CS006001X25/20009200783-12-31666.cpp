#include<cstdio>
int n,m,a[10005];
int main()
{
	scanf("%d%d",&n,&m);
	for(int i=1;i<=(1<<n);i++)scanf("%d",&a[i]);
	while(m--)
	{
		for(int i=1,j=(1<<n);i<j;i++,j--)
		 a[i]+=a[j];
		n--;
	}
	for(int i=1;i<=(1<<n);i++)printf("%d ",a[i]);
}
