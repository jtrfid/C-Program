#include<iostream>
using namespace std;


int m,n;
int main(){
	int cnt1=0,cnt2=0,cnt3=0;
	cin>>m>>n;
	for(int i=m;i<=n;i++){
		if(i%2==0){
			cnt1++;
		}
		if(i%2!=0){
			cnt2++;
		}
		if(i%3==0 && i%7!=0){
			cnt3++;
		}
	}
	cout<<cnt1<<" "<<cnt2<<" "<<cnt3<<endl;
	if(cnt1>=cnt2 && cnt1>=cnt3){
		cout<<cnt1;
	}
	if(cnt2>=cnt3 && cnt2>=cnt1){
		cout<<cnt2;
	}
	if(cnt3>=cnt1 && cnt3>=cnt2){
		cout<<cnt3;
	}
	return 0;
}
