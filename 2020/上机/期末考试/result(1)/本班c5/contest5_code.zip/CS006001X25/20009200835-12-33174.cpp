#include<stdio.h>
#include<math.h>
int main()
{
	int i,m,n,j,xunhuan,c[100]={0};
	scanf("%d %d",&n,&m);
	int k=pow(2,n);
	int a[k],b[k];
	for(i=0;i<k;i++)
	{scanf("%d",&a[i]);
	}
	for(xunhuan=0;xunhuan<m;xunhuan++)
	{
	
	
	for(i=k-1,j=0;i>=0;i--)
	{b[j]=a[i];
	j++;
	}
	k=k/2;
	
	for(i=0;i<k;i++)
	{c[i]=a[i]+b[i];
	
	}
	for(i=0;i<k;i++)
	{
	a[i]=c[i];
}}
for(i=0;i<k;i++)
	{printf("%d ",c[i]);
	}
	
	
	
	
	return 0;
}
