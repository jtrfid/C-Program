#include<stdio.h>
int main()
{
	int m,n,i,j;
	int a[64];
	scanf("%d %d\n",&n,&m);
	for(i=0;i<2^n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=m;i++)
	{
		for(j=0;j<=2^(n-i)-1;j++)
		{
			a[j]=a[j]+a[2^(n-i)-j-1];
		}
	}
	for(i=0;i<=2^(n-m)-1;i++)
	{
		printf("%d ",a[i]);
	}
}
