#include <stdio.h>
#include <math.h>

int main(){
	int a[100]={0},n,m;
	scanf("%d %d",&n,&m);
	int i=0,j=0,p=0,q=0; 
	p=pow(2,n);
	
	for( i=0 ; i<p ; i++ ){
		scanf("%d",&a[i]);
	}

	for( j=0 ; j<m ; j++ ){
		for( i=0 ; i<(p/2) ; i++ ){
			q=p-1-i;
			a[i]=a[i]+a[q];
		}
		p=p/2;
	}
	
	for( i=0 ; i<p ; i++ ){
		printf("%d ",a[i]);
	}
		
	return 0 ;
}
