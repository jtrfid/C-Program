#include<stdio.h>
int main(void)
{
    int m,n;
    int i;
    int a[3]={0,0,0},max;
    scanf("%d %d",&m,&n);
    for(i=m;i<=n;i++)
    {
        if(i%2==0)
        {
            a[0]++;
        }
        if(i%2!=0)
        {
            a[1]++;
        }
        if(i%3==0&&i%7!=0)
        {
            a[2]++;
        }
    }
    for(i=0;i<=2;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
    max=a[0];
    for(i=1;i<=2;i++)
    {
        if(a[i]>max)
        {
            max=a[i];
        }
    }
    printf("%d",max);
    return 0;
}
