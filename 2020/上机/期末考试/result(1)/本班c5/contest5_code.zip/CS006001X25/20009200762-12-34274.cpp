#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int main(){
	int a[64];
	int n,m,N;
	scanf("%d %d",&n,&m);
	N=pow(2,n);
	for(int i =0;i<N;i++){
		scanf("%d",&a[i]);
	}
	for(int i = 1;i<=m;i++){
		for(int j =0;j<N/2;j++){
			a[j]=a[j]+a[N-j-1];
		}
		N/=2;
	}
	
	for(int k = 0;k<N;k++){
		printf("%d ",a[k]);
	}
	
	return 0;
}
