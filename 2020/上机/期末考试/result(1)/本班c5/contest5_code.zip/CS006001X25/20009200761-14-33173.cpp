#include<stdio.h>
void sort(int a[],int n)
{
	int t,i,j=0;
	int change=1;
	while(change)
	{
		change=0;
		for(i=0;i<n-1-j;i++)
		{
			if(a[i]<a[i+1])
			{
				t=a[i];
				a[i]=a[i+1];
				a[i+1]=t;
				change=1;
			}
		}
		j++;
	}
}
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int a[10][10]={0};
	int i,j;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		sort(a[i],n);
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}
