#include<stdio.h>
int main()
{
	int m,n,max;
	int even=0,odd=0,sum=0;
	scanf("%d %d",&m,&n);
	for(int i=m;i<=n;i++)
	{
		if(i%2==0)
		{
			even++;
		}
		if(i%2!=0)
		{
			odd++;
		}
		if(i%3==0&&i%7!=0)
		{
			sum++;
		}
	}
	max=even;
	if(odd>max)
	{
		max=odd;
	}
	if(sum>max)
	{
		max=sum;
	}
	printf("%d %d %d\n",even,odd,sum);
	printf("%d",max);
	return 0;
}
