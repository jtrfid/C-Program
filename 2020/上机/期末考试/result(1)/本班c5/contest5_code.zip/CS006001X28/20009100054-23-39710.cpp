#include <stdio.h>
#include <math.h>

struct RO {
	int num;
	int x;
	int y;
};

int main() {
	struct RO a[100];
	int m, i, j,  imax;
	float sum = 0, max = 10000;
	scanf("%d", &m);
	for (i = 1; i <= m; i++) {
		scanf("%d%d%d", &a[i].num, &a[i].x, &a[i].y);

	}
	for (i = 1; i <= m; i++) {
		sum = 0;
		for (j = 1; j <= m ; j++) {
			sum += sqrt(pow((a[i].x - a[j].x), 2) + pow((a[i].y - a[j].y), 2) );
		}
		if (sum < max) {
			max = sum;
			imax = i;
		}



	}

	printf("%d %.2f", imax, max - 2);

	return 0;
}


