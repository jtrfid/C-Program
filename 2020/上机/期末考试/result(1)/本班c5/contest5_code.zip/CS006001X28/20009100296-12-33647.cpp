#include <stdio.h>

int main() {
	int n, m;
	scanf("%d%d", &n, &m);
	int t = 1;
	int i, j;
	for (i = 0; i < n; i++) {
		t *= 2;
	}
	int a[m + 1][t];
	for (i = 0; i < t; i++) {
		scanf("%d", &a[0][i]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < t / 2; j++) {
			a[i + 1][j] = a[i][j] + a[i][t - j - 1];
		}
		t /= 2;
	}
	for (i = 0; i < t; i++) {
		printf("%d ", a[m][i]);
	}
	return 0;
}