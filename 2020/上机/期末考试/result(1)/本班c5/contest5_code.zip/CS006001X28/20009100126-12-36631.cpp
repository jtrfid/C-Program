#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int a[64], i, j;
	float m, n, k, p, q;
	scanf("%f%f", &n, &m);
	k = pow(2, n);
	for (i = 0; i < k; i++)
		scanf("%d", &a[i]);
	for (p = 1; p <= m; p++) {
		q = k / pow(2, p);
		j = (2 * q - 1);
		for (i = 0 ; i < q; i++) {
			a[i] += a[j];
			j--;
		}
	}
	for (i = 0; i < (k / pow(2, m)) ; i++)
		printf("%d ", a[i]);
	return 0;
}