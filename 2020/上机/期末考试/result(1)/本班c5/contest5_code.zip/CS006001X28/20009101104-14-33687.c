#include <stdio.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int a[100][100];
	int i, j, k, l;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			for (k = 0; k < n - j - 1; k++) {
				if (a[i][k] < a[i][k + 1]) {
					l = a[i][k + 1];
					a[i][k + 1] = a[i][k];
					a[i][k] = l;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}