#include <stdio.h>

int main() {
	int m, n, i;
	int num1 = 0, num2 = 0, num3 = 0, max = 0;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0) {
			num1++;
		} else if (i % 2 == 1) {
			num2++;
		}
		if (i % 3 == 0 && i % 7 != 0) {
			num3++;
		}
	}
	max = num1;
	if (num2 > max)
		max = num2;
	if (num3 > max)
		max = num3;
	printf("%d %d %d\n%d", num1, num2, num3, max);
	return 0;
}