#include <stdio.h>
#include <string.>
#include <stdio.h>
#include <string.h>

int main () {
	int m, n, max;
	scanf("%d%d", &m, &n);
	int num1 = 0, num2 = 0, num3 = 0;
	for (int i = m; i <= n; i++) {
		if (i % 2 == 0)
			num2++;
		else if (i % 2 == 1)
			num1++;
		if (i % 3 == 0 && i % 7 != 0)
			num3++;


	}
	printf("%d %d %d\n", num2, num1, num3);
	max = num1;
	if (num2 > num1)
		max = num2;
	if (max < num3)
		max = num3;
	printf("%d", max);


	return 0;
}