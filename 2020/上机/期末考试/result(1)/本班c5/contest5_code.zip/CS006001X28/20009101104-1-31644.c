#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i;
	int a = 0, b = 0, c = 0;
	for (i = m; i <= n; i++) {
		if (i % 2 == 0) {
			a++;
		} else {
			b++;
		}
		if (i % 3 == 0 && i % 7 != 0) {
			c++;
		}
	}
	int d;
	if (a < b) {
		d = b;
	} else {
		d = a;
	}
	printf("%d %d %d\n%d", a, b, c, d);
	return 0;
}