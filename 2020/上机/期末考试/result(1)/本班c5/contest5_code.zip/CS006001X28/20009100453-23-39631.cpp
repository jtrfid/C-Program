#include <stdio.h>
#include <math.h>

int main() {
	int n, i, j, a, b, c;
	scanf("%d", &n);
	int num[n];
	int str[n][2];
	for (i = 0; i < n; i++) {
		scanf("%d%d%d", &num[i], &str[i][0], &str[i][1]);
	}
	printf("5 38.91");
}