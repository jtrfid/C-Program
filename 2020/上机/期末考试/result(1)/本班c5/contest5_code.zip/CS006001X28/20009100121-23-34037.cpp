#include <bits/stdc++.h>

struct student {
	int num;
	int x;
	int y;
	double d = 0;
} stu[1000000];

int main() {
	int N, i, j, number;
	double min;
	scanf("%d", &N);
	for (i = 0; i < N; i++) {
		scanf("%d%d%d", &stu[i].num, &stu[i].x, &stu[i].y);
	}
	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			stu[i].d += sqrt((stu[i].x - stu[j].x) * (stu[i].x - stu[j].x) + (stu[i].y - stu[j].y) * (stu[i].y - stu[j].y));
		}
	}
	min = stu[0].d;
	number = stu[0].num;
	for (i = 0; i < N ; i++) {
		if (stu[i].d < min) {
			min = stu[i].d;
			number = stu[i].num;
		}
		if (stu[i].d == min && stu[i].num > number) {
			min = stu[i].d;
			number = stu[i].num;
		}
	}
	printf("%d %.2f", number, min);
	return 0;
}