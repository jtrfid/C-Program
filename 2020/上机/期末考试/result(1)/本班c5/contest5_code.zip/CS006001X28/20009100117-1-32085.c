#include <stdio.h>

int main() {
	int m, n, i, ji = 0, ou = 0, k = 0, max1 = 0, max2 = 0;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			ou++;
		else if (i % 2 != 0)
			ji++;
	}
	for (i = m; i <= n; i++) {
		if (i % 3 == 0 && i % 7 != 0)
			k++;
	}
	max1 = ou > ji ? ou : ji;
	max2 = max1 > k ? max1 : k;
	printf("%d %d %d", ou, ji, k);
	printf("\n");
	printf("%d", max2);
	return 0;
}