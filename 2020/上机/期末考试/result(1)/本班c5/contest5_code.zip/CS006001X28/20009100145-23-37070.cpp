#include <stdio.h>
#include <string.h>
#include <math.h>

double dis(int x1, int x2, int y1, int y2) {
	int a = pow(x1 - x2, 2);
	int b = pow(y1 - y2, 2);
	double d = pow(a + b, 0.5);
	return d;
}

int main() {
	int n, num;
	scanf("%d", &n);
	int a[n][3];
	int i, j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < 3; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	double min = 10000000000000;
	double sum = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			sum += dis(a[i][1], a[j][1], a[i][2], a[j][2]);
		}
		if (sum < min) {
			min = sum;
			num = a[i][0];
		}
		if (sum == min && a[i][0] > num) {
			num = a[i][0];
		}
		sum = 0;
	}
	printf("%d %.2f", num, min);
	return 0;
}