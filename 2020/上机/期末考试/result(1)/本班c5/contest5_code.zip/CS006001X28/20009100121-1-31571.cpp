#include <bits/stdc++.h>

int main() {
	int m, n, i, sum1 = 0, sum2 = 0, sum3 = 0, max = 0;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			sum1++;
		if (i % 2 != 0)
			sum2++;
		if (i % 3 == 0 && i % 7 != 0)
			sum3++;
	}
	if (max < sum1)
		max = sum1;
	if (max < sum2)
		max = sum2;
	if (max < sum3)
		max = sum3;
	printf("%d %d %d\n%d", sum1, sum2, sum3, max);

	return 0;
}