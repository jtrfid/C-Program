#include <stdio.h>
#include <math.h>

int main() {
	int n, m;
	int i, j;
	scanf("%d %d", &n, &m);
	int N = (int)pow(2, (float)n);
	int M = (int)pow(2, (float)(n - m));
	int a[N];
	int temp[N] = {0};
	for (i = 0; i < N; i++) {
		scanf("%d", &a[i]);
	}
	for (j = N / 2; j >= M; j /= 2) {
		N /= 2;
		for (i = 0; i <= N; i++) {
			temp[i] = a[i] + a[2 * N - i - 1];
		}
		for (i = 0; i <= N; i++) {
			a[i] = temp[i];
		}
	}
	for (i = 0; i < M; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}