#include <stdio.h>

int main() {
	int m, n, i, j, p, q, t, a[10][10];
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	for (i = 0; i < m; i++) {
		for (p = 0; p < n - 1; p++)
			for (q = 0; q < n - 1; q++)
				if (a[i][q] < a[i][q + 1]) {
					t = a[i][q];
					a[i][q] = a[i][q + 1];
					a[i][q + 1] = t;
				}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
	return 0;
}