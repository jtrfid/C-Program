# include <stdio.h>
# include <math.h>

//sqrt
struct stu {
	int id;
	float x;
	float y;
} a[100];

int main (void) {
	int N, i, j;
	float d[100], D[100];
	scanf("%d", &N);
	for (i = 0; i < N; i++)
		scanf("%d%f%f", &a[i].id, &a[i].x, &a[i].y);
	for (i = 0; i < N; i++) {
		D[i] = 0;
		for (j = 0; j < N; j++) {
			d[j] = sqrt(pow(a[i].x - a[j].x, 2) + pow(a[i].y - a[j].y, 2));
		}
		for (j = 0; j < N; j++) {
			D[i] = D[i] + d[j];
		}
	}
	j = 0;
	for (i = 0; i < N; i++) {
		if (D[i] <= D[j])
			j = i;
	}
	printf("%d %.2f", j + 1, D[j]);
	return 0;
}