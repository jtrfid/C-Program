#include <stdio.h>

int main() {
	int a[10][10], i, j, k, m, n, max, temp = 0;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m ; i++) {
		for (k = 0; k < m - 1; k++) {
			for (j = k + 1; j <= n - 1; j++) {
				if (a[k][j] > a[k][j - 1]) {
					temp = a[k][j];
					a[k][j] = a[k][j - 1];
					a[k][j - 1] = temp;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
	return 0;
}