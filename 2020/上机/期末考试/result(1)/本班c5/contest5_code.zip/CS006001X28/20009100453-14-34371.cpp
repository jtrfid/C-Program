#include <stdio.h>

int main() {
	int m, n, i, j, t;
	scanf("%d%d", &m, &n);
	int str[m][n];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &str[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 1; j < n; j++) {
			for (t = n - 1; t >= j; t--) {
				if (str[i][t] > str[i][t - 1]) {
					int a = str[i][t];
					str[i][t] = str[i][t - 1];
					str[i][t - 1] = a;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", str[i][j]);
		}
		printf("\n");
	}
}