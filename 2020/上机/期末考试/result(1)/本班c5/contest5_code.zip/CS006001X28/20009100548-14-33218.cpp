#include <stdio.h>

int main() {
	int m, n, temp;
	scanf("%d %d", &m, &n);
	int arr[m][n];
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &arr[i][j]);
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n - 1; j++)
			for (int k = 0; k < n - j - 1; k++) {
				if (arr[i][k] < arr[i][k + 1]) {
					temp = arr[i][k];
					arr[i][k] = arr[i][k + 1];
					arr[i][k + 1] = temp;
				}
			}
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n - 1; j++)
			printf("%d ", arr[i][j]);
		printf("%d\n", arr[i][n - 1]);
	}
	return 0;
}