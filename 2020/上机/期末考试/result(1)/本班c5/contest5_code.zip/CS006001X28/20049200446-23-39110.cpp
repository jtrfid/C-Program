#include <stdio.h>
#include <math.h>

struct student {
	int num;
	int x;
	int y;
} a[20], temp;

int main() {
	int n, i, j, t;
	float D, d;
	float min;
	float b[20], sum[20] = {0};
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d%d%d", &a[i].num, &a[i].x, &a[i].y);
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			d = (a[j].x - a[i].x) * (a[j].x - a[i].x) + (a[j].y - a[i].y) * (a[j].y - a[i].y);
			D = D + pow(d, 0.5) ;
			b[i] = D;
		}
		D = 0.0;
	}
	min = b[0];
	for (i = 1; i < n; i++) {
		if (b[i] < min) {
			min = b[i];
			t = i;
		}
		if (b[i] == min && i > t) {
			t = i;
		}
	}
	printf("%d %.2f", t + 1, min);
	return 0;
}