#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int n, m;
	scanf("%d %d", &n, &m);
	int x = pow(2, n);
	int a[x] = {0};
	int i, j;
	for (i = 0; i < x; i++) {
		scanf("%d", &a[i]);
	}
	for (j = 0; j < m; j++) {
		for (i = 0; i < x / 2; i++) {
			a[i] += a[x - i - 1];

		}
		x /= 2;
	}
	for (i = 0; i < x; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}