#include <stdio.h>

int main() {
	int a[1000], b[1000], c[1000], d[1000], e[1000], f[1000], flag = 0, n, x, m, i, j;
	scanf("%d%d", &n, &m);
	for (i = 1; i <= n; i++) {
		x *= 2;
	}
	for (j = 0; j < x; j++) {
		scanf("%d", &a[j]);
	}
	for (j = 0; j < (x / 2); j++) {
		b[j] = a[j] + a[x - j - 1];
	}
	flag++;
	if (flag == m) {
		for (i = 0; i < (x / 2); i++) {
			printf("%d ", b[i]);
		}
	}
	return 0;
}