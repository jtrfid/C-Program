#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	struct s {
		int n;
		double x;
		double y;
		double l;
	} s[n] = {0, 0, 0, 0}, t;
	int i, j;
	for (i = 0; i < n; i++)
		scanf("%d%lf%lf", &s[i].n, &s[i].x, &s[i].y);
	for (i = 0; i < n; i++) {

		for (j = 0; j < n; j++)
			if (j != i)
				s[i].l = s[i].l + sqrt((s[i].x - s[j].x) * (s[i].x - s[j].x) + (s[i].y - s[j].y) * (s[i].y - s[j].y));
	}
	for (j = n - 1; j > 0; j--)
		for (i = 0; i < j; i++)
			if (s[i].l < s[i + 1].l) {
				t = s[i];
				s[i] = s[i + 1];
				s[i + 1] = t;
			}
	printf("%d %.2lf", s[0].n, s[0].l);

	return 0;
}