#include <stdio.h>
#include <math.h>

struct RO {
	int num;
	int x;
	int y;
};

int main() {
	struct RO a[100];
	int m, i, j, max = 100000, max1, h, k, min = 1, imin;
	float s, s1 = 0;
	scanf("%d", &m);
	for (i = 0; i < m; i++) {
		scanf("%d%d%d", &a[i].num, &a[i].x, &a[i].y);

	}
	for (i = 1; i <= m; i++) {
		for (j = 1; j <= m && j != i; j++) {
			h =  (a[j].x - a[i].x) * (a[j].x - a[i].x) + (a[j].y - a[i].y) * (a[j].y - a[i].y) ;
			for (k = 0; k < h; k += 0.01) {
				imin = h - k * k;
				if (imin < min)
					min = imin;
			}
			s1 += min;

		}
		if (s1 < max) {
			max = s1;
			max1 = i;
		}
	}
	printf("%d %.2f", max1, max);
	return 0;


}