#include <stdio.h>

int count1(int n, int m) {
	int i, count = 0;
	for (i = n; i <= m; i++) {
		if (i % 2 == 0) {
			count++;
		}
	}
	return count;
}

int count2(int n, int m) {
	int i, count = 0;
	for (i = n; i <= m; i++) {
		if (i % 2 == 1) {
			count++;
		}
	}
	return count;
}

int count3(int n, int m) {
	int i, count = 0;
	for (i = n; i <= m; i++) {
		if (i % 3 == 0 && i % 7 != 0) {
			count++;
		}
	}
	return count;
}

int main() {
	int n, m, max;
	scanf("%d %d", &n, &m);
	int a = count1(m, n), b = count2(m, n), c = count3(m, n);
	if (a > b) {
		max = a;
	} else {
		max = b;
	}
	if (max < c) {
		max = c;
	}
	printf("%d %d %d\n%d", a, b, c, max);
	return 0;
}