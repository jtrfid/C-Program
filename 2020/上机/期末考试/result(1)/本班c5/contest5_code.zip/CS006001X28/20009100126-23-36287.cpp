#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int n, i, j, jl = 1;
	float sum = 0, sum2 = 0;
	struct place {
		int num;
		float x;
		float y;
	} p[100000], tem;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d%f%f", &p[i].num, &p[i].x, &p[i].y);
	}
	for (j = 1; j < n; j++) {
		sum += sqrt(pow((p[0].x - p[j].x), 2) + pow((p[0].y - p[j].y), 2));
	}
	for (i = 0; i < n; i++) {
		sum2 = 0;
		for (j = 0; j < n; j++) {
			if (j == i)
				continue;
			else
				sum2 += sqrt(pow((p[i].x - p[j].x), 2) + pow((p[i].y - p[j].y), 2));
		}
		if (sum < sum2) {
			jl = i + 1;
			sum = sum2;
		}
		if (sum == sum2) {
			if (i + 1 > jl)
				jl = i + 1;
		}
	}
	printf("%d %.2f", jl, sum);
	return 0;
}