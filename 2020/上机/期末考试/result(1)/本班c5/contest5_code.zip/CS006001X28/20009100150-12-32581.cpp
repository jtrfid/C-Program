#include <stdio.h>
#include <math.h>

int main() {
	int n, m, i, j, N, a[100];
	scanf("%d%d", &n, &m);
	N = pow(2, n);
	for (i = 0; i < N; i++)
		scanf("%d", &a[i]);
	for (i = 1; i <= m; i++) {
		N = pow(2, n - i);
		for (j = 0; j < N; j++)
			a[j] = a[j] + a[2 * N - j - 1];
	}
	for (i = 0; i < N; i++)
		printf("%d ", a[i]);
	return 0;
}