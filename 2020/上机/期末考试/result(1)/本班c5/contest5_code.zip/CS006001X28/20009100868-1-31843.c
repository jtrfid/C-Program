#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <malloc.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int num1 = 0, num2 = 0, num3 = 0, max = 0, i;
	for (i = m; i <= n; i++) {
		if (i % 2 == 0) {
			num1++;
		} else {
			num2++;
		}
		if (i % 3 == 0 && i % 7 != 0) {
			num3++;
		}
	}
	if (num1 > num2) {
		if (num1 > num3) {
			max = num1;
		} else {
			max = num3;
		}
	} else {
		if (num2 > num3) {
			max = num2;
		} else {
			max = num3;
		}
	}
	printf("%d %d %d\n", num1, num2, num3);
	printf("%d", max);
	return 0;
}




//������Ӵ�
//��0�к͵�0�и�0
//�����ȣ����Ͻ�+1
//�������ȣ�=0



//ð������
//	int i,j,n;
//	for(i=0;i<n;i++)
//	{
//		for(j=0;j<n-i-1;j++)
//		{
//			if(ch[j+1]<ch[j])
//			{
//				int temp=ch[j];
//				ch[j]=ch[j+1];
//				ch[j+1]=temp;
//			}
//		}
//	}