#include <stdio.h>
#include <string.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int a[m][n];
	int i, j, k;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			for (k = j + 1; k < n; k++) {
				if (a[i][j] < a[i][k]) {
					int t = a[i][j];
					a[i][j] = a[i][k];
					a[i][k] = t;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}