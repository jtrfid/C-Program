#include <stdio.h>

int main() {
	int a[10][10], c[100] = {0}, i, j, k, m, n, max, temp = 0;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m ; i++) {
		for (j = 0; j < n; j++)
			c[j] = a[i][j];
		for (k = 0; k < n - 1; k++) {
			for (j = k + 1; j <= n - 1; j++) {
				if (c[j] > c[j - 1]) {
					temp = c[j - 1];
					c[j - 1] = c[j ];
					c[j ] = temp;
				}
			}
		}
		for (j = 0; j < n; j++)
			a[i][j] = c[j];
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
	return 0;
}