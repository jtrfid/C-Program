#include <stdio.h>

int main() {
	int i, j, k, n, m, a[100][100];
	scanf("%d %d", &n, &m);
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			for (k = 0; k < m - j - 1; k++) {
				if (a[i][k] < a[i][k + 1]) {
					int t = a[i][k];
					a[i][k] = a[i][k + 1];
					a[i][k + 1] = t;
				}
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}