#include <stdio.h>

int main() {
	int n, m;
	scanf("%d%d", &n, &m);
	int a[n][m];
	int i, j, k, t;
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m - 1; j++) {
			for (k = 0; k < m - 1 - j; k++) {
				if (a[i][k] < a[i][k + 1]) {
					t = a[i][k];
					a[i][k] = a[i][k + 1];
					a[i][k + 1] = t;
				}
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}