#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int n, m;
	scanf("%d %d", &n, &m);
	int x = pow(2, n);
	int b[x] = {0};
	int i, j;
	for (i = 0; i < x; i++) {
		scanf("%d", &b[i]);
	}
	for (j = 0; j < m; j++) {
		for (i = 0; i < x / 2; i++) {
			b[i] += b[x - i - 1];

		}
		x /= 2;
	}
	for (i = 0; i < x; i++) {
		printf("%d ", b[i]);
	}
	return 0;
}