#include <stdio.h>
#include <math.h>

struct a {
	int a;
	double b;
	double c;
	double d;
};

int main() {
	int i, j, n;
	double q;
	struct a s[100], t;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d%lf%lf", &s[i].a, &s[i].b, &s[i].c);
	}
	for (i = 0; i < n; i++) {
		s[i].d = 0;
		for (j = 0; j < n; j++) {
			q = pow(s[i].b - s[j].b, 2) + pow(s[i].c - s[j].c, 2);
			s[i].d += pow(q, 0.5);
		}
	}
	for (i = 0; i < n; i++) {
		for (j = i; j < n; j++) {
			if (s[j].d == s[i].d && s[j].a > s[i].a) {
				t = s[i];
				s[i] = s[j];
				s[j] = t;
			}
			if (s[j].d < s[i].d) {
				t = s[i];
				s[i] = s[j];
				s[j] = t;

			}
		}
	}
	printf("%d %.2f", s[0].a, s[0].d);
	return 0;
}