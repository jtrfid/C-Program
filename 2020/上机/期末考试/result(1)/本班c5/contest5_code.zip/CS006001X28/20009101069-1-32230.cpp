#include <stdio.h>

int main() {
	int i, m, n, a = 0, b = 0, c = 0, d;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			a++;
	}
	for (i = m; i <= n; i++) {
		if (i % 2 != 0)
			b++;
	}
	for (i = m; i <= n; i++) {
		if (i % 3 == 0 && i % 7 != 0)
			c++;
	}
	d = a;
	if (d < b)
		d = b;
	if (d < c)
		d = c;
	printf("%d %d %d\n", a, b, c);
	printf("%d", d);
	return 0;
}