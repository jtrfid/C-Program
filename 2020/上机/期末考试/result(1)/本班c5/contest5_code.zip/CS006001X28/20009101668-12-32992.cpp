# include <stdio.h>
# include <math.h>

int main (void) {
	int n, m, i, N = 1;
	int a[64], b[32];
	scanf("%d%d", &n, &m);
	for (i = 0; i < n; i++)
		N = N * 2;
	for (i = 0; i < N; i++)
		scanf("%d", &a[i]);
	while (m != 0) {
		for (i = 0; i < N / 2; i++) {
			b[i] = a[i] + a[N - 1 - i];
		}
		for (i = 0; i < N / 2; i++)
			a[i] = b[i];
		m--;
		N = N / 2;
	}
	for (i = 0; i < N; i++)
		printf("%d ", a[i]);
	return 0;
}
