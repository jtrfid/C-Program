#include <stdio.h>

int main() {
	int m, n, a[10][10], i, j, k, temp;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			for (k = j; k < n; k++)
				if (a[i][j] < a[i][k]) {
					temp = a[i][j];
					a[i][j] = a[i][k];
					a[i][k] = temp;
				}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
			if (j == n - 1)
				printf("\n");
		}
	}
	return 0;
}