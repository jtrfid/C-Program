#include <stdio.h>
#include <math.h>

int main() {
	int n;
	int i, k;
	int t = 0, l;
	scanf("%d", &n);
	int a[1000][3] = {0};
	for (i = 0; i < n; i++) {
		scanf("%d %d %d", &a[i][0], &a[i][1], &a[i][2]);
	}
	double x = 0.00, y = 1000000.00;
	for (i = 0; i < n; i++) {
		for (k = 0; k < n; k++) {
			x += sqrt((a[i][1] - a[k][1]) * (a[i][1] - a[k][1]) + (a[i][2] - a[k][2]) * (a[i][2] - a[k][2]));
		}
		t++;
		if (x <= y) {
			y = x;
			l = t;
		}
	}
	printf("%d %.2f", t, y);
	return 0;
}