#include <stdio.h>
#include <string.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int s1 = 0, s2 = 0, s3 = 0;
	int i;
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			s1 += 1;
	}
	for (i = m; i <= n; i++) {
		if (i % 2 == 1)
			s2 += 1;
	}
	for (i = m; i <= n; i++) {
		if (i % 3 == 0 && i % 7 != 0)
			s3 += 1;
	}
	int max = s1;
	if (s2 > max)
		max = s2;
	if (s3 > max)
		max = s3;
	printf("%d %d %d\n%d", s1, s2, s3, max);
	return 0;
}