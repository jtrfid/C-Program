#include <stdio.h>

int fact(int n) {
	int i, sum = 1;
	for (i = 1; i <= n; i++) {
		sum *= 2;
	}
	return sum;
}

int main() {
	int m, n, i, d, j;
	int a[100], b[100];
	scanf("%d%d", &n, &m);
	d = fact(n);
	for (i = 0; i < d; i++) {
		scanf("%d", &a[i]);
	}
	for (j = 1; j <= m; j++) {
		for (i = 0; i < d / 2 ; i++) {
			b[i] = a[i] + a[d - i - 1];
		}
		for (i = 0; i < d / 2; i++) {
			a[i] = b[i];
		}
		d = d / 2;
	}
	d = fact(n) / fact(m);
	for (i = 0; i < d; i++) {
		printf("%d ", b[i]);
	}
}