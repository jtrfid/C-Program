#include <stdio.h>
#include <math.h>

int main() {
	struct info {
		int num;
		float x, y;
		float sum;
	} stu[100], temp;
	int n, i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d%f%f", &stu[i].num, &stu[i].x, &stu[i].y);
		stu[i].sum = 0;
	}
	temp.sum = 0;
	temp.num = 0;

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			stu[i].sum += sqrt((stu[i].x - stu[j].x) * (stu[i].x - stu[j].x) + (stu[i].y - stu[j].y) * (stu[i].y - stu[j].y));
			if (stu[i].sum > temp.sum)
				temp = stu[i];
			else if (stu[i].sum = temp.sum && stu[i].num > temp.num)
				temp = stu[i];
		}
	}

	printf("%d %.2f", temp.num, temp.sum);
	return 0;

}