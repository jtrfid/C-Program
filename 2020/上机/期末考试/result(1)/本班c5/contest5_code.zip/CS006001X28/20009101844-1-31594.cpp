#include <stdio.h>

int main() {
	int m, n, max;
	int sum1 = 0, sum2 = 0, sum3 = 0;
	scanf("%d%d", &m, &n);
	for (int i = m; i <= n; i++) {
		if (i % 2 == 0)
			sum1++;
		else if (i % 2 != 0)
			sum2++;
	}
	for (int i = m; i <= n; i++) {
		if (i % 3 == 0 && i % 7 != 0)
			sum3++;
	}
	max = sum1;
	if (sum2 > max)
		max = sum2;
	if (sum3  > max)
		max = sum3;
	printf("%d %d %d\n%d", sum1, sum2, sum3, max);
	return 0;
}