#include <Stdio.h>

int main() {

	int n, m;
	scanf("%d%d", &n, &m);
	int t, k = 0;
	int a[1000] = {0};
	int b[1000] = {0};
	int count = 0;
	for (t = 1; count <= n - 1; count++) {
		t = t * 2;
	}

	int i;
	for (i = 0; i < t; i++)
		scanf("%d", &a[i]);
	int w;
	int mid = t / 2 - 1;
	int zhong = t / 2;
	for (w = 1; w <= m; w++) {
		for (i = 0; i <= mid; i++) {
			b[k] = a[i] + a[zhong*2 - 1 - i];
			k++;
		}
		for (i = 0; i < zhong; i++)
			a[i] = b[i];
		if (w != m) {
			mid = zhong / 2 - 1;
			zhong = zhong / 2;
			k = 0;
		} else
			break;
	}
	for (i = 0; i < zhong; i++)
		printf("%d ", a[i]);
	return 0;
}