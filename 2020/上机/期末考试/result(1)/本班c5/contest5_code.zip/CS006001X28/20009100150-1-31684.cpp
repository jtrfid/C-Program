#include <stdio.h>

int main() {
	int m, n, s1 = 0, s2 = 0, s3 = 0, s, i;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			s1 = s1 + 1;
		else
			s2 = s2 + 1;
		if (i % 3 == 0 && i % 7 != 0)
			s3 = s3 + 1;
	}
	if (s1 >= s2 && s1 >= s3)
		s = s1;
	if (s2 >= s1 && s2 >= s3)
		s = s2;
	if (s3 >= s1 && s3 >= s2)
		s = s3;
	printf("%d %d %d\n%d", s1, s2, s3, s);
	return 0;
}