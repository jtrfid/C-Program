#include <stdio.h>

int main() {
	int m, n, i, j, a[10][10];
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (int h = 0; h < n; h++) {
			for (j = h + 1; j < n; j++) {
				if (a[i][h] < a[i][j]) {
					int temp;
					temp = a[i][h];
					a[i][h] = a[i][j];
					a[i][j] = temp;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
}