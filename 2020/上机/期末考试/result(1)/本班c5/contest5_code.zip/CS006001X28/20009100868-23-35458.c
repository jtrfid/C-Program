#include <stdio.h>
#include <math.h>

typedef struct {
	int id;
	int x;
	int y;
	double sum;
} Init;

int main() {
	int i, j;
	Init stu[20] = {0};
	int N;
	scanf("%d", &N);
	for (i = 0; i < N; i++) {
		scanf("%d %d %d", &stu[i].id, &stu[i].x, &stu[i].y);
	}
	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			double cnt = (stu[i].x - stu[j].x) * (stu[i].x - stu[j].x) * 1.00 + (stu[i].y - stu[j].y) *
			             (stu[i].y - stu[j].y) * 1.00;
			stu[i].sum = stu[i].sum + sqrt(cnt);
		}
	}
	for (i = 0; i < N - 1; i++) {
		for (j = 0; j < N - i - 1; j++) {
			if (stu[j].sum > stu[j + 1].sum || stu[j].sum == stu[j].sum && stu[j + 1].id > stu[j].id) {
				Init temp = stu[j + 1];
				stu[j + 1] = stu[j];
				stu[j] = temp;
			}
		}
	}
	printf("%d  %.2lf", stu[0].id, stu[0].sum);
	return 0;
}