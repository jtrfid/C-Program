#include <stdio.h>

int pow(int m, int n) {
	int x = 1;
	if (n > 0) {
		for (int i = 0; i < n; i++) {
			x *= m;
		}
	}

	return x;
}

int main() {
	int i, j, k, m, n, a[65536] = {0};
	scanf("%d %d", &n, &m);
	for (i = 0; i < pow(2, n); i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < pow(2, n) / pow(2, i + 1); j++) {
			a[j] = a[j] + a[pow(2, n) / pow(2, i) - j - 1];
		}
	}
	for (i = 0; i < pow(2, n) / pow(2, m); i++) {
		printf("%d ", a[i]);
	}
	return 0;
}