#include <stdio.h>

int main() {
	int n, m;
	int i, j;
	int a[10][10];
	scanf("%d %d", &n, &m);
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int t, prep;
	for (i = 0; i < n; i++) {
		for (j = 1; j < m; j++) {
			for (t = 0; t < j; t++) {
				if (a[i][j] > a[i][t]);
				prep = a[i][j];
				a[i][j] = a[i][t];
				a[i][t] = prep;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", a[i][j]);
			if (j == m - 1) {
				printf("\n");
			}
		}
	}
	return 0;
}