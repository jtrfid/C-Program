#include <stdio.h>
#include <math.h>

int main() {
	int n, m, x;
	int sum;
	int i;
	int a[36];
	scanf("%d %d", &n, &m);
	sum = 1;
	for (i = 0; i < n; i++) {
		sum = sum * 2;
	}
	for (i = 0; i < sum; i++) {
		scanf("%d", &a[i]);
	}
	int t;
	t = sum;
	int j = 0;
	i = 0;
	for (j = 0; j < m; j++) {
		for (i = 0; i < sum; i++) {
			a[i] = a[i] + a[sum - 1 - i];
		}
		sum = sum / 2;
	}
	for (i = 0; i < sum; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}