#include <stdio.h>

int main() {
	int i, j, k, t, m, n;
	int a[20][10];
	scanf("%d %d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n - 1; j++) {
			for (k = 0; k < n - 1 - j; k++) {
				if (a[i][k] < a[i][k + 1]) {
					t = a[i][k];
					a[i][k] = a[i][k + 1];
					a[i][k + 1] = t;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}