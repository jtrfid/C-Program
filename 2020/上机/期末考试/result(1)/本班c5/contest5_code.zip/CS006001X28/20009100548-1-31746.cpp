#include <iostream>
using namespace std;

int main() {
	int m, n, sum[3] = {0}, max;
	cin >> m >> n;
	for (int i = m; i <= n; i++) {
		if (i % 2 == 0)
			sum[0] += 1;
		else
			sum[1] += 1;
		if (i % 3 == 0 && i % 7 != 0)
			sum[2] += 1;
	}
	max = sum[0];
	for (int i = 1; i < 3; i++)
		if (max < sum[i])
			max = sum[i];
	cout << sum[0] << " " << sum[1] << " " << sum[2] << endl;
	cout << max;
	return 0;
}