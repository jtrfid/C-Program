#include <stdio.h>
#include <math.h>

int main() {
	int n, m, num, i, j;
	int a[2000];
	scanf("%d%d", &n, &m);
	num = pow(2, n);
	for (i = 0; i < num; i++)
		scanf("%d", &a[i]);

	for (i = 1; i <= m; i++) {
		for (j = 0; j < num / 2; j++) {
			a[j] = a[j] + a[num - 1 - j];

		}
		num = num / 2;
	}
	for (i = 0; i < num; i++)
		printf("%d ", a[i]);

	return 0;
}