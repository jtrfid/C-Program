#include <stdio.h>

int main(void) {
	int n, m, i, j, t;
	int a[3] = {0};
	scanf("%d %d", &n, &m);
	for (i = n; i <= m; i++) {
		if (i % 2 == 0)
			a[1]++;
		else
			a[0]++;
		if (i % 3 == 0 && i % 7 != 0)
			a[2]++;
	}
	printf("%d %d %d\n", a[1], a[0], a[2]);
	for (i = 0; i < 2; i++) {
		for (j = i + 1; j < 3; j++) {
			if (a[i] < a[j]) {
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}
	}
	printf("%d", a[0]);
	return 0;
}