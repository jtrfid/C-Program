#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <malloc.h>

int main() {
	int m, n;
	int i, j, k;
	int num[15][15] = {0};
	scanf("%d %d", & m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &num[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n - 1; j++) {
			for (k = 0; k < n - j - 1; k++) {
				if (num[i][k + 1] > num[i][k]) {
					int temp = num[i][k];
					num[i][k] = num[i][k + 1];
					num[i][k + 1] = temp;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", num[i][j]);
		}
		printf("\n");
	}
	return 0;
}