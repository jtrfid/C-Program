#include <stdio.h>
#include <math.h>

struct stu {
	int c;
	int x;
	int y;
};

int main() {
	int n, w;
	scanf("%d", &n);
	struct stu a[n];
	int i, j;
	float  h;
	float k[n];
	for (i = 0; i < n; i++) {
		scanf("%d%d%d", &(a[i].c), &a[i].x, &a[i].y);
	}
	for (i = 0; i < n; i++) {
		k[i] = 0;
		for (j = 0; j < n; j++) {
			k[i] += pow(pow(a[i].x - a[j].x, 2) + pow(a[i].y - a[j].y, 2),   0.5    );
		}
	}
	h = k[0];
	w = 0;
	for (i = 1; i < n; i++) {
		if (k[i] < h || (k[i] == h && a[i].c > a[w].c) ) {
			h = k[i];
			w = i;
		}
	}
	printf("%d %.2f", a[w].c, h);
	return 0;
}