#include <stdio.h>
#include <math.h>

int main() {
	int n, i, j;
	scanf("%d", &n);
	struct stu {
		int bh;
		int x;
		int y;
	} t;
	stu stu[10000];
	for (i = 0; i < n; i++) {
		scanf("%d %d %d", &stu[i].bh, &stu[i].x, &stu[i].y);
		printf("\n");
	}
	float min;
	float sum[10000] = {0};
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (j != i) {
				sum[i] = sum[i] + sqrt((stu[j].x - stu[i].x) * (stu[j].x - stu[i].x) + (stu[j].y - stu[i].y) * (stu[j].y - stu[i].y));
			}
		}
	}
	min = sum[0];
	int s;
	for (i = 1; i < n; i++) {
		if (min >= sum[i]) {
			min = sum[i];
			s = i;
		}
	}
	printf("%d %.2f", s + 1, min);
	return 0;
}