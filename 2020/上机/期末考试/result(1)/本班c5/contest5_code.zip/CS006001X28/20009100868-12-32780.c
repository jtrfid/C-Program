#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <malloc.h>

int main() {
	int n, m, i, j;
	scanf("%d %d", &n, &m);
	int cnt = pow(2, n), a[100] = {0};
	for (i = 0; i < cnt; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < cnt / pow(2, i); j++) {
			int temp = cnt / pow(2, i) - 1 - j;
			a[j] = a[j] + a[temp];
		}
	}
	for (i = 0; i < cnt / pow(2, m); i++) {
		printf("%d ", a[i]);
	}


	return 0;
}