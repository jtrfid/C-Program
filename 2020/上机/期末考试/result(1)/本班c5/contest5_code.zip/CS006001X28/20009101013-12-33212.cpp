#include <stdio.h>

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	int l = 1, i, j;
	for (i = 0; i < m; i++)
		l = l * 2;
	int a[l];
	int t = l;
	for (i = 0; i < l; i++)
		scanf("%d", &a[i]);

	for (i = 0; i < n; i++) {
		t = l;
		l = l / 2;
		for (j = 0; j < t / 2; j++)
			a[j] = a[t - 1 - j] + a[j];

	}
	for (i = 0; i < l; i++)
		printf("%d ", a[i]);
	return 0;
}