#include <Stdio.h>

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	int sum[3] = {0};
	int i;
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			sum[0]++;
		if (i % 2 != 0)
			sum[1]++;
		if (i % 3 == 0 && i % 7 != 0)
			sum[2]++;
	}
	int j;
	int t;
	int a = sum[0];
	int b = sum[1];
	int c = sum[2];
	for (i = 0; i < 2; i++)
		for (j = i + 1; j < 3; j++) {
			if (sum[i] < sum[j]) {
				t = sum[i];
				sum[i] = sum[j];
				sum[j] = t;
			}
		}
	printf("%d %d %d\n", a, b, c);
	printf("%d", sum[0]);


	return 0;
}