#include <iostream>
#include <math.h>
using namespace std;

int main() {
	int m, n;
	cin >> n >> m;
	const int x = pow(2, n);
	int y = x;
	int a[x];
	for (int i = 0; i < x; i++)
		cin >> a[i];
	for (int i = 0; i < m; i++) {
		y /= 2;
		for (int j = 0; j < y; j++)
			a[j] += a[y * 2 - 1 - j];
	}
	for (int i = 0; i < y - 1; i++)
		cout << a[i] << " ";
	cout << a[y - 1];
	return 0;
}