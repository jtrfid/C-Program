#include <stdio.h>
#include <math.h>

typedef struct  {
	int num;
	int x;
	int y;
} stu;

int main() {
	int n, i, j, a, b, number;
	float min;
	stu s[100000];
	int numb[100000];
	float sum[100000];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d%d%d", &s[i].num, &s[i].x, &s[i].y);
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			a = pow((s[i].x - s[j].x), 2);
			b = pow((s[i].y - s[j].y), 2);
			sum[i] += pow((a + b), 1.0 / 2);
			numb[i] = s[i].num;
		}
	}
	min = sum[0];
	number = numb[0];
	for (i = 1; i < n; i++) {
		if (sum[i] < min) {
			min = sum[i];
			number = numb[i];
		} else if (sum[i] == min) {
			if (numb[i] > number) {
				number = numb[i];
			}
		}
	}
	printf("%d %.2f", number, min);
	return 0;
}