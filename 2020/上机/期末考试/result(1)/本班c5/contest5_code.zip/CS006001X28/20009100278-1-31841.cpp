#include <stdio.h>

int main() {
	int a, b, i, ou = 0, ji = 0, count = 0, max;
	scanf("%d%d", &a, &b);
	for (i = a; i <= b; i++) {
		if (i % 2 == 0)
			ou++;
		if (i % 2 == 1)
			ji++;
		if (i % 3 == 0 && i % 7 != 0)
			count++;
	}
	if (ou > ji)
		max = ou;
	else
		max = ji;
	printf("%d %d %d\n%d", ou, ji, count, max);
	return 0;
}