#include <stdio.h>
#include <string.h>

int main () {
	int m, n, od, ev, sp, i, max;
	od = 0;
	ev = 0;
	sp = 0;
	scanf("%d %d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			ev++;
		if (i % 2 == 1)
			od++;
		if (i % 3 == 0 && i % 7 != 0)
			sp++;
	}
	if (ev > od)
		max = ev;
	else
		max = od;
	if (sp > max)
		max = sp;

	printf("%d %d %d\n", ev, od, sp);
	printf("%d", max);
	return 0;
}