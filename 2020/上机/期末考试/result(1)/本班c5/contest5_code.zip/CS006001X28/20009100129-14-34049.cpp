#include <stdio.h>

void sort(int a[], int n) {
	int i, j, temp;
	int max;
	for (i = 0; i < n - 1; i++) {
		max = a[i];
		for (j = i + 1; j < n; j++) {
			if (max < a[j]) {
				max = a[j];
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}

int main() {
	int n, m;
	int i, j;
	scanf("%d %d", &m, &n);
	int a[m][n];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		sort(a[i], n);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}