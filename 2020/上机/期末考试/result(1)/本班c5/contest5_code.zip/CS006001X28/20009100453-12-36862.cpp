#include <stdio.h>

int pow(int a) {
	int i, j;
	j = 1;
	for (i = 0; i < a; i++) {
		j *= 2;
	}
	return j;
}

int main() {
	int m, n, i, j, a, b, c, x, y;
	scanf("%d%d", &m, &n);
	a = pow(m);
	int str[a];
	for (i = 0; i < a; i++) {
		scanf("%d", &str[i]);
	}
	j = 0;
	x = m - n;
	b = pow(x);
	int arr[b] = {0};
	for (i = 0; i < b; i++) {
		arr[i] += str[i];
		for (j = 0; j < n; j++) {
			y = m - j;
			c =  pow(y);
			arr[i] += str[c - i - 1];
		}
	}
	for (i = 0; i < b; i++) {
		printf("%d ", arr[i]);
	}
}