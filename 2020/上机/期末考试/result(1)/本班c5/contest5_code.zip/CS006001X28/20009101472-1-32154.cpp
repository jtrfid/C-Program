#include <stdio.h>
int single(int, int);
int doub(int, int);
int what(int, int );

int main() {
	int m, n, a, b, c, max;
	scanf("%d %d", &m, &n);
	a = doub(m, n);
	b = single(m, n);
	c = what(m, n);
	max = a;
	if (a < b)
		max = b;
	else if (a < c)
		max = c;
	printf("%d %d %d\n%d", a, b, c, max);
	return 0;
}

int single(int m, int n) {
	int count = 0;
	for (int i = m; i <= n; i++) {
		if (i % 2 != 0)
			count++;
	}
	return count;
}

int doub(int m, int n) {
	int count = 0;
	for (int i = m; i <= n; i++) {
		if (i % 2 == 0)
			count++;
	}
	return count;
}

int what(int m, int n) {
	int count = 0;
	for (int i = m; i <= n; i++) {
		if (i % 3 == 0 && i % 7 != 0)
			count++;
	}
	return count;
}