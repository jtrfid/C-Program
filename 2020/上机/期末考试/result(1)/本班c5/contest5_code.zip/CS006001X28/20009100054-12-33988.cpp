#include <stdio.h>

int  main() {
	int m, n, s;
	scanf("%d%d", &n, &m);
	int a[64], i, k = 1, j, x = 1;
	for (i = 0; i < n; i++) {
		k *= 2;
	}
	for (i = 0; i < k; i++)
		scanf("%d", &a[i]);
	for (i = 0; i < m; i++) {
		for (j = 0; j < i; j++)
			x *= 2;
		for (s = 0; s < k / x; s++) {
			a[s] = a[s] + a[k / x - s - 1];
		}
	}
	x = 1;
	for (i = 0; i < m ; i++)
		x *= 2;
	for (i = 0; i < k /  x; i++)
		printf("%d ", a[i]);
	return 0;
}