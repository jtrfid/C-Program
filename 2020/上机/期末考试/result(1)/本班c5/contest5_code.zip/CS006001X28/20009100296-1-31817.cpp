#include <stdio.h>

int main() {
	int n, m, i;
	scanf("%d%d", &n, &m);
	int a = 0, b = 0, c = 0, d;
	for (i = n; i <= m; i++) {
		if (i % 2 == 1) {
			a++;
		}
		if (i % 2 == 0) {
			b++;
		}
		if (i % 3 == 0 && i % 7 != 0) {
			c++;
		}

	}
	if (a >= b && a >= c) {
		d = a;
	}
	if (b >= a && b >= c) {
		d = b;
	}
	if (c >= b && c >= a) {
		d = c;
	}
	printf("%d %d %d\n%d", a, b, c, d);


	return 0;
}