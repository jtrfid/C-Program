#include <stdio.h>

int main() {
//	int i1 = 0, i2 = 0;
	int m, n, t;
	int j = 0, i = 0, x = 0;
	int a[m][n];
	scanf("%d %d", &m, &n);
	for (j; j < m; j++) {
		for ( i ; i < n; i++) {
			scanf("%d", &a[j][i]);
		}
	}
	for ( j ; j < m; j++) {
		for ( x ; x < n - 1; x++) {

			for (i; i < n - x - 1; i++) {
				if (a[j][i] < a[j][i + 1]) {
					t = a[j][i + 1];
					a[j][i + 1] = a[j][i];
					a[j][i] = t;
				}
			}
		}
	}
	for ( j; j < m; j++) {
		for (i; i < n; i++) {
			printf("%d ", a[j][i]);
		}
		printf("\n");
	}
	return 0;
}