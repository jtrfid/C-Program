#include <stdio.h>
#include <math.h>

struct stu {
	int num;
	int x;
	int y;
};

int main() {
	int n, minID;
	scanf("%d", &n);
	struct stu student[n];
	float d[n] = {0}, min;
	for (int i = 0; i < n; i++)
		scanf("%d %d %d", &student[i].num, &student[i].x, &student[i].y);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			d[i] += pow(pow(student[i].x - student[j].x, 2) + pow(student[i].y - student[j].y, 2), 0.5);
	}
	minID = 1;
	min = d[0];
	for (int i = 1; i < n; i++)
		if (min > d[i]) {
			min = d[i];
			minID = student[i].num;
		}
	printf("%d %.2f", minID, min);
	return 0;
}