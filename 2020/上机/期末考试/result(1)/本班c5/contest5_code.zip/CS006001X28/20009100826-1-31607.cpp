#include <stdio.h>

int main() {
	int a, b, j, o, n;
	scanf("%d %d", &a, &b);
	int i;
	j = 0;
	o = 0;
	n = 0;
	for (i = a; i <= b; i++) {
		if (i % 2 == 0) {
			o++;
		} else {
			j++;
		}
		if (i % 3 == 0 && i % 7 != 0) {
			n++;
		}
	}
	int max = o;
	if (max < j) {
		max = j;
	}
	if (max < n) {
		max = n;
	}
	printf("%d %d %d\n%d", o, j, n, max);
	return 0;
}