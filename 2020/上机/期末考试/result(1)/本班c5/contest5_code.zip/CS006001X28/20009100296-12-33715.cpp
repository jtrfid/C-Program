#include <stdio.h>

int main() {
	printf("qqqq");
	return 0;
}