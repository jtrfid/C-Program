#include <stdio.h>

int main() {
	int a[10][10], i, j, k, m, n, temp;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n - 1; j++)
			for (k = j + 1; k < n; k++) {
				if (a[i][j] < a[i][k]) {
					temp = a[i][j];
					a[i][j] = a[i][k];
					a[i][k] = temp;
				}
			}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
	return 0;
}