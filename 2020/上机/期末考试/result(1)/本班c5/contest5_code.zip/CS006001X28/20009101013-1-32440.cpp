#include <stdio.h>

int main() {
	int n = 0, m = 0;
	scanf("%d%d", &n, &m);
	int o = 0, j = 0, t = 0;
	int i;
	for (i = n; i <= m; i++) {
		if (i % 2 == 0)
			o++;
		else
			j++;
		if ((i % 3 ) == 0 && (i % 7 ) != 0)
			t++;
	}
	printf("%d %d %d\n", o, j, t);
	if (o >= j && o >= t)
		printf("%d", o);
	else if (j >= o && j >= t)
		printf("%d", j);
	else
		printf("%d", t);



	return 0;
}