#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int i, m, n, num, time = 0, a[64];
	scanf("%d %d", &n, &m);
	num = pow(2, n);
	for (i = 0; i < num; i++)
		scanf("%d", &a[i]);
	while (time < m) {
		for (i = 0; i < num / 2; i++)
			a[i] = a[i] + a[num - 1 - i];
		num /= 2;
		time++;

	}
	for (i = 0; i < num; i++)
		printf("%d ", a[i]);

	return 0;
}