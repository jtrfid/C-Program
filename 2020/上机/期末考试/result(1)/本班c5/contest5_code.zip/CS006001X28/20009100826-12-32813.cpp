#include <stdio.h>
#include <math.h>

int main() {
	int n, m;
	int sum;
	int i;
	int a[36];
	scanf("%d %d", &n, &m);
	for (i = 0; i < pow(2, n); i++) {
		scanf("%d", &a[i]);
	}
	sum = pow(2, n);
	int t;
	t = sum;
	int j = 0;
	i = 0;
	for (j = 0; j < m; j++) {
		for (i = 0; i < sum; i++) {
			a[i] = a[i] + a[sum - 1 - i];
		}
		sum = sum / 2;
	}
	for (i = 0; i < sum; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}