#include <stdio.h>

int main() {
	int m, n, i, j, k, t;
	scanf("%d %d", &m, &n);
	int a[m][n];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 1; j < n; j++) {
			for (k = 0; k < n - j; k++) {
				if (a[i][k] < a[i][k + 1]) {
					t = a[i][k];
					a[i][k] = a[i][k + 1];
					a[i][k + 1] = t;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}