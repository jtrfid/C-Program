#include <Stdio.h>
#include <math.h>
int main() {

	struct s {
		int hao;
		int x;
		int y;
		double dis;
	} s[1000];
	int m, i, j;
	int sum = 0;
	int count=1;
	scanf("%d", &m);
	for (i = 0; i < m; i++)
		scanf("%d%d%d", &s[i].hao, &s[i].x, &s[i].y);
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			sum = (s[j].x - s[i].x) * (s[j].x - s[i].x) + (s[j].y - s[i].y) * (s[j].y - s[i].y);
			s[i].dis += sqrt(sum);
		}
	}
	struct s temp;
	for (i = 0; i < m - 1; i++)
		for (j = i + 1; j < m; j++) {
			if (s[i].dis > s[j].dis) {
				temp = s[i];
				s[i] = s[j];
				s[j] = temp;
			}
		}
		for(i=0;i<m-1;i++)
		if(s[i].dis==s[i+1].dis)
		{
		count++;	
		}
		if(count==1)
	printf("%d %.2lf", s[0].hao, s[0].dis);
	else
	{
			for (i = 0; i < m - 1; i++)
		for (j = i + 1; j < m; j++) {
			if (s[i].dis > s[j].dis) {
				temp = s[i];
				s[i] = s[j];
				s[j] = temp;
			}
			if(s[i].dis==s[j].dis)
			{
				if(s[i].hao<s[j].hao)
				
				{
				temp = s[i];
				s[i] = s[j];
				s[j] = temp;	
				}
			}
		}
		printf("%d %.2lf", s[0].hao, s[0].dis);
	}



	return 0;
}