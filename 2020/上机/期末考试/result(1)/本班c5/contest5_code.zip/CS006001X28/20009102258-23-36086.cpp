#include <stdio.h>
#include <math.h>

int main () {
	int a[100000][3], i, j, n, t;
	float sum, sumn = 100000;
	scanf ("%d", &n);
	for (i = 0; i < n; i++) {
		for (j = 0; j < 3; j++)
			scanf("%d", &a[i][j]);
	}

	for (i = 0; i < n; i++) {
		sum = 0;
		{
			for (j = 0; j < n; j++)
				if (j != i)
					sum = sum + pow(((a[i][1] - a[j][1]) * (a[i][1] - a[j][1]) + (a[i][2] - a[j][2]) * (a[i][2] - a[j][2])), 0.5);
		}
		if (sum <= sumn) {
			sumn = sum;
			t = a[i][0];
		}
	}
	printf("%d %.2f", t, sum);
	return 0;
}