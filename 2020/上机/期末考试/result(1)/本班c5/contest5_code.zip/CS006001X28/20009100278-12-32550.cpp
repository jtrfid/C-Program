#include <stdio.h>
#include <math.h>

int main() {
	int n, m, i, j, a[65], b, flag;
	scanf("%d%d", &n, &m);
	b = pow(2, n);
	flag = b;
	for (i = 0; i < b; i++)
		scanf("%d", &a[i]);
	for (i = 0; i < m; i++) {
		flag /= 2;
		for (j = 0; j < flag; j++)
			a[j] += a[b - j - 1];
		b /= 2;
	}
	for (i = 0; i < b - 1; i++)
		printf("%d ", a[i]);
	printf("%d ", a[b - 1]);
	return 0;
}