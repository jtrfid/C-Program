#include <stdio.h>

int main(void) {
	int n, m, i, j, sum, sum1;
	scanf("%d %d", &n, &m);
	int a[99999] = {0};
	sum = 2;
	sum1 = 2;
	for (i = 0; i < n - 1; i++) {
		sum *= 2;
	}
	for (i = 0; i < m - 1; i++) {
		sum1 *= 2;
	}

	for (i = 0; i < sum; i++) {
		scanf("%d", &a[i]);
	}
	int q = sum;
	for (i = 1; i <= m; i++) {
		q /= 2;
		for (j = 0; j < q; j++) {
			a[j] = a[j] + a[q * 2 - j - 1];
		}
	}
	for (i = 0; i < sum / sum1; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}