#include <stdio.h>
#include <math.h>

typedef struct {
	int num;
	int x;
	int y;
} sss;

int main(void) {
	sss stu[10000];
	int n, i, j, c = 0;
	double s = 0.0, min = 0.0;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d %d %d", &stu[i].num, &stu[i].x, &stu[i].y);
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (j == i && j == n - 1)
				break;
			else if (j == i)
				j++;
			s += sqrt((stu[i].x - stu[j].x) * (stu[i].x - stu[j].x) * 1.00 +
			          (stu[i].y - stu[j].y) * (stu[i].y - stu[j].y) * 1.00);

		}
		if (i == 0)
			min = s;
		else if (s <= min) {
			min = s;
			c = i;
		}
		s = 0.0;
	}
	printf("%d %.2f", c + 1, min);
	return 0;
}