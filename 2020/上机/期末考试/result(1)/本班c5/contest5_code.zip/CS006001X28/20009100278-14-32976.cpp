#include <stdio.h>

int main() {
	int i, j, k, m, n, a[11][11], zj;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 1; j < n; j++) {
			for (k = 0; k < j; k++) {
				if (a[i][k] < a[i][j]) {
					zj = a[i][k];
					a[i][k] = a[i][j];
					a[i][j] = zj;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n - 1; j++) {
			printf("%d ", a[i][j]);
		}
		printf("%d\n", a[i][j]);
	}
	return 0;
}