#include <stdio.h>
#include <math.h>

struct xia {
	int id;
	float x;
	float y;
	float len = 0;
};

int main() {
	struct xia xiao[100001];
	int i, j, n, pos;
	float min;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		scanf("%d%f%f", &xiao[i].id, &xiao[i].x, &xiao[i].y);
	for (i = 0; i < n; i++) {
		for (j = 0; j < i; j++)
			xiao[i].len += sqrt((xiao[i].x - xiao[j].x) * (xiao[i].x - xiao[j].x) + (xiao[i].y - xiao[j].y) *
			                    (xiao[i].y - xiao[j].y));
		for (j = i + 1; j < n; j++)
			xiao[i].len += sqrt((xiao[i].x - xiao[j].x) * (xiao[i].x - xiao[j].x) + (xiao[i].y - xiao[j].y) *
			                    (xiao[i].y - xiao[j].y));
	}
	min = xiao[0].len;
	pos = xiao[0].id;
	for (i = 1; i < n; i++) {
		if ((min > xiao[i].len) || (min == xiao[i].len && xiao[i].id > pos)) {
			min = xiao[i].len;
			pos = xiao[i].id;
		}
	}
	printf("%d %.2f", pos, min);
	return 0;
}
//xiao[i].a=