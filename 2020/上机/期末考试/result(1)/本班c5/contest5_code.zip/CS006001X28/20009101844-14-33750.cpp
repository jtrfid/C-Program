#include <stdio.h>

int main() {
	int m, n, t;
	scanf("%d%d", &m, &n);
	int a[m][n];
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n - 1; j++) {
			for (int k = j + 1; k < n; k++)
				if (a[i][j] < a[i][k]) {
					t = a[i][j];
					a[i][j] = a[i][k];
					a[i][k] = t;
				}
		}
	}
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
	return 0;
}