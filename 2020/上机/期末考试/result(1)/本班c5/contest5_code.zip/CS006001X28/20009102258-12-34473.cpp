#include <stdio.h>

int main () {
	int i, j, k = 1, m, n, s, a[64];
	scanf("%d %d", &n, &m);
	for (i = 0; i < n; i++)
		k = 2 * k;
	s = k;
	for (i = 0; i < k; i++)
		scanf ("%d", &a[i]);
	for (i = 0; i < m; i++) {
		for (j = 0; j < (s / 2); j++) {
			a[j] = a[j] + a[s - 1 - j];
		}
		s = s / 2;
	}
	s = 1;
	for (i = 0; i < m; i++)
		s = 2 * s;
	k = k / s;
	for (i = 0; i < k; i++)
		printf("%d ", a[i]);
	return 0;
}