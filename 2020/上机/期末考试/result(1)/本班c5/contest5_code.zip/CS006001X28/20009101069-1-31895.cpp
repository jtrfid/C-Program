#include <stdio.h>

int main() {
	int i, m, n, a = 0, b = 0, c = 0;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			a++;
	}
	for (i = m; i <= n; i++) {
		if (i % 2 != 0)
			b++;
	}
	for (i = m; i <= n; i++) {
		if (i % 3 == 0 && i % 7 != 0)
			c++;
	}
	if (a >= b && a >= c)
		printf("%d", a);
	if (b >= a && b >= c)
		printf("%d", b);
	if (c >= a && c >= b)
		printf("%d", c);
	return 0;
}