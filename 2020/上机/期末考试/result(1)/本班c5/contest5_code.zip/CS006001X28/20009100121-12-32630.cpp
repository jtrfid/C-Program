#include <bits/stdc++.h>

int main() {
	int n, m, i, x, j, a[100];
	scanf("%d%d", &n, &m);
	x = pow(2, n);
	for (i = 0; i < x; i++)
		scanf("%d", &a[i]);

	while (m--) {
		for (i = 0; i < x / 2; i++) {
			a[i] = a[i] + a[x - 1 - i];
		}
		x /= 2;
	}
	for (i = 0; i < x; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}