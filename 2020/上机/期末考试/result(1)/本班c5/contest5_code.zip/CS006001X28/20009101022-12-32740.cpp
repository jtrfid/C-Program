#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int n, m, zs, a[1000], flag = 0;
	scanf("%d%d", &n, &m);
	zs = pow(2, n);
	for (int i = 0; i < zs; i++)
		scanf("%d", &a[i]);
	while (flag < m) {

		for (int i = 0; i < zs / 2; i++)
			a[i] += a[zs - i - 1];
		zs /= 2;
		flag++;
	}
	for (int i = 0; i < zs; i++)
		printf("%d ", a[i]);
	return 0;
}