#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int m, n, max = 0;
	int ou(int m, int n), ji(int m, int n), zc(int m, int n);
	scanf("%d%d", &m, &n);
	if (ou(m, n) > max)
		max = ou(m, n);
	if (ji(m, n) > max)
		max = ji(m, n);
	if (zc(m, n) > max)
		max = zc(m, n);
	printf("%d %d %d\n%d", ou(m, n), ji(m, n), zc(m, n), max);
	return 0;
}

int ou(int m, int n) {
	int flag = 0;
	for (int i = (m > n ? n : m); i <= (m > n ? m : n); i++)
		if (i % 2 == 0)
			flag++;
	return flag;
}

int ji(int m, int n) {
	int flag = 0;
	for (int i = (m > n ? n : m); i <= (m > n ? m : n); i++)
		if (i % 2 != 0)
			flag++;
	return flag;
}

int zc(int m, int n) {
	int flag = 0;
	for (int i = (m > n ? n : m); i <= (m > n ? m : n); i++)
		if (i % 3 == 0 && i % 7 != 0)
			flag++;
	return flag;
}