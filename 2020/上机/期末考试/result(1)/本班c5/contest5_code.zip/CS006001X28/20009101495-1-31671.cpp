#include <stdio.h>

int main() {
	int m, n;
	int a = 0, b = 0, c = 0, i, max = 0;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			a++;
		if (i % 2 == 1)
			b++;
		if (i % 3 == 0 && i % 7 != 0)
			c++;
	}
	if (a > b && a > c)
		max = a;
	else if (c > b && c > a)
		max = c;
	else if (b > c && b > a)
		max = b;
	printf("%d %d %d\n%d", a, b, c, max);
	return 0;
}