#include <stdio.h>

int main() {
	int m, n, i, j, num = 1, sum = 0;
	int a[100], b[100];
	scanf("%d%d", &n, &m);
	for (i = 0; i < n; i++) {
		num = num * 2;
	}
	for (i = 0; i < num; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 1; i <= m; i++) {
		for (j = 0; j < num; j++) {
			a[j] = a[j] + a[num - 1 - j];
		}
		num = num / 2;
	}
	for (i = 0; i < num; i++) {
		printf("%d ", a[i]);
	}
	return 0;

}