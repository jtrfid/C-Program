# include <stdio.h>

int main (void) {
	int a[3] = {0, 0, 0};
	int m, n, i, j = 0;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			a[0]++;
	}
	for (i = m; i <= n; i++) {
		if (i % 2 != 0)
			a[1]++;
	}
	for (i = m; i <= n; i++) {
		if (i % 3 == 0 && i % 7 != 0)
			a[2]++;
	}
	for (i = 0; i < 3; i++) {
		if (a[i] > a[j])
			j = i;
	}
	printf("%d %d %d\n%d", a[0], a[1], a[2], a[j]);
	return 0;
}