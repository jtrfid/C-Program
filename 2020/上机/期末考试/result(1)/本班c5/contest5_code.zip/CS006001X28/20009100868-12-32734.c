#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <malloc.h>

int main() {
	int n, m, i, j;
	scanf("%d %d", &n, &m);
	int cnt = pow(2, n), a[100] = {0};
	for (i = 0; i < cnt; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < cnt / pow(2, i); j++) {
			int temp = cnt / pow(2, i) - 1 - j;
			a[j] = a[j] + a[temp];
		}
	}
	for (i = 0; i < cnt / pow(2, m); i++) {
		printf("%d ", a[i]);
	}
	return 0;
}




//������Ӵ�
//��0�к͵�0�и�0
//�����ȣ����Ͻ�+1
//�������ȣ�=0



//ð������
//	int i,j,n;
//	for(i=0;i<n;i++)
//	{
//		for(j=0;j<n-i-1;j++)
//		{
//			if(ch[j+1]<ch[j])
//			{
//				int temp=ch[j];
//				ch[j]=ch[j+1];
//				ch[j+1]=temp;
//			}
//		}
//	}