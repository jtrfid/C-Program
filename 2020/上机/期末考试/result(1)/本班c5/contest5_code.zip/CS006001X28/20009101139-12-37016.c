#include <stdio.h>

int main() {
	int a[1000], b[1000], c[1000], d[1000], e[1000], f[1000], flag = 0, n, x, m, i, j;
	scanf("%d%d", &n, &m);
	for (i = 1; i <= n; i++) {
		x *= 2;
	}
	for (j = 0; j < x; j++) {
		scanf("%d", &a[j]);
	}
	for (j = 0; j < (x / 2); j++) {
		b[j] = a[j] + a[x - j - 1];
	}
	flag++;
	if (flag == m) {
		for (i = 0; i < (x / 2); i++) {
			printf("%d ", b[i]);
		}
	}//һ��ת��
	int q = x / 2;
	for (j = 0; j < (q / 2); j++) {
		c[j] = b[j] + b[q - j - 1];
	}
	flag++;
	if (flag == m) {
		for (i = 0; i < (q / 2); i++) {
			printf("%d ", c[i]);
		}
	}//����ת��
	int l = q / 2;
	for (j = 0; j < (l / 2); j++) {
		d[j] = c[j] + c[l - j - 1];
	}
	flag++;
	if (flag == m) {
		for (i = 0; i < (l / 2); i++) {
			printf("%d ", d[i]);
		}
	}//����ת��
	int u = l / 2;
	for (j = 0; j < (u / 2); j++) {
		e[j] = d[j] + d[u - j - 1];
	}
	flag++;
	if (flag == m) {
		for (i = 0; i < (u / 2); i++) {
			printf("%d ", e[i]);
		}
	}//����ת��
	int p = u / 2;
	for (j = 0; j < (p / 2); j++) {
		f[j] = e[j] + e[p - j - 1];
	}
	flag++;
	if (flag == m) {
		for (i = 0; i < (p / 2); i++) {
			printf("%d ", f[i]);
		}
	}
	return 0;
}