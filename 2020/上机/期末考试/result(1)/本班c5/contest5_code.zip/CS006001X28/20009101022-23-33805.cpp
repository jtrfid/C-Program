#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int n, flag;
	float min = 121212121;
	scanf("%d", &n);
	struct info {
		int num, x, y;
		float jl;
	} stu[n] = {0};
	for (int i = 0; i < n; i++)
		scanf("%d %d %d", &stu[i].num, &stu[i].x, &stu[i].y);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			stu[i].jl += sqrt(pow(stu[i].x - stu[j].x, 2) + pow(stu[i].y - stu[j].y, 2));
		if (stu[i].jl < min || (stu[i].jl == min && stu[i].num > stu[flag].num)) {
			min = stu[i].jl;
			flag = i;
		}
	}
	printf("%d %.2f", stu[flag].num, min);
	return 0;
}