typedef struct {
	int num;
	int x;
	int y;
} STU;

#include <stdio.h>
#include <math.h>
int main() {
	int n, t;
	float sum;
	scanf("%d", &n);
	STU s[n];
	for (int i = 0; i < n; i++)
		scanf("%d%d%d", &s[i].num, &s[i].x, &s[i].y);
	float a[n];
	int   b[n];
	for (int i = 0; i < n; i++) {
		sum = 0.0;
		for (int j = 0; j < n; j++) {
			sum = sum + sqrt((s[i].x - s[j].x) * (s[i].x - s[j].x) + (s[i].y - s[j].y) * (s[i].y - s[j].y));
		}
		a[i] = sum;
		b[i] = s[i].num;
	}
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			if (a[i] > a[j]) {
				t = a[i];
				a[i] = a[j];
				a[j] = t;
				t = b[i];
				b[i] = b[j];
				b[j] = t;
			}
	printf("%d %.2f", b[0], a[0]);
	return 0;
}