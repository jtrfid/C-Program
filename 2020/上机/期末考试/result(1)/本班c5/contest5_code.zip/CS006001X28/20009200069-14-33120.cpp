#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int i, j, m, n, tmp, k, a[10][10];
	scanf("%d %d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n - 1; j++) {
			for (k = j + 1; k < n; k++) {
				if (a[i][j] < a[i][k]) {
					tmp = a[i][j];
					a[i][j] = a[i][k];
					a[i][k] = tmp;
				}
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
	return 0;
}