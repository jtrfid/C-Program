#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int n, m, zs, a[1000], flag = 0;
	scanf("%d%d", &n, &m);
	zs = pow(2, n);
	for (int i = 0; i < zs; i++)
		scanf("%d", &a[i]);
	while (flag < m) {
		for (int i = 0; i < zs / 2.0; i++)
			a[i] += a[zs - i - 1];
		flag++;
	}
	for (int i = 0; i < (float)(zs) / pow(2, m); i++)
		printf("%d ", a[i]);
	return 0;
}