#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int n, m;
	scanf("%d %d", &n, &m);
	int num = pow(2, n);
	int num2 = pow(2, n);
	int a[num];
	int i;
	for (i = 0; i < num; i++) {
		scanf("%d", &a[i]);
	}


	int j, k, sum = 0;
	for (sum = 1; sum <= m; ) {
		for (i = 0; i < num / 2; i++) {
			a[i] = a[i] + a[num - 1 - i];
		}
		num /= 2;
		sum += 1;
	}
	for (i = 0; i < num2 / pow(2, m); i++) {
		printf("%d ", a[i]);
	}
	return 0;
}