#include <stdio.h>
#include <math.h>

int main() {
	struct stu {
		int num;
		int x;
		int y;
	};
	int n, i, j;
	int JIHE;
	float temp = 0, dis = -1;
	scanf("%d", &n);
	stu S[n];
	for (i = 0; i < n; i++) {
		scanf("%d %d %d", &S[i].num, &S[i].x, &S[i].y);
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			temp += sqrt(pow(S[j].x - S[i].x, 2.0) + pow(S[j].y - S[i].y, 2.0));
		}
		if (dis < 0 || ((temp <= dis) && i + 1 > JIHE)) {
			dis = temp;
			JIHE = i + 1;
		}
		temp = 0;
	}
	printf("%d %.2f", JIHE, dis);
	return 0;
}