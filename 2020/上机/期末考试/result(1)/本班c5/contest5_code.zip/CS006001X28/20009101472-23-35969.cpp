#include <stdio.h>
#include <math.h>

typedef struct place {
	int x, y, num;
	double sum;
} p;

int main() {
	p a[100], max;
	int n, i, j, k;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d %d %d", &a[i].num, &a[i].x, &a[i].y);
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			a[i].sum += pow(pow(a[j].x - a[i].x, 2) + pow(a[j].y - a[i].y, 2), 0.5);
		}
	}
	max = a[0];
	for (i = 1; i < n; i++) {
		if (a[i].sum < max.sum) {
			max = a[i];
		} else if (a[i].sum == max.sum && a[i].num > max.num) {
			max = a[i];
		}
	}
	printf("%d %.2f", max.num, max.sum);
	return 0;
}