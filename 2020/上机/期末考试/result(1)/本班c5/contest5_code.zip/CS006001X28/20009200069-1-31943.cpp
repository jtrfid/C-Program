#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int m, n, n1 = 0, n2 = 0, n3 = 0, max;
	scanf("%d %d", &m, &n);
	for (int i = m; i <= n; i++) {
		if (i % 2 == 0)
			n1++;
		if (i % 2 != 0)
			n2++;
		if (i % 3 == 0 && i % 7 != 0)
			n3++;
	}
	max = n1;
	if (n2 > max)
		max = n2;
	if (n3 > max)
		max = n3;
	printf("%d %d %d\n%d", n1, n2, n3, max);
	return 0;
}