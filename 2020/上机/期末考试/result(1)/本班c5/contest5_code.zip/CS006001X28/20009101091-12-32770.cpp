#include <stdio.h>
#include <math.h>
void add(int array[], int n);

int main() {
	int n, m, i, j, count;
	scanf("%d %d", &n, &m);
	count = pow(2, n);
	int num[count];
	for (i = 0; i < count; i++) {
		scanf("%d", &num[i]);
	}
	for (i = 1; i <= m; i++) {
		add(num, count);
		count = count / 2;
	}
	for (i = 0; i < count; i++) {
		printf("%d ", num[i]);
	}
	return 0;
}

void add(int array[], int n) {
	int i;
	for (i = 0; i < n / 2; i++) {
		array[i] = array[i] + array[n - i - 1];
	}
}