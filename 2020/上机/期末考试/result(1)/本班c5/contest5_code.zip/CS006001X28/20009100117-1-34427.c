#include <stdio.h>
#include <math.h>

int main() {
	int n, m, b[100], c[100] = {0}, i, j, k, a = 1;
	scanf("%d%d", &n, &m);
	a = pow(2, n);
	for (i = 1; i <= a; i++)
		scanf("%d", &b[i]);
	for (i = 1; i <= m; i++) {
		k = a / pow(2, i);
		for (j = 1; j <= k; j++) {
			c[j] = b[j] + b[(a / i) + 1 - j];
		}
		for (j = 1; j <= k; j++)
			b[j] = c[j];
	}
	for (i = 1; i <= k; i++)
		printf("%d ", c[i]);
	return 0;
}