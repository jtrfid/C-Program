#include <stdio.h>

int main () {
	int m, n, i, j, k, t, s;
	int  b[10][10];
	scanf("%d %d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++) {
			scanf("%d", &s);
			b[i][j] = s;
		}
	for (i = 0; i < m; i++)
		for (j = 0; j < n - 1; j++)
			for (k = j; k < n; k++)
				if (b[i][j] < b[i][k]) {
					t = b[i][j];
					b[i][j] = b[i][k];
					b[i][k] = t;
				}



	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", b[i][j]);
		printf("\n");
	}
	return 0;

}