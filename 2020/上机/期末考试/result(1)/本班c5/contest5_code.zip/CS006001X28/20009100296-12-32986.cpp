#include  <stdio.h>
#include <math.h>

int main() {
	int n, m;
	scanf("%d%d", &n, &m);
	int t = pow(2, n);
	int a[m + 1][t];
	int i, j;
	for (i = 0; i < t; i++) {
		scanf("%d", &a[0][i]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < t / 2; j++) {
			a[i + 1][j] = a[i][j] + a[i][t - j - 1];
		}
		t /= 2;
	}
	for (i = 0; i < t; i++) {
		printf("%d ", a[m][i]);
	}
	return 0;
}