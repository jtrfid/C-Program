#include <stdio.h>

int main() {
	int m, n, a = 0, b = 0, c = 0, max, i;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0) {
			a++;
		}
		if (i % 2 != 0) {
			b++;
		}
		if (i % 3 == 0 && i % 7 != 0) {
			c++;
		}
	}
	max = a > b ? a : b;
	max = max > c ? max : c;
	printf("%d %d %d\n%d", a, b, c, max);
	return 0;
}