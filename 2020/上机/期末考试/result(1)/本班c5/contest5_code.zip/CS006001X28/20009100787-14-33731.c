#include <stdio.h>

int main(void) {
	int m, n, i, j, k, t;
	scanf("%d %d", &m, &n);
	int a[10][10] = {0};
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (k = 0; k < m; k++) {
		for (i = 0; i < n - 1; i++) {
			for (j = i + 1; j < n; j++) {
				if (a[k][i] < a[k][j]) {
					t = a[k][i];
					a[k][i] = a[k][j];
					a[k][j] = t;
				}

			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}