#include <stdio.h>

int main() {
	int m, n, a,  max;
	int a1 = 0, a2 = 0, a3 = 0;
	scanf("%d%d", &m, & n);
	for (a = m; a < n + 1; a++) {
		if (a % 2 == 0) {
			a1 = a1 + 1;
		} else {
			a2 = a2 + 1;
		}
		if (a % 3 == 0 && a % 7 != 0) {
			a3 = a3 + 1;
		}
	}
	if (a1 > a2) {
		max = a1;
	} else {
		max = a2;
	}
	if (a3 > max) {
		max = a3;
	}
	printf("%d %d %d\n", a1, a2, a3);
	printf("%d", max);
	return 0;
}