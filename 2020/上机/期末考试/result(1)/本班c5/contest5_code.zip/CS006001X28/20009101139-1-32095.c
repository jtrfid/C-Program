#include <stdio.h>

int main() {
	int m, n, i, j = 0, o = 0, q = 0;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			o++;
		if (i % 3 == 0 && i % 7 != 0)
			q++;
	}
	j = (n - m + 1) - o;
	printf("%d %d %d\n", o, j, q);
	int temp = j;
	if (o > j)
		temp = o;
	if (q > temp)
		temp = q;
	printf("%d", temp);
}