#include <stdio.h>
#include <math.h>

int main() {
	float d(int a, int b, int a0, int b0);
	int N, a[10000], b[10000], D[10000], i, j, t = 0, T;
	float c[10000], d0;
	scanf("%d", &N);
	for (i = 0; i < N; i++) {
		scanf("%d%d%d", &D[i], &a[i], &b[i]);
		c[i] = 0;
	}
	for (i = 0; i < N; i++)
		for (j = 0; j < N; j++) {
			d0 = d(a[j], b[j], a[i], b[i]);
			c[i] = c[i] + d0;
		}
	for (i = 0; i < N; i++) {
		if (c[i] < c[t])
			t = i;
		else if ((c[i] == c[t]) && i > t)
			t = i;
	}
	printf("%d %.2f", T = t + 1, c[t]);
	return 0;
}

float d(int a, int b, int a0, int b0) {
	int DS;
	float D;
	DS = (a - a0) * (a - a0) + (b - b0) * (b - b0);
	D = pow(DS, 0.5);
	return D;
}