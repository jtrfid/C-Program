#include <stdio.h>
#include <string.h>

int main() {
	int m, n, i, j, a, b, c;
	scanf("%d%d", &m, &n);
	a = 0;
	b = 0;
	c = 0;
	for (i = m; i <= n; i++) {
		if (i % 2 == 0) {
			a++;
		}
		if (i % 2 == 1) {
			b++;
		}
		if (i % 3 == 0 && i % 7 != 0) {
			c++;
		}
	}
	if (a >= b && a >= c) {
		j = a;
	} else if (b >= a && b >= c) {
		j = b;
	} else if (c >= a && c >= b) {
		j = c;
	}
	printf("%d %d %d\n%d", a, b, c, j);
}