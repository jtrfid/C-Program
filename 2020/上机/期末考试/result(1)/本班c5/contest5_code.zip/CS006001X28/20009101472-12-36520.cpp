#include <stdio.h>
#include <math.h>

int main() {
	int i, j, n, m, x, y, num[100];
	scanf("%d %d", &n, &m);
	for (i = 0; i < pow(2, n); i++) {
		scanf("%d", &num[i]);
	}
	x = int(pow(2, n));
	for (i = 1; i < m + 1 ; i++) {
		for (j = 0; j < 0.5 * pow(2, n) / pow(2, i) ; j++) {
			y = int(pow(2, i - 1));
			num[j]	+= num[x / y - j];
			printf("%d\n", num[j]);
		}
	}
	x = pow(2, m);
	for (i = 0; i < pow(2, n) / x; i++) {
		printf("%d ", num[i]);
	}
	return 0;
}
