#include <stdio.h>

int main() {
	int n, m, a = 1;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		a = a * 2;
	int b[a];
	int c[a];
	for (int i = 0; i < a; i++)
		scanf("%d", &b[i]);
	for (int i = m; i > 0; i--) {
		for (int j = 0; j < a / 2; j++)
			b[j] = b[j] + b[a - j - 1];
		a = a / 2;
	}
	for (int i = 0; i < a; i++)
		printf("%d ", b[i]);
	return 0;
}