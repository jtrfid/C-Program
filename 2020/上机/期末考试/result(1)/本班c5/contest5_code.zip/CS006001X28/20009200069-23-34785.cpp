#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int i, j, n, N;
	struct info {
		int num;
		int x, y;
		float d;
	} stu[100000], min;
	scanf("%d", &N);
	int dx, dy;
	for (i = 0; i < N; i++)
		scanf("%d %d %d", &stu[i].num, &stu[i].x, &stu[i].y);
	for (i = N - 1; i >= 0; i--) {
		stu[i].d = 0;
		for (j = 0; j < N; j++) {
			if (j != i) {
				dx = (stu[i].x - stu[j].x) * (stu[i].x - stu[j].x);
				dy = (stu[i].y - stu[j].y) * (stu[i].y - stu[j].y);
				stu[i].d += sqrt(dx * 1.0 + dy * 1.0);
			}
		}

	}
	min = stu[N - 1];
	for (i = N - 2; i >= 0; i--) {
		if (stu[i].d < min.d)
			min = stu[i];
	}
	printf("%d %.2f", min.num, min.d);

	return 0;
}