#include <bits/stdc++.h>

int main() {
	int m, n, t, i, j, k, a[10][10];
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	for (i = 0; i < m; i++)
		for (j = 0; j < n - 1; j++) {
			for (k = j; k < n; k++) {
				if (a[i][j] < a[i][k]) {
					t = a[i][j];
					a[i][j] = a[i][k];
					a[i][k] = t;
				}
			}
		}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}

	return 0;
}