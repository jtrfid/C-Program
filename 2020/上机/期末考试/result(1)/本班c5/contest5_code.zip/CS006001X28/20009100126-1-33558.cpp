#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
	int m, n, j = 0, o = 0, n37 = 0, i, tem;
	scanf("%d%d", &m, &n);
	for (i = m; i <= n; i++) {
		if (i % 2 == 0)
			o++;
		else if (i % 2 == 1)
			j++;
		if (i % 3 == 0 && i % 7 != 0)
			n37++;
	}
	tem = o;
	if (tem < j)
		tem = j;
	if (tem < n37)
		tem = n37;
	printf("%d %d %d\n%d", o, j, n37, tem);

	return 0;
}