#include <stdio.h>

int main() {
	int n, m;
	int i = 0;
	int a[2 ^ n], b[2 ^ n / 2 ^ m];
	scanf("%d %d", &n, &m);
	for (i = 0; i < 2 ^ n; i++) {
		scanf("%d", &a[2 ^ n]);
	}
	for (m; m > 0; m--) {
		for (i; i < 2 ^ n / 2 ^ m - 1; i++)
			b[i] = a[i] + a[2 ^ n - i];
		printf("%d", b[i]);
	}

	return 0;
}