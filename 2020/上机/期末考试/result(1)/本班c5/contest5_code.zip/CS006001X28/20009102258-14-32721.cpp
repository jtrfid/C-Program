#include <stdio.h>

int main () {
	int m, n, i, j, num, t;
	int a[100], b[10][10];
	scanf("%d %d", &m, &n);
	num = m * n;
	for (i = 0; i < num; i++)
		scanf("%d", &a[i]);
	for (i = 0; i < num - 1; i++)
		for (j = i; j < num; j++) {
			if (a[j] < a[i]) {
				t = a[j];
				a[j] = a[i];
				a[i] = t;
			}
		}
	for (i = 0; i < m; i++)
		for (j = n - 1; j >= 0; j--)
			b[i][j] = a[(i + 1) * n - j - 1];

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", b[i][j]);
		printf("\n");
	}
	return 0;

}