#include <stdio.h>
#include <math.h>

struct student {
	int num;
	int x;
	int y;
} a[20], temp;

int main() {
	int n, i, j, t;
	float D, d, min;
	float b[20][20], sum[20] = {0.0};
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d%f%f", &a[i].num, &a[i].x, &a[i].y);
	}
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			d = (a[j].x - a[i].x) * (a[j].x - a[i].x) + (a[j].y - a[i].y) * (a[j].y - a[i].y);
			b[i][j] = pow(0.5, d) ;
		}
		for (j = 0; j < i + 1; j++) {
			b[i][j] = b[j][i - 1];
		}
	}
	for (i = 0; i < n; i++)
		for (j = 0; j < n - 1; j++) {
			sum[i] += b[i][j];
		}
	min = sum[0];
	for (i = 0; i < n; i++) {
		if (sum[i] < min)
			min = sum[i];
		t = i;
	}
	printf("%d %.2f", t + 1, min);
	return 0;
}