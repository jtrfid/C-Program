#include <stdio.h>

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	int a[m][n];
	int i, j, k, t;
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	for (i = 0; i < m; i++)
		for (j = n - 1; j > 0; j--)
			for (k = 0; k < j; k++)
				if (a[i][k] > a[i][k + 1]) {
					t = a[i][k];
					a[i][k] = a[i][k + 1];
					a[i][k + 1] = t;
				}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
	return 0;
}