#include <cstdio>
#include <algorithm>
#include <vector>

int A[15], B[15];
int main() {
  int a, n = 10; scanf("%d", &a);
  int cnt = 0;
  while(n --) {
    int x; scanf("%d", &x);
    if(x != a) B[++ cnt] = x;
  }
  std::sort(B + 1, B + 1 + cnt);
  for(int i = 1; i <= cnt; i ++) {
    if(i > 1) putchar(' ');
    printf("%d", B[i]);
  }
  puts("");
  return 0;
}
