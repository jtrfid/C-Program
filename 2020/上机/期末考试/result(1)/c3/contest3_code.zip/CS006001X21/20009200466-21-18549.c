#include<stdio.h>
int main(){
	struct peo{
		char name[50];
		int a[3];
	};
	int n;
	scanf("%d",&n);
	struct peo arr[n];
	struct peo b[n];
	struct peo temp;
	int i;
	for(i = 0;i<n;i++){
		scanf("%s %d/%d/%d",arr[i].name,&arr[i].a[0],&arr[i].a[1],&arr[i].a[2]);
	}
	int flag = 0;
	int j =0;
	for(i = 0;i<n;i++){
		if(arr[i].a[0] > 2021||(arr[i].a[0] == 2021&&arr[i].a[1] > 1)||(arr[i].a[0] == 2021 && arr[i].a[1]==1&&arr[i].a[2] >9));
		else if(arr[i].a[0]<1821);
		else{
			flag = 1;
			b[j++] = arr[i]; 
		}
	}
	int cnt = 0;
	if(!flag) printf("0");
	else {
		for(i = 0;i<j-1;i++){
			for(cnt = 0;cnt < j-i-1;cnt++){
				if(b[j].a[0] > b[j+1].a[0]||(b[j].a[0] == b[j+1].a[0] && b[j].a[1] > b[j+1].a[1])||(b[j].a[0]==b[j+1].a[0]&&b[j].a[1]==b[j+1].a[1]&&b[j].a[2] > b[j+1].a[2])){
					temp = b[j];
					b[j] = b[j+1];
					b[j+1] = temp;
				}
			}
		}
	
	printf("%d\n",j);
	printf("%s\n",b[j-1].name);
	printf("%s\n",b[0].name);
	}
	return 0;
}