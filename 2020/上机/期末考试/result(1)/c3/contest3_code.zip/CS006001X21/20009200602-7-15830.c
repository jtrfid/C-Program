#include<stdio.h>
#include<string.h>
#include<math.h>

int main(void)
{
	int n;
	int i,j;
	scanf("%d",&n);
	int a[10];
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
		
	}
	int t;
	for(i=0;i<9;i++)
	{
		
			for(j=0;j<9-i;j++)
			{
				if(a[j]>a[j+1])
				{
					t=a[j];
					a[j]=a[j+1];
					a[j+1]=t;
				}
			}
		
	}
	for(i=0;i<9;i++)
	{
		
		if(a[i]==n)
		a[i]=-1;
	}
	for(i=0;i<10;i++)
	{
		if(a[i]>=0)
		printf("%d ",a[i]);
		
	}
	return 0;
}
