#include <stdio.h>
int main(){
	int m,n,i;
	int ji=0 ,ou=0,bi=0;
	scanf("%d%d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2==0)
		ou++;
		if(i%2==1)
		ji++;
		if(i%7==0&&i%3!=0)
		bi++;
	}
	printf("%d %d %d\n",ji ,ou ,bi);
	int max=-1;
	if(max<ou)
		max=ou;
	if(max<ji)
		max=ji;
	if(max<bi)
		max=bi;
	printf("%d",max);
		return 0;
	
}
