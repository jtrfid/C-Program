#include<stdio.h>
int jishu(int n)
{
	if(n%2==1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int oushu(int n)
{
	if(n%2==0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int qisan(int n)
{
	if(n%7==0&&n%3!=0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int main()
{
	int a,b,sum1=0,sum2=0,sum3=0,i;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{
		if(jishu(i))
		{
			sum1=sum1+1;
		}
		if(oushu(i))
		{
			sum2=sum2+1;
		}
		if(qisan(i))
		{
			sum3=sum3+1;
		}
	}
	printf("%d %d %d\n",sum1,sum2,sum3);
	if(sum2>=sum1&&sum2>=sum3)
	{
		printf("%d",sum2);
	}
	else if(sum1>=sum2&&sum1>=sum3)
	{
		printf("%d",sum1);
	}
	else
	{
		printf("%d",sum3);
	}
	return 0;
}
