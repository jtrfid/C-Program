#include<stdio.h>

int main(){
	int m,n;
	scanf("%d %d",&m,&n);
	int i,x=0,y=0,z=0;
	for(i=m;i<=n;i++){
		if(i%2==1)
		x++;
		else if(i%2==0)
		y++;
		if(i%3!=0&&i%7==0)
		z++;
	}
	printf("%d %d %d\n",x,y,z);
	int t=x;
	if(y>t)
	t=y;
	if(z>t)
	t=z;
	printf("%d",t);
	return 0;
}
