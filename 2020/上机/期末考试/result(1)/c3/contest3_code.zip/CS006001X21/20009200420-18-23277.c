#include <stdio.h>
int main()
{   int a;
     a=0;
	printf("no");
	return 0;
	
}
