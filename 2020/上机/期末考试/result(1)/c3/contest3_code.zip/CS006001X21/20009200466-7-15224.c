#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int a[10];
	int i = 0;
	for(i = 0;i<10;i++)scanf("%d",&a[i]);
	int j = 0;
	int b[10];
	for(i = 0;i<10;i++){
		if(a[i] != n) b[j++] = a[i];
	}
	int cnt = 0;
	for(i = 0;i<j-1;i++){
		for(cnt = 0;cnt<j-i-1;cnt++){
			if(b[cnt] > b[cnt+1]){
				int temp = b[cnt+1];
				b[cnt+1] = b[cnt];
				b[cnt] = temp;
			}
		}
	}
	for(i = 0;i<j;i++){
		printf("%d ",b[i]);
	}
	
	
	
	return 0;
}

