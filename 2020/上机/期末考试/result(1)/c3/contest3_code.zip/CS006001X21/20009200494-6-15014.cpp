#include<stdio.h>
int m,n,j1=0,o2=0,r3=0,m4=0,cmp=0;
int main(){
	scanf("%d%d",&m,&n);
	for(int i=m;i<=n;i++)
	{
		if(i%2!=0)j1++;
		if(i%2==0)o2++;
		if(i%7==0&&i%3!=0)r3++;
	}
	if(j1>o2)cmp=j1;
	else cmp=o2;
	if(cmp>r3)m4=cmp;
	else m4=r3;
	printf("%d %d %d\n%d",j1,o2,r3,m4);
	return 0;
}
