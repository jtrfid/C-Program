#include <stdio.h>
int main(){
	int a,b[10];
	scanf("%d",&a);
	int i;
	for(i=0;i<10;i++){
		scanf("%d",&b[i]);
	}
	int count=0;
	for(i=0;i<10;i++){
		if(b[i]==a){
			b[i]=-1;
			count++;
		}
	}
	int j=0,c[10];
	for(i=0;i<=10-count;i++){
			if(b[j]!=-1){
				c[i]=b[j];
				j++;
			}
			else j++;
	}
	int z;
	for(i=0;i<10-count;i++){
		for(j=0;j<10-count;j++){
			if(c[j]>c[j+1]){
				z=c[j];
				c[j]=c[j+1];
				c[j+1]=z;
			}
		}
	}
	for(i=0;i<10-count;i++){
		printf("%d ",c[i]);
	}
	return 0;
}
