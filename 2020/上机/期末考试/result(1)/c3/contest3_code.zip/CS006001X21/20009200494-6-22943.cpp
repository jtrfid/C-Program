#include<stdio.h>
int m,n;
struct man{
	char name[16];
	int a1,a2,a3;
}a[20000];
int main(){
	//scanf()
	//if(scanf();)
	printf("0");
	
	return 0;
}
