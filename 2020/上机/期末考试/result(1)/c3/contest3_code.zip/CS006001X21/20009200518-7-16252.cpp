#include<stdio.h>
int main()
{
	int x,a[10],i,j,num=10;
	scanf("%d",&x);
	for(i=0;i<num;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]==x)
		{
			i--;
			num--;
		}
	}
	int min,m,t;
    for(i=0;i<num-1;i++)
    {
    	min=a[i];
    	m=i;
    	for(j=i+1;j<num;j++)
    	{
    		if(a[j]<min)
    		{
    			min=a[j];
    			m=j;
    		}
    	}
    	if(m!=i)
    	{
    		t=a[i];
    		a[i]=a[m];
    		a[m]=t;
    	}
    }
    for(i=0;i<num;i++)
    {
    	printf("%d ",a[i]);
    }
    return 0;
}
