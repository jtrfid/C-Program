#include<stdio.h>
int main()
{
	int a[20],i=1,x,n;
	int b[20],j;
	int k,t;
	scanf("%d",&x);
	for(i=1;i<=10;i++)
	{
		scanf("%d",&a[i]);
	}
	n=10;
	for(i=1,j=1;i<=10;i++)
	{
		if(a[i]!=x)
		{
			b[j]=a[i];
			j++;
		}
		if(a[i]==x)
		{
			n--;
		}
	}
	
	for(i=1;i<=n;i++)
	{
		for(k=i+1;k<=n;k++)
		{
			if(b[i]>b[k])
			{
				t=b[i];
				b[i]=b[k];
				b[k]=t;
			}
		}
	}
	for(i=1;i<=n;i++)
	{
		printf("%d ",b[i]);
	}

}
