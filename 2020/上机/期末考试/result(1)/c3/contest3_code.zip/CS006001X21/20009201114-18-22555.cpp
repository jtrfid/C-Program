#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;

typedef struct{
	int a;
	int index;
} GG;
//80fen
bool cmp(GG x,GG y)
{
	if(x.a==y.a)return x.index<y.index;
	return x.a>y.a;
}

int main()
{
	int m;
	cin>>m;
	GG M[33]={0,0};
	int L=0;
	for(int i=0;i<m;i++)
	{
		float a,b,c;
		cin>>a>>b>>c;
		if(a+b<=c || a+c<=b || b+c<=a)continue;
		float p=(a+b+c)/2.0;
		M[i].a=(int)(p*(p-a)*(p-b)*(p-c));
		M[i].index=i;
		L++;
	}
	sort(M,M+m,cmp);
	if(!M[0].a)
		cout<<"no"<<endl;
	else{
		for(int i=0;i<L;i++)
			cout<<M[i].a<<' '<<M[i].index<<endl;
	}
	return 0;
}
