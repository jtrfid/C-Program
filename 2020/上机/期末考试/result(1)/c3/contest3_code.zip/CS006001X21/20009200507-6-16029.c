#include<stdio.h>
int main()
{
	int m,n,i;
	int k=0,j=0,a=0;
	scanf("%d %d",&m,&n);
	for(i=m;i<n;i++)
	{
		if(i%2==0)
		{
			k++;
		}
		else if(i%2!=0)
		{
			j++;
		}
		else if(i%7==0&&i%3!=0)
		{
			a++;
		}
	}
	printf("%d %d %d\n",k,j,a);
	if(k>j&&k>a)
	{
		printf("%d",k);
	}
	if(j>k&&j>a)
	{
		printf("%d",j);
	}
	if(a>k&&a>j)
	{
	printf("%d",a);
    }
    return 0;
}
