#include<stdio.h>
int area(int *s)
{
	int i,t;
	for(i=0;i<3;i++)
	{
		t+=*s;
		s++;
	}
	s=s-3;
	double p,ss;
	p=t/2.0;
	ss=p*(p-*s)*(p-*(s+1))*(p-*(s+2));
	int n;
	  n=(int)ss;
	return n;
}
int main()
{
	int i,j,m,flag=0,t;
	scanf("%d",&m);
	int a[30][3],b[30][4],k=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		if((a[i][0]+a[i][1]>a[i][2])&&(a[i][0]+a[i][2]>a[i][1])&&(a[i][2]+a[i][1]>a[i][0]))
		  {
		  	b[k][0]=a[i][0];b[k][1]=a[i][1];b[k][2]=a[i][2];b[k][3]=i;
		  	k++;
		  }
	}
	int c[k][2];
	if(k==0)
	{
		printf("no");
		return 0;
	}
	else
	{
		for(i=0;i<k;i++)
		{
			c[i][0]=area(b[i]);
			c[i][1]=b[i][3];
		}
	}
	for(i=0;i<k-1;i++)
	{
		flag=0;
		for(j=0;j<k-1-i;j++)
		{
			if(c[j][0]<c[j+1][0])
			{
				t=c[j][0];c[j][0]=c[j+1][0];c[j+1][0]=t;
				t=c[j][1];c[j][1]=c[j+1][1];c[j+1][1]=t;
				flag=1;
			}
			else if(c[j][0]==c[j+1][0])
			{
				if(c[j][1]>c[j+1][1])
				{
					t=c[j][1];c[j][1]=c[j+1][1];c[j+1][1]=t;
					flag=1;
				}
			}
		}
		if(flag==0)
		  break;
	}
	for(i=0;i<k;i++)
	{
		printf("%d %d\n",c[i][0],c[i][1]);
	}
	return 0;
}
