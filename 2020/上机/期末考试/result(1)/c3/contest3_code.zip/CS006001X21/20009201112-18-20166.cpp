#include<stdio.h>
int area(int a,int b,int c){
	double p=0.5*(a+b+c);
	int s;
	s=p*(p-a)*(p-b)*(p-c);
	return s;
}
int triangle(int a,int b,int c){
	if(a+b>c&&a-b<c)
	return 1;
	else return 0;
}

int main(){
	int m;
	scanf("%d",&m);
	int a[m][3],i,j;
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d",&a[i][j]);
		}
	}
	int t,n,y[10001];
	j=0;
	int p[10001],x=0;//ȡ��  
	for(i=0;i<=m;i++){
		t=triangle(a[i][0],a[i][1],a[i][2]);
		if(t==1){
			p[j]=area(a[i][0],a[i][1],a[i][2]);
			y[j]=i;
			x++;j++;
		}
		
	}
	
	
	if(x==0)
	printf("no");
	
	
	else{
		for(i=0;i<x;i++){
			for(j=i+1;j<=x;j++){
				if(p[i]<p[j]){
					t=p[i];p[i]=p[j];p[j]=t;
					n=y[i];y[i]=y[j];y[j]=n;
				}
			}
		}
		for(i=0;i<x;i++){
			printf("%d %d\n",p[i],y[i]);
		}
	}
	return 0;
	
}
