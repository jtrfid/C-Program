#include<stdio.h>
int main(){
	int m,n,i=0,a,b;
	int j=0,o=0,y=0;
	int max;
	scanf("%d %d",&n,&m);
	a=m-n+1;
	b=n-1;
{
	for(i=0;i<a;i++) {
		b=b+1;
		if(b%2!=0)
		j+=1;
		else if(b%2==0)
		o+=1;
	             	}}
	{
	 for(i=0;i<a;i++)   {
	 b=b+1;
	 {
	 if(b%7==0&&b%3!=0) 
	 y++;}}     }   	
	max=j>o?j:o;	
	printf("%d %d %d %d",j,o,y,max);
	return 0;
}
