#include<stdio.h>
#include<math.h>
int main()
{
	int m,n,i=m,sum=0,d=0,o=0,t;
	scanf("%d %d",m,n);
	for  (i=m,i<=n,i++)
	{	
		if ((i%7=0))&&(i%3>0)))
		sum++;
		else if(i%2=0)
		o++;
		else if(i%2>0)
		d++;	
}
        if (o>=d)
        t=o;
        else
        t=d;
		printf("%d %d %d\n",sum,d,o);
		printf("%d",t);
	return 0;
} 
