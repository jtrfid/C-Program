#include<stdio.h>
int MAX(int a,int b);
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int i;
	int cntj=0,cnto=0,cntt=0;
	int max=0;
	for(i=m;i<=n;i++){
		if(i%2==0)
		cnto++;
		if(i%2!=0)
		cntj++;
		if(i%7==0&&i%3!=0)
		cntt++;
	}
	int ret=MAX(cntt,MAX(cntj,cnto));
	printf("%d %d %d\n",cntj,cnto,cntt);
	printf("%d",ret);
	return 0;
}
int MAX(int a,int b){
	if(a>b)
	return a;
	else 
	return b;
}
