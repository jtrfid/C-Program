#include<stdio.h>
void paixu(int *b,int n)
{
	int i,j,k,t;
	for(i=0;i<n;i++)
	{
		for(j=i+1,k=i;j<n;j++)
		{
			if(b[j]<b[k]) k=j;
		}
		if(k!=i)
		{
			t=b[i];
			b[i]=b[k];
			b[k]=t;
		}
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[10];
	int i;
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}
	int b[10];
	for(i=0;i<10;i++)
	{
		if(a[i]!=n) b[i]=a[i];
		else b[i]=1001;
	}
	paixu(b,10);
	for(i=0;i<10;i++)
	{
		if(b[i]!=1001) printf("%d ",b[i]);
		else continue;
	}
	return 0;
}
