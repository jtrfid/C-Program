#include<stdio.h>
int main()
{
	int i,j,n,t,a[10],b[10],k=0,flag=0;
	scanf("%d",&n);
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<10;i++)
	{
		if(a[i]!=n)
		  b[k++]=a[i];
	}
	for(i=0;i<k-1;i++)
	{
		flag=0;
		for(j=0;j<k-1-i;j++)
		{
			if(b[j]>b[j+1])
			{
			  t=b[j];b[j]=b[j+1];b[j+1]=t;
			  flag=1;
			}
		}
		if(flag==0)
		  break;
	}
	for(i=0;i<k;i++)
	{
		printf("%d ",b[i]);
	}
	return 0;
}
