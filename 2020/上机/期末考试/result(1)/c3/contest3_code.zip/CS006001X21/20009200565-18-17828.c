#include<stdio.h>
int judge(int s,int b,int c)
{	int i,j,k;
	int a[3]={s,b,c};
	for(i=0;i<3;i++)
	{
		for(j=0;j<3-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	if(a[0]+a[1]<=a[2]) 
	return 0;
	else return 1;
}
int sa(int a,int b,int c)
{
	double p=(a+b+c)/2;
	int t=p*(p-a)*(p-b)*(p-c);
//	printf("%d\n",t);
	return t;
}
int main()
{	struct AA{
		int a;
		int b;
	}c[3];
	int n,i,j,cnt=0,k;
	scanf("%d",&n);
	int a[100][3],b[100]={0,0,0};
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	j=0;
	for(i=0;i<n;i++)
	{
		if(judge(a[i][0],a[i][1],a[i][2])!=0)
		{
			b[i]=sa(a[i][0],a[i][1],a[i][2]);
		}
		else if(judge(a[i][0],a[i][1],a[i][2])==0) {
			b[i]=0;
			cnt++;
			}
	}

	for(i=0;i<3;i++)
	{
			c[i].a=i;
			c[i].b=b[i];
	}
	for(i=0;i<n;i++)
	{
		for(k=0;k<n-i-1;k++)
		{
			if(c[k].b<c[k+1].b)
			{
			struct AA temp=c[k];
			c[k]=c[k+1];
			c[k+1]=temp;
			}
		}		
		
	}
	for(i=0;i<n;i++)
	{
		if(c[i].b!=0){
			printf("%d %d\n",c[i].b,c[i].a);
		}
	}
	if(cnt==3)
	printf("no");
	return 0;
}
