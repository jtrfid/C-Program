#include<stdio.h>
int main()
{
	int a,i,j,t;
	int b[10];
	scanf("%d",&a);
	for(i=0;i<10;i++)
	{
		scanf("%d",&b[i]);
	}
	for(i=0;i<9;i++)
	{
		for(j=0;j<9-i;j++)
		{
		if(b[j]>b[j+1])
		  {
		  	t=b[j];
		  	b[j]=b[j+1];
		  	b[j+1]=t;
		  }	
		}
	}
	for(i=0;i<10;i++)
	{ 
		if(b[i]!=a&&i==0) printf("%d",b[i]);
		if(b[i]!=a&&i!=0) printf(" %d",b[i]);
	}
}
