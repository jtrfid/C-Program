#include<stdio.h>
double MJ(int a,int b,int c)
{
	double p,y;
	p=(a+b+c)/2.0;
	y=p*(p-a)*(p-b)*(p-c);
	return y;
}
int isSJX(int a,int b,int c)
{
	return (a+b>c)&&(a+c>b)&&(b+c>a);
}
int qz(double n)
{
	int x;
	x=n;
	return x;
}
int main()
{
	int m;
	scanf("%d",&m);
	int a[m][3],b[m],c[m];
	double B[m];
	int i,j;
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		c[i]=i;
		if(isSJX(a[i][0],a[i][1],a[i][2]))
		{
			B[i]=MJ(a[i][0],a[i][1],a[i][2]);
			b[i]=qz(B[i]);
		}
		else
		{
			b[i]=0;
		}
	}
	int max,k,t;
	for(i=0;i<m-1;i++)
	{
		max=b[i];
		k=i;
		for(j=i+1;j<m;j++)
		{
			if(b[j]>max)
			{
				max=b[j];
				k=j;
			}
		}
		if(k!=i)
		{
			t=b[i];
			b[i]=b[k];
			b[k]=t;
			t=c[i];
			c[i]=c[k];
			c[k]=t;
		}
	}
	if(b[0]!=0)
	{
	    for(i=0;b[i]!=0;i++)
	    {
		    printf("%d %d\n",b[i],c[i]);
	    }
    }
    else
    {
    	printf("no");
    }
	return 0;
}
