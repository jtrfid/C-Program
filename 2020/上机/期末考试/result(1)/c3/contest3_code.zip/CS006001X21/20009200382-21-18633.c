#include <stdio.h>

struct people{
	char name[10];
	int year;
	int month;
	int day;
	int age;
};

int main(){
	int n;
	int i,j,count=0,t;
	struct people m[10];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s %d/%d/%d",&m[i].name,&m[i].year,&m[i].month,&m[i].day);
	}
	for(i=0;i<n;i++){
		if(m[i].month>=1&&m[i].day>=9){
			m[i].age=2021-m[i].year;
		}
		else m[i].age=2021-1-m[i].year;
	}
	for(i=0;i<n-1;i++){
		for(j=0;j<n-i-1;j++){
			if(m[j].age>m[j+1].age){
				t=m[j].age;
				m[j].age=m[j+1].age;
				m[j+1].age=t;
				
			}
		}
	}
	for(i=0;i<n;i++){
		if(m[i].age>200&&m[i].age<0) m[i].age=0;
		else count++;
	}
	for(i=0;i<n;i++){
		if(count==0) printf("0");
		else{
			printf("%d\n",count);
			printf("%s\n",m[n].name);
			printf("%s",m[0].name);
		}
	}
	return 0;
}
