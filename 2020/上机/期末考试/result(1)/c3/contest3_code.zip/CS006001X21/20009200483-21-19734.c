#include <stdio.h>
#include <string.h>
 typedef struct shengri{
 	char name[10];
 	char riqi[10];
 }rq; 
  int main(){
  	int  i,n,c=0;
  	char old[10],young[10];
	char o[10],y[10];
  	scanf("%d",&n);
  	rq shengri[100];
  	for(i=0;i<n;i++){
  		scanf("%s",&shengri[i].name);
  		scanf("%s",&shengri[i].riqi);
  	}
	strcpy(old,shengri[0].name);
	strcpy(young,shengri[0].name);
	strcpy(o,shengri[0].riqi);
	strcpy(y,shengri[0].riqi);
	for(i=0;i<n;i++){
  		if(shengri[i].riqi<'2021/01/09'&&shengri[i].riqi>'1821/01/09'){
  			c++;
		if(o<shengri[i].riqi){
  			strcpy(old,shengri[i].name);
  		}
  		if(y>shengri[i].riqi){
  			strcpy(young,shengri[i].name);
  		}		
  		}
  		
  	}
	printf("%d\n",c);
	printf("%s\n",old);
		printf("%s\n",young);
	
	 		
  return 0;}



