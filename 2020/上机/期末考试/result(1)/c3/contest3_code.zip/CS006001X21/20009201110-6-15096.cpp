#include<stdio.h>
int main(){
	int i,j,m=0,n=0,o=0,x,y;
	scanf("%d %d",&x,&y);
	for(i=x;i<=y;i++){
		if((i%2)==0) m=m+1;
		if((i%2)!=0) n=n+1;
		if((i%7)==0&&(i%3)!=0) o=o+1;
	}
	if(n>=m&&n>=o) j=n;
	if(m>=n&&m>=o) j=m;
	if(o>=n&&o>=m) j=0;
	printf("%d %d %d\n",n,m,o);
	printf("%d",j);
	return 0;
}
