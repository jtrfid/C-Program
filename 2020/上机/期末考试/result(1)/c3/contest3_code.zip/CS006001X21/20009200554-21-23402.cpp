#include<stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct ren
{
	char n[50];
	int y,m,d;
}bir;
int main(){
	int n,y,m,d,k=0,p,z;
    char buf[50],c,bu[50];
    
    scanf("%d",&n);
    bir a[n];
    int i,j,count=0;
    getchar();
    for(i=0;i<n;i++)
    {   gets(buf);
        for(j=0;buf[j]!=' ';j++);
        
             for(z=0;z<=3;z++)
    	    {
    	    	bu[z]=buf[j+z+1];
    	    }
    	    bu[4]='\0';
    	    y=atoi(bu);
    	    j+=5;
    	    for(z=0;z<=1;z++)
    	    {
    	    	bu[z]=buf[j+z+1];
    	    }
    	    bu[2]='\0';
    	    m=atoi(bu);
    	    j+=3;
    	    for(z=0;z<=1;z++)
    	    {
    	    	bu[z]=buf[j+z+1];
    	    }
    	    bu[2]='\0';
    	    d=atoi(bu);
    	    
    		if((y<=1821&&m<=1&&d<=9)||(y>=2021&&m>=1&&d>=9))
    		continue;
    		else
    		{   
    			a[k].y=y;
    			a[k].m=m;
    			a[k].d=d;
    			strcpy(a[k].n,buf);
    			k++;
    		}
    		
    	

    	
    }
	
    if(k==0)
    {
    	printf("0");
    	return 0;
    }
    else
    printf("%d\n",k);
    
    int l;
    l=k;
    bir b;
    for(i=0;i<l;i++)
    {
    	for(j=0;j<l-1;j++)
    	{
    		if(a[j].y<a[j+1].y)
    		{
    			b=a[j];
    			a[j]=a[j+1];
    			a[j+1]=b;
    		}
    		if(a[j].y==a[j+1].y)
    		{
    			if(a[j].m<a[j+1].m)
    			{
    				b=a[j];
    			   a[j]=a[j+1];
    			   a[j+1]=b;
    			}
    			if(a[j].m==a[j+1].m)
    			{
    				if(a[j].d<a[j+1].d)
    				{
    					b=a[j];
    			   a[j]=a[j+1];
    			   a[j+1]=b;
    				}
    			}
    		}
    	}
    }
    for(i=0;a[l-1].n[i]!=' ';i++)
    printf("%c",a[l-1].n[i]);
    printf("\n");
    for(i=0;a[0].n[i]!=' ';i++)
    printf("%c",a[0].n[i]);
    printf("\n");
    
	return 0;
    
    
	
}
