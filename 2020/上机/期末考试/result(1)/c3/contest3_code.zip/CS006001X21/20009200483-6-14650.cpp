#include <stdio.h>
  int main(){
  	int m,n;
	  scanf("%d %d",&m,&n);
	 int i,ji=0,ou=0,qi=0,max;
	 for(i=m;i<=n;i++){
	 	if(i%2==1){
	 		ji++;
	 	}
	 	if(i%2==0){
	 		ou++;
	 	}
	 	if(i%7==0&&i%3!=0){
	 		qi++;
	 	}
	 }	
	  max=ji;
	  if(max<ou){
	  	max=ou;
	  }	
  	if(max<qi){
	  	max=qi;
	  }
  	printf("%d %d %d\n%d",ji,ou,qi,max);
  	
  	
  	
  	
  return 0;}
