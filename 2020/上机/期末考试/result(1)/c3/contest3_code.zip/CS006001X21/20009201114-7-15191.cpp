#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;

bool cmp(int x,int y)
{
	return x<y;
}
int main()
{
	int a;
	int A[15]={0};
	cin>>a;
	int f=0;
	for(int i=1;i<=10;i++){
		cin>>A[i];
		if(a==A[i]){
			f++;
			A[i]=0;
		}
	}
	sort(A+1,A+11,cmp);
	for(int i=f+1;i<=10;i++)
	{
		cout<<A[i]<<' ';
	}
		
	
	return 0;
}
