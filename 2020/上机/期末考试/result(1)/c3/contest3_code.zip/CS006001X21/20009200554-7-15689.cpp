#include <stdio.h>
int main(){
	int a,ar[10]={0},i,j,buf;
	scanf("%d",&a);
	for(i=0;i<10;i++)
	scanf("%d",&ar[i]);
	//for(i=0;i<10;i++)
	//printf("%d ",ar[i]);
	for(i=0;i<10;i++)
	{
		if(ar[i]==a)
		ar[i]=-1;
	}
	//for(i=0;i<10;i++)
	//printf("%d ",ar[i]);
	for(i=0;i<10;i++)
	{
		for(j=0;j<9;j++)
		{
			if(ar[j]>ar[j+1])
			{
				buf=ar[j];
			ar[j]=ar[j+1];
			ar[j+1]=buf;
			}
			
		}
	}
	for(i=0;i<10;i++)
	{
		if(ar[i]>=0)
		printf("%d ",ar[i]);
	}
	return 0;
}
