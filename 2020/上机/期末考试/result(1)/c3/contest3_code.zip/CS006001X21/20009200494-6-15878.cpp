#include<stdio.h>
int q,w[10];
int main(){
	scanf("%d",&q);
	for(int i=0;i<10;i++)
	{
		scanf("%d",w+i);
	}
	for(int i=0;i<9;i++)
	{
		for(int j=0;j<9-i;j++)
		{
			if(w[j]>w[j+1])
			{
				int tmp=w[j];
				w[j]=w[j+1];
				w[j+1]=tmp;
			}
		}
	}

	for(int i=0;i<10;i++)
	{
		if(w[i]!=q)printf("%d ",w[i]);
	}
	/**/
	
	
	
	return 0;
}
