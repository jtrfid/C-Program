#include<stdio.h>
int main()
{
	int N;
	scanf("%d",&N);
	char a[N][10];
	int b[N],c[N],d[N];
	int i,j;
	for(i=0;i<N;i++)
	{
		scanf("%s",&a[N]);
		scanf("%d%d%d",&b[i],&c[i],&d[i]);
	}
	int num=N;
	for(i=0;i<N;i++)
	{
		if(b[i]<1821||(b[i]==1821&&c[i]==1&&d[i]<9)||(b[i]==2021&&c[i]==1&&d[i]>9)||(b[i]==2021&&c[i]>1)||b[i]>2021)
		{
			num--;
			b[i]=0;
		}
	}
	int max=0,min=0;
	for(i=0;i<N;i++)
	{
		if()
	}
}
