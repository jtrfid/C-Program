#include<stdio.h>
int main(){
	void swap(int *x,int*y);
	int i,j,n,t;	
	scanf("%d",&n);
	t=n;
	int a[10];
	for(i=0;i<10;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<10;i++){
		for(j=0;j<10-i;j++){
			if(a[j]>a[j+1]){
				swap(&a[j],&a[j+1]);
			}
		}
	}
	for(i=0;i<11;i++){
		if(a[i]==t){
			continue;
		}
		printf("%d ",a[i]);

} 
} 

 void swap(int*x,int *y){
	int z;
	z=*x;
	*x=*y;
	*y=z;
}
