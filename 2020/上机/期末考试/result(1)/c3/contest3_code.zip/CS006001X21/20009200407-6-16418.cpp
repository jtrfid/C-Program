#include<stdio.h>
int main(){
	int m,n,p=0;
	p=m;
	scanf("%d %d",&m,&n);
	int a,b=0;
	int c,d=0;
	a=m%2;
	b=n%2;
	if(a==0&&b==0){
		c=(n-m)/2;
		d=(n-m)/2+1;
	}
	else if(a==0&&b==1){
		c=(n-m+1)/2;
		d=(n-m+1)/2;
	}
	else if(a==1&&b==0){
		c=(n-m+1)/2;
		d=(n-m+1)/2;
	}
    else if(a==1&&b==1){
    	c=(n-m)/2+1;
    	d=(n-m)/2;
    }
	int h[10000];
	int i,z=0;
	int e,f=0;
	for(i=m;i<=n;i++){
		h[i]=p;
		p++;
	}
	for(i=m;i<=n;i++){
		e=h[i]%3;
		f=h[i]%7;
	if(e!=0&&f==0){
    	z++;
    }else{
    	z=z;
    }	
	}
	int max=0;
	if(c>=d){
		max=c;
	}else{
		max=d;
	}
	if(z>=max){
		max=z;
	}else{
	(max=max);
    }
	printf("%d %d %d\n",c,d,z);
	printf("%d",max);
	return 0;
}
