#include<stdio.h>
#include<string.h>
int main()
{
	int i = 0,j = 0,k = 0,n = 0,m = 0,t = 0,flag = 0,count[3] = {0},max = 0;
	scanf("%d%d",&m,&n);
	for(i = m;i <= n;i++)
	{
		if(i % 2 == 1)
		{
			count[0]++;
		}
		 if(i % 2 == 0)
		{
			count[1]++;
		}
		 if(i % 7 == 0&&i % 3 != 0)
		{
			count[2]++;
		}
	}
	for(i = 0;i < 3;i++)
	{
		max = max > count[i] ? max : count[i];
	}
	printf("%d %d %d\n",count[0],count[1],count[2]);
	printf("%d",max);
	
	
	
	
	
	return 0;
}
