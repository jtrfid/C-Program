#include<stdio.h>
int main(){
	int a;
	int shuzu[10];
	scanf("%d",&a);
	int i;
	for(i=0;i<10;i++){
		if(i<9){
			scanf("%d ",&shuzu[i]);
		}else{scanf("%d",&shuzu[i]);
		}
	}
	int j;
	int jilu=10;
	for(j=0;j<10;j++){
		if(a==shuzu[j]){
			jilu=j;
		}
	}
	int p=10;
	if(jilu!=10){p=p-1;
	}
	int b[p];
	int q;
	for(q=0,i=0;q<p;q++,i++){
		if(i!=jilu){b[q]=shuzu[i];
		}else{i=i+1;b[q]=shuzu[i];
		}
	}
	int r;
	for(i=0;i<q;i++){
		for(j=i+1;j<q;j++){
			if(b[i]>b[j]){
				r=b[i];b[i]=b[j];b[j]=r;
			}
		}
	}
	for(i=0;i<q;i++){
		printf("%d ",b[i]);
	}
	return 0;
}
