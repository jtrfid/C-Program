#include<stdio.h>
void myquick(int *num,int l,int r);
int main()
{
	int a;
	scanf("%d",&a);
	int num[10];
	int i;
	for(i=0;i<10;i++){
		scanf("%d",&num[i]);
		if(num[i]==a)
		num[i]=-1;
	}
	myquick(num,0,9);
	for(i=0;i<10;i++){
		if(num[i]!=-1)
		printf("%d ",num[i]);
	}
	return 0;
}
void myquick(int *num,int l,int r){
	if(l>=r)
	return;
	int first=l;
	int last=r;
	int key=num[first];
	while(first<last){
		while(first<last&&num[last]>=key)
		last--;
		num[first]=num[last];
		while(first<last&&num[first]<=key)
		first++;
		num[last]=num[first];
	}
	num[first]=key;
	myquick(num,l,first-1);
	myquick(num,last+1,r);
}









