#include <stdio.h>
int main(){
	int m , n;
	scanf("%d %d",&m, &n);
	int cnt1 = 0, cnt2 = 0, cnt3 = 0;
	int i;
	for(i = m;i <= n;i++){
		if(i % 2 == 1) cnt1++;
		if(i % 2 == 0) cnt2++;
		if(i % 7 == 0&&i % 3 != 0) cnt3++;
	}
	int a[3] = {cnt1, cnt2, cnt3};
	int max = 0;
	for(i = 0;i < 3;i++){
		if(a[i] > max) max = a[i];
	}
	printf("%d %d %d\n%d", cnt1, cnt2, cnt3, max);
	return 0;		
}
