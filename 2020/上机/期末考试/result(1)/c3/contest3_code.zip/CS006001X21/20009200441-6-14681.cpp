#include<stdio.h>
int main()
{
	int i , m , n ,ji=0 ,ou=0 ,aa=0 ,max ;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i % 2 ==0) 
		{
			ou ++;
		}
		else
		{
			ji++;
		}
		if(i%7==0 && i%3 !=0)
		{
			aa++;
		}
	}
	max=ji>ou?ji:ou;
	printf("%d %d %d\n%d",ji,ou,aa,max);
	return 0 ;
}
