#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <utility>
#include <vector>
typedef std::pair<int, int> pii;
int len[40][3];
int calc_S(int i) {
  double p = (double(len[i][0] + len[i][1] + len[i][2])) / 2.00;
  double ans = p;
  for(int j = 0; j < 3; j ++) ans *= p - (double)len[i][j];
  return floor(ans);
}

int main() {
  int m; scanf("%d", &m);
  for(int i = 0; i < m; i ++) {
    for(int j = 0; j < 3; j ++) scanf("%d", &len[i][j]);
  }
  std::vector<pii> V;
  for(int i = 0; i < m; i ++) {
    std::sort(len[i], len[i] + 3);
    if(len[i][0] + len[i][1] <= len[i][2]) continue;
    int S = calc_S(i);
    V.push_back(pii(-S, i));
  }
  if(V.empty()) {
    puts("no");
    return 0;
  }
  std::sort(V.begin(), V.end());
  for(int i = 0; i < V.size(); i ++) {
    pii pr = V[i];
    printf("%d %d\n", -pr.first, pr.second);
  }
  return 0;
}
