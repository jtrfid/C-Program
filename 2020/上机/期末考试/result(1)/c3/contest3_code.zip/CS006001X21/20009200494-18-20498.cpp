#include<stdio.h>
int m,q[35][3],flag=0;
float w[35][3]={};
int main(){
	scanf("%d",&m);
	for(int i=0;i<m;i++)
	{
		scanf("%d%d%d",&q[i][0],&q[i][1],&q[i][2]);
	}
	for(int i=0;i<m;i++)
	{
		if(q[i][0]<q[i][1]+q[i][2]&&q[i][1]<q[i][2]+q[i][0]&&q[i][2]<q[i][1]+q[i][0])
		{
			float p=(q[i][0]+q[i][1]+q[i][2])/2.0;
			w[i][0]=p*(p-q[i][0])*(p-q[i][1])*(p-q[i][2]);
			w[i][1]=i;
		}
		else w[i][2]=-1;
	}
	for(int i=0;i<m-1;i++)
	{
		for(int j=0;j<m-i-1;j++)
		{
			if(w[j][0]<w[j+1][0])
			{
				float tmp=w[j][0];
				w[j][0]=w[j+1][0];
				w[j+1][0]=tmp;
				float tmp1=w[j][1];
				w[j][1]=w[j+1][1];
				w[j+1][1]=tmp1;
				float tmp2=w[j][2];
				w[j][2]=w[j+1][2];
				w[j+1][2]=tmp2;
			}
		}
	}
	
	for(int i=0;i<m;i++)
	{
		if(w[i][2]!=-1)
		{
			printf("%.0f %.0f\n",w[i][0],w[i][1]);
			flag=1;
		}
		
		
	}
	if(flag==0)printf("no");
	
	return 0;
}
