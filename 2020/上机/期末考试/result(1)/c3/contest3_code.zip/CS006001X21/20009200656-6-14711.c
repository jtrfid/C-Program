#include<stdio.h>
int main()
{
	int i,m,n;
	scanf("%d%d",&m,&n);
	int a[3]={0};
	for(i=m;i<=n;i++)
	{
		if(i%2==1)
		  a[0]++;
		if(i%2==0)
		  a[1]++;
		if(i%7==0&&i%3!=0)
		  a[2]++;
	}
	int max;
	max=a[0];
	for(i=1;i<3;i++)
	{
		max=max>a[i]?max:a[i];
	}
	printf("%d %d %d\n",a[0],a[1],a[2]);
	printf("%d",max);
	return 0;
}
