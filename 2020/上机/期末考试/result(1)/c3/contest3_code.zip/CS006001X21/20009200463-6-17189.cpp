#include<stdio.h>
#include<string.h>
int main(){
	int m,n,a[3]={0},i,j;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++){
		if(i%2==1) a[0]++;
		else a[1]++;
	}
	for(i=m;i<=n;i++){
		if(i%7==0&&i%3!=0) a[2]++;
	}
	printf("%d %d %d\n",a[0],a[1],a[2]);
	for(i=0;i<3;i++){
		for(j=0;j<2-i;j++){
			if(a[j]>a[j+1]){
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	printf("%d",a[2]);
	return 0;
}
