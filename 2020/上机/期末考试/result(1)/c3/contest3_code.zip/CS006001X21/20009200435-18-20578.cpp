#include<stdio.h>
long int fun(int a,int b,int c)
{
	double s,p;
	p=(a+b+c)/2.0;
	s=p*(p-a)*(p-b)*(p-c); 
	return (int)s;
}
int main()
{
	int m,i,p,num=0;
	scanf("%d",&m);
	int a[m][3];
	int b[30];
	int c[30];
	for(i=0;i<m;i+=1)
	{
		for(p=0;p<3;p+=1)
		{
			scanf("%d",&a[i][p]);
		}
	}
	
	for(i=0,p=0;i<m;i+=1)
	{
		if(a[i][0]<a[i][1]+a[i][2]&&a[i][1]<a[i][0]+a[i][2]&&a[i][2]<a[i][1]+a[i][0])
		{
			num+=1;
			c[p]=i;
			p+=1;
			b[p]=fun(a[i][0],a[i][1],a[i][2]);
		}
	}
	int k,j,z,t;
	for(i=0;i<p;i+=1)
	{
		for(k=i,j=i+1;j<p;j+=1)
		{
			if(b[k]>b[j])
			{
				k=j;
			}
		}
		if(i!=k)
		{
			t=b[k];
			b[k]=b[i];
			b[i]=t;
			z=c[k];
			c[k]=c[i];
			c[i]=z;
		}
	}
	for(i=0;i<p;i+=1)
	{
		printf("%d %d\n",b[i],c[i]);
	}
	
	if(num==0)
	{
		printf("no");
	}
	return 0;
}
