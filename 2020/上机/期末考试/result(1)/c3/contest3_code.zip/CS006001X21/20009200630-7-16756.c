#include<stdio.h>

int main()
{
	int a, b[10];
	scanf("%d\n",&a);
	int i;
	for(i=0; i<10; i++)
	{
		scanf("%d ",&b[i]);
	}
	int  sum=0, c[10];
	for(i=0; i<10; i++)
	{
		sum++;
		if(b[i]==a)
		{
			sum--;
		}continue;
		c[sum-1]=b[i];
	}
	int k, flag_swap, t;
	for(i=0; i<sum; i++)
	{
		flag_swap=0;
		for(k=0; k<sum-i-1; k++)
		{
			if(c[k]>c[k+1])
			{
				t=c[k];
				c[k]=c[k+1];
				c[k+1]=t;
				flag_swap=1;
			}
		}
		if(flag_swap==0)break;
	}
	for(i=0; i<sum; i++)
	{
		printf("%d ",c[i]);
	}
	return 0;
}
