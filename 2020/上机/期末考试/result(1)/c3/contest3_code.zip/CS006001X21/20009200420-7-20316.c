#include <stdio.h>
int main()
{
	int a,b[10],c[10],t,m,i,j;
	m=0;
	scanf("%d",&a);
	scanf("%d %d %d %d %d %d %d %d %d %d",&b[0],&b[1],&b[2],&b[3],&b[4],&b[5],&b[6],&b[7],&b[8],&b[9]);
	for(i=0;i<=9;i++)
	if(b[i]!=a)
	{
		c[m]=b[i];
		m++;
	}
	for(i=0;i<=m-2;i++)
	{
		for(j=0;j<=m-1-i;j++)
		if(c[i]>c[i+j])
		{
			t=c[i];
			c[i]=c[i+j];
			c[i+j]=t;
		
		}
	for(i=0;i<=m-1;i++)
	printf("%d ",c[i]);
	return 0;
		
	}
	
}
