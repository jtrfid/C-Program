#include<bits/stdc++.h>
using namespace std;

int main(){
	int i,n,a[10];
	cin>>n;
	for(i=0;i<10;i++){
		cin>>a[i];
	}
	sort(a,a+10);
	for(i=0;i<10;i++){
		if(n!=a[i])cout<<a[i]<<" ";
	}
	return 0;
}
