#include<stdio.h>
typedef struct date{
	int s;
	int i;
}ret;
void myquick(int *num,int l,int r);
void myquick1(ret *num,int l,int r);
int main()
{
	int m;
	scanf("%d",&m);
	int num[m][3];
	ret num1[m];
	int i,j;
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d",&num[i][j]);
		}
		myquick(num[i],0,2);
		if(num[i][0]+num[i][1]>num[i][2]){
			int a=num[i][0];
			int b=num[i][1];
			int c=num[i][2];
			double p=(a+b+c)/2.0;
			int s=p*(p-a)*(p-b)*(p-c);
			num1[i].s=s;
			num1[i].i=i;
		}else{
			num1[i].s=-1;
			num1[i].i=-1;
		}
	}
	int cnt=0;
	myquick1(num1,0,m-1);
	for(i=m-1;i>=0;i--){
		if(num1[i].s!=-1){
			printf("%d %d\n",num1[i].s,num1[i].i);
			cnt=1;
		}
		
	}
	if(cnt==0){
		printf("no\n");
	}
	return 0;
}
void myquick(int *num,int l,int r){
	if(l>=r)
	return;
	int first=l;
	int last=r;
	int key=num[first];
	while(first<last){
		while(first<last&&num[last]>=key)
		last--;
		num[first]=num[last];
		while(first<last&&num[first]<=key)
		first++;
		num[last]=num[first];
	}
	num[first]=key;
	myquick(num,l,first-1);
	myquick(num,last+1,r);
}
void myquick1(ret *num,int l,int r){
	if(l>=r)
	return;
	int first=l;
	int last=r;
	int key=num[first].s;
	ret key1=num[first];
	while(first<last){
		while(first<last&&num[last].s>=key)
		last--;
		num[first]=num[last];
		while(first<last&&num[first].s<=key)
		first++;
		num[last]=num[first];
	}
	num[first]=key1;
	myquick1(num,l,first-1);
	myquick1(num,last+1,r);
}
