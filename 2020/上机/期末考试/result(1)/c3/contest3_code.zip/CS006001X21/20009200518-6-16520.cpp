#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	int i,j=0,o=0,x=0;
	for(i=m;i<=n;i++)
	{
		if(i%2!=0)
		{
			j++;
		}
		else
		{
			o++;
		}
		if(i%7==0&&i%3!=0)
		{
			x++;
		}
	}
	int max;
	max=j;
	if(o>max)
	{
		max=o;
	}
	if(x>max)
	{
		max=x;
	}
	printf("%d %d %d\n%d",j,o,x,max);
}
