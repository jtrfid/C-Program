#include<stdio.h>
int main()
{
	int n,a[10],i,j=0,t,k,b[10];
	scanf("%d",&n);
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}
		for(i=0;i<10;i++)
	{
		if(a[i]==n)
		continue;
	else{
		b[j]=a[i];
		j++;
	}
	}

		for(i=0;i<j;i++)
	{
		for(k=j-1;k>i;k--)
		{
			if(b[k]<b[k-1])
			{
				t=b[k];b[k]=b[k-1];b[k-1]=t;
			}
		}
	}
	for(i=0;i<j;i++)
	{
	
		printf("%d ",b[i]);
	}
	return 0;
}
