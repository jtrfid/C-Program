#include <stdio.h>
int main(){
	int n;
	int a[10];
	scanf("%d", &n);
	int i;
	for(i = 0;i < 10;i++){
		scanf("%d", &a[i]);
	}
	int k = 0,b[10];
	for(i = 0;i < 10;i++){
		if(a[i] == n) continue;
		b[k++] = a[i];
	}
	int j, t;
	for(i = 0;i < k;i++){
		for(j = 0;j < k - i - 1;j++){
			if(b[j] > b[j + 1]){
				t = b[j + 1];
				b[j + 1] = b[j];
				b[j] = t;
			}
		}
	}
	for(i = 0;i < k;i++){
		printf("%d ", b[i]);
	}
	return 0;
}
