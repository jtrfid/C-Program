#include<stdio.h>
int main()
{
	int n,i=0,a[10],count=10;
	scanf("%d",&n);
	while(i<count)
	{
		scanf("%d",&a[i]);
		if(a[i]==n)
		{
			--count;
			--i;
		}
		i++;
	}
	int j,k,temp;
	for(i=0;i<count-1;i++)
	{
		k=i;
		for(j=i+1;j<count;j++)
		{
			if(a[j]<a[k])
			{
				k=j;
			}
		}
		if(k!=i)
			{
				temp=a[i];a[i]=a[k];a[k]=temp;
			}
	}
	for(i=0;i<count;i++)
		printf("%d ",a[i]);
	return 0;
}
