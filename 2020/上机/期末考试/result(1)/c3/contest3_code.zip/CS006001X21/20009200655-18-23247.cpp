#include<stdio.h>
typedef struct
{
	int t;
    int mianji;
}he;
int main()
{
	int m,i,j;
	he o;
	he b[10];
	he p[10];
	scanf("%d",&m);
	int a[m][3];
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		double c=a[i][0];
		double d=a[i][1];
	    double e=a[i][2];
		double p=(c+d+e)/2;
		b[i].t=i;
		b[i].mianji=p*(p-c)*(p-d)*(p-e);
	}
	int k=0;
	for(i=0;i<m;i++)
	{
		if(b[i].mianji>0)
		p[k++]=b[i];
	}
	if(k==0) printf("no");
	for(i=0;i<k;i++)
	{
		for(j=0;j<k-i-1;j++)
		{
			if(p[j].mianji<p[j+1].mianji)
			{
				o=p[j];
				p[j]=p[j+1];
				p[j+1]=o;
			}
		}
	}
	for(i=0;i<k;i++)
	{
		printf("%d %d\n",p[i].mianji,p[i].t);
	}
	return 0;
}

