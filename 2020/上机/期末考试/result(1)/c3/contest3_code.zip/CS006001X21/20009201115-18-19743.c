#include <stdio.h>
int main()
{
	int m;
	double n[m][3];
	double a,b,c;
	int i,j;
	double p,q;
	int s;
	int t=0;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%lf",&n[i][j]);
		}	
	}
	for(i=0;i<m;i++)
	{
		a=n[i][0];
		b=n[i][1];
		c=n[i][2];
		if(a+b>c&&a+c>b&&b+c>a)
		{
			p=(a+b+c)/2;
			q=p*(p-a)*(p-b)*(p-c);
			s=p/1;
			printf("%d %d\n",s,i);
			t=1;
		}
	}
	if(t=0)
	{
		printf("no");
	}
	return 0;
}
