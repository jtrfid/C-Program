#include<stdio.h>
int main()
{
	int x,i,j,t,sum=0;
	scanf("%d",&x);
	int a[10];
	for(i=0;i<10;i++)
	scanf("%d",&a[i]);
	int n=10;
	for(i=0;i<n;i++)
    {
	int s=0;
	for(j=0;j<n-i-1;j++)
	{
		if(a[j+1]<a[j])
		{
			t=a[j];
			a[j]=a[j+1];
			a[j+1]=t;
			s=1;
		}
	}
	if(s=0)break;
    }
    int k=0;
    for(i=0;i<n;i++)
	{
		if(a[i]==x)k=1;
	}
	if(k=0)
	{
	for(i=0;i<n;i++)
    printf("%d",&a[i]);
	}
	else
	{
		for(i=0;i<n;i++)
		{sum++;
		if(a[i]==x)break;
		}
	int b[n-1];
	for(i=0;i<n-1;i++)
	{
		if(i<sum)
		b[i]=a[i];
		else
		b[i]=a[i+1];
	}
	printf("%d",&b[i]);
	}
	return 0;
}
