#include<stdio.h>
#include<string.h>
int main(){
	int m,n,a[10],i=0,j,k;
	scanf("%d",&m);
	for(int g=0;g<10;g++){
		scanf("%d",&n);
		if(n!=m){
			a[i]=n;
			i++;
		}
	}
	for(j=0;j<i;j++){
		for(k=0;k<i-1-j;k++){
			if(a[k]>a[k+1]){
				int temp=a[k];
				a[k]=a[k+1];
				a[k+1]=temp;
			}
		}
	}
	for(j=0;j<i;j++){
		printf("%d ",a[j]);
	}
	return 0;
}
