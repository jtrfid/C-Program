#include<stdio.h>
int main()
{
	int a,b[10],i,c[10],j,u,flag,t;
	scanf("%d",&a);
	for(i=0;i<=9;i++)
	{
		scanf("%d ",&b[i]);
	}
	for(i=0;i<=9;i++)
	{
		if(b[i]!=a)
		{
			c[i]=b[i];
		}
	}
    for(u=0;u<10;u++)
    {
    	flag=0;
    	for(j=0;j<9-u;j++)
    	{
    		if(c[j]>c[j+1])
    		{
    			t=c[j];c[j]=c[j+1];c[j+1]=t;
    			flag=1;
    		}
    	}
    	if(flag==0)break;
    }
    printf("%d %d %d %d %d %d %d %d %d %d",c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]);
	return 0;
}
