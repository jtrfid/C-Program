#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
#define maxn 35

int m;
struct tr{
	int id, a, b, c, s;
	double p;
}t[maxn];
bool vis;

bool cmp(tr u, tr v){
	if(u.s == v.s) return u.id < v.id;
	return u.s > v.s;
}

int main(){
	//freopen("in.txt", "r", stdin);
	cin >> m;
	for(int i = 0; i < m; ++i){
		cin >> t[i].a >> t[i].b >> t[i].c;
		t[i].p = 1.0 * (t[i].a + t[i].b + t[i].c) / 2;
		t[i].id = i;
		int mx = max({t[i].a, t[i].b, t[i].c});
		if(t[i].a + t[i].b + t[i].c - mx > mx) {
			vis = 1;
			t[i].s = (int)(t[i].p*(t[i].p-t[i].a)*(t[i].p-t[i].b)*(t[i].p-t[i].c));
			//if((t[i].a + t[i].b + t[i].c) % 2 == 1) ++t[i].s;
		}
	}
	sort(t, t+m, cmp);
	for(int i = 0; i < m; ++i){
		if(t[i].s) cout << t[i].s << " " << t[i].id << endl;
	}
	if(!vis) cout << "no";













	return 0;
}
