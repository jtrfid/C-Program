#include<stdio.h>


int main()
{
	int m,i,j,n=0,tmp;
	int num[30][3]={0};
	int S[30]={0},lin[30]={0};
	float p,s;
	scanf("%d",&m);
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d",&num[i][j]);
		}
	}
	for(i=0;i<m;i++){
		if((num[i][0]+num[i][1]>num[i][2])&&(num[i][0]+num[i][2]>num[i][1])&&(num[i][2]+num[i][1]>num[i][0])){
			p=(num[i][0]+num[i][1]+num[i][2])*0.5;
			s = p*(p-num[i][0])*(p-num[i][1])*(p-num[i][2]);
			S[n]=(int)s;
			lin[n]=i;
			n++;
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n-i-1;j++){
			if(S[j]<S[j+1]){
				tmp=S[j];
				S[j]=S[j+1];
				S[j+1]=tmp;
				tmp=lin[j];
				lin[j]=lin[j+1];
				lin[j+1]=tmp;
			}
		}
	}
	if(n==0){
		printf("no");
	}else{
		for(i=0;i<n;i++)printf("%d %d\n",S[i],lin[i]);
}
	return 0;
}
