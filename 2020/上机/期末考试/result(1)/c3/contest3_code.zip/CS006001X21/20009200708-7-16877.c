#include<stdio.h>
int main(){
	void swap(int *x,int*y);
	int i,j,n,t;	
	int a[10];
	int *p;
	scanf("%d",&n);
	t=n;
	for(i=0;i<10;i++){
		scanf("%d",&a[i]);
	}
	p=a;
	for(i=0;i<10;i++){
		for(j=0;j<10-i;j++){
			if(a[j]>a[j+1]){
				swap(&a[j],&a[j+1]);
			}
		}
	}
	for(;p<a+10;p++){
		if(*p==t){
			continue;
		}
		printf("%d ",*p);

} 
} 

 void swap(int*x,int *y){
	int z;
	z=*x;
	*x=*y;
	*y=z;
}
