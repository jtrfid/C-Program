#include<stdio.h>
typedef struct per
{
	char name[11];
	int a[3];
}PER;
int main()
{
	int n,i,count=0,k;
	scanf("%d",&n);
	PER pers[n],t1,t2,t;
	getchar();
	for(i=0;i<n;i++)
	{
		scanf("%s %d/%d/%d",pers[i].name,&(pers[i].a[0]),&(pers[i].a[1]),&(pers[i].a[2]));
	}
	t1=pers[0];t2=pers[0];
	for(i=0;i<n;i++)
	{
		k=count;
		if(pers[i].a[0]>1821&&pers[i].a[0]<2021)
		{
			count++;
		}
		else if(pers[i].a[0]==1821)
		{
			if(pers[i].a[1]>1||pers[i].a[2]>=9)
			{
				count++;
			}
		}
		else if(pers[i].a[0]==2021)
		{
			if(pers[i].a[1]==1&&pers[i].a[2]<=9)
			{
				count++;
			}
		}
		if(count-k!=1)
		{
			continue;
		}
		if(pers[i].a[0]<t1.a[0]||(pers[i].a[0]==t1.a[0]&&(pers[i].a[i]<t1.a[1]||(pers[i].a[1]==t1.a[1]&&pers[i].a[2]<t1.a[2]))))
		{
			t=t1;t1=pers[i];pers[i]=t;
		}
		if(pers[i].a[0]>t1.a[0]||(pers[i].a[0]==t1.a[0]&&(pers[i].a[i]>t1.a[1]||(pers[i].a[1]==t1.a[1]&&pers[i].a[2]>t1.a[2]))))
		{
			t=t2;t2=pers[i];pers[i]=t;
		}
	}
	if(count==0)
	{
		printf("no");
		return 0;
	}
	printf("%d\n",count);
	printf("%s\n",t1.name);
	printf("%s\n",t2.name);
	return 0;
}
