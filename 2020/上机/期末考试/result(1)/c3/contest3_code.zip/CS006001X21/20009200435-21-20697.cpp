#include<stdio.h>
int main()
{
	int n,i=0;
	scanf("%d",&n);
	printf("%d",0);
	return 0;
}
