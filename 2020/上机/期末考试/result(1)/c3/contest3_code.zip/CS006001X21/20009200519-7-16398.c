#include<stdio.h>
int main()
{
	int a[20],i=1,x,n,len;
	int b[20],j;
	int k,t;
	scanf("%d",&x);
	while(1)
	{
		scanf("%d",&a[i]);
		n=i;
		if(getchar()=='\n')
		{
			break;
		}
		i++;
	}
	len=n;
	for(i=1,j=1;i<=n;i++)
	{
		if(a[i]!=x)
		{
			b[j]=a[i];
			j++;
		}
		if(a[i]==x)
		{
			len--;
		}
	}
	
	for(i=1;i<=len;i++)
	{
		for(k=i+1;k<=len;k++)
		{
			if(b[i]>b[k])
			{
				t=b[i];
				b[i]=b[k];
				b[k]=t;
			}
		}
	}
	for(i=1;i<=len;i++)
	{
		printf("%d ",b[i]);
	}

}
