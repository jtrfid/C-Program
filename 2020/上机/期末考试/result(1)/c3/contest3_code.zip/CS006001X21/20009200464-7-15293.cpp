#include<stdio.h>
#include<string.h>
int main(){
	int i,j=0,k=0,l,n=10,t;
	int a[10]={0};
	int b[10]={0};
	char s[100],ss[100];
	scanf("%d",&t);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		if(a[i]!=t){
			b[k]=a[i];
			k++;
		}
	}
	for(i=0;i<k;i++){
		for(j=0;j<k-i-1;j++){
			if(b[j]>b[j+1]){
				t=b[j];b[j]=b[j+1];b[j+1]=t;
			}
		}
	}
	for(i=0;i<k;i++){
		printf("%d ",b[i]);
	}

	return 0;
}
