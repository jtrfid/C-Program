#include <stdio.h>
#include <string.h>
int nian(int a, int b, int c);
int main(){
	struct juming{
		char name[10];
		int year;
		int month;
		int day;
	}p[100];
	int n, i, j;
	scanf("%d", &n);
	for(i = 0;i < n;i++){
		scanf("%s %d/%d/%d", &p[i].name, &p[i].year, &p[i].month, &p[i].day);
	}
	int cnt = 0;
	for(i = 0;i < n;i++){
		if(p[i].year > 1821&&p[i].year < 2021) cnt++;
		else if(p[i].year == 1821){
			if(p[i].month >= 1&&p[i].day >= 9) cnt++;
		}
		else if(p[i].year == 2021){
			if(p[i].month <= 1&&p[i].day <= 9) cnt++;
		}
		else {
			p[i].year = 0;
			p[i].month = 0;
			p[i].day = 0;
		}
	}
	if(cnt != 0){
		printf("%d\n", cnt);
		int temp, a[n];
		char t[10];
		for(i = 0;i < n;i++){
			a[i] = nian(p[i].year, p[i].month, p[i].day);
		}
		for(i = 0;i < n;i++){
			for(j = 0;j < n - 1 - i;j++){
				if(a[j] < a[j + 1]){
					temp = a[j + 1];
					a[j + 1] = a[j];
					a[j] = temp;
					strcpy(t,p[j + 1].name);
					strcpy(p[j + 1].name, p[j].name);
					strcpy(p[j].name, t);
				}
			}
		}
		int max, min;
		for(i = 0;a[i] != 0;i++);
		max = a[i - 1];
		min = a[0];
		for(i = 0;a[i] != 0;i++){
			if(a[i] == max) puts(p[i].name);
		}
		for(i = 0;a[i] != 0;i++){
			if(a[i] == min) puts(p[i].name);
		}
	}
	else printf("%d", cnt);
	return 0;
}
int nian(int a, int b, int c){
	if(a = 2021) return c;
	else if(a == 0) return 0;
	else if(a == 2020) return 375 - (30 * b + c);
	else return 365*(2020 - a) + 375 - (30 * b + c);
}
