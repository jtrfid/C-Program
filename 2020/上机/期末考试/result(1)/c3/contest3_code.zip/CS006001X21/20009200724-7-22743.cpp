#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int a[10]={};
	int max;
	int i=0,j=0,m=j+1;
    for(i=0;i<10;i++)
      { 
      scanf("%d",&a[i]);}
      for(i=0;i<10;i++){
      if(n!=a[i])
	   while(j<=i)
	      {
	      a[j]=a[i];
	      max=a[j]>a[m]?a[m]:a[j];
		  j++;
		  }printf("%d",max);
      }
     
    
}
	
	

