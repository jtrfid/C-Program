#include<bits/stdc++.h>
using namespace std;

typedef struct peo{
	string na;
	int n,y,r;
}peop;


bool cmp(const peop a1,const peop a2){
	if(a1.n==a2.n){
		if(a1.y==a2.y){
			return a1.r<a2.r;
		}
		return a1.y<a2.y;
	}
	return a1.n<a2.n;
}

int main(){
	peop a[100005],xiao,lao;
	int i,n,flag=0,j,mx=0,mn=0;
	cin>>n;
	xiao.n=2021,xiao.y=1;xiao.r=9;
	lao.n=1821;lao.y=1;lao.r=9;
	for(i=0;i<n;i++){
		if(flag){
			i--;n--;
		}
		flag=0;
		cin>>a[i].na;
		cin>>a[i].n;
		getchar();
		cin>>a[i].y;
		getchar();
		cin>>a[i].r;
		//scanf("%d/%d/%d",,a[i].y,a[i].r);
		if(cmp(xiao,a[i])||cmp(a[i],lao)){
			flag=1;
		}
	}
	if(flag)n--;
	cout<<n<<endl;
	for(i=0;i<n;i++){
		if(cmp(a[mx],a[i]))mx=i;
		if(cmp(a[i],a[mn]))mn=i;
		
	}
	if(n!=0){
	cout<<a[mn].na<<endl;
	cout<<a[mx].na;
}
	/*for(i=0;i<10;i++){
		if(n!=a[i])cout<<a[i]<<" ";
	}*/
	return 0;
}
