#include<stdio.h>
#include<string.h>
typedef struct{
	char name[20];
	int year;
	int mon;
	int day;
	int is;
}date;
int main()
{
	int n;
	int i;
	scanf("%d",&n);
	int max=0;
	int min=0;
	date a[n];
	int t=n;
	for(i=0;i<n;i++)
	{
		scanf("%s %d %d %d",&a[i].name,&a[i].year,&a[i].mon,&a[i].day);
		a[i].is=1;
		if(a[i].year>2021)
		t--;
		if(a[i].year==2021&&a[i].mon>1)
		t--;
		if(a[i].year==2021&&a[i].mon==1&&a[i].day>9)
		t--;
		if(a[i].year<1821)
		t--;
		if(a[i].year==1821&&a[i].mon<1)
		t--;
		if(a[i].year==1821&&a[i].mon==1&&a[i].day<9)
		t--;
		if(a[i].year>a[max].year)
		{
			max=i;
		}
		if(a[i].year==a[max].year&&a[i].mon>a[max].mon)
		max=i;
		if(a[i].year==a[max].year&&a[i].mon==a[max].mon&&a[i].day>a[max].day)
		max=i;
		if(a[i].year<a[min].year)
		{
			min=i;
		}
		
	}
	printf("%d %s %s",t,a[max].name,a[min].name);
	
}
