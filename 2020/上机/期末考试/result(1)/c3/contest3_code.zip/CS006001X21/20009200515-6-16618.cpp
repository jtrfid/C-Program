#include<stdio.h>
int main(){
	int m,n;
	scanf("%d %d",&m,&n);
	int a,b,c,d,e,f,g=0,h;
	if((n-m)%2!=0){
		e=n-m+1;
		a=e/2;
		b=e/2;
	}
	if((n-m)%2==0){
		e=n-m+1;
		if(n%2==0){
			a=e/2;
			b=e/2+1;
		}
		if(n%2==1){
			a=e/2+1;
			b=e/2;
		}
    }
	for(f=m;f<=n;f++){
		if(f%7==0&&f%3!=0){g=g+1;
		}
	}    
	printf("%d %d %d",a,b,g);
	h=a;
	if(b>=a){
		h=b;
	}
	printf("\n");
	printf("%d",h);
	return 0;
}
