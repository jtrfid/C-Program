#include<stdio.h>
#include<string.h>
int main(){
	int m,b[30][3],c[30][2]={0},i,j,k,temp;
	float p,t;
	scanf("%d",&m);
	for(i=0;i<m;i++){
		scanf("%d %d %d",&b[i][0],&b[i][1],&b[i][2]);
	}
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			for(k=0;k<2-j;k++){
				if(b[j][k]>b[j][k+1]){
					temp=b[j][k];
					b[j][k]=b[j][k+1];
					b[j][k+1]=temp;
				}
			}
		}
	}
	k=0;
	for(i=0;i<m;i++){
		
		if(b[i][0]+b[i][1]>b[i][2]){
			p=(b[i][0]+b[i][1]+b[i][2])/2.0;
			t=p*(p-b[i][0])*(p-b[i][1])*(p-b[i][2]);
			c[k][0]=(int)t;
			c[k][1]=i;
			k++;
		}
	}
	if(k==0) printf("no");
	else{
	for(i=0;i<k;i++){
		for(j=0;j<k-i-1;j++){
			if(c[j][1]>c[j+1][1]){
				temp=c[j][1];
					c[j][1]=c[j+1][1];
					c[j+1][1]=temp;
			}
		}
	}
	for(i=0;i<k;i++){
		for(j=0;j<k-i-1;j++){
			if(c[j][0]<c[j+1][0]){
				temp=c[j][0];
					c[j][0]=c[j+1][0];
					c[j+1][0]=temp;
			}
		}
	}
	for(i=0;i<k;i++){
		printf("%d %d\n",c[i][0],c[i][1]);
	}
}
	return 0;
}
