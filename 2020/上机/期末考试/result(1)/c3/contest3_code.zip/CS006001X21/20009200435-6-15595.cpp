#include<stdio.h>
int main()
{
	int m,n;
	int a,b,s,i;
	scanf("%d %d",&m,&n);
	for(i=m,a=0,b=0,s=0;i<=n;i+=1)
	{
		if(i%2==0)
		{
			a+=1;
		}
		else
		{
			b+=1;
		}
		if(i%7==0&&i%3!=0)
		{
			s+=1;
		}
	}
	printf("%d %d %d\n",b,a,s);
	if(a>=b&&a>=s)
	{
		printf("%d",a);
	}
	else if(b>=a&&b>=s)
	{
		printf("%d",b);
	}
	else
	{
		printf("%d",s);
	}
	return 0;
}
