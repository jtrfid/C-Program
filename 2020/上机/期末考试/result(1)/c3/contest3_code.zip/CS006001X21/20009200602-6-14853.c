#include<stdio.h>
#include<string.h>
#include<math.h>

int main(void)
{
	int a,b,j=0,o=0,s=0;
	int max;
	int i;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{
		if(i%2==0)
		o++;
		if(i%2==1)
		j++;
		if(i%7==0&&i%3!=0)
		s++;
	}
	max=j;
	if(max<o)
	max=o;
	if(max<s)
	max=s;
	printf("%d %d %d\n%d",j,o,s,max);
	return 0;
}
