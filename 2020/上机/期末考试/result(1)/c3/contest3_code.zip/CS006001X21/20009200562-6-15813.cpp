#include<stdio.h>
#include<string.h>
int main()
{
	int i = 0,j = 0,k = 0,n = 0,m = 0,t = 0,flag = 1,a[10] = {0},b[10] = {0};
	scanf("%d",&n);
	for(i = 0;i < 10;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i = 0;i < 10 ;i++)
	{
		if(a[i] != n)
		{
			b[j] = a[i];
			j++;
		}
	}

	
	for(i = 0,flag = 1;i < j - 1&&flag;i++)
{
	flag = 0;
	for(k = 0;k < j - i - 1;k++)
	{
		if(b[k] > b[k+1])
		{
			t = b[k];
			b[k] = b[k+1];
			b[k+1] = t;
			flag = 1;
		}
	}
}
for(i = 0;i < j;i++)
	{
		printf("%d ",b[i]);
	}		
	
	return 0;
}
