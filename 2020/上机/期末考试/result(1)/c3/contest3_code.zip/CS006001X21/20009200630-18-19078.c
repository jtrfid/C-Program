#include<stdio.h>

int main()
{
	int m;
	scanf("%d",&m);
	int a[m][3];
	int i, j;
	for(i=0; i<m; i++)
	{
		for(j=0; j<3; j++)
		{
			scanf("%d ",&a[i][j]);
		}
		scanf("\n");
	}
	float p, S; 
	int num=0, h, b[]={0}, s[]={0};
	for(i=0; i<m; i++)
	{
		if((a[i][0]+a[i][1])>a[i][2]&&(a[i][0]-a[i][1])<a[i][2])
		{
			num++;
			h=num-1;
			p=0.5*(a[i][0]+a[i][1]+a[i][2]);
			S=p*(p-a[i][0])*(p-a[i][1])*(p-a[i][2]);
			s[h]=(int)S;
			b[h]=i;
		}
	}
	if(num==0)
	{
		printf("no");
	}
	
	return 0;
}
