#include<stdio.h>
int main()
{
struct{
	char name[10];
	int year;
	int moon;
	int day;
}s[100];
int n,i,x,c=0,b[100];
scanf("%d",&n);
for(i=0;i<n;i++)
{
	scanf("%s %d/%d/%d",&s[i].name,&s[i].year,&s[i].moon,&s[i].day);
}
for(i=0;i<n;i++)
{
	if(s[i].year>2021&&s[i].year<1821)continue;
	else if(s[i].year==2021&&s[i].moon>1||(s[i].moon==1&&s[i].day>9))continue;
	 else if(s[i].year==1821&&(s[i].moon==1&&s[i].day<9))continue;
	 else {
	 	b[c]=i;
	 	c++;
	 	
	 }
	
}
printf("%d",c);
if(c!=0)
{

printf("\n");
for(i=0;i<c;i++)
{x=b[i];
printf("%s ",s[x].name);
	printf("%d/%d/%d",s[x].year,s[x].moon,s[x].day);
	printf("\n");
}}
	return 0;
}
