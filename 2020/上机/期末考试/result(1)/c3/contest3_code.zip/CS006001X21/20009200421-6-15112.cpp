#include<stdio.h>
int main()
{
	int m,n,i,j=0,k=0,p=0;
	int max;
	scanf("%d%d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2!=0) j++;
		else k++;
	}
	for(i=m;i<=n;i++)
	{
		if(i%7==0&&i%3!=0) p++;
	}
	if(j>k) max=j;
	else max=k;
	printf("%d %d %d\n%d",j,k,p,max);
	return(0);
}
