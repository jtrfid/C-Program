#include<stdio.h>
#include<string.h>
#include<math.h>

int main(){
	int m,n,i,j,t;
	int a1=0,a2=0,a3=0;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++){
		if(i%2==0){
			a2++;
		}
		else{
			a1++;
		}
		if(i%7==0&&i%3!=0){
			a3++;
		}
	}
	printf("%d %d %d\n",a1,a2,a3);
	if(a1>a2){
		printf("%d",a1);
	}
	else{
		printf("%d",a2);
	}
	return 0;
}
