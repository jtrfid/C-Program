#include<stdio.h>
int main()
{
	int a,num[10],i,num1[10],j,z,tmp;
	
	scanf("%d",&a);
	for(i=0;i<10;i++){
		scanf("%d",&num[i]);
	}
	j=0;
	for(i=0;i<10;i++){
		if(num[i]!=a){
			num1[j]=num[i];
			j++;
		}
	}
	for(i=0;i<j+1;i++){
		for(z=0;z<j-i;z++){
			if(num1[z]>num1[z+1]){
				tmp=num1[z];
				num1[z]=num1[z+1];
				num1[z+1]=tmp;				
			}
		}
	} 
	for(i=0;i<j;i++){
		printf("%d ",num1[i]); 
	}
	return 0;
}
