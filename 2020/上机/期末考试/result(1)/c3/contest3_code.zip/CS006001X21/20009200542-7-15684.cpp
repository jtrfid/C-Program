#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
#define maxn 15

int a, c, b[maxn];
vector<int> v;

int main(){
	//freopen("in.txt", "r", stdin);
	cin >> a;
	for(int i = 1; i <= 10; ++i){
		cin >> c;
		if(c != a) v.push_back(c);
	}
	sort(v.begin(), v.end());
	cout << v[0];
	for(int i = 1; i < v.size(); ++i)
		cout << " " << v[i];















	return 0;
}
