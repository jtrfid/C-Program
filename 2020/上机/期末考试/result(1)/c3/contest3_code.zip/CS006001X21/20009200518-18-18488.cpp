#include<stdio.h>
double MJ(int a,int b,int c)
{
	double p,y;
	p=(a+b+c)/2.0;
	y=p*(p-a)*(p-b)*(p-c);
	return y;
}
int isSJX(int a,int b,int c)
{
	return (a+b>c)&&(a+c>b)&&(b+c>a);
}
int qz(double n)
{
	int x;
	x=n;
	return x;
}
int main()
{
	int m;
	scanf("%d",&m);
	int a[m][3];
	int b[m];
	int i,j;
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		if(isSJX(a[i][0],a[i][1],a[i][2]))
		{
			b[i]=MJ(a[i][0],a[i][1],a[i][2]);
			b[i]=qz(b[i]);
		}
	}
	int max,k,t,c[m];
	for(i=0;i<m-1;i++)
	{
		max=b[i];
		k=i;
		for(j=i+1;j<m;j++)
		{
			if(b[j]>max)
			{
				max=b[j];
				k=j;
			}
		}
		if(k!=i)
		{
			t=b[i];
			b[i]=b[k];
			b[k]=t;
			c[i]=k;
		}
	}
	for(i=0;b[i]!=0;i++)
	{
		printf("%d %d\n",b[i],c[i]);
	}
	return 0;
}
