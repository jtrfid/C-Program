#include<stdio.h>
typedef struct
{int ss;
int line;
}tr;
int quzheng(double a)
{if((int) a==a)
return (int)a;
else return int(a+1);
}
void bubblesort(tr a[],int n)//���� 
{int i,k;
tr temp;
for(k=n-1;k>0;k--)
	{for(i=0;i<k;i++)
		{if(a[i].ss<a[i+1].ss)
			{temp=a[i];
			a[i]=a[i+1];
			a[i+1]=temp;
			}
		 else if(a[i].ss==a[i+1].ss)
		 	{if(a[i].line>a[i+1].line)
		 		{temp=a[i];
				a[i]=a[i+1];
				a[i+1]=temp;
		 		}
		 	}
		} 
	}

}
int judge(int a,int b,int c)//�ж��Ƿ��ܹ���������
{if(a+b>c&&a+c>b&&b+c>a)
	{return 1;
	}
else return 0;
} 

int main()
{int m;
scanf("%d",&m);
int a[31][3];
int i,j;
double p=0;

tr tr1[31];
double s1=0;
int k=0;
for(i=0;i<m;i++)
	{for(j=0;j<3;j++)
		{scanf("%d",&a[i][j]);
		}
	if(judge(a[i][0],a[i][1],a[i][2])==1)
		{p=double(a[i][0]+a[i][1]+a[i][2])/2;
		s1=p*(p-a[i][0])*(p-a[i][1])*(p-a[i][2]);
		
		tr1[k].ss=int(s1);
		tr1[k].line=i;
		k++;
		}
	}
bubblesort(tr1,k);
if(k==0)
	{printf("no");
	}
else 
{for(i=0;i<k;i++)
	{printf("%d %d\n",tr1[i].ss,tr1[i].line);
	}
}
return 0;

}
