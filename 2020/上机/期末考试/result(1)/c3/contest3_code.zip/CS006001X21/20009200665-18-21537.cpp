#include<stdio.h>
#include<math.h>
int puanduan(int a,int b,int c)
{
	if((a+b>c)||(a+c>b)||(b+c>a)) return 1;
	else return 0;
}
int zhouchang(int a,int b,int c)
{
	return (a+b+c)/2;
}
int mianji(int x,int a,int b,int c)
{
	int s=x*(x-a)*(x-b)*(x-c);
	return pow(s,2);
}
void paixu(int *h,int *t,int m)
{
	int i,j,k,t1,t2;
	for(i=0;i<m;i++)
	{
		for(j=i+1,k=i;j<m;j++)
		{
			if(h[j]>h[k]) k=j;
		}
		if(k!=i)
		{
			t1=h[i];h[i]=h[k];h[k]=t1;
			t2=t[i];t[i]=t[k];t[k]=t2;
		}
	}
}
int main()
{
	int m;
	scanf("%d",&m);
	int anti[m][3];
	int i,j;
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&anti[i][j]);
		}
	}
	int count=0,h[m],t[m],y[m];
	for(i=0;i<m;i++)
	{
		if(puanduan(anti[i][0],anti[i][1],anti[i][2])==1)
		{
			y[i]=zhouchang(anti[i][0],anti[i][1],anti[i][2]);
			h[i]=mianji(y[i],anti[i][0],anti[i][1],anti[i][2]);
			t[i]=i;
		}
		else 
		{
			y[i]=0;
			h[i]=0;
			t[i]=1001;
			count++;
		}
	}
	paixu(h,t,m);
	if(count==m) printf("no");
	else 
	{
		for(i=0;i<m;i++)
		{
			if(h[i]=0&&t[i]==1001) continue;
			else printf("%d %d\n",h[i],t[i]);
		}
	}
	return 0;
}

