#include<stdio.h>
int main(){
	int a=0;
	int b[10];
	int c[10];
	scanf("%d",&a);
	int i=0;
	for(i=0;i<10;i++){
		scanf("%d",&b[i]);
	}
    for(i=0;i<10;i++){
    	if(a=b[i]){
    		b[i]=0;
    	}else{
    		b[i]=b[i];
    	}
    }
    for(i=0;i<10;i++){
    	if(b[i]>b[i+1]){
    		b[i]=c[i];
    		b[i+1]=c[i+1];
    	    c[i]=b[i+1];
    	    c[i+1]=b[i];
		}else{
			b[i]=b[i];
			b[i+1]=b[i+1];
		}
    }
    for(i=0;i<10;i++){
    	printf("%d ",b[i]);
    }
    return 0;
}
