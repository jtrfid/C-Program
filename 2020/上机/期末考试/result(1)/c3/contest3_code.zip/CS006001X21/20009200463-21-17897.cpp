#include<stdio.h>
#include<string.h>
#define N 100000
int main(){
	int num,birth=0,i,j;
	char month[3]
	typedef struct people{
		char name[11];
		int y;
		int m;
		int d;
	}P;
	P p[N],temp;
	scanf("%d",&num);
	for(i=0;i<num;i++){
		scanf("%s %d/%s/%d",&p[i].name,&p[i].y,&month,&p[i].d);
		p[i].m=(month[0]-48)*10+(month[1]-48);
	}
	for(i=0;i<num;i++){
		if(p[i].y>1821&&p[i].y<2021) birth++;
		
	}
	for(i=0;i<num;i++){
		if(p[i].y==1821){
			if(p[i].m>1) birth++;
			else if(p[i].m=1){
				if(p[i].d>9) birth++;
			}
		}
	}
	for(i=0;i<num;i++){
		if(p[i].y==2021){
			if(p[i].m==1&&p[i].d<9) birth++;
		}
	}
	for(i=0;i<num;i++){
		for(j=0;j<num-i-1;j++){
			if(p[j].d>p[j+1].d){
				temp=p[j];
				p[j]=p[j+1];
				p[j+1]=temp;
			}
		}
	}
	for(i=0;i<num;i++){
		for(j=0;j<num-i-1;j++){
			if(p[j].m>p[j+1].m){
				temp=p[j];
				p[j]=p[j+1];
				p[j+1]=temp;
			}
		}
	}
	for(i=0;i<num;i++){
		for(j=0;j<num-i-1;j++){
			if(p[j].y>p[j+1].y){
				temp=p[j];
				p[j]=p[j+1];
				p[j+1]=temp;
			}
		}
	}
	printf("%d\n",birth);
	printf("%s\n",p[0].name);
	printf("%s\n",p[num-1].name);
	return 0;
}