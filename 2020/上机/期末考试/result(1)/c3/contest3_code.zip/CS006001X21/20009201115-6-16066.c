#include <stdio.h>
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int a,b,c;
	int t;
	int i;
	a=0;
	b=0;
	c=0;
	for(i=m;i<=n;i++)
	{
		if(i%2==0)
		{
			b++;
		}
		else
		{
			a++;
		}
		if(i%7==0&&i%3!=0)
		{
			c++;
		}
	}
	if(a<b)
	{
		t=b;
	}
	else
	{
		t=a;
	}
	if(t<c)
	{
		t=c;
	}
	printf("%d %d %d\n",a,b,c);
	printf("%d",t);
	return 0;
}
