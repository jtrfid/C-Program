#include<stdio.h>
int main()
{
	int m,n,i,j,a[3]={0};
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2==1) a[0]++;
		if(i%2==0) a[1]++;
		if(i%7==0&&i%3!=0) a[2]++;
	}
	printf("%d %d %d\n",a[0],a[1],a[2]);
	for(i=0;i<3;i++)
		for(j=0;j<2-i;j++)
		{
			if(a[j]<a[j+1])
			{
				int t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	printf("%d",a[0]);
		return 0;
}
