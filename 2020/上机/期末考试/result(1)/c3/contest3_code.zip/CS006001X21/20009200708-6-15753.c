#include<stdio.h>
int main(){
	int jiou(int a);
	int chu(int a);
	 void swap(int*x,int *y);
	int m,n,a,p;
	scanf("%d %d",&m,&n);
	a=m;
	int res[3]={0,0,0};	
	for(;a>=m&&a<=n;a++){
		if(jiou(a)==1){
			res[0]++;
		}else{
			res[1]++;
		}
	}
	a=m;
	for(;a>=m&&a<=n;a++){
		if(chu(a)==1){
			res[2]++;
		}
	}
	printf("%d %d %d\n",res[0],res[1],res[2]);
	int i,j;
	for(i=0;i<3;i++){
		for(j=0;j<3-i;j++){
			if(res[j]<res[j+1]){
				swap(&res[j],&res[j+1]);
			}
		}
	}
	printf("%d",res[1]);
	
	
	
	
	
}
//1������0ż�� 
int jiou(int a){
	int ret=0;
	if(a%2!=0){
		ret=1;
	}
	return(ret);
}
//1 ���� 
int chu(int a){
	int ret=0;
	if(a%7==0){
		if(a%3!=0){
			ret=1;
		}
	}
	return(ret);
}

 void swap(int*x,int *y){
	int z;
	z=*x;
	*x=*y;
	*y=z;
}






