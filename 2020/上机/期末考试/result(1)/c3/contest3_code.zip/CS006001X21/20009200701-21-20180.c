#include<stdio.h>
#include<string.h>
#include<math.h>


int main(){
	typedef struct peo{
	char name[10];
	int year,mon,day;
	int age;
	};
	int n,i,j,q,t,num=0;
	scanf("%d",&n);
	struct peo ag[n+3];
	for(i=0;i<n;i++){
		ag[i].age=0;
	}
	for(i=0;i<n;i++){
		scanf("%s %d/%d/%d",&ag[i].name,&ag[i].year,&ag[i].mon,&ag[i].day);
	}
	for(i=0;i<n;i++){
		if(ag[i].year>2021){
			ag[i].age=-1;
		}
		else if(ag[i].year==2021&&ag[i].day>9){
			ag[i].age=-1;
		}
		else if(ag[i].year<1821){
			ag[i].age=-1;
		}
		else if(ag[i].year=1821&&ag[i].mon==1&&ag[i].day<9){
			ag[i].age=-1;
		}
	}
	for(i=0;i<n;i++){
		if(ag[i].age!=-1){
			num++;
		}
	}
	printf("%d\n",num);
	for(j=0;j<n;j++){
				if(ag[j].age==-1) continue;
				if(ag[0].year<ag[j].year){
					ag[n+3]=ag[0];
					ag[0]=ag[j];
					ag[j]=ag[n+3];
				}
				else if(ag[0].year==ag[j].year){
					if(ag[0].mon<ag[j].mon){
						ag[n+3]=ag[0];
						ag[0]=ag[j];
						ag[j]=ag[n+3];
					}
				}
			}
	if(num!=0) {
		printf("%s\n",ag[0].name);
	}
	for(j=0;j<n;j++){
				if(ag[j].age==-1) continue;
				if(ag[0].year>ag[j].year){
					ag[n+3]=ag[0];
					ag[0]=ag[j];
					ag[j]=ag[n+3];
				}
				else if(ag[0].year==ag[j].year){
					if(ag[0].mon>ag[j].mon){
						ag[n+3]=ag[0];
						ag[0]=ag[j];
						ag[j]=ag[n+3];
					}
				}
			}
	if(num!=0) printf("%s",ag[0].name);
	return 0;
}
