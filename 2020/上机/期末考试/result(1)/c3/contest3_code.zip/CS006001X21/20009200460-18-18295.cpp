#include<stdio.h>
#include<math.h>
int main()
{
	int m,i=0,j=0,k,a[50]={0},s[50]={0},f=0,t;
	float b[100]={0},p=0;
	scanf("%d",&m);
	for(i=0;i<m*3;i+=3){
		scanf("%f %f %f",&b[i],&b[i+1],&b[i+2]);
		if(b[i]+b[i+1]>b[i+2]&&b[i+1]+b[i+2]>b[i]&&b[i]+b[i+2]>b[i+1]){
			f=1;
			a[j]=i/3;
			p=(b[i]+b[i+1]+b[i+2])/2;
			s[j]=floor(p*(p-b[i])*(p-b[i+1])*(p-b[i+2]));
			j++;
		}
	}
	if(f==0){
		printf("no");
	}
	else{
		for(i=0;i<j;i++){
			for(k=j-1;k>i;k--){
				if(s[k]>s[k-1]){
					t=s[k];s[k]=s[k-1];s[k-1]=t;
					t=a[k];a[k]=a[k-1];a[k-1]=t;
				}
			}
		}
		for(i=0;i<j;i++){
		    printf("%d %d\n",s[i],a[i]);
	    }
	}
	return 0;
}
