#include<stdio.h>
typedef struct{
	char name[20],c1[10],c2[10];
	int n,y,r;
}person;
int main()
{
	person man[100];
	int n,i;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%s%d%c%d%c%d",&man[i].name,&man[i].n,&man[i].c1,&man[i].y,&man[i].c2,&man[i].r);
	}
	
}
