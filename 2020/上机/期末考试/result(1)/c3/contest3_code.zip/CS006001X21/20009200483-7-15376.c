#include <stdio.h>
  int main(){
  	int a,num[10],i,j,b;
	scanf("%d",&a);
	for(i=0;i<10;i++) 
		scanf("%d",&num[i]);
  	for(i=0;i<10;i++){
  		for(j=i+1;j<10;j++){
  			if(num[i]>num[j]){
  				b=num[i];
  				num[i]=num[j];
  				num[j]=b;
  			}
  			
  	}}
  	for(i=0;i<10;i++){
	  if(num[i]==a) continue;
	  printf("%d ",num[i]);
	  }
  return 0;}

