#include<stdio.h>
int main()
{
	int m,a[30][3],b,c,i,j,count;
	scanf("%d\n",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(count=0,i=0;i<m;i++)
	{
		if(a[i][0]+a[i][1]>a[i][2]&&a[i][0]+a[i][2]>a[i][1])
		{
			if(a[i][1]+a[i][2]>a[i][0])
			{
				count++;
			}      
		}
	}
	if(count==0)
	{
		printf("no");
	}
	return 0;
}
