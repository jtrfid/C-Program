#include<stdio.h>
#include<string.h>

int main()
{
	int n,i,j=0;
	int b[3]={0};
	int y[3]={0},o[3]={2021,1,9};
	char name[12]={'\0'},old[12]={'\0'},yo[12]={'\0'};
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s",name);
		scanf("%d/%d/%d",&b[0],&b[1],&b[2]);
		if((b[0]>2021)||(b[0]==2021&&b[1]>1)||(b[0]==2021&&b[1]==1&&b[2]>9)){
			continue;
		}else if((b[0]<1821)||(b[0]=1821&&b[1]==1&&b[2]<9)){
			continue;
		}else{
			j++;
			if((b[0]<o[0])||(b[0]==o[0]&&b[1]==o[1]&&b[2]<o[2])){
				strcpy(old,name);
				o[0]=b[0];o[1]=b[1];o[2]=b[2];
			}
			if((b[0]>y[0])||(b[0]==y[0]&&b[1]>y[1])||(b[0]==y[0]&&b[1]==y[1]&&b[2]<y[2])){
				strcpy(yo,name);
				y[0]=b[0];y[1]=b[1];y[2]=b[2];
			}
		}
	}
	if(j){
	printf("%d\n",j);
	
	printf("%s\n",yo);
	printf("%s\n",old);
	}else{
		printf("%d\n",j);
	}
	return 0;
}
