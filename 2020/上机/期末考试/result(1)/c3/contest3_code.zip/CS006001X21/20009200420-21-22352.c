#include <stdio.h>
int main()
{   int a;
     a=0;
	printf("%d",a);
	return 0;
	
}
