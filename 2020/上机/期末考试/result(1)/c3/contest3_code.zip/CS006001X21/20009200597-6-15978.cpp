#include<stdio.h>
int main()
{
	int m,n,count_odd=0,count_even=0,Count=0,i;
	int a[m-n+1];
	scanf("%d %d",&m,&n);
	for(i=0;i<=m-n;i++)
	{
		a[i]=m+i;
	}
	for(i=0;i<=m-n;i++)
	{
		if(a[i]%2!=0)
		count_odd++;
		if(a[i]%2==0)
		count_even++;
		if(a[i]%3!=0&&a[i]%7==0)
		Count++;
	}
	int b[3]={count_odd,count_even,Count};
	int max=b[0];
	for(i=0;i<3;i++)
	{
		if (b[i+1]>b[i])max=b[i+1];
	}
	printf("%d %d %d\n%d",&count_odd,&count_even,&Count);
	return 0;
}
