#include<iostream>
#include<cstdio>