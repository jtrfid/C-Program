#include <stdio.h>

int main(){
	int a,b[10];
	int t,j;
	scanf("%d",&a);
	int i;
	int d[10];
	for(i=0;i<10;i++){
		scanf("%d",&b[i]);
	}
	for(i=0;i<10;i++){
		if(b[i]==a) b[i]=0;
	}
	for(i=0;i<9;i++){
		for(j=0;j<9-i;j++){
			if(b[j]>b[j+1]){
				t=b[j];
				b[j]=b[j+1];
				b[j+1]=t;
			}
		}
	}
	for(i=0;i<10;i++){
		if(b[i]!=0){
			printf("%d ",b[i]);
		}
	}
	return 0;
}
