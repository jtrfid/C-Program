#include<stdio.h>
int main(){
	int a;
	scanf("%d",&a);
	const int c=a;
	int b[10];
	int i;
	for(i=0;i<10;i++){
		scanf("%d",&b[i]);
	}
			for(i=0;i<10;i++){
				printf("%d ",b[i]);
			}
			printf("\n");
	int j,t;
	for(i=0;i<10;i++){
		for(j=0;j<10-i;j++){
			if(b[j]>b[j+1]){
			t=b[j];
			b[j]=b[j+1];
			b[j+1]=t;
		}
}
}
			for(i=0;i<10;i++){
				printf("%d ",b[i]);
			}
			printf("\n");
	for(i=0;i<11;){
		
		if(b[i]!=c){
			printf("%d ",b[i]);
		}
		i=i+1;
	
	}
}
