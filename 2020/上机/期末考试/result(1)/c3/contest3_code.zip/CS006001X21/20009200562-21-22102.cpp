#include<stdio.h>
#include<string.h>
int main()
{
	int a[10] = {0},i = 0,j = 0,k = 0,n = 0,m = 0,t = 0,flag = 0,birth1[100000] = {0},q = 0,r = 0,count = 0,birth0 = 0,c = 0,d = 0,max = 0,min = 0;
	char name[10000][10],birth[10000][10];
	scanf("%d",&n);
	for(i = 0;i < n;i++)
	{
		scanf("%s%s",name[i],birth[i]);
	}
	birth0 = 2021 * 365 + 30 + 5;
	for(i = 0;i < n;i++)
	
	{
		c = 0;
		for(j = 0;j < 4;j++)
		{
			a[j] = birth[i][j] - '0';
			m = m * 10 + a[j];
		}
		
		for(j = 5;j < 6;j++)
		{
			a[j] = birth[i][j] - '0';
			q = q * 10 + a[j];
		}
		for(j = 7;j < 8;j++)
		{
			a[j] = birth[i][j] - '0';
			r = r * 10 + a[j];
		}
		c = m * 365 + q * 30 + r;
		if(c - birth0 <= 200 * 365&&c - birth0 >= -200 * 365 )
		{
			birth1[d] = c;
			count++;
			d++;
		}
	}
	for(i = 1;i < d;i++)
	{
		if(birth1[i] > birth1[max])max = i;
		if(birth1[i] < birth1[min])min = i;
	}
    if(count == 0)
    {
    	printf("0");
    }
    else if(count == 1)
    {
    	printf("1\n");
    	printf("%s%s",name[i],birth[i]);
    }
    else if(count > 1)
    {
    	printf("%d\n",count);
    	printf("%s%s\n",name[max],birth[max]);
    	printf("%s%s",name[min],birth[min]);
    }
	
	
	
	return 0;
}
