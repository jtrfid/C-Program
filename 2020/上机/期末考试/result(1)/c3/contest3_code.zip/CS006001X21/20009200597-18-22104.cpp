#include<stdio.h>
#include<math.h>
int main()
{
	int m,i,j,p;
	scanf("%d\n",&m);
	int a[m][3];
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		scanf("%d",&a[i][j]);
	}
	int sum=0;
	for(i=0;i<m;i++)
	{
		int sum=0;
		p=(a[i][1]+a[i][2]+a[i][3])/2;
		if(a[i][1]+a[i][2]>a[i][3]&&a[i][2]+a[i][3]>a[i][1]&&a[i][1]+a[i][3]>a[i][2])
		{p=fabs((p-a[i][1])*(p-a[i][2])*(p-a[i][3])*p);
		printf("%d %d",p,i);
		sum=1;
		}
	}
	if(sum=0)printf("no");
	return 0;
}
