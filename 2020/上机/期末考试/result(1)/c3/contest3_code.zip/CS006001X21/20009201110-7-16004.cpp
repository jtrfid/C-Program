#include<stdio.h>
int main(){
	int a[20],b,i,j,m=0;
	scanf("%d",&b);
	for(i=1;i<=10;i++){
		scanf("%d",&a[i]);
		if(a[i]==b) a[i]=2000;
	}
	for(i=1;i<=10;i++){
		for(j=1;j<=10;j++){
			if(a[j]>a[j+1]){
				m=a[j];
				a[j]=a[j+1];
				a[j+1]=m;
				//m=0;
			}
		}
	}
	for(i=1;i<=10;i++){
		if(a[i]>1111) continue;
		else printf("%d ",a[i]);
	}
	return 0;
}
