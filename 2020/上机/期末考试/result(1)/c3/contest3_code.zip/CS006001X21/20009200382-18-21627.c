#include <stdio.h>

int main(){
	int m,count=0;
	scanf("%d",&m);
	int i,j,p;
	int a[m][3];
	int n[100];
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++){
			p=(a[i][0]+a[i][1]+a[i][2])/2;
			if((a[i][0]+a[i][1])>a[i][2]&&(a[i][0]+a[i][2])>a[i][1]&&(a[i][1]+a[i][2]>a[i][0])){
				n[i]=p*(p-a[i][0])*(p-a[i][1])*(p-a[i][2]);
				count++;
			}
			else n[i]=0;
	}
	int t;
	if(count==0) printf("no");
	if(count!=0){
		for(i=0;i<m-1;i++){
			for(j=0;j<m-1-i;j++){
				if(n[j]<n[j+1]){
					t=n[j];
					n[j]=n[j+1];
					n[j+1]=t;
				}
			}
		}
		for(i=0;i<m;i++){
			printf("%d %d\n",n[i],i);
		}
	}
	return 0;
}
