#include<iostream>
#include<cstdio>

using namespace std;

int main()
{
	int l, r;
	int cnt1, cnt2, cnt3;
	cnt1=cnt2=cnt3=0;
	scanf("%d%d", &l, &r);
	for(int i=l; i<=r; i++)
	{
		if(i%2)	cnt1++;
		else	cnt2++;
		if(i%3 && i%7==0) cnt3++;
	}
	printf("%d %d %d\n", cnt1, cnt2, cnt3);
	int zd=(cnt1>cnt2? cnt1:cnt2);
	zd=(zd>cnt3? zd:cnt3);
	printf("%d", zd);
	return 0;
}