#include<stdio.h>
void SXBPX(int n,int a[],int b[])
{
	int i,t,k,j=0;
	for(i=0;i<10;i++)
	{
		if(a[i]!=n)
		{
			b[j]=a[i];
			j++;
		}
	}
	for(i=0;i<j;i++)
	{
		for(k=0;k<j-i-1;k++)
		{
			if(b[k]>b[k+1])
			{
				t=b[k];
				b[k]=b[k+1];
				b[k+1]=t;
			}
		}
	}
	for(i=0;i<j;i++)
	{
		printf("%d ",b[i]);
	}
}
int main(){
	int n,i;
	int a[10],b[10]={0};
	scanf("%d",&n);
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}
	SXBPX(n,a,b);
	return 0;
}
