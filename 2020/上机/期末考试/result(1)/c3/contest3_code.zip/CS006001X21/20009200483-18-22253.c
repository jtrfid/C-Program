#include <stdio.h>
  int main(){
  	 int m,num[100][3],i,j,max,b=0,c,d,s[100],hang[100];
  	 float p;
	 scanf("%d",&m);
 	 for(i=0;i<m;i++){
  	 	for(j=0;j<3;j++){
  		scanf("%d",&num[i][j]);
  			}}
  	 int tag=0;
  	 for(i=0;i<m;i++){
  	 	max=num[i][0];
  	 	if(max<num[i][1]) {max=num[i][1];}
  	 		
  	 	if(max<num[i][2]) {max=num[i][2];}
  	 		
  	 	if(num[i][1]+num[i][2]>max&&num[i][1]+num[i][0]>max&&num[i][2]+num[i][0]>max){
  	 		tag=1;
  	 		p=(num[i][0]+num[i][1]+num[i][2])/2.0;
  	 		s[b]=(p*(p-num[i][0])*(p-num[i][1])*(p-num[i][2]))/1;
  	 		hang[b]=i;
  	 		b++;
  	 	}}
	 	for(i=0;i<b;i++){
	 		for(j=i+1;j<b;j++){
	 			if(s[i]<s[j]){
	 				c=s[i];
	 				s[i]=s[j];
	 				s[j]=c;
					d=hang[i];
	 				hang[i]=hang[j];
	 				hang[j]=d;
	 			}
	 			if(s[i]==s[j]){
	 				if(hang[i]>hang[j]){	
	 				c=s[i];
	 				s[i]=s[j];
	 				s[j]=c;
					d=hang[i];
	 				hang[i]=hang[j];
	 				hang[j]=d;}
	 			}
	 		}
	 	}
		 if(tag==1){
		 for(i=0;i<b;i++){
		printf("%d %d\n",s[i],hang[i]);
  	 	}
		 }		 
	
	  if(tag==0){
	  printf("no");
	  }
  return 0;}




