#include<stdio.h>
int main()
{
	int m,n;
	int a[m][3];
	int i,j,max,s1;
	float p,s;
	scanf("%d",&n);
	for(i=0;i<=2;i++)
	{
		for(j=0;j<m;j++)
		scanf("%d",&a[m][3]);
		max=a[j][0];
		if(max<a[j][1])
		max=a[j][1];
		if(max<a[j][2])
		max=a[j][2];
		if(a[j][0]+a[j][1]+a[j][2]>2*max)
		{
			p=(a[j][0]+a[j][1]+a[j][2])/2;
			s=p*(p-a[j][0])*(p-a[j][1])*(p-a[j][2]);
			s1=(int)(s+1);
			printf("%d %d",s1,j);
		}	
	}
	return 0;
}
