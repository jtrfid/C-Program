#include <stdio.h>
int main()
{
	int m;
	int n[m][3];
	int a,b,c;
	int i,j;
	int p,q,s;
	int t=0;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&n[i][j]);
		}	
	}
	for(i=0;i<m;i++)
	{
		a=n[i][0];
		b=n[i][1];
		c=n[i][2];
		if(a+b>c&&a+c>b&&b+c>a)
		{
			p=(a+b+c)/2;
			q=p*(p-a)*(p-b)*(p-c);
			s=p/1;
			printf("%d %d\n",s,i);
			t++;
		}
	}
	if(t==0)
	{
		printf("no");
	}
	return 0;
}
