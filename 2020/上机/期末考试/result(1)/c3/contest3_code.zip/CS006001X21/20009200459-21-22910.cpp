#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	char name[n][10];
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<10;j++){
			name[i][j]='\0';
		}
	}
	int nian[n],yue[n],ri[n];
	for(i=0;i<n;i++){
		if(i<n-1){
		scanf("%s %d/%d/%d\n",&name[i],&nian[i],&yue[i],&ri[i]);
	}else{scanf("%s %d/%d/%d",&name[i],&nian[i],&yue[i],&ri[i]);
	}
	}
	int youxiao=0;
	int nianzhang;
	int nianz=2021,yuez=1,riz=9;
	int nianqing;
	int nianq=2021,yueq=1,riq=9;
	for(i=0;i<n;i++){
			youxiao=youxiao+1;
			if(nian[i]<nianz){
				nianz=nian[i];
				yuez=yue[i];
				riz=ri[i];
				nianzhang=i;
			}else if(nian[i]==nianz){
				if(yue[i]<yuez){
					yuez=yue[i];
					riz=ri[i];
					nianzhang=i;
				}else if(yue[i]==yuez){
					if(ri[i]<riz){
						riz=ri[i];
						nianzhang=i;
					}
				}
			}
			if(nian[i]>nianq){
				nianq=nian[i];
				yueq=yue[i];
				riq=ri[i];
				nianqing=i;
			}else if(nian[i]==nianq){
				if(yue[i]>yueq){
					yueq=yue[i];
					riq=ri[i];
					nianqing=i;
				}else if(yue[i]==yueq){
					if(ri[i]<riq){
						riq=ri[i];
						nianqing=i;
					}
				}
			}
		
	}
	printf("%d\n%s\n%s\n",youxiao,name[nianzhang],name[nianqing]);
	return 0;
	
	
}
