#include<stdio.h>
int main()
{
    int i,j;
	int n,m;
	double p;
	double a[50][50],s[50],b[50];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=1;j<=3;j++)
		{
			scanf("%lf",&a[i][j]);
		}
	}
	for(i=0,j=1;i<n;i++)
	{
		if(a[i][1]+a[i][2]>a[i][3]&&a[i][1]+a[i][3]>a[i][2]&&a[i][2]+a[i][3]>a[i][1])
		{
			p=(a[i][1]+a[i][2]+a[i][3])/2;
			s[j]=p*(p-a[i][1])*(p-a[i][2])*(p-a[i][3]);
			b[j]=i;
			j++;
		}
	}
	int k,t1,t2;
	for(i=1;i<=j-1;i++)
	{
		for(k=i+1;k<=j-1;k++)
		{
			if(s[i]<s[k])
			{
				t1=s[i];
				s[i]=s[k];
				s[k]=t1;
				
				t2=b[i];
				b[i]=b[k];
				b[k]=t2;
			}
		}
	}
	for(i=1;i<=j-1;i++)
	{
		printf("%.f %.f\n",s[i],b[i]);
	}
	
}
