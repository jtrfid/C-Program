#include<stdio.h>
int main()
{
	int m,n,i,max;
	int cnt1=0,cnt2=0,cnt3=0;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2==1)
		cnt1++;
		else
		cnt2++;
		if(i%7==0&&i%3!=0)
		cnt3++;
	}
	printf("%d %d %d",cnt1,cnt2,cnt3);
	printf("\n");
	max=cnt1;
	if(max<cnt2)
	max=cnt2;
	if(max<cnt3)
	max=cnt3;
	printf("%d",max);
	return 0;
}
