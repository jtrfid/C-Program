#include<stdio.h>
int main()
{
	int m , i , j ,min , mid ,max ,sum=0 ,t , flag;
	double p ; 
	scanf("%d",&m);
	int a[m][3] , pp[m];
	int s[m];
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
		min = a[i][0];
		max = a[i][1];
		for(j=0;j<3;j++)
		{
			if(a[i][j]<min)
			{
				min = a[i][j];
			}
			if(a[i][j]>max)
			{
				max = a[i][j];
			}
		}
		mid = a[i][0]+a[i][1]+a[i][2] - min - max ;
		p = (a[i][0]+a[i][1]+a[i][2])/2.0;
		if(min+mid>max)
		{
			
			s[sum] = p*(p-min)*(p-mid)*(p-max);
			if(s[sum])
			pp[sum] = i;
			sum++;
		}
	}
	if(sum==0)
	{
		printf("no");
		return 0 ;
	}
	for(i=1;i<sum;i++)
{
	flag = 0;
	for(j=0;j<sum-i;j++)
	{
		if(s[j]<s[j+1])
		{
			t=s[j];
			s[j]=s[j+1];
			s[j+1]=t;	
			t=pp[j];
			pp[j]=pp[j+1];
			pp[j+1]=t;
			flag = 1;
		}
	}
	if(flag == 0)
	{
		break;
	}
}
for(i=0;i<sum;i++)
{
	printf("%d %d\n",s[i],pp[i]);
}
	return 0 ;
}
