#include<stdio.h>
int main()
{
	int a,b[10],i,c[10],d[10],j,u,flag,t,i2,flag2=0;
	scanf("%d",&a);
	for(i=0;i<=9;i++)
	{
		scanf("%d",&b[i]);
	}
	for(u=0;u<10;u++)
    {
    	flag=0;
    	for(j=0;j<9-u;j++)
    	{
    		if(b[j]>b[j+1])
    		{
    			t=b[j];b[j]=b[j+1];b[j+1]=t;
    			flag=1;
    		}
    	}
    	if(flag==0)break;
    }
	for(i=0,i2=0;i<=9;i++,i2++)
	{
		if(b[i]!=a)
		{
			c[i2]=b[i];
		}
		else
		{
			i2=i2-1;
			flag2=1;
		}
	}
    
    //printf("%d %d %d %d %d %d %d %d %d %d",c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]);
    if(flag2==1)
    {
    	for(i=0;i<9;i++)
        {
    	    printf("%d ",c[i]);
        }
    }
    if(flag2==0)
    {
    	for(i=0;i<=9;i++)
        {
    	    printf("%d ",c[i]);
        }
    }
	return 0;
}
