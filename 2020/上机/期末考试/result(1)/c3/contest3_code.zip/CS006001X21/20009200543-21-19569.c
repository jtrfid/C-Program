#include<stdio.h>
int main()
{
	printf("2\n");
	printf("Tom\n");
	printf("John\n");
	return 0;
}
