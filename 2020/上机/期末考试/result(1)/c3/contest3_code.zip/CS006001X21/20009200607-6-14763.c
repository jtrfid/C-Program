#include <stdio.h>
int main(){
	int m,n;
	scanf("%d %d",&m,&n);
	int a[3];
	int i,count1=0,count2=0,count3=0;
	for(i=m;i<=n;i++){
		if(i%2!=0)
		count1++;
		if(i%2==0)
		count2++;
		if(i%7==0&&i%3!=0)
		count3++;
	}
	a[0]=count1;
	a[1]=count2;
	a[2]=count3;
	int max;
	max=(a[0]>a[1])?a[0]:a[1];
	max=(max>a[2])?max:a[2];
	printf("%d %d %d\n",a[0],a[1],a[2]);
	printf("%d",max);
	return 0;
}
