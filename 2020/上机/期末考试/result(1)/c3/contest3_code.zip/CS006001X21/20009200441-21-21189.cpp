#include<stdio.h>
int main()
{
	int n  , i , j ,sum=0 , young , old ;
	scanf("%d",&n);
	char name[n][10];
	int y[n] , m[n] ,d[n] , p[n];
	for(i=0;i<n;i++)
	{
		p[i] =1 ;
		scanf("%s",name[i]);
		scanf("%d/%d/%d",&y[i],&m[i],&d[i]);
		if(y[i]>2021)
		{
			p[i]=0;
		}
		if(y[i]==2021 && m[i]>1)
		{
			p[i]=0;
		}
		if(y[i]==2021 && m[i]==1 && d[i]>9)
		{
			p[i]=0;
		}
		if(2021-y[i]>200)
		{
			p[i]=0;
		}
		if(2021-y[i]==200 && 1-m[i]>0)
		{
			p[i]=0;
		}
		if(2021-y[i]==200 && 1-m[i]== 0 && 9-d[i]>0 )
		{
			p[i]=0;
		}
		if(p[i]==1)
		{
			sum++;
		}
	}
	if(sum==0)
	{
		printf("0\n");
		return 0 ;
	}
	else
	{
	for(i=0;i<n;i++)
	{
		if(p[i]==1)
		{
			old= i;
			young=i;
			break;
		}
	}
	for(i=0;i<n;i++)
	{
		if(y[i]<y[old] && p[i]==1)
		{
			old=i;
		}
		if(y[i]==y[old]&& m[i]<m[old] && p[i]==1)
		{
			old=i;
		}
		if(y[i]==y[old]&& m[i]==m[old] && d[i]<d[old] && p[i]==1)
		{
			old=i;
		}
		if(y[i]>y[young] && p[i]==1)
		{
			young=i;
		}
		if(y[i]==y[young]&& m[i]>m[young] && p[i]==1)
		{
			young=i;
		}
		if(y[i]==y[young]&& m[i]==m[young] && d[i]>d[young] && p[i]==1)
		{
			young=i;
		}
	}
	printf("%d\n%s\n%s\n",sum,name[old],name[young]);
	}
	return 0 ;
}
