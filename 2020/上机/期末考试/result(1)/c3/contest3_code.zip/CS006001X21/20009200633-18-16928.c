#include <stdio.h>
#include <math.h>
int area(int a, int b, int c);
int san(int a, int b,int c);
int main(){
	int m;
	scanf("%d", &m);
	int i, j, a[m][3];
	for(i = 0;i < m;i++){
		for(j = 0;j < 3;j++){
			scanf("%d", &a[i][j]);
		}
	}
	int flag = 0, b[m], c[m], k = 0;
	for(i = 0;i < m;i++){
		if(san(a[i][0], a[i][1], a[i][2])){
			flag = 1;
			b[k] = area(a[i][0], a[i][1], a[i][2]);
			c[k] = i;
			k++;
		}
	}
	int t1, t2;
	if(flag == 0) printf("no");
	else {
		for(i = 0;i < k;i++){
			for(j = 0;j < k - 1 - i;j++){
				if(b[j] < b[j + 1]||(b[j] == b[j + 1]&&(c[j] > c[j + 1]))){
					t1 = b[j + 1];
					b[j + 1] = b[j];
					b[j] = t1;
					t2 = c[j + 1];
					c[j + 1] = c[j];
					c[j] = t2;
				}
			}
		}
		for(i = 0;i < k;i++){
			printf("%d %d\n", b[i], c[i]);
		}
	}
	return 0;
}
int area(int a, int b, int c){
	double p =1.0 * (a + b + c) / 2;
	double s;
	s = p * (p - a) * (p - b) * (p - c);
	return s;
}
int san(int a, int b,int c){
	if((a + b) > c&&abs(a - b) < c) return 1;
	else return 0;
}
