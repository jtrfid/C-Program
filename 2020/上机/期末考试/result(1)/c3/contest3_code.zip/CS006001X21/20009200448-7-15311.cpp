#include<stdio.h>
void bubblesort(int a[],int n)//���� 
{int i,k;
int temp=0;
for(k=n-1;k>0;k--)
	{for(i=0;i<k;i++)
		{if(a[i]>a[i+1])
			{temp=a[i];
			a[i]=a[i+1];
			a[i+1]=temp;
			}
		} 
	}

}
int main()
{int org[10];
int dst[10];
int k=0;
int i;
int n;
scanf("%d",&n);
for(i=0;i<10;i++)
	{scanf("%d",&org[i]);
	if(org[i]!=n)
		{dst[k++]=org[i];
		}
	}
bubblesort(dst,k);
for(i=0;i<k;i++)
	{printf("%d ",dst[i]);
	}
return 0;

}
