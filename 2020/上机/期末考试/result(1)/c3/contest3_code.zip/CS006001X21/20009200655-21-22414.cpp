#include<stdio.h>
#include<stdlib.h>
typedef struct
{
	char name[20];
	int year;
	int month;
	int day;
}People;
int main()
{
	int m;
	scanf("%d",&m);
	int i,k=0;
	People b[100];
	People a[100];
	char sts[20];
	for(i=0;i<m;i++)
    {
     gets(b[i].name);
    	scanf("%d/%d/%d",&b[i].year,&b[i].month,&b[i].day);
    }
    for(i=0;i<m;i++)
    {
    	if(b[i].year>1821&&b[i].year<2021)
    	{
    		a[k++]=b[i];
    	}
    	else if(b[i].year==1821)
    	{
    		if(b[i].month>1)
    		{
    			a[k++]=b[i];
    		}
    		else if(b[i].month==1)
    		{
    			if(b[i].day>9)
    			a[k++]=b[i];
    		}
    	}
    	else if(b[i].year==2021)
    	{
    		if(b[i].month==1&&b[i].day<9)
    		{
    			a[k++]=b[i];
    		}
    	}
    }
    People max=a[0],min=a[0];
    for(i=1;i<m;i++)
    {
    	if(max.year>a[i].year)
    	{
    	     max=a[i];
    	}
    	else if(max.year==a[i].year)
    	{
    		if(max.month>a[i].month)
    		{
    			max=a[i];
    		}
    		else if(max.month=a[i].month)
    		{
    			if(max.day>a[i].day)
    			{
    				max=a[i];
    			}
    		}
    	}
    	if(min.year<a[i].year)
    	{
    		min=a[i];
    	}
    	else if(min.year==a[i].year)
    	{
    		if(min.month<a[i].month)
    		{
    			min=a[i];
    		}
    		else if(min.month==a[i].month)
    		{
    			if(min.day<a[i].day)
    			{
    				min=a[i];
    			}
    		}
    	}
    }
    printf("%d",k);
    printf("%s\n%s",max.name,min.name);
    return 0;
}
