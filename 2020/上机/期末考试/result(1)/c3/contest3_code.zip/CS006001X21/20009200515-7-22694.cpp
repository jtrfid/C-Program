#include<stdio.h>
int main(){
	int n,b,c,d,e,f,g,h,i,j,k,x,y;
	scanf("%d\n",&n);
	scanf("%d %d %d %d %d %d %d %d %d %d",&b,&c,&d,&e,&f,&g,&h,&i,&j,&k);
	int a[10];
	int m=1;
	a[1]=b;
	a[2]=c;
	a[3]=d;
	a[4]=e;
	a[5]=f;
	a[6]=g;
	a[7]=h;
	a[8]=i;
	a[9]=j;
	a[10]=k;
	for(m=1;m<=10;m++)
	printf("%d %d %d %d %d %d %d %d %d %d",a[10],a[9],a[8],a[7],a[6],a[5],a[4],a[3],a[2],a[1]);
	return 0;
}
