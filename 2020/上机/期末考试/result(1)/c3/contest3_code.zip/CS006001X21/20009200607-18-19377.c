#include <stdio.h>
int main(){
	int i,j,a[30][3],m;
	scanf("%d",&m);
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
		scanf("%d",&a[i][j]);
		}
	}
	int b[30],d[30],x=0;
	int C;
	float c1,s;
	for(i=0;i<m;i++){
		if(a[i][0]+a[i][1]>a[i][2]&&a[i][2]+a[i][1]>a[i][0]&&a[i][0]+a[i][2]>a[i][1])
		{
			C=a[i][0]+a[i][1]+a[i][2];
			c1=C/2.0;
			s=c1*(c1-a[i][1])*(c1-a[i][2])*(c1-a[i][0]);
			b[x]=s;
			d[x]=i;
			x++;
		}
	}
	int z1,z2;
	if(x!=0){
		for(i=0;i<x;i++){
		for(j=0;j<x-i-1;j++){
			if(b[i]<b[i+1]){
				z1=b[i];
				z2=d[i];
				b[i]=b[i+1];
				d[i]=d[i+1];
				b[i+1]=z1;
				d[i+1]=z2;
			}
			else if(b[i]==b[i+1])
			{
				for(i=0;i<x;i++){
		        for(j=0;j<x-i-1;j++){
		        	if(d[i]>d[i+1]){
						z1=b[i];
				z2=d[i];
				b[i]=b[i+1];
				d[i]=d[i+1];
				b[i+1]=z1;
				d[i+1]=z2;
				}

		        }

				}
			}
		}
		}
		for(i=0;i<x;i++){
			printf("%d %d\n",b[i],d[i]);
		}
	}
	else printf("no");
	return 0;
}
