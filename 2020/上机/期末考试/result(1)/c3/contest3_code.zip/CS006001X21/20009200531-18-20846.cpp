#include<stdio.h>
int mianji(int a,int b,int c)
{
	float p;
	int s;
	p=(a+b+c)*1.0/2;
	s=int(p*(p-a)*(p-b)*(p-c));
	
	return s;
}

int main()
{
	int a[30][3],s[30],m,i,t,j,k=0;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}}
	for(i=0;i<m;i++)
	{
		if(a[i][1]>a[i][2])
		{t=a[i][1];a[i][1]=a[i][2];a[i][2]=t;
		}
		if(a[i][2]>a[i][3])
		{t=a[i][2];a[i][2]=a[i][3];a[i][3]=t;
		}
		if(a[i][1]>a[i][2])
		{t=a[i][1];a[i][1]=a[i][2];a[i][2]=t;
		}
		if(a[i][1]*a[i][1]+a[i][2]*a[i][2]>=a[i][3]*a[i][3])
		s[i]=a[i][1]*a[i][2]*a[i][1]*a[i][1];
		else s[i]=0;
	}
	
	
	for(i=0;i<m;i++)
	{
		if(s[i]==0)continue;
		else{
			printf("%d %d",s,i);
			printf("\n");k++;
	}
	if(k==0)printf("no");
	}
	
	
	
	
	
	return 0;
}
