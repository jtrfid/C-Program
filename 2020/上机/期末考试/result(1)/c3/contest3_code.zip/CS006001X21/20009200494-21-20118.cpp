#include<stdio.h>
int m,n;
struct man{
	char name[];
	int a1,a2,a3;
}a[20000];
int main(){
	scanf("%d",&m);
	n=m;
	for(int i=0;i<m;i++)
	{
		scanf("%s %d/%d/%d",a[i].name,a[i].a1,a[i].a2,a[i].a3);
	}
	for(int i=0;i<m;i++)
	{
		if((a[i].a1<1821)||(a[i].a1==1821&&a[i].a2==1&&a[i].a3<9)||(a[i].a1>2021)||(a[i].a1==2021&&a[i].a2>=2)||(a[i].a1==2021&&a[i].a2==2&&a[i].a3>9))
		{
			n--;
		}
	}
	printf("%d\n",&n);
	for(int i=0;i<m;i++)
	{
		if((a[i].a1<1821)||(a[i].a1==1821&&a[i].a2==1&&a[i].a3<9)||(a[i].a1>2021)||(a[i].a1==2021&&a[i].a2>=2)||(a[i].a1==2021&&a[i].a2==2&&a[i].a3>9))continue;
		printf("%s\n",a[i].name);
	}
	
	return 0;
}
