#include<iostream>
#include<cstdio>
#include<algorithm>
#include<string>

using namespace std;

struct Man
{
	int year, month, day;
	string name;
}t[100005];
bool cmp(const Man& A, const Man& B)
{
	if(A.year==B.year)
	{
		if(A.month==B.month)
			return A.day<B.day;
		return A.month<B.month;
	}
	return A.year<B.year;
}

int main()
{
	int n, cur=0, a, b, c;
	string temp;
	scanf("%d", &n);
	for(int i=1; i<=n; i++)
	{
		cin>>temp;
		scanf("%d/%d/%d", &a, &b, &c);
		if(a>2021 || a<1821) continue;
		if(a==2021)
		{
			if(b>1) continue;
			if(b==1)
				if(c>9) continue;
		}
		t[++cur].name=temp;
		t[cur].year=a, t[cur].month=b, t[cur].day=c;
	}
	if(cur==0)
	{
		printf("0");
	}
	else
	{
		sort(t+1, t+cur+1, cmp);
		printf("%d\n", cur);
		cout<<t[1].name<<endl<<t[cur].name;
	}
}