#include<stdio.h>
#include<string.h>
#include<math.h>

int main(void)
{
	int m;
	int i,j;
	int a,b;
	double p,sign=0;
	scanf("%d",&m);
	float x[m][3];
	int s1[m];
	int s2[m];
	float t;
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
	   {
		   scanf("%f",&x[i][j]);
	   }
	   for(a=0;a<2;a++)
	   {
	   	  for(b=0;b<2-a;b++)
	   	  {
	   	  	if(x[i][b]<x[i][b+1]){
	   	  	
	   	  	t=x[i][b];
	   	  	x[i][b]=x[i][b+1];
	   	  	x[i][b+1]=t;}
	   	  }
	   }
	   if(x[i][0]<x[i][1]+x[i][2]&&x[i][1]>x[i][0]-x[i][2])
	   {
	   	p=(x[i][0]+x[i][1]+x[i][2])/2;
	   	s1[i]=(int)(p*(p-x[i][0])*(p-x[i][1])*(p-x[i][2]));
	   	s2[i]=i;
	   }
	   else{
	   s2[i]=i;
	   s1[i]=-1;
}
	}
	for(a=0;a<m-1;a++)
	   {
	   	  for(b=0;b<m-1-a;b++)
	   	  {
	   	  	if(s1[b]<s1[b+1])
	   	  	{
	   	  		t=s1[b];
	   	  		s1[b]=s1[b+1];
	   	  		s1[b+1]=t;
	   	  		t=s2[b];
	   	  		s2[b]=s2[b+1];
	   	  		s2[b+1]=t;
	   	  	}
	   	  	
	   	  }
	   }
	   
	   for(i=0;i<m;i++)
	   {
	   	if(s1[i]>0)
	   	 {
	   	 	printf("%d %d\n",s1[i],s2[i]);
	   	 }
	   }
	return 0;
}
