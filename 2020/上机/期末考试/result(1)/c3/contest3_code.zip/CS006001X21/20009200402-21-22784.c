#include<stdio.h>

typedef struct people
{
	char name[11];
	int year;
	int month;
	int day;
}People;

People a[100000];
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%s %d/%d/%d",a[i].name,&a[i].year,&a[i].month,&a[i].day);
		if(a[i].year>2021)
		{
			--i;
			--n;
		}
		else if(a[i].year==2021&&a[i].month>1)
		{
			--i;
			--n;
		}
		else if(a[i].year==2021&&a[i].month==1&&a[i].day>9)
		{
			--i,--n;
		}
		else if(a[i].year<1821)
		{
			--i,--n;
		}
		else if(a[i].year==1821&&a[i].month==1&&a[i].day<9)
		{
			--i,--n;
		}
	}
	if(n==0||n<0)
		printf("0");
	else
	{
		People max,min;
		max=min=a[0];
		for(i=0;i<n;i++)
		{
			if(a[i].year<max.year)
				max=a[i];
			else if(a[i].year==max.year&&a[i].month<max.month)
				max=a[i];
			else if(a[i].year==max.year&&a[i].month==max.month&&a[i].day<max.day)
				max=a[i];
			if(a[i].year>min.year)
				min=a[i];
			else if(a[i].year==min.year&&a[i].month>min.month)
				min=a[i];
			else if(a[i].year>min.year&&a[i].month>min.month&&a[i].day>min.day)
				min=a[i];
		}
		printf("%s %d/%d/%d\n",max.name,max.year,max.month,max.day);
		printf("%s %d/%d/%d",min.name,min.year,min.month,min.day);
	}
	return 0;
}











