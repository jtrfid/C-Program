#include <stdio.h>
int main()//first 
{
	int a,b,jishu,oushu,zhengshu,i,o,m,max;
	double t;
	oushu=0;
	jishu=0;
	zhengshu=0;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{
		t=i;
		if((t/2-i/2)==0)
		oushu++;
		if((t+1)/2-(i+1)/2==0)
		jishu++;
		if(t/7-i/7==0&&t/3-i/3!=0)
		zhengshu++;
		
	}
	o=jishu;
	m=oushu;
	if(o>m)
	max=o;
	else
	max=m;
	printf("%d %d %d",jishu,oushu,zhengshu);
	printf("\n");
	printf("%d",max);
	
	
}
