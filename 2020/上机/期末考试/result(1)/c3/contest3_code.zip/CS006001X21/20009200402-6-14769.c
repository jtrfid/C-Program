#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	int i,j=0,o=0,k=0,max;
	for(i=n;i<=m;i++)
	{
		if(i%2==0)
		{
			o++;
		}
		else
		{
			j++;
		}
		if(i%7==0&&i%3!=0)
		{
			k++;
		}
	}
	max=j;
	if(o>max)
		max=o;
	if(k>max)
		max=k;
	printf("%d %d %d\n%d",j,o,k,max);
	return 0;
}
