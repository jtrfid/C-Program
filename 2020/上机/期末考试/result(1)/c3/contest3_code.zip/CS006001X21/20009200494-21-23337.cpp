#include<stdio.h>
int m,n;
char name[12000][16];
	int a1[12000],a2[12000],a3[12000];
int main(){
	scanf("%d",&m);
	for(int i=0;i<m;i++)
	{
		scanf("%s %d/%d/%d",name[16][i],a1[i],a2[i],a3[i]);
	}
	//if(scanf();)
	printf("0");
	
	return 0;
}
