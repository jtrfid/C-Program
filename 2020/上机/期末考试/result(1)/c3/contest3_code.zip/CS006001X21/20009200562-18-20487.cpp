#include<stdio.h>
#include<string.h>
#include<math.h>
int qu(float n){
	int i,m = 0;
	while(n >= 1)
	{
		if(n >= 1)
		{
			m++;
			n = n - 1;
		}
	}
	return m;
} 
int main()
{
	int i = 0,j = 0,k = 0,n = 0,m = 0,t = 0,flag = 0,a[31][3],loc[31] = {0},s2[31] = {0};
	float p = 0,s1[31] = {0};
	scanf("%d",&m);
	for(i = 0;i < m;i++)
	{
		for(j = 0;j < 3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i = 0;i < m;i++)
	{
			p = 0;
			if(a[i][0] + a[i][1] > a[i][2]&&a[i][1] + a[i][2] > a[i][0]&&a[i][0] + a[i][2] > a[i][1]&&a[i][0] != 0&&a[i][1] != 0&&a[i][2] != 0)
			{
				p = (a[i][0] + a[i][1] + a[i][2]) / 2.0;
				s2[k] = ((p * (p - a[i][0]) * (p - a[i][1]) * (p - a[i][2])));
				loc[k] = i;
				k++;	
			}
		
	}
	if(k == 0 )printf("no");
	else
	{
		
	for(i = 0,flag = 1;i < k - 1&&flag;i++)
{
	flag = 0;
	for(j = 0;j < k - i - 1;j++)
	{
		if(s2[j] > s2[j+1])
		{
			t = s2[j];
			s2[j] = s2[j+1];
			s2[j+1] = t;
			t = loc[j];
			loc[j] = loc[j+1];
			loc[j+1] = t;
			flag = 1;
			if(s2[j] == s2[j+1]&&loc[j] > loc[j+1])
			{
				t = loc[j];
			    loc[j] = loc[j+1];
			    loc[j+1] = t;
			    flag = 1;
			}
		
		}
	}
}
	for(i = k - 1;i >= 0;i--)
	{
		if(i != 0)
		printf("%d %d\n",s2[i],loc[i]);
		else
		printf("%d %d",s2[i],loc[i]);
	}
	
	
	
	
}
	return 0;
}
