#include<stdio.h>
int main()
{
	int n,i,j,t;
	int a[10];
	scanf("%d",&n);
	for(i=0;i<=8;i++)
	{
		scanf("%d ",&a[i]);
		for(j=i;j<=9;j++)
		{
			if(a[i]>a[j])
			{
				t=a[i];
				a[i]=a[j];
				a[j]=t;
			}
		}
	}
	for(i=0;i<=9;i++)
		printf("%d ",a[i]);
	return 0;
}
