#include<stdio.h>
int main()
{
	int a,b,c,d,e,i,max,end;
	scanf("%d %d",&a,&b);
	for(c=0,d=0,e=0,i=a;i<=b;i++)
	{
		if(i%2!=0)
		{
			c++;
		}
		if(i%2==0)
		{
			d++;
		}
		if(i%7==0&&i%3!=0)
		{
			e++;
		}
	}
	max=(c>=d?c:d);
	end=(e>=max?e:max);
	printf("%d %d %d\n",c,d,e);
	printf("%d",end);
	return 0;
} 
