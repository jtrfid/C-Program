#include<stdio.h>
int main(){
	int m=0;
	int s,p=0;
	int a[30][3];
    int b[30];
	scanf("%d\n",&m);
	int i,j=0;
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d ",&a[i][j]);
		}
	}
	for(i=0;i<m;i++){
    	if(a[i][0]+a[i][1]>a[i][2]||a[i][0]+a[i][2]>a[i][1]||a[i][1]+a[i][2]>a[i][0]){
    	p=(a[i][0]+a[i][1]+a[i][2])/2;
		s=p*(p-a[i][0])*(p-a[i][1])*(p-a[i][2]);	
    	for(j=0;j<30;j++){
    		b[j]=s;
    	}
		}else{
			break;
		}
    }
    for(j=0;j<m;j++){
    	printf("%d %d",b[j],j);
    }
    return 0;
}
