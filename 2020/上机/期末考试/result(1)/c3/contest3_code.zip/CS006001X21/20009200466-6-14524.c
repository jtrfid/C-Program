#include<stdio.h>
int main(){
	int m,n;
	scanf("%d%d",&m,&n);
	int i;
	int a=0,b=0,c=0;
	for(i = m;i<=n;i++){
		if(i%2==0) b++;
		else a++;
		if(i%7==0 && i%3 != 0) c++;
	}
	printf("%d %d %d\n",a,b,c);
	int max = a;
	if(max < b) max = b;
	if(max <c) max = c;
	printf("%d",max);
	
	
	
	return 0;
}
