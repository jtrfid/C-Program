#include<stdio.h>
#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;
char name[10][100000]={{'\0'}};
typedef struct{
	char name[11]={'\0'};
	int a;
	int b;
	int c;
} person;
int panduan(int y,int m,int d)
{
	if(y<1821 || y>2021)return 1;
	if(y==1821 && d<9 || y==2021 && m>1 || y==2021 && m==1 && d>9 )
	    return 1;
	return 0;
}
int main()
{
	int n;
	cin>>n;
	person Q,mx,mn;
	mx.a=1820;
	mx.b=0;
	mx.c=0;
	mn.a=2022;
	mn.b=33;
	mn.c=33;
	int num=0;
	for(int i=1;i<=n;i++)
	{
		cin>>Q.name;
		scanf("%d/%d/%d",&Q.a,&Q.b,&Q.c);
		if(panduan(Q.a,Q.b,Q.c))continue; //���Ϸ�����¼
		//�Ϸ���ʼ�Ƚ����䣻
		if(mx.a<Q.a || mx.a==Q.a && mx.b<Q.b || mx.a==Q.a && mx.b==Q.b && mx.c<Q.c ){
			mx=Q;
		} 
		if(mn.a>Q.a || mn.a==Q.a && mn.b>Q.b || mn.a==Q.a && mn.b==Q.b && mn.c>Q.c ){
			mn=Q;
		} 
		num++;
	}
	if(mx.a==1820)cout<<0;
	else{
		cout<<num<<endl;
		cout<<mn.name<<endl;
		cout<<mx.name<<endl;
	}
	return 0;
}
