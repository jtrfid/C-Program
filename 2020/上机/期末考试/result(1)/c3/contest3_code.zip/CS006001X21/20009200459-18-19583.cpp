#include<stdio.h>
int main(){
	int m;
	scanf("%d",&m);
	float ju[m][3];
	int i;
	int j;
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			if(j<2){
				scanf("%f ",&ju[i][j]);
			}else{
				scanf("%f",&ju[i][j]);
			}
		}
	}
	int jilu[m];
	for(i=0;i<m;i++){
		jilu[i]=m;
	}
	int p=0;
	int ss;
	for(ss=0;ss<m;ss++){
		if(ju[ss][0]+ju[ss][1]-ju[ss][2]>0&&ju[ss][2]+ju[ss][1]-ju[ss][0]>0&&ju[ss][0]+ju[ss][2]-ju[ss][1]>0){
			jilu[p]=ss;p=p+1;
		}
	}
	int S[p][2];
	for(ss=0;ss<p;ss++){
		S[ss][0]=((ju[jilu[ss]][0]+ju[jilu[ss]][1]+ju[jilu[ss]][2])/2)*((ju[jilu[ss]][0]+ju[jilu[ss]][1]+ju[jilu[ss]][2])/2-ju[jilu[ss]][0])*((ju[jilu[ss]][0]+ju[jilu[ss]][1]+ju[jilu[ss]][2])/2-ju[jilu[ss]][1])*((ju[jilu[ss]][0]+ju[jilu[ss]][1]+ju[jilu[ss]][2])/2-ju[jilu[ss]][2]);
		S[ss][1]=jilu[ss];
	}
	int change1;
	int change2;
	for(i=0;i<p;i++){
		for(j=i+1;j<p;j++){
			if(S[i][0]<S[j][0]){
				change1=S[i][0];
				S[i][0]=S[j][0];
				S[j][0]=change1;
				
				change2=S[i][1];
				S[i][1]=S[j][1];
				S[j][1]=change2;
			}
			else if(S[i][0]==S[j][0]){
				if(S[i][1]>S[j][1]){
				change2=S[i][1];
				S[i][1]=S[j][1];
				S[j][1]=change2;
				}
			}
		}
	}
	for(i=0;i<p;i++){
		if(i<p-1){
		printf("%d %d\n",S[i][0],S[i][1]);}
		else{printf("%d %d",S[i][0],S[i][1]);
		}
	}
	if(p==0){
		printf("no");
	}
	return 0;
}
