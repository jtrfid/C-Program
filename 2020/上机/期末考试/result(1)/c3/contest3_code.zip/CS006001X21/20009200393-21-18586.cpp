#include<stdio.h>
#include<string.h>
typedef struct date{
	char name[11];
	int year;
	int month;
	int day;
}people;
void myquicky(people *num,int l,int r);
void myquickm(people *num,int l,int r);
void myquickd(people *num,int l,int r);

int main()
{
	int n;
	scanf("%d",&n);
	people num[n];
	int i;
	int cnt=0;
	for(i=0;i<n;i++){
		char name[11];
		scanf("%s",name);
		int year,month,day;
		scanf("%d/%d/%d",&year,&month,&day);
		if(year>1821&&year<2021){
			strcpy(num[i].name,name);
			num[i].year=year;
			num[i].month=month;
			num[i].day=day;
			cnt++;
		}else if(year==1821&&(month>1||(month==1&&day>=9))){
			strcpy(num[i].name,name);
			num[i].year=year;
			num[i].month=month;
			num[i].day=day;
			cnt++;
		}else if(year==2021&&month==1&&day<=9){
			strcpy(num[i].name,name);
			num[i].year=year;
			num[i].month=month;
			num[i].day=day;
			cnt++;
		}else{
			num[i].year=-1;
			num[i].month=-1;
			num[i].day=-1;
		}
	}
	myquicky(num,0,n-1);
	for(i=0;i<n-1;i++){
		int fi,li;
		if(num[i].year==num[i+1].year){
			fi=i;
			while(num[i].year==num[i+1].year)
			i++;
			li=i;
			myquickm(num,fi,li);
		}
	}
	for(i=0;i<n-1;i++){
		int fi,li;
		if(num[i].year==num[i+1].year&&num[i].month==num[i+1].month){
			fi=i;
			while(num[i].year==num[i+1].year&&num[i].month==num[i+1].month)
			i++;
			li=i;
			myquickd(num,fi,li);
		}
	}
	printf("%d\n",cnt);
	if(cnt!=0){
		for(i=0;i<n;i++){
			if(num[i].year!=-1){
				printf("%s\n",num[i].name);
				break;
			}
		}
		printf("%s",num[n-1].name);
	}
	return 0;
}
void myquicky(people *num,int l,int r){
	if(l>=r)
	return;
	int first=l;
	int last=r;
	int key=num[first].year;
	people key1=num[first];
	while(first<last){
		while(first<last&&num[last].year>=key)
		last--;
		num[first]=num[last];
		while(first<last&&num[first].year<=key)
		first++;
		num[last]=num[first];
	}
	num[first]=key1;
	myquicky(num,l,first-1);
	myquicky(num,last+1,r);
}
void myquickm(people *num,int l,int r){
	if(l>=r)
	return;
	int first=l;
	int last=r;
	int key=num[first].month;
	people key1=num[first];
	while(first<last){
		while(first<last&&num[last].month>=key)
		last--;
		num[first]=num[last];
		while(first<last&&num[first].month<=key)
		first++;
		num[last]=num[first];
	}
	num[first]=key1;
	myquicky(num,l,first-1);
	myquicky(num,last+1,r);
}
void myquickd(people *num,int l,int r){
	if(l>=r)
	return;
	int first=l;
	int last=r;
	int key=num[first].day;
	people key1=num[first];
	while(first<last){
		while(first<last&&num[last].day>=key)
		last--;
		num[first]=num[last];
		while(first<last&&num[first].day<=key)
		first++;
		num[last]=num[first];
	}
	num[first]=key1;
	myquicky(num,l,first-1);
	myquicky(num,last+1,r);
}
