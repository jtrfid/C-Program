#include<stdio.h>
int main(){
	int n,m;
	scanf("%d %d",&n,&m);
	int i;
	int jishu=0,oushu=0,qi=0;
	for(i=n;i<=m;i++){
		if(i%2==1){jishu=jishu+1;
		}else{oushu=oushu+1;
		}
		if(i%7==0&&i%3!=0){
			qi=qi+1;
		}
	}
	printf("%d %d %d\n",jishu,oushu,qi);
	if(jishu>oushu&&jishu>qi){
		printf("%d",jishu);
	}
	else if(oushu>=jishu&&oushu>=qi){
		printf("%d",oushu);
	}
	else{printf("%d",qi);}
	
	
	return 0;
}
