#include<iostream>
#include<cstdio>
#include<algorithm>

using namespace std;

int main()
{
	int a[15], std;
	scanf("%d", &std);
	for(int i=1; i<=10; i++)
		scanf("%d", &a[i]);
	sort(a+1, a+11);
	for(int i=1; i<=10; i++)
	{
		if(a[i]==std) continue;
		printf("%d ", a[i]);
	}

}