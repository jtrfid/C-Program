#include<stdio.h>
int main()
{int m,n;
scanf("%d %d",&m,&n);
int i;
int count[3]={0};
int max=0;
for(i=m;i<=n;i++)
	{if(i%2==1)
		{count[0]++;
		}
	else if(i%2==0)
		{count[1]++;
		}
	if(i%7==0&&i%3!=0)
		{count[2]++;
		}
	}
for(i=0;i<=2;i++)
	{if(count[i]>max)
		{max=count[i];
		}
	}
printf("%d %d %d\n",count[0],count[1],count[2]);
printf("%d",max);
return 0;
}
