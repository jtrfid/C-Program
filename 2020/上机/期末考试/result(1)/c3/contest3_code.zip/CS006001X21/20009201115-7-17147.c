#include <stdio.h>
int main()
{
	int a;
	int m[10];
	int n[10];
	int i,j,k;
	int t=0;
	scanf("%d",&a);
	for(i=0;i<10;i++)
	{
		scanf("%d",&m[i]);
	}
	for(i=0;i<10;i++)
	{
		if(m[i]==a)
		{
			m[i]=10000;
			t=1;
		}
	}
	for(i=0;i<10;i++)
	{
		for(j=i+1;j<10;j++)
		{
			if(m[i]>m[j])
			{
				k=m[i];
				m[i]=m[j];
				m[j]=k;
			}
		}
	}
	if(t=0)
	{
		for(i=0;i<10;i++)
		{
			printf("%d ",m[i]);
		}
	}
	if(t=1)
	{
		for(i=0;i<9;i++)
		{
			printf("%d ",m[i]);
		}
	}
	return 0;
}
