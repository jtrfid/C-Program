#include<stdio.h>
typedef struct{
	char a[100];
	int year,month,day;
}PC;
int main()
{
	int n,cnt=0,i,j=0,k;
	scanf("%d",&n);
	PC s[n],q[n];
	for(i=0;i<n;i++)
	{
		scanf("%s %d/%d/%d",&s[i].a,&s[i].year,&s[i].month,&s[i].day);
	}
	for(i=0;i<n;i++)
	{
		if(s[i].year>2021||s[i].year<1821)
			cnt++;
		else if(s[i].year==2021)
		{
			if(s[i].month>1)
			cnt++;
			else if(s[i].month==1&&s[i].day>9)
			cnt++;
			
		}
		else 
		{
			q[j]=s[i];
			j++;
		}
	}
	for(i=0;i<j;i++)
	{
		for(k=0;k<j-i-1;k++)
		{
			if(q[k].day>q[k+1].day)
			{
				PC temp=q[k];
				q[k]=q[k+1];
				q[k+1]=temp;
			}
		}
	}
		for(i=0;i<j;i++)
		{
		for(k=0;k<j-i-1;k++)
		{
			if(q[k].month>q[k+1].month)
			{
				PC temp=q[k];
				q[k]=q[k+1];
				q[k+1]=temp;
			}
		}
		}
		for(i=0;i<j;i++)
		{
		for(k=0;k<j-i-1;k++)
		{
			if(q[k].year>q[k+1].year)
			{
				PC temp=q[k];
				q[k]=q[k+1];
				q[k+1]=temp;
			}
		}
		}
	if(cnt==n) printf("%d",0);
	else 
	{
	printf("%d\n%s\n%s",n-cnt,q[0].a,q[j-1].a);	
	}
}
