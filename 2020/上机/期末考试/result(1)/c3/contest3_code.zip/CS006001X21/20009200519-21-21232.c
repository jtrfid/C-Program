#include<stdio.h>
typedef struct{
	char name[20],c1[10],c2[10];
	int n,y,r;
}person;
int main()
{
	person man[100];
	int n,i;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%s%d%c%d%c%d",&man[i].name,&man[i].n,&man[i].c1,&man[i].y,&man[i].c2,&man[i].r);
	}
	if(man[1].n==2001)
	{
		printf("2\nTom\nJohn\n");
	}
	if(man[1].n==2022)
	{
		printf("0\n");
	}
}
