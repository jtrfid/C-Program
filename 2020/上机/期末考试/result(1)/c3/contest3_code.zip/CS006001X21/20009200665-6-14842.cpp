#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	int i;
	int a[3]={0};
	for(i=m;i<=n;i++)
	{
		if(i%2!=0) a[0]++;
	    if(i%2==0) a[1]++;
		if(i%7==0&&i%3!=0) a[2]++;
	}
	int max=a[0];
	for(i=0;i<3;i++)
	{
		if(max<=a[i]) max=a[i];
	}
	printf("%d %d %d\n%d",a[0],a[1],a[2],max);
	return 0;
}
