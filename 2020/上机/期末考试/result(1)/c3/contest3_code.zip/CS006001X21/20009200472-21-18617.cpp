#include<stdio.h>
struct people{
	char name[10];
	int year;
	int month;
	int day;
};
int main()
{
	int N;
	struct people peo[100],peop[100],tmp;
	int flag=0,i,j,z=0;
	
	scanf("%d",&N);
	for(i=0;i<N;i++){
		scanf("%s %d/%d/%d",&peo[i].name,&peo[i].year,&peo[i].month,&peo[i].day);
	}
	
	for(i=0;i<N;i++){
		if(peo[i].year<1821||peo[i].year>2021){
			continue;
		}else if(peo[i].year==1821){
			if(peo[i].month==1&&peo[i].day<8){
				continue;
			}
		}else if(peo[i].year==2021){
			if(peo[i].month>1||(peo[i].month==1&&peo[i].day>9)){
				continue;
			} 
		}
		
		peop[z]=peo[i];
		flag=1;
		z++;
	}
	
	for(i=0;i<z;i++){
		for(j=0;j<z-i-1;j++){
			if(peop[j].year>peop[j+1].year){
				tmp=peop[j];
				peop[j]=peop[j+1];
				peop[j+1]=tmp; 
			}else if(peop[j].year==peop[j+1].year){
				if(peop[j].month>peop[j+1].month){
					tmp=peop[j];
					peop[j]=peop[j+1];
					peop[j+1]=tmp; 
				}else if(peop[j].month==peop[j+1].month){
					if(peop[j].day>peop[j+1].day){
						tmp=peop[j];
						peop[j]=peop[j+1];
						peop[j+1]=tmp; 
					}
				}
			}
		}
	}
	if(flag==1){
		printf("%d\n",z);
		printf("%s\n%s",peop[0].name,peop[z-1].name);
	}else if(flag==0){
		printf("0");
	}
	
	return 0;
}
