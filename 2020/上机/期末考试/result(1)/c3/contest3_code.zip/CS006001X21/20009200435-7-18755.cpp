#include<stdio.h>
int main()
{
	int n,i,s,p=10;
	scanf("%d",&n);
	int a[10];
	for(i=0;i<10;i+=1)
	{
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<10;i+=1)
	{
		if(a[i]==n)
		{
			p=9;
		}
	}
	
	int b[p];
	for(i=0,s=0;i<p;)
	{
		if(a[i]==n)
		{
			b[s]=a[i+1];
			break;
		}
		else
		{
			b[s]=a[i];
			i+=1;
			s+=1;
		}
	}
	
	if(a[i]==n)
	{
		for(i=s+1;i<10;)
		{
			b[s]=a[i];
			i+=1;
			s+=1;
		}
	}
	
	
	int k,j,t;
	for(i=0;i<p;i+=1)
	{
		for(k=i,j=i+1;j<p;j+=1)
		{
			if(b[k]>b[j])
			{
				k=j;
			}
		}
		if(i!=k)
		{
			t=b[k];
			b[k]=b[i];
			b[i]=t;
		}
	}
	
	for(i=0;i<p;i+=1)
	{
		if(i==p-1)
		{
			printf("%d",b[i]);
		}
		else
		{
			printf("%d ",b[i]);
		}
	}

	return 0;
}
