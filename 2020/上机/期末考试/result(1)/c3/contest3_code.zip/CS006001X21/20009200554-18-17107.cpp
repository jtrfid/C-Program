#include<stdio.h>
typedef struct san
{
	int s;
	int line;
}tri;

int main(){
	int m,i,j,q,k=0,s;
	double p;
	int a[50][3]={0};
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d" ,&a[i][j]);
		}
	}
	tri ar[50];
	for(i=0;i<m;i++)
	{   q=0;
		if(a[i][0]+a[i][1]<=a[i][2])
		q=1;
		if(a[i][0]+a[i][2]<=a[i][1])
		q=1;
		if(a[i][2]+a[i][1]<=a[i][0])
		q=1;
		if(q==0)
		{
			p=(a[i][0]+a[i][1]+a[i][2])*1.0/2.0;
			s=p*(p-a[i][0])*(p-a[i][1])*(p-a[i][2]);
			ar[k].s=s/1;
			ar[k].line=i;
			k++;
		}
	}
	if(k==0)
	printf("no");
	int l;
	tri buf;
	l=k;
	for(i=0;i<l;i++)
	{
		for(j=0;j<l-1;j++)
		{
			if(ar[j].s<ar[j+1].s)
			{
				buf=ar[j];
				ar[j]=ar[j+1];
				ar[j+1]=buf;
			}
		}
	}
	for(i=0;i<l;i++)
	printf("%d %d\n",ar[i].s,ar[i].line);
	return 0;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d " ,a[i][j]);
		}
	}
	return 0;
}
