#include<stdio.h>
int main(){
	int n,i,a=0;
	int x,y,z=0;
	scanf("%d\n",n);
	for(i=0;i<n;i++){
		scanf("%d/%d/%d",&x,&y,&z);
	}
	for(i=0,a=0;i<n;i++){
	if(x=2021&&y==1){
		if(z<=9){
			a++;
		}else{
			a=a;
		}
	}
    if(x<2021&&x>=1821){
    	a++;
    }
}
    printf("%d\n",a);
    return 0;
}
