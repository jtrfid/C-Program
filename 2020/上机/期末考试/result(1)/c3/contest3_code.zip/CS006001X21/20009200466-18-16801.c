#include<stdio.h>
int junge(int a,int b,int c);
int main(){
	int m;
	scanf("%d",&m);
	int a[m][3];
	int i,j;
	for(i = 0;i<m;i++)
		for(j = 0;j<3;j++)
			scanf("%d",&a[i][j]);
	int b[m][2];
	int flag = 0;int count = 0;
	for(i = 0,j=0;i<m;i++){
		if(junge(a[i][0],a[i][1],a[i][2])){
			flag = 1;
			double temp3 =1.0*(a[i][0]+a[i][1]+a[i][2])/2*(a[i][0]+a[i][1]-a[i][2])/2*(a[i][0]-a[i][1]+a[i][2])/2*(-a[i][0]+a[i][1]+a[i][2])/2; 
			b[j][1] = (int)temp3;
			b[j][0] = i;
			j++;
			//printf("i = %d",i);
			count++;
		}
	}
	if(flag){
		for(i = 0;i<count-1;i++){
		for(j = 0;j< count-i-1;j++){
			if(b[j][1] > b[j+1][1]){
				int temp = b[j+1][1];
				b[j+1][1] = b[j][1];
				b[j][1] = b[j+1][1];
				int tmep2 = b[j+1][0];
				b[j+1][0] = b[j][0];
				b[j][0] = b[j+1][0];
			}
			if(b[j][1] == b[j+1][1] && b[j][0] > b[j+1][0]){
			int temp = b[j+1][1];
				b[j+1][1] = b[j][1];
				b[j][1] = b[j+1][1];
				int tmep2 = b[j+1][0];
				b[j+1][0] = b[j][0];
				b[j][0] = b[j+1][0];	
			}
		}
	}
	for(i = 0;i<count;i++){
		for(j=1;j>=0;j--){
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	}else printf("no");
	/*for(i = 0;i<count-1;i++){
		for(j = 0;j< count-i-1;j++){
			if(b[j][1] > b[j+1][1]){
				int temp = b[j+1][1];
				b[j+1][1] = b[j][1];
				b[j][1] = b[j+1][1];
				int tmep2 = b[j+1][0];
				b[j+1][0] = b[j][0];
				b[j][0] = b[j+1][0];
			}
			if(b[j][1] == b[j+1][1] && b[j][0] > b[j+1][0]){
			int temp = b[j+1][1];
				b[j+1][1] = b[j][1];
				b[j][1] = b[j+1][1];
				int tmep2 = b[j+1][0];
				b[j+1][0] = b[j][0];
				b[j][0] = b[j+1][0];	
			}
		}
	}
	for(i = 0;i<count;i++){
		for(j=0;j<2;j++){
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}*/
	return 0;
}
int junge(int a,int b,int c){
	if(a+b>c &&a+c >b &&b+c > a) return 1;
	else return 0;
}