#include<stdio.h>
int main()
{
    int m,n;
    int i;
    int q1,q2,q3;
    int x=0,y=0,z=0;
    int a[5],max=0;
    scanf("%d %d",&m,&n);
    for(i=m;i<=n;i++)
    {
    	q1=i%2;
    	q2=i%3;
    	q3=i%7;
    	if(q1==0)
    	{
    		x++;
    	}
    	if(q1!=0)
    	{
    		y++;
    	}
    	if(q2!=0&&q3==0)
    	{
    		z++;
    	}
    }
    a[1]=x;
    a[2]=y;
    a[3]=z;
    for(i=1;i<=3;i++)
    {
    	if(max<a[i])
    	{
    		max=a[i];
    	}
    }
    printf("%d %d %d\n%d",y,x,z,max);
    
}
