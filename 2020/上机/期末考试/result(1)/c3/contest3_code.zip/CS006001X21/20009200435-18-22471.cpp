#include<stdio.h>
int main()
{
	int n=900,m=8;
	int a=2,b=0;
	printf("%d %d\n",n,a);
	printf("%d %d\n",m,b);
	return 0;
}
