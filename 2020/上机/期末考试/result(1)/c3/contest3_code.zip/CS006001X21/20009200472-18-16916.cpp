#include<stdio.h>
#include<math.h>
struct spa{
	int b;
	int c;
};
int ans(int a){
	if(a>0) return a;
	if(a<0) return -a;
}
int iden(int a,int b,int c){
	if(a+b>c&&ans(a-b)<c&&a+c>b&&ans(a-c)<b&&b+c>a&&ans(b-c)<a){
		return 1;
	}else {
		return 0;
	}
}
int main()
{
	struct spa sp[30],tp;
	int m,a[30][3],i,j,z;
	double p;
	int flag=0;
	
	scanf("%d",&m);
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d",&a[i][j]);
		} 
	}
	j=0;
	for(i=0;i<m;i++){
		p=double(a[i][0]+a[i][1]+a[i][2])/2;
		if(iden(a[i][0],a[i][1],a[i][2])==1){
			sp[j].b=int(p*(p-a[i][0])*(p-a[i][1])*(p-a[i][2]));
			sp[j].c=i;
			j++;
			flag=1;
		}
	}
	
	for(i=0;i<j;i++){
		for(z=0;z<j-i-1;z++){
			if(sp[z].b<sp[z+1].b){
				tp=sp[z];
				sp[z]=sp[z+1];
				sp[z+1]=tp; 
			}else if(sp[z].b==sp[z+1].b){
				if(sp[z].c>sp[z+1].c){
					tp=sp[z];
					sp[z]=sp[z+1];
					sp[z+1]=tp; 
				}
			}
		}
	}
	for(i=0;i<j;i++){
		printf("%d %d\n",sp[i].b,sp[i].c);
	}
	
	if(flag==0){
		printf("no");
	}
	
	return 0;
}
