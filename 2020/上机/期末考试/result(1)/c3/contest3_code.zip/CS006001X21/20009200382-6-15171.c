#include <stdio.h>

int main(){
	int m,n,ji=0,ou=0,count=0,max;
	int a;
	scanf("%d %d",&m,&n);
	for(a=m;a<=n;a++){
		if(a%2!=0) ji++;
		if(a%2==0) ou++;
		if(a%7==0&&a%3!=0) count++;
	}
	printf("%d %d %d\n",ji,ou,count);
	if(ji>ou&&ji>count||ji==ou&&ji>count||ji==count&&ji>ou||ji==ou&&ji==count){
		max=ji;
	}
	if(ou>ji&&ou>count){
		max=ou;
	}
	if(count>ji&&count>ou){
		max=count;
	}
	printf("%d",max);
	return 0;
}
