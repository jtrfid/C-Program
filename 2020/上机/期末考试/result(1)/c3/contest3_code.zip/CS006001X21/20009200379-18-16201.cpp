#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>

using namespace std;

struct rec
{
	int code, area;
}t[35];
bool cmp(const rec &A, const rec &B)
{
	if(A.area==B.area) return A.code<B.code;
	return A.area>B.area;
}

int main()
{
	int n, cur=0;
	int a, b, c;
	double p;
	scanf("%d", &n);
	for(int i=1; i<=n; i++)
	{
		scanf("%d%d%d", &a, &b, &c);
		if(a+b>c && abs(a-b)<c)
		{
			t[++cur].code=i-1;
			p=(a+b+c)/2.0;
			t[cur].area=(p*(p-a)*(p-b)*(p-c));
		}
	}
	
	if(cur==0)
	{
		printf("no");
	}
	else
	{
		sort(t+1, t+cur+1, cmp);
		for(int i=1; i<=cur; i++)
			printf("%d %d\n", t[i].area, t[i].code);
	}
	return 0;
}