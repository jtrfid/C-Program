#include<stdio.h>

int main()
{
	int tri(int a,int b,int c);
	int m,i,j,a[30][3],b[30]={0},k=0,area,flag=0;
	double p;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<3;j++)
			scanf("%d",&a[i][j]);
	}
	
	for(i=0;i<m;i++)
	{
		if(tri(a[i][0],a[i][1],a[i][2]))
		{
			p=(double)((a[i][0]+a[i][1]+a[i][2]))/2.0;
			area=(p*(p-a[i][0])*(p-a[i][1])*(p-a[i][2]));
			b[i]=area;
			++k;
			flag=1;
		}
		else
		{
			b[i]=0;
			continue;
		}
	}
	int t;
	if(flag==1)
	{
	for(i=0;i<k;i++)
	{
		for(j=0,t=0;j<m;j++)
		{
			if(b[j]>b[t])
			{
				t=j;
			}
		}
		printf("%d %d\n",b[t],t);
		b[t]=0;
	}
	}
	else
		printf("no");
	return 0;
}

int tri(int q,int b,int c)
{
	int a[3],i,j,k,temp;
	a[0]=q,a[1]=b,a[2]=c;
	for(i=0;i<2;i++)
	{
		k=i;
		for(j=i+1;j<3;j++)
		{
			if(a[j]<a[k])
			{
				k=j;
			}
			
		}
		if(k!=i)
			{
				temp=a[k];a[k]=a[i];a[i]=temp;
			}
	}
	if(a[0]+a[1]>a[2]&&a[2]-a[0]<a[1])
		return 1;
	else
		return 0;
}
