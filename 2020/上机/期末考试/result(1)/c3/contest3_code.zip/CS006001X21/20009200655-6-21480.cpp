#include<stdio.h>
int main(){
	int i;
	int odd=0,even=0,t=0;
	int m,n;
	scanf("%d%d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2==0) even++;
		else odd++;
        if(i%3!=0&&i%7==0) t++;
	}
	printf("%d %d %d\n",odd,even,t);
	if(odd>even) printf("%d",odd);
	else printf("%d",even);
	return 0;
}
