#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;

//cin.getline(str,length);
//scanf("%[^\n]%*c",&str);
int main()
{
	int s1=0,s2=0,s3=0;
	int m,n;
	cin>>m>>n;
	for(int i=m;i<=n;i++)
	{
		if(i%2)s1++;
		if(!(i%2))s2++;
		if(!(i%7) && i%3 )s3++;
	}
	cout<<s1<<' '<<s2<<' '<<s3<<endl;
	if(s1>s2)s2=s1;
	if(s3>s2)s2=s3;
	cout<<s2;
	return 0;
}
