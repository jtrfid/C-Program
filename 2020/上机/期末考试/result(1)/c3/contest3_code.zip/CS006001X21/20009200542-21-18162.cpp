#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 100005

int n, cnt;
char ch;

struct name{
	string id;
	int y, m, d;
	bool b;
}c[maxn];

bool cmp(name a, name b){
	if(a.y == b.y){
		if(a.m == b.m) return a.d < b.d;
		return a.m < b.m;
	}
	return a.y < b.y;
}

bool is_available(int y, int m, int d){
	if(y > 2021 || y < 1821) return false;
	if(y == 2021) {
		if(m > 1) return false;
		if(m == 1){
			if(d > 9) return false;
		}
	}
	if(y == 1821) {
		if(m == 1 && d < 10) return false;
	}
	return true;
}

int main(){
	//freopen("in.txt", "r", stdin);
	cin >> n;
	for(int i = 0; i < n; ++i){
		cin >> c[i].id >> c[i].y >> ch >> c[i].m;
		if(!c[i].m) cin >> c[i].m;
  		cin >> ch >> c[i].d;
  		if(is_available(c[i].y, c[i].m, c[i].d)) c[i].b = 1;
	}
	
	sort(c, c+n, cmp);
	
	for(int i = 0; i < n; ++i){
		if(c[i].b) {
			++cnt;
            break;
		}
	}

	for(int i = n-1; i >= 0; --i){
		if(c[i].b) {
			++cnt;
			break;
		}
	}
		cout << cnt << endl;
	
	for(int i = 0; i < n; ++i){
		if(c[i].b) {
			cout << c[i].id << endl;
			break;
		}
	}
	
	for(int i = n-1; i >= 0; --i){
		if(c[i].b) {
			cout << c[i].id << endl;
			break;
		}
	}















	return 0;
}
