#include<stdio.h>
#include<math.h>
int main()
{
	int a,b[10]={0},i,j,end=10,t;
	scanf("%d",&a);
	for(i=0;i<10;i++){
		scanf("%d",&b[i]);
	}
	for(i=0;i<end;i++){
		if(b[i]==a){
			for(j=i;j<end-1;j++){
				b[j]=b[j+1];
			}
			end--;
		}
	}
	for(i=0;i<end;i++){
		for(j=end-1;j>i;j--){
			if(b[j]<b[j-1]){
				t=b[j];b[j]=b[j-1];b[j-1]=t;
			}
		}
	}
	for(i=0;i<end;i++){
		printf("%d ",b[i]);
	}
	return 0;
}
