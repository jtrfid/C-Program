#include <stdio.h>
#include <string.h>
int main(){
	struct juming{
		char name[10];
		int year;
		int month;
		int day;
	}p[100];
	int n, i, j;
	scanf("%d", &n);
	for(i = 0;i < n;i++){
		scanf("%s %d/%d/%d", &p[i].name, &p[i].year, &p[i].month, &p[i].day);
	}
	int cnt = 0;
	for(i = 0;i < n;i++){
		if(p[i].year > 1821&&p[i].year < 2021) cnt++;
		else if(p[i].year == 1821){
			if(p[i].month >= 1&&p[i].day >= 9) cnt++;
		}
		else if(p[i].year == 2021){
			if(p[i].month <= 1&&p[i].day <= 9) cnt++;
		}
		else {
			p[i].year = 0;
			p[i].month = 0;
			p[i].day = 0;
		}
	}
	if(cnt != 0){
		printf("%d\n", cnt);
		int temp;
		char t[10];
		for(i = 0;i < n;i++){
			for(j = 0;j < n - 1 - i;j++){
				if(p[j].year < p[j + 1].year){
					temp = p[j + 1].year;
					p[j + 1].year = p[j].year;
					p[j].year = temp;
					strcpy(t,p[j + 1].name);
					strcpy(p[j + 1].name, p[j].name);
					strcpy(p[j].name, t);
				}
			}
		}
		for(i = 0;p[i].year !=0;i++);
		puts(p[i - 1].name);
		puts(p[0].name);
	}
	else printf("%d", cnt);
	return 0;
}
