#include<stdio.h>
int main(){
	int m,i=1,b=1,c=1;
	int a[i];
	scanf("%d\n",&m);
    scanf("%d",&i);
	printf("no");
	return 0;
}
