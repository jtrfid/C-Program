#include<stdio.h>
int main()
{
	float a[10][3];
	float b[10];
	int i,j,n,t,m;
	float c,mianji;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
		{
		 scanf("%f",&a[i][j]);	
		}
	}
	for(i=0;i<n;i++)
	{
		for(m=0;m<2;m++)
		{
			for(j=0;j<2-m;j++)
			{
				if(a[i][j]>a[i][j+1])
				{
					t=a[i][j];
					a[i][j]=a[i][j+1];
					a[i][j+1]=t;
				}
			}
		}
	}
	t=0;
	for(i=0;i<n;i++)
	{
		if(a[i][0]+a[i][1]>a[i][2])
		{
		 c=(a[i][0]+a[i][1]+a[i][2])/2;
		 mianji=c*(c-a[i][0])*(c-a[i][1])*(c-a[i][2]);
		 b[t]=mianji;
		 t++;	
	    }
		else continue;
	}
	if(t==0) printf("no\n");  //OK
	else
	 {
	 for(i=0;i<t-1;i++)
	  {
		for(j=0;j<t-1-i;j++)
		{
			if(b[j]>b[j+1])
			{
				m=b[j];
				b[j]=b[j+1];
				b[j+1]=m;
			}
		}
	  }
	  for(i=t-1;i>=0;i--)
	  {
			printf("%.0f %d\n",b[i],i);
	  }
     }
	return(0);
}
