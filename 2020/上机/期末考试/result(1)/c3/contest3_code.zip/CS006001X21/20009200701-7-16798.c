#include<stdio.h>
#include<string.h>
#include<math.h>

int main(){
	int n,a[10],i,j=0,t=10,q;
	scanf("%d",&n);
	for(i=0;i<t;i++){
		scanf("%d",&a[i]);
		if(a[i]==n){
			i--;
			t--;
		}
	}
	for(i=0;i<t;i++){
		for(j=i;j<t;j++){
			if(a[i]>a[j]){
				q=a[i];
				a[i]=a[j];
				a[j]=q;
			}
		}
	}
	for(i=0;i<t;i++){
		printf("%d ",a[i]);
	}
	return 0;
}
