#include<bits/stdc++.h>
using namespace std;
typedef struct sa{
	int h,s;
}saa;
bool cmp(const sa &a1,const sa &a2){
	if(a1.s==a2.s)return a1.h<a2.h;
	else return a1.s>a2.s;
}
int main(){
	saa b[50];
	int a[5],c=0,T,i,s;
	double p;
	cin>>T;
	for(i=0;i<T;i++){
		cin>>a[0]>>a[1]>>a[2];
		sort(a,a+3);
		if(a[0]+a[1]>a[2]){
			p=(a[1]+a[2]+a[0])/2.0;
			
			b[c].h=i;
			s=(int)(p*(p-a[0])*(p-a[1])*(p-a[2]));
			b[c].s=s;
			c++;
		}

	}
	if(c>0){
		sort(b,b+c,cmp);
		for(i=0;i<c;i++){
			cout<<b[i].s<<" "<<b[i].h<<endl;
		}
	}
	else cout<<"no";

}
