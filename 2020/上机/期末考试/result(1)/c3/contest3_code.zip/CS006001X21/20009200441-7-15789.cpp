#include<stdio.h>
int main()
{
	int a , aa[10] ,p[10] , i , j , t,flag ;
	scanf("%d",&a);
	for(i=0 ; i <10 ; i++)
	{
		p[i]=1;
		scanf("%d",&aa[i]);
		if(aa[i]==a)
		{
			p[i]=0;
		}
	} 
	for(i=1;i<10;i++)
	{
		flag = 0;
		for(j=0;j<10-i;j++)
		{
			if(aa[j]>aa[j+1])
			{
				t=aa[j];
				aa[j]=aa[j+1];
				aa[j+1]=t;
				flag =1;
			}
		}
		if(flag == 0)
		{
			break;
		}
	}
	for(i=0;i<10;i++)
	{
		if(p[i]==1)
		{
			printf("%d ",aa[i]);
		}
	}
	return 0 ;
}
