#include<stdio.h>
#include<string.h>
int main(){
	int i,j,k,l,m,n,c1=0,c2=0,c3=0;
	int a[100]={0};
	char s[100],ss[100];
	scanf("%d%d",&m,&n);
	for(i=m;i<=n;i++){
		if(i%2==1) c1++;
		if(i%2==0) c2++;
		if(i%7==0&&i%3!=0) c3++;
	}
	int max=c1;
	if(c2>max) max=c2;
	if(c3>max) max=c3;
	printf("%d %d %d\n%d",c1,c2,c3,max);
	
	
	return 0;
}
