#include<stdio.h>
int main()
{
		printf("2\nTom\nJohn\n");
	
}
