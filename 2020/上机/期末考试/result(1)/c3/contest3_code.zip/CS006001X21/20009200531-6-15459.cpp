#include<stdio.h>
int main()
{
	int b[10],m,n,i,j=0,k=0,q=0,p=0;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%7==0&&i%3!=0)
		{
		
			j++;
		}
	}

	for(i=m;i<=n;i++)
	{
		if(i%2==0)q++;
		else p++;
	}
	b[0]=q;
	b[1]=p;
	b[2]=j;
	for(i=0;i<3;i++)
	{
		if(b[i]>k)k=b[i];
	}
		printf("%d %d %d",p,q,j);
	printf("\n");
	printf("%d",k);
	return 0;
}
