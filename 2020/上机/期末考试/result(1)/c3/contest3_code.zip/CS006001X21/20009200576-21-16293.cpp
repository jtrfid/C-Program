#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <utility>
#include <vector>
#include <string>
const int maxn = 100005;
char name[maxn][14], day[maxn][12];
char tmp[7], tmp_2[7], tmp_3[7];
int main() {
  int n; scanf("%d", &n);
  std::string maxs("0000/00/00"), mins("2077/00/00");
  std::string min_name(""), max_name("");
  int cnt = 0;
  for(int i = 1; i <= n; i ++) {
    scanf("%s%s", name[i], day[i]);
    char *d = day[i];
    std::copy(d, d + 4, tmp); tmp[4] = 0;
    std::copy(d + 5, d + 7, tmp_2); tmp_2[2] = 0;
    std::copy(d + 8, d + 10, tmp_3); tmp_3[2] = 0;
    int yr; sscanf(tmp, "%d", &yr);
    int month; sscanf(tmp_2, "%d", &month);
    int pd; sscanf(tmp_3, "%d", &pd);
#ifdef LOCAL
    printf("%s : %d %d %d\n", name[i], yr, month, pd);
#endif
    if(yr < 1821) {
      continue;
    } else if(yr == 1821) {
      if(month == 1 && pd < 9) continue;
    } else if(yr == 2021) {
      if(month > 1 || pd > 9) continue;
    } else if(yr > 2021) {
      continue;
    }
    cnt ++;
    std::string s_1(name[i]);
    std::string s_2(day[i]);
    if(s_2 < mins) {
      min_name = s_1;
      mins = s_2;
    }
    if(s_2 > maxs) {
      max_name = s_1;
      maxs = s_2;
    }
  }
  if(cnt == 1) cnt --;
  printf("%d\n", cnt);
  if(cnt > 1) {
    printf("%s\n%s\n", min_name.c_str(), max_name.c_str());
  }
  return 0;
}
