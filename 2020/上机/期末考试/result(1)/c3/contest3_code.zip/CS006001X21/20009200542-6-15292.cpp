#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;

int m, n, cnt1, cnt2, cnt3;

int main(){
	//freopen("in.txt", "r", stdin);
	cin >> m >> n;
	for(int i = m; i <= n; ++i){
		if(i % 2 == 1) ++cnt1;
		if(i % 2 == 0) ++cnt2;
		if(i % 7 == 0 && i % 3 != 0) ++cnt3;
	}
	cout << cnt1 << " " << cnt2 << " " << cnt3 << endl;
	cout << max({cnt1, cnt2, cnt3});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
