#include<stdio.h>
int main()
{
	int n,i,j,t;
	int a[10];
	scanf("%d",&n);
	for(i=0;i<=9;i++)
	{
		scanf("%d",&a[10]);
		if(n!=a[i])
		{
			for(i=0;i<=8;i++)
			{
				for(j=i+1;j<=9;j++)
				{
					if(a[i]>a[j])
					{
						t=a[i];
						a[i]=a[j];
						a[j]=t;
					}
				}
			}
			for(i=0;i<=9;i++)
			printf("%d ",a[i]);
		}
	}
	return 0;
}
