#include<stdio.h>
int main(){
	char a[20];
	int i,n;
	scanf("%d",&n);
	n=n*2;
	for(i=1;i<=n;i++){
		scanf("%s",&a);
	}
	printf("0");
}
