#include<stdio.h>

int main()
{
	int m, n;
	scanf("%d %d",&m,&n);
	int i;
	int s1=0, s2=0, s3=0;
	for(i=m; i<=n; i++)
	{
		if(i%2)
		{
			s1++;
		}
		if(i%2==0)
		{
			s2++;
		}
		if(i%7==0&&i%3!=0)
		{
			s3++;
		}
	}
	int max=s1;
	if(max<s2)
	{
		max=s2;
	}
	if(max<s3)
	{
		max=s3;
	}
	printf("%d %d %d\n",s1,s2,s3);
	printf("%d",max);
	return 0;
}
