#include<stdio.h>

int main()
{
	int m,n,odd,even,num,max,i;
	odd = 0,even = 0,num = 0,max = 0;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++){
		if(i%2==0){
			even++;
		}else if(i%2!=0){
			odd++;
		}
		if((i%7==0)&&(i%3!=0)){
			num++;
		}
	}
	max=odd;
	if(even>max){
		max=even;
	}
	if(num>max){
		max=num;
	}
	printf("%d %d %d\n%d",odd,even,num,max);
	return 0;
}
