#include<stdio.h>
#include<string.h>
int main(){
	int i,j,k,l,n,m,t;
	int a[10000]={0};
	char tmp[10];
	char s[10000][10],sr[10000][10];
	int yy[10000]={0},mm[10000]={0},dd[10000]={0};
	scanf("%d",&n);
	m=n;
	for(i=0;i<n;i++){
		scanf("%s %s",s[i],sr[i]);
	}
	for(j=0;j<n;j++){
		for(i=0;i<4;i++){
			yy[j]=yy[j]*10+(sr[j][i]-'0');
		}
		for(i=5;i<7;i++){
			mm[j]=mm[j]*10+(sr[j][i]-'0');
		}
		for(i=8;i<10;i++){
			dd[j]=dd[j]*10+(sr[j][i]-'0');
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n-i-1;j++){
			if(yy[j]>yy[j+1]||yy[j]==yy[j+1]&&mm[j]>mm[j+1]||yy[j]==yy[j+1]&&mm[j]==mm[j+1]&&dd[j]>dd[j+1]){
				t=yy[j];yy[j]=yy[j+1];yy[j+1]=t;
				t=dd[j];dd[j]=dd[j+1];dd[j+1]=t;
				t=mm[j];mm[j]=mm[j+1];mm[j+1]=t;
				strcpy(tmp,s[j]);strcpy(s[j],s[j+1]);strcpy(s[j+1],tmp);
			}
		}
	}
	for(i=0;i<n;i++){
		if(yy[i]>2021||yy[i]<1820||yy[i]==1820&&mm[i]==1&&dd[i]<=9||yy[i]==2021&&mm[i]>1||yy[i]==2021&&mm[i]==1&&dd[i]>9){
			m--;
			a[i]=1;
		}
	}
	printf("%d\n",m);
	for(i=0;i<n;i++){
		if(a[i]==0){
			printf("%s\n",s[i]);break;
		}
	}for(i=n-1;i>=0;i--){
		if(a[i]==0){
			printf("%s\n",s[i]);break;
		}
	}
	return 0;
}

