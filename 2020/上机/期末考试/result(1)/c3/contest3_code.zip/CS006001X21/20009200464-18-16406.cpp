#include<stdio.h>
#include<string.h>
int main(){
	int i,j=0,k=0,l,m,n,t=0;
	int ff[100]={0};
	double p[100],b[100]={0};
	int c[100]={0};
	double a[100][3];
	double s[100]={0};
	scanf("%d",&m);
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%lf",&a[i][j]);
		}
		p[i]=0.5*(a[i][0]+a[i][1]+a[i][2]);
	}
	for(i=0;i<m;i++){
		if(a[i][0]+a[i][1]>a[i][2]&&a[i][0]+a[i][2]>a[i][1]&&a[i][2]+a[i][1]>a[i][0]){
			ff[i]++;
		}
	}
	for(i=0;i<m;i++){
		if(ff[i]){
			s[i]=p[i]*(p[i]-a[i][0])*(p[i]-a[i][1])*(p[i]-a[i][2]);
		}
	}
	for(i=0;i<m;i++){
		if(s[i]>0){
			b[k]=s[i];
			c[k]=i;
			k++;
		}
	}
	for(i=0;i<k;i++){
		for(j=0;j<k-i-1;j++){
			if(b[j]<b[j+1]){
				t=b[j];b[j]=b[j+1];b[j+1]=t;
				t=c[j];c[j]=c[j+1];c[j+1]=t;
			}
		}
	}
	for(i=0;i<k;i++){
		if((int)b[i]-b[i]!=0){
			b[i]=(int)b[i]+1;
		}
	}
	for(i=0;i<k;i++){
		printf("%.0f %d\n",b[i],c[i]);
	}
	if(k==0) printf("no");
	return 0;
}
