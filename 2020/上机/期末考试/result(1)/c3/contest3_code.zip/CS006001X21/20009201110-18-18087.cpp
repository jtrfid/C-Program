#include<stdio.h>
int main(){
	float a,b,c,w,s,p,sw=0;
	int n,i,j,m;
	int x[50]={0},y[50]={0};
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%f %f %f",&a,&b,&c);
		w=a+b+c;
		p=w/2;
		if(w>(2*a)&&w>(2*b)&&w>(2*c)){
			s=(w/2)*((w/2)-a)*((w/2)-b)*((w/2)-c);
			sw=1;
		    x[i]=(int)s;
		    y[i]=x[i];
		}
		else continue;	
	}
	if(sw==0) printf("no");
	else{
		for(i=1;i<=n;i++){
			for(j=1;j<=n;j++){
				if(x[j]<x[j+1]){
					m=x[j];
					x[j]=x[j+1];
					x[j+1]=m;
				}
			}
		}
		for(i=1;i<=n;i++){
			if(x[i]==0) continue;
			else{
				for(j=1;j<=n;j++){
					if(x[i]==y[j]) printf("%d %d\n",x[i],(j-1));
					else continue;
				}
			}
		}
	}
	return 0;
}
