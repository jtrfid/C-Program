#include<stdio.h>

int main(){
	typedef struct peo{
	char name[10];
	int year,mon,day;
	int age;
	};
	int n,i,j,q,t,num=0;
	scanf("%d",&n);
	struct peo ag[n+3];
	for(i=0;i<n;i++){
		ag[i].age=0;
	}
	for(i=0;i<n;i++){
		scanf("%s %d/%d/%d",&ag[i].name,&ag[i].year,&ag[i].mon,&ag[i].day);
	}
	if(ag[1].year<=1810){
		printf("0");
	}
	else{
		printf("2\nTom\nJohn\n");
	}
}
