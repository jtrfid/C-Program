#include<stdio.h>
int main(){
	int m,t;
	scanf("%d",&m);
	int a[10],i,j;
	for(i=0;i<10;i++)
	scanf("%d",&a[i]);
	int flag=0;
	for(i=0;i<10;i++){
		if(a[i]==m&&i!=9){
		flag=1;
		for(;i<9;i++)
		a[i]=a[i+1];
		for(i=0;i<8;i++){
			for(j=i+1;j<9;j++){
				t=a[j];a[j]=a[i];a[i]=t;
			}
		} 
		for(i=0;i<9;i++)
		printf("%d ",a[i]);	 
	}
	    else if(a[9]==m)
	    {
	    	flag=1;
	    	for(i=0;i<8;i++){
	    		for(j=i+1;j<9;j++){
	    		t=a[j];a[j]=a[i];a[i]=t;	
	    		}
	    	}
	    	for(i=0;i<9;i++)
	    	printf("%d ",a[i]);	 
	    }
	    
	}
	if(flag==0){
	    	for(i=0;i<9;i++){
	    		for(j=i+1;j<10;j++){
	    		t=a[j];a[j]=a[i];a[i]=t;	
	    		}
	    	}
	    	for(i=0;i<10;i++)
	    	printf("%d ",a[i]);	
	}
	return 0;
	
}
