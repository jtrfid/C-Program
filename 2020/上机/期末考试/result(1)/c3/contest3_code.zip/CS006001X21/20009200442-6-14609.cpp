#include<bits/stdc++.h>
using namespace std;

int main(){
	int m,n,a[3]={0};
	cin>>m>>n;
	int i;
	for(i=m;i<=n;i++){
		if(i%2==0)a[1]++;
		else a[0]++;
		if(i%7==0&&i%3!=0)a[2]++;
	}
	cout<<a[0]<<" "<<a[1]<<" "<<a[2]<<endl;
	sort(a,a+3);
	cout<<a[2];
	return 0;
}
