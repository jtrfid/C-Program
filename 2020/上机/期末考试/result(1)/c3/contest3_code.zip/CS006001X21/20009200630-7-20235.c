#include<stdio.h>
int main()
{
	int a;
	scanf("%d\n",&a);
	int i, b[10];
	for(i=0; i<10; i++)
	{
		scanf("%d ",&b[i]);
	}
	int num=0, j, c[10]={0};
	for(i=0; i<10; i++)
	{
		num++;
		j=num-1;
		if(b[i]==a)
		{
			num--;
		}
		if(b[i]!=a)
		{
			c[j]=b[i];
		}
	}
	int k, flag, t;
	for(i=0; i<num; i++)
	{
		flag=0;
		for(k=0; k<num-i-1; k++)
		{
			if(c[k]>c[k+1])
			{
			t=c[k];
			c[k]=c[k+1];
			c[k+1]=t;
			flag=1;	
			}
		}
		if(flag==0)break;
	}
	for(i=0; i<num; i++)
	{
		printf("%d ",c[i]);
	}
	return 0;
}
