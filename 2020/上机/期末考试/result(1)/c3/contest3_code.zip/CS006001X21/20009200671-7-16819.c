#include<stdio.h>
int main()
{
	int a[10],b,c[10],i,j,t,p,q;
	scanf("%d\n",&b);
	for(j=0,i=0;i<10;i++)
	{
		scanf("%d",&c[i]);
		if(c[i]!=b)
		{
			a[j]=c[i];
			j++;
		}
		else if(c[i]==b)
		{
			continue;
		}
	}
	for(i=0;i<j-1;i++)
	{
		for(p=i+1,q=i;p<j;p++)
		{
			if(a[p]<a[q])
			{
				q=p;
			}   
		}
		if(q!=i)
		{
			t=a[q];
			a[q]=a[i];
			a[i]=t;
		}
	}
	for(i=0;i<j;i++)
	{
		printf(" %d",a[i]);
	}
	return 0;
}
