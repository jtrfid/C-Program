#include<stdio.h>
#include<math.h>
int main()
{
	int a,b[10]={0},c[10]={0},i,j,s=10,t;
	scanf("%d",&a);
	for(i=0;i<10;i++){
		scanf("%d",&b[i]);
	}
	for(i=0;i<10;i++){
		if(b[i]==a){
			b[i]=-1;
			s--;
		}
	}
	j=0;
	for(i=0;i<10;i++){
	    if(b[i]>=0){
		    c[j]=b[i];
			j++;
	    }
	}
	for(i=0;i<s;i++){
		for(j=s-1;j>i;j--){
			if(c[j]<c[j-1]){
				t=c[j];c[j]=c[j-1];c[j-1]=t;
			}
		}
	}
	for(i=0;i<s;i++){
		printf("%d ",c[i]);
	}
	return 0;
}
