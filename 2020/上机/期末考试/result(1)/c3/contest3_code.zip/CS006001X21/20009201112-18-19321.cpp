#include<stdio.h>
double area(int a,int b,int c){
	double p=0.5*(a+b+c);
	double s;
	s=p*(p-a)*(p-b)*(p-c);
	return s;
}
int triangle(int a,int b,int c){
	if(a+b>c&&a-b<c)
	return 1;
	else return 0;
}
int main(){
	int m;
	scanf("%d",&m);
	int a[m][3],i,j;
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d",&a[i][j]);
		}
    }
    int s[10001],y[10001],x=0;
    double p[10001];
    j=0;
    for(i=0;i<m;i++){
    	if(triangle(a[i][0],a[i][1],a[1][2])==1){
    		p[j++]=area(a[i][0],a[i][1],a[1][2]);
    		s[j]=int (p[j]);
    		y[j]=i;
    		x++;
    	}
    }
    if(x==0)
    printf("no");
    else
    {for(i=0;i<x;i++)
    printf("%d %d",s[i],y[i]);
    }
}
