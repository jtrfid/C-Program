#include <cstdio>
#include <algorithm>

int main() {
  int m, n; scanf("%d%d", &m, &n);
  int cnt_o = 0, cnt_e = 0, cnt_c = 0;
  for(int i = m; i <= n; i ++) {
    if(1 & i) {
      cnt_o ++;
    } else {
      cnt_e ++;
    }
    if((!(i % 7)) && (i % 3)) cnt_c ++;
  }
  int ans = std::max(cnt_o, std::max(cnt_e, cnt_c));
  printf("%d %d %d\n%d\n", cnt_o, cnt_e, cnt_c, ans);
  return 0;
}
