#include<stdio.h>
int main()
{
	int a,i,j,tmp,n=0;
	int num[10]={0};
	scanf("%d",&a);
	for(i=0;i<10;i++){
		scanf("%d",&num[i]);
	}
	for(i=0;i<10;i++){
		for(j=0;j<10;j++){
			if(num[j]>num[j+1]){
				tmp=num[j];
				num[j]=num[j+1];
				num[j+1]=tmp;
			}
		}
	}
	for(i=0;i<10;i++){
		if(num[i]==a){
			for(i;i<10;i++){
				num[i]=num[i+1];
			}
			n++;
		}
	}
	for(i=0;i<10-n;i++){
		printf("%d",num[i]);
	}
	return 0;
}
