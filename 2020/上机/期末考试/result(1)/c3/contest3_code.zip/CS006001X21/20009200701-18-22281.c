#include<stdio.h>
#include<string.h>
#include<math.h>


int main(){
	typedef struct jk{
	int S;
	int num;
	};
	int m,n,t0,t1,i,j;
	float p,a,b,c;
	scanf("%d",&m);
	struct jk ss[m+2];
	int s[m][3];
	int q=0;
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			scanf("%d",&s[i][j]);
		}
		a=s[i][0];
		b=s[i][1];
		c=s[i][2];
		if(a+b>c&&a+c>b&&b+c>a&&a>0&&b>0&&c>0){
			p=a+b+c;
			p/=2;
			ss[q].S=p*(p-a)*(p-b)*(p-c);
			ss[q].num=i;
			q++;
		}
	}
	for(i=0;i<q;i++){
		for(j=i;j<q;j++){
			if(ss[i].S<ss[j].S){
				ss[m+1]=ss[i];
				ss[i]=ss[j];
				ss[j]=ss[m+1];
			}
			else if(ss[i].S==ss[j].S){
				if(ss[i].num>ss[j].num){
					ss[m+1]=ss[i];
					ss[i]=ss[j];
					ss[j]=ss[m+1];
				}
			}
		}
	}
	for(i=0;i<q;i++){
		printf("%d %d\n",ss[i].S,ss[i].num);
	}
	if(q==0){
		printf("no\n");
	}
	return 0;
}
