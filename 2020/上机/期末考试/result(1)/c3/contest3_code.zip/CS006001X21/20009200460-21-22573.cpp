#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j=0,maxy=2022,maxm=13,maxd=32,miny=1820,minm=0,mind=0,f=0,y,m,d;
	char a[20]={0},b[20]={0},maxname[20]={0},minname[20]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s %s",&a,&b);
		y=(b[0]-'0')*1000+(b[1]-'0')*100+(b[2]-'0')*10+(b[3]-'0');
		m=(b[5]-'0')*10+(b[6]-'0');
		d=(b[8]-'0')*10+(b[9]-'0');
		if(y>=1822&&y<=2020||y==1821&&m>=2||y==1821&&m==1&&d>=9||y==2021&&m==1&&d<=9){
			f++;
			if(y<maxy||y==maxy&&m<maxm||y==maxy&&m==maxm&&d<maxd){
				maxy=y;maxm=m;maxd=d;
				while(a[j]!='\0'){
					maxname[j]=a[j];
					j++;
				}
			}
			j=0;
			if(y>miny||y==miny&&m>minm||y==miny&&m==minm&&d>mind){
				miny=y;minm=m;mind=d;
				while(a[j]!='\0'){
					minname[j]=a[j];
					j++;
				}
			}
		}
	}
	if(f==0){
		printf("no");
	}
	else{
		printf("%d\n%s\n%s",f,maxname,minname);
	}
	return 0;
}
