#incloude<stdio.h>
int main()
{
	int h;
	charc;
	scanf("%d",&h);
	int b[h][17];
	char d[h];
	for(i=0;j<n;j++){
		scanf("%d"&c);
		if(j!=17){
			a[i][j]=c-'0';
		}
	}
	
	return0;
}
