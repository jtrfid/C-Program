#include<stdio.h>
#include<string.h>
int main()
{ char m;
scanf {"%c\n",&n};
char ch(100);
int i;
gets(ch);
int;
i=strlen(ch);
for(i=0;i<1,i++);
{ if (ch(i)=='m'; ch(i)=='m-32');
{
for int (j=1; ch(j)=='m'; ch(j)=='m-32')
printf("$c",ch(j)); }

break

}





}
