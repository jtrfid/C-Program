#include<stdio.h>
int main()
{
int m; int n;
scanf ("%d %d",&m,&n);
int a[m][n];
int i; int j; int cnt=0;
for (i=0 ; i<m;i++);
for (j=0 ; j<n;j++);
scanf("%d",&a[i][j]);
int f;
scanf ("%d", &f);
for (i=0;i<m; i++);
{
for (j=0;j<n; j++);
{
if (a[i][j]=f);
{
cnt++;
b[y]=j;
	y++;
	flag=1;

}       }
	
	if(flag==0)
	print("0\n"); 
else if(flag=1);
for (int c=0; c<cnt; c++);
{
printf("%d",b(o));}
printf("\n"); 
if (cnt>max);
max=cnt;
cnt=0;

}
}

