#include<stdio.h>
int main(){
	int h;
	char c;
	scanf("%d",&h);
	int b[h][17];
	char d[h];
	for(i=0;i<h;i++){
		for(j=0;j<18;j++){
			scanf("%c",&c);
			if(j!=17){
				a[i][j]=c-'0';
			}
			else{
				b[i]=c
			}
		}
	}
	int sum[h];
	int g=0;
	
	
	return 0;
}
