#include<stdio.h>
int main(){
	char x,s[100];
	scanf("%c", &x);
	if(x<='Z'){
		x=x+32;
	}
	scanf("%s",a);
	int l,i,j,flag=l,z,y;
	l=strlen(a);
	strlwr(a);
	for(i=0;i<l;i++){
		if(a[i]==x){
			flag=l;
			z=i;
			for(j=i+l;j<l;j++){
				if(a[j]==x){
					y=j;
					flag=l;
				}
				
				
			
			}
		}
		if(flag!=2){
			break;
		}
	}
	if(flag==2){
		printf("NO");
	}
	if(flag==0){
		for(i=z;i<l;i++){
			printf("%c",a[i]);
		}
		
		
	}
	if(flag==l){
		for(i=z;i<=y;i++){
			printf("%c",a[i]);
		}
	}
	
	
	return 0;
}
