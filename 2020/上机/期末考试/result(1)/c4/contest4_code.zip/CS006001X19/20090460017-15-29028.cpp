#incloude<stdio.h>
int main()
{
	int main m,n'
	scanf("%d,%d"%m,&n);
	int a[m][n],b[m]=(0);
	int i,j,k=0;
	for(i=0;j<n;j++){
		for(j=0;j<n;j++){
			scanf("%d"&a[i][l]);
	}
}
    int x;
    scanf("%d",&x);
    for(i=0;i<m;i++){
    	for(j=0;j<n;j++){
    		if(a[i][j]==x){
    			k++;
    		}
    	}
    	b[i]=k;
    	k=0;
    }
    int max=0;
    for(i=0;i<m;i++){
    	if(max<b[i]){
    		max=b[i];
    	}
    }
	if(max==0){
		printf("no");
	}
	else{
		for(i=0;i<m;i++){
			printf("%d\n",b[i]);
		}
		printf("%d",k);
	}
	
	return 0;
}
