#include<stdio.h>
#include<string.h>
int main(){
	char x,g[100];
	scanf("%c", &x);
	if(x<='Z'){
		x=x+32;
	}
	scanf("%s",g);
	int l,i,j,flag=l,z,y;
	l=strlen(g);
	strlwr(g);
	for(i=0;i<l;i++){
		if(g[i]==x){
			flag=l;
			z=i;
			for(j=i+l;j<l;j++){
				if(g[j]==x){
					y=j;
					flag=l;
				}
				
				
			
			}
		}
		if(flag!=2){
			break;
		}
	}
	if(flag==2){
		printf("NO");
	}
	if(flag==0){
		for(i=z;i<l;i++){
			printf("%c",g[i]);
		}
		
		
	}
	if(flag==l){
		for(i=z;i<=y;i++){
			printf("%c",b[i]);
		}
	}
	
	
	return 0;
}
