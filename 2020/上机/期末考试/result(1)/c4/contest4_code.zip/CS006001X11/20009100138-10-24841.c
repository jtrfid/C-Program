#include <stdio.h>
#include <string.h>
#include <math.h>
int main ()
{
	char gbf;
	char string_gbf[101];
	int strlen_gbf,abc=0;
	int i,p,q;
	scanf ("%c",&gbf);
	scanf ("%s",&string_gbf);
//	gets (string_gbf);
	strlen_gbf=strlen (string_gbf);
	for (i=0;i<strlen_gbf;i++)
	{
		if (string_gbf[i]>=65&&string_gbf[i]<=90)
		{
			string_gbf[i]=string_gbf[i]+32;
		}
	}
	if (gbf>=65&&gbf<=90)
	{
		gbf=gbf+32;
	}
	for (i=0;i<strlen_gbf;i++)
	{
		if (gbf==string_gbf[i]) 
		{
			p=i;
			abc++;
			break;
		}
	}
	if (abc!=0)
	{
		for (i=p+1;i<=strlen_gbf;i++)
		{
			if (gbf==string_gbf[i]||string_gbf[i]=='\n'||string_gbf[i]=='\0') 
			{
				q=i;
				break;
			}
		}
		for (i=p;i<=q;i++)
		{
			printf ("%c",string_gbf[i]);
		}
//		getch();
		return 0;
	}
	else 
	{
		printf ("NO");
//		getch();
		return 0;
	}
}