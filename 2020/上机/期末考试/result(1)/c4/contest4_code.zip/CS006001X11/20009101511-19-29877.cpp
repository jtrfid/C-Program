#include <stdio.h>

int main() {
	int n, b[] = {7, 9, 10, 5, 8, 4, 2, 1, 6, 37, 9, 10, 5, 8, 4, 2}, i, sum, j, m = 0;
	char a[10][18];
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		for (j = 0; j < 18; j++)
			scanf("%c", &a[i][j]);
	for (i = 0; i < n; i++) {
		for (j = 0; j < 17; j++) {
			if (a[i][j] < '0' || a[i][j] > '9')
				m++;

		}

		if (m != 0) {
			for (j = 0; j < 18; j++)
				printf("%c", a[i][j]);
			printf("\n");
		} else {
			sum = 0;
			for (j = 0; j < 17; j++)
				sum = sum + a[i][j] * b[i];
			sum = sum % 11;
			switch (sum) {
				case 0:
					if (a[i][17] != 1)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 1:
					if (a[i][17] != 0)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 2:
					if (a[i][17] != 1)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 3:
					if (a[i][17] != 9)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 4:
					if (a[i][17] != 8)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 5:
					if (a[i][17] != 7)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 6:
					if (a[i][17] != 6)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 7:
					if (a[i][17] != 5)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 8:
					if (a[i][17] != 4)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 9:
					if (a[i][17] != 3)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
				case 10:
					if (a[i][17] != 2)
						for (j = 0; j < 18; j++)
							printf("%c", a[i][j]);
					printf("\n");
					break;
			}
		}
		printf("\n");
	}
}