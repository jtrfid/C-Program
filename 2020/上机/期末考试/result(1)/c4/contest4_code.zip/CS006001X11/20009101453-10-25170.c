#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	char a[100],xx,x,tem,X;
	int len,i;
	scanf("%c",&x);
	scanf("%s",a);
	X=x+32;
	xx=x-32;
	len=strlen(a);
	for(i=0;i<len;i++)
	{
		if(a[i]==x)
		break;
		if(a[i]==X)
		break;
		if(a[i]==xx)
			break;
		if(i==len-1)
		printf("NO");
	}
	printf("%c",a[i]);
	for(i=i+1;i<len;i++)
	{
		printf("%c",a[i]);
		if(a[i]==x)
		break;
		if(a[i]==X)
		break;
		if(a[i]==xx)
			break;
	}
	return 0;
}