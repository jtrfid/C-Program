#include <stdio.h>
int main()
{
	int m,n,a[100][100],i,j,key,c1=0,c2=0,b[100],c[100],x,y,p=0,q=0,d[10],min,s=0,jishu=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(p=0;p<m;p++)
	{
		for(q=0;q<n;q++)
		{
			if(a[p][q]==key)
			{
			b[c1]=q;
			c1++;
			}
		}d[s]=p;s++;
		if(c1!=0)
		{
		printf("%d ",c1);
		for(x=0;x<c1;x++)
		{
			printf("%d ",b[x]);
		}
		}
		else{printf("0");jishu++;}
		printf("\n");
		c1=0;
	}
	if(jishu==m) printf("no");
	else{
		for(x=0;x<s;x++)
	{
		for(y=1;y<s;y++)
		{
			if(d[x]<d[y]) min=d[x];
			else min=d[y];
		}
	}
		printf("%d",min);}
}