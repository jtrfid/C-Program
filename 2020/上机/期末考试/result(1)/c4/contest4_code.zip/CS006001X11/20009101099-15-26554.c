#include<stdio.h>
int main()
{
	int m,n,i,j,k,x,y,max,f=0,a[100][200],b[200],c[100];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++) scanf("%d",&a[i][j]);
	}
	scanf("%d",&k);
	for(i=0;i<m;i++)
	{
		x=0;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==k)
			{
				b[x]=j;
				x++;
				f++;
			}
		}
		c[i]=x;
		printf("%d ",x);
		for(y=0;y<x;y++) printf("%d ",b[y]);
		printf("\n");
	}
	max=c[0];
	y=0;
	for(i=0;i<m;i++)
	{
		if(max<c[i])
		{
			max=c[i];
			y=i;
		}
	}
	if(f==0) printf("no");
	else printf("%d",y);
	return 0;
}
				

