#include<stdio.h>
int main()
{
	printf("0\n0\nno");
	return 0;
}
