#include <stdio.h>
int main()
{
	int m,n;
	int a[200][200];
	int i,j;
	int key;
	int count[200]={0};
	int max,f;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
			{
				count[i]++;
			}
		}
		printf("%d ",count[i]);
		if(count[i]!=0)
		{
			for(j=0;j<n;j++)
			{
				if(a[i][j]==key)
					printf("%d ",j);
			}
			printf("\n");
		}
		if(count[i]==0)
			printf("\n");
	}
	max=count[0];
	for(i=1;i<200;i++)
	{
		if(count[i]>max)
		{
			max=count[i];
			f=i;
		}
	}
	if(max=0)
		printf("no");
	else
	printf("%d",f);
	return 0;
}



