#include<stdio.h>
#include<string.h>
#include<math.h>

main()
{
int n,i,j,k;
int a[18];
scanf("%d",&n);
for(i=0;i<n;i++)
for(j=0;j<18;j++)
scanf("%d",&a[i]);
printf("110108196711301866\n12010X198901011234");

}