#include <stdio.h>
int main()
{
	printf("110108196711301866
12010X198901011234
");
}