#include <stdio.h>
#include <string.h>
int main()
{
	int i,n,ji=0,ou=0,chu=0,min;
	scanf("%d",&n);
    for(i=n;i<=5*n;i++)
	{
		if(i%2==0) ou++;
		if(i%2==1) ji++;
		if(i%3==0&&i%5!=0) chu++;
	}
	min=chu;
	printf("%d %d %d",ji,ou,chu);
	printf("\n");
	printf("%d",min);

	return 0;
}