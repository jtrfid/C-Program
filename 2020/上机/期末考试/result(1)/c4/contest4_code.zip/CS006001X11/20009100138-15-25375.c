#include <stdio.h>
#include <string.h>
#include <math.h>
int main ()
{
	int m_gbf,n_gbf,key_gbf,sum=0,sum_gbf[201]={0},sum1=0;
	int gbf[201][201]={0};
	int i,j,p;
	scanf ("%d%d",&m_gbf,&n_gbf);
	for (i=0;i<m_gbf;i++)
	{
		for (j=0;j<n_gbf;j++)
		{
			scanf ("%d",&gbf[i][j]);
		}
	}
	scanf ("%d",&key_gbf);
	for (i=0;i<m_gbf;i++)
	{
		for (j=0;j<n_gbf;j++)
		{
			if (gbf[i][j]==key_gbf)
			{
				sum_gbf[sum]=j;
				sum++;
			}
		}
		if (sum==0) printf ("0\n");
		else
		{
			sum1++;
			printf ("%d ",sum);
			for (p=0;p<sum;p++)
			{
				printf ("%d ",sum_gbf[p]);
			}
			printf ("\n");
		}
		sum=0;
	}
	if (sum1==0) printf ("no");
	else printf ("%d",sum1);
//	getch();
	return 0;
}