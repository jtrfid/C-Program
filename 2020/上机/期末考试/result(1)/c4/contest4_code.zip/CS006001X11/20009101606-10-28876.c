#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	char key,s[100],t,i=0;
	int flag=0,Flag=0;
	scanf("%c\n",&key);
	if(key>='A'&&key<='Z')
		key=key+'a'-'A';
	gets(s);
	for(i=0;i<=100;i++)
	{
		if(s[i]=='key'||s[i]=='key'-('a'-'A'))
		flag=i;
		break;
	}
	for(i=flag;i<=100;i++)
	{
		if((s[i]=='key'||s[i]=='key'-('a'-'A'))||s[i]=='\0')
		Flag=i;
		break;
	}
	if(flag!=0)
	{for(i=flag;i<=Flag;i++)
	printf("%c",s[i]);}
	else
		printf("no");
}