#include<stdio.h>
int main()
{
	int n,n1;
	int i=0,j=0,k=0;
	int temp,sum;
	int min;
	scanf("%d",&n);
	n1=5*n;
	for(temp=n;temp<=n1;temp++)
	{
		sum=temp;
		if(sum%2==1)
		{
			if(sum%3==0&&sum%5!=0)
				i++,k++;
			else
				i++;
		}
		else if(sum%2==0)
		{
			if(sum%3==0&&sum%5!=0)
			{
				j++,k++;
			}
			else 
				j++;
		}
	}
	min=i;
	if(j<min)
		min=j;
	if(k<min)
		min=k;
	printf("%d %d %d\n",i,j,k);
	printf("%d\n",min);
	return 0;
}