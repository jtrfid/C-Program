#include <stdio.h>

int main() {
	int i, n, a = 0, b = 0, c = 0;
	scanf("%d", &n);
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 == 1)
			a++;
		else
			b++;
		if (i % 3 == 0 && i % 5 != 0)
			c++;
	}
	printf("%d %d %d\n", a, b, c);
	if (a < b && a < c)
		printf("%d", a);
	if (b < a && b < c)
		printf("%d", b);
	if (c < a && c < b)
		printf("%d", c);
}