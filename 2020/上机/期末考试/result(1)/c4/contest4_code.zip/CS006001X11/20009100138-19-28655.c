#include <stdio.h>
#include <string.h>
#include <math.h>
int main ()
{
	int check_gbf (char *a);
	int m_gbf;
	int i,sum_gbf=0;
	char gbf[100][19];
	scanf ("%d",&m_gbf);
	for (i=0;i<m_gbf;i++)
	{
		scanf ("%s",&gbf[i]);
	}
	for (i=0;i<m_gbf;i++)
	{
		if (gbf[i][17]==check_gbf (gbf[i]))
		{
			sum_gbf++;
		}
	}
	if (sum_gbf==m_gbf)
	{
		printf ("All passed");
	}
	else
	{
		for (i=0;i<m_gbf;i++)
		{
			if (gbf[i][17]!=check_gbf (gbf[i]))
			{
				puts (gbf[i]);
			}
		}
	}
//	getch();
	return 0;
}

int check_gbf (char *a)
{
	int figure=0,figure1;
	int i;
	int b[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	for (i=0;i<17;i++)
	{
		if (*(a+i)>57||*(a+i)<48) return 'Y';
	}
	for (i=0;i<17;i++)
	{
		figure=figure+b[i]*(*(a+i));
	}
	figure1=figure%11;
	if (figure1>2)
	{
		return (60-figure1);
	}
	else
	{
		if (figure1<2) return (49-figure1);
		else return 'X';
	}
}