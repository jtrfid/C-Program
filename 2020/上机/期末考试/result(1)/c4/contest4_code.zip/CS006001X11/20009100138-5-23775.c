#include <stdio.h>
#include <string.h>
#include <math.h>
int main ()
{
	int n_gbf,odd_gbf=0,ou_gbf=0,chushu_gbf=0,dierhang_gbf;
	int i;
	scanf ("%d",&n_gbf);
	for (i=n_gbf;i<=5*n_gbf;i++)
	{
		if (i%2==1) odd_gbf++;
		if (i%2==0) ou_gbf++;
		if (i%3==0&&i%5!=0) chushu_gbf++;
	}
	dierhang_gbf=odd_gbf<ou_gbf?odd_gbf:ou_gbf;
	dierhang_gbf=dierhang_gbf<chushu_gbf?dierhang_gbf:chushu_gbf;
	printf ("%d %d %d\n%d",odd_gbf,ou_gbf,chushu_gbf,dierhang_gbf);
//	getch();
	return 0;
}