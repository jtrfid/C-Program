#include<stdio.h>
int main()
{
	int n,i,j,k=0,z,w[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2},sum,m[11]={1,0,10,9,8,7,6,5,4,3,2};
	char a[100][18];

	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%s",&a[i]);
	for(i=0;i<n;i++)
	{
		sum=0;
		for(j=0;j<17;j++)
		{
			sum=sum+w[j]*a[i][j];
		}
		sum=sum%11;
		if(a[i][17]!=m[sum]) 
		{
			for(z=0;z<18;z++)
			{
			printf("%c",a[i][z]);
			}
			printf("\n");
			k++;
		}
	}
	if(k==0) printf("ALL passed");
	return 0;
}
