#include <stdio.h>
#include <string.h>
int main()
{
	char c[100],shu;
	int len,i=0,j;
	scanf("%c",&shu);
	scanf("%s",&c);
	len=strlen(c);
	for(i=0;i<len;i++)
	{
		if(c[i]+26!=shu&&c[i]-26!=shu&&c[i]!=shu)
		{
			if(i==len-1)
			{
				printf("NO");
			}
		}
		else
		{
			break;
		}
	}
	for(i=0;i<len;i++)
	{
		if(c[i]+26==shu||c[i]-26==shu||c[i]==shu)
		{
			printf("%c",c[i]);
			for(j=i+1;j<len;j++)
			{
				if(c[j]+26!=shu&&c[j]-26!=shu&&c[j]!=shu)
				{
					printf("%c",c[j]);
				}
				else
				{
					printf("%c",shu);
					break;
				}
			}
			break;
		}
	}
	return 0;
}







