#include<stdio.h>
int main()
{
	int w[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2},n,sum,flag1=0,flag2=0,i,j;
	char str[18],m[11]={'1','0','X','9','8','7','6','5','4','3','2'},a[100][18];
	scanf("%d",&n);
	getchar();
	for (i=0;i<n;i++)
	{
		sum=0;
		flag1=0;
		gets(str);
		for (j=1;j<17;j++)
		{
			if (str[j]<='9'&&str[j]>='0')
				sum+=w[j]*(str[j]-'0');
			else {flag1++;break;}
		}
		if (flag1) {strcpy(a[flag2],str);flag2++;continue;}
		sum%=11;
		if (m[sum]!=str[17]) {strcpy(a[flag2],str);flag2++;}
	}
	if (flag2==0) printf("All passed");
	else
	{
		for(i=0;i<flag2;i++)
			puts(a[i]);
	}
}