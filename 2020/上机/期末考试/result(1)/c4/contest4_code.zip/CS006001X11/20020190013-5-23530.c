#include <stdio.h>
int main()
{
	int n,jishu=0,oushu=0,sanwu=0,i;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2!=0) jishu++;
		if(i%2==0) oushu++;
		if(i%3==0&&i%5!=0) sanwu++;
	}
	printf("%d %d %d\n",jishu,oushu,sanwu);
	printf("%d",sanwu);
}
