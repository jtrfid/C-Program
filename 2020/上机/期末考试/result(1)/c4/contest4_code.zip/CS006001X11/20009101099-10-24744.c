#include<stdio.h>
#include<string.h>
int main()
{
	char x,a[100],b[100];
	int i,l,m,n;
	scanf("%c",&x);
	scanf("%s",&a);
	strcpy(b,a);
	strupr(b);
	l=strlen(a);
	if('x'>='a') x=x-32;
	for(i=0;i<l;i++)
	{
		if(b[i]==x) 
		{
			m=i;
			break;
		}
	}
	for(i=0;i<l;i++)
	{
		if(b[i]==x) n=i;
	}
	for(i=m;i<=n;i++) printf("%c",a[i]);
	return 0;
}




