#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int temp,a[200][200],k,b[200]={0},m,n,j,i,o=0;
	scanf("%d%d",&m,&n);
	for(j=0;j<m;j++)
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[j][i]);
		}
	scanf("%d",&k);
	for(j=0;j<m;j++)
	{
		for(i=0;i<n;i++)
		{
			if(a[j][i]==k)
			{
				o=o+1;
				b[j]=b[j]+1;
			}
		}
		printf("%d ",b[j]);
		for(i=0;i<n;i++)
		{
			if(a[j][i]==k)
			{
				printf("%d ",i);
			}
		}
		printf("\n");
	}
	temp=0;
	for(i=0;i<j;i++)
	{
		if(temp<b[i])
		{
			temp=b[i];
			m=i;
		}
	}
	if(o!=0)
		printf("%d",m);
	if(o==0)
		printf("no");
	return 0;
}