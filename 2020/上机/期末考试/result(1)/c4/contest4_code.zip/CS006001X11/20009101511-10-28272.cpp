#include <stdio.h>

int main() {
	char a, b[100];
	int i, j, m = 0;
	scanf("%c", &a);
	scanf("%s", &b);
	for (i = 0; b[i] != '\0'; i++) {
		if (b[i] == a || b[i] == a + 32 || b[i] == a - 32) {
			m++;
			printf("%c", b[i]);
			for (j = i + 1; b[j] != a && b[j] != a + 32 && b[j] != a - 32 && b[j] != '\0'; j++) {
				printf("%c", b[j]);
			}
			if (b[j] != '\0')
				printf("%c", b[j]);

		}
		if (m != 0)
			break;
	}
	if (m == 0)
		printf("NO");
}