#include<stdio.h>
int main()
{
	int n,i,ji=0,ou=0,chu=0,min=1000;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2)
			ji++;
		else
			ou++;
		if(i%3==0&&i%5)
			chu++;
	}
	if(ou<min)
		min=ou;
	if(ji<min)
		min=ji;
	if(chu<min)
		min=chu;
	printf("%d %d %d\n%d",ji,ou,chu,min);
	return 0;
}
