#include<stdio.h>
int main()
{
	int i,j,m,a=0,b=0,c=0;
	scanf("%d",&m);
	for(i=m;i<=5*m;i++)
	{
		if(i%2==1)
			a++;
		if(i%2==0)
			b++;
		if(i%3==0&&i%5!=0)
			c++;
	}
	printf("%d %d %d\n",a,b,c);
	if(a<b&&a<c)
		printf("%d",a);
else if(c<b&&c<a)
		printf("%d",c);
if(b<a&&b<c)
		printf("%d",b);




	return 0;
}