#include<stdio.h>
int main()
{
	int m,n,key,i,j,t,flag=0,max=0,mark;
	int arra[200][200],stri[200][200];
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
		stri[i][0]=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
			scanf("%d",&arra[i][j]);
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0,t=1;j<n;j++)
		{
			if(arra[i][j]==key)
			{
				stri[i][0]++;
				stri[i][t]=j;
				t++;
				flag=1;
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<stri[i][0]+1;j++)
			printf("%d ",stri[i][j]);
		printf("\n");
	}
	if(flag==0)
		printf("no\n");
	else
	{
		for(i=0;i<m;i++)
		{
			if(stri[i][0]>max)
			{
				max=stri[i][0];
				mark=i;
			}
		}
		printf("%d\n",mark);
	}
	return 0;
}