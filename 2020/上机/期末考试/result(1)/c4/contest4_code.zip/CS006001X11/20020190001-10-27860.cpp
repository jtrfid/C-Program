#include<stdio.h>
int main()
{
	char x;
	int i;
	char a[100];
	scanf("%c",&x);
	getchar();
	gets(a);
	for(i=0;;i++)
	{
		if(a[i]==x)
		{
			for(;a[i]!='\0';i++)
			{printf("%c",a[i]);}
			break;
		}
	}
	printf("\n");
	printf("%c %s",x,a);
}