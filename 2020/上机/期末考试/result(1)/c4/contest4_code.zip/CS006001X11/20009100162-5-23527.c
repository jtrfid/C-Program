#include <stdio.h>

int main(void) {
	int n;
	scanf("%d", &n);
	int i, t1 = 0, t2 = 0, t3 = 0;
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 != 0)
			t1++;
		if (i % 2 == 0)
			t2++;
		if (i % 3 == 0 && i % 5 != 0)
			t3++;
	}
	int min = t1, temp = t2;
	if (t2 > t3)
		temp = t3;
	if (min > temp)
		min = temp;
	printf("%d %d %d\n%d", t1, t2, t3, min);
}