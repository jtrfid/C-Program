#include <stdio.h>
#include <string.h>
int main()
{
	char x;
	char str[100],c[100];
	int i,k=0,a,b;
	int p[2];
	scanf("%c",&x);
	scanf("%s",str);
	
	for(i=0;i<strlen(str);i++)
	{
		if(str[i]==x||str[i]+32==x||str[i]-32==x) 
		{
			p[k]=i;
			k++;
		}
	}
	if(k==2)
	{
		a=p[0];
		b=p[1];
		for(i=a;i<=b;i++)
			printf("%c",str[i]);
	}
	if(k==1)
	{
		a=p[0];
		for(i=a;i<strlen(str);i++)
			printf("%c",str[i]);
	}
	if(k==0)
		printf("NO");

	
	return 0;
}


