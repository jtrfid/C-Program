#include <stdio.h>

int main() {
	int j = 0, o = 0, c = 0, n, i, t, m;
	int a[3];
	scanf("%d", &n);
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 == 0)
			o = o + 1;
		if (i % 2 == 1)
			j = j + 1;
		if (i % 3 == 0 && i % 5 != 0)
			c = c + 1;
	}
	printf("%d %d %d\n", j, o, c);
	a[0] = j;
	a[1] = o;
	a[2] = c;
	for (i = 0; i < 2; i++)
		for (m = 0; m < 2 - i; m++)
			if (a[m] > a[m + 1]) {
				t = a[m];
				a[m] = a[m + 1];
				a[m + 1] = t;
			}
	printf("%d", a[0]);
	return 0;
}