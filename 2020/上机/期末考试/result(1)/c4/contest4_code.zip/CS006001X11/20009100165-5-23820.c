#include<stdio.h>
int main()
{
	int n,i,k;
	int ji=0,ou=0,te=0;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==1)
			ji++;
		if(i%2==0)
			ou++;
		if(i%3==0&&i%5!=0)
			te++;
	}
	if(ji<=ou)
	{
		if(ji<=te)
			k=ji;
		else
			k=te;
	}
	else
	{
		if(ou<=te)
			k=ou;
		else
			k=te;
	}
	printf("%d %d %d\n%d",ji,ou,te,k);
	return 0;
}
	


