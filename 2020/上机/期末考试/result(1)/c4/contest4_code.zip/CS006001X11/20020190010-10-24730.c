#include <stdio.h>
#include <string.h>

int main() {
	int i, j, s, p = 0;
	char n;
	char a[100];
	scanf("%c", &n);
	getchar();
	gets(a);
	s = strlen(a);
	for (i = 0; i < s; i++)
		if (a[i] == n || a[i] == n + 32 || a[i] == n - 32)
			p = 1;
	if (p == 1) {
		for (i = 0; i < s; i++)
			if (a[i] == n || a[i]	== n + 32 || a[i] == n - 32)
				break;
		printf("%c", a[i]);
		i = i + 1;
		for (; i < s; i++) {
			printf("%c", a[i]);
			if (a[i] == n || a[i] == n + 32 || a[i] == n - 32)

				break;
		}

	} else
		printf("NO");
}