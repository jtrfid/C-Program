#include <stdio.h>
#include <string.h>
int main()
{
	int n,i,sum[100],j;
	char num[20];
	int mo[100];
	int z[100],m[100];
	int zheng[100];
	int X;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",num);
		
		sum[i]=7*num[0]+9*num[1]+10*num[2]+5*num[3]+8*num[4]+4*num[5]+2*num[6]+1*num[7]+6*num[8]+3*num[9]+7*num[10]+9*num[11]+10*num[12]+5*num[13]+8*num[14]+4*num[15]+2*num[16];
	    mo[i]=sum[i]%11;
		m[i]=num[17];
	
  	   for(i=0;i<n;i++)
	   {   
		if(mo[i]==0) z[i]=1;
		if(mo[i]==1) z[i]=0;
		if(mo[i]==2) z[i]=X;
		if(mo[i]==3) z[i]=9;
		if(mo[i]==4) z[i]=8;
		if(mo[i]==5) z[i]=7;
		if(mo[i]==6) z[i]=6;
		if(mo[i]==7) z[i]=5;
		if(mo[i]==8) z[i]=4;
		if(mo[i]==9) z[i]=3;
		if(mo[i]==10) z[i]=2;
	   }
	   for(i=0;i<n;i++)
	   {
		if(z[i]!=m[i]) printf("%d",num);
	   }
	   }
	return 0;
}







