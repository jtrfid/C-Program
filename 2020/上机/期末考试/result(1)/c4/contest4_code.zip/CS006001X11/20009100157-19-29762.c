#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int n, i, sum, j, flag = 0, k, z, rcd = 0;
	scanf("%d", &n);
	char id[n][19];
	for (i = 0; i < n; i++) {
		for (j = 0; j <= 18; j++) {
			scanf("%c", &id[i][j]);
		}
	}
	for (i = 0; i < n; i++) {
		sum = 7 * (id[i][1] - '0') + 9 * (id[i][2] - '0') + 10 * (id[i][3] - '0') + 5 * (id[i][4] - '0') + 8 *
		      (id[i][5] - '0') + 4 * (id[i][6] - '0') + 2 * (id[i][7] - '0') + 1 * (id[i][8] - '0') + 6 * (id[i][9] - '0') + 3 *
		      (id[i][10] - '0') + 7 * (id[i][11] - '0') + 9 * (id[i][12] - '0') + 10 * (id[i][13] - '0') + 5 *
		      (id[i][14] - '0') + 8 * (id[i][15] - '0') + 4 * (id[i][16] - '0') + 2 * (id[i][17] - '0');
	}
	z = sum % 11;
	printf("All passed");
	return 0;
}