#include <stdio.h>
#include <string.h>

int main() {
	char a;
	char aa[200];
	int flag1 = -1, flag2 = -1;
	scanf("%c\n", &a);
	if (a >= 'a' && a <= 'z') {
		a -= 32;
	}
	gets(aa);
	int i, j = 0;
	for (i = 0; i < strlen(aa); i++) {
		if (aa[i] == a || aa[i] == a + 32) {
			flag1 = i;
			break;
		}
	}
	for (i = flag1 + 1; i < strlen(aa); i++) {
		if (aa[i] == a || aa[i] == a + 32 || i + 1 == strlen(aa)) {
			flag2 = i;
			break;
		}
	}
	if (flag1 != -1 && flag2 != -1) {
		for (i = flag1; i <= flag2; i++)
			printf("%c", aa[i]);
	} else {
		printf("NO");
	}
	return 0;
}