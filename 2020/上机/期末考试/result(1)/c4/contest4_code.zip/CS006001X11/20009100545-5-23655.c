#include<stdio.h>
int main()
{
	int n,i,j,countji=0,countou=0,countqita=0,min;
	scanf("%d",&n);
	min=5*n+1;
	for(i=n;i<=5*n;i++)
	{
		if(i%2!=0) countji++;
		if(i%2==0) countou++;
		if(i%3==0&&i%5!=0) countqita++;
	}
	if(countji<min) min=countji;
	if(countou<min) min=countou;
	if(countqita<min) min=countqita;
	printf("%d %d %d",countji,countou,countqita);
	printf("\n");
	printf("%d",min);
	return 0;
}

