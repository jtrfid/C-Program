#include <stdio.h>
#include <string.h>
int main()
{
	char zheng[100][20]={'0'};
	int n,d[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	int sum[100]={0},z,t0=1,t1,i,j,t2;
	scanf("%d",&n);
	n++;
	for(i=0;i<n;i++)
	{
		gets(zheng[i]);
	}
	for(i=0;i<n;i++)
	{
		t1=0;
		t2=0;
		for(j=0;j<17;j++)
		{
			if(zheng[i][j]>='0'&&zheng[i][j]<='9')
				t1=t1+1;
		}
		for(j=0;j<17;j++)
		{
			sum[i]=sum[i]+(zheng[i][j]-48)*d[j];
		}
		z=sum[i]%11;
		if(z==0&&zheng[i][17]=='1') t2=1;
		if(z==1&&zheng[i][17]=='0') t2=1;
		if(z==2&&zheng[i][17]=='x') t2=1;
		if(z>=3&&z+(zheng[i][17]-48)==12) t2=1;
		if(t1!=17&&t2!=1)
		{
			puts(zheng[i]);
			t0=0;
		}
	}
	if(t0==1) printf("All passed");
}





