#include <stdio.h>
#include <string.h>
int main()
{
	char ch,str[100];
	int i,n,start,end;
	scanf("%c",&ch);
	getchar();
	if(ch>='a'&&ch<='z')
		ch-=32;
	gets(str);
	n=strlen(str);
	end=n;
	start=0;
	for(i=0;i<n;i++)
	{
		if(str[i]==ch||str[i]==ch+32)
		{
			start=i;
			for(i=i+1 ;i<n;i++)
			{
				if(str[i]==ch||str[i]==ch+32)
				{
					end=i;
					break;
				}
			}
			break;
		}
	}
	if(start==0)
	{
		printf("NO");
		return 0;
	}
	else
	{
		for(i=start;i<=end;i++)
			printf("%c",str[i]);
	}
	return 0;
}

		
		

