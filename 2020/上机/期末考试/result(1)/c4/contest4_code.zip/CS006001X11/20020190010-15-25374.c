#include <stdio.h>

int main() {
	int x, m, n, i, j, c, max, d = 0,p=0;
	int a[200] = {0};
	int b[200][200] = {0};
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &b[i][j]);
	scanf("%d", &x);
	for (i = 0; i < m; i++) {
		c = 0;
		for (j = 0; j < n; j++) {
			if (b[i][j] == x)
				c = c + 1;
		}
		printf("%d ", c);
		for (j = 0; j < n; j++) {
			if (b[i][j] == x)
				printf("%d ", j);
		}
		printf("\n");
		a[i] = c;
	}
	for(i=0;i<m;i++)
	if(a[i]!=0) p=1;
	if(p==1) 
	{
		max = a[0];
	for (i = 1; i < m; i++)
		if (a[i] > max)

		{
			max = a[i];
			d = i;
		}
	printf("%d", d);
	}
	else printf("no");
}