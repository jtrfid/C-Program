#include<stdio.h>
int main()
{
	int a,b=0,c=0,d=0,i,j,k,n,min;
	scanf("%d",&n);
	a=5*n;
	for(i=n;i<=a;i++)
	{
		if(i%2!=0)
			b++;
		if(i%2==0)
			c++;
		if(i%3==0&&i%5!=0)
			d++;
	}
	min=b;
	if(min>c)
		min=c;
	if(min>d)
		min=d;


	printf("%d %d %d\n%d",b,c,d,min);
}