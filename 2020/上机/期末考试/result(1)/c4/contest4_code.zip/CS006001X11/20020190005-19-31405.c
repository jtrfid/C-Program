#include <stdio.h>
#include <string.h>
int main()
{
	int n,i,sum[100],j;
	int num[20];
	int mo[100];
	int z[100],m[100];
	int zheng[100];
	int a[100];
	int X;
	int p=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
	}
	for(i=0;i<n;i++)
	{ 
		while(num[i]!=0)
		{
			a[p]=num[i]%10;
			p++;
			num[i]=num[i]/10;
		}
		sum[i]=7*a[0]+9*a[1]+10*a[2]+5*a[3]+8*a[4]+4*a[5]+2*a[6]+1*a[7]+6*a[8]+3*a[9]+7*a[10]+9*a[11]+10*a[12]+5*a[13]+8*a[14]+4*a[15]+2*a[16];
       mo[i]=sum[i]%11;
		m[i]=num[17];
	
  	   for(i=0;i<n;i++)
	   {   
		if(mo[i]==0) z[i]=1;
		if(mo[i]==1) z[i]=0;
		if(mo[i]==2) z[i]=X;
		if(mo[i]==3) z[i]=9;
		if(mo[i]==4) z[i]=8;
		if(mo[i]==5) z[i]=7;
		if(mo[i]==6) z[i]=6;
		if(mo[i]==7) z[i]=5;
		if(mo[i]==8) z[i]=4;
		if(mo[i]==9) z[i]=3;
		if(mo[i]==10) z[i]=2;
	   }
	   for(i=0;i<n;i++)
	   {
		if(z[i]!=m[i]) printf("%d",num);
	   }
	   }
	
	return 0;
}







