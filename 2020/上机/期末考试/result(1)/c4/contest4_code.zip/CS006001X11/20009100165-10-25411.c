#include<stdio.h>
#include<string.h>
int main()
{
	char te;
	char str[100];
	int i,j,k,ci=0;
	scanf("%c",&te);
	scanf("%s",&str);
	if(te>='a'&&te<='z')
		te=te+'A'-'a';
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==te||str[i]==te-'A'+'a')
		{
			ci++;
			for(j=i+1;str[j]!='\0';j++)
			{
				while(str[j]==te||str[j]==te-'A'+'a')
				{
					for(k=i;k<=j;k++)
						printf("%c",str[k]);
					ci++;
					break;
				}
				if(str[j+1]=='\0'&&ci==1)
					for(k=i;str[k]!='\0';k++)
						printf("%c",str[k]);
			}break;
		}
	}
	if(ci==0)
		printf("NO");
	return 0;
}

			
