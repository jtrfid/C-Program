#include <stdio.h>
#include <string.h>

int main() {
	char str[100], c;
	int l, i, j, sum = 0;
	scanf("%c", &c);
	gets(str);
	l = strlen(str);
	for (i = 0; i < l; i++) {
		if (str[i] == c || str[i] == c + 32 || str[i] == c - 32) {
			printf("%c", str[i]);
			for (j = i + 1; j < l; j++) {
				if (str[j] == c || str[j] == c + 32 || str[j] == c - 32) {
					break;
				} else
					printf("%c", str[j]);
			}
			if (j != l)
				printf("%c", str[j]);
			sum = 1;
			break;
		}
	}
	if (sum == 0)
		printf("NO");
	return 0;

}