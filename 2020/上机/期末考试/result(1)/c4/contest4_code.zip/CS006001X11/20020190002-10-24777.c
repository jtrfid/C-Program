#include<stdio.h>
#include<string.h>
int main()
{
	char a,b;
	char str[100];
	int len,i,j,flag=0;
	scanf("%c",&a);
	scanf("%s",&str);
	len=strlen(str);
	if(a<90)b=a+32;
	else b=a-32;
	for(i=0;i<len;i++)
	{
		if(str[i]==a||str[i]==b)
		{
			flag++;
			for(j=i;j<len-i;j++)
			{
				printf("%c",str[j]);
				if(str[j+1]==a||str[j+1]==b||str[j+1]==0)
				{
					printf("%c",str[j+1]);
					break;
				}
			}
		}
	}
	if(flag==0)
		printf("NO");
	return 0;
}