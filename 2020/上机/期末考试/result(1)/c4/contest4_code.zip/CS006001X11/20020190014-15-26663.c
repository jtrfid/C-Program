#include <stdio.h>
int main()
{
	int m,n,key,i,j;
	int a[100][100],flag=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
		{	scanf("%d",&a[i][j]);}
		scanf("%d",&key);
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
		{
			if(a[i][j]!=key)
				flag++;
		}
		if(flag==m*n)
			printf("0\n0\nno");
}


