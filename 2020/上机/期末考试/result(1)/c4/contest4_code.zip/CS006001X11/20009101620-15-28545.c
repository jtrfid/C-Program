#include<stdio.h>
int main()
{
	int m,n,key;
	int mat[201][201]={0};
	int sum[201][201]={0};
	int i,j,k;
	int max;
	int sea=0;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&mat[i][j]);
		}
	}
	scanf("%d",&key);
	k=1;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(mat[i][j]==key)
			{
				sum[i][0]++;
				sum[i][k]=j;
				k++;
			}
			else
				continue;
		}
	}
	for(i=0;i<m;i++)
	{
		if(sum[i][0]!=0)
			sea++;
		else
			continue;
	}
	max=sum[0][0];
	for(i=0;i<m;i++)
	{
		if(sum[i][0]>max)
			max=sum[i][0];
		else
			continue;
	}
	for(i=0;i<m;i++)
	{
		if(sea==0)
		{
			for(j=0;j<m;j++)
				printf("0\n");
			printf("no\n");
			break;
		}
		else
		{
			if(sum[i][0]==0)
				printf("0\n");
			else
			{
				printf("%d ",sum[i][0]);
				for(j=1;j<=sum[i][0];j++)
				{
					printf("%d ",sum[i][j]);
				}
				printf("\n");
			}
		}
	}
	if(sea!=0)
		printf("%d\n",max-1);
	return 0;
}