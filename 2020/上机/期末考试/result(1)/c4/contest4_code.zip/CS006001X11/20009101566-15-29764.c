#include <stdio.h>
int main()
{
	int a[200][200],m,n,i,j,key;
	int g=0,w[100],s=0,x,temp=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);     //shuru
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
			{
				g=g+1;
				w[s]=j;
				s=s+1;
			}
			if(j==n-1&&g!=0)
			{
				printf("%d ",g);
				for(x=0;x<g;x++)
				{
					printf("%d ",w[x]);
				}
				printf("\n");
				temp=g;
				g=0;
				s=0;
			}
			if(j==n-1&&temp==0)
			{
				printf("0\n");
				g=0;
				s=0;
			}
		}
	}
}




