#include<stdio.h>
int main()
{
	int n,a=0,b=0,c=0,i;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2) a++;
		else b++;
		if(i%3==0&&i%5!=0) c++;
	}
	printf("%d %d %d\n",a,b,c);
	if (b<a) a=b;
	if (c<a) a=c;
	printf("%d",a);

}