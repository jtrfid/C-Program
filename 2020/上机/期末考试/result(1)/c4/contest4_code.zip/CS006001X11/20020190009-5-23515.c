#include <stdio.h>

int main() {
	int i, j, n;
	scanf("%d", &n);
	int ans1 = 0, ans2 = 0, ans3 = 0;
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 == 1)
			ans1++;
		if (i % 2 == 0)
			ans2++;
		if (i % 3 == 0 && i % 5 != 0)
			ans3++;
	}
	printf("%d %d %d\n", ans1, ans2, ans3);
	if (ans1 > ans2) {
		j = ans2;
	} else {
		j = ans1;
	}
	if (j > ans3)
		printf("%d", ans3);
	else
		printf("%d", j);
	return 0;
}