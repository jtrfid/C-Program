#include <stdio.h>
#include <string.h>

int find(char s[], char x, int begin) {
	int leng = strlen(s);
	for (int i = 0; i < leng; i++) {
		if (s[i] == x)
			return i;
	}
	return -1;
}

int main() {
	char str[1000];
	char str_t[1000];
	char x;
	scanf("%c", &x);
	scanf("%s", str);
	if (x  >='A' && x <= 'Z')
		x += 32;
	int leng = strlen(str);
	for (int i = 0; i < leng; i++) {
		if (str[i] >= 'A' && str[i] <= 'Z')
			str_t[i] = (char)(str[i] + 32);
		else
			str_t[i] = str[i];
	}
	int judge;
	if (find(str, x, 0) == -1)
		printf("NO");
	else {
		judge = find(str, x, judge);
	}
	if (find(str, x, judge + 1) == -1)
		for (int i = judge; i < leng; i++)
			printf("%c", str[i]);
	else {
		int judge1 = find(str, x, judge + 1);
		for (int i = judge; i <= judge1; i++)
			printf("%c", str[i]);
	}

}