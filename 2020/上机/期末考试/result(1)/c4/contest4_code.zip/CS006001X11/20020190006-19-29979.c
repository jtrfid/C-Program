#include<stdio.h>
#include<string.h>
int main()
{
	char fac(int z);
	int n;
	char s[100][19];
	int i,j;
	int sum;
	int z,m;
	int b[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	int t=1;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		gets(s[i]);
	for(i=0;i<n;i++)
	{
		sum=0;
		for(j=0;j<17;j++)
		{
			if(s[i][j]>='0'&&s[i][j]<='9')
				sum+=(s[i][j]-48)*b[j];
			else
			{
				puts(s[i]);
				t=0;
				continue;
			}
			z=sum%11;
			m=fac(z);
			if(s[i][17]!=m)
			{
				puts(s[i]);
				t=0;
			}
		}
	}
	if(t)
		printf("All passed");
	return 0;
}
char fac(int z)
{
	char m;
	switch(z)
	{
	case 0:m=1;break;
	case 1:m=0;break;
	case 2:m='X';break;
	case 3:m=9;break;
	case 4:m=8;break;
	case 5:m=7;break;
	case 6:m=6;break;
	case 7:m=5;break;
	case 8:m=4;break;
	case 9:m=3;break;
	case 10:m=2;break;
	}
	return(m);
}