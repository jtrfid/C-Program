#include<stdio.h>
int main()
{
	int n;
	int i;
	int ji=0,ou=0,count=0;
	int min;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			ou++;
		if(i%2!=0)
			ji++;
		if(i%3==0&&i%5!=0)
			count++;
	}
	min=ji;
	if(ou<min)
		min=ou;
	if(count<min)
		min=count;
	printf("%d %d %d",ji,ou,count);
	printf("%d",min);
	return 0;
}