#include <stdio.h>

int main(void) {
	printf("All passed");
}

//A 65 Z90
//a 97
//0 48                  9 57