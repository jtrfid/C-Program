#include<stdio.h>
#include<string.h>
int main()
{
	char c,t;
	char str[100],a[100];
	int n,i,j=0,flag=0;
	scanf("%c",&c);
	getchar();
	gets(str);
	n=strlen(str);
	if(c<='z'&&c>='a')
		t=c-32;;
	if(c<='Z'&&c>='A')
		t=c+32;
	for(i=0;i<n;i++)
	{
		if(str[i]==c||str[i]==t)
		{
			flag=1;
			a[0]=c;
			i++;
			j++;
			while(str[i]!=c&&str[i]!='\0'&&str[i]!=t)
			{
				a[j++]=str[i];
				i++;
			}
			a[j++]=str[i];
			break;
		}
	}
	if(flag==0)
		printf("no");
	else
	{
	for(i=0;i<j;i++)
		printf("%c",a[i]);
	}
}



	

		
	

