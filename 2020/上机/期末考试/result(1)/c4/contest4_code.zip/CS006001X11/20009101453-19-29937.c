#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int Z,i,n,jiao[100],sum[100]={0},d[17],j,k,w[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	char hao[18],pass,M[11]={'1','0','X','9','8','7','6','5','4','3','2'};
	scanf("%d",&n);
	for(j=0;j<n;j++)
	{
			scanf("%s",hao);
			jiao[j]=hao[17];
			for(k=0;k<17;k++)
			if(hao[k]=='X')
				pass=1;
	    for(i=0;i<17;i++)
		{
			d[i]=hao[i]-48;
			sum[j]=sum[j]+w[i]*d[i];
		}
		Z=sum[j]%11;
		if(M[Z]!=jiao[j])
			pass=1;
		if(pass==1)
		{
			printf("%s",hao);
			continue;
		}
	}
	if(pass!=1)
		printf("All passed");
	return 0;
}
