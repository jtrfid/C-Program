#include<stdio.h>
#include<string.h>
int main()
{
	int flag=0,i;
	char x,a[100],s[100];
	scanf("%c",&x);
	getchar();
	gets(a);
	strcpy(s,a);
	strlwr(s);
	if (x>='A'&&x<='Z') x+=32;
	i=0;
	while(s[i]!=0)
	{
		if (s[i]==x) flag++;
		if (flag==0) {i++;continue;}
		if (flag==1) printf("%c",a[i]);
		if (flag==2) {printf("%c",a[i]);break;}
		i++;
	}
	if (!flag) printf("NO");
}