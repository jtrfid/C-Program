#include <stdio.h>
int main()
{
	printf("All passed");
}