#include<stdio.h>
int main()
{
	int n,i;
	int js=0;
	int os=0;
	int num=0;
	int min;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			os++;
		if(i%2!=0)
			js++;
		if(i%3==0&&i%5!=0)
			num++;
	}
	min=os;
	if(js<min)
		min=js;
	if(num<min)
		min=num;
	printf("%d %d %d\n%d",js,os,num,min);
	return 0;



}