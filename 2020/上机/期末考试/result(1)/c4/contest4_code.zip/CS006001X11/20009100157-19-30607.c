#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int n, i, sum, j, flag = 0, k, z, rcd = 0;
	scanf("%d", &n);
	char id[n][19];
	for (i = 0; i < n; i++) {
		for (j = 0; j < 19; j++)
			scanf("%c", &id[i][j]);
	}
	for (i = 0; i < n; i++) {
		flag = 0;
		for (j = 1; j <= 17; j++) {
			if (id[i][j] < '0' || id[i][j] > '9') {
				rcd++;
				flag++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
				break;
			}
		}
		if (flag == 0) {
			sum = 7 * (id[i][1] - '0') + 9 * (id[i][2] - '0') + 10 * (id[i][3] - '0') + 5 * (id[i][4] - '0') + 8 *
			      (id[i][5] - '0') + 4 * (id[i][6] - '0') + 2 * (id[i][7] - '0') + 1 * (id[i][8] - '0') + 6 * (id[i][9] - '0') + 3 *
			      (id[i][10] - '0') + 7 * (id[i][11] - '0') + 9 * (id[i][12] - '0') + 10 * (id[i][13] - '0') + 5 *
			      (id[i][14] - '0') + 8 * (id[i][15] - '0') + 4 * (id[i][16] - '0') + 2 * (id[i][17] - '0');
		}
		z = sum % 11;
		if (z == 0) {
			if (id[18] != '1') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 1) {
			if (id[18] != '0') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 2) {
			if (id[18] != 'X') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 3) {
			if (id[18] != '9') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 4) {
			if (id[18] != '8') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 5) {
			if (id[18] != '7') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}

		}

		else if (z == 6) {
			if (id[18] == '6') {
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("%c", id[i][18]);
				printf("%d", rcd);
				printf("\n");
			}
		} else if (z == 7) {
			if (id[18] != '5') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 8) {
			if (id[18] != '4') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 9) {
			if (id[18] != '3') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		} else if (z == 10) {
			if (id[18] != '2') {
				rcd++;
				for (k = 1; k <= 18; k++) {
					printf("%c", id[i][k]);
				}
				printf("\n");
			}
		}
	}
	if (rcd == 0)
		printf("All passed");
	return 0;
}