#include<stdio.h>
int main()
{
	int in,ji=0,ou=0,sw=0,i,min;
	scanf("%d",&in);
	for(i=in;i<=in*5;++i)
	{
		if(i%2==1)
			++ji;
		if(i%2==0)
			++ou;
		if(i%3==0&&i%5!=0)
			++sw;
	}
	if(ji<ou)
		min=ji;
	else
		min=ou;
	if(sw<min)
		min=sw;
	printf("%d %d %d\n%d",ji,ou,sw,min);
	return 0;
}