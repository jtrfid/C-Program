#include<stdio.h>
#include<string.h>
int main()
{
	int i,j,n,a[100],sum=0;
	char x[100][18];
	scanf("%d",&n);
	scanf("\n");
	for(i=0;i<n;i++)
		gets(x[i]);
	
	for(i=0;i<n;i++)
	{
		int z=0;
		for(j=0;j<17;j++)
			if(x[i][j]<'0'||x[i][j]>'9')
			{
				puts(x[i]);
			break;z=1;
			}
			if(z==0)
			{
		int owe=0;
		a[i]=(x[i][0]-48)*7+(x[i][1]-48)*9+(x[i][2]-48)*10+(x[i][3]-48)*5+(x[i][4]-48)*8+(x[i][5]-48)*4+(x[i][6]-48)*2+(x[i][7]-48)*1+(x[i][8]-48)*6+(x[i][9]-48)*3+(x[i][10]-48)*7+(x[i][11]-48)*9+(x[i][12]-48)*10+(x[i][13]-48)*5+(x[i][14]-48)*8+(x[i][15]-48)*4+(x[i][16]-48)*2;
		owe=a[i]%11;
		if(owe==0&&x[i][17]=='1'||owe==1&&x[i][17]=='0'||owe==2&&x[i][17]=='X'||owe==3&&x[i][17]=='9'||owe==4&&x[i][17]=='8'||owe==5&&x[i][17]=='7'||owe==6&&x[i][17]=='6'||owe==7&&x[i][17]=='5'||owe==8&&x[i][17]=='4'||owe==9&&x[i][17]=='3'||owe==10&&x[i][17]=='2')
			sum++;
		else
			puts(x[i]);
			}
	}
	if(sum==n)
		printf("All passed");
	return 0;
}