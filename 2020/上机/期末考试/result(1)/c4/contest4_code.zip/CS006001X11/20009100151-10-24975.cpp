#include<stdio.h>
#include<math.h>
#include<string.h>
int main ()
{
	char a;
	char str[100],array[100];
	int i,j,len,op,ed,temp=0;
	scanf("%c",&a);
	scanf("%s",&str);
	len=strlen(str);
	strcpy(array,str);
	if(a>='A'&&a<='Z')
		a=a+32;
	for(i=0;i<len;i++)
	{
		if(str[i]>='A'&&str[i]<='Z')
			str[i]=str[i]+32;
	}
	for(i=0;i<len;i++)
	{
		if(str[i]==a&&temp==1)
		{
			ed=i;
			break;
		}
		if(str[i]==a&&temp==0)
		{
			op=i;
			temp=1;
		}
	}
	if(temp==1)
	{
		for(i=op;i<=ed;i++)
	{
		printf("%c",array[i]);
	}
	}
	if(temp==0)
		printf("no");

}


		