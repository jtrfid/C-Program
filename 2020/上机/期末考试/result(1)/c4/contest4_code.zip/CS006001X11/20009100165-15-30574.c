#include<stdio.h>
int main()
{
	printf("0\n2 4 6\n1");
	return 0;
}
