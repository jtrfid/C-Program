#include <stdio.h>
#include <string.h>

int main() {
	int i = 0, j = 0, ou = 0, q = 0, flag = 0, n, max;
	scanf("%d", &n);
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 == 0)
			ou++;
		else
			j++;
		if (i % 3 == 0 & i % 5 != 0)
			q++;
		max = ( ou < j) ? ou : j;
		max = (max < q) ? max : q;
	}
	printf("%d %d %d\n%d", j, ou, q, max);
}
