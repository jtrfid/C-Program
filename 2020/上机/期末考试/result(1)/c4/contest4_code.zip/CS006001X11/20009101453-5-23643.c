#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int n,i,j,ji=0,ou=0,sw=0,max;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			ou=ou+1;
		if(i%2==1)
			ji=ji+1;
		if(i%3==0&&i%5!=0)
			sw=sw+1;
	}
	printf("%d %d %d\n",ji,ou,sw);
	max=ji;
	if(max>ou)
		max=ou;
	if(max>sw)
		max=sw;
	printf("%d",max);
	return 0;
}