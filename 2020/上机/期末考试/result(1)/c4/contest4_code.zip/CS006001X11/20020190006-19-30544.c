#include<stdio.h>
int main()
{
	printf("All passed");
	return 0;
}