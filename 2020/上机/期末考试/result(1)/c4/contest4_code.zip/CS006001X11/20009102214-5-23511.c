#include<stdio.h>
#include<string.h>
int main()
{
	int n,i;
	int temp1=0,temp2=0,temp3=0,min=0;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			temp1++;
		if(i%2!=0)
			temp2++;
		if(i%3==0&&i%5!=0)
			temp3++;
	}
	if(temp1>temp2)
		min=temp2;
	else
		min=temp1;
	if(temp2>temp3)
		min=temp3;
	else
		min=temp2;
	printf("%d %d %d\n%d",temp2,temp1,temp3,min);
}


