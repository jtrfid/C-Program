#include <stdio.h>

char c[100][30];
int main(void) {
	int check(int i);
	int n;
	scanf("%d", &n);
	int i, j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < 18; j++)
			scanf("%c", &c[i][j]);
	}
	int mod[n], flag = 0, sign = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < 18; j++) {
			if (c[i][j] < 48 || c[i][j] > 57) {
				flag = 1;
				sign = 1;
				for (j = 0; j < 18; j++)
					printf("%c", c[i][j]);
				printf("\n");
			}
		}
		if (flag == 0) {
			mod[i] = check(i);
			if (mod[i] == c[i][17] - 48)
				continue;
			else {
				for (j = 0; j < 18; j++)
					printf("%c", c[i][j]);
				sign = 1;
				printf("\n");
			}
		}
		flag = 0;
	}
	if (sign == 0)
		printf("All passed");
}

int check(int i) {
	int sum, mod;
	sum = 7 * (c[i][0] - 48) + 9 * (c[i][1] - 48) + 10 * (c[i][2] - 48) + 5 * (c[i][3] - 48) + 8 * (c[i][4] - 48) + 4 *
	      (c[i][5] - 48) + 2 * (c[i][6] - 48) + 1 * (c[i][7] - 48) + 6 * (c[i][8] - 48) + 3 * (c[i][9] - 48) + 7 *
	      (c[i][10] - 48) + 9 * (c[i][11] - 48) + 10 * (c[i][12] - 48) + 5 * (c[i][13] - 48) + 8 * (c[i][14] - 48) + 4 *
	      (c[i][15] - 48) + 2 * (c[i][16] - 48);
	mod = sum % 11;
	return mod;
}