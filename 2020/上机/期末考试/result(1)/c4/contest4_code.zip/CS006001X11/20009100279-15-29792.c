#include <stdio.h>

void main()
{
	int row, col;
	int mat[100][100];
	int find, write = 0;
	int findmtx[100] = {0};
	int flag = 0;
	int finds[100][100] = {0};
	int i, j;
	int lines[100][1] = {0};
	scanf("%d%d", &row, &col);
	for (i = 0; i < row; i++)
	{
		for(j = 0; j < col; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	scanf("%d", &find);
	for(i = 0; i < row; i++)
	{
		for(j = 0; (j < col); j++)
		{
			if (mat[i][j] == find)
			{
				findmtx[i]++;
				flag = 1;
				finds[i][write++] = j;
			}
		}
		write = 0;
	}
	for (i = 0; i < row; i++)
	{
		printf("%d ", findmtx[i]);
		for(j = 0; finds[i][j] != 0; j++)
		{
			printf("%d ", finds[i][j]);
		}
		printf("\n");
	}

	for(i = 0; i < row; i++) lines[i][0] = findmtx[i]; 
	for(i = 0; i < row; i++)
	{
		for(j = 0; j < row; j++)
		{
			if(findmtx[i] < findmtx[i+1])
			{
				int temp;
				temp = findmtx[i];
				findmtx[i] = findmtx[i+1];
				findmtx[i+1] = temp;
			}
		}
	}
	if(!flag) printf("no");
	else
	{
		for(i = 0; i < row; i++)
		{
			if (lines[i][0] == findmtx[0]){ printf("%d", i); break;}
		}
	}

	/*
	int times[100][4] = {0};
	for (i = 0; (i < row); i++)
	{
		printf("%d ", findmtx[i]);
		for(j = 0; finds[i][j] != 0; j++)
		{
			printf("%d ", finds[i][j]);
			times[i][0] += 1;
		}
		printf("\n");
	}
	for( i = 0; (i < row); i++)
	{
		for(j = 0;( j < row); j++)
		{
			if(times[j][0] < times[j+1][0])
			{
				int temp = times[j][0];
				times[j][0] = time[j + 1][0];
				times[j + 1][0] = temp;
			}
		}
	}
	printf("%d", times[0][0]);*/
	getchar();getchar();
}