#include<stdio.h>
#include<string.h>
#include<math.h>

main()
{
	char x;
	char str[100],str1[100];
	int n,i,k,j,temp=0;
	scanf("%c",&x);
	scanf("%s",&str);
	n=strlen(str);
		for(i=0;i<n;i++)
			if((str[i]==x+('A'-'a'))||(str[i]==x-('A'-'a')))
				temp++;

	for(i=0;i<n;i++)
		if((str[i]==x+('A'-'a'))||(str[i]==x-('A'-'a')))
		{
		for(;i<n;i++)
		{
			printf("%c",str[i]);
			if((str[i+1]==x+('A'-'a'))||(str[i+1]==x-('A'-'a')))
				break;
		}
		}
if(temp==0)
printf("NO");
}