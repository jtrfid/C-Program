#include<stdio.h>
int main()
{
	int n,i,j,k=0,w[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2},z[11],sum;
	int a[100][18],m[11]={1,0,10,9,8,7,6,5,4,3,2};

	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%s",&a[i]);
	for(i=0;i<n;i++)
	{
		sum=0;
		for(j=0;j<17;j++)
		{
			sum=sum+w[j]*a[i][j];
		}
		sum=sum%11;
		if(a[i][17]!=m[sum]) 
		{
			printf("%s\n",a[i]);
			k++;
		}
	}
	if(k==0) printf("ALL passed");
	return 0;
}

3
320124198808240056
110108196711301866
12010X198901011234
