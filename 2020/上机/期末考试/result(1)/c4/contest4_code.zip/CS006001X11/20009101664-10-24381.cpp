#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int i,j,sigh=0,m=0;
	char a,x[100],y[100];
	scanf("%c",&a);
	scanf("\n");
	gets(x);
	for(i=0;i<strlen(x);i++)
		if(x[i]==a||abs(x[j]-a)==32)
		{
			sigh=1;
			y[m++]=x[i];
			break;
		}

		if(sigh==1)
		{
		for(j=i+1;x[j]!=a&&abs(x[j]-a)!=32;j++)
		{
			y[m++]=x[j];
			if(j==strlen(x)-1)
				break;
		}
		puts(y);
		}
		else if(sigh==0)
			printf("NO");
	return 0;
}