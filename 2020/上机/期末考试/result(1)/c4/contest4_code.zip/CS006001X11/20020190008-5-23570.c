#include<stdio.h>
int main()
{
	int n,x=0,y=0,z=0;
	int i,min;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2!=0)
			x++;
		if(i%2==0)
			y++;
		if(i%3==0&&i%5!=0)
			z++;
	}
	min=x;
	if(y<min)
		min=y;
	if(z<min)
		min=z;
	printf("%d %d %d\n",x,y,z);
	printf("%d\n",min);
}


		
	

