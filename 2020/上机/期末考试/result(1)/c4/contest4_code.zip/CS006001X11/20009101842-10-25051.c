#include<stdio.h>
#include<string.h>
int main()
{
	char s[100]={'\0'},b[100]={'\0'};
	char m;
	int a,c,i,j,k,n;
	scanf("%c\n",&m);
	gets(s);
	for(i=0;s[i]!='\0';i++)
	{
		if(s[i]==m||s[i]==m-32)
		{
			b[0]=m;
			for(j=1,k=i+1;s[k]!='\0';j++)
			{
				b[j]=s[k];
				k++;
				if(s[k]==m||s[k]==m-32)
				{
					b[j+1]=s[k];
					break;
				}

			}
			break;
		}
	}
	if(b[0]=='\0')
		printf("NO");
	else
		puts(b);
}
