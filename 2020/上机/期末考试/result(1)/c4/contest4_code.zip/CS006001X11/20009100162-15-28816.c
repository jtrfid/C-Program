#include <stdio.h>

int main(void) {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, j, a[m][n], b[m][n], check[m];
	for (i = 0; i < m; i++) {
		check[i] = 0;
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			b[i][j] = 0;
		}
	}
	int key, k = 0;
	scanf("%d", &key);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			if (a[i][j] == key) {
				check[i]++;
				b[i][k] = j;
				k++;
			}
		}
		k = 0;
	}
	int t = 0;
	for (i = 0; i < m; i++) {
		printf("%d ", check[i]);
		for (t = 0; t < n; t++) {
			if (b[i][t] != 0) {
				printf("%d ", b[i][t]);
			}
		}
		printf("\n");
	}
	int max = check[0], flag = 0;
	for (i = 0; i < m; i++) {
		if (check[i] > max) {
			max = check[i];
			flag = i;
		}
	}
	if (flag != 0)
		printf("%d", flag);
	else
		printf("no");
}