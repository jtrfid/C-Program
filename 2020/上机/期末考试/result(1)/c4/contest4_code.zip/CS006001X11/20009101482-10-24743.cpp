#include<stdio.h>
#include<string.h>
int main()
{
	char a,zifuchuan[100];
	int weizhi[100],i,j,len,sum=0;
	scanf("%c",&a);
	scanf("%s",zifuchuan);
	if(a>='A'&&a<='Z')a=a-'A'+'a';
	strlwr(zifuchuan);
	for(i=0;i<strlen(zifuchuan);i++)
	{
		if(zifuchuan[i]==a)
		{
			weizhi[sum]=i;
			sum++;
		}
	}
	if(sum==0)printf("NO");
	else if(sum==1)
	{
		for(i=weizhi[0];i<strlen(zifuchuan);i++)
			printf("%c",zifuchuan[i]);
	}
	else
	{
		for(i=weizhi[0];i<=weizhi[1];i++)
			printf("%c",zifuchuan[i]);
	}



}