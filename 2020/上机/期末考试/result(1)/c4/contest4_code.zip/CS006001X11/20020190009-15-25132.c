#include <stdio.h>
#include <string.h>

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	int a[m][n];
	int i, j, k;
	int b[m];
	for (i = 0; i < m; i++)
		b[i] = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int key;
	int ans = 0;
	scanf("%d", &key);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			if (a[i][j] == key) {
				ans++;
			}
		}
		if (ans == 0) {
			printf("0\n");
			continue;
		} else
			printf("%d ", ans);
		for (j = 0; j < n; j++) {
			if (a[i][j] == key) {
				printf("%d ", j);
			}
		}
		printf("\n");
		b[i] = ans;
		ans = 0;
	}
	int c[m], temp;
	for (i = 0; i < m; i++) {
		c[i] = i;
	}
	for (i = 0; i < m - 1; i++) {
		for (j = i + 1; j < m; j++) {
			if (b[i] < b[j]) {
				temp = c[j];
				c[i] = c[j];
				c[i] = temp;
				temp = b[j];
				b[i] = b[j];
				b[i] = temp;
			}
		}
	}
	int anss = 0;
	for (i = 0; i < m; i++)
		anss += b[i];
	if (anss == 0)
		printf("no");
	else
		printf("%d", c[0]);
	return 0;
}