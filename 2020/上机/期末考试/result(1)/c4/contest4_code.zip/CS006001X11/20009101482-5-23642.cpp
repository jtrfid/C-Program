#include<stdio.h>
int main()
{
	int n,i,b[3]={0},min=1000;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==1)b[0]++;
		else b[1]++;
		if(i%3==0&&i%5!=0)b[2]++;
	}
	for(i=0;i<3;i++)
	{
		if(b[i]<min)min=b[i];
	}
	printf("%d %d %d\n",b[0],b[1],b[2]);
	printf("%d",min);

}