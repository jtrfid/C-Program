#include <stdio.h>
int main()
{
	printf("110108196711301866\n12010X198901011234");
}