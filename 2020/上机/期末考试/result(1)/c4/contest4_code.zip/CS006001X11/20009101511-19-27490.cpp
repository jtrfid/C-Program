#include <stdio.h>

int main() {
	int n, b[] = {7, 9, 10, 5, 8, 4, 2, 1, 6, 37, 9, 10, 5, 8, 4, 2}, i, sum = 0, j, m = 0;
	char a[10][17];
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		for (j = 0; j < 17; j++)
			scanf("%c", &a[i][j]);
	for (i = 0; i < 18; i++) {
		for (j = 0; j < 18; j++) {
			if (a[i][j] < '0' || a[i][j] > '9')
				m++;
			sum = sum + a[i][j] * b[i];
		}
		if (m != 0) {
			for (j = 0; j < 18; j++)
				printf("%c", a[i][j]);
		}
		printf("\n");
	}
}