#include <stdio.h>
#include <string.h>

int main(void) {
	char c, str[100];
	scanf("%c", &c);
	getchar();
	gets(str);
	int n = strlen(str);
	if (c >= 65 && c <= 90)
		c = c + 32;
	int i, flag[50], t = 0, temp = 0;
	for (i = 0; i < n; i++) {
		if (str[i] == c || str[i] == c - 32) {
			temp = 1;
			flag[t] = i;
			t++;
		}
	}
	if (temp != 0) {
		for (i = flag[0]; i <= flag[1]; i++)
			printf("%c", str[i]);
	}
	if (temp == 0)
		printf("NO");
}