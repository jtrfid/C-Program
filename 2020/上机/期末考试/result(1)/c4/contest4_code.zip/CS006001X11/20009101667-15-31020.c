#include <stdio.h>
int main()
{
	int a[200][200],b[200][200]={0},c[200];
	int i,j,m,n,max=0,ma,key,k=1;
	scanf("%d%d",&m,&n);
	for(i=0;i<200;i++)
		b[i][0]=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		k=1;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
			{
				b[i][0]++;
				b[i][k]=j;
				k++;
			}
		}
		c[i]=k;
	}
	for(i=0;i<m;i++)
	{
		if(b[i][0]>max)
		{
			max=b[i][0];
			ma=i;
		}
	}
	for(i=0;i<m;i++)
	{
		if(b[i][0]==max)
		{
			ma=i;
			break;
		}
	}
	for(i=0;i<m;i++)
	{
			for(j=0;j<c[i];j++)
			{
				printf("%d ",b[i][j]);
		
			}
			printf("\n");
		
	}
	if(max==0)
	{
		printf("no");
	}
	else
		printf("%d",ma);
	return 0;
}

