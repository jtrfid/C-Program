#include<stdio.h>
#include<string.h>
int main()
{
	char og[100]={' '},as;
	unsigned int len,i,bo=0;
	scanf("%c%s",&as,og);
	for(i=0;i<strlen(og);++i)
	{
		if(og[i]==as||og[i]==as+32||og[i]==as-32)
		{
			bo=1;
			printf("%c",og[i]);
			++i;
			while(og[i]!=' '&&og[i]!=as&&og[i]!=as+32&&og[i]!=as-32)
			{
				printf("%c",og[i]);
				++i;
			}
			printf("%c",og[i]);
			continue;
		}
	}
	return 0;
}