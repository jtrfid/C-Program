#include<stdio.h>
int main()
{
	int a[200][200],p,key,m,n,max=0,l[200],t,i,j;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		t=0;
		for(j=0;j<n;j++)
			if (a[i][j]==key)
			{
				l[t]=j;
				t++;
			}
			printf("%d ",t);
			for (j=0;j<t;j++)
				printf("%d ",l[j]);
			printf("\n");
			if (t>max) {max=t;p=i;}
	}
	if (max) printf("%d",p);
	else printf("no");
}
