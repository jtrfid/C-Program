#include <stdio.h>

int main() {
	int i, j, n;
	scanf("%d", &n);
	int ans1 = 0, ans2 = 0, ans3 = 0;
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 == 1)
			ans1++;
		if (i % 2 == 0)
			ans2++;
		if (i % 3 == 0 && i % 5 != 0)
			ans3++;
	}
	printf("%d %d %d", ans1, ans2, ans3);
	return 0;
}