#include<stdio.h>
#include<string.h>
int main()
{
	char a[100],c,b[100];
	int i,flag=0;
	scanf("%c",&c);
	if(c>='a'&&c<='z')
		c=c-32;
	getchar();
	gets(a);
	strcpy(b,a);
	strupr(a);
	for(i=0;a[i]!='\0';i++)
	{
		if(a[i]==c)
		{
			while(1)
			{
				printf("%c",b[i]);
				i++;
				if(a[i]==c)
				{
					printf("%c",b[i]);
					flag=1;
					break;
				}
				if(a[i]=='\0')
				{
					flag=1;
					break;
				}
			}
		}
		if(flag)
			break;
	}
	if(flag==0)
		printf("NO");
	return 0;
}
