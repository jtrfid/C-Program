#include <stdio.h>
int main()
{
	char a;
	char str[100];
	int i,j=0;
	scanf("%c",&a);
	getchar();
	gets(str);
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==a||str[i]==a-32||str[i]==a+32)
		{
			for(j=i;;j++)
			{
				printf("%c",str[j]);
			
				if(str[j+1]==a||str[j+1]==a-32||str[j+1]==a+32||str[j+1]=='\0')
					break;
			}
			if(j!=0)
				printf("%c",str[j+1]);
		}
		if(j!=0)break;
	}
	if(j==0)
		printf("NO");
	return 0;
}
