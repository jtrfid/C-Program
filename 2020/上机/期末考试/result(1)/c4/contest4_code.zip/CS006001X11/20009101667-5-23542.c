#include <stdio.h>
int main()
{
	int n,i,jishu=0,oushu=0,geshu=0,max=1000;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			oushu++;
		if(i%2!=0)
			jishu++;
		if(i%3==0&&i%5!=0)
			geshu++;
	}
	if(jishu<=max)
		max=jishu;
	if(oushu<=max)
		max=oushu;
	if(geshu<=max)
		max=geshu;
	printf("%d %d %d",jishu,oushu,geshu);
	printf("\n%d",max);
	return 0;
}