#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	char a[101][20];
	int n,sum[101],z[101],count=0,i,j,k,temp=0,b[20];
	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		gets(a[i]);
	}
	for(i=0;i<n;i++)
	{
		temp=0;
		for(j=0;j<18;j++)
        if(a[i][j]<'0'||a[i][j]>'9') temp=1;
		if(temp==1) {puts(a[i]);continue;}
		else{
		for(k=0;k<18;k++)
			b[k]=a[i][k]-48;
		sum[i]=b[0]*7+b[1]*9+b[2]*10+b[3]*5+b[4]*8+b[5]*4+b[6]*2+b[7]*1+b[8]*6+b[9]*3+b[10]*7+b[11]*9+b[12]*10+b[13]*5+b[14]*8+b[15]*4+b[16]*2;
		z[i]=sum[i]%11;
		if(z[i]==0&&b[17]==1) count++;
		else{
			if(z[i]==1&&b[17]==0) count++;
			else{
			if(z[i]==2&&a[17]=='X') count++;
			else{
			if(z[i]+b[17]==12) count++;
			else{
				puts(a[i]);
			}
			}
			}
		}
		}


	
	}
	if(count==n) printf("All passed");
	return 0;
}