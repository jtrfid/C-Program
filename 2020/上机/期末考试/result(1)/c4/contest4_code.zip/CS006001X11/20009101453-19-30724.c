#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int p[100],Z,i,n,jiao[100],sum[100]={0},d[17],j,k,w[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	char hao[100][18],pass,M[11]={'1','0','X','9','8','7','6','5','4','3','2'};
	scanf("%d",&n);
	for(j=0;j<n;j++)
	{
			scanf("%s",hao[j][0]);
			jiao[j]=hao[j][17];
			for(k=0;k<17;k++)
			if(hao[j][k]=='X')
			{
				p[j]=1;
				pass=1;
			}
	    for(i=0;i<17;i++)
		{
			d[i]=hao[i]-48;
			sum[j]=sum[j]+w[i]*d[i];
		}
		Z=sum[j]%11;
		if(M[Z]!=jiao[j])
		{
			p[j]=1;
			pass=1;
		}
	}
	for(j=0;j<n;j++)
		if(p[j]==1)
		{
			for(i=0;i<17;i++)
			printf("%s",hao[j][i]);
		}
	if(pass!=1)
		printf("All passed");
	return 0;
}
