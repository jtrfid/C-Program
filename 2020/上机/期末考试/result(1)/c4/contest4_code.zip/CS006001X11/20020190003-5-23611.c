#include <stdio.h>

int main() {
	int n, i, sum1 = 0, sum2 = 0, sum3 = 0;
	int temp;
	scanf("%d", &n);
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 != 0)
			sum1++;
		else
			sum2++;
		if (i % 3 == 0 && i % 5 != 0)
			sum3++;
	}
	if (sum1 > sum2)
		temp = sum2;
	else
		temp = sum1;
	if (temp > sum3)
		temp = sum3;
	printf("%d %d %d\n", sum1, sum2, sum3);
	printf("%d", temp);
	return 0;
}