#include<stdio.h>
#include<string.h>
int main()
{
	char x;
	char s[100];
	int t=1;
	int i,n,j;
	scanf("%c",&x);
	scanf("\n");
	gets(s);
	n=strlen(s);
	if(x>='a'&&x<='z')
		x=x-32;
	for(i=0;i<n;i++)
	{
		if(s[i]==x||s[i]==x+32)
		{
			t=0;
			for(j=i;j<n;j++)
				printf("%c",s[j]);
			break;
		}
	}
	if(t)
		printf("NO");
	return 0;
}