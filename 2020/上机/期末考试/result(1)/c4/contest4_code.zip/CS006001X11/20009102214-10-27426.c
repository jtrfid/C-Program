#include<stdio.h>
#include<string.h>
int main()
{
	int i,num,flag,len,num1;
	char s[100],c,b[100]={0};
	scanf("%c\n",&c);
	gets(s);
	if(c>='A'&&c<='Z')
	{
		for(i=0;i<len;i++)
		{
			if(c==s[i])
			{
				flag=1;
				num=i;
				break;
			}
			else
				flag=0;
		}
		for(i=num+1;i<len;i++)
		{
			if(s[i]!=c&&s[i]!=c+32)
			{
				b[i-num]=s[i];
			}
			if(s[i]==c||s[i]==c+32)
			{
				num1=i-num;
				break;
			}
		}
	}
	if(c>='a'&&c<='z')
	{
		for(i=0;i<len;i++)
		{
			if(c==s[i])
			{
				flag=1;
				num=i;
				break;
			}
			else
				flag=0;
		}
		for(i=num+1;i<len;i++)
		{
			if(s[i]!=c&&s[i]!=c-32)
			{
				b[i-num]=s[i];
			}
			if(s[i]==c||s[i]==c-32)
			{
				num1=i-num;
				break;
			}
		}
	}
	if(flag==0)
		printf("NO");
	else if(flag==1)
		puts(b);
}



