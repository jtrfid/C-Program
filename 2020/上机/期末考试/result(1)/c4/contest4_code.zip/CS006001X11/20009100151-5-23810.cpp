#include<stdio.h>
#include<math.h>
#include<string.h>
int main ()
{
	int n,i,j;
	int a=0,b=0,c=0,d=0,e,f,g;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==1)
			a++;
		if(i%2==0)
			b++;
		if(i%3==0&&i%5!=0)
			c++;
	}
	d=a;
	if(d>b)
		d=b;
	if(d>c)
		d=c;
	printf("%d %d %d\n",a,b,c);
	printf("%d",d);
}































