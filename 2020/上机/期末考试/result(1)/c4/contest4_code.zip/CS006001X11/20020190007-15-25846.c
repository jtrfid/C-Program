#include<stdio.h>
int main()
{
	int a[200][200],b,m,n,i,j,k,ci[200]={0},wei[200][200],flag=0,max=0,hang;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&b);


	for(i=0;i<m;i++)
	{
		k=0;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==b)
			{
				ci[i]++;
				wei[i][k]=j;
				k++;
			}
		}
	}


	for(i=0;i<m;i++)
	{
		printf("%d ",ci[i]);
		if(ci[i]>max)
		{
			max=ci[i];
			hang=i;
		}
		if(ci[i])
		{
			flag=1;
			for(k=0;k<ci[i];k++)
				printf("%d ",wei[i][k]);
		}
		printf("\n");
	}
	if(flag==0)
		printf("no");
	else
		printf("%d",hang);
	return 0;
}