#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	char str[100],str1[100];
	char c1;
	int len,i,j;
	scanf("%c",&c1);
	getchar();
	gets(str);
	len=strlen(str);
	strcpy(str1,str);
	strupr(str1);
	if('a'<=c1&&c1<='z') c1=c1-32;
	for(i=0;i<len;i++)
	{
		if(str1[i]==c1) break;
	}
	if(i==len) printf("NO");
	else{
		printf("%c",str[i]);
		for(j=i+1;j<len;j++)
		{
			printf("%c",str[j]);
		if(str1[j]==c1) break;
		}
	}


	return 0;
}