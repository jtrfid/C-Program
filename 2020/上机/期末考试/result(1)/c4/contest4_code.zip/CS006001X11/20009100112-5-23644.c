#include <stdio.h>
int main()
{
	int n;
	int i;
	int a=0,b=0,c=0;
	int min;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2!=0)
			a++;
		if(i%2==0)
			b++;
		if(i%3==0&&i%5!=0)
			c++;
	}
	min=a;
	if(b<min)
		min=b;
	if(c<min)
		min=c;
	printf("%d %d %d\n",a,b,c);
	printf("%d",min);
	return 0;
}
