#include<stdio.h>
int main()
{
	char x,y;
	char s[100],t[100];
	int i,k,c=0;
	scanf("%c",&x);
	scanf("%s",s);
	if(x>='a'&&x<='z')
		y=x-32;
	if(x>='A'&&x<='Z')
		y=x+32;
	for(i=0;s[i-1]!='\0';i++)
	{
		if(s[i]==x||s[i]==y)
		{
			if(c==0)
			k=i;
			c++;
		}
		if(c==1)
			t[i-k]=s[i];
	    if(c==2)
		{
			t[i-k]=s[i];
			t[i-k+1]='\0';
			break;
		}
	}

	if(c==0)
		printf("NO");
	else
		printf("%s",t);
}

