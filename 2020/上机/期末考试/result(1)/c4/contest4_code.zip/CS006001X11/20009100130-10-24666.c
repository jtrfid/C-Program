#include <stdio.h>
#include <string.h>
int main()
{
	char x;
	char str1[100],str2[100];
	int t=0,i1,i2,i,n;
	scanf("%c\n",&x);
	gets(str1);
	strcpy(str2,str1);
	strupr(str1);
	n=strlen(str1);
	if(x>='a'&&x<='z') x=x-32;
	for(i=0;i<n;i++)
	{
		if(str1[i]==x&&t==1)
		{
			i2=i;
			break;
		}
		if(str1[i]==x&&t==0)
		{
			t=1;
			i1=i;
		}
		
		if(i==n-1||t==1)
		{
			i2=i;
		}

	}
	if(t==1)
	{
		for(i=i1;i<=i2;i++)
		{
			printf("%c",str2[i]);
		}
	}
	if(t==0) printf("NO");
}

	


	
