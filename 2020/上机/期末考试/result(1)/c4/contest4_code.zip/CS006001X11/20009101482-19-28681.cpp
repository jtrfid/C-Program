#include<stdio.h>
int main()
{
	int sum(char a[]);
	int n,i,j,z,m,chucuoshu=0,temp=0;
	char shenfenzheng[100][18];
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%s",shenfenzheng[i]);
	for(i=0;i<n;i++)
	{
		for(j=0;j<17;j++)
		{
			if(shenfenzheng[i][j]<'0'||shenfenzheng[i][j]>'9')
			{   temp=1;
				printf("%s\n",shenfenzheng[i]);
				break;
			}
		}
		if(temp==0)
		{
		
				z=sum(shenfenzheng[i])%11;
				if(z==0)m='1';
				else if(z==1)m='0';
				else if(z==2)m='X';
				else m=12-z+'0';
		if(m!=shenfenzheng[i][17])
		{
			printf("%s\n",shenfenzheng[i]);
			chucuoshu++;
		}
		}
	}
	if(chucuoshu==0)printf("All pleased");
}
int sum(char a[])
{
	int i,he;
	he=(a[0]-'0')*7+(a[1]-'0')*9+(a[2]-'0')*10+(a[3]-'0')*5+(a[4]-'0')*8+(a[5]-'0')*4+(a[6]-'0')*2+a[7]-'0'+(a[8]-'0')*6+(a[9]-'0')*3+(a[10]-'0')*7+(a[11]-'0')*9+(a[12]-'0')*10+(a[13]-'0')*5+(a[14]-'0')*8+(a[15]-'0')*4+(a[16]-'0')*2;
    return he;
}
