#include<stdio.h>
int main()
{
	int m,n;
	int key,cs[200]={0},wz[200][200]={0};
	int sz[200][200];
	int i,j,k;
	int max,maxh;
	int flag=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
			scanf("%d",&sz[i][j]);
	scanf("%d",&key);

	for(i=0;i<m;i++)
	{
		for(j=0,k=0;j<n;j++)
		{
			if(sz[i][j]==key)
			{
				cs[i]++;
				wz[i][k]=j;
				k++;
			}
		}
	}

	max=cs[0];
	maxh=0;
	for(i=1;i<m;i++)
	{
		if(cs[i]>max)
		{
			max=cs[i];
			maxh=i;
		}
		if(cs[i]==max)
		{
			if(i<maxh)
				maxh=i;
		}
	}

	for(i=0;i<m;i++)
	{
		printf("%d ",cs[i]);
		for(j=0;wz[i][j]!=0;j++)
			printf("%d ",wz[i][j]);
		printf("\n");
	}
	for(i=0;i<m;i++)
	{
		if(cs[i]!=0)
			flag=1;
	}
	if(flag==1)
	printf("%d",maxh);
	else
		printf("no");



}