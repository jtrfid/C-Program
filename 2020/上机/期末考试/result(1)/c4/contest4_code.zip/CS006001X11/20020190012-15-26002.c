#include <stdio.h>
int main()
{
	int i,j,k,zhen[100][100],m,n,num,jia[100][100],a,temp=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&zhen[i][j]);
		}
	}
	scanf("%d",&num);
	for(i=0;i<m;i++)
	{
		k=0;
		for(j=0;j<n;j++)
		{
			if(num==zhen[i][j])
			{
				k++;
				jia[i][k]=j;
			}
		}
		jia[i][0]=k;
		for(a=0;a<=k;a++)
		printf("%d ",jia[i][a]);
		printf("\n");
	}
	for(i=0;i<m;i++)
	{
	
		if(jia[i][0]>temp)
		{
			temp=jia[i][0];
		}
	}
	if(temp!=0)
		printf("%d",temp);
	else
		printf("no");





	return 0;
}

