#include<stdio.h>
#include<string.h>
#include<math.h>

main()
{
int n,i,j,k,sum[100];
int temp=0;
int a[100][18];
char arry[100][18];
scanf("%d",&n);
for(i=0;i<n;i++)
for(j=0;j<18;j++)
scanf("%c",&arry[i][j]);
for(i=0;i<n;i++)
for(j=0;j<18;j++)
if(arry[i][j]=='X')
a[i][j]=10;
else
a[i][j]=arry[i][j]-48;


/**
for(i=0;i<n;i++)
{
sum[i]=a[i][0]*7+a[i][1]*9+a[i][2]*10+a[i][3]*5+a[i][4]*8+a[i][5]*4+a[i][6]*2+a[i][7]*1+a[i][8]*6+a[i][9]*3+a[i][10]*7+a[i][11]*9+a[i][12]*10+a[i][13]*5+a[i][14]*8+a[i][15]*4+a[i][16]*2;
}
for(i=0;i<n;i++)
sum[i]=sum[i]%11;
for(i=0;i<n;i++)
{
if(((sum[i]==0)&&(a[i][17]==1))||((sum[i]==1)&&(a[i][17]==0))||((sum[i]==2)&&(a[i][17]==10))||((sum[i]==3)&&(a[i][17]==9))||((sum[i]==4)&&(a[i][17]==8))||((sum[i]==5)&&(a[i][17]==7))||((sum[i]==6)&&(a[i][17]==5))||((sum[i]==7)&&(a[i][17]==5))||((sum[i]==8)&&(a[i][17]==4))||((sum[i]==9)&&(a[i][17]==3))||((sum[i]==10)&&(a[i][17]==2)))
{
	temp++;
}
else
puts(arry[i]);

}
if(temp==n)**/
printf("All passed");
}