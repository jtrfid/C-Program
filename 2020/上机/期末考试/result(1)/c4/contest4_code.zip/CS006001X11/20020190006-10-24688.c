#include<stdio.h>
#include<string.h>
int main()
{
	char x;
	char s[100];
	int t=1,p=1;
	int i,n,j;
	int start,end;
	scanf("%c",&x);
	scanf("\n");
	gets(s);
	n=strlen(s);
	if(x>='a'&&x<='z')
		x=x-32;
	for(i=0;i<n;i++)
	{
		if(s[i]==x||s[i]==x+32)
		{
			start=i;
			t=0;
			for(j=i;j<n;j++)
			{
				if(s[j]==x||s[j]==x+32)
				{
					end=j;
					p=0;
				}
			}
			if(p)
				end=n-1;
			for(j=start;j<=end;j++)
				printf("%c",s[j]);
			break;
		}
	}
	if(t)
		printf("NO");
	return 0;
}