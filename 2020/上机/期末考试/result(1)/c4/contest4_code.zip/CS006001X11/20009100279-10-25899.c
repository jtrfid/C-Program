#include <stdio.h>
#include <string.h>

void main()
{
	int flag = 0;
	int i = 0;
	char find;
	char str[400] = {0};
	scanf("%c", &find);getchar();
	gets(str);
	for (i=0; (str[i] != '\0'); i++)
	{
		if ((str[i] == find) || ((str[i] == find + ('A' - 'a')) || (str[i] == find - ('A' - 'a')))) { printf("%c", str[i]); flag++; }
		else if(flag == 1) printf("%c", str[i]);
	}
	if (!flag) printf("NO");
}
