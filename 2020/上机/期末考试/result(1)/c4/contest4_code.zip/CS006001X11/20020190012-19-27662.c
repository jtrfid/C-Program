#include <stdio.h>
int main()
{
	int n,i,j,k;
	char num[10][20];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",num[i]);
	}
	printf("All passed");
	return 0;
}