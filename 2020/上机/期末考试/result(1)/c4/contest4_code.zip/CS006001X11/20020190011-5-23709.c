#include<stdio.h>
#include<string.h>
#include<math.h>

main()
{
	int i,n,j=0,o=0,q=0,k;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2!=0)
			j++;
	    if(i%2==0)
			o++;
		if((i%3==0)&&(i%5!=0))
			 q++;
	}
if(j<o)
k=j;
else
k=0;
if(q<k)
k=q;
printf("%d %d %d\n%d",j,o,q,k);
}