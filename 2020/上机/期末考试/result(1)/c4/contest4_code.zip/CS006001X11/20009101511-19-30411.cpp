#include <stdio.h>

int main() {
	char a[10][18];
	int n, i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		for (j = 0; j < 18; j++)
			scanf("%c", &a[i][j]);

	for (j = 0; j < 18; j++)
		printf("%c", a[1][j]);
	printf("\n");
	for (j = 0; j < 18; j++)
		printf("%c", a[3][j]);
	printf("\n");

}