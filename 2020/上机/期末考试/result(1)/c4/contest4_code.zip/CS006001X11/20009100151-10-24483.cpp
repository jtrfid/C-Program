#include<stdio.h>
#include<math.h>
#include<string.h>
int main ()
{
	char a;
	char str[100];
	int i,j,len,op,ed,temp=0;
	getchar(a);
	gets(str);
	len=strlen(str);
	for(i=0;i<len;i++)
	{
		if(str[i]>='A'&&str[i]<='Z')
			str[i]=str[i]-32;
	}
	for(i=0;i<len;i++)
	{
		if(str[i]==a&&temp==0)
		{
			op=i;
			temp=1;
		}
		if(str[i]==a&&temp==1)
		{
			ed=i;
		}
	}
	for(i=op;i<=ed;i++)
	{
		printf("%c",str[i]);
	}
}


		