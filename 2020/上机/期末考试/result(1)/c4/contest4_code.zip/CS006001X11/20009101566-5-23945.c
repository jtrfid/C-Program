#include <stdio.h>
int main()
{
	int n,ji=0,ou=0,neng=0,i,zui;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
		{
			ou=ou+1;
		}
		else
		{
			ji=ji+1;
		}
	}
	for(i=n;i<=5*n;i++)
	{
		if(i%3==0&&i%5!=0)
		{
			neng=neng+1;
		}
	}
	printf("%d %d %d\n",ji,ou,neng);
	if(neng<=ji&&neng<=ou)
	{
		zui=neng;
	}
	else if(ji<=ou&&ji<=neng)
	{
		zui=ji;
	}
	else
	{
		zui=ou;
	}
	printf("%d",zui);
	return 0;
}

