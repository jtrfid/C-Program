#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int n, i, sumji = 0, sumou = 0, sum3 = 0, min, Min;
	scanf("%d", &n);
	for (i = n; i <= 5 * n; i++) {
		if (i % 2 != 0)
			sumji++;
		if (i % 2 == 0)
			sumou++;
		if (i % 3 == 0 && i % 5 != 0)
			sum3++;
	}
	printf("%d %d %d\n", sumji, sumou, sum3);
	if (sumji <= sumou) {
		min = sumji;
	} else
		min = sumou;
	if (min <= sum3)
		Min = min;
	else
		Min = sum3;
	printf("%d", Min);
	return 0;
}