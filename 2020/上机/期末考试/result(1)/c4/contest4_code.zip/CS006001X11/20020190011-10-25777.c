#include<stdio.h>
#include<string.h>
#include<math.h>

main()
{
	char x;
	char str[100],str1[100];
	int n,i,k,j,temp=0;
	scanf("%c",&x);
	scanf("%s",&str);
	n=strlen(str);
		for(i=0;i<n;i++)
			if((str[i]==x+32)||(str[i]==x-32)||(str[i]==x))
				temp++;

	for(i=0;i<n;i++)
		if((str[i]==x+32)||(str[i]==x-32)||(str[i]==x))
		{
			do{
			printf("%c",str[i]);
			i++;
			if((str[i]==x+32)||(str[i]==x-32)||(str[i]==x))
			{
				printf("%c",str[i]);
				break;
			}
			}
			while(i<n);
			break;
			
		
		}
if(temp==0)
printf("NO");




}