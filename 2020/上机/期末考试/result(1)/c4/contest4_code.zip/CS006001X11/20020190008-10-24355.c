#include<stdio.h>
#include<string.h>
int main()
{
	char c;
	char str[100],a[100];
	int n,i,j=0;
	scanf("%c",&c);
	getchar();
	gets(str);
	n=strlen(str);
	if(c<='z'&&c>='a')
		strlwr(str);
	if(c<='Z'&&c>='A')
		strupr(str);
	for(i=0;i<n;i++)
	{
		if(str[i]==c)
		{
			while(str[i]!=c||str[i]!='\0')
			{
				a[j++]=str[i];
				i++;
			}
			break;
		}
	}
	printf("%s",a);
}



	

		
	

