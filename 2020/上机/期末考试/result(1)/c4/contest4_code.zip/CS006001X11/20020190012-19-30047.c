#include <stdio.h>
int main()
{
	
	int n,i,j,k,sum=0,flag=0,z;
	char num[10][20],M;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",&num[i]);
	}
	for(i=0;i<n;i++)
	{
		sum=0;
	  sum=(num[i][0]-48)*7+(num[i][1]-48)*9+(num[i][2]-48)*10+(num[i][3]-48)*5+(num[i][4]-48)*8+(num[i][5]-48)*4+(num[i][6]-48)*2+(num[i][7]-48)*1+(num[i][8]-48)*6+(num[i][9]-48)*3+(num[i][10]-48)*7+(num[i][11]-48)*9+(num[i][12]-48)*10+(num[i][13]-48)*5+(num[i][14]-48)*8+(num[i][15]-48)*4+(num[i][16]-48)*2;
	  z=sum%11;
	  switch(z)
	  {
	  case 0:M=1;break;
	  case 1:M=0;break;
      case 2:M=x;break;
	  case 3:M=9;break;
	  case 4:M=8;break;
    	case 5:M=7;break;
		case 6:M=6;break;
		case 7:M=5;break;
    	case 8:M=4;break;
	    case 9:M=3;break;
		case 10:M=2;break;
	  }
	  if(num[i][16]!=M)
	  {
		  printf("%s",num[i]);
		  flag=1;
	  }
	}
	if(flag==0)
	printf("All passed");
	return 0;
}