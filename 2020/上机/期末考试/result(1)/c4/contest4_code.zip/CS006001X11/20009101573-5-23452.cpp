#include <iostream>
#include <algorithm>
using namespace std;

int main() {
	int count[3] = {0};
	int n;
	cin >> n;
	for (int i = n; i <= 5 * n; i++) {
		if (i % 2 == 0) {
			count[0] ++;
		}
		if (i % 2 != 0)
			count[1] ++;
		if (i % 3 == 0 && i % 5 != 0)
			count[2] ++;
	}
	cout << count[0] << ' ' << count[1] << ' ' << count[2] << endl;
	int min = *min_element(count, count + 3);
	cout << min;
}