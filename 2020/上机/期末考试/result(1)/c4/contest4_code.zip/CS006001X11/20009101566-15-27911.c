#include <stdio.h>
int main()
{
	int a[200][200],m,n,i,j,key;
	int g=0,w[100],s=0,x;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
			{
				g=g+1;
				w[s]=j;
				s=s+1;
				if(j==n-1)
				{
					printf("%d ",g);
					for(x=0;x<g;x++)
					{
						printf("%d ",w[x]);
					}
					s=0;
				}
			}
			else
			{
				if(j==n-1)
				{
					printf("0\n");
				}
			}
		}
	}
}






