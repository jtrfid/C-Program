#include <stdio.h>

int main() {
	char a[100][18];
	int sum[100] = {0};
	int n, z, p, i, j, c = 0, x;
	scanf("%d", &n);
	getchar();
	for (i = 0; i < n; i++) {
		for (j = 0; j < 18; j++)
			scanf("%c", &a[i][j]);
		getchar();
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < 18; j++) {
			if (a[i][j] == 'X')
				a[i][j] = 10;
			else
				a[i][j] = a[i][j] - 48;

		}
	}
	for (i = 0; i < n; i++) {
		z = 0;
		p = 0;
		x = 0;
		sum[i] = a[i][0] * 7 + a[i][1] * 9 + a[i][2] * 10 + a[i][3] * 5 + a[i][4] * 8 + a[i][5] * 4 + a[i][6] * 2 + a[i][7] * 1;
		sum[i] = sum[i] + a[i][8] * 6 + a[i][9] * 3 + a[i][10] * 7 + a[i][11] * 9 + a[i][12] * 10 + a[i][13] * 5;
		sum[i] = sum[i] + a[i][14] * 8 + a[i][15] * 4 + a[i][16] * 2;
		z = sum[i] % 11;
		if (z == 0 && a[i][17] == 1)
			p = 1;
		else if (z == 1 && a[i][17] == 0)
			p = 1;
		else if (z == 2 && a[i][17] == 10)
			p = 1;
		else if (z == 3 && a[i][17] == 9)
			p = 1;
		else if (z == 4 && a[i][17] == 8)
			p = 1;
		else if (z == 5 && a[i][17] == 7)
			p = 1;
		else if (z == 6 && a[i][17] == 6)
			p = 1;
		else if (z == 7 && a[i][17] == 5)
			p = 1;
		else if (z == 8 && a[i][17] == 4)
			p = 1;
		else if (z == 9 && a[i][17] == 3)
			p = 1;
		else if (z == 10 && a[i][17] == 2)
			p = 1;
		for (j = 0; j < 17; j++) {
			if (a[i][j] == 10)
				x = 1;
		}

		if (p == 0 || x == 1) {
			for (j = 0; j < 18; j++) {
				if (a[i][j] == 10)
					printf("X");
				if (a[i][j] == 10)
					continue;
				printf("%d", a[i][j]);
			}
			printf("\n");
		} else
			c = c + 1;
	}
	if (c == n)
		printf("All passed");


}