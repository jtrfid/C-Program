#include <stdio.h>
int main()
{
	int m,n,i,j,key,p=0,q=0,num[200]={0};
	int a[200][200]={0};
	int b[200]={0};
	int max=0,z,wu=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key) 
			{
				num[i]++;
				b[p]=j;
				p++;
				q=p;

			}
		}
		printf("%d ",num[i]);
		for(p=0;p<q;p++)
			printf("%d ",b[p]);
	  printf("\n");
	  p=0;
	  q=0;
	}
	for(i=0;i<m;i++)
	{
		if(num[i]==0) wu++;
	}
	if(wu==m) printf("no");
	else
	{

	    for(i=0;i<m;i++)
		{
		    if(num[i]>max)
			{
			max=a[i];
			z=i;
			}
		}
	    printf("%d",z);
	}


	return 0;
}
		
