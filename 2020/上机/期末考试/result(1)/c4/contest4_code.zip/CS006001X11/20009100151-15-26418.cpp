#include<stdio.h>
#include<math.h>
#include<string.h>
int main ()
{
	int m,n,i,k,j,num=0;
	int t,d,b,c,temp=0,tot=0,op;
	int a[100][100],ci[100];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&t);
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(t==a[i][j])
			{
				ci[num]=j;
				num++;
				temp=1;
			}
		}
		
		if(temp==1)
		{
			if(num>tot)
			{
				tot=num;
				op=i;
			}
				
			printf("%d ",num);
			for(k=0;k<num;k++)
				printf("%d ",ci[k]);
		}
		if(temp==0)
			printf("0");
		temp=0;
		num=0;
		printf("\n");
	}
	printf("%d",op);
}
	
	
	




	

