#include<stdio.h>
#include<string.h>
int main()
{
	char c[101]={'0'};
	char m,n;
	int leg,i,j,sum,temp=0;
	scanf("%c\n",&m);
	gets(c);
	leg=strlen(c);
	for(i=0;i<leg;i++)
	{
		if(c[i]==m||c[i]==m+32||c[i]==m-32)
			temp++;
		else
			continue;
	}
	for(sum=0;sum<leg;sum++)
	{
		if(c[sum]==m||c[sum]==m+32||c[sum]==m-32)
		{
			i=sum;
			break;
		}
	}
	for(sum=i+1;sum<leg;sum++)
	{
		if(c[sum]==m||c[sum]==m+32||c[sum]==m-32)
		{
			j=sum;
			break;
		}
	}
	if(sum==leg)
		j=sum;
	if(temp==0)
		printf("NO");
	else
	{
		for(temp=i;temp<=j;temp++)
			printf("%c",c[temp]);
	}
	printf("\n");
	return 0;
}