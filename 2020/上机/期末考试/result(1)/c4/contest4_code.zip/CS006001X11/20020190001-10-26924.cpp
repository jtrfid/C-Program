#include<stdio.h>
int main()
{
	char x;
	char a[100];
	scanf("%c",&x);
	gets(a);
printf("no");
}