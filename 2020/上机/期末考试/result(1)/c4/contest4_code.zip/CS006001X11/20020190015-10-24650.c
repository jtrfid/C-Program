#include<stdio.h>
#include<string.h>
int main()
{
	int i,t=0,mark=0,arr[100];
	char cha,b,c;
	char stri[100];
	scanf("%c",&cha);
	b=cha+32;
	c=cha-32;
	scanf("%s",stri);
	for(i=0;i<strlen(stri);i++)
	{
		if(stri[i]==cha||stri[i]==b||stri[i]==c)
		{
			mark++;
			arr[t]=i;
			t++;
		}
	}
	if(mark==0)
		printf("NO\n");
	else if(mark==1)
	{
		for(i=arr[0];i<strlen(stri);i++)
			printf("%c",stri[i]);
		printf("\n");
	}
	else
	{
		for(i=arr[0];i<=arr[1];i++)
			printf("%c",stri[i]);
		printf("\n");
	}
	return 0;
}