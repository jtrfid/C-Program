#include <stdio.h>
#include <string.h>

int main() {
	int i = 0, len = 0, flag = 0, n, max, q = 0;
	char s, str[100];
	scanf("%c", &s);
	scanf("%s", &str);
	len = strlen(str);
	if ('A' <= s && s <= 'Z')
		s += 32;
	for (i = 0; i < len; i++) {
		if (str[i] == s || str[i] + 32 == s ) {
			q++;
			if (flag == 0)
				flag++;
			else if (flag == 1) {
				flag -= 20;
				printf("%c", str[i]);
			}
		}
		if (flag == 1)
			printf("%c", str[i]);
	}
	if (q == 0)
		printf("NO");
}
