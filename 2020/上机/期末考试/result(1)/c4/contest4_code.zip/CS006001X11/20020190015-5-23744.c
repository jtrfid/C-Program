#include<stdio.h>
int main()
{
	int m,n,i;
	int reg1=0,reg2=0,reg3=0;
	scanf("%d",&n);
	m=5*n;
	for(i=n;i<=m;i++)
	{
		if(i%2!=0)
			reg1++;
		if(i%2==0)
			reg2++;
	    if(i%3==0&&i%5!=0)
			reg3++;
	}
	printf("%d %d %d\n",reg1,reg2,reg3);
	if(reg1<=reg2&&reg1<=reg3)
		printf("%d\n",reg1);
	if(reg2<=reg1&&reg2<=reg3)
		printf("%d\n",reg2);
	if(reg3<=reg2&&reg3<=reg1)
		printf("%d\n",reg3);
	return 0;
}