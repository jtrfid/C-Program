#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int m, n, i, j, key, p, max = -1;
	scanf("%d%d", &m, &n);
	int sum[m], record[n], k = 0;
	for (i = 0; i < m; i++)
		sum[i] = 0;
	int xi[m][n];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &xi[i][j]);
		}
	}
	scanf("%d", &key);
	for (i = 0; i < m; i++) {
		k = 0;
		for (j = 0; j < n; j++) {
			if (xi[i][j] == key) {
				sum[i]++;
				record[k] = j;
				k++;
			}
		}
		if (sum[i] == 0)
			printf("0\n");
		else {
			printf("%d ", sum[i]);
			for (p = 0; p < k; p++) {
				printf("%d ", record[p]);
			}
			printf("\n");
		}
	}
	k = 0;
	for (i = 0; i < m; i++) {
		if (sum[i] != 0) {
			k++;
		}
	}
	if (k == 0)
		printf("no");
	else {
		for (i = 0; i < m; i++) {
			if (sum[i] >= max)
				max = sum[i];
		}
		for (i = 0; i < m; i++) {
			if (sum[i] == max) {
				printf("%d", i);
				break;
			}
		}

	}
	return 0;
}