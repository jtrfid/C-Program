#include<stdio.h>
int main()
{
	char a[100][18],m[11]={'1','0','X','9','8','7','6','5','4','3','2'};
	int i,j,cnt,q[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2},z=0,bo[100]={0},bi=0,bj=0;
	scanf("%d",&cnt);
	for(i=0;i<cnt;++i)
	{
		scanf("%s",a[i]);
	}
	for(i=0;i<cnt;++i)
	{
		z=0;
		for(j=0;j<17;++j)
		{
			z=z+(a[i][j]-'0')*q[j];
			if(a[i][j]>'9'&&a[i][j]<'0')
				bi=1;
		}
		z=z%11;
		if(m[z]!=a[i][17]&&bi==0)
		{
			bo[i]=1;
			bj=1;
		}
		if(bi==1)
		{
			bo[i]=1;
			bi=0;
			bj=1;
		}
	}
	for(i=0;i<cnt;++i)
	{
		if(bo[i]==1)
		{
			for(j=0;j<18;++j)
				printf("%c",a[i][j]);
			printf("\n");
		}
	}
	if(bj==0)
		printf("All passed\n");
	return 0;
}