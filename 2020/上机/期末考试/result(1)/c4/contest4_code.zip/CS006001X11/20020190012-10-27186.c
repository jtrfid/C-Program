#include <stdio.h>
int main()
{
	char cha;
	int i,k=0;
	char str[100],str1[100];
	scanf("%c",&cha);
	scanf("%s",&str);
	if(cha>=97&&cha<=122)
			cha=cha-32;
	for(i=0;str[i]!='\0';i++)
	{
		str1[i]=str[i];
		if(str[i]>=97&&str[i]<=122)
			str[i]=str[i]-32;
	}


	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==cha)
		{
			printf("%c",str1[i]);
			for(k=i+1;;k++)
			{
				if(str[k]=='\0')
				{
					break;
				}
				printf("%c",str1[k]);
				if(str[k]==cha)
				{
					break;
				}	
			}
			
		}

		if(k!=0)
			break;
	}
	if(k==0)
		printf("no");




//	printf("%d %d %d\n%d",ji,ou,san,temp);
	return 0;
}
