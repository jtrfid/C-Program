#include<stdio.h>
#include<string.h>
#include<math.h>

main()
{
	int m,n,i,j,k,temp,e,v,temp1,f,da;
	int a[200][200];
	int b[200][200];
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
scanf("%d",&k);
for(i=0;i<199;i++)
		for(j=0;j<199;j++)
		b[i][j]=0;
for(i=0;i<m;i++)
{
	temp=0;e=0;f=0;

		for(j=0;j<n;j++)
		{
			if(a[i][j]==k)
			{
				temp++;
				b[i][e]=j;
				e++;
			}
		}
		if(temp>f){f=temp;da=i;}
		if(temp!=0)
		{
		printf("%d ",temp);
		for(v=0;b[i][v]!=0;v++)
		{
			printf("%d",b[i][v]+1);
			printf("\n");
		}
		temp1++;
		}
		else
			printf("0");
}

if(temp1==0)
printf("no");
printf("%d",da+1);

		



}