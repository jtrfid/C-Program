#include <stdio.h>
#include <string.h>
int main()
{
	int m,n,a[100][100],t=0,k=0,i,j,w,sum[100]={0},lie[100]={0},key,max=0,maxi;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		k=0;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
			{
				t=1;
				sum[i]=sum[i]+1;
				lie[k]=j;
				k=k+1;
			}
		}
		if(sum[i]!=0&&sum[i]>max)
		{
			max=sum[i];
			maxi=i;
		}
		if(sum[i]==0) printf("0");
		else
		{
			printf("%d ",sum[i]);
			for(w=0;w<k;w++)
			{
				printf("%d ",lie[w]);
			}
		}
		printf("\n");
	}
	if(t==0) printf("no");
	if(t==1) printf("%d",maxi);
}

	




	
	
