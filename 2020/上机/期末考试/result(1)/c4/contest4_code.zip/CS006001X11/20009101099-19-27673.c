#include<stdio.h>
int main()
{
	int n,i;
	char a[100][18];
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%s",&a[i]);
	printf("ALL passed");
	return 0;
}
