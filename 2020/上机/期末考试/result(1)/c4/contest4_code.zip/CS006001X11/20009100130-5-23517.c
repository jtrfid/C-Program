#include <stdio.h>
#include <string.h>
int main()
{
	int n,i,j,ji=0,ou=0,san=0,t,min=9999;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==1) ji=ji+1;
		if(i%2==2) ou=ou+1;
		if(i%3==0&&i%5!=0) san=san+1;
	}
	if(ji<min) min=ji;
	if(ou<min) min=ou;
	if(san<min) min=san;
	printf("%d %d %d\n",ji,ou,san);
	printf("%d",min);

}