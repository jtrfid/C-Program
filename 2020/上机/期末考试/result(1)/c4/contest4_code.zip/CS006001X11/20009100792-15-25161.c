#include<stdio.h>
int main()
{
	int a[200][200]={0},b[200]={0},bo=1,cnt=0,m,n,i,j,trg,k[201]={0},max=200;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;++i)
	{
		for(j=0;j<n;++j)
			scanf("%d",&a[i][j]);
	}
	scanf("%d",&trg);
	for(i=0;i<m;++i)
	{
		cnt=0;
		for(j=0;j<n;++j)
		{
			if(a[i][j]==trg)
			{
				bo=1;
				b[cnt]=j;
				++cnt;
			}
		}
		if(cnt>k[max])
		{
			max=i;
			k[max]=cnt;
		}
		printf("%d ",cnt);
		if(bo==1)
		{
			for(j=0;j<cnt;++j)
				printf("%d ",b[j]);
		}
		printf("\n");
	}
	if(max==200)
		printf("no");
	else
		printf("%d",max);
	return 0;
}