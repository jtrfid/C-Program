#include <stdio.h>
int main()
{
	int n,i,k,min=10000;

	int ji=0,ou=0,num=0;
	int a[3];
	scanf("%d",&n);
    for(i=n;i<=5*n;i++)
	{
		if(i%2==0) ou++;
		if(i%2!=0) ji++;
		if(i%3==0&&i%5!=0) num++;
	}
	a[0]=ji;
	a[1]=ou;
	a[2]=num;
	
	
	for(i=0;i<3;i++)
	{
		if(a[i]<min) min=a[i];
	}
	printf("%d %d %d",ji,ou,num);
	printf("\n");
	printf("%d",min);
	return 0;
}
	



