#include<stdio.h>
int main()
{
	int w[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	char m[100],c[100][17];
	int i,sum[100]={0},n,j,flag=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		getchar();
		for(j=0;j<17;j++)
		{
			scanf("%c",&c[i][j]);
			sum[i]+=(c[i][j]-48)*w[j];
		}
		scanf("%c",&m[i]);
	}

	for(i=0;i<n;i++)
	{
		sum[i]=sum[i]%11;
		switch(sum[i])
		{
		case 0:if(m[i]=='1') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 1:if(m[i]=='0') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 2:if(m[i]=='X') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 3:if(m[i]=='9') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 4:if(m[i]=='8') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 5:if(m[i]=='7') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 6:if(m[i]=='6') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 7:if(m[i]=='5') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 8:if(m[i]=='4') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 9:if(m[i]=='3') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);}break;
		case 10:if(m[i]=='2') flag++;else {for(j=0;j<17;j++) printf("%c",c[i][j]); printf("%c\n",m[i]);};
		}
	}
	if(flag==n)
		printf("All passed");
	return 0;
}