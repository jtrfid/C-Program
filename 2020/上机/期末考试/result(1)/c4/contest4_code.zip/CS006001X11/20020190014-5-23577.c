#include <stdio.h>
int main()
{
	int n,i,ji=0,ou=0,a=0;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			ou++;
		if(i%2!=0)
			ji++;
		if((i%3==0)&&(i%5!=0))
			a++;
	}
	printf("%d %d %d\n",ji,ou,a);
	printf("%d",a);
}

	
