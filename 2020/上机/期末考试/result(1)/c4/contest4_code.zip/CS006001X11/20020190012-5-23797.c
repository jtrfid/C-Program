#include <stdio.h>
int main()
{
	int n,temp,i,j,k,ji=0,ou=0,san=0;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			ou++;
		else if(i%2==1)
			ji++;
		if(i%3==0&&i%5!=0)
			san++;
	}
	temp=san;
	if(ji<temp)
		temp=ji;
	if(ou<temp)
		temp=ou;
	printf("%d %d %d\n%d",ji,ou,san,temp);
	return 0;
}
