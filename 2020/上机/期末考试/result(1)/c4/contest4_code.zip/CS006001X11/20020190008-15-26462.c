#include<stdio.h>
int main()
{
	int a[200][200];
	int b[200]={0};
	int c[200][200];
	int m,n,t,s,num,min=0,max=0;
	int i,j;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&t);
	for(i=0;i<m;i++)
	{
		s=0;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==t)
			{
				b[i]++;
				c[i][s++]=j;
			}
		}
	}
	for(i=0;i<m;i++)
	{
		if(b[i]<b[min])
			min=i;
		if(b[i]>b[max])
			max=i;
    }
	for(i=0;i<m;i++)
	{
		printf("%d ",b[i]);
		for(j=0;j<b[i];j++)
		{
			printf("%d ",c[i][j]);
		}
		printf("\n");
	}
	if(b[max]==0)
		printf("no");
	else
		printf("%d",max);
}

