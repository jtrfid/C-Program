#include<stdio.h>
#include<string.h>
int main()
{
	char a[100][19];
	int b[100]={0},flag=0;
	int n,i,j,sum,z;
	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		gets(a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<17;j++)
		{
			if(a[i][j]>='9'||a[i][j]<='0')
				b[i]=1;
		}
	}
	for(i=0;i<n;i++)
	{
		sum=0;
		sum=sum+(a[i][0]-'0')*7;
		sum=sum+(a[i][1]-'0')*9;
		sum=sum+(a[i][2]-'0')*10;
		sum=sum+(a[i][3]-'0')*5;
		sum=sum+(a[i][4]-'0')*8;
		sum=sum+(a[i][5]-'0')*4;
		sum=sum+(a[i][6]-'0')*2;
		sum=sum+(a[i][7]-'0')*1;
		sum=sum+(a[i][8]-'0')*6;
		sum=sum+(a[i][9]-'0')*3;
		sum=sum+(a[i][10]-'0')*7;
		sum=sum+(a[i][11]-'0')*9;
		sum=sum+(a[i][12]-'0')*10;
		sum=sum+(a[i][13]-'0')*5;
		sum=sum+(a[i][14]-'0')*8;
		sum=sum+(a[i][15]-'0')*4;
		sum=sum+(a[i][16]-'0')*2;
		z=sum%11;
		if(z==0)
		{
			if(a[i][18]!='1')
				b[i]=1;
		}
		if(z==1)
		{
			if(a[i][18]!='0')
				b[i]=1;
		}
		if(z==2)
		{
			if(a[i][18]!='X')
				b[i]=1;
		}
		if(z==3)
		{
			if(a[i][18]!='9')
				b[i]=1;
		}
		if(z==4)
		{
			if(a[i][18]!='8')
				b[i]=1;
		}
		if(z==5)
		{
			if(a[i][18]!='7')
				b[i]=1;
		}
		if(z==6)
		{
			if(a[i][18]!='6')
				b[i]=1;
		}
		if(z==7)
		{
			if(a[i][18]!='5')
				b[i]=1;
		}
		if(z==8)
		{
			if(a[i][18]!='4')
				b[i]=1;
		}
		if(z==9)
		{
			if(a[i][18]!='3')
				b[i]=1;
		}
		if(z==10)
		{
			if(a[i][18]!='2')
				b[i]=1;
		}
	}
	for(i=0;i<n;i++)
	{
		if(b[i]==1)
		{
			printf("%s",a[i][19]);
			flag=1;
		}
	}
	if(flag==0)
		printf("All passed");
	}
				




	