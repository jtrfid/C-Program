#include <stdio.h>

int main() {
	int a[200][200], m, n, i, j, b, c = 0, d, e = 0;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	scanf("%d", &b);
	for (i = 0; i < m; i++) {

		for (j = 0; j < n; j++) {
			if (a[i][j] == b)
				c++;
		}
		printf("%d ", c);
		for (j = 0; j < n; j++)
			if (a[i][j] == b)
				printf("%d ", j);

		printf("\n");
		if (c > e)
			e = c;
	}
	if (e == 0)
		printf("no");
	else
		printf("%d", e - 1);
}