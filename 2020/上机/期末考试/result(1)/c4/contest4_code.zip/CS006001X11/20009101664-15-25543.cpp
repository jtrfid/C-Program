#include<stdio.h>
int main()
{
	int m,n,i,j,b,t,x[100][100],p[100],key;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	for(j=0;j<n;j++)
	scanf("%d",&x[i][j]);
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		int cishu=0,a[100]={0},k=1;
		for(j=0;j<n;j++)
			if(x[i][j]==key)
			{
				cishu++;
				a[k++]=j;
			}
			if(cishu==0)
				printf("0");
			else
			{
				printf("%d ",cishu);
					for(t=1;t<k;t++)
						printf("%d ",a[t]);
			}
			p[i]=cishu;
			printf("\n");
	}
	int max=0,zui;
	for(i=0;i<m;i++)
	{
		if(max<p[i])
		{
			zui=i;
			max=p[i];
		}
	}
	if(max==0)
		printf("no");
	else
		printf("%d",zui);
	return 0;
}