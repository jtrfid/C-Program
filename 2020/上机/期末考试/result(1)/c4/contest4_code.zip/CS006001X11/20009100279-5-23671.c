#include <stdio.h>

void main()
{
	int n, i;
	int odd = 0, even = 0, div = 0;
	int min = 0;
	scanf("%d", &n);
	for(i = n; i <= (5*n); i++)
	{
		if (i % 2 == 0) even ++;
		if (i % 2 != 0) odd++;
		if (i % 3 == 0)
			if (i % 5 != 0)
				div++;
	}
	min = (odd < even) ? odd : even;
	min = (min < div) ? min : div;
	printf("%d %d %d\n%d", odd, even, div, min);
}