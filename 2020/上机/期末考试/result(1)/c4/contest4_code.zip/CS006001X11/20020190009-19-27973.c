#include <stdio.h>
#include <string.h>

int main() {
	int i, j, k;
	int n;
	int a[17] = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};
	int flag1 = -1, flag2 = 0;
	int sum = 0;
	int mo;
	char moo;
	scanf("%d\n", &n);
	char shenfenzheng[19];
	for (i = 0; i < n; i++) {
		for (j = 0; j < 19; j++) {
			scanf("%c", &shenfenzheng[j]);
		}
		for (j = 0; j < 17; j++) {
			if (shenfenzheng[j] < '0' || shenfenzheng[j] > '9') {
				for (k = 0; k < 19; k++) {
					printf("%c", shenfenzheng[k]);
					flag1 = 0;
				}
				printf("\n");
				break;
			}
		}
		if (flag1 == 0) {
			flag1 = -1;
			continue;
		}
		for (j = 0; j < 17; j++) {
			k = shenfenzheng[j] - '0';
			sum += k * a[j];
		}
		mo = sum % 11;
		sum = 0;
		switch (mo) {
			case 0:
				moo = '1';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 1:
				moo = '0';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 2:
				moo = 'X';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 3:
				moo = '9';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 4:
				moo = '8';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 5:
				moo = '7';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 6:
				moo = '6';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 7:
				moo = '5';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 8:
				moo = '4';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 9:
				moo = '3';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
			case 10:
				moo = '2';
				if (moo == shenfenzheng[17]) {
					break;
				} else {
					for (j = 0; j < 19; j++) {
						printf("%c", shenfenzheng[j]);
					}
					printf("\n");
					flag2++;
				}
				break;
		}
	}
	if (flag2 == 0) {
		printf("All passed");
	}
	return 0;
}