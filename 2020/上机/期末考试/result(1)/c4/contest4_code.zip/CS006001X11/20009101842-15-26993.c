#include<stdio.h>
#include<string.h>
int main()
{
	int m,n,a[200][200],key,c[200][200]={0};
	int b[200]={0},i,j,k=0,max,d[200],f=0,l;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
			{
				b[i]++;
				c[i][k]=j;
				k++;
			}
		}
		
	}
	for(i=0;i<m;i++)
	{
		l=0;
		max=b[0];
		if(max<b[i])
		{
			max=b[i];
			d[l]=i;
			l++;
		}
	}
	for(i=0;i<l;i++)
	{
		max=d[0];
		if(max>d[0])
			max=d[0];
	}
	for(i=0;i<m;i++)
	{ 
		if(b[i]!=0)
			f++;
	}
	if(f==0)
	{
		for(i=0;i<m;i++)
		{ 
			printf("%d\n",b[i]);
		}
		printf("no");
	}
	if(f!=0)
	{



	for(i=0;i<m;i++)
	{ 
		printf("%d ",b[i]);
		for(j=0;j<k;j++)
		{
			if(b[i]==0)
				continue;
		
			printf("%d ",c[i][j]);
		}
		printf("\n");
	}
	printf("%d",max);
	}
}

				

