#include<stdio.h>
int main()
{
	char str[100][20];
	int i,n,j,arr[100][18],real,sum,res,flag=0,reg=0;
	char man[11]={'1','0','X','9','8','7','6','5','4','3','2'};
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",str[i]);
		for(j=0;j<18;j++)
		{
			if(str[i][j]=='X')
				arr[i][j]==10;
			else
				arr[i][j]=str[i][j]-48;
		}
	}
	for(i=0;i<n;i++)
	{
		reg=0;
		sum=arr[i][0]*7+arr[i][1]*9+arr[i][2]*10+arr[i][3]*5;
		sum=sum+arr[i][4]*8+arr[i][5]*4+arr[i][6]*2+arr[i][7]*1;
		sum=sum+arr[i][8]*6+arr[i][9]*3+arr[i][10]*7+arr[i][11]*9;
		sum=sum+arr[i][12]*10+arr[i][13]*5+arr[i][14]*8+arr[i][15]*4;
		sum=sum+arr[i][16]*2;
		res=sum%11;
		if(man[res]!=str[i][17])
		{
			flag=1;
			for(j=0;j<18-reg;j++)
			{
				if(arr[i][j]==10)
				{
					printf("X");
					reg++;
					j++;
				}
				else
					printf("%d",arr[i][j]);
			}
			printf("\n");
		}
	}
	if(flag==0)
		printf("All passed\n");
	return 0;
}