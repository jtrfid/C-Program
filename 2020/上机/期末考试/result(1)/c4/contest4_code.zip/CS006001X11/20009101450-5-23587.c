#include<stdio.h>
int main()
{
	int n,j=0,o=0,c=0,i,min;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==1)
			j++;
		if(i%2==0)
			o++;
		if(i%3==0&&i%5!=0)
			c++;
	}
	min=c;
	if(j<min)
		min=j;
	if(o<min)
		min=o;
	printf("%d %d %d\n%d",j,o,c,min);
}
