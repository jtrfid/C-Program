#include <stdio.h>
#include <string.h>
int main()
{
	char str[100][20];
	int a[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	char ch[11]={'1','0','X','9','8','7','6','5','4','3','2'};
	int i,j,n,b[100],sum=0,k=0,z,leap=1;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		getchar();
		gets(str[i]);
	}
	for(i=0;i<n;i++)
	{
		sum=0;
		for(j=0;j<17;j++)
		{
			leap=1;
			if(str[i][j]>='0'&&str[i][j]<='9')
			{
				sum+=(str[i][j]-'0')*a[j];
			}
			else
			{
				b[k]=i;
				leap=0;
				k++;
				break;
			}
		}
		if(leap!=0)
		{
			z=sum%11;
			if((str[i][17]+'0')!=ch[z])
			{
				b[k]=i;
				k++;
			}
		}
	}
	for(i=1;i<k;i++)
	{
		printf("%s\n",str[i]);
	}
	if(k==0)
		printf("All passed");
	return 0;
}
			

