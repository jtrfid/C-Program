#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int m,n,a[200][200],cishu,s[200];
	int key,flag=0,t=0,i,j;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	}
	scanf("%d",&key);
	
	for(i=0;i<m;i++)
	{
		cishu=0;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
				cishu++;
		}	
		s[i]=cishu;
	}
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(s[i]<s[j])
				flag++;
		}
		if(flag!=0)
			continue;
		else
		{
			t=i;
			break;
		}
	}
	for(i=0;i<m;i++)
	{
		printf("%d ",s[i]);
	
		if(cishu!=0)
			for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
				printf("%d ",j);
		}	
		printf("\n");
	}
	if(t==0)
		printf("no");
	else
		printf("%d",t);
	
}