#include<stdio.h>
#include<string.h>
int main()
{
	int n;
	int sum=0;
	char m;
	int i,j,k=0;
	char num[100][18];
	char wenti[100][18];
	int qz[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
	int flag1=1,flag2=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%s",&num);
	for(i=0;i<n;i++)
	{
		flag1=1;
		for(j=0;j<17;j++)
		{
			if(num[i][j]<'0'||num[i][j]>'9')
			{
				strcpy(wenti[k],num[i]);
				k++;
				flag1=0;
				flag2=1;
				break;
			}
		}
		if(flag1==1)
		{
			for(j=0;j<17;j++)
			{sum=sum+(num[i][j]-48)*qz[j];}
			sum=sum%11;
			if(sum==0)
				m='1';
			if(sum==1)
				m='0';
			if(sum==2)
				m='X';
			if(sum==3)
				m='9';
			if(sum==4)
				m='8';
			if(sum==5)
				m='7';
			if(sum==6)
				m='6';
			if(sum==7)
				m='5';
			if(sum==8)
				m='4';
			if(sum==9)
				m='3';
			if(sum==10)
				m='2';

			if(m!=num[i][17])
			{
				strcpy(wenti[k],num[i]);
				k++;
				flag2=1;
			}
		}
		
	}
	if(flag2==0)
		printf("All passed");
	else
	{
		for(i=0;i<k;i++)
		{
		printf("%s\n",wenti[i]);
		}
	}
	return 0;



}