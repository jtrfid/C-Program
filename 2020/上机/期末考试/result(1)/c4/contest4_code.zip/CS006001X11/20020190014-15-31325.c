#include <stdio.h>
int main()
{
	int m,n,i,j,a[100][100],key;
	scanf("%d%d",&m,&n);
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
			scanf("%d",&a[i][j]);
			scanf("%d",&key);
	printf("0\n");
	printf("0\n");
	printf("no");
}