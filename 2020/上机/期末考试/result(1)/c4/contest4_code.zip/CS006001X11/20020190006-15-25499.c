#include<stdio.h>
int main()
{
	int m,n;
	int a[200][200];
	int key;
	int i,j,k;
	int count=0;
	int hang;
	int b[100];
	int p;
	int max;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		max=count;
		count=0;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key)
			{
				count++;
				b[p]=j;
				p++;
			}
		}
		if(count>max)
			max=count;
		printf("%d ",count);
		if(p=0)
			continue;
		else
		{
			for(k=0;k<p;k++)
				printf("%d ",b[k]);
		}
		printf("\n");
	}
	printf("%d",max);
	return 0;
}