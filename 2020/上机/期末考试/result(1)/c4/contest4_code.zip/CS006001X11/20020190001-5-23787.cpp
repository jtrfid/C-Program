#include<stdio.h>
int main()
{
	int  n,o=0,j=0,q=0,min,i;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
		{o++;}
		else
		{j++;}
		if(i%3==0&&i%5!=0)
		{q++;}
	}
	min=j;
	if(o<j)
	{min=o;}

	if(q<j)
	{min=q;}
	if(q<o)
	{min=q;}
	printf("%d %d %d\n",j,o,q);
	printf("%d",min);










return 0;
}