#include<stdio.h>
int main()
{
	int m,n,i,j,a[100][100],find,k,count,zuobiao[100],hang[100],max=-1,icount;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&find);
	for(i=0;i<m;i++)
	{
		count=0;k=0;
		for(j=0;j<n;j++)
		{
			if(a[i][j]==find)
			{
				count++;
				zuobiao[k]=j;
				k++;
			}
		}
		hang[i]=count;
		if(count==0)
		{
			printf("0\n");
		}
		else
		{		
			printf("%d ",count);
			for(j=0;j<k;j++)
			{
				printf("%d ",zuobiao[j]);
			}
			printf("\n");
		}
	}
	for(i=0;i<n;i++)
	{
		if(hang[i]>max)
		{
			max=hang[i];
			icount=i;
		}
	}

	if(max!=0)printf("%d",icount);
	if(max==0) printf("no");



	return 0;
}

