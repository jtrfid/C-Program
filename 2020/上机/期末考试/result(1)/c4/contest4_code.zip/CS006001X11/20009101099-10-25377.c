#include<stdio.h>
#include<string.h>
int main()
{
	char x,a[100],b[100];
	int i,l,m=-1,n=-1;
	scanf("%c",&x);
	scanf("%s",&a);
	strcpy(b,a);
	strupr(b);
	l=strlen(a);
	if('x'>=97) x=x-32;
	for(i=0;i<l;i++)
	{
		if(b[i]==x) 
		{
			m=i;
			break;
		}
	}
	for(i=0;i<l;i++)
	{
		if(b[i]==x)
		{
			n=i;
			if(n!=m) break;
		}
	}
	if(m!=n)
	{
	for(i=m;i<=n;i++) printf("%c",a[i]);
	}
	if(m==n&&m!=-1)
	{
	for(i=m;i<l;i++) printf("%c",a[i]);
	}
	if(m==-1) printf("NO");

	return 0;
}




