#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int flag = 0, temp[100], i, k = 0;
	temp[0] = -1;
	temp[1] = -1;
	char x;
	char s[101] = {0}, temp2[101] = {0};
	scanf("%c", &x);
	scanf("%s", s);
	strcpy(temp2, s);
	if (x >= 'A' && x <= 'Z') {
		x = x + 32;
	}
	for (i = 0; i < strlen(temp2); i++) {
		if (temp2[i] >= 'A' && temp2[i] <= 'Z')
			temp2[i] = temp2[i] + 32;
		if (temp2[i] == x) {
			flag++;
			temp[k] = i;
			k++;
		}
	}
	if (flag == 0)
		printf("NO");
	else if (temp[0] != -1 && temp[1] == -1) {
		for (i = temp[0]; i < strlen(temp2); i++) {
			printf("%c", s[i]);
		}
	} else if (temp[0] != -1 && temp[1] != -1) {
		for (i = temp[0]; i <= temp[1]; i++) {
			printf("%c", s[i]);
		}
	}
	return 0;
}