#include<stdio.h>
int main()
{
	int n,i,x=0,y=0,z=0,min;
	scanf("%d",&n);
	for(i=n;i<=5*n;i++)
	{
		if(i%2!=0) x++;
		if(i%2==0) y++;
		if(i%3==0&&i%5!=0) z++;
	}
	min=x;
	if(x>y) min=y;
	if(x>z) min=z;
	if(y>z) min=z;
	printf("%d %d %d\n%d",x,y,z,min);
	return 0;
}
	
