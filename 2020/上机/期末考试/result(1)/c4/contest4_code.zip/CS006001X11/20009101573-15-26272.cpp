#include <iostream>
#include <algorithm>
using namespace std;

struct c {
	int num;
	int co;
};

int cmp(c a, c b) {
	if (a.co > b.co)
		return 1;
	else if (a.co == b.co) {
		if (a.num < b.num)
			return 0;
	}
}

int main() {
	int a[100][100];
	int m, n;
	int key;
	c count[100] = {0, 0};
	int pos[100][100];
	int k = 0;
	cin >> m >> n;
	for (int i = 0; i < m; i++)
		count[i].num = i;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cin >> a[i][j];
		}
	}
	cin >> key;
	for (int i = 0; i < m; i++) {
		k = 0;
		for (int j = 0; j < n; j++) {
			if (a[i][j] == key) {
				count[i].co++;
				pos[i][k] = j;
				k++;
			}
		}
	}
	int judge = 0;
	for (int i = 0; i < m; i++) {
		cout << count[i].co << ' ';
		if (count[i] .co != 0) {
			judge = 1;
			for (int j = 0; j < count[i].co; j++)
				cout << pos[i][j] << ' ';
			cout << endl;
		} else
			cout << endl;
	}
	if (judge == 0)
		cout << "no";
	else {

		sort(count, count + m, cmp);
		cout << count[0].num;
	}
}