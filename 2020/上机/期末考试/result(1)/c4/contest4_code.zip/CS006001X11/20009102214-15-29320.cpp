#include<stdio.h>
#include<string.h>
int main()
{
	printf("0\n0\nno\n");
}
