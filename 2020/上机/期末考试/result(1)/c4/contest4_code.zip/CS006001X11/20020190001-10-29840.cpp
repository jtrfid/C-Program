#include<stdio.h>
int main()
{
	char x;
	int i,flag=1;
	char a[100];
	scanf("%c",&x);
	getchar();
	gets(a);
	for(i=0;;i++)
	{
		if(a[i]==x||a[i]==x-32||a[i]==x+32)
		{
			printf("%c",x);
			for(i=i+1;a[i]!='\0';i++)
			{
				printf("%c",a[i]);
			    if(a[i]==x||a[i]==x-32||a[i]==x+32)
				{break;}
			}
			flag=0;
			break;
		}
		if(a[i+1]=='\0')
		{break;}
		
	}
	if(flag)
	{printf("NO");}
return 0;

}