#include <stdio.h>
#include <string.h>
int main()
{
	char x,a[100];
	int i,n,j=0,b[2];
	int flag=0,k=0;
	scanf("%c\n",&x);
	gets(a);
	n=strlen(a);
	
    if(x>='a'&&x<='z')
	{for(i=0;i<n;i++)
		{
		if(a[i]==x||a[i]==x-32)
		{b[j]=i;j++;}
		if(a[i]!=x&&a[i]!=x-32)
			k++;
		
		}
	 if(k==n-1)
	{for(i=b[0];i<n;i++)
	printf("%c",a[i]);}
	else if(k==n)
		printf("NO");
	else
	{for(i=b[0];i<=b[1];i++)
	printf("%c",a[i]);}
	}
	else if(x>='A'&&x<='Z')
	{
		for(i=0;i<n;i++)
		{
		if(a[i]==x||a[i]==x+32)
		{b[j]=i;j++;}
		if(a[i]!=x&&a[i]!=x+32)
			flag++;
		}

		 if(flag==n-1)
		{ for(i=b[0];i<n;i++)
		printf("%c",a[i]);}
		else if(flag==n)
			printf("NO");
		else
		{ for(i=b[0];i<=b[1];i++)
		printf("%c",a[i]);}
	}

	else
	{for(i=0;i<n;i++)
		{
		if(a[i]==x)
		{b[j]=i;j++;}
		if(a[i]!=x)
			k++;
		
		}
	 if(k==n-1)
	{for(i=b[0];i<n;i++)
	printf("%c",a[i]);}
	else if(k==n)
		printf("NO");
	else
	{for(i=b[0];i<=b[1];i++)
	printf("%c",a[i]);}
	}


}

