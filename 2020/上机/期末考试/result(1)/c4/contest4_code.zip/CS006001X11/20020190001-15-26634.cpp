#include<stdio.h>
int main()
{
	int a[200][200],sum[10000]={0},b[200];
	int m,n,k,i,j,y=0,q,max=0,flag=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{scanf("%d",&a[i][j]);}
	}
	scanf("%d",&k);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==k)
			{sum[i]++;b[y]=j;y++;}
		}
		printf("%d ",sum[i]);
		if(sum[i]!=0)
		{
			for(q=0;q<y;q++)
				printf("%d ",b[q]);
		}
	
		printf("\n");
		y=0;
	}
	for(i=0;i<m;i++)
	{
		if(sum[i]>max)
		{max=i;}
		if(sum[i]!=0)
			flag=1;
	}
	if(flag)
	{
		printf("%d",max);}
	else
	{printf("no");}
	return 0;
}
	

