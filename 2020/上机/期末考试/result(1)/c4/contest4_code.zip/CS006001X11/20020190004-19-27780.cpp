#include <stdio.h>

typedef struct {
	char sim[18];
} z;

int main() {
	int i, j, k, flag, p, q, num, zhengque = 0, sum[100] = {0}, jieguo = 0;
	int quan[17] = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2}, Q = 0;
	char zhuanhua[11] = {'1', '0', 'X', '9', '8', '7', '6', '5',  '4',  '3', '2'};
	scanf("%d", &num);
	z zheng[100];
	for (i = 0; i < num; i++)
		scanf("%s", zheng[i].sim);
	for (i = 0; i < num; i++) {
		Q = 0;
		zhengque = 0;
		for (j = 0; j < 17; j++) {
			if ('0' <= zheng[i].sim[j] && zheng[i].sim[j] <= '9') {
				sum[i] = sum[i] + (zheng[i].sim[j] - 48) * quan[Q];
				Q++;
			} else
				zhengque--;
		}
		if (zhengque != 0)
			continue ;
		else {
			sum[i] = sum[i] % 11;
			if (zhuanhua[sum[i]] == zheng[i].sim[17] ) {
				jieguo++;
			}
		}
	}
	if (jieguo == num)
		printf("All passed");
	else {
		for (i = 0; i < num; i++) {
			if (sum[i] != zheng[i].sim[17] - 48) {
				for (k = 0; k < 18; k++) {
					printf("%c", zheng[i].sim[k]);
				}
				printf("\n");
			}
		}
	}

}