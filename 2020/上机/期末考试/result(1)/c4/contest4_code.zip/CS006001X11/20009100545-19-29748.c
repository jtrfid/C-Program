#include<stdio.h>
int main()
{
	int i,j,n,count[100]={0},quan[20]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2},count1=0;
	char ch[100][100];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",&ch[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<17;j++)
		{
			if(ch[i][j]!='X')
			{
				count[i]=count[i]+(ch[i][j]-'0')*quan[j];
			}
			else count[i]=count[i]+10*quan[j];
		}

	}
	for(i=0;i<n;i++)
	{
		count[i]=count[i]%11;
	}
	for(i=0;i<n;i++)
	{
		if(count[i]==0&&ch[i][17]=='1')
		{
			count1++;
		}
		if(count[i]==1&&ch[i][17]=='0')count1++;
		if(count[i]==2&&ch[i][17]=='X')count1++;
		if(count[i]==3&&ch[i][17]=='9')count1++;
		if(count[i]==4&&ch[i][17]=='8')count1++;
		if(count[i]==5&&ch[i][17]=='7')count1++;
		if(count[i]==6&&ch[i][17]=='6')count1++;
		if(count[i]==7&&ch[i][17]=='5')count1++;
		if(count[i]==8&&ch[i][17]=='4')count1++;
		if(count[i]==9&&ch[i][17]=='3')count1++;
		if(count[i]==10&&ch[i][17]=='2')count1++;
	}
	for(i=0;i<n;i++)
	{
		if(count[i]==0)
		{
			if(ch[i][17]!='1')printf("%s\n",ch[i]);
		}
		if(count[i]==1)
		{
			if(ch[i][17]!='0')printf("%s\n",ch[i]);
		}
		if(count[i]==2)
		{
			if(ch[i][17]!='X')printf("%s\n",ch[i]);
		}
		if(count[i]==3)
		{
			if(ch[i][17]!='9')printf("%s\n",ch[i]);
		}
		if(count[i]==4)
		{
			if(ch[i][17]!='8')printf("%s\n",ch[i]);
		}
		if(count[i]==5)
		{
			if(ch[i][17]!='7')printf("%s\n",ch[i]);
		}
		if(count[i]==6)
		{
			if(ch[i][17]!='6')printf("%s\n",ch[i]);
		}
		if(count[i]==7)
		{
			if(ch[i][17]!='5')printf("%s\n",ch[i]);
		}
		if(count[i]==8)
		{
			if(ch[i][17]!='4')printf("%s\n",ch[i]);
		}
		if(count[i]==9)
		{
			if(ch[i][17]!='3')printf("%s\n",ch[i]);
		}
		if(count[i]==10)
		{
			if(ch[i][17]!='2')printf("%s\n",ch[i]);
		}
	
	}
	if(count1==n)printf("All passed");


	return 0;
}

