#include <stdio.h>

int main() {
	int a[200][200], i, j, key, m, n, b[200] = {0}, c[200];
	int x, y, temp, s, z = 0;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	scanf("%d", &key);
	for (i = 0; i < m; i++) {
		for (s = 0; s < x; s++) {
			c[s] == 0;
		}
		x = 0;
		for (j = 0; j < n; j++) {
			if (a[i][j] == key) {
				b[i]++;
				c[x] = j;
				x++;
			}
		}
		printf("%d ", b[i]);
		for (y = 0; y < x; y++) {
			printf("%d ", c[y]);
		}
		printf("\n");
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m - i - 1; j++) {
			if (b[j] > b[j + 1]) {
				temp = b[j];
				b[j] = b[j + 1];
				b[j + 1] = temp;
			}
		}
	}
	for (i = 0; i < m; i++) {
		if (b[i] != 0) {
			z = 1;
		}
	}
	if (z == 0)
		printf("no");
	else
		printf("%d", b[0]);
	return 0;
}