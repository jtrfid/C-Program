#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int a[201][201];
	int count[201]={0},stu=0;
	int i,j,max,m,n,key,temp=1,sign=0;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==key) {temp=1;sign=1;count[i]++;}
		}
		if(sign==0) printf("0");
		else{
			printf("%d ",count[i]);
            for(j=0;j<n;j++)
		{
			if(a[i][j]==key) printf("%d ",j);
		}

		}
		printf("\n");

	}
	max=count[0];
    for(i=0;i<m;i++)
	{
		if(count[i]>max) {max=count[i];stu=i;}
	}
	printf("%d",stu);

	return 0;
}