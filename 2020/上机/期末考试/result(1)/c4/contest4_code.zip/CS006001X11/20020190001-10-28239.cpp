#include<stdio.h>
int main()
{
	char x;
	int i,flag=1;
	char a[100];
	scanf("%c",&x);
	getchar();
	gets(a);
	for(i=0;;i++)
	{
		if(a[i]==x)
		{
			printf("%c",x);
			for(i=i+1;a[i]!='\0';i++)
			{
				printf("%c",a[i]);
			    if(a[i]==x)
				{break;}
			}
			flag=0;
			break;
		}
	}
	if(flag)
	{printf("no");}
return 0;

}