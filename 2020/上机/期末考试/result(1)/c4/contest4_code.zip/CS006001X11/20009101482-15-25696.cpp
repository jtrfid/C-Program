#include<stdio.h>
int main()
{
	int m,n,i,j,max=0,hangshu=0,temp=0,juzhen[200][200],cishu[200]={0},key,weizhi[200][200];
	scanf("%d%d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&juzhen[i][j]);
		}
	}
	scanf("%d",&key);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(juzhen[i][j]==key)
			{
				weizhi[i][cishu[i]]=j;
				cishu[i]++;
			}
		}
	}
	for(i=0;i<m;i++)
	{
		if(cishu[i]>max)
		{
			max=cishu[i];
			hangshu=i;
		}
		printf("%d ",cishu[i]);
		for(j=0;j<cishu[i];j++)
			printf("%d ",weizhi[i][j]);
		printf("\n");
	}
	if(max==0)printf("no");
	else printf("%d",hangshu);
	
}