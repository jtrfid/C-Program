#include<stdio.h>
int main()
{
	int m,n,a[200][200],i,j,s,c[200],w,b[200],k,max=0,h;
	scanf("%d%d",&m,&n);
	for(j=0;j<m;j++)
	{
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[j][i]);
		}
	}
	scanf("%d",&s);
	for(j=0;j<m;j++)
	{
		c[j]=0;
		for(i=0;i<n;i++)
		{
			if(a[j][i]==s)
			{
				c[j]++;
				b[c[j]-1]=i;
			}
		}
		if(c[j]==0)
			printf("0\n");
		else
		{
			printf("%d ",c[j]);
			for(k=0;k<c[j];k++)
				printf("%d ",b[k]);
			printf("\n");
		}
	}
	for(i=0;i<m;i++)
	{
		if(c[i]>max)
		{
			max=c[i];
			h=i;
		}
	}
	if(max==0)
		printf("no");
	else
	printf("%d",h);
}



