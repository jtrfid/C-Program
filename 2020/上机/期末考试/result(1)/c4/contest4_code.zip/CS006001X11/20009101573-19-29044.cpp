#include <iostream>
#include <string>
using namespace std;

int main() {
	int n;
	cin >> n;
	int z;
	int sum = 0;
	int judge = 1;
	int b[17] = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};
	int a[100][18];
	for (int i = 0; i < n; i++) {
		sum = 0;
		for (int j = 0; j < 18; j++) {
			cin >> a[i][j];
			if (j != 17)
				sum += b[j] * a[i][j];
		}
		z = sum % 11;
		if (z == a[i][17])
			judge = 0;
		else
			for (int p = 0; p < 18; p++)
				printf("%d", a[i][p]);
		printf("\n");
	}
	if (judge == 1)
		printf("All passed");
}