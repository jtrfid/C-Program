#include <stdio.h>

int main() {
	int m, n, i, j, k, flag = 0, key, max = 0, mo = 0;
	scanf("%d %d", &m, &n);
	int a[m][n], cunzai[m] = {0}, weizhi[n] = {-1, 0}, w = 0;
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	scanf("%d", &key);
	for (i = 0; i < m; i++) {
		w = 0;
		for (j = 0; j < n; j++) {
			if (a[i][j] == key) {
				cunzai[i]++;
				weizhi[w] = j;
				w++;
			}
		}
		if (cunzai[i] == 0)
			printf("0");
		else {
			printf("%d ", cunzai[i]);
			for (k = 0; k < w; k++)
				printf("%d ", weizhi[k]);
		}
		printf("\n");
	}
	for (i = 0; i < m; i++) {
		if (max < cunzai[i]) {
			mo = i;
			max = cunzai[i];
		}
	}
	if (mo == 0)
		printf("no");
	else
		printf("%d", mo);

}