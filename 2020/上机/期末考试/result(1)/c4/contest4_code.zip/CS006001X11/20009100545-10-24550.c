#include<stdio.h>
#include<string.h>
int main()
{
	char c[10],ch[100],str[100],count[100];
	int i,j,k;	
	int b[2];
	b[0]=-1;
	b[1]=-1;
	gets(c);
	gets(ch);
	strcpy(str,ch);
	strupr(c);
	strupr(str);
	k=0;
	for(i=0;i<strlen(str);i++)
	{
		if(str[i]==c[0])
		{
			b[k]=i;
			k++;
		}
	}
	if(b[0]!=-1&&b[1]!=-1)
	{
		for(i=b[0];i<=b[1];i++)
		{
			printf("%c",ch[i]);
		}
	}
	if(b[0]!=-1&&b[1]==-1)
	{
		for(i=b[0];i<strlen(str);i++)
		{
			printf("%c",ch[i]);
		}
	}
	if(b[0]==-1&&b[1]==-1) printf("NO");

	return 0;
}