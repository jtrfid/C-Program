#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	char x;
	scanf("%c\n", &x); //shuru X
	char a[100] = {0};
	char b[100] = {0};
	int n[2] = {0, 0, 0};
	int i, j = 0;
	gets(a);
	if (x >= 97) {
		for (i = 0; a[i] != '\0'; i++) {
			if (a[i] == x || a[i] == (x - 32)) {
				n[j] = i;
				j++;
				if (j == 2)
					break;
			}
		}

	} else {
		for (i = 0; a[i] != '\0'; i++) {
			if (a[i] == x || a[i] == (x + 32)) {
				n[j] = i;
				j++;
				if (j == 2)
					break;
			}
		}
	}
	if (j == 0)
		printf("NO");

	else {

		for (i = n[0];; i++) {
			printf("%c", a[n[i]]);
			if (i == n[1])
				break;
		}
	}

	return 0;
}
