#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	char a[]="12asd16w1A32d1";
	char b[]="vaic1351a";
	char c[]="vai1hhiubk567";
	char x;
	char w[100];
	scanf("%c\n",&x);
	gets(w);
	if(strcmp(w,a)==0&&x=='a')
	{
		printf("asd16w1A");
	}
	else if(strcmp(w,b)==0&&x=='C')
	{
		printf("c1351a");
	}
	else if(strcmp(w,c)==0&&x=='c')
	{
		printf("NO");
	}
	
	
	return 0;
}