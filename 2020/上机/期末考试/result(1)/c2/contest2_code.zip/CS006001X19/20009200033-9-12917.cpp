#include <stdio.h>
int main()
{
	int n,i,j,temp;
	int x,y;
	scanf("%d\n",&n);
	int a[30];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int b[30];
	for(i=0;i<30;i++)
	{
		b[i]=a[i];
	}
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[j]>a[i])
			{
				temp=a[j];
				a[j]=a[i];
				a[i]=temp;
			}
		}
	}
	for(i=a[0];i>0;i++)
	{
		if(i%a[0]==0&&i%a[n-1]==0)
		{
			x=i;
			break;
		}
	}
	for(i=a[n-1];i>0;i--)
	{
		if(a[0]%i==0&&a[n-1]%i==0)
		{
			y=i;
			break;
		}
	}
	for(i=0;i<n;i++)
	{
		if(b[i]==a[0])
		{
			b[i]=x;
		}
		if(b[i]==a[n-1])
		{
			b[i]=y;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",b[i]);
	}
	return 0;
}

