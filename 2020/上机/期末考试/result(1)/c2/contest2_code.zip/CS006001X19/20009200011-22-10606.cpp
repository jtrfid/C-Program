#include<stdio.h>
#include<math.h>
double len(int m,int n,int a[],int q,int b[],int w)
{
	int s1=0,s2=0,temp,i;
	if(m>n)
	{
		temp=n;
		n=m;
		m=temp;
	}
	for(i=m;i<n;i++)
	{
		s1+=sqrt((a[i]-a[i+1])*(a[i]-a[i+1])+(b[i]-b[i+1])*(b[i]-b[i+1]));
	}
	for(i=n;i<=q;i++)
	{
		if(i!=q)
		  s2+=sqrt((a[i]-a[i+1])*(a[i]-a[i+1])+(b[i]-b[i+1])*(b[i]-b[i+1]));
		if(i==q)
		  s2+=sqrt((a[i]-a[1])*(a[i]-a[1])+(b[i]-b[1])*(b[i]-b[1]));
	}
	for(i=1;i<m;i++)
	{
		s2+=sqrt((a[i]-a[i+1])*(a[i]-a[i+1])+(b[i]-b[i+1])*(b[i]-b[i+1]));
	}
	if(s1>=s2)
	   return s2;
	else
	   return s1;   
}
int main()
{
	long int N;
	scanf("%d",&N);
	int i,a[N],b[N];
	for(i=1;i<=N;i++)
	{
		scanf("%d %d %d",&i,&a[i],&b[i]);
	}
	int m[N*N],n[N*N],c=1,j=0;
	while(c==1)
	{
		j++;
		scanf("%d %d",&m[j],&n[j]);
		if(m[j]==0&&n[j]==0)
		   c=0;
	}
	double s;
	for(i=1;i<j;i++)
	{
		s=len(m[i],n[i],a,N,b,N);
		printf("%.2f\n",s);
	}
	return 0;
}
