#include <stdio.h>
int main()
{
	int a,b,m,n,c[50][50],i,j,k=0,l=0;
	scanf("%d %d",&a,&b);
	for(i=0;i<=a-1;i++)
		for(j=0;j<=b-1;j++)
		{
			scanf("%d",&c[i][j]);
		}
	scanf("%d %d",&m,&n);
	while(l<=n)
	{	
		k=0;
		while(k<m)
		{
			for(i=0;i<=a;i++)
			for(j=0;j<=b;j++)
			{
				c[i+l*a][j+k*b]=c[i][j];
			}
			k++;
		}	
		l++;
	}
	for(i=0;i<=m*a-1;i++)
		for(j=0;j<=n*b-1;j++)
		{
			printf("%d ",c[i][j]);
			if(j==n*b-1)printf("\n");
		}
	return 0;
}
