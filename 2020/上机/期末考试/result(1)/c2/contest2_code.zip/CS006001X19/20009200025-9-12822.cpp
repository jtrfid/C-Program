#include <cstdio>
#include <algorithm>
using namespace std;
int gongyueshu(int a,int b)
{
    int n=a;
    if(a==0)
        return b;
    if(b==0)
        return a;
   while(1)
   {
       if(a%n==0&&b%n==0)
        return n;
       else n--;
   }
}
int gongbeishu(int a,int b)
{
    int t=gongyueshu(a,b);
    return (a/t)*(b/t)*t;
}
int main()
{
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
   int b[n];
    for(int i=0;i<n;i++)
    {
       b[i]=a[i];
    }
    sort(a,a+n);
    int syd=gongyueshu(a[0],a[n-1]);
    int syd1=gongbeishu(a[0],a[n-1]);
    for(int i=0;i<n;i++)
    {
      if (b[i]==a[0])
      {
          b[i]=syd;
      }
     else  if(b[i]==a[n-1])
      {
          b[i]=syd1;
      }
    }
      for(int i=0;i<n;i++)
    {
        printf("%d ",b[i]);
    }
    return 0;
}
