#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int n,a,b,t,s,sum,i,c=0;
	scanf("%d",&n);
	if(n%2!=0)
	{
		t=n/2;
		a=(t-1)*t+2*t;
		s=((n-1)*n)/2;
		b=s-a;
	}
	if(n%2==0)
	{
		t=n/2;
		a=(t-1)*t;
		s=((n-1)*n)/2;
		b=s-a;
	}
	for(i=1;i<n;i++)
	{
		if(i%5==0&&i%3!=0)
		{
			c=c+i;
		}
		
	}
	printf("%d %d %d\n",b,a,c);
	if(a>=c&&a>=b)
		sum=a;
	if(b>=a&&b>=c)
		sum=b;
	if(c>=a&&c>=b)
		sum=c;
	printf("%d",sum);
	return 0;
}
