#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	
	int c[50][50];
	int i,j,k,m,n;
	
	
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		scanf("%d",&c[i][j]);
	}
	scanf("%d %d",&m,&n);
	for(k=1;k<=n;k++)
	{
		for(i=0;i<a;i++)
		{
			for(j=b;j<b*n;j++)
			c[i][j]=c[i][j-b];
		}
	}
	for(k=1;k<=m;k++)
	{
	    for(i=0;i<a;i++)
	    {
		    for(j=0;j<b*n;j++)
		    {
			    printf("%d ",c[i][j]);
		    }
		    printf("\n");
	    }
    }
	return 0;
}
