#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int x[a][b];
	int i,j,h,k,t,g;
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&x[i][j]);
		}
	}
	int m,n;
	scanf("%d%d",&m,&n);
	int y[m*a][n*b];
	for(h=0;h<a;h++)
	{
		g=h;
		for(i=0;i<m*a;i=i+a)
	{
		for(j=0;j<n*b;j++)
		{
			k=j%b;
			y[i][j]=x[g][k];
		}
	}
	g++;
	for(i=1;i<m*a;i=i+a)
	{
		for(j=0;j<n*b;j++)
		{
			t=j%b;
			y[i][j]=x[g][t];
			
		}
	}
	g++;
	if(g==a)
	break;
	}
	
	for(i=0;i<m*a;i++)
	{
		for(j=0;j<n*b;j++)
		{
			printf("%d ",y[i][j]);
		}
		printf("\n");
	}
	return 0 ;
}
