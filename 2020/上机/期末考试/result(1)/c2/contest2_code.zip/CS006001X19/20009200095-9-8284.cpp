#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	int i,j,max=0,min=1001,k,t;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			k=i;
		}
	}
	for(i=0;i<n;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			t=i;
		}
	}
	for(i=max;i>0;i++)
	{
		if(i%max==0&&i%min==0)
		{
			a[k]=i;
			break;
		}
	}
	for(j=min;j>0;j--)
	{
		if(max%j==0&&min%j==0)
		{
			a[t]=j;
			break;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	
	return 0 ;
}
