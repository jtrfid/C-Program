#include <stdio.h>
int main()
{
	int i,n,a=0,b=0,c=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		if(i%2!=0)a+=i;
		if(i%2==0)b+=i;
		if(i%5==0&&i%3!=0)c+=i;
	}
	printf("%d %d %d\n",a,b,c);
	if(a>=b&&a>=c)printf("%d",a);
	else if(b>=a&&b>=c)printf("%d",b);
	else printf("%d",c);
	return 0;
}
