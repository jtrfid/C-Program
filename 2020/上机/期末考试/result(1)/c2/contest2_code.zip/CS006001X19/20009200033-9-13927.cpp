#include <stdio.h>
int main()
{
	int n,i,j,temp;
	int x,y;
	scanf("%d\n",&n);
	int a[30];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int min=a[0];
	int max=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]<min)
		min=a[i];
		if(a[i]>max)
		max=a[i];
		
	}
	for(i=max;i>0;i++)
	{
		if(i%max==0&&i%min==0)
		{
			x=i;
			break;
		}
	}//zuixiaogongbeishu
	for(i=min;i>0;i--)
	{
		if(min%i==0&&max%i==0)
		{
			y=i;
			break;
		}
	}//zuidagongyueshu
	for(i=0;i<n;i++)
	{
		if(a[i]==max)
		a[i]=x;
		if(a[i]==min)
		a[i]=y;
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
