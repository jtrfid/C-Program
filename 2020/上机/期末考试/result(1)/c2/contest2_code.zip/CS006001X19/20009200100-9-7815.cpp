#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int max=a[0],min=a[0],maxi=0,mini=0;
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			maxi=i;
		}
		if(a[i]<min)
		{
			min=a[i];
			mini=i;
		}
	}
	int x;
	for(i=min;i>0;i--)
	{
		if(min%i==0&&max%i==0)
		{
			x=i;
			break;
		}
	}
	int y;
	for(i=1;i<=min*max;i++)
	{
		if(i%min==0&&i%max==0)
		{
			y=i;
			break;
		}
	}
	a[maxi]=y;
	a[mini]=x;
	printf("%d",a[0]);
	for(i=1;i<n;i++)
	{
		printf(" %d",a[i]);
	}
	return 0;
}
