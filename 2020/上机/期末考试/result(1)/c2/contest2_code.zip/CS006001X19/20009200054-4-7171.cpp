#include<stdio.h>
int main()
{
	int m,s1=0,s2=0,s3=0,max;
	scanf("%d",&m);
	
	int i;
	for(i=0;i<m;i++)
	{
		if(i%2!=0) s1+=i;
		else s2+=i;
		
		if(i%5==0 && i%3!=0) s3+=i;
	} 
	
	max=s1;
	if(max<s2) max=s2;
	if(max<s3) max=s3;
	printf("%d %d %d\n%d",s1,s2,s3,max);
	return 0;
}
