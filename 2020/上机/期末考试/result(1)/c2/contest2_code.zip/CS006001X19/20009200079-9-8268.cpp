#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	int max=0,min=1000,max_i,min_i;
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			max_i=i;
		}
		if(a[i]<min)
		{
			min=a[i];
			min_i=i;
		}
	}
	
	int yue,bei;
	for(i=max;;i++)
	{
		if(i%max==0&&i%min==0)
		{
			bei=i;
			break;
		}
	}
	for(i=min;;i--)
	{
		if(min%i==0&&max%i==0)
		{
			yue=i;
			break;
		}
	} 
	
	a[max_i]=bei;
	a[min_i]=yue;
	
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
}
