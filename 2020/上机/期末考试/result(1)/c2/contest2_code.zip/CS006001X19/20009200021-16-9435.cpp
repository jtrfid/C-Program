#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int x[a][b];
	int i,j,k,l;
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&x[i][j]);
		}
	}
	int m,n;
	scanf("%d%d",&m,&n);
	for(l=0;l<m;l++)
	{
		for(i=0;i<a;i++)
		{
			for(k=0;k<n;k++)
			{
				for(j=0;j<b;j++)
				{
					printf("%d ",x[i][j]);
				}
			}
			printf("\n");
		}
	}
	return 0;
}
