#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int jishu(int n);
int jishu(int n)
{
    if(n%2==1)
        return 1;
    else return 0;
}
int oushu(int n);
int oushu(int n)
{
    if(n%2==0)
        return 1;
    else return 0;
}
int chu(int n);
int chu(int n)
{
    if((n%5==0)&&(n%3!=0))
        return 1;
    else
        return 0;
}
int daxiao(int a,int b,int c);
int daxiao(int a,int b,int c)
{
    if(a>b)
    {
        if(a>c)
            return a;
        else return c;
    }
    if(a<b)
    {
      if(b>c)
            return b;
        else return c;
    }
}
int main()
{
  int n;
  scanf("%d",&n);
  int sum1=0,sum2=0,sum3=0;
  for(int i=0;i<n;i++)
  {
      if(jishu(i))
        sum1+=i;
    if(oushu(i))
        sum2+=i;
      if(chu(i))
        sum3+=i;
  }
  printf("%d %d %d",sum1,sum2,sum3);
  printf("\n");
  printf("%d",daxiao(sum1,sum2,sum3));
    return 0;
}
