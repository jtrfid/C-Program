#include<stdio.h>
#include<math.h>
typedef struct
{
	int a;
	int b;
	int c;
}M;
typedef struct
{
    int z;
	int y;
}N;

int main()
{
	int n,i,j,count=0;
	scanf("%d",&n);
	M x[n];
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d",&x[i].a,&x[i].b,&x[i].c);
	}
	N r[n];
	for(i=0;i>=0;i++)
	{
		scanf("%d%d",&r[i].z,&r[i].y);
		
		if(r[i].z==0&&r[i].y==0)
		{
			break;
		}	
		count++;
	}
	float sum[100]={-1};
	int count1=0;
	for(i=0;i<count;i++)
	{
		if(r[i].z==1&&r[i].y==n)
		{
			sum[i]=sqrt((x[1].b-x[n-1].b)*(x[1].b-x[n-1].b)+(x[1].c-x[n-1].c)*(x[1].c-x[n-1].c));
		}
		else
		{
			
			for(j=r[i].z;j<=r[i].y-1;j++)
			{
				sum[i]+=1.0*sqrt((x[j].b-x[j+1].b)*(x[j].b-x[j+1].b)+(x[j].c-x[j+1].c)*(x[j].c-x[j+1].c));
			}
			
		}
		count1++;
	}
	for(i=0;i<count1;i++)
	{
		
		
			printf("%.2f\n",sum[i]);
		
	}
	
	
	return 0 ;
}
