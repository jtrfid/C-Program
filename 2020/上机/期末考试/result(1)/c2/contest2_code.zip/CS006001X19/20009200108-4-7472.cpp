#include<stdio.h>
int main()
{
	int i,p,sum1=0,sum2=0,sum3=0;		//
	scanf("%d",&p);
	for(i=1;i<p;i++){
		if(i%2!=0)	sum1+=i;
		else	sum2+=i;
		
		if(i%5==0 && i%3!=0)	sum3+=i;
	}
	int max=0;
	if(sum1>sum2 && sum1>sum3)	max=sum1;
	else if(sum2>sum1 && sum2>sum3)	max=sum2;
	else max=sum3;
	printf("%d %d %d\n%d",sum1,sum2,sum3,max);
	return 0;
}
