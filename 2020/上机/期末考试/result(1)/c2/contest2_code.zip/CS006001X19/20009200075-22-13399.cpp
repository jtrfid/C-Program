#include <stdio.h>
#include <math.h>
typedef struct
{
	int num;
	int x;
	int y;
} Loca;
int distance (double *m,int i,int j,int n)
{
	if (i==0) return 0;
	int a=i-1,b=j-1;
	double length=0;
	int p,q;
	if(a>b)
	{
		int temp;
		temp=a;
		a=b;
		b=temp;
	}
	for (p=a;p<b;p++)
	{
		length+=m[p];
	}
	double length2=0;
	for (q=b;q<n;q++)
	length2+=m[q];
	for (q=0;q<a;q++)
	length2+=m[q];
	double min=(length<length2)?length:length2;
	
	printf("%.2f",min);
}
int main()
{
    int n,i; 
    scanf("%d",&n);
    Loca a[n];
    for (i=0;i<n;i++)
    {
    	scanf("%d %d %d",&a[i].num,&a[i].x,&a[i].y);
    }
    double b[n];
    for (i=0;i<n;i++)
    {  if (i!=n-1)
    	{
    	double c=pow(a[i].x-a[i+1].x,2)+pow(a[i].y-a[i+1].y,2);
    	b[i]=sqrt(c);
        }
        else 
        {
        	double c=pow(a[n-1].x-a[0].x,2)+pow(a[n-1].y-a[0].y,2);
        	b[n-1]=sqrt(c);
        }
	}
	int j,k;
	do
	{
		scanf("%d %d",&j,&k);
		distance(b,j,k,n);
	} while (j!=0&&k!=0);
}


