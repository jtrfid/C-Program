#include<stdio.h>
#include<math.h>
int main()
{
	int N,i,j,k=0,s=0;
	scanf("%d",&N);
	typedef struct Dir{
		int id;
		double x;
		double y;
	};
	Dir dir[N];
	for(i=0;i<N;i++)
		scanf("%d%lf%lf",&dir[i].id,&dir[i].x,&dir[i].y);
	int a[200],b[200];
	while(1)
	{
		scanf("%d %d",&a[k++],&b[s++]);
		if(a[k-1]==0&&b[k-1]==0)
		break;
	}
	for(i=0;i<k-1;i++)
	{
		int re1=0,st1=0,st2=0,re2=0;
		double l1=0,l2=0,l=0;
		for(j=0;j<N;j++)
		{
			if(a[i]==dir[j].id)
				st1=j;
			if(b[i]==dir[j].id)
				re1=j;
		}
		st2=st1;
		re2=re1;
		while(re1!=st1)
		{
			l1+=sqrt(pow((dir[st1].x-dir[st1+1].x),2)+pow((dir[st1].y-dir[st1+1].y),2));
			st1++;
		}
		while(re2!=N-1)
		{
			l2+=sqrt(pow((dir[re2].x-dir[re2+1].x),2)+pow((dir[re2].y-dir[re2+1].y),2));
			re2++;
		}
		l2+=sqrt(pow((dir[0].x-dir[N-1].x),2)+pow((dir[0].y-dir[N-1].y),2));
		while(st2!=0)
		{
			l2+=sqrt(pow((dir[st2].x-dir[st2-1].x),2)+pow((dir[st2].y-dir[st2-1].y),2));
			st2--;
		}
		l=l1<l2?l1:l2;
		printf("%.2f\n",l);
	}
	return 0;
}
