#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
typedef struct
{
	int num;
	int x;
	int y;
	int st;
	int des;
}P;

int main()
{
	int x1,x2,y1,y2;
	int count=0;
	int n;
	int i,j=0;
	scanf("%d",&n);
	P in[n],des[n],go,next;
	double d1=0,d2=0;
	P p[n]; 
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d",&p[i].num,&p[i].x,&p[i].y);
	}
	i=0;
	//in[0].st=1;
	while(1)
	{
		scanf("%d%d",&in[i].st,&in[i].des);
		if(in[i].st!=0&&in[i].des!=0)
		{
			count++;
			i++;
		}
		if(in[i].st==0&&in[i].des==0) break;
		
	
	}
	for(i=0;i<count;i++)
	{
		go.num=in[i].st;
		while(next.num!=in[i].des)
		{
			
			//go.num++;
			next.num=go.num+1;
			if(go.num>=n-1)//warning
			{
				next.num=0;
			}
			x1=p[go.num].x;
			x2=p[next.num].x;
			y1=p[go.num].y;
			y2=p[next.num].y;
			d1+=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
			go.num++;
		}
		while(next.num!=in[i].des)
		{
			
			//go.num--;
			next.num=go.num-1;
			if(go.num==0)//warning
			{
				next.num=n-1;
			}
			x1=p[go.num].x;
			x2=p[next.num].x;
			y1=p[go.num].y;
			y2=p[next.num].y;
			d2+=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
			go.num++;
		}
	}
       
       printf("%.2lf",d2);
       

	return 0;
}
