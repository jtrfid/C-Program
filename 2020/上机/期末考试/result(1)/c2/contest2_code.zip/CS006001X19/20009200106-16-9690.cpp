#include<stdio.h>
int main()
{
	int m,n,c,d;
	scanf("%d %d",&m,&n);
	int a[m][n];
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d %d",&c,&d);
	int A[c*m][d*n];
	for(int i=0;i<c*m;i++)
	{
		for(int j=0;j<d*n;j++)
		{
			if(i<m)
			{
				if(j<n)
				{
					A[i][j]=a[i][j];
				}
				else
				{
					A[i][j]=a[i][(j)%n];
				}
			}
			else
			{
				if(j<n)
				{
					A[i][j]=a[(i)%m][j];
				}
				else
				{
					A[i][j]=a[(i)%m][(j)%n];
				}
			}
		}
	}
	for(int i=0;i<c*m;i++)
	{
		for(int j=0;j<d*n;j++)
		{
			printf("%d ",A[i][j]);
			if(j==(d*n-1))
			{
				printf("\n");
			}
		}
	}
	return 0;
}
