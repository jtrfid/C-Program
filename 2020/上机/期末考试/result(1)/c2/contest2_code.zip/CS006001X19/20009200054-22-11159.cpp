#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,a,b,j;
	scanf("%d",&n);
	struct point
	{
		int num,x,y;
	};
	
	point p[n];
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d",&p[i].num,&p[i].x,&p[i].y);
	}
	
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(p[i].num>p[j].num)
			{
				int temp=p[j].num;
				p[j].num=p[i].num;
				p[i].num=temp;
			}
		}
	}
	
	float len[100];
	i=0;
	while(1)
	{
		scanf("%d%d",&a,&b);
		if(a==0 || b==0) break;
		else
		{
			float t1=0,t2=0;
			if(a==b) len[i]=0;
			else if(a<b)
			{
				for(j=a;j<b;j++)
				{
					t1+=sqrt(pow((p[j].x-p[j-1].x),2)+pow((p[j].y-p[j-1].y),2));
				}
				for(j=a-1;j>0;j--)
				{
					t2+=sqrt(pow((p[j].x-p[j-1].x),2)+pow((p[j].y-p[j-1].y),2));
				}
				for(j=n-1;j>b-1;j--)
				{
					t2+=sqrt(pow((p[j].x-p[j-1].x),2)+pow((p[j].y-p[j-1].y),2));
				}
				len[i]=t1;
				if(len[i]>t2) len[i]=t2;
			}
			else
			{
				for(j=b;j<a;j++)
				{
					t1+=sqrt(pow((p[j].x-p[j-1].x),2)+pow((p[j].y-p[j-1].y),2));
				}
				for(j=b-1;j>0;j--)
				{
					t2+=sqrt(pow((p[j].x-p[j-1].x),2)+pow((p[j].y-p[j-1].y),2));
				}
				for(j=n-1;j>a-1;j--)
				{
					t2+=sqrt(pow((p[j].x-p[j-1].x),2)+pow((p[j].y-p[j-1].y),2));
				}
				len[i]=t1;
				if(len[i]>t2) len[i]=t2;
			}
		}
		i++;
	}
	for(j=0;j<i;j++)
	{
		printf("%.2f\n",len[j]);
	}
	return 0;
}
