#include <stdio.h>
int main()
{
	int m;
	int i,s1=0,s2=0,s3=0;
	scanf("%d",&m);
	for (i=1;i<m;i++)
	{
		if (i%2!=0) s1+=i;
		if (i%2==0) s2+=i;
		if (i%5==0&&i%3!=0) s3+=i;
	}
	int max1=(s1>s2)?s1:s2;
	int max2=(s2>s3)?s2:s3;
	int max=(max1>max2)?max1:max2;
	printf("%d %d %d\n",s1,s2,s3);
	printf("%d",max);
}
