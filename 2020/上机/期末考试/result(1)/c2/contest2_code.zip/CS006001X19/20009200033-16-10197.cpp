#include <stdio.h>
int main()
{
	int a,b,m,n,i,j;
	scanf("%d %d\n",&a,&b);
	int w[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&w[i][j]);
		}
	}
	scanf("%d %d",&m,&n);
	int q[m*a][n*b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			q[i][j]=w[i][j];
		}
	}
		for(i=0;i<a*m;i++)
	{
		for(j=0;j<b*n;j++)
		{
			q[i+a][j]=q[i][j];
		}
		
	}
	for(j=0;j<b*n;j++)
	{
		for(i=0;i<a*m;i++)
		{
			q[i][j+b]=q[i][j];
		}
	}
for(i=0;i<a*m;i++)
	{
		for(j=0;j<b*n;j++)
		{
			printf("%d ",q[i][j]);
		}
		printf("\n");
	}
	return 0;
	
}
