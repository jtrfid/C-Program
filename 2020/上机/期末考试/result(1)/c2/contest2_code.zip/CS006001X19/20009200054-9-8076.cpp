#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	int max=a[0],min=a[0],j=0,k=0;
	for(i=1;i<n;i++)
	{
		if(max<a[i])
		{
			max=a[i];j=i;
		} 
		if(min>a[i])
		{
			min=a[i];k=i;
		} 
	}
	
	for(i=min;i>0;i--)
	{
		if(min%i==0 && max%i==0)
		{
			a[k]=i;break;
		}
	}
	i=max;
	while(1)
	{
		if(i%max==0 && i%min==0)
		{
			a[j]=i;break;
		}
		i++;
	}
	
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
