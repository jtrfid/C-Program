#include <stdio.h>
int main()
{
    int n,i;
    scanf("%d",&n);
    int a[n];
    for (i=0;i<n;i++)
       scanf("%d",&a[i]);
    int min=a[0],minn=0;
    int max=a[0],maxn=0;
    for (i=1;i<n;i++)
    {
    	if (a[i]<min)
    	{
    		min=a[i];
    		minn=i;
    	}
    	if (a[i]>max)
    	{
    		max=a[i];
    		maxn=i;
    	}
    }
    int j=max;
    while (1)
    {
    	
    	if (j%min==0&&j%max==0) break;
    	j++;
    }
    a[maxn]=j;
    int c=max%min;
    while (c!=0)
    {
    	max=min;
    	min=c;
    	c=max%min;
    }
    a[minn]=min;
    for (i=0;i<n;i++)
    printf("%d ",a[i]);
}
