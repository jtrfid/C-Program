#include<stdio.h>
int main()
{
	int  max=0 , min=0 , max_i=0,min_i =0, co_max=0,co_min =0, j=0 , h=0 , m=0 , n;
	scanf("%d",&n);
	int a[n],x;
		for(x=0;x<n;x++)
       {
	     scanf("%d",&a[n]);
	   }
	     max_i=0;
       	 min_i=0;
       	 max=a[0];
       	 min=a[0];      
	 for(x=0;x<n;x++)
	 {  
	     if(a[x]>max)
	     {
	    	max=a[x];
	    	max_i=x;
	     }
	      else if(a[x]<min)
	     {
	     	min=a[x];
	     	min_i=x;
	     }
	   
     }
	for(h=1;h<=min;h++)
	{
		if(min%h==0&&max%h==0)
		{
			co_max=h;
		}
	}
	int f = 1;
	for(j=max;j<=min*max;j++)
	{
		if(j%max==0&&j%min==0&&f==1)
		{
			co_min=j;
			f = 0;
		}
	}
	a[max_i]=co_min;
	a[min_i]=co_max;
	for(m=0;m<n;m++)
	{
		if(m!=n-1)
		printf("%d ",a[m]);
		if(m==n-1)
		printf("%d",a[m]);
	}
	return 0;
}
