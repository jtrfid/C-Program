#include<stdio.h>
#include<stdlib.h>
#include<string.h>



int main()
{
	int n,max=0,min=10000,t1,t2;
	scanf("%d",&n);
	int a[n];
	int i,j;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			t1=i;
		}
		
		if(a[i]<min)
		{
			min=a[i];
			t2=i;
		}
		
	}
	int max1=max;
	for(i=1;i<max*min+1;i++)
	{
		if(i%max==0&&i%min==0)
		{
			max=i;
			break;
		}
	}
	for(i=min;i>0;i--)
	{
		if(min%i==0&&max1%i==0)
		{
			min=i;
			break;
		}
	}
	a[t1]=max;
	a[t2]=min;
	
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}


	return 0;
}
