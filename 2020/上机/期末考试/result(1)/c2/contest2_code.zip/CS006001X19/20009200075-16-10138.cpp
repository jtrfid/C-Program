#include <stdio.h>
int main()
{
    int a,b,m,n;
    scanf("%d %d",&a,&b);
    int i,j;
    int x[a][b];
    for (i=0;i<a;i++)
    	for(j=0;j<b;j++)
    		scanf("%d",&x[i][j]);
    scanf("%d %d",&m,&n);
    int y[a*m][b*n];
    int p,q;
    for (i=0;i<a;i++)
    {
    	for (j=0;j<b;j++)
    	{
    		for (p=0;p<n;p++)
    		{
    			y[i][j+p*b]=x[i][j];
    		}
    	}
    	
    }
    for (j=0;j<b*n;j++)
    {
    	for (i=0;i<a;i++)
    	{
    		for (q=0;q<m;q++)
    		{
    			y[i+q*a][j]=y[i][j];
    		}
    	}
    	
    }
    for (i=0;i<a*m;i++)
       {
        for (j=0;j<b*n;j++)
        {
        printf("%d ",y[i][j]);
	    } printf("\n");
	}
}

