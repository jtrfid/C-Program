#include<stdio.h>
int main()
{
    int n;
    int a[100];
    int i;
    int j=0,maxnum,minnum;
    int max=0,min=0,g=0,y=0;
    
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
     scanf("%d",&a[i]);
    }
    
    for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		if(a[i]<a[j]) break;
    	}
    	if(j==n) 
		{max=a[i]; maxnum=i;}
    }
    
    for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		if(a[i]>a[j]) break;
    	}
    	if(j==n) 
		{min=a[i]; minnum=i;}
    }
    
	for(i=max;i<=max*min;i++)
    {
    	if(i%max==0&&i%min==0) g=i;
    }
    for(i=1;i<=min;i++)
    {
    	if(min%i==0&&max%i==0) y=i;
    }
    a[maxnum]=g;
    a[minnum]=y;
	 for(i=0;i<n;i++)
     {printf("%d ",a[i]);}
	return 0;
}
