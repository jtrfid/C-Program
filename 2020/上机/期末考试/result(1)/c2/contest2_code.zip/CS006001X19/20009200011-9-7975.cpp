#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],l,s,i;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	l=a[1];s=a[1];
	for(i=2;i<=n;i++)
	{
		if(a[i]<s)
		   s=a[i];
		if(a[i]>l)
		   l=a[i];   
	}
	int s1,l1;
	for(i=s;i<=s*l;i++)
	{
		if(i%s==0&&i%l==0)
		{
			l1=i;
			break;
		}
	}
	for(i=s;i>=1;i--)
	{
		if(s%i==0&&l%i==0)
		{
			s1=i;
			break;
		}
	}
	for(i=1;i<=n;i++)
	{
		if(a[i]==l)
		   a[i]=l1;
		if(a[i]==s)
		   a[i]=s1;
		printf("%d ",a[i]);      
	}
	return 0;
}
