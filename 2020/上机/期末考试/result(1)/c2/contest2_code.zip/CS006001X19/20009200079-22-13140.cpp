#include<stdio.h>
#include<math.h>
typedef struct
{
	int no;
	int x,y;
}point;
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	point p[n];
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&p[i].no,&p[i].x,&p[i].y);
	}
	
	double sum[n];
	for(i=0;i<n-1;i++)
	{
		sum[i]=sqrt(pow((p[i].x-p[i+1].x),2)+pow((p[i].y-p[i+1].y),2));
	}
	sum[i]=sqrt(pow((p[i].x-p[0].x),2)+pow((p[i].y-p[0].y),2));
	
	int t1,t2;
	double res1=0,res2=0;
	
	scanf("%d %d",&t1,&t2);
	while(t1!=0&&t2!=0)
	{
		for(i=t1-1;i<t2-1;i++)
		{
			res1 +=sum[i];
		}
		for(i=0;i<t1-1;i++)
		{
			res2 +=sum[i];
		}
		for(i=t2-1;i<n;i++)
		{
			res2 +=sum[i];
		}
		
		
		if((t2-t1)<(n-t2+t1))
		{
			printf("%.2f",res1);
		}
		else if((t2-t1)>(n-t2+t1))
		{
			printf("%.2f",res2);
		}
		else if((t2-t1)==(n-t2+t1))
		{
			if(res1>res2) printf("%.2f",res2);
			else printf("%.2f",res1);
		}
		
		scanf("%d %d",&t1,&t2);
	}
	
	return 0;
}
