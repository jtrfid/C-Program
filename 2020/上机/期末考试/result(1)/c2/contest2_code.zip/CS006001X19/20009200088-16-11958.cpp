# include <stdio.h>
int main ()
{
	int a,b;
	scanf("%d%d",&a,&b);
	
	int str[a][b];
	
	for(int i=0;i<a;i++)
	{
		for (int j=0;j<b;j++)
		{
			scanf("%d",&str[i][j]);
		}
	}
	
	int m,n;
	scanf("%d%d",&m,&n);

	
	for(int t1=0;t1<a;++t1)
	{
		for (int j=b;j<m*b;j++)  // fuzhi hang 
		{
			{
				int k;
				k=j%b;
				str[t1][j]=str[t1][k];
			}
		}
	}
	
	for (int j1=0;j1<m*b;j1++)
	{
		for (int j2=a;j2<n*a;j2++)
		{
			int k2;
			k2=j2%a;
			str[j2][j1]=str[j2][k2];
		}
	}
	
	for (int s1=0;s1<n*a;s1++)
	{
		for (int s2=0;s2<m*b;s2++)
		{
			printf("%d ",str[s1][s2]);
		}
	}
	
	
	return 0;
}
