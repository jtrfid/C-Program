#include<stdio.h>
int gcd(int max,int min)
{
	int i;
	for(i=min;i>0;i--)
	{
		if(max%i==0&&min%i==0)
		break;
	}return i;
}
int gcb(int max,int min)
{
	int j;
	for(j=max;;j++)
	{
		if(j%max==0&&j%min==0)
		break;
	}return j;
}
int main()
{
	int i,j,k,m,n,t,max1,min1,max2,min2;
	scanf("%d",&n);
	int a[n],b[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	b[i]=a[i];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(a[j+1]>a[j])
			{
				t=a[j+1];a[j+1]=a[j];a[j]=t;
			}
		}
	}
	max1=a[0];min1=a[n-1];
	max2=gcb(max1,min1);
	min2=gcd(max1,min1);
	for(i=0;i<n;i++)
	{
		if(b[i]==a[0])
		b[i]=max2;
		if(b[i]==a[n-1])
		b[i]=min2;
	}
	for(i=0;i<n;i++)
	printf("%d ",b[i]);
	return 0;
}
