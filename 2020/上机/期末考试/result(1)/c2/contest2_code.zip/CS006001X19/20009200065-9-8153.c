#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	
	int a[20];
	int i,max,min,j=0,k=0;
	
	scanf("%d",&a[0]);
	max=a[0];
	min=a[0];
	
	for(i=1;i<n;i++)
	{
	    scanf("%d",&a[i]);
	    if(a[i]>max)
	    {
	    	max=a[i];
	    	j=i;
	    }
	    if(a[i]<min)
	    {
	    	min=a[i];
	    	k=i;
	    }
    }
    
    int b,y;
    
    for(i=1;i<=min;i++)
    {
    	if(min%i==0&&max%i==0)
    	y=i;
    }
    a[k]=y;
    b=max*min/y;
    a[j]=b;
    
    for(i=0;i<n;i++)
    printf("%d ",a[i]);
    
    return 0;
    
	
}
