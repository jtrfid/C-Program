#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
	int i,j,a[100][100],b[100][100],c,d,D,X,t=0;
	int m,n,m1,n1;
	scanf("%d %d",&m,&n);
	for(i=0,j=0,t=0;t<m*n;t++)
	{
		scanf("%d",&a[i][j]);
		j++;
		if(j==n)
		j=0,i++;
	}
	scanf("%d %d",&m1,&n1);
	for(i=0,j=0,t=0;t<m*n;t++)
	{
		for(c=0;c<n1;c++)
		{
			b[i][j+c*(n)]=a[i][j];
		}
		j++;
		if(j==n)
		j=0,i++;
	}
	for(i=0,j=0,t=0;t<m*n*n1;t++)
	{
		for(c=0;c<m1;c++)
		{
			b[i+c*(m)][j]=b[i][j];
		}	
		j++;
		if(j==n*n1)
	
		j=0,i++;
	}
	for(i=0,j=0,t=0;t<m*n*m1*n1;t++)
	{
		printf("%d ",b[i][j]);
		j++;
		if(j==n*n1)
		j=0,i++,printf("\n");
	}

}
