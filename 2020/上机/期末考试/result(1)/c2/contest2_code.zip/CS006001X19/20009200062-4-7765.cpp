#include<stdio.h>
int main()
{
	int m,i;
	int oushu=0,jishu=0,k=0;
	int max=0;
	scanf("%d",&m);
	for(i=1;i<m;i++)
	{
		if(i%2==0) oushu=oushu+i;
		if(i%2!=0) jishu=jishu+i;
		if(i%5==0&&i%3!=0) k=k+i;
	}
	if(jishu>oushu&&jishu>k) max=jishu;
	if(oushu>jishu&&oushu>k) max=oushu;
	if(k>jishu&&k>oushu) max=k;
	printf("%d %d %d\n",jishu,oushu,k);
	printf("%d",max);
	
	return 0;
}
