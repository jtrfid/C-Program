# include <stdio.h>

int main ()
{
	int n,bei,gcd;
	scanf("%d",&n);
	int a[n]={0};
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	int max=a[0],min=a[0];
	int pos_max=0,pos_min=0;
	
    
    a[pos_max]=bei;
    a[pos_min]=gcd;
    
    for (int t=0;t<n;t++)
    {
    	printf("%d ",a[t]);
    }
    
	return 0;
}
