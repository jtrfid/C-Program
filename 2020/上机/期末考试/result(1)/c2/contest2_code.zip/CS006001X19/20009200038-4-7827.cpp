#include<stdio.h>
int main(){
	int i,m,a,b,c,max;
	a=0;
	b=0;
	c=0;
	scanf("%d",&m);
	for(i=1;i<m;i=i+2){
		a=a+i;
	};
	for(i=2;i<m;i=i+2){
		b=b+i;
	};
	for(i=1;i<m;i++){
		if(i%5==0&&i%3!=0){
			c=c+i;
		}
	};
	printf("%d %d %d\n",a,b,c);
	if(a>b){
		max=a;
	}else{
		max=b;
	};
	printf("%d",max);
	
	
	return 0;
}
