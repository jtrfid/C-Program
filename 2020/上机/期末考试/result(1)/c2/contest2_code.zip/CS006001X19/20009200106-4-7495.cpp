#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a=0,b=0,c=0;
	for(int i=0;i<n;i+=2)
	{
		a=a+i;
	}
	for(int i=1;i<n;i+=2)
	{
		b=b+i;
	}
	for(int i=5;i<n;i++)
	{
		if(i%5==0&&i%3!=0)
		{
			c=c+i;
		}
	}
	int max=0;
	if(a>b)
	{
		max=a;
		if(c>max)
		{
			max=c;
		}
	}
	else
	{
		max=b;
		if(c>max)
		{
			max=c;
		}
	}
	printf("%d %d %d\n",b,a,c);
	printf("%d",max);
	return 0;
}
