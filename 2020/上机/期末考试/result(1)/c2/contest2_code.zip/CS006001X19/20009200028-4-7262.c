#include<stdio.h>
int main()
{
	int m,sum1=0,sum2=0,sum5=0,max=0,i,j;
	scanf("%d",&m);
	for(i=1;i<m;i++)
	{
		if(i%2==0)
		{
			sum1+=i;
		}
		if(i%2!=0)
		{
			sum2+=i;
		}
		if(i%5==0&&i%3!=0)
		{
			sum5+=i;
		}
	}
	printf("%d %d %d\n",sum2,sum1,sum5);
	if(sum1>=sum2&&sum1>=sum5)
	printf("%d",sum1);
	if(sum2>=sum1&&sum2>=sum5)
	printf("%d",&sum2);
	if(sum5>=sum1&&sum5>=sum2)
	printf("%d",&sum5);
	return 0;
} 
