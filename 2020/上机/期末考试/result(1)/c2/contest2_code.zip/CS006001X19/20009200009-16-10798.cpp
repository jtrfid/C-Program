#include<stdio.h>
int main()
{	int a,b,i,j;
	scanf("%d%d",&a,&b);
	int s[a][b];
	for(i=0;i<a;i++)
	{	for(j=0;j<b;j++)
		{	scanf("%d",&s[i][j]);
		}
	}
	int m,n;
	scanf("%d%d",&m,&n);
	n=n*b;
	m=m*a;
	int d[m][n];
	for(i=0;i<m;i++)
	{	for(j=0;j<n;j++)
		{	if(j/b<=0&&i/a<=0)
			{	d[i][j]=s[i][j];
			}
			if(j/b>0)
			{	d[i][j]=d[i][j-(j/b)*b];
			}
			if(i/a>0)
			{	d[i][j]=d[i-(i/a)*a][j];
			}
		}
	}
	for(i=0;i<m;i++)
	{	for(j=0;j<n;j++)
		{	printf("%d ",d[i][j]);
			if(j==n-1)
			{	printf("\n");
			}
		}
	}
	return 0;
}
