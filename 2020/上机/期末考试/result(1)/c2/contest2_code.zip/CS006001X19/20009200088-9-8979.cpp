# include <stdio.h>
int main ()
{
	int n;
	scanf("%d",&n);
	printf("%d",n);
	int a[n]={0};
	for (int i=0;i<n;i++)
		printf("%d ",a[i]);
	
	return 0;
	
}
