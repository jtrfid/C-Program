#include <stdio.h>
int main()
{
	int a,b,m,n,i,j;
	scanf("%d %d\n",&a,&b);
	int w[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&w[i][j]);
		}
	}
	scanf("%d %d",&m,&n);
	int t=a*m;
	int k=b*n;
	
	int q[t][k];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			q[i][j]=w[i][j];
		}
	}
	for(i=0;i<t-a;i++)
	{
		for(j=0;j<k;j++)
		{
			q[i+a][j]=q[i][j];
		}
		
	}
	for(j=0;j<t-b;j++)
	{
		for(i=0;i<t;i++)
		{
			q[i][j+b]=q[i][j];
		}
	}
		
     for(i=0;i<t;i++)
	{
		for(j=0;j<k;j++)
		{
			printf("%d ",q[i][j]);
		}
		printf("\n");
	}
	return 0;
	
}
