#include<stdio.h>
int main(){
	int a,b,m,n;
	int arr[20][20]={0};
	scanf("%d %d",&a,&b);
	for(int i=1;i<=a;i++){
		for(int j=1;j<=b;j++)
		   scanf("%d",&arr[i][j]);
	}
	scanf("%d %d",&m,&n);
	int x=1;
	for(int i=1;i<=m*a;i++){
		for(int j=1;j<=n;j++){
			for(int k=1;k<=b;k++)
			   printf("%d ",arr[x][k]);
		}
		printf("\n");
		x++;
		if(x>a) x=1;
	}
	return 0;
}
