#include<stdio.h>
int min(int ,int );
int max(int ,int );
int main()
{
	int n=0,i=0,p1=0,p2=0,k=0;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	int temp_min=a[0],temp_max=a[0];
	for(i=0;i<n;i++)
	{
		if(temp_min>=a[i])
		{
			temp_min=a[i];
			p1=i;
		}
		if(temp_max<=a[i])
		{
			temp_max=a[i];
			p2=i;
		}
	} 
	a[p2]=min(a[p1],a[p2]);
	a[p1]=max(a[p1],a[p2]); 
//	printf("%d %d\n",a[p1],a[p2]);
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
int min(int a,int b)
{
	int i,p;
	if(a>=b)	i=a;
	else i=b;
	for(p=i;p<=a*b;p++){
		if (p%a==0 && p%b==0)
		{
			return p;
			break;
		}
	}
}
int max(int a,int b)
{
/*	if(a>b && a%b==0)	return b;
	else if(a<b && b%a==0)	return a;
	else if(a==b)	return a;
	else{
		int i=0,p=0,x=0;
		if(a>=b)	p=b;
		else p=a;
		for(i=p-1;i>=0;i--){
			if(a%i==0 && b%i==0)
			{
				x=i;
				break;
			}
	}
	return x;
	}*/
	int i,result;
	for(i=1;i<=a;i++){
		if(a%i==0 && b%i==0)	result=i;
	}
	return result;
}
