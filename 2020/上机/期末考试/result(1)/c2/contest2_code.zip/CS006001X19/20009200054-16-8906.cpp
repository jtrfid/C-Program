#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int i,j,s[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&s[i][j]);
		}
	}
	int m,n;
	scanf("%d%d",&m,&n);
	
	int p[a*m][b*n],k,t;
	for(i=0;i<a*m;i++)
	{
		for(j=0;j<b*n;j++)
		{
			k=i;t=j;
			while(k>=a) k-=a;
			while(t>=b) t-=b;
			p[i][j]=s[k][t];
		}
	}
	for(i=0;i<a*m;i++)
	{
		for(j=0;j<b*n;j++)
		{
			printf("%d ",p[i][j]);
		}
		printf("\n");
	}
	return 0;
}
