#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int ori[a][b];
	int i,j,k;
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&ori[i][j]);
		}
	}
	int m,n;
	scanf("%d %d",&m,&n);
	int tar[m*a][n*b];
	
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			for(k=0;k<m;k++)
			{
				tar[i+a*k][j]=ori[i][j];
			}
		}
	}
	
	for(i=0;i<a*m;i++)
	{
		for(j=0;j<b;j++)
		{
			for(k=1;k<n;k++)
			{
				tar[i][j+b*k]=tar[i][j];
			}
		}
	}
	
	for(i=0;i<m*a;i++)
	{
		for(j=0;j<n*b;j++)
		{
			printf("%d ",tar[i][j]);
		}
		printf("\n");
	}
}
