#include<stdio.h>
int tar(int n)
{
	if(n%5==0&&n%3!=0) return 1;
	else return 0;
}
int main()
{
	int m;
	scanf("%d",&m);
	int i=0;
	int sum_j=0,sum_o=0,sum=0;
	int sumz[3];
	
	for(i=0;i<m;i++)
	{
		if(i%2==0) sum_o +=i;
		if(i%2!=0) sum_j +=i;
		if(tar(i)) sum +=i;
	}
	
	int temp=sum_j;
	if(sum_o>sum_j)temp=sum_o;
	if(sum>temp)temp=sum;
	
	printf("%d %d %d\n",sum_j,sum_o,sum);
	printf("%d",temp);
	
	return 0;
}
