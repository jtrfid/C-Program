#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	int sumj=0,sumo=0,sum=0,max;
	int i;
	for(i=1;i<m;i++)
	{
		if(i%2==1)
		{
			sumj+=i;
		}
		else
		{
			sumo+=i;
		}
		if(i%5==0&&i%3!=0)
		{
			sum+=i;
		}
	}
	printf("%d ",sumj);
	printf("%d ",sumo);
	printf("%d\n",sum);
	
	max=sumj;
	if(sumo>max)
	{
		max=sumo;
	}
	if(sum>max)
	{
		max=sum;
	}
	printf("%d\n",max);
	
	return 0;
}
