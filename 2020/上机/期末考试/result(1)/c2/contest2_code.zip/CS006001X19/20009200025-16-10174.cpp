#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main()
{
   int a,b;
   int t[10][10];
   scanf("%d %d",&a,&b);
   for(int i=0;i<a;i++)
   {
       for(int j=0;j<b;j++)
       {
           scanf("%d",&t[i][j]);
       }
   }
   int m,n;
   scanf("%d %d",&m,&n);
   for(int p=1;p<=m;p++)
   {
       for(int i=0;i<a;i++)
   {
       for(int k=1;k<=n;k++)
       {
        for(int j=0;j<b;j++)
       {
           printf("%d ",t[i][j]);
       }
       }
       printf("\n");
   }
   }
        return 0;
}
