#include <stdio.h>
int main()
{
	int m,i,j;
	int x=0,y=0,z=0;
	scanf("%d",&m);
	for(i=0;i<m;i=i+2)
	{
		x+=i;
	}
	for(i=1;i<m;i=i+2)
	{
		y+=i;
	}
	for(i=0;i<m;i++)
	{
		if(i%5==0&&i%3!=0)
		z+=i;
	}
	printf("%d %d %d\n",y,x,z);
	j=x;
	if(y>j)
	{
		j=y;
	}
	if(z>j)
	{
		j=z;
	}
	printf("%d",j);
	return 0;
	
	
}
