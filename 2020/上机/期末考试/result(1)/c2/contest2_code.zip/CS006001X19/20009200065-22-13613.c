#include<stdio.h>
#include<math.h>
int main()
{
	int n;
	scanf("%d",&n);
	
	int c[10000],x[10000],y[10000],z[10000];
	int i;
	for(i=0;i<n;i++)
	scanf("%d %d %d",&c[i],&x[i],&y[i]);
	
	for(i=0;i<n-1;i++)
	{
	    z[i]=(x[i+1]-x[i])*(x[i+1]-x[i])+(y[i+1]-y[i])*(y[i+1]-y[i]);
	}
	z[n-1]=(x[0]-x[n-1])*(x[0]-x[n-1])+(y[0]-y[n-1])*(y[0]-y[n-1]);
	int p[10000],q[10000];
	i=0;
	do{
		scanf("%d %d",&p[i],&q[i]);
		
		i++;
	}while(p[i-1]!=0||q[i-1]!=0);
	i=0;
	int a,b;
	do{
		a=p[i],b=q[i];
		float j=0,k=0,sum=0;
		for(i=0;i<n;i++)
		sum+=sqrt(z[i]);
		for(i=a-1;i<b-1;i++)
		j+=sqrt(z[i]);
		k=sum-j;
		if(k<j)
		printf("%.2f\n",k);
		else
		printf("%.2f\n",j);
		
		i++;	
	}while(a!=0||b!=0);
	
    return 0;
}
