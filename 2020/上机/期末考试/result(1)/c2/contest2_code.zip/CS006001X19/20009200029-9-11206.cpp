#include<stdio.h>
int main()
{
	int n , max , min , max_i,min_i , co_max,co_min;
	scanf("%d",&n);
	int a[n] , i;
		for(i=0;i<n;i++)
       {
	     scanf("%d",&a[i]);
	     if(a[i]=='\n')break;
	   }
	     max_i=0;
       	 min_i=0;
       	 max=a[0];
       	 min=a[0];
       
	 for(i=0;i<n;i++)
	 {  
	     if(a[i]>max)
	     {
	    	max=a[i];
	    	max_i=i;
	     }
	      else if(a[i]<min)
	     {
	     	min=a[i];
	     	min_i=i;
	     }
	   
     }
	for(i=2;i<=min;i++)
	{
		if(min%i==0&&max%i==0)
		{
			co_max=i;
		}
	}
	for(i=max;i<=min*max;i++)
	{
		if(i%max==0&&i%min==0)
		{
			co_min=i;
			break;
		}
	}
	a[max_i]=co_min;
	a[min_i]=co_max;
	for(i=0;i<n;i++)
	{
		scanf("%d",a[i]);
	}
	return 0;
}
