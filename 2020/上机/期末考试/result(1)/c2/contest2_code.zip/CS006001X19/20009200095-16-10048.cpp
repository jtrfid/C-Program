#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int x[a][b];
	int i,j,h,k,t;
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&x[i][j]);
		}
	}
	int m,n;
	scanf("%d%d",&m,&n);
	int y[m*a][n*b];
	for(h=0;h<m;h++)
	{
		for(i=0;i<m*a;i=i+a)
	{
		for(j=0;j<n*b;j++)
		{
			k=j%b;
			y[i][j]=x[h][k];
		}
	}
	for(i=1;i<m*a;i=i+a)
	{
		for(j=0;j<n*b;j++)
		{
			t=j%b;
			y[i][j]=x[h+1][t];
			
		}
	}
	}
	
	for(i=0;i<m*a;i++)
	{
		for(j=0;j<n*b;j++)
		{
			printf("%d ",y[i][j]);
		}
		printf("\n");
	}
	return 0 ;
}
