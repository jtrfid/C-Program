#include<stdio.h>
int main()
{
	int n,i,max,min,x=1,y=1,max_=0,min_=0;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	max=a[0];
	min=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			max_=i;
		}
		if(a[i]<min)
		{
			min=a[i];
			min_=i;
		}	
	}
	for(i=1;i<=min;i++)
		if(max%i==0&&min%i==0)
			x=i;
	for(i=max;;i++)
	{
		if(i%max==0&&i%min==0)
		{
			y=i;
			break;
		}
	}
	a[max_]=y;
	a[min_]=x;
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
	return 0;
}
