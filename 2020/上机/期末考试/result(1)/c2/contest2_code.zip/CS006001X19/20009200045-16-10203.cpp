#include<stdio.h>
#include<stdlib.h>
#include<string.h>



int main()
{
	int a,b,c1,c2;
	int i,j,k;
	scanf("%d%d",&a,&b);
	int arr1[a][b];
	for(i=0;i<a;i++)
		for(j=0;j<b;j++)
		{
				scanf("%d",&arr1[i][j]);
		}
		
	int m,n;
	scanf("%d %d",&m,&n);
	
	int arr2[100][100];
	i=0;
	j=0;
	for(c1=0;c1<a*m;c1++)
	{
		for(c2=0;c2<b*n;c2++)
		{
			arr2[c1][c2]=arr1[i][j];
			j++;
			if(j==b)
			j=0;
		}
		i++;
		if(i==a)
		i=0;
		
	}
	for(i=0;i<a*m;i++)
	{
			for(j=0;j<b*n;j++)
			{
				printf("%d ",arr2[i][j]);
			}
	  printf("\n");
	}
	

	return 0;
}
