#include<stdio.h>
int main()
{
	int n , max , min , max_i,min_i , co_max,co_min , j , h , m;
	scanf("%d",&n);
	int a[n] , i;
		for(i=0;i<n;i++)
       {
	     scanf("%d",&a[i]);
	   }
	     max_i=0;
       	 min_i=0;
       	 max=a[0];
       	 min=a[0];
       
	 for(i=0;i<n;i++)
	 {  
	     if(a[i]>max)
	     {
	    	max=a[i];
	    	max_i=i;
	     }
	      else if(a[i]<min)
	     {
	     	min=a[i];
	     	min_i=i;
	     }
	   
     }
	for(h=1;h<=min;h++)
	{
		if(min%h==0&&max%h==0)
		{
			co_max=h;
		}
	}
	for(j=max;j<=min*max;j++)
	{
		if(j%max==0&&j%min==0)
		{
			co_min=j;
			break;
		}
	}
	a[max_i]=co_min;
	a[min_i]=co_max;
	for(m=0;m<n;m++)
	{
		scanf("%d",a[m]);
	}
	return 0;
}
