#include<stdio.h>
int main()
{
	int m,sum1=0,sum2=0,sum3=0;
	scanf("%d",&m);
	int i;
	for(i=0;i<m;i++)
	{
		if(i%2)
		{
			sum1+=i;
		}
		else
		{
			sum2+=i;
		}
		if(i%5==0&&i%3!=0)
		{
			sum3+=i;
		}
	}
	printf("%d %d %d\n",sum1,sum2,sum3);
	if(sum2>sum1)
	{
		sum1=sum2;
	}
	if(sum3>sum1)
	{
		sum1=sum3;
	}
	printf("%d",sum1);
	return 0;
}
