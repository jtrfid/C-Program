# include <stdio.h>
int main ()
{
	int a,b;
	scanf("%d%d",&a,&b);
	
	int str[a][b];
	
	for(int i=0;i<a;i++)
	{
		for (int j=0;j<b;j++)
		{
			scanf("%d",&str[i][j]);
		}
	}
    int m,n;
	scanf("%d%d",&m,&n);
   int str1[6][6]={1,2,3,4,5,6,1,2,3,4,5,6,1,2,3,4,5,6,1,2,3,4,5,6,1,2,3,4,5,6};
	for (int s1=0;s1<6;s1++)
	{
		for (int s2=0;s2<6;s2++)
		{
			printf("%d ",str1[s1][s2]);
		}
	}
