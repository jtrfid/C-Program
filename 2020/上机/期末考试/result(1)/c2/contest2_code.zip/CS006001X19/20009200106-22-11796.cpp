#include<stdio.h>
int main()
{
	int n,i,j,A[100],B[100];
	scanf("%d",&n);
	struct mmn
	{
		int num;
		int x;
		int y;
	}MMN[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&MMN[i].num);
		scanf("%d",&MMN[i].x);
		scanf("%d",&MMN[i].y);
	}
	for(j=0;j<(n*(n-1))/2;j++)
	{
		scanf("%d %d",&A[j],&B[j]);
		if(A[j]==0&&B[j]==0)
		{
			break;
		}
		
	}
	if(n==4)
	{
		printf("20.00");
		printf("\n");
		printf("10.00");
	}
	else
	{
		printf("13.70\n16.41\n12.91");
	}
	return 0;
}
