#include<stdio.h>
int main(){
	int a,b,i,j,hk,sk,c,d,e,f;
	int aa[10][10];
	scanf("%d %d",&a,&b);
	for(i=0;i<a;i++){
		for(j=0;j<b;j++){
			scanf("%d",&aa[i][j]);
		}
	};
	scanf("%d %d",&sk,&hk);
	for(c=0;c<sk;c++){
		for(f=0;f<a;f++){
			for(d=0;d<hk;d++){
			  for(e=0;e<b;e++){
				printf("%d ",aa[f][e]);
			  }
			
			
			
			
			
			
		    }  printf("\n");
		}
		
		
		
		
		
		
		
		
	};
	
	
	
	
	return 0;
}
