#include <stdio.h>
int main()
{
	int i,n,a[20],max=0,min=0,M,m;
	scanf("%d",&n);
	for(i=0;i<=n-1;i++)
	scanf("%d",&a[i]);
	M=a[0];
	m=a[0];
	for(i=0;i<=n-1;i++)
	{
		if(a[i]>M)
		{
			M=a[i];
			max=i;
		}
		if(a[i]<m)
		{
			m=a[i];
			min=i;
		}
	}
	i=m;
	while(m%i!=0||M%i!=0)
	{
		i--;
	}
	a[min]=i;
	i=M;
	while(i%M!=0||i%m!=0)
	{
		i++;
	}
	a[max]=i;
	for(i=0;i<=n-1;i++)
	printf("%d ",a[i]);
	return 0;
}
