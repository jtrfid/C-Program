#include<stdio.h>
#include<math.h>
int main(){
	int id[10005]={0},x[10005]={0},y[10005]={0};
	int n;
	double d[10005]={0},delta_x,delta_y;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d %d %d",&id[i],&x[i],&y[i]);
	for(int i=2;i<=n;i++){
		delta_x=x[i]-x[i-1];
		delta_x*=delta_x;
		delta_y=y[i]-y[i-1];
		delta_y*=delta_y;
		
		d[i]=d[i-1]+sqrt(delta_x+delta_y);
	}
	int num1,num2;
	while(1){
		scanf("%d %d",&num1,&num2);
		if(num1==0&&num2==0) break;
		printf("%.2lf\n",d[num2]-d[num1]);
	}
	return 0;
}
