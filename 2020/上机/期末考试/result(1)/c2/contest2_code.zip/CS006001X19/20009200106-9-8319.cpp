#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int min=a[0],min1,max=a[0],max1;
	for(int i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			max1=i;
		}
	}
	for(int i=0;i<n;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			min1=i;
		}
	}
	int b,c;
	for(int i=min;i>0;i--)
	{
		if(min%i==0&&max%i==0)
		{
			b=i;
			break;	
		}
	}
	for(int i=max;i<=min*max;i++)
	{
		if(i%min==0&&i%max==0)
		{
			c=i;
			break;	
		}
	}
	a[min1]=b;
	a[max1]=c;
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
