#include<stdio.h>
int main()
{	int n,a=0,b=0,c=0,i;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{	if(i%2==0)
		{	a +=i;
		}
		if(i%2!=0)
		{	b +=i;
		}
		if(i%5==0&&i%3!=0)
		{	c +=i;
		}
	}
	printf("%d %d %d\n",b,a,c);
	int max;
	if(a>b)
	{	max=a;
	}
	else
	{	max=b;
	}
	if(c>max)
	{	max=c;
	}
	printf("%d",max);
	return 0;
}
