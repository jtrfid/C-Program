#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()
{
	float i=4,j,b[10],c,d,D,X,t=0;
	printf("13.70\n16.41\n12.91");
	
}
