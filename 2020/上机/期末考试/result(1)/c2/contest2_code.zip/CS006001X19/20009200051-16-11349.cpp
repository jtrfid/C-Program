#include <stdio.h>
int main()
{
	int a,b,m,n,c[50][50],i,j,k=0,l=0;
	scanf("%d %d",&a,&b);
	for(i=0;i<=a-1;i++)
		for(j=0;j<=b-1;j++)
		{
			scanf("%d",&c[i][j]);
		}
	scanf("%d %d",&m,&n);
	if(m>1&&n>1){
	while(l<=n)
	{	
		k=0;
		while(k<=m)
		{
			for(i=0;i<=a;i++)
			for(j=0;j<=b;j++)
			{
				c[i+l*a][j+k*b]=c[i][j];
			}
			k++;
		}	
		l++;
	}
	}
	else if(m>1)
	{
		for(i=0;i<=a;i++)
			for(j=0;j<=b;j++)
			{
				l++;
				c[i+l*a][j]=c[i][j];
				if(l==n)break;
			}
	}
		else if(n>1)
	{
		for(i=0;i<=a;i++)
			for(j=0;j<=b;j++)
			{
				k++;
				c[i][j+k*b]=c[i][j];
				if(k==m)break;
			}
	}
	for(i=0;i<=m*a-1;i++)
		for(j=0;j<=n*b-1;j++)
		{
			printf("%d ",c[i][j]);
			if(j==n*b-1)printf("\n");
		}
	return 0;
}
