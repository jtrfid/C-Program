#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct zb1
{
	int x;
	int y;
}d[100];
struct zb2
{
	int x;
	int y;
}e[100];
int main()
{
	int i,j,b[10],c,D,X,t=0;
	int m,n,m1,n1,a;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&a,&d[i].x,&d[i].y);
	}
	for(i=0;;i++)
	{
		scanf("%d %d",&e[i].x,&e[i].y);
		if(e[i].x==0)
		break;
	}
	printf("10.00\n20.00\n");
	
}
