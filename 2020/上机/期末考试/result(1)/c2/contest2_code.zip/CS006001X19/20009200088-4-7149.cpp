# include <stdio.h>
int main ()
{
	int m;
	scanf("%d",&m);
	int sum_odd=0,sum_even=0,sum=0;
	
	for (int i=1;i<m;i++)
	{
		if(i%2==0)
			sum_even+=i;
		else
			sum_odd+=i;
		
		if(i%5==0&&i%3!=0)
			sum+=i;
	}
	int max=sum_even;
	
	if (max<sum_odd)
		max=sum_odd;
	
	if (max<sum)
		max=sum;
	
	
	printf("%d %d %d\n",sum_odd,sum_even,sum);
	printf("%d",max);
	
	
	return 0;
}
