#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int min=a[0],max=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		   max=a[i];
		if(a[i]<min)
		   min=a[i];   
	}
	int ax,in;
	for(i=min;i>=1;i--)
	{
		if(max%i==0&&min%i==0)
		   ax=i;
	}
	for(i=max;i<=max*min;i++)
	{
		if(i%max==0&&i%min==0)
		   in=i;
	}
	for(i=0;i<n;i++)
	{
		if(a[i]==max)
		   a[i]=in;
		if(a[i]==min)
		   a[i]=ax;
		printf("%d ",a[i]);      
	}
	return 0;
}
