#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int ori[a+1][b+1];
	int i,j;
	for(i=1;i<=a;i++)
	{
		for(j=1;j<=b;j++)
		{
			scanf("%d",&ori[i][j]);
		}
	}
	int m,n,k;
	scanf("%d%d",&m,&n);
	int ans[a+1][n*b+1];
	for(i=1;i<=a;i++)
	{
		for(k=0;k<n;k++)
		{
			for(j=1;j<=b;j++)
			{
				ans[i][k*b+j]=ori[i][j];
			}
		}
	}
	for(k=1;k<=m;k++)
	{
		for(i=1;i<=a;i++)
		{
			for(j=1;j<=n*b;j++)
			{
				printf("%d ",ans[i][j]);
			}
			printf("\n");
		}
	}
	return 0;
}
