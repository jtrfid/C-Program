#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int n,a[25],i,b[25];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	int j,k,t;
	for(i=0;i<n-1;i++)
	{
		for(j=i+1,k=i;j<n;j++)
		{
			if(a[j]<a[k])
				k=j;
		}
		if(k!=i)
		{
			t=a[i];a[i]=a[k];a[k]=t;
		}	
	}
	int max,min,c,d;
	max=a[n-1];min=a[0];
	for(i=1;i<=min;i++)
	{
		if(min%i==0&&max%i==0)
		{
			c=i;
			break;
		}
	}
	for(i=max;i<=min*max;i++)
	{
		if(i%max==0&&i%min==0)
		{
			d=i;
			break;
		}
	}
	for(i=0;i<n;i++)
	{
		if(b[i]==max)
		{
			b[i]=d;
		}
		if(b[i]==min)
		{
			b[i]=c;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",b[i]);
	}
	return 0;
}
