#include<stdio.h>
#include<math.h>
int main()
{
	int N,a[200],b[200],i,j;
	scanf("%d",&N);
	typedef struct Dir{
		int number;
		double x;
		double y;
	};
	Dir dir[N];
	for(i=0;i<N;i++)
		scanf("%d %lf %lf\n",&dir[i].number,&dir[i].x,&dir[i].y);
	int k=0,s=0;
	while(1)
	{
		scanf("%d%d",&a[k++],&b[s++]);
		if(a[k-1]==0&&b[s-1]==0)
			break;
	}	
	for(j=0;j<k-1;j++)
	{
		double m1,n1,m2,n2,l;
		for(i=0;i<N;i++)
		{
			if(a[j]==dir[i].number)
			{
				m1=dir[i].x;
				n1=dir[i].y;
			}
			if(b[j]==dir[i].number)
			{
				m2=dir[i].x;
				n2=dir[i].y;
			}
		}
		l=sqrt(pow((m1-m2),2)+pow((n1-n2),2));
		printf("%.2f\n",l);
	}	
	return 0;
}
