#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],max,min,b,y;
	int i,j=0,k=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	max=a[0];
	min=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			j=i;
		}
		if(a[i]<min)
		{
			min=a[i];
			k=i;
		}
	}
	
	for(i=max;;i++)
	{
		if(i%max==0&&i%min==0)
		{
			b=i;
			break;
		}
	}
	for(i=min;i>0;i--)
	{
		if(max%i==0&&min%i==0)
		{
			y=i;
			break;
		}
	}
	a[j]=b;
	a[k]=y;
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	
	return 0;
}
