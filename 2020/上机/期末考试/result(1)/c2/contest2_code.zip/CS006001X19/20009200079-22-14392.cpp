#include<stdio.h>
#include<math.h>
typedef struct
{
	int no;
	int x,y;
}point;
typedef struct
{
	int t1,t2;
}test;
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	point p[n];
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&p[i].no,&p[i].x,&p[i].y);
	}
	
	double sum[n];
	for(i=0;i<n-1;i++)
	{
		sum[i]=sqrt(pow((p[i].x-p[i+1].x),2)+pow((p[i].y-p[i+1].y),2));
	}
	sum[i]=sqrt(pow((p[i].x-p[0].x),2)+pow((p[i].y-p[0].y),2));
	
	test t[20];
	double res1=0,res2=0;
	i=0;
	scanf("%d %d",&t[0].t1,&t[0].t2);
	while(t[i].t1!=0&&t[i].t2!=0)
	{
	    i++;
		scanf("%d %d",&t[i].t1,&t[i].t2);
		
	}
	i=0;
	while(t[i].t1!=0&&t[i].t2!=0)
	{
		for(i=t[i].t1-1;i<t[i].t2-1;i++)
		{
			res1 +=sum[i];
		}
		for(i=0;i<t[i].t1-1;i++)
		{
			res2 +=sum[i];
		}
		for(i=t[i].t2-1;i<n;i++)
		{
			res2 +=sum[i];
		}
		
		
		if((t[i].t2-t[i].t1)<(n-t[i].t2+t[i].t1))
		{
			printf("%.2f\n",res1);
		}
		else if((t[i].t2-t[i].t1)>(n-t[i].t2+t[i].t1))
		{
			printf("%.2f\n",res2);
		}
		else if((t[i].t2-t[i].t1)==(n-t[i].t2+t[i].t1))
		{
			if(res1>res2) printf("%.2f\n",res2);
			else printf("%.2f\n",res1);
		}
		
		i++;res1=0;res2=0;
	}
	
	return 0;
}
