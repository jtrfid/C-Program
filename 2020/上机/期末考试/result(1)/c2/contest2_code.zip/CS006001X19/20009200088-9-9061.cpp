# include <stdio.h>
int main ()
{
	int n;
	scanf("%d",&n);
	printf("%d",n);
	int a[n]={0};
	for (int i=0;i<n;i++)
		scanf("%d",&a[i]);
		
	for (int t=0;t<n;t++)
		printf("%d ",a[t]);
	
	return 0;
	
}
