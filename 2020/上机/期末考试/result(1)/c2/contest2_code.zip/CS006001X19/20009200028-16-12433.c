#include<stdio.h>
int main()
{
	int i,j,k,m,n,t,a,b;
	scanf("%d %d",&a,&b);
	int A[a][b],B[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		scanf("%d",&A[i][j]);
	}
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		B[i][j]=A[i][j];
	}
	scanf("%d %d",&m,&n);
	for(t=1;t<=m;t++)
	{
		for(i=0+(t-1)*a;i<a+(t-1)*a;i++)
		{
			for(k=1;k<=n;k++)
			{
				for(j=(k-1)*b;j<b+b*(k-1);j++)
				{
					printf("%d ",A[i-(t-1)*a][j-(k-1)*b]);
				}
			}printf("\n");
		}
	}
	return 0;
}
