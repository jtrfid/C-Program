#include<stdio.h>
int main(){
	int n,max=0,min=1001,x;
	int arr[105]={0};
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);	
		arr[i]=x;
		if(x>max) max=x;
		if(x<min) min=x;
	}
	int temp=0;
	for(int i=min;i>0;i--){
		if(max%i==0&&min%i==0){
			temp=i;
			break;
		}
	}
	for(int i=1;i<=n;i++){
		if(arr[i]==max) {
			arr[i]=max*min/temp;
			break;
		}
	}
	for(int i=1;i<=n;i++){
		if(arr[i]==min) {
			arr[i]=temp;
			break;
		}
	}
	for(int i=1;i<=n;i++)
	   printf("%d ",arr[i]);
	return 0;
}
