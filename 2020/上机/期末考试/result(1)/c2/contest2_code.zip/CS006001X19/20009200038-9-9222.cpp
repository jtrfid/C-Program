#include<stdio.h>
int main(){
	int a[20]={0};
	int i,n,max,min,xb,dy,fa,fb;
	max=0;
	min=1000;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	};
	for(i=0;i<n;i++){
		if(a[i]>max){
			max=a[i];
			fa=i;
		}
	};
	for(i=0;i<n;i++){
		if(a[i]<min){
			min=a[i];
			fb=i;
		}
	};
	for(i=max;i<1000000;i++){
		if(i%min==0&&i%max==0){
			xb=i;
			break;
		}
	};
	for(i=min;i>0;i--){
		if(max%i==0){
			dy=i;
			break;
		}
	};
	a[fa]=xb;
	a[fb]=dy;
	for(i=0;i<n;i++){
		printf("%d ",a[i]);
	}

	
	
	return 0;
}

