#include<stdio.h>
#include<stdlib.h>
#include<string.h>



int main()
{
	int m,i,j,ji=0,ou=0,chu=0;
	scanf("%d",&m);
	int a[m];
	for(i=0;i<m;i++)
	{
		a[i]=i;
	}
	for(i=0;i<m;i++)
	{
		if(a[i]%2==0)
		{
			ou+=a[i];
		}
		else if(a[i]%2==1)
		{
			ji+=a[i];
		}
	    if(a[i]%5==0&&a[i]%3!=0)
		{
			chu+=a[i];
		}
	}
	printf("%d %d %d\n",ji,ou,chu);
	
	int max=ji;
	if(ou>max)
	max=ou;
	if(chu>max)
	max=chu;
		

	printf("%d",max);
	return 0;
}
