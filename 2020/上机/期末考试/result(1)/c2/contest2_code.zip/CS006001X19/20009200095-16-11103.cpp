#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int x[a][b];
	int i,j,k,t,g;
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&x[i][j]);
		}
	}
	int m,n;
	scanf("%d%d",&m,&n);
	int y[m*a][n*b];
	int h=0;
	while(h<a)
	{
		for(i=0;i<a;i++)
		{
			g=i;
			for(;g<m*a;g=g+a)
			{
				for(j=0;j<n*b;j++)
				{
					k=j%b;
					y[g][j]=x[h][k];
				}
			}
			h++;
			
		}
		
	}
	
	for(i=0;i<m*a;i++)
	{
		for(j=0;j<n*b;j++)
		{
			printf("%d ",y[i][j]);
		}
		printf("\n");
	}
	return 0 ;
}
