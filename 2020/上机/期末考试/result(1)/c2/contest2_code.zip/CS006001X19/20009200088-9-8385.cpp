# include <stdio.h>

int main ()
{
	int n,bei,gcd;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	int max=a[0],min=a[0];
	int pos_max=0,pos_min=0;
	
	for (int k=1;k<n;k++)
	{
		if (a[k]>max)
		{
			max=a[k];
			pos_max=k;
		}
		if (a[k]<min)
		{
			min=a[k];
			pos_min=k;
		}
	}
	
	for (int m=max;m>0;m++)
	{
		if (m%max==0&&m%min==0)
		{
			bei=m;
			break;
		}
	}
	
	for (int s=min;s>0;s--)
    {
    	if (min%s==0&&max%s==0)
    	{
    		gcd=s;
    		break;
    	}
    }
    
    a[pos_max]=bei;
    a[pos_min]=gcd;
    
    for (int t=0;t<n;t++)
    {
    	printf("%d ",a[t]);
    }
    
	return 0;
}
