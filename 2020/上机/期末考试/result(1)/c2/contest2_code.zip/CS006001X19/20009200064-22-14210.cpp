#include<stdio.h>
#include<math.h>
double a[10000],b[10000];
double juli(int i,int j)
{
	double t,d,c,e,m,n;
	c=a[i-1];e=b[i-1];
	m=a[j-1];n=b[j-1];
	t=(m-c)*(m-c)+(e-n)*(e-n);
	d=pow(t,0.5);
	printf("%lf",d);
	return d;
}
double sumjuli(int i,int j,int g)
{
	double d1=0,d2=0,t,m,n;
	int k;
	if(i>=j)
	{
		m=i;n=j;
	}
	if(i<j)
	{
		m=j;n=i;
	}
	for(k=n;k<m;k++)
	{
		d1=juli(k,k+1)+d1;
	}
	for(k=m;k<g;k++)
	{
		d2=juli(k,k+1)+d2;
	}
	d2=d2+juli(n,1);
	for(k=1;k<n;k++)
	{
		d2=d2+juli(k,k+1);
	}
	if(d1>d2)
	{
		t=d2;
	}
	if(d1<=d2)
	{
		t=d1;
	}
	return t;
}
int main()
{
	
	int n,i,j,k,t,num,c,d,m;
	scanf("%d",&n);
	for(i=0;i<=n;i++)
	{
		scanf("%d %lf %lf",&num,&a[i],&b[i]);
	}
	int y;
	for(y=0;y<10000;y++)
	{
		scanf("%d %d",&c,&d);
		if(d-c==1||d-c==-1)
		{
			m=juli(c,d);
		}
		if(d==c)
		{
			m=0;
		}
		if((d-c)==(n-1)||(d-c)==(1-n))
		{
			m=juli(c,d);
		}
		if((d-c)>1||(d-c)<-1)
		{
			m=sumjuli(c,d,n);
		}
		printf("%.2f\n",m);
	}
	return 0;
}
