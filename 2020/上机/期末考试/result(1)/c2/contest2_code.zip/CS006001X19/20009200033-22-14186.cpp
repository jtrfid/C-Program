#include <stdio.h>
int main()
{
	struct dian{
		int a;
		int x;
		int y;
	};
	int n,i;
	scanf("%d\n",&n);
	dian a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&a[i].a,&a[i].x,&a[i].y);
	}
	
	
}
