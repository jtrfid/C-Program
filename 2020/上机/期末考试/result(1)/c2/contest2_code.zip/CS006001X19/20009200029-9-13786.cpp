#include<stdio.h>
int main()
{
	int  max=0 , min=0 , max_i=0,min_i =0, co_max=0,co_min =0, j=0 , h=0 , m=0 , n;
	scanf("%d",&n);
	int a[n],i;
	   for(i=0;i<n;i++)
	   {
	   	  a[i]=0;
	   }
		for(i=0;i<n;i++)
       {
	     scanf("%d",&a[n]);
	   }
	     max_i=0;
       	 min_i=0;
       	 max=a[0];
       	 min=a[0];      
	 for(i=0;i<n;i++)
	 {  
	     if(a[i]>max)
	     {
	    	max=a[i];
	    	max_i=i;
	     }
	      else if(a[i]<min)
	     {
	     	min=a[i];
	     	min_i=i;
	     }
	   
     }
	for(h=1;h<=min;h++)
	{
		if(min%h==0&&max%h==0)
		{
			co_max=h;
		}
	}
	int f = 1;
	for(j=max;j<=min*max;j++)
	{
		if(j%max==0&&j%min==0&&f==1)
		{
			co_min=j;
			f = 0;
		}
	}
	a[max_i]=co_min;
	a[min_i]=co_max;
	for(m=0;m<n;m++)
	{
		scanf("%d",a[m]);
	}
	return 0;
}
