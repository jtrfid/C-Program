#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	
	int i,sum1=0,sum2=0,sum3=0;
	for(i=1;i<n;i++)
	{
		if(i%2==1)
		sum1+=i;
		if(i%2==0)
		sum2+=i;
		if(i%5==0&&i%3!=0)
		sum3+=i;
	}
	
	printf("%d %d %d\n",sum1,sum2,sum3);
	
	int max;
	if(sum1>sum2)
	max=sum1;
	else
	max=sum2;
	
	if(sum3>max)
	max=sum3;
	
	printf("%d",max);
	return 0;
}
