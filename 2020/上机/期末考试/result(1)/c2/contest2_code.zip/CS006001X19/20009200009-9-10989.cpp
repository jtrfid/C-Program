#include<stdio.h>
int main()
{	int n,i,j,max,min,p,q;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{	scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{	for(j=0;j<n;j++)
		{	if(a[i]<a[j]&&i!=j)
			{	break;
			}
			
		}
		if(j==n)
		{	max=a[i];
		}
	}
	for(i=0;i<n;i++)
	{	for(j=0;j<n;j++)
		{	if(a[i]>a[j]&&i!=j)
			{	break;
			}
			
		}
		if(j==n)
		{	min=a[i];
		}
	}
	for(i=1;i<=min;i++)
	{	if(max%i==0&&min%i==0)
		{	p=i;
		}
	}
	for(i=max*min;i>0;i--)
	{	if(i%max==0&&i%min==0)
		{	q=i;
		}
	}
	for(i=0;i<n;i++)
	{	if(a[i]==max)
		{	a[i]=q;
		}
	}
	for(i=0;i<n;i++)
	{	if(a[i]==min)
		{	a[i]=p;
		}
	}
	for(i=0;i<n;i++)
	{	printf("%d ",a[i]);
	}
	
	return 0;
}
