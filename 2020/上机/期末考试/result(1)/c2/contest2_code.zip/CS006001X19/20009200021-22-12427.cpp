#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j,t=0;
	scanf("%d",&n);
	int num[n],x[n],y[n];
	float d_1,d_2;
	float d[100000];
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d",&num[i],&x[i],&y[i]);
	}
	int a,b;
	for(j=0;;j++)
	{
		t++;
		d_1=0.0,d_2=0.0;
		scanf("%d%d",&a,&b);
		if(a==0&&b==0)
		{
			break;
		}
		if(a>b)
		{
			int t=a;
			a=b;
			b=t;
		}
		
		for(i=a;i<b;i++)
		{
			d_1+=1.0*sqrt(1.0*(x[i]-x[i-1])*(x[i]-x[i-1])+1.0*(y[i]-y[i-1])*(y[i]-y[i-1]));
		}
		for(i=b;i<n;i++)
		{
			d_2+=1.0*sqrt(1.0*(x[i]-x[i-1])*(x[i]-x[i-1])+1.0*(y[i]-y[i-1])*(y[i]-y[i-1]));
		}
		d_2+=1.0*sqrt(1.0*(x[0]-x[n-1])*(x[0]-x[n-1])+1.0*(y[0]-y[n-1])*(y[0]-y[n-1]));
		for(i=1;i<a;i++)
		{
			d_2+=1.0*sqrt(1.0*(x[i]-x[i-1])*(x[i]-x[i-1])+1.0*(y[i]-y[i-1])*(y[i]-y[i-1]));
		}
		
		if(d_1<d_2)
		{
			d[j]=d_1;
		}
		else
		{
			d[j]=d_2;
		}
		
	}
	for(j=0;j<t-1;j++)
	{
		printf("%.2f\n",d[j]);
	}
	return 0;
}
