#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int A[a][b],i,j;
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&A[i][j]);
		}
	}
	int m,n,k,l;
	scanf("%d %d",&m,&n);
	for(k=1;k<=m;k++)
	{
		for(i=0;i<a;i++)
		{
			for(l=1;l<=n;l++)
			{
				for(j=0;j<b;j++)
				{
					printf("%d ",A[i][j]);
				}
			}
			printf("\n");
		}
	}
	return 0;
}
