#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int N[a][b];
	int i,p,c1,c2;
	for(i=0;i<a;i++){
		for(p=0;p<b;p++){
			scanf("%d",&N[i][p]);
		}
	}
	scanf("%d %d",&c1,&c2);
	int r,s;
	for(s=0;s<c1;s++){
		for(i=0;i<a;i++)
		{
			for(r=0;r<c2;r++)
			{
				for(p=0;p<b;p++)
				{
					printf("%d ",N[i][p]);
				}
				if(r==c2-1)	printf("\n");
			}
		}
	}
	
}
