#include<stdio.h>
#include<math.h>
int main(){
	int id[10005]={0},x[10005]={0},y[10005]={0};
	int n;
	double d[10005]={0,0},delta_x,delta_y;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d %d %d",&id[i],&x[i],&y[i]);
	x[n+1]=x[1];
	y[n+1]=y[1];
	for(int i=2;i<=n+1;i++){
		delta_x=x[i]-x[i-1]*1.0;
		delta_x*=delta_x;
		delta_y=y[i]-y[i-1]*1.0;
		delta_y*=delta_y;
		
		d[i]=d[i-1]+sqrt(delta_x+delta_y);
	}
	for(int i=1;i<=n+1;i++) printf("%.2f ",d[i]);
	int num1,num2;
	double maxd=d[n+1],minL;
	while(1){
		scanf("%d %d",&num1,&num2);
		if(num1==0&&num2==0) break;
		if(num2<num1) {
			int temp=num1;
			num1=num2;
			num2=temp;
		}
		minL=d[num2]-d[num1];
		if(minL*2>maxd) minL=maxd-minL;
		printf("%.2lf\n",minL);
	}
	return 0;
}
