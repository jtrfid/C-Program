#include<stdio.h>
int main()
{
	int m,i,s1,s2,s3;
	scanf("%d",&m);
	s1=0;
	s2=0;
	s3=0;
	for(i=1;i<m;i++)
	{
		if(i%2==1)
		   s1+=i;
		if(i%2==0)
		   s2+=i;
		if(i%5==0&&i%3!=0)
		   s3+=i;      
	}
	int max;
	if(s1>=s2&&s1>=s3)
	   max=s1;
	if(s2>=s1&&s2>=s3)
	   max=s2;
	if(s3>=s1&&s3>=s2)
	   max=s3;
	printf("%d %d %d\n",s1,s2,s3);
	printf("%d",max);
	return 0;         
}
