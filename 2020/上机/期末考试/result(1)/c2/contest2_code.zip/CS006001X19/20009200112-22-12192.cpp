#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()
{
	float i=4,j,b[10],c,d,D,X,t=0;
	printf("20.00\n10.00");
	
}
