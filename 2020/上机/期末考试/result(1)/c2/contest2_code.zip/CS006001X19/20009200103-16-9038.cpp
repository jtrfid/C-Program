#include<stdio.h>
int main()
{
	int m,n,a,b,i,j;
	scanf("%d%d",&a,&b);
	int ar[a][b];
	for(i=0;i<a;i++)
		for(j=0;j<b;j++)
			scanf("%d",&ar[i][j]);
	scanf("%d%d",&m,&n);
	int br[m*a][n*b];
	for(i=0;i<m*a;i++)
	{
		for(j=0;j<b*n;j++)
		{
			int x=(i+1)%a;
			if(x==0)
				x=a;
			int y=(j+1)%b;
			if(y==0)
				y=b;
			
			br[i][j]=ar[x-1][y-1];
		}
			
	}
	for(i=0;i<m*a;i++)
	{
		for(j=0;j<b*n;j++)
			printf("%d ",br[i][j]);
		printf("\n");
	}
		
	return 0;
}
