#include<stdio.h>
#include<string.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int c[100][100];
	int i,j,k,w;
	for(i=0;i<a;i++){
		for(j=0;j<b;j++){
			scanf("%d",&c[i][j]);
		}
	}
	int m,n;
	scanf("%d",&m);
	scanf("%d",&n);
	for(i=0;i<a;i++){
		for(j=0;j<b*n;j++){
			c[i][j]=c[i][j%b];
		}
	}
	for(k=1;k<=m;k++){
		for(i=0;i<a;i++){
			for(j=0;j<b*n;j++){
				printf("%d ",c[i][j]);
			}
			printf("\n");
		}
	}
}


