#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,c,d,e,f;
scanf("%d",&a);
int i[a],m[a],n[a];
for(b=0;b<a;b++)
{scanf("%d",&i[b]);
m[b]=i[b];
n[b]=i[b];
}
for(b=0;b<a-1;b++)
{if(m[b]<m[b+1])
m[b+1]=m[b];
}
c=m[a-1];
for(b=0;b<a-1;b++)
{if(n[b]>n[b+1])
n[b+1]=n[b];
}
d=n[a-1];
for(b=c;b>0;b--)
{if(c%b==0&&d%b==0)
{e=b;
break;
}
}
for(b=d;;b++)
{if(b%c==0&&b%d==0)
{f=b;
break;
}
}
for(b=0;b<a;b++)
{if(i[b]==c)
i[b]=e;
if(i[b]==d)
i[b]=f;
}
for(b=0;b<a;b++)
{printf("%d ",i[b]);
}
	return 0;
}
