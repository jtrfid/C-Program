#include<stdio.h>
#include<string.h>
int main()
{
	int i;
	scanf("%d",&i);
	int a[100];
	int n;
	for(n=0;n<i;n++)
	{
		scanf("%d",&a[n]);
	}
	int j,t,w,k,z;
	int max,min;
	max=a[0];
	min=a[0];
	for(n=0;n<i;n++){
		if(a[n]>max){
			max=a[n];
			j=n;
		}
		if(a[n]<min){
			min=a[n];
			t=n;
		}
		}
	int ab,cd;
	ab=max;
	cd=min;
	while(w>0){
		w=ab%cd;
		ab=cd;
		cd=w;
	}
	k=max*min;
	z=k/ab;
	a[j]=z;
	a[t]=ab;
	for(n=0;n<i;n++){
		printf("%d ",a[n]);
	}
}
