#include<stdio.h>
int y(int n,int m){
	int k=0;
		for(int i=m;i>=1;i--)
		{
			if(n%i==0&&m%i==0) {
				k=i;
				break;
			}
	}
	return k;
}
int b(int n,int m){
	int k=0;
		for(int i=n;i<=n*m;i++)
		if(i%m==0&&i%n==0){
			k=i;break;
		}
	return k;
}
int main(){
	int n;
	scanf("%d",&n);
	int a[1000]={0};
	for(int i=0;i<=n-1;i++){
		scanf("%d",&a[i]);
	}
	int max=0,min=1000;
	for(int k=0;k<=n-1;k++){
		if(a[k]>max)max=a[k];
		if(a[k]<min)min=a[k];
	}
	int gy=y(max,min);
	int gb=b(max,min);
	for(int j=0;j<=n-1;j++){
		if(a[j]==max)a[j]=gb;
		if(a[j]==min)a[j]=gy;
	}
	for(int l=0;l<=n-1;l++)
	printf("%d ",a[l]);
	return 0;
}
