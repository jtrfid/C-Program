#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 
{
	int m,i,a=0,b=0,c=0,max=0;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		if(i%2==1)a=a+i;
		if(i%2==0)b=b+i;
		if(i%5==0&&i%3!=0)c=c+i;
	}
	if(a>b)max=a;
	else max=b;
	if(c>max)max=c;
	printf("%d %d %d\n%d",a,b,c,max);
	return 0;
}
