#include<stdio.h>
#include<math.h>
double ju(double ,double ,double ,double );
int main(void)
{
	int n,f,i,j,p=1;
	int a[10000],b[10000];
	scanf("%d",&n);
	double x[n+1],y[n+1];
	double t[n+1];
	for (i=1;i<=n;i++) scanf("%d %lf %lf",&f,&x[i],&y[i]);
	t[1]=ju(x[1],x[n],y[1],y[n]);
	for (i=2;i<=n;i++)
	{
		t[i]=ju(x[i],x[i-1],y[i],y[i-1]);
	}
	scanf("%d %d",&a[p],&b[p]); if(a[p]>b[p]) {f=a[p];a[p]=b[p];b[p]=f;}
	while(a[p]!=0&&b[p]!=0)
	{
		p=p+1;
		scanf("%d %d",&a[p],&b[p]);
		if(a[p]>b[p]) {f=a[p];a[p]=b[p];b[p]=f;}
	}
	double g[p],h[p];
	p=p-1;
	for (i=1;i<=p;i++) {g[i]=0;h[i]=0;}
	for (i=1;i<=p;i++)
	{
		for(j=1;j<=a[i];j++) g[i]=g[i]+t[j];
		for (j=b[i]+1;j<=n;j++) g[i]=g[i]+t[j];
		for (j=a[i]+1;j<=b[i];j++) h[i]=h[i]+t[j];
	}
    for (i=1;i<=p;i++)
	{
		if(g[i]<h[i]) printf("%.2f\n",g[i]);
		else printf("%.2f\n",h[i]);
	}
	return 0;
}
double ju(double x1,double x2,double y1,double y2)
{
	double t,tt;
	t=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
	tt=sqrt(t);
	return tt;
}
