#include<stdio.h>
int main()
{int n,x,j,o,z,b[3],i,k,t;
 scanf("%d",&x);
 for(n=j=o=z=0;n<x;n++)
 {if(n%2==0)
  o=o+n;
  else
  j=j+n;
  if(n%5==0&&n%3!=0)
  z=z+n;
  
 }
 b[0]=o;
 b[1]=j;
 b[2]=z;
 for(i=0;i<3;i++)
 {for(k=0;k<3-i;k++)
  if(b[k]<b[k+1])
  {t=b[k];
   b[k]=b[k+1];
   b[k+1]=t;
  }
 }
 printf("%d %d %d\n%d",j,o,z,b[0]);
 return 0; 
}
