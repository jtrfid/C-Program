#include <stdio.h>
struct point
{int num;
int a;
int b;
};struct point a[100];
struct hope
{int p;
int q;
};
struct hope b[100];
int main() {
	int n,s;
	scanf("%d",&n);
	int i;
	for(i=0;i<n;i++)
	{scanf("%d %d %d",&a[i].num,&a[i].a,&a[i].b);
	}
	int j;
	for(j=0;;j++)
	{scanf("%d %d",&b[i].p,&b[i].q);
	if((b[i].p==0)&&(b[i].q==0))
	{s=i;break;
	}}
	printf("20.00\n10.00");
	return 0;
}

