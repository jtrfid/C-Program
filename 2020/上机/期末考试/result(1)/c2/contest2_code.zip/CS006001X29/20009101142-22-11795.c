#include <stdio.h>
#include <math.h>

int main()
{
	int n;
	scanf("%d",&n);
	int x[n],y[n],i,num[i];
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&num[i],&x[i],&y[i]);
	}
	int a[1000],b[1000];
	for(i=0;;i++)
	{
		scanf("%d %d",&a[i],&b[i]);
		if(a[i]==0&&b[i]==0)
		{
			break;
		}
	}
	int j,p,q,m;
	double s1,s2,s; 
	for(j=0;j<i;j++)
	{
		s1=0;s2=0;s=0; 
		p=a[j]-1;
		q=b[j]-1;
		if(p==q) s=0;
		else
		{
			if(p>q)
			{	
				int t;
				t=p;
				p=q;
				q=t;
			}
			for(m=p;m<q;m++)
			{
				s1=s1+pow(((x[m]-x[m+1])*(x[m]-x[m+1])+
					(y[m]-y[m+1])*(y[m]-y[m+1])),0.5);
			}
			for(m=0;m<n-1;m++)
			{
				s2=s2+pow(((x[m]-x[m+1])*(x[m]-x[m+1])+
					(y[m]-y[m+1])*(y[m]-y[m+1])),0.5);
			}
			s2=s2-s1+pow(((x[0]-x[n-1])*(x[0]-x[n-1])+
					(y[0]-y[n-1])*(y[0]-y[n-1])),0.5);;
			if(s2>s1) s=s1;
			else s=s2;
		}
		printf("%.2lf\n",s);
	}
}
