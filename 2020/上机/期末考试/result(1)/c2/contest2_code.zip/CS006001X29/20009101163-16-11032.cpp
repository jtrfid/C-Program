#include<stdio.h>
int main()
{
	int m,n,i,j,b,c,k,l;
	int a[10][10];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
	}
	scanf("%d %d",&k,&l);
	for(b=0;b<k;b++)
	    for(i=0;i<m;i++)
		 {
		 	for(c=0;c<l;c++)
		 	{
		 		for(j=0;j<n;j++)
		 		printf("%d ",a[i][j]);
		 	}
		 	printf("\n");
		 }	
	return 0;
}
