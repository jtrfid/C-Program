#include<stdio.h>
#include<string>
int main()
{
	int x,a,b,c,max,i;
	a=0;
	b=0;
	c=0;
	scanf("%d",&x);
	for(i=1;i<x;i++)
	{
		if(i%2!=0)
		
		{
			a=a+i;
		}
		if(i%2==0)
		{
			b=b+i;
		}
		if(i%5==0&&i%3!=0)
		{
			c=c+i;
		}
		
	}
	
	max=a;
	if(max<b) max=b;
	if(max<c) max=c;
	printf("%d %d %d",a,b,c);
	printf("\n");
	printf("%d",max);
	
	
	
	
	return 0;
}
