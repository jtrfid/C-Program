#include <stdio.h>

int main(){
	int x[10][10]={0},y[50][50]={0},i,j,a,b,m,n,p,q;
	scanf("%d %d",&a,&b);
	for(i=0;i<a;i++){
		for(j=0;j<b;j++)scanf("%d",&x[i][j]);
	}
	scanf("%d %d",&m,&n);
	
	for(p=0;p<m;p++){
		for(q=0;q<n;q++){
			for(i=0;i<a;i++){
				for(j=0;j<b;j++){
					y[p*a+i][q*b+j]=x[i][j];
				}
			}
		}
	}
	
	for(i=0;i<m*a;i++){
		for(j=0;j<n*b;j++){
			printf("%d ",y[i][j]);
		}
		printf("\n");
	}
	return(0);
}
