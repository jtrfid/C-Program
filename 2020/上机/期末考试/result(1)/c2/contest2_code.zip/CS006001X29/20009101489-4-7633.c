#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int m,i,s1=0,s2=0,s3=0;
	scanf("%d",&m);
	for(i=1;i<m;i++)
	{
		if(i%2!=0)
		{
			s1+=i;
		}
		if(i%2==0)
		{
			s2+=i;
		}
		if(i%5==0&&i%3!=0)
		{
			s3+=i;
		}
	}
		printf("%d %d %d\n",s1,s2,s3);
		if(s1<s2)
		{
			i=s1;
			s1=s2;
			s2=i;
		}
		if(s2<s3)
		{
			i=s2;
			s2=s3;
			s3=i;
		}
		if(s1<s2)
		{
			i=s1;
			s1=s2;
			s2=i;
		}
		
		printf("%d",s1);
	
	return 0;
}
