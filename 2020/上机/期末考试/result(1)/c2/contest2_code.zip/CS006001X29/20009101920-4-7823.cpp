#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

int main()
{int a,b,c=0,d=0,e=0,f;
scanf("%d",&a);
for(b=1;b<a;b++)
{if(b%2==1)
c=c+b;
if(b%2==0)
d=d+b;
if(b%5==0&&b%3!=0)
e=e+b;
}
printf("%d %d %d\n",c,d,e);
if(c>=d&&c>=e)
printf("%d",c);
else
{if(d>=e)
printf("%d",d);
else 
printf("%d",e);
}
	return 0;
}
