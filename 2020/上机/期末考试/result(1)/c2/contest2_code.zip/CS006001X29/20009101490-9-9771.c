#include <stdio.h>
#include<string.h>
int main() {
	int n;
	scanf("%d",&n);
	int i,j,t,m,q,k,p;
	int a[100],b[100];
	for(i=0;i<n;i++)
	{scanf("%d",&a[i]);
	b[i]=a[i];}
	for(j=0;j<n-1;j++)
		{for(i=0;i<n-1-j;i++)
		if(a[i]>a[i+1])
		{t=a[i];
		a[i]=a[i+1];
		a[i+1]=t;
		}
		}
	m=a[0];
	q=a[n-1];
	for(i=n;;i++)
	{if((i%q==0)&&(i%m==0))
	{k=i;break;}
	}
	for(j=m;;j--)
	{if((m%j==0)&&(q%j==0))
	{p=j;break;}
	}
	for(i=0;i<n;i++)
		{if(b[i]==m){b[i]=p;}
		if(b[i]==q){b[i]=k;}
		}
	for(i=0;i<n;i++)
	{printf("%d ",b[i]);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
	
