#include<stdio.h>
#include<math.h>
int main()
{
	float length(int x,int y,int h,int j);
	int n,i,j;float zhi,wuguan;
	scanf("%d",&n);
	int  a[n],b[n];
	for(i=0;i<n;i++)
	{
		scanf("%f%d%d",&wuguan,&a[i],&b[i]);
	}
	int o,p;
	scanf("%d%d",&o,&p);
	while(o!=0&&p!=0)
	{
		zhi=length(a[o-1],b[o-1],a[p-1],b[p-1]);
		printf("%.2f\n",zhi);
		scanf("%d%d",&o,&p);
	}
	
}

float length(int x,int y,int h,int j)
{
	float z;
	z=sqrt((x-h)*(x-h)+(y-j)*(y-j));
	return (z);
}
