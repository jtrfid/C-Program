#include<stdio.h>
int main ()
{
	int n,i,j,min,max,p,q;
	int a[20];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	 scanf("%d",&a[i]);
	min=a[0];
	max=a[0];  
        for(i=1;i<n;i++)
    {
    	if(a[i]<min)
    	{
    		min=a[i];
    		p=i;
    	} 
    	if(a[i]>max)
    	{
    		max=a[i];
    		q=i;
    	}
    }
        int b=0,c=0,g;
    for(g=min;g>=2;g--)
    {
    	if(min%g==0&&max%g==0)
    	{
    		b=g;
    		break;
    	}
    }
    c=b*(min/b)*(max/b);
    a[p]=b;
    a[q]=c;
    int l;
    for(l=0;l<n;l++)
     printf("%d ",a[l]);
    return 0;
}
