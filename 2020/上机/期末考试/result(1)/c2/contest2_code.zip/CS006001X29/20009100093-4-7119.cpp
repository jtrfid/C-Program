#include <stdio.h>

int main(){
	int m,i,s1=0,s2=0,s3=0,t;
	scanf("%d",&m);
	for(i=1;i<m;i++){
		if(i%2!=0)s1=s1+i;
		else s2=s2+i;
		if((i%5==0)&&(i%3!=0))s3=s3+i;
	}
	
	if(s1>s2)t=s1;
	else t=s2;
	if(s3>t)t=s3;
	
	printf("%d %d %d\n%d",s1,s2,s3,t);
	return(0);
}
