#include <bits/stdc++.h>
#define N (100010)
#define INF (2100000000)
using namespace std;
inline void judge() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
}
int n, Max, Min;
int a[N];
int x, y;
int main() {
	//judge();
	
	
	scanf("%d", &n);
	Min = INF;
	for (int i = 1; i <= n; ++i) scanf("%d", &a[i]);
	for (int i = 1; i <= n; ++i) {
		if (a[i] > Max) Max = a[i];
		if (a[i] < Min) Min = a[i];
	}
	x = __gcd(Max, Min); y = Max / x * Min;
	for (int i = 1; i <= n; ++i) {
		if (a[i] == Max) a[i] = y;
		if (a[i] == Min) a[i] = x;
	}
	for (int i = 1; i <= n; ++i) printf("%d ", a[i]); 
	return 0;
}
