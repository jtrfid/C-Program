#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int weizhi1,weizhi2;
	int max=a[0],min=a[0];
	for(i=0;i<n;i++)
	{
		if(max<a[i])
		{
			int k;
			k=max;
			max=a[i];
			a[i]=k;
			weizhi1=i;
		}
		if(min>a[i])
		{
			int k;
			k=min;
			min=a[i];
			a[i]=k;
			weizhi2=i;
		}
	}
	for(i=min;i>0;i--)
	{
		if(max%i==0&&min%i==0)
		{
			break;
		}
		
	}
	int min1,max1;
	min1=i;
	max1=max*min/min1;
	a[weizhi1]=max1;
	a[weizhi2]=min1;
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
}
