#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int n;
	scanf("%d",&n);
	int zu[n],cop[n];
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%d",&zu[i]);
		cop[i]=zu[i];
	}
	int max=0,min=9999,da,xiao,max1,min1;
	for(i=0;i<n;i++)
	{
		if(zu[i]>max)
		{
			max=cop[i];
			da=i;
		}
		if(zu[i]<min)
		{
			min=cop[i];
			xiao=i;
		}
	}
	for(int i=max;;i++)
	{
		if(i%max==0 && i%min==0)
		{
		max1=i;
		break;}
	}
	for(int i=min-1;;i--)
	{
		if(max%i==0&&min%i==0){
		
		min1=i;
		break;}
	}
	
	zu[da]=max1;
	zu[xiao]=min1;
	for(i=0;i<n;i++)
	{
		printf("%d ",zu[i]);
	}
	return 0;
}
