#include<stdio.h>
int main(void)
{
	int m,n,hf,lf,i,j,p,q;
	scanf("%d %d",&m,&n);
	int a[m+1][n+1];
	for (i=1;i<=m;i++)
	 for (j=1;j<=n;j++)
	  scanf("%d",&a[i][j]);
	scanf("%d %d",&hf,&lf);
	for (q=1;q<=hf;q++)
	{
	 for (p=1;p<=m;p++)
	  {
	    for (i=1;i<=lf;i++)
	    {
          for (j=1;j<=n;j++) printf("%d ",a[p][j]);
	    }
	    printf("\n");
      }
    }
    return 0;
}

