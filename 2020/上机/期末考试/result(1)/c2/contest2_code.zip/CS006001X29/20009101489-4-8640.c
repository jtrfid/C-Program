#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int ab(int ,int );
	int n;
	scanf("%d%",&n);
	int num[n],i,max,min,mr,nr;
	for(i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
	}
	max=num[0];
	min=num[0];
	for(i=1;i<n;i++)
	{
		if(num[i]>max)
		{
			max=num[i];
			mr=i;
		}
		if(num[i]<min)
		{
			min=num[i];
			nr=i;
		}
	}
	int in,ax;
	in=ab(max,min);
	ax=min*max/in;
	num[mr]=ax;
	num[nr]=in;
	for(i=0;i<n;i++)
	{
		printf("%d ",num[i]);
	}
	return 0;
}
int ab(int a,int b)
{
	int c;
	do
	{
		c=a%b;
		a=b;
		b=c;
	}while(b!=0);
	return a;
}
