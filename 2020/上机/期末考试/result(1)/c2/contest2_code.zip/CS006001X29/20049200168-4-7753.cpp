#include<stdio.h>
int main()
{ int n=0,a=0,b=0;
  int i,t,m;
  scanf("%d",&m);
  for(i=0;i<m;i++)
  {if(i%2==1)
    n=n+i;
  }
   for(i=0;i<m;i++)
  {if(i%2==0)
    a=a+i;
  }
   for(i=0;i<m;i++)
  {if(i%5==0&&i%3!=0)
    b=b+i;
  }
  if(n>=a&&n>=b)
  t=n;
  if(b>=a&&b>=n)
  t=b;
  if(a>=n&&a>=b)
  t=a;
  printf("%d %d %d\n",n,a,b);
  printf("%d",t);
	return 0;
}
