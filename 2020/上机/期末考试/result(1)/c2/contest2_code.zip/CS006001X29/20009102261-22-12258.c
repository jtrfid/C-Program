#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,i,j;
	double count11,count12,count1,count2,count21,count22;
	scanf("%d",&n);
	int a[100][3];
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
		scanf("%d",&a[i][j]);
	}
	int x[100],y[100];
	i=0;
	while(x[i]==0 && y[i]==0)
	{
		scanf("%d %d",x[i],y[i]);
		i++;
	}
	i=0;
	for(j=0;j<i;j++)
	{
		while(y[i]==x[i])
		{
			count11=0;
			count12=0;
			count11=pow(2,(a[x[i]][2]-a[x[i]+1][2]));
			count12=pow(2,(a[x[i]][3]-a[x[i]+1][3]));
			count1+=pow(0.5,count11+count12);
			x[i]++;
		}
	printf("%.2f",count1);
    }
	return 0;
}
