#include<stdio.h>
int main(){
	int m;
	scanf("%d",&m);
	int i,s1=0,s2=0,s3=0;
	for(i=1;i<m;i++){
		if(i%2!=0)s1=s1+i;
		if(i%2==0)s2=s2+i;
		if(i%5==0&&i%3!=0)s3=s3+i;
		
	}
	int max;
	if(s1>s2)max=s1;
	else max=s2;
	if(s3>max)max=s3;
	printf("%d %d %d\n%d",s1,s2,s3,max);
	
	return 0;
	
}
