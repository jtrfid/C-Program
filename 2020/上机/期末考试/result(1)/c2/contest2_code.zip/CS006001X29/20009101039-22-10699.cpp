#include<stdio.h>
#include<string.h>
#include<math.h>
struct zuobiao
{
	int bianhao;
	float x;
	float y;
};
int main()
{
    float sum=0.0;
	int N,flag=1,num1=-1,num2=-1;
    scanf("%d",&N);
    struct zuobiao dian[N];
    for(int i=0;i<N;i++)
    {
    	scanf("%d %f %f",&dian[i].bianhao,&dian[i].x,&dian[i].y);
    }
    
    
    	scanf("%d %d",&num1,&num2);
    	/*if(num1==num2==0)
    	{
    		break;
    	}*/
		if(num1>num2)
    	{
    		int temp;
    		temp=num1;
    		num1=num2;
    		num2=temp;
    	}
    	for(int i=num1-1;i<num2-1;i++)
    	{
    		sum=sum+pow(((dian[i].x-dian[i+1].x)*(dian[i].x-dian[i+1].x)+(dian[i].y-dian[i+1].y)*(dian[i].y-dian[i+1].y)),0.5);
    	}
    	printf("%.2f",sum);
    
    
	return 0;
}
