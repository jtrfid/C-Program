#include<stdio.h>
int main()
{
	int n,i;
	int weizhi1=0,weizhi2=0;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}

	int max=a[0],min=a[0];
	for(i=0;i<n;i++)
	{
		if(max<a[i])
		{
			max=a[i];
			weizhi1=i;
	
		}
		if(min>a[i])
		{
			min=a[i];
			weizhi2=i;
		}
	}

	int max1,min1;	
	for(i=min;i>0;i--)
	{
		if(max%i==0&&min%i==0)
		{
			min1=i;break;
		}
		
	}

	
	max1=max*min/min1;
	
	a[weizhi1]=max1;
	a[weizhi2]=min1;
	
	

	
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	}

