#include<stdio.h>
#include<math.h>
#include<string.h>
int main() 
{
	int array[10][10];int a,b,m,n,i,j,p,q;int arraypro[50][50];
	scanf("%d%d",&a,&b);
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		scanf("%d",&array[i][j]);
	}
	scanf("%d%d",&m,&n);
	
	for(q=0;q<m;q++)
	{
		for(p=0;p<n;p++)
		{
			for(i=0;i<a;i++)
			{
				for(j=0;j<b;j++)
					arraypro[i+q*a][j+p*b]=array[i][j];
			}
		}
	}
	for(i=0;i<a*m;i++)
	{
		for(j=0;j<b*n-1;j++)
		{
			printf("%d ",arraypro[i][j]);
			
		}
		printf("%d \n",arraypro[i][b*n-1]);	
	}
	
	return 0;
}

