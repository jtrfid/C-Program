#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int bei(int x,int y)
{
	int i,a;
	for(i=10000;i>x;i--)
	{
		if(i%x==0 && i%y==0)
		{
			a=i;
		}
	}
	return a;
}
int yin(int x,int y)
{
	int i,a;
	for(i=1;i<y;i++)
	{
		if(x%i==0 && y%i==0)
		{
			a=i;
		}
	}
	return a;
}
int main(int argc, char *argv[]) {
	int n,i,j,min,max,x,y,b,c;
	scanf("%d",&n);
	int a[1000];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
		min=a[0];
		max=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
	{
	max=a[i];
	x=i;
	}
		
	}
		for(i=0;i<n;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			y=i;
		}
		
	}
	b=bei(a[x],a[y]);
	a[x]=b;
	c=yin(a[x],a[y]);
	a[y]=c;
	

	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
