#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	int max=a[0],min=a[0];
	for(i=0;i<n;i++)
	{
		max=(max>a[i])?max:a[i];
		min=(min<a[i])?min:a[i];
	}
	for(i=min;i>0;i--)
	{
		if(max%i==0&&min%i==0)
		{
			break;
		}
		
	}
	int min1,max1;
	min1=i;
	max1=max*min/min1;
	for(int i=0;i<n;i++)
	{
		if(a[i]==max)
		{
			a[i]=max1;
		}
		else if(a[i]==min)
		{
			a[i]=min1;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
}
