#include<stdio.h>
int main(){
	int a,b,m,n,i,j;
	scanf("%d %d",&a,&b);
	int s[a][b];
	for(i=0;i<a;i++){
		for(j=0;j<b;j++){
			scanf("%d",&s[i][j]);
		}
	}
scanf("%d %d",&m,&n);
int x[a*m][b*n];
for(i=0;i<a*m;i++){
	for(j=0;j<b*n;j++){
		x[i][j]=s[i%a][j%b];
	}
}
for(i=0;i<a*m;i++){printf("\n");
	for(j=0;j<b*n;j++){
		printf("%d ",s[i%a][j%b]);
	}
}

return 0;


	
	
}
