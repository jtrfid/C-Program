#include <stdio.h>

int main() {
	int n,x,y,i,m,p;
    scanf("%d",&n);
	int a[n-1];
	for (i=0;i<n;i++)  scanf("%d",&a[i]);
	x=a[0];y=a[0];
    for (i=0;i<n;i++)  {x=x>a[i]?x:a[i];if(x==a[i]) m=i;}  //da
	for (i=0;i<n;i++)  {y=y<a[i]?y:a[i];if(y==a[i]) p=i;}  //xiao
	for (;x-y!=0;)  {x=x-y; if (x<y) {i=x;x=y;y=i;}}
	x=a[m]*a[p]/y;
	a[m]=x;a[p]=y;
	for (i=0;i<n;i++)  printf("%d ",a[i]);
	return 0;
}
