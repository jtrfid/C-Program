#include <stdio.h>
int main() {
	int a,b,m,n,i,j,x,y;
	scanf("%d %d",&a,&b);
	int s[a-1][b-1];
	for (i=0;i<a;i++)
	  for (j=0;j<b;j++)  scanf ("%d",&s[i][j]);
	scanf ("%d %d",&m,&n);
    for (x=0;x<m;x++){
    	for (i=0;i<a;i++){
    		for (y=0;y<n;y++){
    			for (j=0;j<b;j++)  {printf("%d ",s[i][j]);}	
    		}
			printf("\n");
    	}
    }
	 
	return 0;
}
