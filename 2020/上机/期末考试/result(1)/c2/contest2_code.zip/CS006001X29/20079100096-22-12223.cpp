#include<stdio.h>
#include<math.h>
int main(){
	int n,a,b,i;
	float d;
	scanf("%d",&n);
	struct shu {
	int xuhao;int a;int b;
	}s[n];
	for(i=0;i<n;i++){
		scanf("%d %d %d",&s[i].xuhao,&s[i].a,&s[i].b);	
	}
	int x,y;
	float sum=0;
	while(scanf("%d %d",&x,&y)!='0 0'){
	for(i=x;i<y;i++){
		sum=sum+sqrt((s[i-1].a-s[i].a)*(s[i-1].a-s[i].a)+(s[i-1].b-s[i].b)*(s[i-1].b-s[i].b));
	}printf("%.2f",sum);
	}
	
	return 0;
	
	
}
