#include<stdio.h>
#include<math.h>
struct aa{
	int a;
	int x;
	int y;
};
struct qq{
	int p1;
	int p2;
};
int main(){
	int n;
	scanf("%d",&n);
	struct aa p[n];
	int m;
	struct qq q[1000];
	int i;
	for(i=1;i<=n;i++){
		scanf("%d %d %d",&p[i].a,&p[i].x,&p[i].y);
	}
	for(i=1;;i++){
		scanf("%d %d",&q[i].p1,&q[i].p2);
		if(q[i].p1==0&&q[i].p2==0){
			m=i-1;
			break;
		}
	}
	double a[m];
	double long0=0.0;
	for(i=1;i<=n;i++){
		a[i]=0.0;
		if(i<n){
			long0+=sqrt((p[i+1].x-p[i].x)*(p[i+1].x-p[i].x)+(p[i+1].y-p[i].y)*(p[i+1].y-p[i].y));
		}
		else long0+=sqrt((p[i].x-p[1].x)*(p[i].x-p[1].x)+(p[i].y-p[1].y)*(p[i].y-p[1].y));
	}
	//printf("%.2f",long0);
	for(i=1;i<=m;i++){
		for(int j=q[i].p1;j<q[i].p2;j++)a[i]+=sqrt((p[j].x-p[j+1].x)*(p[j].x-p[j+1].x)+(p[j].y-p[j+1].y)*(p[j].y-p[j+1].y));
		if(a[i]>(long0-a[i]))a[i]=long0-a[i];
		
	}
	for(i=1;i<=m;i++)printf("%.2f\n",a[i]);
	return 0;
}

