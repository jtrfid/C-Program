#include<stdio.h>
int main()
{
	int a[20],n,i,max=0,min,p,q,yue,bei;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	   scanf("%d",&a[i]);
	min=a[0]; q=0;
	for(i=0;i<n;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			q=i;
		}
		if(a[i]>max)
		{
			max=a[i];
			p=i;
		}
	}
	for(i=1;i<=min;i++)
	{
		if(min%i==0&&max%i==0) yue=i;
	}
	for(i=max;i<=max*min;i++)
	{
		if(i%min==0&&i%max==0) 
		{
		bei=i;
		break;
	    }
	}
	a[p]=bei; a[q]=yue;
	for(i=0;i<n-1;i++) printf("%d ",a[i]);
	printf("%d",a[n-1]);
	return 0;
}
