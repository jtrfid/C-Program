#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

/*int main(int argc, char *argv[]) 
{
    int n,i,max,min,gb,gy;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
    	scanf("%d",&a[i]);
    }
    max=min=a[0];
    for(i=0;i<n;i++)
    {
    	if(a[i]>max)max=a[i];
    	if(a[i]<min)min=a[i];
    }
    for(i=max;;i++)
    {
    	if(i%max==0&&i%min==0)
    	{
    		gb=i;
    		break;
    	}
    }
    for(i=min;i>0;i--)
    {
    	if(max%i==0&&min%i==0)
    	{
    		gy=i;
    		break;
    	}
    }
    for(i=0;i<n;i++)
    {
    	if(a[i]==max)a[i]=gb;
    	if(a[i]==min)a[i]=gy;
    }
    for(i=0;i<n;i++)
    {
    	printf("%d ",a[i]);
    }
	return 0;
}*/
int main()
{
	float min(float a,float b);
	int n,js,i,j,q,w,t;
	scanf("%d",&n);
	float a[n][3],z=0;
	int b[5][2];
	float jl[5];
	for(i=0;i<n;i++)
	{
		scanf("%f %f %f",&a[i][0],&a[i][1],&a[i][2]);
	}
	for(i=0;i<5;i++)
	{
		scanf("%d %d",&b[i][0],&b[i][1]);
		if(b[i][0]==0&&b[i][1]==0)break;
	}
	js=i;
	for(j=1;j<n;j++)
	{
		z=z+sqrt(pow(a[j-1][1]-a[j][1],2.0)+pow(a[j-1][2]-a[j][2],2.0));
	}
	z=z+sqrt(pow(a[0][1]-a[n-1][1],2.0)+pow(a[0][2]-a[n-1][2],2.0));
	for(i=0;i<js;i++)
	{
		jl[i]=0;
	}
	for(i=0;i<js;i++)
	{
		q=b[i][0];w=b[i][1];
		if(q>w)
		{
			t=q;
			q=w;
			w=t;
		}
		for(j=q;j<w;j++)
		{
		    jl[i]=jl[i]+sqrt(pow(a[j-1][1]-a[j][1],2.0)+pow(a[j-1][2]-a[j][2],2.0));	
		}
		
	}

	for(i=0;i<js;i++)
	{
		printf("%.2f\n",min(z,jl[i]));
	}
	return 0;
}
float min(float a,float b)
{
	float c;
	c=a-b;
	if(c<b)return c;
	else return b;
}
