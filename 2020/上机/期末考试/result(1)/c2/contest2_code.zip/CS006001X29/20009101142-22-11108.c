#include <stdio.h>
#include <math.h>


int main()
{
	int n,i,j,p,q,k;
	scanf("%d",&n);
	struct point
	{
		int num;
		int x;
		int y;
	}a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&a[i].num,&a[i].x,&a[i].y);
	}
	int c[1000],d[1000];
	for(i=0;;i++)
	{
		scanf("%d %d",&c[i],&d[i]);
		if(c[i]==0&&d[i]==0)
		{
			break;
		}
	}
	double s1,s2,s;
	int m;
	for(j=0;j<i;j++)
	{
		s1=0;s2=0;
		for(k=0;k<n;k++)
		{
			if(a[k].num==c[j]) p=c[j];
			if(a[k].num==d[j]) q=d[j];
		}
	
		if(p>q)
		{	
			int t;
			t=p;
			p=q;
			q=t;
		}
		for(m=p;m<p;m++)
		{
			s1=s1+pow(((a[m].x-a[m+1].x)*(a[m].x-a[m+1].x)+
				(a[m].y-a[m+1].y)*(a[m].y-a[m+1].y)),0.5);
		}
		for(m=0;m<n;m++)
		{
			s2=s2+pow(((a[m].x-a[m+1].x)*(a[m].x-a[m+1].x)+
				(a[m].y-a[m+1].y)*(a[m].y-a[m+1].y)),0.5);
		}
		s2=s2-s1;
		if(s2>s1) s=s1;
		else s=s2;
		printf("%.2lf\n",s);
	}
}
