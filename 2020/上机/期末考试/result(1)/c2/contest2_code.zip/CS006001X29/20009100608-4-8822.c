#include<stdio.h>
#include<string.h>
int main()
{
	int i;
	scanf("%d",&i);
	int n;
	int a,b,c;
	a=0;
	b=0;
	c=0;
	if(i%2==0){
		for(n=0;n<=i;n+=2){
			a+=n;
		}
		for(n=1;n<i;n+=2){
			b+=n;
		}
	}else{
		for(n=0;n<i;n+=2){
			a+=n;
		}
		for(n=1;n<=i;n+=2){
			b+=n;
	}
}
	for(n=0;n<=i;n++){
		if((n%5==0)&&(n%3!=0)){
			c+=n;
		}
	}
	printf("%d %d %d\n",a,b,c);
	
	if(a>b){
		if(a>c){
			printf("%d",a);
		}else{
			printf("%d",c);
		}
	}else{
		if(b>c){
			printf("%d",b);
		}else{
			printf("%d",c);
		}
	}
	
	
	

}
