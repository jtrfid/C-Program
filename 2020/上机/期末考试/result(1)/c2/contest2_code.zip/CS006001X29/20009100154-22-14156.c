#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

struct point{
	int num;
	int x;
	int y;
}; 
int main() {
	int N;
	int m[N],n[N],r,i,a;
	scanf("%d",&N);
	struct point p[N];
	double d1=0.0,d2=0.0,max=0.0;
	for(i=0;i<N;i++)
	    {
	    	scanf("%d %d %d",&p[i].num,&p[i].x,&p[i].y);
	    }
	while(m[i]!=0){
		scanf("%d %d",&m[i],&n[i]); 
		if(m[i]>n[i]){r=m[i];m[i]=n[i];n[i]=r;}
		i++;a++;	
	}   
	for(i=0;i<a;i++){
		d1=0.0;d2=0.0;
		for(r=m[i]-1;r<n[i]-1;r++){
		    d1=d1+sqrt(pow((p[r].x-p[r+1].x),2)+pow((p[r].y-p[r+1].y),2));	
		}
		for(r=n[i]-1;r<N-1;r++){
			d2=d2+sqrt(pow((p[r].x-p[r+1].x),2)+pow((p[r].y-p[r+1].y),2));
		}
		for(r=0;r<m[i]-1;r++){
			d2=d2+sqrt(pow((p[r].x-p[r+1].x),2)+pow((p[r].y-p[r+1].y),2));
		}
		if(d1<d2)printf("%.2lf\n",d1);
		else printf("%.2lf\n",d2);
	}
	 
	return 0;
}
