#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int max(int x,int y)
{
	if(x>y)
	return x;
	else return y;
}







int main(int argc, char *argv[]) {
	int n;
	scanf("%d",&n);
	int i,sumji=0,sumou=0,sum35=0;
	int m;
	for(i=0;i<n;i++)
	{
		if(i%2==0)
		sumou+=i;
		if(i%2!=0)
		sumji+=i;
		if(i%5==0 && i%3!=0)
		sum35+=i;
	}
	m=max(sumji,sumou);
	m=max(sum35,m);
	printf("%d %d %d\n",sumji,sumou,sum35);
	printf("%d",m);
	return 0;
}
