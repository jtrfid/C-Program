#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float len(int a,int b,int c,int d);
	struct p
	{
		int n;
		int x;
		int y;
	};
	int shu,i;
	float sumlen;
	scanf("%d",&shu);
	struct p num[100];
	for(i=0;i<shu;i++)
	{
		printf("%d %d %d",&num[i].n,&num[i].x,&num[i].y);
	}
	for(i=0;i<shu-1;i++)
	{
		sumlen+=len(num[i].x,num[i+1].x,num[i].y,num[i+1].y);
	}
	sumlen+=len(num[0].x,num[shu-1].x,num[0].y,num[shu-1].y);
	int a,b,temp;
	float slen,sslen;
	do
	{
		scanf("%d %d",&a,&b);
		if(a==0&&b==0)
		{
			break;
		}
		if(a>b)
		{
			temp=a;
			a=b;
			b=temp;
		}
		for(i=a-1;i<b-1;i++)
		{
			slen+=len(num[i].x,num[i+1].x,num[i].y,num[i+1].y);
		}
		sslen=sumlen-slen;
		if(sslen>slen)
		{
			printf("%.2f",slen);
		}
		else
		{
			printf("%.2f",sslen);
		}
	}while(1);
}
float len(int a,int b,int c,int d)
{
	float x1=a-b;
	float x2=c-d;
	x1=pow(x1,2);
	x2=pow(x2,2);
	float l=sqrt(x1+x2);
	return l;
}
