#include <stdio.h>

int main(){
	int a[20],n,i,M=0,m=1000,X,x,D,d;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]>M)M=a[i],X=i;
		if(a[i]<m)m=a[i],x=i;
	}
	
	for(i=m;i>0;i--)if((m%i==0)&&(M%i==0))D=i;
	for(i=M;i<=M*m;i++)if((i%M==0)&&(i%m==0))d=i;
	
	a[X]=d;
	a[x]=D;
	
	for(i=0;i<n;i++)printf("%d ",a[i]);
	return(0);
}
