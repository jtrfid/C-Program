#include<stdio.h>
#include<math.h>
int main()
{int a,f,g,z=1,v,o,q,n,u;
scanf("%d",&a);
int b[a];
for(int i=0;i<a;i++)
{scanf("%d",&b[i]);
}
int c=b[0],d=b[0];
for(int m=0;m<a;m++)
{if(c<b[m]){
c=b[m];
f=m;
}
else
if(d>b[m]){
d=b[m];
g=m;}
}
v=c;
for(int h=1;h<=d;h++)
{o=c%h;
q=d%h;
if((o==0)&&(q==0)){
z=h;
break;
}}
for(int s=c;;s++)
{n=s%c;
u=s%d;
if((n==0)&&(u==0))
{v=s;
break;
}
}
b[f]=v;
b[g]=z;
for(int p=0;p<a;p++)
printf("%d ",b[p]);
return 0;}
