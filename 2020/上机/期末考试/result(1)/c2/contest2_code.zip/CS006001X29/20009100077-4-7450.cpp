#include<stdio.h>
#include<string.h>
int main(){
	int sum1=0,sum2=0,sum3=0;
	int n;
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		if(i%2==0) sum2+=i;
		if(i%2!=0)sum1+=i;
		if(i%5==0&&i%3!=0)sum3+=i;
	}
	int a;
	if(sum1>=sum2){
		a=sum1;
	}else a=sum2;
	if(sum3>a)a=sum3;
	printf("%d %d %d\n",sum1,sum2,sum3);
	printf("%d",a);
	return 0;
}
