#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

/*int main(int argc, char *argv[]) 
{
    int n,i,max,min,gb,gy;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
    	scanf("%d",&a[i]);
    }
    max=min=a[0];
    for(i=0;i<n;i++)
    {
    	if(a[i]>max)max=a[i];
    	if(a[i]<min)min=a[i];
    }
    for(i=max;;i++)
    {
    	if(i%max==0&&i%min==0)
    	{
    		gb=i;
    		break;
    	}
    }
    for(i=min;i>0;i--)
    {
    	if(max%i==0&&min%i==0)
    	{
    		gy=i;
    		break;
    	}
    }
    for(i=0;i<n;i++)
    {
    	if(a[i]==max)a[i]=gb;
    	if(a[i]==min)a[i]=gy;
    }
    for(i=0;i<n;i++)
    {
    	printf("%d ",a[i]);
    }
	return 0;
}*/
int main()
{
	int a,b,m,n,i,j,k,y=0;
	scanf("%d %d",&a,&b);
	int s[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&s[i][j]);
		}
	}
	scanf("%d %d",&m,&n);
	int x[a*m][b*n];
	for(y=0;y<a;y++)
	{
		for(i=y;i<a*m;i=i+a)
	    {
		    for(j=0;j<b*n;j++)
		    {
			    x[i][j]=s[y][j%b];
			    	//printf("%d ",s[y][j%b]);
		    }
	    }
	}
	
	for(i=0;i<a*m;i++)
	{
		for(j=0;j<b*n;j++)
		{
			printf("%d ",x[i][j]);
			if(j==b*n-1)printf("\n");
		}
	}

	return 0;
}
