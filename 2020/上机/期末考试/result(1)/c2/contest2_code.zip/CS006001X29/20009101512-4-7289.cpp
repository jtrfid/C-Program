#include <stdio.h>
int main() {
	int i,x,y,z;
	int m;
	scanf("%d",&m);
	for (i=1,x=0;i<m;i+=2)  x+=i;
	for (i=2,y=0;i<m;i+=2)  y+=i;
	for (i=5,z=0;i<m;i+=5)  if (i%3!=0) z+=i;
	
	i=x>y ? x:y;
	i=i>z ? i:z;
	
	printf("%d %d %d\n%d",x,y,z,i);
	
	
	
	return 0;
}
