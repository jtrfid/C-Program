# include <stdio.h>
 int main(){
 	int a[20],n,i,j,t,k,max=0,min=1000,p,q;
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
 	{
 		scanf("%d ",&a[i]);
 	}
 	for(i=0;i<n;i++)
 	{
 		if(a[i]>max) max=a[i];
 		if(a[i]<min) min=a[i];
 		
 	}
 	while(max%min!=0)
 	{
 		k=max%min;
 		max=min;
 		min=k;
 	}
 	p=min;
 	q=max*min/p;
 	for(i=0;i<n;i++)
	 {
	 	if(a[i]<max&&a[i]>min) printf("%d",a[i]);
	 	else if(a[i]=max) printf("%d",q);
	 	else printf("%d",p);
	 }
 	return 0;
 }
