#include <stdio.h>

int main() {
	int m,t;
	scanf("%d",&m);
	int i,a=0,b=0,c=0,a1,b1,c1;
	for(i=1;i<m;i++)
	{if(i%2!=0)
	{a=a+i;}
	else if(i%2==0)
	{b=b+i;}
	if((i%5==0)&&(i%3!=0))
	{c=c+i;
	}}
	a1=a;
	b1=b;
	c1=c;
	if(a<b)
	{t=a;a=b;b=t;}
	if(a<c)
	{t=a;a=c;c=t;}
	printf("%d %d %d\n%d",a1,b1,c1,a);
	return 0;
}
