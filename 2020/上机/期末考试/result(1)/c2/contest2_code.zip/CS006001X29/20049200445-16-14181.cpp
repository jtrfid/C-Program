#include<stdio.h>
#include<math.h>
int main()
{int a,b,d,e,f,g,l,o;
scanf("%d %d",&a,&b);
int c[a][b];
for(int i=0;i<a;i++)
   for(int j=0;j<b;j++)
   scanf("%d",&c[i][j]);
scanf("%d %d",&d,&e);
f=a*d;
g=b*e;
int v[f][g];
for(int w=0;w<f;w++)
      {for(int y=0;y<g;y++)
        {l=(w+1)%a-1;
        o=(y+1)%b-1;
        v[w][o]=c[l][o];
        }
      }
for( int w=0;w<f;w++)
      {for(int y=0;y<g;y++)
      printf("%d",v[w][o]);}
return 0;}
