#include <bits/stdc++.h>
#define N (100010)
#define INF (2100000000)
#define sqr(x) ((x) * (x))
using namespace std;
inline void judge() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
}
int n, m;
double s[N], sum;
int x, y;

struct point {
	int x, y;
} p[N];
inline double dis(const point &x, const point &y) {
	return sqrt(sqr(x.x - y.x) + sqr(x.y - y.y));
}
int main() {
	//judge();
	
	scanf("%d", &n);
	for (int i = 1, num, x, y; i <= n; ++i) {
		scanf("%d%d%d", &num, &x, &y);
		p[num].x = x;
		p[num].y = y;
	}
	for (int i = 2; i <= n; ++i) {
		s[i] = s[i - 1] + dis(p[i], p[i - 1]);
	}
	sum = s[n] + dis(p[1], p[n]);
	while (1) {
		scanf("%d%d", &x, &y);
		if (x == 0 && y == 0) break;
		double tmp = fabs(s[x] - s[y]);
		printf("%.2lf\n", min(tmp, sum - tmp));
	}
	
	return 0;
}
