#include<stdio.h>
#include<math.h>
int main(){
	int n,d[1000],e[1000],p,q,ans=0,i,max,min,j,t;
    float ju1,jusum;
	scanf("%d",&n);
	int a[n],b[n],c[n];
    for(i=0;i<n;i++){
    	scanf("%d",&a[i]);
    	scanf("%d",&b[i]);
    	scanf("%d",&c[i]);
    }
    t=sqrt((b[0]-b[n-1])*(b[0]-b[n-1])+(c[0]-c[n-1])*(c[0]-c[n-1]));
    for(i=0;i<n;i++){
    	scanf("%d",&d[i]);
    	scanf("%d",&e[i]);
    	ans++;
		if(d[i]==0&&e[i]==0){
    	  break;}
    }
    for(i=0;i<ans-1;i++){
    	jusum=0;
	    ju1=0;
		p=d[i];
    	q=e[i];
    	if(p>q){
    		max=p;
    		min=q;
    	}
    	if(q>p){
    		max=q;
    		min=p;
    	}
    	for(j=max;j!=min;j--){
    		ju1=ju1+sqrt((b[j-1]-b[j-2])*(b[j-1]-b[j-2])+(c[j-1]-c[j-2])*(c[j-1]-c[j-2]));
    	}
    	for(j=0;j<n-1;j++){
    		jusum=jusum+sqrt((b[j]-b[j+1])*(b[j]-b[j+1])+(c[j]-c[j+1])*(c[j]-c[j+1]));
    	}
    	if(i!=ans-2){
		if((jusum+t-ju1)<ju1)
    	{printf("%.2f\n",jusum+t-ju1);
    	}
    	if((jusum+t-ju1)>=ju1)
    	{printf("%.2f\n",ju1);
    	}
    }
    if(i==ans-2){
		if((jusum+t-ju1)<ju1)
    	{printf("%.2f",jusum+t-ju1);
    	}
    	if((jusum+t-ju1)>=ju1)
    	{printf("%.2f",ju1);
    	}
    }
    }
	
	
	
	
	
	return 0;
}
