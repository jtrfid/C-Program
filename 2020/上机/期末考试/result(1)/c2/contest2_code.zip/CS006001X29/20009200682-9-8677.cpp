#include<stdio.h>
int main(){
	int l;
	int max,min;
	scanf("%d",&l);
	int a[l];
	int i;
	for(i=1;i<=l;i++){
		scanf("%d",&a[i]);
	}
	max=min=a[1];
	for(i=1;i<=l;i++){
		max=max>a[i]?max:a[i];
		min=min<a[i]?min:a[i];
	}

	
	int x=1,y=max;
	for(i=1;i<min;i++){
		if(max%i==0&&min%i==0){
			x=x>i?x:i;
		}
	}
	for(i=max;;i++){
		if(i%max==0&&i%min==0){
			y=i;
			break;
		}
	}
for(i=1;i<=l;i++){
		if(max==a[i])a[i]=y;
		if(min==a[i])a[i]=x;
	}
	for(i=1;i<=l;i++)printf("%d ",a[i]);
	return 0;
}
