#include<stdio.h>
int main()
{int a[20],b[20];
 int n,i,j,t,min,max,m,gys,gbs,r,x,y,k;
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 for(i=0;i<n;i++)
 b[i]=a[i];
 for(i=0;i<n;i++)
 for(j=0;j<n-i;j++)
 if(a[j]>a[j+1])
 {t=a[j];
  a[j]=a[j+1];
  a[j+1]=t;
 }
 m=n;
 min=a[0];
 max=a[i-1];
 x=max;
 y=min;
 while((r=x%y)!=0)
 {x=y;
  y=r;
 }
 gys=y;
 gbs=min*max/gys;
 for(j=0;j<n;j++)
 {if(b[j]==min)
  {b[j]=gys;
  }
  else if(b[j]==max)
  b[j]=gbs;
 }
 for(i=0;i<n;i++)
 printf("%d ",b[i]);
 return 0;
}
