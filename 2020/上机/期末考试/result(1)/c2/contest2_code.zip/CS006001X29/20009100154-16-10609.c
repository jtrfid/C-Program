#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int arr[50][50];
	int a,b;
	int m,n;
	scanf("%d %d",&a,&b);
	int i,j,p,q;
	for(i=0;i<a;i++)
	    for(j=0;j<b;j++)
		scanf("%d",&arr[i][j]);
	scanf("%d %d",&m,&n);
	for(p=1;p<=n;p++)
        for(i=0;i<a;i++)
	        for(j=0;j<b;j++)
			arr[i][j+p*(b)]=arr[i][j];
	
	for(q=1;q<=m;q++)
        for(i=0;i<a;i++)
	        for(j=0;j<b*n;j++)
			    arr[i+q*(a)][j]=arr[i][j];	
			    
	for(i=0;i<a*m;i++)
	    for(j=0;j<b*n;j++){
	    
		    printf("%d ",arr[i][j]); 
			if(j==b*n-1)printf("\n");
		}
		
	return 0;
	
}
