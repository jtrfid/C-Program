#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int m,sum1=0,sum2=0,sum3=0;
	scanf("%d",&m);
	int i;
	for(i=1;i<m;i++)
	{
		if(i%2==0)
		{
			sum2=sum2+i;
		}
		else sum1=sum1+i;
		
		if(i%5==0 && i%3!=0)
		{
			sum3=sum3+i;
		}
	}
	int max=0;
	if(sum1>max){
		max=sum1;
	}
	if(sum2>max){
		max=sum2;
	}
	if(sum3>max){
		max=sum3;
	}
	printf("%d %d %d\n",sum1,sum2,sum3);
	printf("%d",max);
	return 0;
}
