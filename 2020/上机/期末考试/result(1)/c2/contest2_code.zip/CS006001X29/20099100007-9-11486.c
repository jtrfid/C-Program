# include <stdio.h>
 int main(){
 	int a[20],n,i,j,t,k,max=0,min=1000,p,q,m,l;
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
 	{
 		scanf("%d",&a[i]);
 	}
 	for(i=0;i<n;i++)
 	{
 		if(a[i]>max) max=a[i];
 		if(a[i]<min) min=a[i];
 		
 	}
 	m=max;l=min;
 	while((max%min)!=0)
 	{
 		k=max/min;
 		max=min;
 		min=k;
		
 	}
 	p=min;
 	printf("%d\n",p);
 	q=m*min/p;
 	for(i=0;i<n;i++)
	 {
	 	
	 	if(a[i]<max&&a[i]>min) printf("%d ",a[i]);
	 	else if(a[i]==m) printf("%d ",q);
		else if(a[i]==l) printf("%d ",p);
	 }
 	return 0;
 }
