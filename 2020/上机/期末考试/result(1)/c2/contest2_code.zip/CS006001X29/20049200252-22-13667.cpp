#include<stdio.h>
#include<math.h>
struct point
{
	int x,y;
}stu[100000];
int main()
{
	int N,i,j,t,tim=0;
	float anse[100000];
	scanf("%d",&N);
	for(i=1;i<=N;i++)
	{
	   scanf("%d",&t);
	   scanf("%d %d",&stu[t].x,&stu[t].y);
    }
	for(i=0;;i++)
	{
		int p1,p2;
		float sum1=0,sum2=0,ans;
		scanf("%d %d",&p1,&p2);
		if(p1==0&&p2==0) break;
		if(p1>p2){t=p1;p1=p2;p2=t;}
		for(j=p1;j<p2;j++)
		{
			sum1+=sqrt(pow(stu[j].x-stu[j+1].x,2)+pow(stu[j].y-stu[j+1].y,2));
		}
		for(j=p2;j<N;j++)
		{
			sum2+=sqrt(pow(stu[j].x-stu[j+1].x,2)+pow(stu[j].y-stu[j+1].y,2));
		}
		for(j=1;j<p1;j++)
		   sum2+=sqrt(pow(stu[j].x-stu[j+1].x,2)+pow(stu[j].y-stu[j+1].y,2));
		sum2+=sqrt(pow(stu[N].x-stu[1].x,2)+pow(stu[N].y-stu[1].y,2));
		ans=sum1<sum2?sum1:sum2;
		anse[i]=ans;
		tim+=1;
	}
	for(i=0;i<tim-1;i++)
	printf("%.2f\n",anse[i]);
	printf("%.2f",anse[i]);
	return 0;
}
