#include<iostream>
using namespace std;
int n;
int arr[21];
int m1=0;
int m2=1001;
int maxn,minn;
int gcd(int x,int y)
{
	if(x%y==0) return y;
	else return gcd(y,x%y);
}
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>arr[i];
		if(arr[i]>m1)
		{
			m1=arr[i];
			maxn=i;
		}
		if(arr[i]<m2)
		{
			m2=arr[i];
			minn=i;
		}
	}
	int b=gcd(m1,m2);
	int a=m1*m2/b;
	arr[minn]=b;
	arr[maxn]=a;
	for(int i=1;i<=n;i++)
	{
		cout<<arr[i]<<" ";
	}
	
	return 0;
}
