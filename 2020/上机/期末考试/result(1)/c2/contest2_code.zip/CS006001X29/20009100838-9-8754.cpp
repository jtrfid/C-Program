#include<stdio.h>
#include<string>
int main()
{
	int n,i,j,min,max,temp,gy,gb,m,p;
	scanf("%d",&n);
	int a[n];
	int b[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(a[j]>a[j+1])
			{
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	
	max=a[n-1];
	min=a[0];
	for(i=0;i<n;i++)
	{
		if(b[i]==max) m=i;
		if(b[i]==min) p=i;
	}
	
	for(j=min;j>=1;j--)
	{
		if(min%j==0&&max%j==0)
		{
			gy=j;
			break;
		}
	}
	for(j=max;;j++)
	{
		if(j%max==0&&j%min==0)
		{
			gb=j;
			break;
		}
	}
	b[m]=gb;
	b[p]=gy;
	for(i=0;i<n;i++)
	{
		printf("%d ",b[i]);
	}
	
	
	
	
	
	return 0;
}
