#include<stdio.h>
int max(int sum1,int sum2,int sum3 )
{
	int max=sum1;
	if(sum2>max)
	 max=sum2;
	if(sum3>max)
	 max=sum3;
	return max;
}
int main ()
{
	int m,sum1=0,sum2=0,sum3=0,i=0,n;
	scanf("%d",&m);
	for(i=1;i<m;i++)
	{
		if(i%2!=0)
		 sum1+=i;
		if(i%2==0)
		 sum2+=i;
		if(i%5==0&&i%3!=0)
		 sum3+=i;
	}
	n=max(sum1,sum2,sum3);
	printf("%d %d %d\n",sum1,sum2,sum3);
	printf("%d",n);
	return 0;
}
