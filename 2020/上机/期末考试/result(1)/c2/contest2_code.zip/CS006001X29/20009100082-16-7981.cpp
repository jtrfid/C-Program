#include<iostream>
using namespace std;
int n,m;
int a,b;
int arr[11][11];
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
    	for(int j=1;j<=m;j++)
    	{
    		cin>>arr[i][j];
    	}
    }
	cin>>a>>b;
	for(int i=1;i<=a;i++)
	{
		for(int k=1;k<=n;k++)
		{
			for(int j=1;j<=b;j++)
			{
				for(int l=1;l<=m;l++)
				{
					cout<<arr[k][l]<<" ";
				}
			}
			cout<<endl;
		}
	}
	return 0;
}
