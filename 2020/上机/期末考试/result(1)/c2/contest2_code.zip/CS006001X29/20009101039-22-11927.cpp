#include<stdio.h>
#include<string.h>
#include<math.h>
struct zuobiao
{
	int bianhao;
	float x;
	float y;
};
int main()
{
    float sum[100]={0.0},sum1[100]={0.0},sum2[100]={0.0};
	int N,flag=1,num1=-1,num2=-1,j=0;
    scanf("%d",&N);
    struct zuobiao dian[N];
    for(int i=0;i<N;i++)
    {
    	scanf("%d %f %f",&dian[i].bianhao,&dian[i].x,&dian[i].y);
    }
    
    for(;;){
    
    	scanf("%d %d",&num1,&num2);
    	if(num1==0&&num2==0)
    	{
    		break;
    	}
		if(num1>num2)
    	{
    		int temp;
    		temp=num1;
    		num1=num2;
    		num2=temp;
    	}
    	for(int i=num1-1;i<num2-1;i++)
    	{
    		sum1[j]=sum1[j]+pow(((dian[i].x-dian[i+1].x)*(dian[i].x-dian[i+1].x)+(dian[i].y-dian[i+1].y)*(dian[i].y-dian[i+1].y)),0.5);
    	}
    	for(int i=num2-1;i<N-1;i++)
    	{
    		sum2[j]=sum2[j]+pow(((dian[i].x-dian[i+1].x)*(dian[i].x-dian[i+1].x)+(dian[i].y-dian[i+1].y)*(dian[i].y-dian[i+1].y)),0.5);
    	}
    	for(int i=0;i<num1-1;i++)
    	{
    		sum2[j]=sum2[j]+pow(((dian[i].x-dian[i+1].x)*(dian[i].x-dian[i+1].x)+(dian[i].y-dian[i+1].y)*(dian[i].y-dian[i+1].y)),0.5);
    	}
    	sum2[j]=sum2[j]+pow(((dian[N-1].x-dian[0].x)*(dian[N-1].x-dian[0].x)+(dian[N-1].y-dian[0].y)*(dian[N-1].y-dian[0].y)),0.5);
    	
		if(sum1[j]>sum2[j])
    	{
    		sum[j]=sum2[j];
    	}
    	else sum[j]=sum1[j];
    
        j++;
        num1=-1,num2=-1;
}
    	for(int i=0;i<=j-1;i++){
		printf("%.2f\n",sum[i]);}
	return 0;
}
