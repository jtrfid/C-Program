#include<stdio.h>
#include<math.h>
#include<string.h>

int main()
{
	int i,y1=0,y2=0,y3=0,n;
	scanf("%d",&n);
	for(i=1;i<n;i+=2)
	{
		y1+=i;
	}
	for(i=2;i<n;i+=2)
	{
		y2+=i;
	}
	for(i=1;i<n;i++)
	{
		if((i%5==0)&&(i%3!=0))
		y3+=i;
	}
	printf("%d %d %d\n",y1,y2,y3);
	int temp;
	if(y2<y3)
	{
		temp=y2;
		y2=y3;
		y3=temp;
	}
	if(y1<y2)
	{
		temp=y1;
		y1=y2;
		y2=temp;
	}
	if(y1<y3)
	{
		temp=y1;
		y1=y3;
		y3=temp;
	}
	printf("%d",y1);
return 0;	
}

