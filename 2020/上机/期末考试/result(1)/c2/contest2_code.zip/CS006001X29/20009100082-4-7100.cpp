#include<iostream>
using namespace std;
int m;
int ans1,ans2,ans3,ans;
int main()
{
	cin>>m;
	for(int i=1;i<m;i++)
	{
		if(i%2==1) ans1+=i;
		if(i%2==0) ans2+=i;
		if(i%5==0&&i%3!=0) ans3+=i;
	}
	ans=max(ans1,max(ans2,ans3));
	cout<<ans1<<" "<<ans2<<" "<<ans3<<endl<<ans;
	
	
	
	
	return 0;
}
