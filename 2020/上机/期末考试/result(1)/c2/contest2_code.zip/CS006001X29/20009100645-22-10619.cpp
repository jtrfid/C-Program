#include<stdio.h>
#include<math.h>
#include<string.h>
struct dian
{
	int num;
	int x;
	int y;
};
int main() 
{
	struct dian point[10];
	int i,j,n,a,b;float d;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d%d%d",&point[i].num,&point[i].x,&point[i].y);
	scanf("%d%d",&a,&b);
	while(a!=0&&b!=0)
	{
		d=sqrt((point[a-1].x-point[b-1].x)*(point[a-1].x-point[b-1].x)+(point[a-1].y-point[b-1].y)*(point[a-1].y-point[b-1].y));
		printf("%.2f\n",d);
		scanf("%d%d",&a,&b);
	}
	
	return 0;
}	
	
	
	
	
	


