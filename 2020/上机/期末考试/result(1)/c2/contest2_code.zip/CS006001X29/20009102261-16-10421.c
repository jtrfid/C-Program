#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int q[100][100],w[100][100];
	int a,b,x,y,i,j,m,n;
	scanf("%d %d",&a,&b);
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		scanf("%d",&q[i][j]);
	}
	scanf("%d %d",&x,&y);
	for(n=0;n<x;n++)
	{
	for(i=0;i<a;i++)
	{
		for(m=0;m<y;m++)
		{
	
		for(j=0;j<b;j++)
		{
			printf("%d ",q[i][j]);
		}
	}
		printf("\n");
	}
}
	
		
		
	return 0;
}
