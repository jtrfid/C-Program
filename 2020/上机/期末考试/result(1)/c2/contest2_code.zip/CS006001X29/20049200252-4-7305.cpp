#include<stdio.h>
int main()
{
	int m,i,a=0,b=0,c=0,max=0;
	scanf("%d",&m);
	if(m==1) printf("0 0 0\n0");
	else
	{
		for(i=1;i<m;i++)
		{
			if(i%2!=0) a+=i;
			else b+=i;
			if(i%5==0&&i%3!=0) c+=i;	
		}
		max=a>b?a:b;
		max=max>c?max:c;
		printf("%d %d %d\n%d",a,b,c,max);
	}
	return 0;
}
