#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;
int n;
struct node
{
	double num,x,y;
} arr[100001];
double dis(node a,node b)
{
	return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
int a,b;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
    	cin>>arr[i].num>>arr[i].x>>arr[i].y;
    }
    while(cin>>a>>b)
    {
    	if(a==0&&b==0) break;
    	double ans1=0.0,ans2=0.0;
    	int m=a;
    	while(a!=b)
    	{
    		int t=a;
    		a++;
    		if(a>n) a=1;
    		ans1+=dis(arr[t],arr[a]);
    	}
    	a=m;
    	while(a!=b)
    	{
    		int t=a;
    		a--;
    		if(a<1) a=n;
    		ans2+=dis(arr[t],arr[a]);
    	}
    	double ans=min(ans1,ans2);
    	cout<<fixed<<setprecision(2)<<ans<<endl;
    }
	return 0;
}
