#include<stdio.h>
int main(){
	int m,n;
	scanf("%d %d",&m,&n);
	int a[m][n];
	int i,j,k,l;
	for(i=1;i<=m;i++){
		for(j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	int x,y;
	int z1=0,z2=0;
	scanf("%d %d",&x,&y);
	//int b[m*x][n*y];
	
	for(k=0;k<x;k++)
	for(i=1;i<=m;i++){
		
		for(l=0;l<y;l++){
		for(j=1;j<=n;j++){
			printf("%d ",a[i][j]);
		}
	}
		printf("\n");
	}

	return 0;
}
