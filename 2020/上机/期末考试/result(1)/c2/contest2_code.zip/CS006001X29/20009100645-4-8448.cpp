#include<stdio.h>
#include<math.h>
#include<string.h>

int main() 
{
	void chuli(int n);
	int n;
	scanf("%d",&n);
	chuli(n);
	return 0;
}
void chuli(int n)
{
	int num[n],i,j,t;int max,min;int flag1,flag2;int bei,yue;
	for(i=0;i<n;i++)
	scanf("%d",&num[i]);
	max=num[0];min=num[0];flag1=0;flag2=0;
	for(i=0;i<n;i++)
	{
	if(num[i]<min){min=num[i];flag1=i;}
	if(num[i]>max){max=num[i];flag2=i;}
	}
	for(i=max;i<=max*min;i++)
	if(i%max==0&&i%min==0){bei=i;break;}
	for(i=min;i>0;i--)
	if(min%i==0&&max%i==0){yue=i;break;}
	num[flag2]=bei;num[flag1]=yue;
	for(i=0;i<n;i++)
	printf("%d ",num[i]);
}









