#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[100];
	int i,da,xiao;
	int max=0,min=1000;
	for(i=0;i<n;i++)
	{
	scanf("%d",&a[i]);
    if(a[i]>max)
    {
    max=a[i];
    da=i;
    }
    if(a[i]<min)
    {
    	min=a[i];
    	xiao=i;
    }
	}
	int yue,bei;
	for(i=1;i<=min;i++)
	{
		if(min%i==0&&max%i==0)
		{
			yue=i;
		}
	}
	bei=max*min/yue;
	a[da]=bei;
	a[xiao]=yue;
	for(i=0;i<n;i++)
	printf("%d ",a[i]);
	return 0;
}
