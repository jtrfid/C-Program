#include<stdio.h>
int main()
{
	int i,t,n,m,s1=0,s2=0,s3=0;
	scanf("%d",&m);
	for(i=1;i<m;i++)
	{
		if(i%2==1)s1+=i;
		else s2+=i;
		if(i%5==0&&i%3!=0)s3+=i;
	}
	n=(s1>s2)?s1:s2;
	t=(n>s3)?n:s3;
	printf("%d %d %d\n",s1,s2,s3);
	printf("%d",t);
	return 0;
}
