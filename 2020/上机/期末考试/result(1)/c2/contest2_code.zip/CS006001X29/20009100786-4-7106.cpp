#include <bits/stdc++.h>
#define N (100010)
using namespace std;
inline void judge() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
}
int n, a, b, c;
int main() {
	//judge();
	
	
	scanf("%d", &n);
	for (int i = 1; i < n; ++i) {
		if (i & 1) a += i; else b += i;
		if (i % 5 == 0 && i % 3 != 0) c += i;
	}
	printf("%d %d %d\n%d", a, b, c, max(a, max(b, c)));
	return 0;
}
