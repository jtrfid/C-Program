#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int a[n];
	int i,j,t;
	for(i=0;i<n;i++)scanf("%d",&a[i]);
	int max=a[0],min=a[0];
	int c,d;
	for(i=0;i<n;i++){
		if(a[i]>max){
		max=a[i];c=i;}
		else if(a[i]<min){
		min=a[i];d=i;}
	}
	int m,k,r,q;
	k=min;m=max;
	q=m*k;
	while(k){
		r=m%k;
		m=k;
		k=r;
		
	}
	a[c]=q/m;a[d]=m;
	for(i=0;i<n;i++)printf("%d ",a[i]);
	return 0;
	
	
}
