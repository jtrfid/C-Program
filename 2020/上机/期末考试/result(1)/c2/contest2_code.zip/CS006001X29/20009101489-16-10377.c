#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,i,j,k,x;
	scanf("%d %d",&a,&b);
	int a1[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&a1[i][j]);
		}
	}
		int m,n;
		scanf("%d %d",&m,&n);
	for(i=1;i<=m;i++)
	{
		for(j=0;j<a;j++)
		{
			for(k=1;k<=n;k++)
			{
				for(x=0;x<b;x++)
				{
					printf("%d ",a1[j][x]);
				}
			}
			printf("\n");
		}
	}
		
	return 0;
}
