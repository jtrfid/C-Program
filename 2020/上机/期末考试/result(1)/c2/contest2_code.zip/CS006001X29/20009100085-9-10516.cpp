#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	scanf("%d",&a[i]);
	
	int weizhi1,weizhi2;
	int max=a[0],min=a[0];
	for(int i=0;i<n;i++)
	{
		if(max<a[i])
		{
			max=a[i];
			weizhi1=i;
		}
		else
		if(min>a[i])
		{
			min=a[i];
			weizhi2=i;
		}
	}
	int z;
	for(int i=min;i>0;i--)
	{
		if(max%i==0&&min%i==0)
		{
		z=i;	break;
		}
	}
	int max1,min1;
	min1=z;
	max1=max*min/z;
	a[weizhi1]=max1;
	a[weizhi2]=min1;
	for(int i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
