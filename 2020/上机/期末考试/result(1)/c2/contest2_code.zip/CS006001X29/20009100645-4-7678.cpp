#include<stdio.h>
#include<math.h>
#include<string.h>
int main() 
{
	int m,jishu=0,oushu=0,zhengchu=0;
	scanf("%d",&m);
	int i;
	for(i=1;i<m;i=i+2)
	jishu=jishu+i;
	for(i=2;i<m;i=i+2)
	oushu=oushu+i;
	for(i=5;i<m;i=i+5)
	if(i%3!=0)zhengchu=zhengchu+i;
	printf("%d %d %d",jishu,oushu,zhengchu);
	if(jishu>oushu&&jishu>zhengchu)	printf("\n%d",jishu);
	if(oushu>jishu&&oushu>zhengchu) printf("\n%d",oushu);
	if(zhengchu>jishu&&zhengchu>oushu) printf("\n%d",zhengchu);
	return 0;
}
