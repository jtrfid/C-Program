#include<stdio.h>
int main()
{int a,b,i,j,m,n,line,roll,time1,time2,c[10][10];
 scanf("%d %d",&a,&b);
 for(i=0;i<a;i++)
 for(j=0;j<b;j++)
 scanf("%d",&c[i][j]);
 scanf("%d %d",&m,&n);
 for(time1=1;time1<=m;time1++)
 for(line=0;line<=a-1;line++)
 {for(time2=1;time2<=n;time2++)
  for(roll=0;roll<=b-1;roll++)
  printf("%d ",c[line][roll]);
  printf("\n");
 }
}

