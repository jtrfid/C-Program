#include<stdio.h>
#include<math.h>
int main()
{int a,b=0,c=0,d=0,e,f,g,h;
scanf("%d",&a);
for(int i=1;i<a;i++)
{e=i%2;
if(e==0)
    c=c+i;
    else
    b=c+i;
}
for(int m=1;m<a;m++)
{f=m%5;
g=m%3;
if((f==0)&&(g!=0))
d=d+m;
}
printf("%d %d %d\n",b,c,d);
if(b>c){
h=b;
b=c;
c=h;}
if(d>c)
printf("%d",d);
else
printf("%d",c);
return 0;
}
