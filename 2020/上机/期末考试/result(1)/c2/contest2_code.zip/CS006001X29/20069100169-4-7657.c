#include<stdio.h>
int main(){
	int n,ans1=0,i,ans2=0,ans3=0;
	scanf("%d",&n);
	if(n==1){
	    printf("0 0 0");
		printf("\n");
		printf("0");	
	}
	if(n>=2){
	   for(i=1;i<n;i++){
	   	if(i%2==1){
	   		ans1=ans1+i;
	   	}
	   	if(i%2==0){
	   		ans2=ans2+i;
	   	}
	   	if(i%5==0&&i%3!=0){
	   		ans3=ans3+i;
	   	}
	   }
	   printf("%d %d %d",ans1,ans2,ans3);
	   printf("\n");
	   if(ans1>=ans2){
	   	 if(ans2>=ans3)
	   	 {printf("%d",ans1);
	   	 }
	   	 if(ans3>ans1)
	   	 {printf("%d",ans3);
	   	 }
	   }
	   if(ans1<ans2){
	   	 if(ans2>=ans3)
	   	 {printf("%d",ans2);
	   	 }
	   	 if(ans3>ans2)
	   	 {printf("%d",ans3);
	   	 }
	   }
}
	return 0;
}
