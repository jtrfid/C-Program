#include <bits/stdc++.h>
#define N (100)
#define INF (2100000000)
using namespace std;
inline void judge() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
}
int n, m;
int a[N][N];
int x, y;
int main() {
	//judge();
	
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) 
		for (int j = 1; j <= m; ++j) scanf("%d", &a[i][j]);
	scanf("%d%d", &x, &y);
	for (int k = 1; k <= x; ++k) {
		for (int i = 1; i <= n; ++i) {
			for (int p = 1; p <= y; ++p)
				for (int j = 1; j <= m; ++j) printf("%d ", a[i][j]);
			printf("\n");
		}
	}
	return 0;
}
