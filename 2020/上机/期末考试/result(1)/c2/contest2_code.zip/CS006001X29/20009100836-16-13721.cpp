#include<stdio.h>
#include<math.h>
#include<string.h>

int main()
{
	int i,j,a,b;
	long int x[50][50];
	scanf("%d%d",&a,&b);
	
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%ld",&x[i][j]);
		}
	}
	
	int z,m,n,q;
	scanf("%d%d",&m,&n);
	



	for(i=0;i<m;i++)//mei lie zhixing
	{
		for(j=b;j<n*b;j+=b)//yi hang fuzhi
		{
			for(q=0;q<b;q++)
			{
				x[i][j+q]=x[i][q];
			}
		}
	}
	for(z=0;z<m;z++)
	{
		for(i=0;i<a;i++)
		{
			for(j=0;j<n*b;j++)
			{
				printf("%ld ",x[i][j]);
			}
			printf("\n");
		}
	}


return 0;	
}

