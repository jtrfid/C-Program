#include<stdio.h>
#include<math.h>
#include<string.h>
struct dian
{
	int num;
	int x;
	int y;
}point[10];
int main() 
{
	float juli(int a,int b,int c,int d);
	int i,j,n,a,t,b;float d=0,mm;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d%d%d",&point[i].num,&point[i].x,&point[i].y);
	scanf("%d%d",&a,&b);
	while(a!=0&&b!=0)
	{
		if(a>b){t=a;a=b;b=t;}
		if(a-b==(-1))
			{
				mm=(point[a-1].x-point[b-1].x)*(point[a-1].x-point[b-1].x)+(point[a-1].y-point[b-1].y)*(point[a-1].y-point[b-1].y);
				d=sqrt(mm);
			}
		else if(a-b==(-2))
		{
			if(a<=n/2)
			{
				
				for(i=0;i<=a-1;i++)
				d=d+juli(point[i].x,point[a-1].x,point[i].y,point[a-1].y);
				for(i=b;i<n;i++)
				d=d+juli(point[i-1].x,point[n-1].x,point[i-1].y,point[n-1].y);
				d=d+juli(point[n-1].x,point[0].x,point[n-1].y,point[0].y);
			}
			else
			{
				for(i=a;i<=b;i++)
				{
					d=d+juli(point[i-1].x,point[b-1].x,point[i-1].y,point[b-1].y);
				}
			}
		}
		if(b==n)
		{
			d=juli(point[n-1].x,point[0].x,point[n-1].y,point[0].y);
			for(i=0;i<=a-1;i++)
				d=d+juli(point[i].x,point[a-1].x,point[i].y,point[a-1].y);
		}
		
		printf("%.2f\n",d);
		scanf("%d%d",&a,&b);
	}
	
	return 0;
}	
float juli(int a,int b,int c,int d)
{
	float dd,mm;
	mm=(a-b)*(a-b)+(c-d)*(c-d);
		dd=sqrt(mm);
	return dd;
}
	
	
