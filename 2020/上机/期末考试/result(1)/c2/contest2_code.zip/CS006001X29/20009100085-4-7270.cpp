#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int ji=0,ou=0,wan=0;
	for(int i=1;i<n;i++)
	{
		if(i%2==0)
		{
			ou+=i;
		}
		else 
		{
			ji+=i;
		}
		
		if(i%5==0&&i%3!=0)
		{
			wan+=i;
		}
	}
	int max;
	max=(ji>ou)?ji:ou;
	max=(max>wan)?max:wan;
	printf("%d %d %d\n%d",ji,ou,wan,max);
	
}
