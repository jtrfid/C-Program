#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,i,j,min,max,x,y;
	scanf("%d",&n);
	int a[100],b[100],c[100];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
		min=a[0];
		max=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
	{
	max=a[i];
	x=i;
	}
		
	}
		for(i=0;i<n;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			y=i;
		}
		
	}
	
	for(i=0;i<=min;i++)
	{
		if(max%i==0 && min%i==0)
		a[y]=i;
	}
	for(i=max;i<10000;i++)
	{
		if(i%max==0 && i%min==0)
		{a[x]=i;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
	return 0;
}
