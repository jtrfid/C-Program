#include<stdio.h>
int main()
{ int n,t,m,i,x,y,p,j,k;
  int a[1000];
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {scanf("%d",&a[i]);
  }
  m=a[0];
  t=a[0];
  for(i=0;i<n-1;i++)
  {if(a[i+1]>a[i])
    m=a[i+1];
  }
  j=m;
  for(i=0;i<n-1;i++)
  {if(a[i+1]<a[i])
    t=a[i+1];
  }
  k=t;
  p=m*t;
  x=m%t;
  while(x!=0)
  {x=m%t;
   m=t;
   t=x;
  }
  y=p/t;
  printf("%d",y);
  /*for(i=0;i<n;i++)
  {if(a[i]==j)
   a[i]=y;
  }
  for(i=0;i<n;i++)
  {if(a[i]==k)
   [i]=t;
  }
  for(i=0;i<n;i++)
  printf("%d",a[i]);*/
  return 0;
}
