#include<stdio.h>
int main ()
{
	int a,b,p,c[100],k;
	scanf("%d%d",&a,&b);
	p=a*b;
	int i=0;
	for(i=1;i<=p;i++)
	 scanf("%d",&c[i]);
	int m,n;
	scanf("%d%d",&m,&n);
	for(k=0;k<n;k++)
	{
		int j;
		for(j=0;j<m;j++)
	    {
	    	for(i=1;i<=b;i++)
	    	 printf("%d ",c[i]);
	    }
	    	printf("\n");
	    for(j=0;j<m;j++)
	    {
	    	for(i=b+1;i<=p;i++)
	    	 printf("%d ",c[i]);
	    }
		printf("\n");
	}
	return 0;
}
