#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,max,min,q,w,i,j,yin,bei;
	scanf("%d",&n);
	int a[100];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	max=0;
	min=1001;
	for(i=0;i<n;i++)
	{
		if(max<a[i])
		{
			max=a[i];
			q=i;
		}
		if(min>a[i])
		{
			min=a[i];
			w=i;
		}
	}
	for(j=1;j<=min;j++)
	{
		if(max%j==0 && min%j==0)
		yin=j;
	}
	for(j=100000;j>=max;j--)
	{
		if(j%max==0 && j%min==0)
		{
			bei=j;
		}
	}
    a[w]=yin;
    a[q]=bei;
    for(i=0;i<n;i++)
    printf("%d ",a[i]);
	return 0;
}
