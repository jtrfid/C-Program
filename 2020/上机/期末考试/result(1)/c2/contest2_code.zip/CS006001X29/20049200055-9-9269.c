#include<stdio.h>
int main(void)
{
	int n,i,j,p,q,px,qx,zd,zx;
	scanf("%d",&n);
	int a[n+1];
	for (i=1;i<=n;i++) scanf("%d",&a[i]);
    px=a[1];qx=a[1];p=1;q=1;
    for (i=1;i<=n;i++)
    {
    	if(a[i]<px) {px=a[i];p=i;}
    	if(a[i]>qx) {qx=a[i];q=i;}
    }
    for (i=px;i>=1;i--)
    {
    	if(px%i==0&&qx%i==0)
		{
    	    zd=i;break;	
    	}
    }
    zx=px*qx/zd;
    a[p]=zd;a[q]=zx;
    for (i=1;i<=n;i++) printf("%d ",a[i]);
    return 0;
}
