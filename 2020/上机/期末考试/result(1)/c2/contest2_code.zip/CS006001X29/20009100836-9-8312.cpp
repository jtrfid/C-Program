#include<stdio.h>
#include<math.h>
#include<string.h>

int main()
{
	int max=0,maxi,mini,min=10000000,n,i,a[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]>max)
		{
			max=a[i];
			maxi=i;
		}
		if(a[i]<min)
		{
			min=a[i];
			mini=i;
		}
	}
	i=min;
	int yue,bei;
	while(i>0)
	{
		
		if(min%i==0&&max%i==0)
		{
			yue=i;
			break;
		}
		i--;
	}
	bei=max*min/yue;
	a[maxi]=bei;a[mini]=yue;
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
return 0;	
}

