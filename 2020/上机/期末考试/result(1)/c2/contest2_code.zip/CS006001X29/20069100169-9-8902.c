#include<stdio.h>
int main(){
	int n,i,j,temp,p,q,yuanmax,yuanmin;
    scanf("%d",&n);
    int a[n],b[n];
    for(i=0;i<n;i++){
    	scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
    	b[i]=a[i];
	}
    for(i=0;i<n;i++){
    	for(j=0;j<n-1;j++){
    		if(b[j]>b[j+1]){
    			temp=b[j];
    			b[j]=b[j+1];
    			b[j+1]=temp;
    		}
    	}
    }
    p=b[0];
    q=b[n-1];
	yuanmin=p;
	yuanmax=q;
	do{
		if(p>q){
			p=p-q;
		}
		if(q>p){
			q=q-p;
		}
	}
    while(p!=q);
	for(i=0;i<n;i++){
		if(a[i]==yuanmax){
			a[i]=(yuanmax*yuanmin)/p;
		}
		if(a[i]==yuanmin){
			a[i]=p;
		}
	}
	for(i=0;i<n;i++){
    	printf("%d ",a[i]);
    }
	
	
	return 0;
}
