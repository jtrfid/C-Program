#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	int a[100][100];
	int i,j;
	int k=0,l=0;
	for(i=0;i<m;i++)
	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);
	
	int x,y;
	scanf("%d%d",&x,&y);
	int b[100][100];
	for(i=0;i<(x*m);i++)
    {		
	for(j=0;j<(y*n);j++)
	{
		b[i][j]=a[k][l];
		l++;
		if(l%n==0)
		{
		l=0;
	    }
	}
	k++;
	if(		k%m==0)
    {
		k=0;
	}
	}
	for(i=0;i<(x*m);i++)
	{
	for(j=0;j<(y*n);j++)
	{
	printf("%d ",b[i][j]);
    }
    printf("\n");
	}return 0;
}
