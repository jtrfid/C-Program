#include <stdio.h>

int main()
{
	int n;
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int max=a[0],min=a[0],p1=0,p2=0;
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			p1=i;
		}
		if(a[i]<min)
		{
			min=a[i];
			p2=i;
		}
	}
	int yue,bei;
	for(i=min;i>0;i--)
	{
		if(min%i==0&&max%i==0)
		{
			yue=i;
			break;
		}
	}
	a[p2]=yue;
	for(i=max;;i++)
	{
		if(i%min==0&&i%max==0)
		{
			bei=i;
			break;
		}
	}
	a[p1]=bei;
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}

}
