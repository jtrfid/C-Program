#include <stdio.h>

int main()
{
	int m,sum_1=0,sum_2=0,sum_3=0;
	scanf("%d",&m);
	int i;
	for(i=0;i<m;i++)
	{
		if(i%2==1)
		{
			sum_1+=i;
		}
	}
	for(i=0;i<m;i++)
	{
		if(i%2==0)
		{
			sum_2+=i;
		}
	}
	for(i=0;i<m;i++)
	{
		if(i%5==0&&i%3!=0)
		{
			sum_3+=i;
		}
	}
	int max=sum_1;
	if(max<sum_2) max=sum_2;
	if(max<sum_3) max=sum_3;
	printf("%d %d %d\n%d",sum_1,sum_2,sum_3,max);
}
