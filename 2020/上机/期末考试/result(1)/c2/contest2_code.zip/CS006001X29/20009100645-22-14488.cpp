#include<stdio.h>
#include<math.h>
#include<string.h>
struct dian
{
	int num;
	int x;
	int y;
}point[10];
int main() 
{
	float juli(int a,int b,int c,int d);
	int i,j,n,a,t,b;float d1=0,d2=0,d,mm;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d%d%d",&point[i].num,&point[i].x,&point[i].y);
	scanf("%d%d",&a,&b);
	while(a!=0&&b!=0)
	{
	d=juli(point[a-1].x,point[b-1].x,point[a-1].y,point[b-1].y);
		printf("%.2f\n",d);
		scanf("%d%d",&a,&b);
	}
	
	return 0;
}	
float juli(int a,int b,int c,int d)
{
	float dd,mm;
	mm=(a-b)*(a-b)+(c-d)*(c-d);
		dd=sqrt(mm);
	return dd;
}
	
