#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}

	int max=a[0],min=a[0];
	for(i=0;i<n;i++)
	{
		if(max<=a[i])
		{
			max=a[i];
	
		}
		if(min>=a[i])
		{
			min=a[i];
		
		}
	}
	if(min!=0)
	{
	
	for(i=min;i>0;i--)
	{
		if(max%i==0&&min%i==0)
		{
			break;
		}
		
	}
	int max1,min1;
	min1=i; 
	for(int k=max;;k++)
	{
		if(k%max==0&&k%min==0)
		{
		max1=k;	break;
		}
	}
	
	for(i=0;i<n;i++)
	{
		if(a[i]==max)
		{
			a[i]=max1;
		}
		if(a[i]==min)
		{
			a[i]=min1;
		}
	}
	}
	else 
	{
	for(i=0;i<n;i++)
	{
		if(a[i]==max)
		{
			a[i]=0;
		}
		if(a[i]==min)
		{
			a[i]=0;
		}
	}

	}
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
}
