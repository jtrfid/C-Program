#include <stdio.h>

int main(){
	int n,a[20],i,j,x,y,t,M,m;
	scanf("%d",&n);
	for(i=0;i<n;i++)scanf("%d",&a[i]);
	for(i=0;i<n;i++){
		t=0;
		for(j=0;j<n;j++){
			if(a[i]<a[j])break;
			else t+=1;
		}
		if(t==n){
			x=i;
			break;
		}
	}
	for(i=0;i<n;i++){
		t=0;
		for(j=0;j<n;j++){
			if(a[i]>a[j])break;
			else t+=1;
		}
		if(t==n){
			y=i;
			break;
		}
	}
	
	for(i=a[y];i>0;i--){
		if((a[y]%i==0)&&(a[x]%i==0))M=i;
	}
	for(i=a[x];i<=a[x]*a[y];i++){
		if((i%a[y]==0)&&(i%a[x]==0))m=i;
	}
	
	a[x]=m;
	a[y]=M;
	
	for(i=0;i<n;i++)printf("%d ",a[i]);
	return(0);
}
