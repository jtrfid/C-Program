#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int m,n;
	scanf("%d %d",&m,&n);
	int i,j;
	int a[100][100],b[100][100];
	for(i=0;i<m;i++)
	{	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);
	b[i][j]=a[i][j];
	}
	int p,q;
	scanf("%d %d",&p,&q);
	for(i=0;i<m*p;i++)
	{for(j=0;j<n*q;j++)
	b[i][j]=a[i%m][j%n];
	}
	for(i=0;i<m*p;i++)
	{
	{for(j=0;j<n*q;j++)
	printf("%d ",b[i][j]);}	
	printf("\n");
	}
	return 0;
}
