# include <stdio.h>
int main(){
	int c[100][100],a,b,m,n,i,j,k,t;
	scanf("%d %d",&a,&b);
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&c[i][j]);
		}
	}
	scanf("%d %d",&m,&n);
	for(k=0;k<m;k++)
	{
		for(i=0;i<a;i++)
		{
			for(t=0;t<n;t++)
			{
				for(j=0;j<b;j++)
				{
					printf("%d ",c[i][j]);
				}
				
			}printf("\n");
		}
	}
}
