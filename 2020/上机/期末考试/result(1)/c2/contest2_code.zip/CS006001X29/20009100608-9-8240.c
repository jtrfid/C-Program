#include<stdio.h>
#include<string.h>
int main()
{
	int i;
	scanf("%d",i);
	int a[i];
	int n;
	for(n=0;n<i;n++)
	{
		scanf("%d",&a[n]);
	}
	int j,t,w,k,z;
	int max,min;
	max=a[0];
	min=a[0];
	for(n=0;n<i;n++){
		if(a[i]>max){
			max=a[i];
			j=i;
		}
		if(a[i]<min){
			min=a[i];
			t=i;
		}
		}
	while(min!=0){
		w=max-min;
		max=min;
		min=w;
	}
	k=max*min;
	z=k/w;
	a[j]=z;
	a[t]=w;
	for(n=0;n<i;n++){
		printf("%d",a[n]);
	}
}
