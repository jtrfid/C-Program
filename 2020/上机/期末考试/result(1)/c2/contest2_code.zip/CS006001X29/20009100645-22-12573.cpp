#include<stdio.h>
#include<math.h>
#include<string.h>
struct dian
{
	int num;
	int x;
	int y;
}point[10];
int main() 
{
	float juli(int a,int b,int c,int d);
	int i,j,n,a,t,b;float d1=0,d2=0,d,mm;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d%d%d",&point[i].num,&point[i].x,&point[i].y);
	scanf("%d%d",&a,&b);
	while(a!=0&&b!=0)
	{
		if(a>b){t=a;a=b;b=t;}
		for(i=a;i<=b;i++)
		{
			d1=d1+juli(point[i-1].x,point[b-1].x,point[i-1].y,point[b-1].y);
		}
		for(i=1;i<=a;i++)
		{
			d2=d2+juli(point[i=1].x,point[a-1].x,point[i=1].y,point[a-1].y);
		}
		for(i=b;i<n;i++)
		{
			d2=d2+juli(point[i-1].x,point[n-1].x,point[i=1].y,point[n-1].y);
		}
		d2=d2+juli(point[0].x,point[n-1].x,point[0].y,point[n-1].y);
		
		if(d1<d2)d=d1;
		else d=d2;
	
		printf("%.2f\n",d);
		scanf("%d%d",&a,&b);
	}
	
	return 0;
}	
float juli(int a,int b,int c,int d)
{
	float dd,mm;
	mm=(a-b)*(a-b)+(c-d)*(c-d);
		dd=sqrt(mm);
	return dd;
}
	
	
	
	
	
	
	
	
	
