#include<stdio.h>
int main()
{
	int c[10][10],d[50][50];
	int a,b,m,n,i,j,k;
	scanf("%d %d",&a,&b);
	for(i=0;i<a;i++)
	  for(j=0;j<b;j++)
	  scanf("%d",&c[i][j]);
	scanf("%d %d",&m,&n);
	for(k=0;k<m;k++)
	{
		for(i=0;i<a;i++)
		  for(j=0;j<b;j++)
		  d[k*a+i][j]=c[i][j];
		 // printf("%d %d\n",k,d[k*a][0]);
	}
	for(k=0;k<n;k++)
	{
		for(i=0;i<a*m;i++)
		  for(j=0;j<b;j++)
		  d[i][k*b+j]=d[i][j];
	}
	for(i=0;i<a*m;i++)
	{
		for(j=0;j<n*b-1;j++)
		printf("%d ",d[i][j]);
		printf("%d",d[i][j]);
		if(i<a*m-1) printf("\n");
	}
	return 0;
}
