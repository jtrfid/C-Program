#include<stdio.h>
int main()
{
	int n,i,j=0,k=0,l,r,t,s,a[20];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	  scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		if(a[j]<a[i])j=i;
		if(a[k]>a[i])k=i;
	}
	l=a[j];
	r=a[k];
	for(i=1;i<=a[k];i++)
	  if(a[k]%i==0&&a[j]%i==0)t=i;
	a[k]=t;
	for(i=l;i<=l*r;i++)
	  if(i%l==0&&i%r==0)s=i;
	a[j]=s;
	for(i=0;i<n;i++)
	  printf("%d ",a[i]);	
	return 0;
}
