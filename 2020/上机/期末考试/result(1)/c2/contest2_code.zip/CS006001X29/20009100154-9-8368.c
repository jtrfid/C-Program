#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,i,j,k;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	    scanf("%d",&a[i]);
	int max=0,min=1001;
	for(i=0;i<n;i++)
	{
		if(max<a[i]){max = a[i];j=i;}
		if(min>a[i]){min = a[i];k=i;}
	}
	int gongyue,gongbei;
	for(i=max;;i++){
		if(i%max==0&&i%min==0){
			gongbei = i;
			break;
		}
	} 
	for(i=max;i>0;i--){
		if(max%i==0&&min%i==0){
			gongyue = i;
			break;
		}
	}
	
	a[j]=gongbei;a[k]=gongyue;
	for(i=0;i<n;i++)
	    printf("%d ",a[i]);  
	return 0;
}
