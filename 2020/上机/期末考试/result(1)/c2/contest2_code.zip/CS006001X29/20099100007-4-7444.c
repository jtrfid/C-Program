# include <stdio.h>
# include <string.h>

int main(){
	int n,i,j,t,s=0,p=0,max,q=0;
	scanf("%d",&n);
	for(i=0;i<n;i=i+2)
	{
		s+=i;
	}
	for(i=1;i<n;i=i+2)
	{
		p+=i;
	}
	for(i=0;i<n;i++)
	{
		if(i%5==0&&i%3!=0) q+=i;
	}
	if(s>p) max=s;
	else max=p;
	if(p>max) max=p;
	printf("%d %d %d\n%d",p,s,q,max);
	return 0;
} 
