#include <stdio.h>
#include <math.h>

struct dot{
	int num;
	double x;
	double y;
};


int main(){
	int N,i,j,m,n,t;
	scanf("%d",&N);
	double s[10000],s1,s2,S[10000];
	dot a[10000],x,y;
	for(i=0;i<N;i++)scanf("%d %lf %lf",&a[i].num,&a[i].x,&a[i].y);
	
	for(i=0;i<N-1;i++)s[i]=sqrt(pow(a[i+1].x-a[i].x,2)+pow(a[i+1].y-a[i].y,2));
	s[N-1]=sqrt(pow(a[N-1].x-a[0].x,2)+pow(a[N-1].y-a[0].y,2));
	
	for(j=0;j<1000000;j++){
		scanf("%d %d",&m,&n);
		if(m==0&&n==0)break;
		s1=0,s2=0;
		if(m>n)t=m,m=n,n=t;
		for(i=m;i<n;i++)s1+=s[i];
		for(i=0;i<m;i++)s2+=s[i];
		for(i=n;i<N;i++)s2+=s[i];
		
		if(s1>s2)S[j]=s2;
		else S[j]=s1;
	}
	
	for(i=0;i<j;i++)printf("%.2f\n",S[i]);
	return(0);
}
