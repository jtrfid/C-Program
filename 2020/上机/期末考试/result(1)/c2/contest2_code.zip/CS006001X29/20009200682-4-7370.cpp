#include<stdio.h>
int main(){
	int m;
	int p1,p2,p3;
	p1=p2=p3=0;
	scanf("%d",&m);
	int i;
	for(i=1;i<m;i++)
	{
		if(i%2==0)p2+=i;
		else p1+=i;
		if(i%5==0&&i%3!=0)p3+=i;
	}
	int max=p1;
	int max1=p2;
	max1=max1>p3?max1:p3;
	max=max>max1?max:max1;
	printf("%d %d %d\n%d",p1,p2,p3,max);
	return 0;
}
