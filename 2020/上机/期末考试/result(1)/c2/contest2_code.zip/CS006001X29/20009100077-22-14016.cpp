#include <stdio.h>
#include<math.h>
	struct dot{
		int num;
		int x;
		int y;
	};
int d( dot a[n], dot a[m]){
	if(a[n].x==a[m].x){
		if(a[n].y>=a[m].y)return a[n].y-a[m].y;
	
	else return a[m].y-a[n].y;
}
else return d(struct dot a[n],struct dot a[m-1])+d(struct dot a[ int m-1],struct dot a[int m]);
}
int main(){
	struct dot{
		int num;
		int x;
		int y;
	};
	struct dot p[100000];
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		p[i].num=i;
		scanf("%d %d",&p[i].x,&p[i].y);
	}
	int a,b,num=0;
	float chj[10000];
	while(a!=0&&b!=0){
		scanf("%d %d",&a,&b);
		chj[num]=sqrt((p[a].x-p[b].x)*(p[a].x-p[b].x)+(p[a].y-p[b].y)*(p[a].y-p[b].y));
		num++;
	}
	for(int i=0;i<=num-1;i++)printf("%.2f",chj[i]);
	return 0;
}
