#include<stdio.h>

int main()
{int a,b,c,d,e,f,g,h,s,l;
scanf("%d %d",&a,&b);
int m[a][b];
for(c=0;c<a;c++)
{for(d=0;d<b;d++)
{scanf("%d ",&m[c][d]);
}
}

scanf("%d %d",&e,&f);
g=e*a;
h=f*b;
int n[g][h];
for(c=0;c<e;c++)
{for(d=0;d<f;d++)
{for(p=0;p<a;p++)
{for(q=0;q<b;q++)
{s=c*a+p;
l=d*b+q;
n[s][l]=m[p][q];
}
}
}
}

for(c=0;c<g;c++)
{for(d=0;d<h;d++)
{printf("%d ",n[c][d]);
}
printf("\n");
}

return 0;
}
