#include <bits/stdc++.h>
#define N (1010)
#define INF (2100000000)
using namespace std;
inline void judge() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
}
int n, Max, Min;
int a[N];
int x, y;
int main() {
	//judge();
	
	//printf("%d %d", __gcd(1, 7), __gcd(3, 7));
	scanf("%d", &n);
	Min = INF;
	for (int i = 1; i <= n; ++i) scanf("%d", &a[i]);
	for (int i = 1; i <= n; ++i) {
		if (a[i] > Max) Max = a[i];
		if (a[i] < Min) Min = a[i];
	}
	x = __gcd(Max, Min); y = Max / x * Min;
	for (int i = 1; i <= n; ++i) {
		if (a[i] == Max) a[i] = y;
		else {
			if (a[i] == Min) a[i] = x;
		}
	}
	printf("%d", a[1]);
	for (int i = 2; i <= n; ++i) printf(" %d", a[i]); 
	return 0;
}
