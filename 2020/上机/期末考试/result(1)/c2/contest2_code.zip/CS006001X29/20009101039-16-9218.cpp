#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int a,b,a1,b1,i,j;
	scanf("%d %d",&a,&b);
	int zu[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&zu[i][j]);
		}
	}
	scanf("%d %d",&b1,&a1);
	int cop[a*a1][b*b1];
	for(i=0;i<a*a1;i++)
	{
		for(j=0;j<b*b1;j++)
		{
			printf("%d ",zu[i%a][j%b]);	
		}
		printf("\n");
	}
	return 0;
}
