#include<stdio.h>
int main(void)
{
	int n,j,o,x,p;
	scanf("%d",&n);
	if (n%2==0)
	{
		j=n*n/4;
		o=n*(n-2)/4;
	}
	else 
	{
		j=(n-1)*(n-1)/4;
		o=(n+1)*(n-1)/4;
	}
	p=(n-1)/5;
	x=(5+5*p)*p/2-(15+15*(p/3))*(p/3)/2;
	printf("%d %d %d\n",j,o,x);
	if(n%2) printf("%d",o);
	else printf("%d",j);
	return 0;
}
