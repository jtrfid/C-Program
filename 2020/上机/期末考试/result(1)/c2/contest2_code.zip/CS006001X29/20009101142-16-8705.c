#include <stdio.h>

int main()
{
	int a,b,m,n,j,i,k;
	scanf("%d %d",&a,&b);
	int ori[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&ori[i][j]);
		}
	}
	scanf("%d %d",&m,&n);
	int copy[a][b*n];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b*n;j++)
		{
			copy[i][j]=ori[i][j%b];
		}
	}
	for(k=0;k<m;k++)
	{
		for(i=0;i<a;i++)
		{
			for(j=0;j<b*n;j++)
			{
				printf("%d ",copy[i][j]);
			}
			printf("\n");
		}
	}
}
