#include<stdio.h>
int main(){
	int a,b,c,d,i,j;
    scanf("%d %d",&a,&b);
    int shuzu[a][b];
    for(i=0;i<a;i++){
    	for(j=0;j<b;j++){
    		scanf("%d",&shuzu[i][j]);
    	}
    }
	scanf("%d %d",&c,&d);
	int zuzu[a*c][b*d];
	for(i=0;i<a*c;i++){
    	for(j=0;j<b*d;j++){
    		zuzu[i][j]=shuzu[i%a][j%b];
    	}
    }
    for(i=0;i<a*c;i++){
    	for(j=0;j<b*d;j++){
    		if(j!=b*d-1){
			printf("%d ",zuzu[i][j]);
		}
		if(j==b*d-1){
			printf("%d\n",zuzu[i][j]);
		}
    	}
    }
	return 0;
}
