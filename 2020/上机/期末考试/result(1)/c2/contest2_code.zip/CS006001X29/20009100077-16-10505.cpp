#include<stdio.h>
int main(){
	int a,b;
	scanf("%d %d",&a,&b);
	int f[10][10]={0};
	for(int i=0;i<=a-1;i++){
		for(int j=0;j<=b-1;j++) scanf("%d",&f[i][j]);
	}
	int m,n;
	scanf("%d %d",&m,&n);
	int f2[20][20]={0};
	for(int k=0;k<=m*a-1;k++){
		for(int y=0;y<=n*b-1;y++){
			int c=k%a,g=y%b;
			f2[k][y]=f[c][g];
		}
	}
	for(int r=0;r<=m*n-1;r++)
	{
		for(int u=0;u<=n*b-1;u++){
			printf("%d ",f2[r][u]);
		}
		printf("\n");
	}
	return 0;
	
}
