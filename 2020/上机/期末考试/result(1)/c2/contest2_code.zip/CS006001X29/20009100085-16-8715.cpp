#include<stdio.h>
int main()
{
	int m,n,i,j;
	scanf("%d%d",&m,&n);
	
	int c[m][n];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&c[i][j]);
		}
	}
	
	int a,b;
	scanf("%d%d",&a,&b);
	
	a=a*m;
	b=b*n;
	
	int d[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			int k,l;
			k=i%m;
			l=j%n;
			d[i][j]=c[k][l];
		}
	}
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			printf("%d ",d[i][j]);
		}
		printf("\n");
	}
}
