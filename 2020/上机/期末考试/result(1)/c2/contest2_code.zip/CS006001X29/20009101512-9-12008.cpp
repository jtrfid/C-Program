#include <stdio.h>

int main() {
	int n,x,y,i,m,p;
    scanf("%d",&n);
	int a[n];
	for (i=0;i<n;i++)  scanf("%d",&a[i]);
	x=a[0];y=a[0];
    for (i=0;i<n;i++)  {x=x>a[i]?x:a[i];if(x==a[i]) m=i;}
	for (i=0;i<n;i++)  {y=y<a[i]?y:a[i];if(y==a[i]) p=i;}
	for (;x-y!=0;)  {x=x-y; if (x<y) {i=x;x=y;y=i;}}
	x=a[m]*a[p]/y;
	a[m]=x;a[p]=y;
	printf("%d",a[0]);
	for (i=1;i<n;i++)  printf(" %d",a[i]);
	return 0;
}
