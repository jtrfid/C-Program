#include<stdio.h>
#include<math.h>
int main()
{int a,b,d,e;
scanf("%d %d",&a,&b);
int c[a][b];
for(int i=0;i<a;i++)
   for(int j=0;j<b;j++)
   scanf("%d",&c[i][j]);
scanf("%d %d",&d,&e);
for(int m=0;m<e;m++){
printf("\n");
for(int h=0;h<d;h++){
for(int k=0;k<a;k++)
   {
   for(int l=0;l<b;l++)
         printf("%d",c[k][b]);}}
}
return 0;}
