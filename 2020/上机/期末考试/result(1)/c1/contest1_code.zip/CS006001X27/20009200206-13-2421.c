#include <stdio.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, j, k;
	int a[10][10] = {0};
	int b[10][10] = {0};
	int c[10][10] = {0};
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n; i++) {//ת��
		for (j = 0; j < m; j++) {
			b[i][j] = a[j][i];
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (k = 0; k <= n - 1; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
}
