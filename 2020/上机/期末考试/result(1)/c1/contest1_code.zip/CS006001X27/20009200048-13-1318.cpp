#include <cstdio>
#include <cstring>
using namespace std;

int main() {
	int m, n;
	int A[12][12], B[12][12], C[12][12];
	memset(A, 0, sizeof(A));
	memset(B, 0, sizeof(B));

	scanf("%d %d", &m, &n);
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &A[i][j]);
			B[j][i] = A[i][j];
		}
	}

	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			int sum = 0;
			for (int k = 0; k < n; k++) {
				sum += A[i][k] * B[k][j];
			}
			C[i][j] = sum;
		}
	}
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			printf("%d", C[i][j]);
			if (j != m - 1)
				printf(" ");
			else
				printf("\n");
		}
	}
	return 0;
}