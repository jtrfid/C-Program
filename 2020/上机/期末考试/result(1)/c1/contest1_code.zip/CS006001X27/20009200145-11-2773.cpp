#include <stdio.h>
int a[1000];
int b[1000][1000];

int main() {
	int n, i, j;
	scanf("%d", &n);
	for (i = 1; i <= n * n; i++) {
		scanf("%d", &a[i]);

	}
	int middle;
	for (i = 1; i <= n * n; i++) {
		for (j = i - 1; j >= 1; j--) {
			if (a[j] > a[j + 1]) {
				middle = a[j];
				a[j] = a[j + 1];
				a[j + 1] = middle;
			}
		}
	}
	for (j = 1; j <= n; j++) {
		for (i = 1; i <= n; i++) {
			b[i][j] = a[n * (j - 1) + i];
		}
	}
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	return 0;













}