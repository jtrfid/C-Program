#include <stdio.h>

int main() {

	int m, n, j, s = 0, t, i;
	int a = 0, b = 0;
	int num[100];
	int con[10][10];
	scanf("%d", &n);
	m = n * n;
	for (i = 0; i < m; i++) {
		scanf("%d", &num[i]);
	}
	for (i = 0; i < m - 1; i++) {
		for (j = 0; j < m - i - 1; j++) {
			if (num[j] > num[j + 1]) {
				t = num[j + 1];
				num[j + 1] = num[j];
				num[j] = t;
			}
		}
	}
	for (i = 0; i < m; i++) {
		con[a][b] = num[i];
		a++;
		if (a == n) {
			b++;
			a = 0;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", con[i][j]);
			if (j == n - 1) {
				printf("\n");
			}
		}
	}

	return 0;
}