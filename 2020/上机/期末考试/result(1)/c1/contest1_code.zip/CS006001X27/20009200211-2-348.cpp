#include <stdio.h>
#include <string.h>

int main() {
	int n, i, j;
	int count[3] = {0};
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			count[0]++;
		}
		if (i % 2 != 0) {
			count[1]++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			count[2]++;
		}
	}
	printf("%d %d %d\n", count[1], count[0], count[2]);
	int max = count[1];
	for (i = 0; i < 3; i++) {
		for (j = i; j < 3; j++) {
			if (count[j] > count[i]) {
				int t = count[i];
				count[i] = count[j];
				count[j] = t;
			}
		}
	}
	printf("%d", count[0]);







	return 0;
}