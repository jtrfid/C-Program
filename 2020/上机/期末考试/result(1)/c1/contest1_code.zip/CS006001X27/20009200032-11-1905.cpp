#include <stdio.h>

int main() {
	int n, b[100], a[10][10] = {0}, i, j, t;
	//
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &b[i]);
	}
	//
	for (i = 0; i < n * n - 1; i++) {
		for (j = 0; j < n * n - i - 1; j++) {
			if (b[j] > b[j + 1]) {
				t = b[j];
				b[j] = b[j + 1];
				b[j + 1] = t;
			}
		}
	}//
	int cout = 0;
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			a[i][j] = b[cout];
			cout++;
		}
	}
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			printf("%d ", a[j][i]);
		}
		printf("\n");
	}


	//
	return 0;
}