#include <stdio.h>
#include <string.h>

struct STUDENT {
	char a[20];
} num[100];

int main() {

	int m, n, t, j, i;
	int co[20];
	scanf("%d ", &n);
	for (i = 1; i <= n; i++) {
		gets(num[i].a);
		//printf("%s\n", num[i].a );
	}
	scanf("%d", &m);
	//printf("%d", m);
	for (i = 1; i <= n; i++) {
		scanf("%d", &co[i]);
		//printf("%d", co[i]);
	}
	for (j = 0; j < m; j++) {
		for (i = 1; i <= n; i++) {
			t = co[i];
			num[t + 1 + n] = num[i];
		}
		for (i = 1; i <= n; i++) {
			num[i] = num[i + 1 + n];
		}
	}
	for (i = 1; i <= n; i++) {
		printf("%s\n", num[i].a);
	}
	return 0;
}