#include <iostream>
using namespace std;
int n, a[105], b[15][15];

int main() {
	cin >> n;
	for (int i = 1; i <= n * n; i++)
		cin >> a[i];
	for (int i = 1; i < n * n; i++)
		for (int j = i + 1; j <= n * n; j++)
			if (a[i] > a[j])  {
				int c = a[i];
				a[i] = a[j];
				a[j] = c;
			}
	int num = 0;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++) {
			num++;
			b[j][i] = a[num];
		}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++)
			cout << b[i][j] << ' ';
		cout << endl;
	}
	return 0;
}