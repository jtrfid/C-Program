#include <stdio.h>
#include <string.h>

int main() {
	struct CARD {
		char name[100];
	} card[56] = {0};
	int k, i, n, t;
	scanf("%d", &n);
	for (i = 0; i <= n; i++) {
		gets(card[i].name);
	}

	int x, change[56], m;

	scanf("%d", &k);

	for (i = 0; i < n; i++) {
		scanf("%d", &change[i]);
	}
	for (i = 0; i < k - 1; i++) {
		for (t = 1; t <= n; t++) {
			card[55] = card[t];
			m = change[t - 1];
			card[t] = card[m];
			card[m] = card[55];
		}
	}
	for (i = 1; i <= n; i++) {
		printf("%s\n", card[i].name);
	}

	return 0;
}
