#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int a[n][n], ak[n * n];
	int i, j = 0;
	for (i = 0; i < n * n ; i++) {
		scanf("%d", &ak[j]);
		//printf("%d-\n", ak[j]);
		j++;
	}
	int jk = 0;
	for (i = 0; i < n * n ; i++) {
		for (jk = 0; jk < j - 1; jk++) {
			if (ak[jk] > ak[jk + 1]) {
				int t;
				t = ak[jk];
				ak[jk] = ak[jk + 1];
				ak[jk + 1] = t;
			}
		}
	}
	jk = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			a[j][i] = ak[jk];
			jk++;
		}

	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (j != n - 1)
				printf("%d ", a[i][j]);
			else if (j == n - 1) {
				printf("%d\n", a[i][j]);
			}
		}
	}





	return 0;
}