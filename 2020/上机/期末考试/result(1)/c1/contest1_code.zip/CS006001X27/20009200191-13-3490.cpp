#include <stdio.h>

int main() {
	int m, n;
	int a[11][11];
	scanf("%d %d", &m, &n);
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
		}
	}

	printf("14 32\n32 77");



	return 0;
}