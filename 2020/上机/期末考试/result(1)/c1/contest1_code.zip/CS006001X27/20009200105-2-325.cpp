#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int n, a, b, c, d, e, i;
	scanf("%d", &n);
	a = n * n;
	b = 0;
	c = 0;
	d = 0;
	for (i = n; i <= a; i++) {
		if (i % 2 != 0)
			b++;
		if (i % 2 == 0)
			c++;
		if (i % 4 == 0 && i % 3 != 0)
			d++;
	}
	if (b >= c)
		e = b;
	else
		e = c;
	if (e <= d)
		e = d;
	printf("%d %d %d\n", b, c, d);
	printf("%d", e);
	return 0;
}
