#include <stdio.h>

int main () {
	int n, i, j;
	int max = 0;
	int count1 = 0, count2 = 0, count3 = 0;
	scanf("%d", &n);
	int m = n * n;
	for (i = n; i <= m; i++) {
		if (i % 2 != 0) {
			count1++;
		} else if (i % 2 == 0) {
			count2++;
		}
	}
	for (i = n; i <= m; i++) {
		if (i % 4 == 0 && i % 3 != 0) {
			count3++;
		}
	}
	if (max == 0) {
		if (count1 <= count2) {
			max = count2;
			if (max <= count3) {
				max = count3;
			}
		} else if (count1 > count2) {
			max = count1;
			if (max <= count3) {
				max = count3;
			}
		}
	}
	printf("%d %d %d\n", count1, count2, count3);
	printf("%d", max);
	return 0;
}