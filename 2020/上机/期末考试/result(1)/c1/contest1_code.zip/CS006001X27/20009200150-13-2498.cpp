#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int m = 0, n = 0, arr1[100][100] = {0}, arr2[100][100] = {0};
	int result[10][10] = {0};
	scanf("%d %d", &m, &n);
	for (int i1 = 0; i1 < m; i1++) {
		for (int i2 = 0; i2 < n; i2++) {
			scanf("%d", &arr1[i1][i2]);
		}
	}
	for (int i1 = 0; i1 < m; i1++) {
		for (int i2 = 0; i2 < n; i2++) {
			arr2[i2][i1] = arr1[i1][i2];
		}
	}
	for (int i1 = 0; i1 < m ; i1++) {
		for (int i2 = 0; i2 < m ; i2++) {
			for (int i0 = 0; i0 < n ; i0++) {
				result[i1][i2] += arr1[i1][i0] * arr2[i0][i2];
			}
		}
	}
	for (int i1 = 0; i1 < m; i1++) {
		for (int i2 = 0; i2 < m ; i2++) {
			if (i2 == m - 1) {
				printf("%d\n", result[i1][i2]);
			} else {
				printf("%d ", result[i1][i2]);
			}
		}
	}
	return 0;














}