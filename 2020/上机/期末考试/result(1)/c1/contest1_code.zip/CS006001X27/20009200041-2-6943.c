#include <stdio.h>

int main() {
	int n;
	int num1[100], num2[100], num3[100];

	int count1 = 0, count2 = 0, count3 = 0;
	scanf("%d", &n);
	int i;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			num1[count1] = i;
			count1++;
			if (i % 4 == 0 && i % 3 != 0) {
				num3[count3] = i;
				count3++;
			}
		} else if (i % 2 != 0) {
			num2[count2] = i;
			count2++;
		}
	}
	int max;
	if (n % 2 == 0) {
		max = count1;
	} else if (n % 2 != 0) {
		max = count2;
	}

	printf("%d %d %d\n", count2, count1, count3);

	printf("%d", max);
	return 0;
}