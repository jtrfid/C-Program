#include <stdio.h>
int num1[1000];
int num2[1000][1000];

int main() {
	int n;
	scanf("%d", &n);
	int i, j, k;
	i = j = k = 0;
	for (i = 0; i < n * n; i++) {
		scanf("%d", &num1[i]);

	}
	for (i = 0; i < n * n; i++) {
		for (j = 0; j < n * n - 1; j++) {
			if (num1[j + 1] < num1[j]) {
				int temp = num1[j + 1];
				num1[j + 1] = num1[j];
				num1[j] = temp;
			}
		}
	}
	//for (i = 0; i < n * n; i++)
	//	printf("%d ", num1[i]);
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			num2[j][i] = num1[k++];
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", num2[i][j]);
		putchar('\n');
	}
	return 0;
}