#include <stdio.h>

int main() {
	int n, sum1 = 0, sum2 = 0, sum3 = 0, i, max;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			sum2++;
		else
			sum1++;
		if (i % 4 == 0 && i % 3 != 0)
			sum3++;
	}
	max = sum1;
	if (sum2 > max)
		max = sum2;
	if (sum3 > max)
		max = sum3;
	printf("%d %d %d\n%d", sum1, sum2, sum3, max);
	return 0;
}