#include <stdio.h>
int a[100][100];
int b[100][100];

int c[100][100] = {0};

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, j;
	for (i = 1; i <= m; i++) {
		for (j = 1; j <= n; j++) {
			scanf("%d", &a[i][j]);
			b[j][i] = a[i][j];
		}
	}
	int k, l;
	for (k = 1; k <= m; k++) {
		for (l = 1; l <= m; l++) {
			for (i = 1; i <= n; i++) {
				c[k][l] += a[k][i] * b[i][l];
			}
		}
	}
	for (k = 1; k <= m; k++) {
		for (l = 1; l <= m; l++) {
			printf("%d ", c[k][l]);
		}
		printf("\n");
	}
	return 0;












}