#include <stdio.h>

int main() {
	int n, i, k, m, j, t, p, a[100], b[10][10];
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < n * n; i++) {
		for (j = 0; j < n * n - i - 1; j++) {
			if (a[j] > a[j + 1]) {
				t = a[j];
				a[j] = a[j + 1];
				a[j + 1] = t;
			}
		}
	}
	i = 0;
	for (j = 0; j < n; j++) {
		for (k = 0; k < n; k++) {
			b[k][j] = a[i];
			i++;
		}
	}
	p = 0;
	for (k = 0; k < n; k++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[k][j]);
			p++;
			if (p % 3 == 0)
				printf("\n");
		}
	}

	return 0;
}