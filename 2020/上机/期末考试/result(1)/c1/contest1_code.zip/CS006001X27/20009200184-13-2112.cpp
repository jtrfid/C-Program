#include <iostream>
using namespace std;
int n, m, a[15][15], b[15][15], c[15][15];

int main() {
	cin >> m >> n;
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= n; j++)
			cin >> a[i][j];
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= n; j++)
			b[j][i] = a[i][j];
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= m; j++)
			for (int k = 1; k <= n; k++)
				c[i][j] += a[i][k] * b[k][j];
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= m; j++)
			cout << c[i][j] << ' ';
		cout << endl;
	}
	return 0;
}