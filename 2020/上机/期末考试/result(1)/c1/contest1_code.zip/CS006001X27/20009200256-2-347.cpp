#include <stdio.h>

int main() {
	int j = 0, o = 0, c = 0, max, n;
	scanf("%d", &n);
	for (int i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			o++;
		}
		if (i % 2 == 1) {
			j++;
		}
		if ((i % 4 == 0) && (i % 3 != 0)) {
			c++;
		}
	}
	printf("%d %d %d\n", j, o, c);
	if (j > o) {
		printf("%d", j);
	} else {
		printf("%d", o);
	}
	return 0;
}