#include <stdio.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int p[m][n];
	int g[n][m];
	int i, q;
	for (i = 0; i < m; i++) {
		for (q = 0; q < n; q++) {
			scanf("%d", &p[i][q]);
		}
	}
	for (i = 0; i < m; i++) {
		for (q = 0; q < n; q++) {
			g[q][i] = p[i][q];
		}
	}
	int game[m][m];
	int w, e;
	for (w = 0; w < m; w++) {
		for (e = 0; e < m; e++) {
			int sum = 0;
			for (i = 0; i < n; i++) {
				sum += p[w][i] * g[i][e];
			}
			game[w][e] = sum;
		}
	}
	for (i = 0; i < m; i++) {
		for (q = 0; q < m - 1; q++) {
			printf("%d ", game[i][q]);
		}
		printf("%d\n", game[i][m - 1]);
	}
	return 0;
}