#include <stdio.h>

typedef struct ind {
	char sur[10];
	char color[10];
} Paper;

int main() {
	int N;
	int i, j;
	int k;
	int order [54] = {0};
	Paper data[54] = {0};
	//����
	scanf("%d", &N);
	for (i = 0; i < N; i++) {
		int t = getchar();
		scanf("%s %s", data[i].sur, data[i].color);
	}
	scanf("%d", &k);
	for (i = 0; i < N; i++) {
		scanf("%d", &order[i]);
	}
	//ִ�л�λ����
	Paper final[54] = {0};
	for (i = 0; i < k; i++) {

		for (j = 0; j < N; j++) {
			final[order[j] - 1] = data[j];
		}
		for (j = 0; j < N; j++) {
			data[j] = final[j];
		}
	}
	//���
	for (i = 0; i < N; i++) {
		printf("%s %s\n", final[i].sur, final[i].color);
	}




	return 0;
}