#include <stdio.h>

int main() {
	int n, m, sum = 0, s;
	scanf("%d %d", &m, &n);
	int ch[m][n], ch1[n][m], ch2[m][m];
	int i, k;
	for (i = 0; i < m; i++) {
		for (k = 0; k < n; k++) {
			scanf("%d", &ch[i][k]);
		}
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < m; k++) {
			ch1[i][k] = ch[k][i];
		}
	}
	for (i = 0; i < m; i++) {

		for (k = 0; k < m; k++) {
			sum = 0;
			for (s = 0; s < n; s++) {
				sum += ch[i][s] * ch1[s][k];
			}
			ch2[i][k] = sum;
		}
	}
	for (i = 0; i < m; i++) {
		for (k = 0; k < m; k++) {
			printf("%d ", ch2[i][k]);
		}
		printf("\n");
	}
	return 0;
}