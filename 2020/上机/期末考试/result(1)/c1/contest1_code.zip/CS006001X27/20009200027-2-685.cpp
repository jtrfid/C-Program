#include <stdio.h>

int main(void) {
	int n;
	scanf("%d", &n);
	int m = n * n;
	int n1 = 0, n2 = 0, n3 = 0;
	for (n; n <= m; n++) {
		if (n % 2 == 0) {
			n1++;
		}
		if (n % 2 != 0) {
			n2++;
		}
		if (n % 3 != 0 && n % 4 == 0) {
			n3++;
		}
	}
	printf("%d %d %d\n", n1, n2, n3);
	int z;
	if (n1 > n2) {
		z = n1;
	} else {
		z = n2;
	}
	if (z > n3) {
		printf("%d\n", z);
	} else {
		printf("%d\n", n3);
	}

	return 0;

}