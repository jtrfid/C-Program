#include <stdio.h>

int main() {
	int m, n;
	int a[10][10];
	int b[10][10];
	int c[100];
	int d[10][10] = {0};
	scanf("%d %d", &m, &n);
	int i, j;
	for (i = 0; i < m * n ; i++) {
		scanf("%d", &c[i]);
	}
	int t = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			a[i][j] = c[t];
			t++;
		}
	}
	t = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = c[t];
			t++;
		}
	}
	int x;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (x = 0; x < n; x++) {
				d[i][j] += a[i][x] * b[x][j];
			}
		}
	}
	int count = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", d[i][j]);
			count++;
		}
		if (count == m) {
			printf("\n");
			count = 0;
		}
	}
	return 0;
}