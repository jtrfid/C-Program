#include <stdio.h>

int main() {
	int m, n, a[15][15], b[15][15], c[15][15] = {0}, i, j, k;
	scanf("%d %d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (k = 0; k < n; k++) {
				c[i][j] += a[i][k] * a[j][k];
			}
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
	return 0;
}