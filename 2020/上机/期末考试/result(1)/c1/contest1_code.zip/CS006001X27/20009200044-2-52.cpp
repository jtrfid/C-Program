#include <iostream>
#include <algorithm>
using namespace std;

int main() {
	int n, c1 = 0, c2 = 0, c3 = 0;
	cin >> n;
	for (int i = n; i <= n * n; ++i) {
		if (i % 2 == 0)
			++c2;
		else
			++c1;
		if (i % 4 == 0 && i % 3 != 0)
			++c3;
	}
	cout << c1 << " " << c2 << " " << c3 << endl;
	if (c1 >= c2 && c1 >= c3)
		cout << c1;
	if (c2 >= c1 && c2 >= c3)
		cout << c2;
	if (c3 >= c1 && c3 >= c2)
		cout << c3;
}