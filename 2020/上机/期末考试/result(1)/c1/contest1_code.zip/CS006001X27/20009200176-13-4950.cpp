#include <stdio.h>
#include <string.h>

int main() {
	int m, n, i, j, w = 0, e = 0, o = 0, x = 0, t, p;
	scanf("%d %d", &m, &n);
	t = m;
	p = m;
	int a[m][n], b[n][m], c[m][m];
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			c[i][j] = 0;
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			b[j][i] = a[i][j];
		}
	}
	for (i = 0; i < m; i++) {
		while (t) {
			for (j = 0; j < n; j++) {
				c[i][x] +=	b[w][e] * a[i][j];
				w++;
			}
			w = 0;
			x++;
			e++;
			t--;

		}
		x = 0;
		e = 0;
		w = 0;
		t = p;


	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}

}

