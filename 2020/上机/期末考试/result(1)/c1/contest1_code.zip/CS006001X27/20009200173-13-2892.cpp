#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int num[m][n];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &num[i][j]);
		}
	}

	int NUM[n][m];
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			NUM[i][j] = num[j][i];
			//printf("%d ", NUM[i][j]);
		}
	}

	int temp[m][m] = {};
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			for (int k = 0; k < n; k++) {
				temp[i][j] += num[i][k] * NUM[k][j];
			}
			printf("%d ", temp[i][j]);
		}
		printf("\n");
	}

	return 0;
}