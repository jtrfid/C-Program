#include <stdio.h>

int main() {
	int A[12][12], B[12][12], C[12][12], p[144];
	int a, b, c, d, n, s, x, m;
	scanf("%d%d", &m, &n);
	c = 0;
	for (a = 0; a < m; a++) {
		for (b = 0; b < n; b++) {
			scanf("%d", &A[a][b]);
			p[c] = A[a][b];
			c++;
		}
	}
	c = 0;
	for (a = 0; a < m; a++) {
		for (b = 0; b < n; b++) {
			B[b][a] = p[c];
			c++;
		}
	}
	for (a = 0; a < m; a++) {
		for (b = 0; b < m; b++) {
			for (d = 0, s = 0; d < n; d++) {
				s = s + A[a][d] * B[d][b];
			}
			C[a][b] = s;
		}
	}
	for (a = 0; a < m; a++) {
		for (b = 0; b < m; b++) {
			printf("%d ", C[a][b]);
		}
		printf("\n");
	}
}