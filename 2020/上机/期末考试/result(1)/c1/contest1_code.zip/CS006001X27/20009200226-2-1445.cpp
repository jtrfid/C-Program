#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i;
	int a = 0, b = 0, c = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 4 == 0 && i % 3 != 0) {
			c++;
		}
	}
	for (i = n; i <= n * n; i++) {
		if (i % 2 != 0) {
			a++;
		} else {
			b++;
		}
	}
	printf("%d %d %d\n", a, b, c);
	int max;
	if (a >= b) {
		max = a;
	} else {
		max = b;
	}
	if (max <= c) {
		max = c;
	}
	printf("%d", max);
	return 0;
}