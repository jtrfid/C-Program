#include <stdio.h>

int main() {
	int o[100], p[10][10];
	int a, b, c, n, max;
	scanf("%d", &n);
	for (a = 0; a < n * n; a++) {
		scanf("%d", &o[a]);
	}
	for (b = 0; b < n * n - 1; b++) {
		for (c = b + 1; c < n * n; c++) {
			if (o[b] > o[c]) {
				max = o[b];
				o[b] = o[c];
				o[c] = max;
			}
		}
	}
	c = 0;
	for (a = 0; a < n; a++) {
		for (b = 0; b < n; b++) {
			p[b][a] = o[c];
			c++;
		}
	}
	for (a = 0; a < n; a++) {
		for (b = 0; b < n; b++) {
			printf("%d ", p[a][b]);
		}
		printf("\n");
	}
}