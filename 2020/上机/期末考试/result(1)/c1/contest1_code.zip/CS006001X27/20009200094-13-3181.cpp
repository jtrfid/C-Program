#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

struct xinxi {
	char a;
	char b[10];
} stu[100], t;

int main() {
	int n, k;
	scanf("%d", &n);
	int i, j, u;
	for (i = 1; i <= n; i++) {
		scanf("%c %s", &stu[i].a, &stu[i].b);
	}
	scanf("%d", &k);
	int b[100];
	for (i = 1; i <= n; i++) {
		scanf("%d", &b[i]);
	}
	while (k > 0) {
		for (i = 1; i <= n; i++) {
			for (j = 1; j <= n; j++) {
				if (j == b[i]) {
					t = stu[i];
					stu[i] = stu[j];
					stu[j] = t;
				}
			}
			k--;
		}
	}
	for (i = 1; i <= n; i++) {
		printf("%c %s", stu[i].a, stu[i].b);
	}




	return 0;
}