#include <cstdio>
#include <algorithm>
using namespace std;

bool cmp(int a, int b) {
	return a < b;
}

int main() {
	int n, index = 0;
	int arr[145];
	int mat[12][12];  // I don't trust you.

	scanf("%d", &n);
	for (int i = 0; i < n * n; i++) {
		scanf("%d", &arr[i]);
	}

	sort(arr, arr + n * n, cmp);
	for (int j = 0; j < n; j++) {
		for (int i = 0; i < n; i++) {
			mat[i][j] = arr[index++];
		}
	}

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			printf("%d", mat[i][j]);
			if (j != n - 1)
				printf(" ");
			else
				printf("\n");
		}
	}
	return 0;
}