#include <stdio.h>

int main() {
	int n, i, a = 0, b = 0, c = 0;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 != 0) {
			a++;
		}
		if (i % 2 == 0) {
			b++;
		}
		if (i % 3 != 0 && i % 4 == 0) {
			c++;
		}
	}
	int max = 0;
	if (a > max)
		max = a;
	if (b > max)
		max = b;
	if (c > max)
		max = c;
	printf("%d %d %d\n", a, b, c);
	printf("%d", max);
	return 0;
}
