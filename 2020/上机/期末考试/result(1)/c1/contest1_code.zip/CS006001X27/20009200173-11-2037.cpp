#include <stdio.h>


int main() {
	int n;
	scanf("%d", &n);

	int number = n;
	//printf("%d\n", n);
	int num[n];
	int pf = n * n;
	for (int i = 0; i < pf; i++) {
		scanf("%d", &num[i]);
	}

	int t, swap_flag;
	for (int i = 0; i < pf; i++) {
		swap_flag = 0;
		for (int j = 0; j < pf - i - 1; j++) {
			if (num[j] > num[j + 1]) {
				t = num[j];
				num[j] = num[j + 1];
				num[j + 1] = t;
				swap_flag = 1;
			}
		}
		if (swap_flag == 0)
			break;
	}

	int temp = 0;
	while (temp != pf ) {
		for (int i = 0; i < number; i++) {
			printf("%d ", num[temp]);
			temp++;
		}
		printf("\n");
	}

	return 0;
}