#include <stdio.h>

int main() {
	int n, tem, x = 0, y = 0, k = 0, d = 0, a[n * n], b[x][y], j = 0;
	scanf("%d", &n);

	for (int i = 0; i < n * n; i++)
		scanf("%d", &a[i]);

	for (j; j < n * n / 2; j++)
		if (a[j] >= a[n * n - j]) {
			tem = a[j];
			a[j] = a[n * n - j];
			a[n * n - j] = tem;
		}
	for (y; y < n; y++)
		for (x; x < n; x++)
			for (k; k < n * n; k++) {
				b[x][y] = a[k];
			}

	for (y; y < n; y++)
		for (x; x < n; x++) {
			printf("%d", b[x][y]);
		}

	return 0;
}