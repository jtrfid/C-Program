#include <stdio.h>

int Max(int a, int b, int c) {
	int max;
	if (a >= b) {
		max = a;
	} else {
		max = b;
	}
	if (max <= c) {
		max = c;
	}
	return max;
}

int main() {
	int n;
	scanf("%d", &n);
	int i;
	int odd = 0, even = 0, num = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			even++;
		}
		if (i % 2 == 1) {
			odd++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			num++;
		}

	}
	int max = Max(even, odd, num);
	printf("%d %d %d\n%d", odd, even, num, max);
	return 0;













}