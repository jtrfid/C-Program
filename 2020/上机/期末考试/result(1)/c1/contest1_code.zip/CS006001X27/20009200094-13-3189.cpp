#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int c[100][100] = {0};

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, j;
	int a[100][100];
	int b[100][100];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			b[i][j] = a[j][i];
		}
	}
	int i1, j1, k;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (k = 0; k <= n - 1; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}


	return 0;
}