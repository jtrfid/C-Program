#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n;
	scanf("%d", &n);
	int i = 0, b[10000], x, j = 0;
	for (i = 0; i < n * n; i++) {
		scanf("%d", &b[i]);
	}
	for (i = 0; i < n * n; i++) {
		for (j = 0; j < n * n; j++) {
			if (b[i] < b[j]) {
				x = b[i];
				b[i] = b[j];
				b[j] = x;
			}
		}
	}
	/*for (i = 0; i < n * n; i++) {
		printf("%d ", b[i]);
	}*/
	int c[100][100];
	int w = 0;
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			for (w = 0; w < n * n; w++) {
				c[i][j] = b[w];
			}
		}
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", c[i][j]);
			if (j == n - 1) {
				printf("\n");
			}
		}
	}

	return 0;
}