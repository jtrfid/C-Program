#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, j, sum1 = 0, sum2 = 0, sum3 = 0;
	for (i = n; i <= n * n ; i++) {
		if (i % 2 == 0) {
			sum1++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			sum3++;
		}
	}
	sum2 = n * n - n - sum1;
	int max = sum1;
	if (sum2 + 1 > max) {
		max = sum2 + 1;
	}
	if (sum3 > max) {
		max = sum3;
	}
	printf("%d %d %d\n", sum2 + 1, sum1, sum3);
	printf("%d", max);

	return 0;
}