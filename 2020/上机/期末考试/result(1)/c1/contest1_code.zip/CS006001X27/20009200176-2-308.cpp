#include <stdio.h>
#include <string.h>

int main() {
	int n, i, j = 0, o = 0, x = 0, max = 0;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			o += 1;
		} else {
			j += 1;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			x += 1;
		}
	}
	printf("%d %d %d\n", j, o, x);
	if (j >= o && j >= x) {
		max = j;
	} else if (o >= j && o >= x) {
		max = o;
	} else
		max = x;
	printf("%d", max);
}