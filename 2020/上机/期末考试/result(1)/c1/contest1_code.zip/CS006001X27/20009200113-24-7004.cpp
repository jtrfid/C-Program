#include <stdio.h>

int main() {
	char a[10], c[10];
	int n, k, i, j, b[10];

	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		gets(&a[i]);
	}
	scanf("%d", &k);
	for (i = 0; i < n; i++) {
		scanf("%d", b[i]);
	}
	for (i = 0; i < n; i++) {
		c[i] = a[i];
	}
	for (i = 0; i < k; i++) {
		for (j = 0; j < n; j++) {
			a[b[j]] = c[j];
		}
	}
	for (i = 0; i < n; i++) {
		puts( &a[i]);
	}
	return 0;
}