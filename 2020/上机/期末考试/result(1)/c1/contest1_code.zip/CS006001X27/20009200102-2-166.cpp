#include <stdio.h>

int main() {
	int n, max = 0, a = 0, b = 0, c = 0, i;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 != 0) {
			a++;
		}
		if (i % 2 == 0) {
			b++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			c++;
		}
	}
	a > max ? max = a : max = max;
	b > max ? max = b : max = max;
	c > max ? max = c : max = max;
	printf("%d %d %d\n", a, b, c);
	printf("%d", max);


	return 0;
}