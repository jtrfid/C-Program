#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, j, k;
	int a[100];
	for (i = 1; i <= n * n; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 1; i <= n * n - 1; i++) {
		for (j = i + 1; j <= n * n; j++) {
			if (a[i] > a[j]) {
				k = a[i];
				a[i] = a[j];
				a[j] = k;
			}
		}
	}
	int u = 1;
	int b[10][10];

	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			b[i][j] = a[u];
			u++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}




	return 0;
}