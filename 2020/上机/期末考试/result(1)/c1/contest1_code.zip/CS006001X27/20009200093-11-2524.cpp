#include <stdio.h>

void fun(int a[], int n) {
	int i, j, swap, t;
	for (i = 0; i < n; i++) {
		swap = 1;
		for (j = 0; j < n - i - 1; j++) {
			if (a[j] > a[j + 1]) {
				t = a[j + 1];
				a[j + 1] = a[j];
				a[j] = t;
				swap = 1;
			}
			if (swap == 0)
				break;
		}
	}
}

int main() {
	int n, a[100], b[10][10], i, j;
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	fun(a, n * n);

	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			b[i][j] = a[j * n + i];
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {

			printf("%d ", b[i][j]);

		}
		printf("\n");
	}

	return 0;
}