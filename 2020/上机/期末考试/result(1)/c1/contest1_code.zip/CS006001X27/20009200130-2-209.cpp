#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n1, n2;
	scanf("%d", &n1);
	n2 = n1 * n1;
	int ji = 0, ou = 0, p = 0;
	int i, j;
	for (i = n1; i <= n2; i++) {
		if (i % 2 == 0) {
			ou++;
		}
		if (i % 2 != 0) {
			ji++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			p++;
		}
	}
	int max = ou;
	if (ji > max) {
		max = ji;
	}
	if (p > max) {
		max = p;
	}
	printf("%d %d %d\n", ji, ou, p);
	printf("%d", max);















	return 0;
}