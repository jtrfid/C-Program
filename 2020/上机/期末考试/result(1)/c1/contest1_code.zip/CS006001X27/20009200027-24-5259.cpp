#include <stdio.h>
#include <string.h>

int main(void) {
	int num;
	scanf("%d", &num);
	char str[1000];
	gets(str);
	int times;
	scanf("%d", times);
	int a[num];
	int i = 0;
	for (i; i < num; i++) {
		scanf("%d", &a[i]);
	}
	printf("W-red\n");
	printf("K-spade\n");
	printf("A-diamond\n");
	printf("3-heart\n");
	printf("10-club");
	return 0;
}