#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int n, k, i, num, j, e = 0;
	scanf("%d\n", &n);
	struct card {
		char face[10];
		char name[10];
	} c[54], d[54];
	for (i = 0; i < n; i++) {
		scanf("%s", &c[i].face);
		scanf("%s", &c[i].name);
	}
	scanf("%d", &k);
	int b[54];
	for (i = 0; i < n; i++) {
		scanf("%d", &b[i]);
	}
	for (i = 0; i < k; i++) {
		for (j = 0, e = 0; j < n; j++) {
			num = b[e] - 1;
			d[num] = c[j];
			e++;
		}
		for (j = 0; j < n; j++) {
			c[j] = d[j];
		}
	}
	for (i = 0; i < n; i++)
		printf("%s %s\n", d[i].face, d[i].name);
}