#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, k, sum1 = 0, sum2 = 0, sum3 = 0, max;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			sum1++;
		else
			sum2++;
		if (i % 4 == 0 && i % 3 != 0)
			sum3++;
	}
	max = sum1;
	if (sum2 > max)
		max = sum2;
	if (sum3 > max)
		max = sum3;
	printf("%d %d %d\n%d", sum2, sum1, sum3, max);
	return 0;
}