#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int n, a, oushu = 0, jishu = 0, other = 0, i, j, max = 0;
	int b[3];
	scanf("%d", &n);
	a = n * n;
	for (i = n; i <= a; i++) {
		if (i % 2 == 0) {
			oushu++;
		}
		if (i % 2 != 0) {
			jishu++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			other++;
		}
	}
	b[0] = oushu;
	b[1] = jishu;
	b[2] = other;
	for (i = 0; i < 2; i++) {
		for (j = i + 1; j < 3; j++) {
			if (b[i] < b[j]) {
				max = b[j];
				b[j] = b[i];
				b[i] = max;
			}
		}
	}
	printf("%d %d %d\n", jishu, oushu, other);
	printf("%d", b[0]);
}