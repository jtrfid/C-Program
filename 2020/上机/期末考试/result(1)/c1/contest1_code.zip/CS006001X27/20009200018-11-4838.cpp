#include <stdio.h>

int main() {

	int n, c, b[10][10], i, a[10][10], m;
	scanf("%d\n", &n);
	for (i = 0; i < n  ; i++) {

		scanf("%d", &a[i][i]);
	}


	for (i = 0; i < n; i++) {
		for (m = 0; m < n; m++) {

			if (a[i][m] <= a[0][0]) {
				c = a[0][0];
				a[0][0] = a[i][m];
				a[i][m] = c;
			}
		}
	}

	printf("%d ", b[i][m]);


	return 0;
}