#include <stdio.h>

int main() {
	int ji = 0, ou = 0, shi = 0, max, n;
	scanf("%d", &n);
	int d = n * n;
	for (int i = n; i <= d; i++) {
		if (i % 2 != 0)
			ji++;
		else {
			ou++;
			if (i % 4 == 0 && i % 3 != 0)
				shi++;
		}
	}
	max = ji;
	if (ji < ou)
		max = ou;
	printf("%d %d %d\n", ji, ou, shi);
	printf("%d", max);









	return 0;
}