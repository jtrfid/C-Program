#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n;
	scanf("%d", &n);

	int start = n, end = n * n;
	int oushu = 0, jishu = 0;
	for (int i = start; i <= end; i++) {
		if (i % 2 == 0)
			oushu++;
		else
			jishu++;
	}
	int num = 0;
	for (int i = start; i < end; i++) {
		if (i % 4 == 0 && i % 3 != 0)
			num++;
	}

	printf("%d %d %d\n", jishu, oushu, num);

	int max;
	if (jishu > oushu)
		max = jishu;
	else
		max = oushu;

	if (max < num)
		max = num;

	printf("%d", max);


	return 0;
}