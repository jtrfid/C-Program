#include <stdio.h>
#include <string.h>

int main() {

	int m, n, t, i, j, o = 0;
	int count = 0;
	int a[10][10];
	int b[10][10];
	int c[10][10];
	scanf("%d %d", &m, &n);
	//printf("%d %d", m, n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			b[j][i] = a[i][j];

		}
	}
	t = m;
	if (m > n) {
		t = n;
	}
	for (i = 0; i < t; i++) {
		for (j = 0; j < t; j++) {
			for (o = 0; o < n; o++) {
				count = count + a[i][o] * b[o][j];
			}
			c[j][i] = count;
			count = 0;
			printf("%d ", c[j][i]);
		}

		printf("\n");
	}
	return 0;
}