#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, a[n * n], j, k, t;
	for (i = 0; i < n * n; i++)
		scanf("%d", &a[i]);
	for (i = 0; i < n * n - 1; i++) {
		for (j = i + 1, k = i; j < n * n; j++) {
			if (a[j] < a[k])
				k = j;
		}
		if (k != i) {
			t = a[i];
			a[i] = a[k];
			a[k] = t;
		}
	}
	int b[n][n];
	for (j = 0; j < n; j++) {
		k = n * j;
		for (i = 0; i < n; i++, k++) {
			b[i][j] = a[k];
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	return 0;
}