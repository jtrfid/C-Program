#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	int i1, i2, i3, i4, i5;
	int c1 = 0, c2 = 0, c3 = 0;
	for (i1 = n; i1 <= n * n; i1++) {
		if (i1 % 2 != 0) {
			c1++;
		}
		if (i1 % 2 == 0) {
			c2++;
		}
		if (i1 % 4 == 0 && i1 % 3 != 0) {
			c3++;
		}
	}
	int max = c1;
	if (c2 > max) {
		max = c2;
	}
	if (c3 > max) {
		max = c3;
	}
	printf("%d %d %d\n", c1, c2, c3);
	printf("%d", max);
	return 0;
}