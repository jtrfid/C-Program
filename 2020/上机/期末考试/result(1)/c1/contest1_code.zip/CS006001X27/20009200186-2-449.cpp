#include <stdio.h>

int main() {
	int number;
	int a = 0, aa = 0, po = 0, poa;
	scanf("%d", &number);
	for (int n = number; n <= number * number; n++) {
		if (n % 2 == 0) {
			aa++;
		} else
			a++;
		if (n % 4 == 0 && n % 3 != 0) {
			po++;
		}
	}
	poa = a;
	if (a < aa)
		poa = aa;
	if (aa < po)
		poa = po;
	printf("%d %d %d\n%d", a, aa, po, poa);
	return 0;
}