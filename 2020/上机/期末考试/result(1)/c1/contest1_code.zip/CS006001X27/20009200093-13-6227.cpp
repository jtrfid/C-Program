#include <stdio.h>


int main() {
	int n, a[100][100], b[100][100], c[100][100], k, i, j, m, s;
	scanf("%d%d", &m, &s);

	for (i = 0; i < m; i++) {
		{
			for (j = 0; j < s; j++)
				scanf("%d", &a[i][j]);
		}
	}
	for (j = 0; j < m; j++) {
		{
			for (i = 0; i < s; i++)
				b[i][j] = a[j][i];
		}
	}

	for (i = 0; i < s; i++) {
		{
			for (j = 0; j < m; j++)
				printf("%d ", b[i][j]);
		}
	}
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (k = 0; k < s ; k++) {
				c[i][j] = c[i][j] + a[i][k] * b[k][j];
			}
		}
	}

	for (i = 0; i < m; i++) {
		{
			for (j = 0; j < m; j++)
				printf("%d ", c[i][j]);
		}
		printf("\n");
	}



	return 0;
}