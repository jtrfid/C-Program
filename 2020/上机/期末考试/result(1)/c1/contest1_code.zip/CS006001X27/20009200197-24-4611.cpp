#include <stdio.h>
int pos[100];

typedef struct a {
	char num[10];
	char se[10];
} p;

int main() {
	p s[100];
	p s0[100];
	int n;
	scanf("%d", &n);

	int i;
	for (i = 0; i < n; i++) {
		scanf("%s %s", s[i].num, s[i].se);

	}
	int k;
	scanf("%d", &k); //ϴ�ƴ���
	for (i = 0; i < n; i++)
		scanf("%d", &pos[i]);
	int j;
	p temp;
	int cnt;
	int x;
	for (i = 0; i < k ; i++) {

		for (cnt = 0; cnt < n; cnt++) {
			s0[cnt] = s[cnt];
		}//
		for (x = 0; x < n; x++)

			//printf("%s %s\n", s0[x].num, s0[x].se);//
			for (j = 0; j < n ; j++) {
				s[pos[j] - 1] = s0[j];

			}//

	}
	for (i = 0; i < n; i++)

		printf("%s %s\n", s[i].num, s[i].se);


	return 0;
}