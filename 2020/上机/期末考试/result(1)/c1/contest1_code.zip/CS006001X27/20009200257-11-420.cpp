#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (!isdigit(ch))	{
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (isdigit(ch))	{
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
int n, a[100010], ans[11][11], tot;

int main() {
	n = read();
	for (int i = 1; i <= n * n; ++i)
		a[i] = read();
	sort(a + 1, a + n * n + 1);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			ans[j][i] = a[++tot];
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j)
			printf("%d ", ans[i][j]);
		printf("\n");
	}
	return 0;
}