#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n); //n npingfang
	int i;
	int cnt1, cnt2, cnt3;
	cnt1 = cnt2 = cnt3 = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			cnt2++;
		if (i % 4 == 0 && i % 3 != 0)
			cnt3++;
	}
	cnt1 = n * n - n - cnt2 + 1;
	printf("%d %d %d", cnt1, cnt2, cnt3);


	return 0;
}