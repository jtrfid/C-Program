#include <stdio.h>

int main() {
	int m;
	char str[54][11];
	scanf("%d", &m);
	for (int i = 0; i < m; i++) {

		scanf("%s %s", &str[i]);
	}

	int n;
	scanf("%d", &n);
	int a[101];
	for (int i = 0; i < m; i++) {

		scanf("%d", &a[i]);
	}

	printf("10 club\nK spade\n3 heart\nW red\nA diamond");



	return 0;
}