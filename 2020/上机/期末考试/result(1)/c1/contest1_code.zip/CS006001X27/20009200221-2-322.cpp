#include <bits/stdc++.h>
using namespace std;

int main() {
	int jishu = 0;
	int oushu = 0;
	int num = 0;
	int maxn = 0;
	int n;
	scanf("%d", &n);
	int last = n * n;
	for (int i = n; i <= last; i++) {
		if (i % 2 == 0) {
			oushu++;
		}
		if (i % 2 != 0) {
			jishu++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			num++;
		}
	}
	maxn = max(maxn, num);
	maxn = max(maxn, jishu);
	maxn = max(maxn, oushu);
	printf("%d %d %d\n%d", jishu, oushu, num, maxn);
	return 0;
}