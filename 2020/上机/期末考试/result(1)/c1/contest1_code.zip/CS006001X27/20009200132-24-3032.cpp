#include <stdio.h>
#include <string.h>

int main() {
	int n;
	scanf("%d", &n);
	struct card {
		char c[15];
	} pkc[n], pks[n];
	int a[54];
	getchar();
	for (int i = 0; i < n; i++) {
		gets(pkc[i].c);
	}
	int count, coo;
	scanf("%d", &count);
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 0; i < n; i++) {
		coo = i;
		for (int j = 0; j < count; j++) {
			coo = a[coo]-1;
		}
		pks[coo] = pkc[i];
	}
	for (int i = 0; i < n; i++) {
		printf("%s\n", pks[i].c);
	}
	;
	return 0;
}