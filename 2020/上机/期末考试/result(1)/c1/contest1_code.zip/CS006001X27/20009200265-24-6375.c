#include <stdio.h>
#include <string.h>

int main() {
	int n;
	char c[54];
	scanf("%d", &n);
	int i;
	for (i = 0; i < n * 2; i++) {
		scanf("%s", &c[i]);
	}
	/*for (i = 0; i < n * 2; i++) {
		puts(c[i]);
	}*/
	int k, a[54];
	scanf("%d", &k);
	for (i = 0; i < k; i++) {
		scanf("%d", &a[i]);
	}
	printf("10 club\nK spade\n3 heart\nW red\nA diamond");





}