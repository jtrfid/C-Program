#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int ch[100];
	int i, k, s, num = 0;
	int ch1[n][n];
	for (i = 0; i < n * n; i++) {
		scanf("%d", &ch[i]);
	}
	for (i = 0; i < n * n - 1; i++) {
		for (k = i + 1; k < n * n; k++) {
			if (ch[k] < ch[i]) {
				s = ch[i];
				ch[i] = ch[k];
				ch[k] = s;
			}
		}
	}

	for (i = 0; i < n; i++) {
		for (k = 0; k < n; k++) {
			ch1[k][i] = ch[num];
			num++;
		}
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < n; k++) {
			printf("%d ", ch1[i][k]);

		}
		printf("\n");
	}
	return 0;
}