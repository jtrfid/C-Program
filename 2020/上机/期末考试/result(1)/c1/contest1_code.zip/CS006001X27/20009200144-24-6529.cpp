#include <stdio.h>
#include <string.h>

int main() {

	int n;

	scanf("%d", &n);
	getchar();

	char card[n][12];

	int i;
	for (i = 0; i < n ; i++) {
		gets(card[i]);
	}

	int k;

	scanf("%d", &k);

	int od[n];

	for (i = 0; i < n; i++) {
		scanf("%d", &od[i]);
	}

	char t[n][12];

	int j, l;
	for (i = 1; i <= k; i++) {

		for (j = 0; j < n; j++) {
			strcpy(t[od[j]], card[j]);
			printf("%s\n", t[od[j]]);
		}
		getchar();
		for (j = 0; j < n; j++) {
			strcpy(card[j], t[j]);
			printf("%s\n", card[j]);
		}

	}

	for (i = 0; i < n ; i++) {
		printf("%s\n", card[i]);
	}
	return 0;
}