#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct m {
	char str[100];
} sti[100];

struct x {
	char temp[100];
} TEMP[100];

int main() {
	int n;
	scanf("%d\n", &n);
	for (int i = 0; i < n; i++) {
		char f[100];
		gets(f);
		strcpy(sti[i].str, f);
		//printf("%s\n", sti[i].str);
	}
	int times;
	scanf("%d", &times);

	int num[n];
	for (int i = 0; i < n; i++) {
		scanf("%d", &num[i]);
	}


	for (int i = 0; i < times; i++) {
		for (int j = 0; j < n; j++) {
			int tmp = num[j] - 1;
			char tmpt[100];
			strcpy(TEMP[tmp].temp, sti[j].str);
		}
		for (int k = 0; k < n; k++) {
			strcpy(sti[k].str, TEMP[k].temp);
		}
	}

	for (int i = 0; i < n; i++) {
		printf("%s\n", TEMP[i].temp);
	}
	return 0;
}