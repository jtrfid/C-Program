#include <stdio.h>
#include <string.h>

int main() {
	int n, i, j, t, o = 0;
	scanf("%d", &n);
	int a[n][n], b[n * n];
	for (i = 0; i < n * n; i++) {
		scanf("%d", &b[i]);
	}

	for (i = 0; i < n * n; i++) {
		for (j = 0; j < n * n - 1; j++) {
			if (b[j] >= b[j + 1]) {
				t = b[j];
				b[j] = b[j + 1];
				b[j + 1] = t;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n ; j++) {
			a[j][i] = b[o];
			o++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n ; j++) {
			if (j == n - 1) {
				printf("%d", a[i][j]);
			}

			else
				printf("%d ", a[i][j]);

		}
		if (i != n - 1)
			printf("\n");

	}
}

