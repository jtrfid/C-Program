#include <stdio.h>
#include <string.h>

int main() {
	int n;
	int t;
	scanf("%d", &n);
	int cu[n * n];
	int i, j;
	int juzheng[n][n];
	for (i = 0; i < n * n; i++) {
		scanf("%d", &cu[i]);
	}
	for (i = 0; i < n * n; i++) {
		for (j = 0; j < n * n - i - 1; j++) {
			if (cu[j] > cu[j + 1]) {
				t = cu[j];
				cu[j] = cu[j + 1];
				cu[j + 1] = t;
			}
		}
	}
	int k = 0;
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			juzheng[i][j] = cu[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", juzheng[i][j]);
		}

	}

	//int juzheng[n][n];

	return 0;
}

