#include <bits/stdc++.h>
using namespace std;

int a[11][11] = {};

int b[11][11] = {};

int c[11][11] = {};
int i, j, m, n;

int main() {
	cin >> m >> n;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			b[j][i] = a[i][j];
		}
	}
	int p = m * n;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (int k = 0; k < n; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}
			cout << c[i][j] << " ";
		}
		cout << endl;
	}
	return 0;
}