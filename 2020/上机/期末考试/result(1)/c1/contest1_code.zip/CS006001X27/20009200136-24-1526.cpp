#include <iostream>

using namespace std;

struct pai {
	char s1[10], s2[10];
} a[10010];

int f[10010];
int n;

void solve() {
	pai b[10010];
	for (int i = 1; i <= n; i++) {
		b[f[i]] = a[i];
	}
	for (int i = 1; i <= n; i++)
		a[i] = b[i];
}
int k;

int main() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i].s1 >> a[i].s2;
	}
	cin >> k;
	for (int i = 1; i <= n; i++) {
		cin >> f[i];
	}

	for (int i = 1; i <= k; i++)
		solve();




	for (int i = 1; i <= n; i++) {
		cout << a[i].s1 << " " << a[i].s2 << endl;
	}

}