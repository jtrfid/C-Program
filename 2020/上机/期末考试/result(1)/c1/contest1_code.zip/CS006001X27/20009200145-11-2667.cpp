#include <stdio.h> 

int main(int argc, char** argv) {
	int k=100;
	k *=2;
	for(int i=0;i<20;i++)
		k +=i;

	printf("k= %d\n",k);
	printf("Hello World\n");
	return 0;
}
