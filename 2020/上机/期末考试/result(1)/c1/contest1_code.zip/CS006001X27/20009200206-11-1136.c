#include <stdio.h>
#include <stdlib.h>

int cmp(const void *a, const void *b) {
	return *(int *)a - *(int *)b;
}

int main() {
	int n;
	scanf("%d", &n);
	int a[n * n];
	int i, j;
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	qsort(a, n * n, sizeof(int), cmp);
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i + j * n]);
		}
		printf("\n");
	}
	return 0;
}