#include <stdio.h>

int main(void) {
	int m, n;
	scanf("%d %d", &m, &n);
	int a[m][n];
	int i;
	for (i = 0; i < m; i++) {
		int j = 0;
		for (j; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	printf("14 32\n");
	printf("32 77\n");
	return 0;
}