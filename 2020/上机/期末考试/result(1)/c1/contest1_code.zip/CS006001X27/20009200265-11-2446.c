#include <stdio.h>
#include <string.h>

int main() {
	int n, a[10][10], s[100];
	int i, j, k, t;
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &s[i]);
	}
	for (i = 0; i < n * n; i++) {
		k = 0;
		for (j = 0; j < n * n - i - 1; j++) {
			if (s[j] > s[j + 1]) {
				t = s[j];
				s[j] = s[j + 1];
				s[j + 1] = t;
			}
			k = 1;
		}
		if (k == 0)
			break;
	}
	/*for (i = 0; i < n * n; i++) {
			//	printf("%d ", s[i]);
		}
	t = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; i++) {
			a[i][j] = s[t];
			t++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; i++) {
			printf("%d", a[i][j]);
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; i++) {
			printf("%d\n", s[t]);
			t++;
		}*/
	for (i = 0; i < n; i++) {
		k = i;
		for (j = 0; j < n; j++) {
			printf("%d ", s[k]);
			k += n;
		}
		printf("\n");
	}
}










