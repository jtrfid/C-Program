#include <iostream>
using namespace std;

struct card {
	string color, num;
} magic[60], tool[60];
int n, rule[60], k;

int main() {
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> magic[i].num >> magic[i].color;
	cin >> k;
	for (int i = 1; i <= n; i++)
		cin >> rule[i];
	int time = 1;
	while (time <= k) {
		for (int i = 1; i <= n; i++) {
			tool[rule[i]].color = magic[i].color;
			tool[rule[i]].num = magic[i].num;
		}
		for (int i = 1; i <= n; i++) {
			magic[i].num = tool[i].num;
			magic[i].color = tool[i].color;
		}
		time++;
	}
	for (int i = 1; i <= n; i++)
		cout << magic[i].num << ' ' << magic[i].color << endl;
	return 0;
}