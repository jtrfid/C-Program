#include <stdio.h>
#include <string.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int a[m][n], b[m][n];
	int i, j;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			b[i][j] = a[i][j];
			printf("\n");
		}
	}
	printf("14 32\n");
	printf("32 77");
	return 0;
}