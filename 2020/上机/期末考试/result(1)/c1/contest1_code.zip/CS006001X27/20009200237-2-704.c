#include <stdio.h>

int main() {
	int n, i, ji = 0, ou = 0, x = 0, max = 0;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			ou++;
		if (i % 2 != 0)
			ji++;
		if (i % 3 != 0 && i % 4 == 0)
			x++;
	}
	if (ji > ou)
		max = ji;
	else
		max = ou;
	printf("%d %d %d\n%d", ji, ou, x, max);
	return 0;
}