#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int n = 0, arr0[100], arr[10][10] = {0};
	scanf("%d", &n);
	for (int i = 0; i < n * n; i++) {
		scanf("%d", &arr0[i]);
	}
	for (int i1 = n * n - 1; i1 >= 0; i1--) {
		for (int i2 = 0; i2 < i1; i2++) {
			if (arr0[i2] > arr0[i2 + 1]) {
				int temp = arr0[i2];
				arr0[i2] = arr0[i2 + 1];
				arr0[i2 + 1] = temp;
			}
		}
	}
	int i0 = 0;
	for (int i1 = 0; i1 < n; i1++) {
		for (int i2 = 0; i2 < n; i2++) {
			arr[i2][i1] = arr0[i0];
			i0++;
		}
	}
	for (int i1 = 0; i1 < n; i1++) {
		for (int i2 = 0; i2 < n; i2++) {
			if (i2 == n - 1) {
				printf("%d\n", arr[i1][i2]);
			} else {
				printf("%d ", arr[i1][i2]);
			}
		}
	}
	return 0;
}