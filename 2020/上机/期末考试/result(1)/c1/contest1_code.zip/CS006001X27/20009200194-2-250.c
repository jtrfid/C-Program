#include <stdio.h>
#include <string.h>

int main() {
	int n, i, t = 0, q = 0, d = 0, s;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			d++;
		} else
			q++;
		if (i % 4 == 0 && i % 3 != 0) {
			t++;
		}
	}
	s = t;
	if (d > s) {
		s = d;
		if (q > s) {
			s = q;
		}
	} else if (q > s) {
		s = q;
	}
	printf("%d %d %d\n", q, d, t);
	printf("%d", s);



	return 0;
}
