#include <stdio.h>
#include <string.h>

int main() {
	int n, a[100], i, t;
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	int temp, k, m = 0;

	for (i = 0; i < n * n ; i++) {
		for (t = i + 1, k = i; t < n * n ; t++) {
			if (a[t] < a[k])
				k = t;
		}
		if (k != i) {
			temp = a[i];
			a[i] = a[k];
			a[k] = temp;
		}
	}

	int b[10][10];
	for (i = 0; i < n; i++) {
		for (t = 0; t < n; t++) {
			b[t][i] = a[m];
			m++;
		}
	}
	for (i = 0; i < n; i++) {
		for (t = 0; t < n; t++) {
			printf("%d ", b[i][t]);
		}
		printf("\n");
	}



	return 0;
}
