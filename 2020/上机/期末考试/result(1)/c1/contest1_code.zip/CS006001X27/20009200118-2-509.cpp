#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n, oushu = 0, jishu = 0, teshu = 0, max = 0, fang, i;
	scanf("%d", &n);
	fang = n * n;
	for (i = n; i <= fang; i++) {
		if (i % 2 == 0) {
			oushu++;
		}
		if (i % 2 != 0) {
			jishu++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			teshu++;
		}
	}
	int a[2];
	a[0] = jishu;
	a[1] = oushu;
	a[2] = teshu;
	for (i = 0; i < 3; i++) {
		if (a[i] > max) {
			max = a[i];
		}
	}
	printf("%d %d %d\n", jishu, oushu, teshu);
	printf("%d", max);


	return 0;
}