//2
#include <stdio.h>

void swap(int *a, int *b) {
	int t;
	t = *a;
	*a = *b;
	*b = t;
}

int main() {
	int n, i, j, x = 0;
	scanf("%d", &n);
	int a[n * n];
	int b[n][n];
	for (i = 0; i < n * n; i++)
		scanf("%d", &a[i]);

	for (i = 0; i < n * n - 1; i++) {
		for (j = i + 1; j < n * n; j++) {
			if (a[i] > a[j])
				swap(&a[i], &a[j]);
		}
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[x];
			x++;
		}
	}
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++) {
			if (j == n - 1)
				printf("%d\n", b[i][j]);
			else
				printf("%d ", b[i][j]);
		}
	return 0;
}

