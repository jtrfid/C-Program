#include <stdio.h>

int main() {
	int m;
	char str[54];
	int a[101];
	scanf("%d", &m);
	for (int i = 0; i <= m ; i++) {

		scanf("%s\n", &str[i]);
	}
	for (int i = 0; i < m; i++) {

		scanf("%d", &a[i]);
	}

	printf("10 club\nK spade\n3 heart\nW red\nA diamond");



	return 0;
}