#include <stdio.h>

int main() {
	int n, i, j, t;
	scanf("%d", &n);
	int c = n * n, a[c];
	for (i = 0; i < c; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < c; i++) {
		for (j = i + 1; j < c; j++) {
			if (a[i] > a[j]) {
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i + n * j]);
		}
		printf("\n");
	}
	return 0;
}