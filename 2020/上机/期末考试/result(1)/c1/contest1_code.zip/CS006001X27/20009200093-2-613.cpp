#include <stdio.h>

int main() {
	int n;
	int a, b, c, max, i, p;
	a = 0;
	b = 0;
	c = 0;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			a++;
		else
			b++;
		if ((i % 4 == 0) && (i % 3 != 0))
			c++;

	}
	if (a > b)
		max = a;
	else
		max = b;
	if (c > max)
		max = c;
	printf("%d %d %d\n", b, a, c);
	printf("%d", max);
	return 0;
}