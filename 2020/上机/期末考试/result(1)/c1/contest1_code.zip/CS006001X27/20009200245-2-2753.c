//1
#include <stdio.h>

int main() {
	int n, i, j;
	int a = 0, b = 0, c = 0, max;
	scanf("%d", &n);

	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			a++;
		else
			b++;
		if (i % 4 == 0 && i % 3 != 0)
			c++;
	}

	if (a > b)
		max = a;
	else
		max = b;

	if (max > c)
		max = max;
	else
		max = c;

	printf("%d %d %d\n%d", b, a, c, max);

	return 0;
}