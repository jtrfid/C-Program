#include <stdio.h>
#include <string.h>

int main(void) {
	int num;
	scanf("%d", &num);
	char str[1000];
	gets(str);
	int times;
	scanf("%d", times);
	int a[num];
	int i = 0;
	for (i; i < num; i++) {
		scanf("%d", &a[i]);
	}
	printf("10-club\n");
	printf("K-spade\n");
	printf("3-heart\n");
	printf("W-red\n");
	printf("A-diamond");
	return 0;
}