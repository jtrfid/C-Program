#include <stdio.h>

int main() {
	int n, temp;
	scanf("%d", &n);
	int a[n][n];
	int b[n * n];
	for (int i = 0; i < n * n; i++) {
		scanf("%d", &b[i]);
	}
	for (int i = 0; i < n * n - 1 ; i++) {
		int k = 1;
		for (int j = 0; j < n * n - k; j++) {
			if (b[j] > b[j + 1]) {
				temp = b[j];
				b[j] = b[j + 1];
				b[j + 1] = temp;
			}
		}
		k++;
	}
	/*for (int i = 0; i < n * n; i++) {
		printf("%d\n", b[i]);
	}*/


	for (int j = 0, i = 0; j < n; j++) {

		for (int k = 0; k < n; k++) {

			a[k][j] = b[i];
			i++;
		}
	}

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}