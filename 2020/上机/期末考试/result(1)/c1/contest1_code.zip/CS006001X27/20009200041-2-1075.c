#include <stdio.h>

int main() {
	int n;
	int num1[1000], num2[1000], num3[1000];

	int count1 = 0, count2 = 0, count3 = 0;
	scanf("%d", &n);
	int i;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			num1[count1] = i;
			count1++;
			if (i % 4 == 0 && i % 3 != 0) {
				num3[count3] = i;
				count3++;
			}
		} else if (i % 2 != 0) {
			num2[count2] = i;
			count2++;
		}
	}
	int max = 0;
	if (count2  >= count3  && count2 >= count1 ) {
		max = count2 ;
	} else if ( count3  >= count2 && count3  >= count1)  {
		max = count3 ;
	} else if (count1  >= count2 && count1 >= count3) {
		max = count1;
	}

	printf("%d %d %d\n", count2, count1, count3);

	printf("%d", max);
	return 0;
}