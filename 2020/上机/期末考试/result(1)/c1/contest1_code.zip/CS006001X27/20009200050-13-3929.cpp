#include <stdio.h>
#include <string.h>

int main() {
	int m, n;
	int x, y;
	int a[101][101], b[101][101];
	int c[101][101] = {0};
	int i, j;
	scanf("%d %d", &m, &n);
	int min;
	if (m <= n)
		min = m;
	if (m > n)
		min = n;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[j][i]);
		}
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			b[j][i] = a[i][j];
		}
	}

	if (m <= n) {
		for (i = 0; i < min; i++) {
			for (j = 0; j < min; j++) {
				for (x = 0; x < n; x++) {
					c[j][i] += a[x][i] * b[j][x];
				}
			}
		}
	}

	if (m > n) {
		for (i = 0; i < min; i++) {
			for (j = 0; j < min; j++) {
				for (x = 0; x < m; x++) {
					c[j][i] += b[x][i] * a[j][x];
				}
			}
		}
	}

	for (i = 0; i < min; i++) {
		for (j = 0; j < min; j++) {
			printf("%d ", c[j][i]);
			if (j == min - 1) {
				printf("\n");
			}
		}
	}
	return 0;
}