#include <stdio.h>

int main() {

	int m, n, t, i;
	scanf("%d", &n);
	int a = 0, b = 0, c = 0;
	m = n * n;
	for (i = n; i <= m; i++) {
		if (i % 2 == 1) {
			a++;
		}
		if (i % 2 == 0) {
			b++;
		}
		if ((i % 4 == 0) && (i % 3 != 0)) {
			c++;
		}
	}
	t = a;
	if (a < b) {
		t = b;
	}
	printf("%d %d %d\n%d", a, b, c, t);


	return 0;
}