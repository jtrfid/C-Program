#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
	int n;
	int m;
	vector<int> v;
	cin >> n;
	for (int i = 0; i < n * n; i++) {
		cin >> m;
		v.push_back(m);
	}
	sort(v.begin(), v.end());

	int a[10][10];
	int x = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			a[j][i] = v[x++];
		}
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cout << a[i][j] << ' ';
		}
		cout << endl;
	}
	return 0;
}