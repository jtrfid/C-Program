#include <stdio.h>

int main() {
	int i, j, k, a = 0, b = 0, c = 0, d = 0, e;
	scanf("%d", &e);
	for (i = e; i <= e * e; i++) {
		if (i % 2 == 0)
			b++;
		else
			a++;
		if (i % 4 == 0 && i % 3 != 0)
			c++;
	}
	if (d < a)
		d = a;
	if (d < b)
		d = b;
	if (d < c)
		d = c;

	printf("%d %d %d\n%d", a, b, c, d);
	return 0;
}