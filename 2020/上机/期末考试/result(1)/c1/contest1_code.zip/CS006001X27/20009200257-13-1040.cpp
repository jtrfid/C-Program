#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (!isdigit(ch))	{
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (isdigit(ch))	{
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
int m, n, a[11][11], b[11][11], c[11][11];

int main() {
	m = read();
	n = read();
	for (int i = 1; i <= m; ++i)
		for (int j = 1; j <= n; ++j)
			a[i][j] = read();
	for (int i = 1; i <= m; ++i)
		for (int j = 1; j <= n; ++j)
			b[j][i] = a[i][j];
	for (int i = 1; i <= m; ++i)
		for (int j = 1; j <= m; ++j)
			for (int k = 1; k <= n; ++k)
				c[i][j] += a[i][k] * b[k][j];
	for (int i = 1; i <= m; ++i) {
		for (int j = 1; j <= m; ++j)
			printf("%d ", c[i][j]);
		printf("\n");
	}

	return 0;
}