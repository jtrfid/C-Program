#include <stdio.h>
#include <string.h>

int main() {
	int n;
	int m = 0;
	int i, j;
	int a[100] = {0}, b[10][10] = {0};
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}

	for (i = 0; i < n * n - 1; i++) {
		for (j = 0; j < n * n - 1 - i; j++) {
			if (a[j] > a[j + 1]) {
				int t = a[j];
				a[j] = a[j + 1];
				a[j + 1] = t;
			}
		}
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			b[i][j] = a[m];
			m++;
		}
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[j][i]);
			if (j == n - 1) {
				printf("\n");
			}
		}
	}

	return 0;
}