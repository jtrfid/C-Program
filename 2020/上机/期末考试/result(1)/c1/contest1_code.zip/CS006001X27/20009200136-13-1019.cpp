#include <iostream>

using namespace std;

int n, m;
int a[100][100], b[100][100];
int f[100][100] = {0};

int main() {
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) {
			cin >> a[i][j];
			b[j][i] = a[i][j];
		}
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			for (int k = 1; k <= m; k++) {
				f[i][j] += a[i][k] * b[k][j];
			}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			cout << f[i][j] << " ";
		}
		cout << endl;
	}
}