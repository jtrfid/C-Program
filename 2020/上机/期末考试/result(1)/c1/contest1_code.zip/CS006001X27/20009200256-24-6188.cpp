#include <stdio.h>
#include <string.h>

int main() {
	int n, l, k;
	scanf("%d", &n);
	int c[n], d[n][2];
	for (int i = 0; i < n; i++) {
		d[i][0] = i;
	}
	char a[n][10], b[n][10];
	for (int i = 0; i < n; i++) {
		gets(a[i]);
	}
	scanf("%d", &k);
	for (int i = 0; i < n; i++) {
		scanf("%d", &c[i]);
		d[i][1] = c[i];
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < k - 1; j++) {
			d[i][1] = c[d[i][1]];
		}
	}
	for (int i = 0; i < n; i++) {
		l = strlen(a[i]);
		for (int j = 0; j < l; j++) {
			b[d[i][1] - 1][j] = a[i][j];
			//strcpy(b[d[i][2] - 1], a[i]);
		}
		//printf("-");
	}
	for (int i = 0; i < n; i++) {
		printf("%s\n", b[i]);
	}
	return 0;
}