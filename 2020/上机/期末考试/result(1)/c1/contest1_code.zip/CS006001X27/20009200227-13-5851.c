#include <stdio.h>

int main() {
	int n, m;
	scanf("%d%d", &m, &n);
	int a[m][n], b[n][m];
	int min;
	if (n >= m) {
		min = m;
	} else {
		min = n;
	}
	int c[m][m];
	int i, j, i1, j1;
	for (i = 0, i1 = 0; i < m; i++, i1++) {
		for (j = 0, j1 = 0; j < n; j++, j1++) {
			scanf("%d", &a[i][j]);
			b[j1][i1] = a[i][j];
			//printf("a[%d][%d]=%d---b[%d][%d]=%d\n", i, j, a[i][j], j1, i1, b[j1][i1]);
		}
	}
	int ji, ij;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			int sum = 0;
			for (ji = 0, ij = 0; ji < n; ji++, ij++) {
				sum = sum + a[i][ji] * b[ij][j];
				//printf("sum=%d i=%d\n", sum, i);
			}
			c[i][j] = sum;
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			if (j != m - 1)
				printf("%d ", c[i][j]);
			else if (j == m - 1) {
				printf("%d\n", c[i][j]);
			}
		}
	}




	return 0;
}
