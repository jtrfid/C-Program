#include <stdio.h>

int main() {
	int i;
	int n, num1 = 0, num2 = 0, num3 = 0, max = 0;

	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 != 0) {
			num1++;
		}
		if (i % 2 == 0) {
			num2++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			num3++;
		}
	}
	if (num1 > max) {
		max = num1;
	}
	if (num2 > max)
		max = num2;
	if (num3 > max)
		max = num3;
	printf("%d %d %d\n", num1, num2, num3);
	printf("%d", max);



	return 0;
}