#include <stdio.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);

	int aa[m][n], bb[n][m];
	int i1, i2, i3, i4, i5;
	for (i1 = 0; i1 <= m - 1; i1++) {
		for (i2 = 0; i2 <= n - 1; i2++) {
			scanf("%d", &aa[i1][i2]);

		}
	}
	for (i2 = 0; i2 <= m - 1; i2++) {
		for (i1 = 0; i1 <= n - 1; i1++) {
			bb[i1][i2] = aa[i2][i1];

		}
	}






	int cc[m][m];
	for (i3 = 0; i3 <= m - 1; i3++) {
		for (i4 = 0; i4 <= m - 1; i4++) {
			cc[i3][i4] = 0;
		}
	}
	int j, i0, k;



	for (i3 = 0; i3 <= m - 1; i3++) {
		for (i4 = 0; i4 <= m - 1; i4++) {
			i0 = i3;
			j = i4;
			k = 0;
			while (k <= n - 1) {
				cc[i3][i4] += aa[i0][k] * bb[k][j];
				k++;
				//printf("%d ", cc[i3][i4]);
			}
		}
	}


	for (i3 = 0; i3 <= m - 1; i3++) {
		for (i4 = 0; i4 <= m - 1; i4++) {
			printf("%d ", cc[i3][i4]);
		}
		printf("\n");
	}
	return 0;
}