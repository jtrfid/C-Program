#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

struct xinxi {
	char a;
	char b[20];
} stu[100], t;

int main() {
	int n, k;
	scanf("%d", &n);
	int i, j, u;
	for (i = 0; i <= n; i++) {
		gets(stu[i].b);
	}
	scanf("%d", &k);
	int c[100];
	for (i = 1; i <= n; i++) {
		scanf("%d", &c[i]);
	}
	while (k > 0) {
		for (i = 1; i <= n; i++) {
			for (j = 0 ; j <= n; j++) {
				if (j == c[i]) {
					t = stu[i];
					stu[i] = stu[j];
					stu[j] = t;
				}
			}
			k--;
		}
	}
	for (i = 0; i <= n; i++) {
		puts(stu[i].b);
	}
	return 0;
}