#include <stdio.h>
#include <string.h>

int main() {
	char o[60][12], p[60][12];
	int a, b, c, n, k;
	int l[100];
	scanf("%d", &n);
	getchar();
	for (a = 1; a <= n; a++)
		gets(o[a]);
	scanf("%d", &k);
	for (a = 1; a <= n; a++)
		scanf("%d", &l[a]);
	for (a = 1; a <= k; a++) {
		for (b = 1; b <= n; b++) {
			strcpy(p[b], o[b]);
		}
		for (c = 1; c <= n; c++)
			strcpy(o[l[c]], p[c]);
	}
	for (a = 1; a <= n; a++)
		puts(o[a]);
}