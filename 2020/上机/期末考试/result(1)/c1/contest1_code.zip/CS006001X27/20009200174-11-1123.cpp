#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n;
	scanf("%d", &n);
	int m = n * n;
	int a[m] = {};
	int i, j;
	for (i = 0; i < m; i++) {
		scanf("%d", &a[i]);
	}
	int t;
	for (i = 0; i < m - 1; i++) {
		for (j = 0; j < m - 1; j++) {
			if (a[j + 1] < a[j]) {
				t = a[j];
				a[j] = a[j + 1];
				a[j + 1] = t;
			}

		}
	}
	for (i = 0; i < n; i++) {
		for (j = i; j < m; j += n) {
			printf("%d ", a[j]);
		}
		printf("\n");

	}


	return 0;
}