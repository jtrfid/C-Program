#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	struct card {
		char num[20];
		char color[20];
	} card1[20], card2[20];
	int i;
	for (i = 0; i < n; i++) {
		scanf("%s %s", &card1[i].num, &card1[i].color);
	}
	int k;
	scanf("%d", &k);
	int a[100];
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	int t;
	int j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < n; j++) {
			t = a[j];
			card2[t] = card1[j];
		}

	}
	for (i = 0; i < n; i++) {
		printf("%s %s\n", card2[i].num, card2[i].color);
	}




	return 0;
}