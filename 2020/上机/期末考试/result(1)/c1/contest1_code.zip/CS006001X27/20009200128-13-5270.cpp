#include <stdio.h>
#include <string.h>

int main() {
	int m, s;
	int t = 0;
	scanf("%d %d", &m, &s);
	int juzheng[m][s];
	int i, j;
	int cu[m * s];
	int k = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < s; j++) {
			scanf("%d", &juzheng[i][j]);
			cu[k] = juzheng[i][j];
			k++;
		}
	}
	k = 0;
	int juzheng2[s][m];
	for (i = 0; i < m; i++) {
		for (j = 0; j < s; j++) {
			juzheng2[j][i] = cu[k];
			k++;
		}
	}
	int c[m][m];
	//for (i = 0; i < s; i++) {
	//	for (j = 0; j < m; j++) {
	//		printf("%d ", juzheng2[i][j]);
	//	}
	//	printf("\n");
	//}
	int a = 0;
	int b = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++ ) {
			c[i][j] = 0;
			for (a = 0, b = 0; a < s; a++, b++) {
				t = juzheng[i][a] * juzheng2[b][j];
				c[i][j] = c[i][j] + t;
			}

		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");



	}
	return 0;
}

