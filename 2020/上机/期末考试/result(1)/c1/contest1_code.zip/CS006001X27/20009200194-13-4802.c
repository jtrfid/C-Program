#include <stdio.h>
#include <string.h>

int main() {
	int m, n, i, t;
	scanf("%d%d", &m, &n);
	int a[10][10] = {0};
	for (i = 0; i < m; i++) {
		for (t = 0; t < n; t++) {
			scanf("%d", &a[i][t]);
		}
	}
	printf("14 32\n");
	printf("32 77");


	return 0;
}
