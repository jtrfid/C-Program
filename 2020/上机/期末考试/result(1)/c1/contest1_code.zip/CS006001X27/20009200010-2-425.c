#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int n;
	scanf("%d", &n);
	int a = n, b = n * n;
	int i, ji = 0, ou = 0, te = 0;
	for (i = a; i <= b; i++) {
		if (i % 2 == 0) {
			ou++;
		}
		if (i % 2 != 0) {
			ji++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			te++;
		}
	}
	printf("%d %d %d\n", ji, ou, te);
	int j = (ji > ou) ? ji : ou;
	printf("%d", j);
	return 0;
}