#include <stdio.h>

int main() {

	int m;

	scanf("%d", &m);

	int i, n = m * m;
	int a[n];

	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}

	int j, t;

	for (i = 0; i < n - 1; i++) {
		for (j = i + 1; j < n; j++) {
			if (a[i] > a[j]) {
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}
	}

	int array[m][m];
	int k;
	for (k = 0, i = 0; i < m; i++) {
		for (j = 0; j < m; k++, j++) {
			array[j][i] = a[i + k];
		}
		k--;
	}

	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", array[i][j]);
		}
		printf("\n");
	}

	return 0;
}