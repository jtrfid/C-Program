#include <stdio.h>

int main() {
	int n, m, i, j, p;
	scanf("%d%d", &m, &n);
	int a[m][n];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int c[m][m];
	for (i = 0; i < m; i++)
		for (j = 0; j < m; j++)
			c[i][j] = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (p = 0; p < n; p++) {
				c[i][j] = c[i][j] + a[i][p] * a[j][p];
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
	return 0;
}