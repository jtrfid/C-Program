#include <stdio.h>

int main() {
	int m, s;
	scanf("%d %d", &m, &s);
	int a[m][s];
	int b[s][m];
	int c[m][m];


	int i, j;
	for (i = 0; i < m; ++i) {
		for (j = 0; j < s; ++j) {
			scanf("%d", &a[i][j]);
		}
	}

	int k;
	for (i = 0; i < m; ++i) {
		for (j = 0; j < m; ++j) {
			c[i][j] = 0;
			for (k = 0; k < s; ++k) {
				c[i][j] += a[i][k] * a[j][k];
			}
		}
	}

	for (i = 0; i < m; ++i) {
		for (j = 0; j < m; ++j) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}


	return 0;
}