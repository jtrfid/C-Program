#include <stdio.h>

int main() {
	void sort(int a[], int n);
	int n;
	int i, j, k;
	scanf("%d", &n);
	int  a[100] = {0}, b[10][10] = {0};
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	sort(a, n * n);
	for (i = 0, k = 0; i < n; i++) {

		for (j = 0; j < n; j++) {
			b[j][i] = a[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}



	return 0;
}

void sort(int a[], int n) {
	int i, j, k;
	int temp;
	for (i = 0; i < n; i++) {
		k = i;
		for (j = i; j < n; j++) {
			if (a[k] > a[j])
				k = j;
		}
		if (k != i) {
			temp = a[i];
			a[i] = a[k];
			a[k] = temp;
		}
	}
}