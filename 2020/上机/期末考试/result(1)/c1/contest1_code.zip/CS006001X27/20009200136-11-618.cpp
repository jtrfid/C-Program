#include <iostream>
#include <algorithm>
using namespace std;


int n;
int a[100100];
int f[100][100];


int main() {
	cin >> n;
	for (int i = 1; i <= n * n; i++)
		cin >> a[i];
	sort(a + 1, a + n * n + 1);
	//for (int i = 1; i <= n * n; i++)
	//	cout << a[i] << " ";
	int k = 1;
	for (int j = 1; j <= n; j++)
		for (int i = 1; i <= n; i++) {
			f[i][j] = a[k];
			k++;
		}

	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			cout << f[i][j] << " ";
		}
		cout << endl;
	}
}