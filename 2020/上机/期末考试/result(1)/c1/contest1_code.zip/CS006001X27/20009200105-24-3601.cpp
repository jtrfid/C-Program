#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	typedef struct pai {
		int a;
		char b;
	} PAI;
	int n, l, i, j, k, m;
	int c[100];
	scanf("%d", &n);
	PAI pai[54];
	PAI xi[54];
	PAI hello;
	for (i = 0; i < n; i++) {
		scanf("%d%s", &pai[i].a, &pai[i].b);
	}
	scanf("%d", &l);
	for (i = 0; i < n; i++) {
		scanf("%d", &c[i]);
	}
	for (i = 0; i < l; i++) {
		for (j = 0; j < n; j++) {
			k = c[j];
			pai[j] = xi[k];
		}
		if (i != (l - 1)) {
			for (m = 0; m < n; m++) {
				pai[m] = xi[m];
			}
		}
	}
	for (i = 0; i < n; i++) {
		printf("%d %s\n", xi[i].a, xi[i].b);
	}
	return 0;

}