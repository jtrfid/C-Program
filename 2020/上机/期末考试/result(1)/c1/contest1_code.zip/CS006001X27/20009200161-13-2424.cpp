#include <iostream>
using namespace std;

int main() {
	int m, n;
	cin >> m >> n;
	int a[10][10] = {0};
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cin >> a[i][j];
		}
	} // ¼��a

// ��ʼ¼��b
	int b[10][10] = {0};
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			b[i][j] = a[j][i];
		}
	}

// ��ʼ���� c
	int c[10][10] = {0};
	int sum = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			sum = 0;
			for (int k = 0; k <= n - 1; k++) {
				sum += a[i][k] * b[k][j];
			}
			c[i][j] = sum;
			cout << c[i][j] << ' ';
		}
		cout << endl;
	}
	return 0;
}