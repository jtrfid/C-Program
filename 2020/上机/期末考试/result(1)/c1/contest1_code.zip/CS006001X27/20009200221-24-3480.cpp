#include <bits/stdc++.h>
using namespace std;
int n;
int i, j, wash[100];

struct card {
	string name1;
	string name2;
} a[100], temp;

struct card1 {
	string name3;
	string name4;
} b[100], temp1;

int main() {
	int n, n1, n2, number = 0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		cin >> a[i].name1 >> a[i].name2;
	}
	scanf("%d", &n1);
	while (cin >> n2) {
		wash[++number] = n2;
	}
	for (i = 1; i <= n1; i++) {
		for (j = 1; j <= number; j++) {
			b[wash[j]].name3 = a[j].name1;
			b[wash[j]].name4 = a[j].name2;
		}
		for (j = 1; j <= number; j++) {
			a[j].name1 = b[j].name3;
			a[j].name2 = b[j].name4;
		}
	}
	for (i = 1; i <= n; i++) {
		cout << a[i].name1 << " " << a[i].name2 << endl;
	}
	return 0;
}