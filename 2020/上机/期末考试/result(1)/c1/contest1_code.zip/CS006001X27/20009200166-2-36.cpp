#include <stdio.h>

int main() {
	int n, i, a = 0, b = 0, c = 0;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			a += 1;
		}
		if (i % 2 != 0) {
			b += 1;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			c += 1;
		}
	}
	int max = a;
	if (max < b) {
		max = b;
	}
	if (max < c) {
		max = c;
	}
	printf("%d %d %d\n%d", b, a, c, max);
	return 0;
}
