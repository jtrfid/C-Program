#include <stdio.h>

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	int a[m][n];
	int b[n][m];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			b[j][i] = a[i][j];
		}
	}
	int c[m][m];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			int sum = 0;
			for (int t = 0; t < n; t++) {
				sum += a[i][t] * b[t][j];
			}
			c[i][j] = sum;
		}
	}
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
	return 0;
}