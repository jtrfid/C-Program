#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int a = n, b = n * n, c = b - a + 1;
	int j, o, ge = 0, da = -1;
	if (n % 2 == 0) {
		j = (c - 1) / 2;
		o = (c + 1) / 2;
		da = o;
	} else {
		j = (c + 1) / 2;
		o = (c - 1) / 2;
		da = j;
	}
	for (int i = a; i <= b; i++) {
		if (i % 4 == 0 && i % 3 != 0)
			ge++;
	}
	if (ge > da)
		da = ge;
	printf("%d %d %d\n%d", j, o, ge, da);
	return 0;
}