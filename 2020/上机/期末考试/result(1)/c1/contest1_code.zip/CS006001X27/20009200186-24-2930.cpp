#include <stdio.h>

typedef struct {
	char number[3];
	char col[10];
} card;

int main() {
	card all[54];
	card next[54];
	int number;
	scanf("%d", &number);
	for (int n = 0; n < number; n++) {
		scanf("%s", all[n].number );
		scanf("%s", all[n].col );
	}
	int ci;
	scanf("%d", &ci);
	int list[100];
	for (int n = 0; n < number; n++) {
		scanf("%d", &list[n]);
	}
	for (int m = 0; m < ci; m++) {
		for (int n = 0; n < number; n++) {
			next[list[n] - 1] = all[n];
		}
		for (int n = 0; n < number; n++) {
			all[n] = next[n];
		}
	}
	for (int n = 0; n < number; n++) {
		printf("%s ", all[n].number );
		printf("%s\n", all[n].col );
	}

	return 0;
}