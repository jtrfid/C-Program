#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main() {

	int n, sum;
	scanf("%d", &n);
	sum = n * n;
	int i, j, k, a[sum];
	for (i = 0; i < sum; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < sum; i++) {
		for (j = i; j < sum; j++) {
			if (a[j] <= a[i]) {
				k = a[i];
				a[i] = a[j];
				a[j] = k;
			}
		}
	}
	int b[n][n];
	k = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (j != n - 1) {

				printf("%d ", b[i][j]);
			}
			if (j == n - 1) {
				printf("%d\n", b[i][j]);
			}

		}
	}










	return 0;
}