#include <stdio.h>
#include <stdlib.h>



int main() 
{
	int n;
	scanf("%d",&n);
	int i,countou=0,countji=0,count=0,max=0;
	for(i=n;i<=n*n;i++)
	{
		if(i%2==0)countou++;
		if(i%4==0&&i%3!=0)count++;	
	}	
	countji=n*n-n+1-countou;
	printf("%d %d %d\n",countji,countou,count);
	if(countji>countou)max=countji;
	else if(countji==countou)max=countji;
	else max=countou;
	if(max<=count)max=count;
	printf("%d",max);
	return 0;
}