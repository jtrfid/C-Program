#include <iostream>
#include <algorithm>
using namespace std;

struct card {
	int ar;
	string name;
};

bool cmp(card c, card d) {
	return c.ar > d.ar;
}

int main() {
	int n;
	cin >> n;
	int b[n];
	card a[n];
	for (int i = 0; i < n ; ++i) {
		a[i].ar = i + 2;
		getline(cin, a[i].name);
	}
	int ti, coun = 0;
	while (!(cin.peek() <= '9' && cin.peek() >= '0'))
		cin.get();
	cin >> ti;
	while (!(cin.peek() <= '9' && cin.peek() >= '0'))
		cin.get();
	for (int i = 0; i < n; ++i) {
		while (!(cin.peek() <= '9' && cin.peek() >= '0'))
			cin.get();
		cin >> b[i];
	}
	while (ti - coun > 0) {
		for (int i = 0; i < n; ++i) {
			a[i].ar = b[i];
		}
		sort(a, a + n, cmp);
		++coun;
	}
	for (int i = 0; i < n; ++i)
		cout << a[i].name;
}