#include <stdio.h>

int main() {
	int n, i, num[105], j, minn, tmpe;
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &num[i]);
	}
	for (i = 0; i < n * n; i++) {
		minn = i;
		for (j = i; j < n * n; j++) {
			if (num[j] < num[minn])
				minn = j;
		}
		tmpe = num[minn];
		num[minn] = num[i];
		num[i] = tmpe;
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", num[i + j * n]);
		}
		printf("\n");
	}
	return 0;
}