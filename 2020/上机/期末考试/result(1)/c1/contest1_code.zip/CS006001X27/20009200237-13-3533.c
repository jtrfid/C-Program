#include <stdio.h>

int main() {
	int n, m, i, j, k, l, t[10][10], x[10][10] = {0};
	scanf("%d %d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &t[i][j]);
	for (i = 0; i < m; i++)
		for (j = 0; j < m; j++)
			for (k = 0; k < n; k++) {
				x[i][j] += t[i][k] * t[j][k];
			}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++)
			printf("%d ", x[i][j]);
		printf("\n");
	}
	return 0;
}