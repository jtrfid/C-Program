#include <stdio.h>

int main() {
	int a[1000] = {0};
	int b[10][10] = {0};
	int n, i, j;
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < n * n; i++) {
		for (j = i; j < n * n; j++) {
			if (a[j] > a[i]) {
				int t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}
	}
	int n2 = n * n - 1;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[n2];
			n2--;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	return 0;
}