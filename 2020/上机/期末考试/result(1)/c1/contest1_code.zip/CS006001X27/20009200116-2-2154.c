#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n;
	scanf("%d", &n);

	int i = 0, c1 = 0, c2 = 0, c3 = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 1) {
			c1++;
		} else {
			c2++;
		}
	}
	for (i = n; i <= n * n; i++) {
		if (i % 4 == 0 && i % 3 != 0) {
			c3++;
		}
	}
	int b[3] = {c1, c2, c3}, x;
	for (i = 0; i < 3; i++) {
		if (b[i - 1] < b[i ]) {
			x = b[i - 1];
			b[i - 1] = b[i ];
			b[i] = x;
		}
	}
	printf("%d %d %d\n", c1, c2, c3);
	printf("%d", b[0]);



	return 0;
}