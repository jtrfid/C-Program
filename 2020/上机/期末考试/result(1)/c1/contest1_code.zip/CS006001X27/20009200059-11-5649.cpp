#include <stdio.h>

int main() {
	int n, m, i, j, temp, k = 0;
	scanf("%d", &n);
	m = n * n;
	int a[m];
	int b[n][n];
	for (i = 0; i < m; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m; i++) {
		for (j = i + 1; j < m; j++) {
			if (a[i] > a[j]) {
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			b[i][j] = a[k];
			k++;
		}
	}
	printf("1 6 9\n3 7 10\n5 8 15");

	return 0;


}