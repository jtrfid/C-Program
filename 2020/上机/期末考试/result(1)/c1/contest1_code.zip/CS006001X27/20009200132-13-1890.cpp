#include <stdio.h>

int main() {
	int m, n, a[10][10], b[10][10], c[10][10] = {0};
	scanf("%d %d", &m, &n);
	int i, j;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			b[i][j] = a[j][i];
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (int o = 0; o < n; o++) {
				c[i][j] += a[i][o] * b[o][j];
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
	return 0;
}