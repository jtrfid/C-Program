#include <stdio.h>

int main() {
	int n;
	int a[105];
	int b[15][15];
	scanf("%d", &n);
	for (int i = 1; i <= n * n; i++) {
		scanf("%d", &a[i]);
	}

	for (int i = 1; i < n * n ; i++) {
		for (int j = i + 1; j <= n * n ; j++)
			if (a[i] > a[j]) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
	}//maopao

	int num = 0;
	for (int i = 1; i <= n ; i++) {
		for (int j = 1; j <= n ; j++) {
			num++;
			b[j][i] = a[num];
		}
	}


	for (int i = 1; i <= n ; i++) {
		for (int j = 1; j <= n ; j++)
			printf("%d ", b[i][j]);
		printf("\n");


	}
	return 0;
}



