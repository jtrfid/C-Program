#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n1, n2;
	scanf("%d", &n1);
	n2 = n1 * n1;
	int i, j, a[n2], k;
	for (i = 0; i < n2; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < n2; i++) {
		for (j = i; j < n2; j++) {
			if (a[j] < a[i]) {
				k = a[i];
				a[i] = a[j];
				a[j] = k;
			}
		}
	}
	int b[n1][n1] = {0};
	k = 0;
	for (i = 0; i < n1; i++) {
		for (j = 0; j < n1; j++) {
			b[j][i] = a[k];
			k++;
		}
	}
	for (i = 0; i < n1; i++) {
		for (j = 0; j < n1; j++) {
			if (j != n1 - 1) {

				printf("%d ", b[i][j]);
			}
			if (j == n1 - 1 && i != n1 - 1) {
				printf("%d\n", b[i][j]);
			}
			if (j == n1 - 1 && i == n1 - 1) {
				printf("%d", b[i][j]);
			}
		}
	}











	return 0;
}