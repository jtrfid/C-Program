#include <stdio.h>
#include <string.h>

struct card {
	char numb[20];
	char type[20];
};
card a[100];
card b[100];
int c[100];

int main() {
	int n, i, j;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		scanf("%s %s", &a[i].numb, &a[i].type);

	}


	int times;
	scanf("%d", &times);
	card middle;
	for (i = 1; i <= n; i++) {
		scanf("%d", &c[i]);
	}
	for (j = 1; j <= times; j++) {
		for (i = 1; i <= n; i++) {
			b[c[i]] = a[i];
		}
		for (i = 1; i <= n; i++) {
			a[i] = b[i];
		}

	}
	for (i = 1; i <= n; i++) {
		printf("%s %s\n", a[i].numb, a[i].type);

	}




	return 0;





}
