#include <stdio.h>

int b[11][11] = {0};

int a[11][11] = {0};

int sum1(int n, int m) {
	int i, j, sum = 0;
	for (i = 0; i < n; i++) {
		sum = sum + (a[i][0] * b[0][i]);
		//	printf("%d %d\n", a[i][0], b[0][i]);
	}
	//aprintf("%d", sum);
	return sum;
}

int main() {
	int a[11][11] = {0};
	int copy[1000] = {0};

	int c[11][11] = {0};
	int n, m, i, j, k = 0;
	int sum[1000] = {0};
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			copy[k] = a[i][j];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			b[i][j] = copy[k];
			k++;
			//printf("%d ", b[i][j]);
		}
		//	printf("\n");
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			c[i][j] = sum1(i, j);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
























	/*for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			sum[k] += (a[i][j] * b[j][i]);
			k++;
		}
	}
	k = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			c[i][j] = sum[k];
			k++;
			printf("%d", c[i][j]);
		}
		printf("\n");
	}*/
	return 0;
}