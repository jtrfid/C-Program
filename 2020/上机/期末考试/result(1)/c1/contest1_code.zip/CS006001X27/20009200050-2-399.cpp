#include <stdio.h>
#include <string.h>

int main() {
	int n;
	int i, j;
	int count[3] = {0};
	scanf("%d", &n);

	for (i = n; i <= n * n; i++) {
		if (i % 2 == 1) {
			count[0]++;
		}
		if (i % 2 == 0) {
			count[1]++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			count[2]++;
		}
	}

	printf("%d %d %d\n", count[0], count[1], count[2]);

	for (i = 0; i < 2; i++) {
		for (j = 0; j < 2 - i; j++) {
			if (count[i] < count[i + 1]) {
				int t = count[i];
				count[i] = count[i + 1];
				count[i + 1] = t;
			}
		}
	}

	printf("%d", count[0]);
	return 0;
}