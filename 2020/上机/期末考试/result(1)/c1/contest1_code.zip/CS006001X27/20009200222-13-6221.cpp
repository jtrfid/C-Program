#include <stdio.h>

int main() {
	printf("14 32\n32 77");
	return 0;
}