#include <stdio.h>
#include <string.h>

int main() {
	int x, i, ji = 0, ou = 0, special = 0, max = 0;
	scanf("%d", &x);
	for (i = x; i <= x * x; i++) {
		if (i % 2 == 0)
			ou++;
		else
			ji++;
		if (i % 4 == 0 && i % 3 != 0)
			special++;
	}
	max = ji;
	if (max < ou)
		max = ou;
	if (max < special)
		max = special;
	printf("%d %d %d\n%d", ji, ou, special, max);
}