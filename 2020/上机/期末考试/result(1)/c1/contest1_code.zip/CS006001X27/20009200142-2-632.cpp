#include <stdio.h>
#include <math.h>

int main() {
	int a, b, c, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, x = 0;
	scanf("%d", &a);
	b = a * a;
	for (c = a; c <= b; c++) {
		if (c % 2 != 0) {
			f += 1;
			if (c > d) {
				d = c;
			}
		}
		if (c % 2 == 0) {
			g += 1;
			if (c > e) {
				e = c;
			}

		}
		if (c % 4 == 0 && c % 3 != 0) {

			h += 1;
			if (c > i) {
				i = c;
			}
		}
	}
	if (f > g) {
		x = f;
	}
	if (g > f) {
		x = g;
	}
	if (h > x) {
		x = h;
	}
	printf("%d %d %d\n%d", f, g, h, x);

}