#include <stdio.h>

int main() {

	int n, c, tem, x = 0, y = 0, k = 0, d = 0, a[100], b[10][10], j = 0;

	scanf("%d", &n);
	c = n * n;
	for (int i = 0; i < c; i++) {
		scanf("%d", &a[i]);
	}
	//for (int i = 0; i < n * n; i++)
	//	printf("%d ", a[i]);


	for (j; j < (n * n / 2) ; j++) {

		if (a[j] >= a[j + 1]) {
			tem = a[j];
			a[j] = a[j + 1];
			a[j + 1] = tem;
			for (int b = 0; b < (n * n / 2) ; b++) {
				if (a[j] >= a[b + 1]) {
					tem = a[j];
					a[j] = a[b + 1];
					a[b + 1] = tem;
				}
			}
		}
	}
	for (int i = 0; i < n * n; i++)
		printf("%d ", a[i]);
	for (y; y < n; y++) {
		for (x; x < n; x++) {
			for (k; k < n * n; k++) {
				b[x][y] = a[k];
			}
		}

	}


	for (y; y < n; y++) {
		for (x; x < n; x++) {
			printf("%d", b[x][y]);
		}
	}


	return 0;
}