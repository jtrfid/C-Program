#include <bits/stdc++.h>
using namespace std;
int jvzhen[11][11];
int zhuanzhi[11][11];

int c[11][11] = {};
int i, j;

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	for (i = 1; i <= m; i++) {
		for (j = 1; j <= n; j++) {
			scanf("%d", &jvzhen[i][j]);
			zhuanzhi[j][i] = jvzhen[i][j];
		}
	}
	int chengji = m * n;
	for (i = 1; i <= m; i++) {
		for (j = 1; j <= m; j++) {
			for (int k = 1; k <= chengji; k++) {
				c[i][j] += jvzhen[i][k] * zhuanzhi[k][j];
			}
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
	return 0;
}