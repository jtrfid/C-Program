#include <stdio.h>

int main() {
	int i, x, y, m, n;
	scanf("%d%d", &m, &n);
	int a[m][n];
	for (x = 0; x < m; x++)
		for (y = 0; y < n; y++)
			scanf("%d", &a[x][y]);

	int c[m][m];
	for (x = 0; x < m; x++)
		for (y = 0; y < m; y++) {
			c[x][y] = 0;
			for (i = 0; i < n; i++)
				c[x][y] = c[x][y] + a[x][i] * a[y][i];
		}

	for (x = 0; x < m; x++) {
		for (y = 0; y < m; y++)
			printf("%d ", c[x][y]);
		printf("\n");
	}

	return 0;
}