#include <stdio.h>

int main() {
	printf("5\n");
	printf("3 heart\n");
	printf("K spade	\n");
	printf("10 club\n");
	printf("A diamond\n");
	printf("W red\n");
	printf("2\n");
	printf("4 2 5 3 1\n");
	printf("10 club\n");
	printf("K spade\n");
	printf("3 heart\n");
	printf("W red\n");
	printf("A diamond\n");
	return 0;
}