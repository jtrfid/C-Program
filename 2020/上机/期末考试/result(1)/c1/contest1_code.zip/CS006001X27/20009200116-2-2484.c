#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n;
	scanf("%d", &n);

	int i = 0, c1 = 0, c2 = 0, c3 = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 1) {
			c1++;
		} else {
			c2++;
		}
	}
	for (i = n; i <= n * n; i++) {
		if (i % 4 == 0 && i % 3 != 0) {
			c3++;
		}
	}
	int max;
	if (c1 < c2) {
		max = c2;
		if (c2 < c3) {
			max = c3;
		}

		else {
			max = c2;
		}

	}
	if (c2 < c1) {
		max = c1;
		if (c1 < c3) {
			max = c3;
		}

		else {
			max = c1;
		}

	}
	if (c2 < c3) {
		max = c3;
		if (c3 < c1) {
			max = c1;
		}

		else {
			max = c3;
		}

	}
	printf("%d %d %d\n", c1, c2, c3);

	printf("%d", max);



	return 0;
}