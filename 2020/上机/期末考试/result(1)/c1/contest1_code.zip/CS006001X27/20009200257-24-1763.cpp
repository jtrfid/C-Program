#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (!isdigit(ch))	{
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (isdigit(ch))	{
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
int n, k, a[100010];
string s1[1001], s2[1001];

int main() {
	n = read();
	for (int i = 1; i <= n; ++i)
		getline(cin, s1[i]);
	k = read();
	for (int i = 1; i <= n; ++i)
		a[i] = read();
	while (k--) {
		for (int i = 1; i <= n; ++i)
			s2[a[i]] = s1[i];
		for (int i = 1; i <= n; ++i)
			s1[i] = s2[i];
	}
	for (int i = 1; i <= n; ++i)
		cout << s1[i] << endl;
	return 0;
}