#include <stdio.h>

int main() {
	int n, m, i, j, temp = 0, k = 0;
	scanf("%d", &n);
	m = n * n;
	int a[m] = {0};
	int b[n][n] = {{0}};
	for (i = 0; i < m; i++)
		scanf("%d", &a[i]);
	for (i = 0; i < m - 1; i++) {
		for (j = m - 1; j > i; j--) {
			if (a[j - 1] > a[j]) {
				temp = a[j - 1];
				a[j - 1] = a[j];
				a[j] = temp;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; i < n; j++) {
			b[j][i] = a[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", b[i][j]);
	}
	return 0;
}