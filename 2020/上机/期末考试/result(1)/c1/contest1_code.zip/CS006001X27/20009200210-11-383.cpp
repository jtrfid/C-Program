#include <bits/stdc++.h>
using namespace std;

int main() {
	int n, a[200];
	cin >> n;
	for (int i = 1; i <= n * n; i++) {
		cin >> a[i];
	}
	sort(a + 1, a + 1 + n * n);
	for (int i = 1; i <= n; i++) {
		for (int j = i; j <= n * n; j += n) {
			cout << a[j] << " ";
		}
		cout << endl;
	}
	return 0;
}