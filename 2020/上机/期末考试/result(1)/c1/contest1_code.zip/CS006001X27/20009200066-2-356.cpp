#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, j, max;
	int count_oushu = 0, count_jishu = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			count_oushu++;
		else
			count_jishu++;
	}
	if (count_oushu > count_jishu)
		max = count_oushu;
	else
		max = count_jishu;
	int count = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 4 == 0 && i % 3 != 0)
			count++;
	}
	if (count > max)
		max = count;
	printf("%d %d %d\n%d", count_jishu, count_oushu, count, max);
	return 0;
}