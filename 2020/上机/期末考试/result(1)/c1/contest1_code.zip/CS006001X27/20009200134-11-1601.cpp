#include <stdio.h>

void swap(int *x, int *y) {
	int t = *x;
	*x = *y;
	*y = t;
}

int main() {
	int n;
	scanf("%d", &n);

	int ans[10][10] = {0};
	int a[100] = {0};
	for (int i = 0; i < n * n ; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 0 ; i < n * n ; i++) {
		for (int j = 0 ; j < n * n ; j++) {
			if (a[i] < a[j])
				swap(&a[i], &a[j]);
		}
	}

	int p = 0;

	for (int i = 0 ; i < n ; i++) {
		for (int j = 0 ; j < n ; j++) {
			ans[j][i] = a[p];
			p++;
		}
	}

	for (int i = 0 ; i < n ; i++) {
		for (int j = 0 ; j < n ; j++) {
			printf("%d ", ans[i][j]);
		}
		printf("\n");
	}

	return 0;
}