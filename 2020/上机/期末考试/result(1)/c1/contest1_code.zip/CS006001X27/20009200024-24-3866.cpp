#include <stdio.h>
#include <string.h>

struct STUDENT {
	char a[20];
} num[20], stu[20];

int main() {

	int m, n, t, j, i;
	int co[20];
	scanf("%d", &n);
	for (i = 1; i <= 1 + n; i++) {
		gets(num[i].a);
	}
	scanf("%d", &m);
	//printf("%d", m);
	for (i = 1; i <= n; i++) {
		scanf("%d", &co[i]);
		//	printf("%d", co[i]);
	}
	for (j = 0; j <= m; j++) {
		for (i = 1; i <= n; i++) {

			t = co[i] + 1;
			stu[t] = num[i];
		}
		for (i = 1; i <= n; i++) {
			num[i] = stu[i];
		}
	}
	for (i = 1; i <= 1 + n; i++) {
		printf("%s\n", stu[i].a );
	}




	return 0;
}