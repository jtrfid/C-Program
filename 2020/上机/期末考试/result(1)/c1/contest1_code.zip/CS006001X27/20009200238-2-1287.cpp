#include <stdio.h>
int main()

{
	int n, m;
	for (n > 1 && n < 1000; m >= n && m <= n ^ 2) {
		if (m % 2 != 0)
			printf( % d, m);
		break;
	}
	{
		else if (m % 2 == 0)
			printf( % d, m);
		break;
	}
	{
		else if (m % 4 == 0 && m % 3 != 0)
			printf( % d, m);
		break;
	}
	return 0;

}