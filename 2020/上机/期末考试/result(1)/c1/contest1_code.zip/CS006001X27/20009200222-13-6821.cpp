#include <stdio.h>

int main() {
	int xa, xb, ya, yb, x, y;

	scanf("%d %d", &x, &y);
	int re[x][x];
	xa = x;
	xb = y;
	ya = y;
	yb = x;
	int a[xa][ya], b[xb][yb];
	int q = 0, w = 0, e = 0, r = 0;
	while (q != xa) {
		scanf("%d", &x);
		a[q][w] = x;
		b[w][q] = x;
		if (w == ya - 1) {
			w = 0;
			q++;
		} else {
			w++;
		}
	}
	while (r != xa) {
		int s = 0;
		int o = 0;
		while (o <= ya - 1) {
			s = s + a[e][o] * b[o][r];
			o++;
		}
		re[e][r] = s;
		if (e == xa - 1) {
			e = 0;
			r++;
		} else {
			e++;
		}
	}
	q = 0;
	w = 0;
	while (w != xa) {
		printf("%d", re[q][w]);
		if (q == xa - 1) {
			q = 0;
			w++;
			printf("\n");
		} else {
			q++;
			printf(" ");
		}
	}
	return 0;
}