#include <stdio.h>
#include <stdlib.h>



int main() 
{
	int n;
	scanf("%d",&n);
	int m;
	m=n*n;
	int i,b[100];
	for(i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
	}
	int j,t;
	for(j=0;j<m-1;j++)
	{
		for(i=0;i<m-1-j;i++)
		{
			if(b[i]>b[i+1])
			{
				t=b[i+1];
				b[i+1]=b[i];
				b[i]=t;
			}
		}
	}
	int h=0;
	int c[10][10];
	for(j=0;j<n;j++)
	{
		for(i=0;i<n;i++)
		{
			c[i][j]=b[h];
			h++;
		}
	}
	for(j=0;j<n;j++)
	{
		for(i=0;i<n;i++)
		{
			printf("%d ",c[j][i]);
		}
		printf("\n");
	}
	return 0;
}