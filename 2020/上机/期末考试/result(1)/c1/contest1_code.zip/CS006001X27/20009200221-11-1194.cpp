#include <bits/stdc++.h>
using namespace std;
int a[101], i, j;
int b[11][11];

int main() {
	int n;
	scanf("%d", &n);
	int x = n * n;
	for (i = 1; i <= x; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 1; i < x; i++) {
		for (j = i + 1; j <= x; j++) {
			if (a[i] > a[j]) {
				swap(a[i], a[j]);
			}
		}
	}
	int number = 0;
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			b[j][i] = a[++number];
		}
	}
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	return 0;
}