#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n;
	scanf("%d", &n);
	int i = 0, b[10000], x;
	for (i = 0; i < n * n; i++) {
		scanf("%d", b[i]);
	}
	for (i = 0; i < n * n; i++) {
		if (b[i - 1] > b[i ]) {
			x = b[i];
			b[i] = b[i + 1];
			b[i + 1] = x;
		}
	}
	int c[100][100];
	int j = 0, w = 0;
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			for (w = 0; w < n * n; w++) {
				c[i][j] = b[w];
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d", c[i][j]);
		}
	}

	return 0;
}