#include <stdio.h>

int main() {
	int m, n, i, j, x = 0, y = 0;
	scanf("%d %d", &m, &n);
	int a[m][n] = {0};
	int b[n][m] = {0};
	int c[m][m] = {0};
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++)
			b[i][j] = a[j][i];
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++)
			c[i][j] = 0;
	}
	for (x = 0; x < m; x++) {
		for (y = 0; y < m; y++) {
			for (j = 0; j < n; j++)
				c[x][y] = c[x][y] + a[x][j] * b[j][y];
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++)
			printf("%d  ", c[i][j]);
		puts("");
	}
	return 0;
}