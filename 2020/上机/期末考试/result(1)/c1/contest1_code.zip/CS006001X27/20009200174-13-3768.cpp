#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, j;
	int a[m][n] = {};
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int b[n][m] = {};
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			b[i][j] = a[j][i];
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	int c[m][m] = {};
	int ans = 0;
	int k;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (ans = 0, k = 0; k < n; k++) {
				ans += a[i][k] * b[k][j];

			}

			c[i][j] = ans;
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}


	return 0;
}