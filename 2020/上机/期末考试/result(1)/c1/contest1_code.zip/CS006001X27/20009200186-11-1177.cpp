#include <stdio.h>

int main() {
	int number;
	scanf("%d", &number);
	int list[100];
	for (int n = 0; n < number * number; n++) {
		scanf("%d", &list[n]);
	}
	int temp;
	for (int n = 0; n < number * number - 1; n++) {
		for (int m = 0; m < number * number - 1 - n; m++) {
			if (list[m] > list[m + 1]) {
				temp = list[m];
				list[m] = list[m + 1];
				list[m + 1] = temp;
			}
		}
	}
	for (int n = 0; n < number; n++) {
		for (int m = 0; m < number; m++) {
			printf("%d ", list[m * number + n]);
		}
		printf("\n");
	}
	return 0;
}