#include <stdio.h>

int main() {
	int count = 0;
	int num = 0;
	int n;
	scanf("%d", &n);

	for (int i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			count++;
		if (i % 4 == 0 && i % 3 != 0)
			num++;

	}
	int a = n * n - n + 1 - count;
	printf("%d %d %d\n", a, count, num);

	int max;
	if (count > num)
		max = count;
	else
		max = num;
	if (a > max)
		max = a ;
	else
		max = a;
	printf("%d", max);

	return 0;
}