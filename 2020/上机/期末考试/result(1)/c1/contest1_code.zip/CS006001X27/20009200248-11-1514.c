#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int n, i, j, temp = 0;
	scanf("%d", &n);
	int len = n * n;
	int a[len];
	int cnt = 0;
	for (i = 0; i < len; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 1; i < len; i++) {
		for (j = len - 1; j >= i; j--) {
			if (a[j - 1] > a[j]) {
				temp = a[j - 1];
				a[j - 1] = a[j];
				a[j] = temp;
			}
		}
	}
	for (i = 0; i < len; i++) {
		printf("%d ", a[i]);
		if ((i + 1) % n == 0)
			printf("\n");
	}
	return 0;
}