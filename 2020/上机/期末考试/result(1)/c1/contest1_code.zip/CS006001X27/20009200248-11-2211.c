#include <stdio.h>

int main() {
	int i, j, temp = 0;
	int n;
	scanf("%d", &n);
	int len = n * n;
	int a[100] = {0};
	int cnt = 0;
	for (i = 0; i < len; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 1; i < len; i++) {
		for (j = len - 1; j >= i; j--) {
			if (a[j - 1] > a[j]) {
				temp = a[j - 1];
				a[j - 1] = a[j];
				a[j] = temp;
			}
		}
	}
	int b[n][n];
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[cnt++];
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	return 0;
}