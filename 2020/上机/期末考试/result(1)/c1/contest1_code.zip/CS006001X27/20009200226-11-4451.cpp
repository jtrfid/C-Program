#include <stdio.h>

int main() {
	int n, i, j;
	scanf("%d", &n);
	int t = n * n;
	int a[t];
	for (i = 0; i < t; i++) {
		scanf("%d", &a[i]);
	}
	int m;
	for (i = 0; i < t; i++) {
		for (j = i + 1; j < t; j++) {
			if (a[i] >= a[j]) {
				m = a[i];
				a[i] = a[j];
				a[j] = m;
			}
		}
	}
	int b[n][n];
	int c = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[c];
			c++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	return 0;
}