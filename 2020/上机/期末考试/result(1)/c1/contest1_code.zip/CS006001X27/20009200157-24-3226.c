#include <stdio.h>

int main() {
	int N, n, num[60], i, j, q[105], sum[60];
	char a[60][30];
	scanf("%d", &N);
	for (i = 0; i <= N ; i++) {
		gets(a[i]);
	}
	scanf("%d", &n);
	for (i = 0; i < N; i++) {
		scanf("%d", &q[i]);
	}
	for (i = 1; i <= N; i++) {
		num[i] = i;
	}
	for (i = 0; i < n; i++) {
		for (j = 1; j <= N; j++) {
			sum[q[j - 1]] = num[j];
		}
		for (j = 1; j <= N; j++) {
			num[j] = sum[j];
		}
	}
	for (i = 1; i <= N; i++) {
		printf("%s\n", a[sum[i]]);
	}
	return 0;
}