#include <stdio.h>

int main() {
	int a, b = 0, c = 0, d = 0, i, i1, i2, i3, i4, i5, i6, i7, n, m;
	scanf("%d", &a);

	for (i = a; i <= a * a; i++) {
		i1 = i ;
		i2 = (i - i1) % 10;
		i3 = (i - i1 - i2) % 100;
		i4 = (i - i1 - i2 - i3) % 1000;
		i5 = (i - i1 - i2 - i3 - i4) % 10000;
		i6 = (i - i1 - i2 - i3 - i4 - i5) % 100000;
		i7 = (i - i1 - i2 - i3 - i4 - i5 - i6) % 1000000;
		n = i1 + i2 + i3 + i4 + i5 + i6 + i7;
		if (i % 2 == 0 ) {
			b++;
		}
		if (i % 2 != 0 ) {
			c++;
		}
		if ( i % 4 == 0 && n % 3 != 0 ) {
			d++;
		}
	}
	if (b >= c && b >= d)
		m = b;
	if (c >= b && c >= d)
		m = c;
	if (d >= b && d >= c)
		m = d;
	printf("%d %d %d\n%d", b, c, d, m);







	return 0;
}