#include <stdio.h>

int main(void) {
	int n;
	scanf("%d", &n);
	int a[n * n];
	int i = 0;
	for (i; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	int j, ret;
	for (j = 0; j < n * n; j++) {
		int k = j + 1;
		for (k; k < n * n; k++) {
			if (a[k] < a[j]) {
				ret = a[k];
				a[k] = a[j];
				a[j] = ret;
			}
		}
	}
	int p = 0;
	for (p; p < n; p++) {
		int q = 0;
		for (q; q < n; q++) {
			printf("%d ", a[p + q * n]);
		}
		printf("\n");
	}
	return 0;
}