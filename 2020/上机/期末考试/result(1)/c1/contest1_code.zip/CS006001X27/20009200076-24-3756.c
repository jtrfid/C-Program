#include <stdio.h>
#include <string.h>

typedef struct {
	char a[10];
	char b[10];
} Paise;

int main() {
	int N, K;
	scanf("%d", &N);
	int i;
	int a[54];
	Paise pai[54];
	Paise pai1[54];
	int x, y;
	for (i = 0; i < N; i++) {
		scanf("%s %s", &pai[i].a, &pai[i].b);
		x = strlen(pai[i].b);
		y = strlen(pai[i].a);
		pai[i].b[x] = '\0';
		pai[i].a[y] = '\0';
	}
	scanf("%d", &K);
	for (i = 0; i < N; i++) {
		scanf("%d", &a[i]);
	}
	int t;
	int min;
	for (t = 0; t < K; t++) {
		for (i = 0; i < N; i++) {
			min = a[i] - 1;
			pai1[min] = pai[i];
		}
		for (i = 0; i < N; i++) {
			pai[i] = pai1[i];
		}
	}
	for (i = 0; i < N; i++) {
		printf("%s %s\n", pai1[i].a, pai1[i].b);
	}
	return 0;
}