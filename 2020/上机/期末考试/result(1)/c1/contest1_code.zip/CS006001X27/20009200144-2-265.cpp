#include <stdio.h>

int main() {

	int n;

	scanf("%d", &n);

	int i;

	int num1 = 0, num2 = 0, num3 = 0;

	for (i = n; i <= n * n; i++) {
		if (i % 2 == 1)
			num1++;
		if (i % 2 == 0)
			num2++;
		if (i % 4 == 0 && i % 3 != 0)
			num3++;
	}

	int max = num1;

	if (max < num2)
		max = num2;
	if (max < num3)
		max = num3;


	printf("%d %d %d\n", num1, num2, num3);
	printf("%d", max);


	return 0;
}