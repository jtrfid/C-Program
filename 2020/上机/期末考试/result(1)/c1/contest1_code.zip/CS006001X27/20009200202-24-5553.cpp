#include <stdio.h>

struct pai {
	char b[10];
};

int main() {
	int i, i1, n, k, j;
	scanf("%d\n", &n);
	struct pai a[n];
	struct pai d[n];
	for (i = 0; i < n; i++) {
		gets(a[i].b);
	}
	scanf("%d", &k);

	int c[n];
	for (i = 0; i < n; i++)
		scanf("%d", &c[i]);

	for (i1 = 0; i1 < k; i1++) {
		for (i = 0; i < n ; i++)
			for (j = 0; j < 10; j++)
				d[c[i] - 1].b[j] = a[i].b[j];
		for (i = 0; i < n ; i++)
			for (j = 0; j < 10; j++)
				a[i].b[j] = d[i].b[j];
	}

	for (i = 0; i < n; i++) {
		printf("%s\n", a[i].b);
	}

	return 0;
}