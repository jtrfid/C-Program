#include <stdio.h>

typedef struct {
	char c[20];
	char a[20];
} paixu;

int main() {
	int n, i, k, t;
	scanf("%d", &n);
	paixu s[n];
	for (i = 0; i < n; i++) {
		scanf("%s %s", &s[i].c, s[i].a);
	}
	scanf("%d", &k);
	int c[n];
	for (i = 0; i < n; i++) {
		scanf("%d", &c[i]);
	}
	paixu b[n];
	for (i = 0; i < n; i++) {
		t = c[i];
		paixu st = s[i];
		s[i] = b[t];
		b[t] = st;
	}
	for (i = 0; i < n; i++) {
		t = c[i];
		paixu st = s[i];
		s[i] = b[t];
		b[t] = s[i];
	}
	for (i = 0; i < n; i++) {
		printf("%s %s", s[i].c, s[i].a);
	}
	return 0;

}