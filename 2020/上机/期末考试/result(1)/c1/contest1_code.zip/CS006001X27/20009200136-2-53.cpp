#include <stdio.h>

int main() {
	int n;
	int a = 0, b = 0, c = 0, max1 = 0;
	scanf("%d", &n);
	for (int i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			a++;
		if (i % 2 == 1)
			b++;
		if (i % 4 == 0 && i % 3 != 0)
			c++;
	}
	printf("%d %d %d\n", b, a, c);
	if (a > b)
		max1 = a;
	else
		max1 = b;
	if (max1 < c)
		max1 = c;
	printf("%d", max1);

}