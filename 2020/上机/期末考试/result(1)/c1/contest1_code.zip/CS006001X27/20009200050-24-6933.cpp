#include <stdio.h>
#include <string.h>

struct card {
	char num[2];
	char color[7];
} a[54], temp[54];


int main() {
	int N;
	int i, j;
	int det[5];
	int m = 0;
	int count;
	scanf("%d", &N);
	for (i = 0; i < N; i++) {
		scanf("%s", &a[i].num);
		getchar( );
		scanf("%s", &a[i].color);
	}
	scanf("%d", &count);
	for (j = 0; j < N; j++) {
		scanf("%d", &det[j]);
	}



	for (i = 0; i < count; i++) {
		m = 0;
		for (j = 0; j < N; j++)
			temp[j] = a[j];
		for (j = 0; j < N; j++) {
			a[det[m]] = temp[m];
			m++;
		}
	}

	for (j = 0; j < N; j++) {
		printf("%s %s\n", a[j].num, a[j].color);
	}

	return 0;
}