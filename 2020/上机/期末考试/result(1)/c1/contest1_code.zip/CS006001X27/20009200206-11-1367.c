#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int a[10000];
	int i, j;
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	int t;
	for (i = 0; i < n * n - 1; i++) {
		for (j = i + 1; j < n * n; j++) {
			if (a[i] > a[j]) {
				t = a[j];
				a[j] = a[i];
				a[i] = t;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i + j * n]);
		}
		printf("\n");
	}
	return 0;
}