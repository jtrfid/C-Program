#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int m, n, k, i, j, p, s, sum = 0;
	scanf("%d%d", &m, &n);
	s = m;
	int a[m][n];
	int b[n][m];

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			b[i][j] = a[j][i];
		}
	}


	int c[s][n];

	for (i = 0; i < s; i++) {
		for (j = 0; j < s; j++) {

			for (sum = 0, p = 0; p < n; p++) {
				sum += a[i][p] * b[p][j];

			}
			c[i][j] = sum;
		}
	}
	for (i = 0; i < s; i++) {
		for (j = 0; j < s; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}



	return 0;
}