#include <stdio.h>

int main() {
	int a, n, max, x, y, z;
	scanf("%d", &n);
	if (n % 2 == 0) {
		y = (n * n - n) / 2 + 1;
		x = y - 1;
	} else {
		x = (n * n - n) / 2 + 1;
		y = x - 1;
	}
	for (a = n, z = 0; a <= n * n; a++) {
		if (a % 4 == 0 && a % 3 != 0)
			z++;
	}
	if (x >= y && x >= z)
		max = x;
	else if (y >= x && y >= z)
		max = y;
	else
		max = z;
	printf("%d %d %d\n%d", x, y, z, max);
}