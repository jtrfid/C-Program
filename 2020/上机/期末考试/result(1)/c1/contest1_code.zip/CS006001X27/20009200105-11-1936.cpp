#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int n, i, j, k, l, t, x, y, z;
	int a[100];
	int b[10][10];
	scanf("%d", &n);
	z = n * n;
	for (i = 0; i < z; i++) {
		scanf("%d", a[i]);
	}
	for (i = 0; i < z; i++) {
		l = 0;
		for (j = 0; j < z - i - 1; j++) {
			if (a[j] > a[j + 1]) {
				t = a[j];
				a[j] = a[j + 1];
				a[j + 1] = t;
				l = 1;
			}
		}
		if (l == 0)
			break;
	}
	for (j = 0; j < n; j++) {
		x = 0;
		for (k = 0; k < n; k++) {
			y = k + x * n;
			b[k][j] = a[y];
		}
		x++;
	}
	for (j = 0; j < n; j++) {
		for (k = 0; k < n; k++) {
			printf("%d ", b[j][k]);
		}
		printf("\n");
	}
	return 0;



}