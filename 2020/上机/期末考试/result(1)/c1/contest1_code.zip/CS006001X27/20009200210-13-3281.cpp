#include <bits/stdc++.h>
using namespace std;

int main() {
	int m, n, a[20][20], b[20][20], c[20][20];
	cin >> m >> n;
	for (int i = 1; i <= 15; i++) {
		for (int j = 1; j <= 15; j++) {
			c[i][j] = 0;
		}
	}
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			cin >> a[i][j];
			b[j][i] = a[i][j];
		}
	}
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			for (int k = 1; k <= n; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}
		}
	}
	int MIN = min(m, n);
	for (int i = 1; i <= MIN; i++) {
		for (int j = 1; j <= MIN; j++) {
			cout << c[i][j] << " ";
		}
		cout << endl;
	}
	return 0;
}