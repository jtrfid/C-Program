#include <stdio.h>

int main() {
	int n, a[3], i, k = 0, p = 0, q = 0, m, j, temp;
	scanf("%d", &n);
	m = n * n;
	for (i = n; i <= m; i++) {
		if (i % 2 != 0) {
			k++;
		}
		if (i % 2 == 0) {
			p++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			q++;
		}
	}
	a[0] = k;
	a[1] = p;
	a[2] = q;
	for (i = 0; i < 3; i++) {
		for (j = i + 1; j < 2; j++) {
			if (a[i] < a[j]) {
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	printf("%d %d %d\n", k, p, q);
	printf("%d", a[0]);
	return 0;


}