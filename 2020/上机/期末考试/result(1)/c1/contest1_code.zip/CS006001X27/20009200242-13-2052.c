#include <stdio.h>

int main() {

	int a[10][10] = {0}, b[10][10] = {0}, c[10][10] = {0};
	int m, n, k;
	scanf("%d%d", &m, &n);
	int i, j;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[i][j];
		}
	}

	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (k = 0; k < n ; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}

		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}


	return 0;
}