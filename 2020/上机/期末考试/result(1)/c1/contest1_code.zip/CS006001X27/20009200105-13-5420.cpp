#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int m, s;
	int n, j, k, i;
	int a[10][10];
	int b[10][10];
	int c[10][10] = {0};
	scanf("%d%d", &m, &n);
	s = n - 1;
	for (j = 0; j < m; j++) {
		for (k = 0; k < n; k++) {
			scanf("%d", &a[j][k]);
		}
	}
	for (j = 0; j < m; j++) {
		for (k = 0; k < n; k++) {
			b[k][j] = a[j][k];
		}
	}
	for (j = 0; j < m; j++) {
		for (k = 0; k < m; k++) {
			for (i = 0; i < n; i++) {
				c[j][k] = c[j][k] + a[j][i] * b[i][k];
			}

		}
	}
	for (j = 0; j < m; j++) {
		for (k = 0; k < m; k++) {
			printf("%d ", c[j][k]);
		}
		printf("\n");
	}
	return 0;

}