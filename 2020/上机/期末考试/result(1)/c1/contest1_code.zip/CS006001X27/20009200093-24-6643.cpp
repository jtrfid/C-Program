#include <stdio.h>

int main() {
	int n, i, p, m, b[100];
	scanf("%d", &n);
	char str[100];
	struct data {
		char a[100];
	} pai[54];
	for (i = 0; i < n * 2; i++) {
		getchar();
		scanf("%s", &pai[i]);
	}
	scanf("%d", &m);


	for (i = 0, p = 0; i < n * 2 ; i++) {
		p++;
		printf("%s ", pai[i]);
		if (p == 2) {
			p = 0;
			printf("\n", pai[i]);
		}
	}
}