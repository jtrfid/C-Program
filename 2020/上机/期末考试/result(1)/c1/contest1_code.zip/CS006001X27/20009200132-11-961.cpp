#include <stdio.h>
#include <math.h>

int main() {
	int n, temp;
	scanf("%d", &n);
	int i, j, a[100], m[10][10];
	for (i = 0; i < pow(n, 2); i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < pow(n, 2); i++) {
		for (j = 0; j < pow(n, 2) - 1 - i; j++) {
			if (a[j] > a[j + 1]) {
				temp = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			m[j][i] = a[i * n + j];
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}
	return 0;
}