#include <stdio.h>

typedef struct {
	char ni;
	char nij;
	char name[20];
} ty;

int main() {
	int n;
	scanf("%d", &n);
	getchar();
	ty pai[n], shu[n];
	int i, j;
	for (i = 0; i < n; i++) {

		pai[i].ni = getchar();
		if (getchar() == '0') {
			pai[i].nij = '0';
		}

		gets(pai[i].name);
	}
	int k;
	scanf("%d", &k);
	int cmd[n];
	for (i = 0; i < n; i++) {
		scanf("%d", &cmd[i]);
	}
	for (i = 0; i < k; i++) {
		for (j = 0; j < n; j++) {
			if (i == 0 || i % 2 == 0) {

				shu[cmd[j] - 1] = pai[j];
				//printf("shu=%s--%d\n", shu[cmd[j] - 1].name, cmd[j] - 1);
			} else {
				pai[cmd[j] - 1] = shu[j];
				//printf("pai=%s--%d\n", pai[cmd[j] - 1].name, cmd[j] - 1);
			}

		}
	}
	if (i % 2 != 0) {
		for (i = 0; i < n; i++) {
			if (shu[i].nij != '0')
				printf("%c %s\n", shu[i].ni, shu[i].name);
			else {
				printf("%c%c %s\n", shu[i].ni, shu[i].nij, shu[i].name);
			}
		}
	} else if (i % 2 == 0) {
		for (i = 0; i < n; i++) {
			if (pai[i].nij != '0')
				printf("%c %s\n", pai[i].ni, pai[i].name);
			else {
				printf("%c%c %s\n", pai[i].ni, pai[i].nij, pai[i].name);
			}
		}
	}


	return 0;
}