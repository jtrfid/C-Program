#include <stdio.h>

int main() {
	int n;
	int temp;
	int i = 0;
	int p;
	int q = 0;
	scanf("%d", &n);
	int record[n * n];
	int a[n][n];
	for (i = 0; i < n * n; i++)
		scanf("%d", &record[i]);
	for (i = 0; i < n * n - 1; i++) {
		for (p = 0; p < n * n - 1 - i; p++) {
			if (record[p] > record[p + 1]) {
				temp = record[p];
				record[p] = record[p + 1];
				record[p + 1] = temp;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (p = 0; p < n; p++) {
			a[p][i] = record[q];
			q++;
		}
	}
	for (i = 0; i < n; i++) {
		for (p = 0; p < n - 1; p++) {
			printf("%d ", a[i][p]);
		}
		printf("%d\n", a[i][n - 1]);
	}

	return 0;
}