#include <stdio.h>

int main() {

	int m, n;

	scanf("%d %d", &m, &n);

	int a[m][n], b[n][m];

	int i, j;

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[i][j];
		}
	}

	int k;
	int c[m][m], sum;

	for (i = 0; i < m; i++) {
		for ( j = 0; j < m; j++) {
			for (sum = 0, k = 0; k < n; k++) {
				sum += a[i][k] * b[k][j];
			}
			c[i][j] = sum;
		}
	}

	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}

	return 0;
}