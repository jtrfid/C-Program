#include <stdio.h>
#include <math.h>
#include <string.h>

typedef struct {
	char x[3];
	char y[8];
} a;

int main() {
	int n, i, j, f;
	scanf("%d", &n);
	a ch[n];
	for (i = 0; i < n; i++) {
		scanf("%s", &ch[i].x);
		scanf("%s", &ch[i].y);
	}
	int k, num[n], num1[n];
	scanf("%d", &k);
	for (i = 0; i < n; i++) {
		scanf("%d", &num[i]);
		num1[i] = num[i];
	}
	for (i = 1; i <= k; i++) {
		//printf("%d\n", i);
		for (j = 1; j < n; j++) {
			int d = num[0] - 1;
			//printf("%d ", d);
			a z;
			z = ch[d];
			ch[d] = ch[0];
			ch[0] = z;

			int e = num[d];
			num[d] = num[0];
			num[0] = e;
		}
		for (f = 0; f < n; f++) {
			num[f] = num1[f];
			//printf("%d\n", num[i]);
		}

	}
	for (i = 0; i < n; i++) {
		printf("%s %s\n", ch[i].x, ch[i].y);
	}
	return 0;
}