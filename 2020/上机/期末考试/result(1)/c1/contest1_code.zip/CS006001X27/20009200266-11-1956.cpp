#include <stdio.h>

int main() {
	int n, d, i, j, c;
	scanf("%d", &n);
	d = n * n;
	int a[d] = {0};
	for (i = 0; i < d; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < d - 1; i++) {
		for (j = 0; j < d - i - 1; j++)
			if (a[j] > a[j + 1]) {
				c = a[j];
				a[j] = a[j + 1];
				a[j + 1] = c;
			}

	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			d = i + j * n;

			printf("%d ", a[d]);
		}
		printf("\n");

	}
	return 0;




}