#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

struct cards {
	char color[100];
	char num[100];
};

int main() {
	struct cards card[100];
	int n = 0, k = 0;
	int arr[100] = {0};
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%s %s", card[i].num, card[i].color);
	}
	for (int i = 1; i <= n; i++) {
		printf("%s %s\n", card[i].num, card[i].color);
	}
	/*
	scanf("%d", &k);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &arr[i]);
	}
	struct cards temp[100];
	for (int i1 = 1; i1 <= k; i1++) {
		for (int i2 = 1; i2 <= n; i2++) {
			temp[arr[i2]] = card[i2];
		}
		for (int i2 = 1; i2 <= n; i2++) {
			card[i2] = temp[i2];
		}
	}
	for (int i = 1; i <= n; i++) {
		printf("%s ", card[i].num);
		printf("%s\n", card[i].color);
	}
	*/
	return 0;
}