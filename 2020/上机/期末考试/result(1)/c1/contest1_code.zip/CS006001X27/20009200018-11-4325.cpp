#include <stdio.h>

int main() {

	int n, c, b[10][10], i, a[100];
	scanf("%d\n", &n);
	for (i = 0; i < n * n ; i++) {

		scanf("%d", &a[i]);
	}
	b[(i + 1) % n - 1][(i  - (i + 1) % n) - 1] == a[i];
	for (i = 0; i < n; i++) {
		if (b[i][i] <= b[0][0]) {
			c = b[0][0];
			b[0][0] = b[i][i];
			b[i][i] = c;
		}
	}

	printf("%d ", b[1][1]);


	return 0;
}