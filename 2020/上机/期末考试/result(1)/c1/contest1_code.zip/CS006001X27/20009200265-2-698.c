#include <stdio.h>
#include <string.h>

int main() {
	int n, i, j = 0, o = 0, k = 0;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			o++;
		if (i % 2 != 0)
			j++;
		if (i % 4 == 0 && i % 3 != 0)
			k++;
	}
	printf("%d %d %d\n", j, o, k);
	int max = j;
	if (o > max)

		max = o;
	if (k > max)
		max = k;


	printf("%d", max);


}