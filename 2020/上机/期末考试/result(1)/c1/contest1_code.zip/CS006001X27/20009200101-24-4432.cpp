#include <stdio.h>
#include <string.h>

typedef struct {
	char card[100];
} Str;

int main () {
	int N, K, i, j, n;
	scanf("%d", &N);
	int num[55] = {0};
	Str c[100];
	Str b[100];
	Str d[100];
	scanf("\n");
	for (i = 1; i <= N; i++) {
		gets(c[i].card);
	}
	scanf("\n");

	scanf("%d", &K);

	for (i = 1; i <= N; i++) {
		scanf("%d", &num[i]);
	}
	for (i = 1; i <= N; i++) {
		strcpy(b[i].card, c[i].card);
		strcpy(d[i].card, c[i].card);
	}
	for (j = 0; j < K; j++) {
		for (i = 1; i <= N; i++) {
			strcpy(b[num[i]].card, c[i].card);

		}
		for (n = 1; n <= N; n++) {
			strcpy(c[n].card, b[n].card);
		}
	}

	for (i = 1; i <= N; i++) {
		printf("%s\n", b[i].card);
	}

	return 0;
}