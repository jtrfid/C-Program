#include <stdio.h>
#include <string.h>

int main() {
	int m, n, i, t, j;
	scanf("%d%d", &m, &n);
	int a[10][10] = {0};
	for (i = 0; i < m; i++) {
		for (t = 0; t < n; t++) {
			scanf("%d", &a[i][t]);
		}
	}
	int b[10][10] = {0};
	for (i = 0; i < m; i++) {
		for (t = 0; t < n; t++) {
			b[t][i] = a[i][t];
		}
	}
	long c[10][10] = {0}, s;

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			for (s = 0; s < n; s++) {
				c[i][j] += a[i][s] * b[s][j];
			}
		}
	}
	for (i = 0; i < m; i++) {
		for (t = 0; t < m; t++) {
			printf("%ld ", c[i][t]);
		}
		printf("\n");
	}

	return 0;
}
