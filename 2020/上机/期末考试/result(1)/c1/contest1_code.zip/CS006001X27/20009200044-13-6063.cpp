#include <iostream>
#include <algorithm>
using namespace std;

int main() {
	int a, b, cal = 0;
	int s, q;
	cin >> a >> b;
	int A[a][b], B[b][a];
	if (a > b) {
		s = b;
		q = a;
	} else {
		s = a;
		q = b;
	}
	int c[s][s];
	for (int i = 0; i < a; ++i)
		for (int r = 0; r < b; ++r)
			cin >> A[i][r];
	for (int i = 0; i < a; ++i)
		for (int r = 0; r < b; ++r) {
			B[r][i] = A[i][r];
		}
	for (int i = 0; i < s; ++i)
		for (int j = 0; j < s; ++j) {
			for (int x = 0; x < s + 1; ++x)
				cal += A[i][x] * B[x][j];
			c[i][j] = cal;
			cal = 0;
		}
	for (int i = 0; i < s; ++i) {
		for (int j = 0; j < s; ++j)
			cout << c[i][j] << " ";
		cout << endl;
	}
}