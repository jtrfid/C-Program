#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int n, i, c, e = 0, j = 0, min = 0;
	scanf("%d", &n);
	int a[10][10];
	int b[100];
	c = n * n;
	for (i = 0; i < c; i++) {
		scanf("%d", &b[i]);
	}
	for (i = 0; i < c - 1; i++) {
		for (j = i + 1; j < c; j++) {
			if (b[i] > b[j]) {
				min = b[j];
				b[j] = b[i];
				b[i] = min;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			a[j][i] = b[e];
			e++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {

			printf("%d ", a[i][j]);
			if (j == n - 1) {
				printf("\n");
			}
		}
	}

}