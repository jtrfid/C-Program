#include <stdio.h>

struct card {
	char val[15], col[15];
} pre[55], cur[55];

int main() {
	int n, k;
	int order[55];

	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%s %s", &pre[i].val, &pre[i].col);
	}
	scanf("%d", &k);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &order[i]);
	}

	for (int i = 0; i < k; i++) {
		for (int j = 1; j <= n; j++) {
			cur[order[j]] = pre[j];
		}
		for (int j = 1; j <= n; j++) {
			pre[j] = cur[j];
		}
	}

	for (int i = 1; i <= n; i++) {
		printf("%s %s\n", pre[i].val, pre[i].col);
	}
	return 0;
}