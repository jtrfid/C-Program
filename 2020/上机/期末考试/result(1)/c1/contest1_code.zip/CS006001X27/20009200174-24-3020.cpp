#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct pai {
	char name[20];
};

int main() {
	int n;
	scanf("%d\n", &n);
	struct pai posi[n + 1];
	struct pai now[n + 1];
	int i, j;
	for (i = 1; i < n + 1 ; i++) {
		gets(now[i].name);
	}
	//printf("flag");
	int m;
	int x;
	scanf("%d", &x);
	int a[n] = {};
	struct pai t;
	int k;
	for (i = 1; i < n + 1; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < x; i++) {
		for (j = 1; j < n + 1; j++) {
			posi[a[j]] = now[j];
		}
		for (k = 1; k < n + 1; k++) {
			now[k] = posi[k];
		}
	}
	for (i = 1; i < n + 1; i++) {
		printf("%s\n", now[i].name);
	}


	return 0;
}