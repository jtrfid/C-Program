#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int t[n][n];
	int a = 0, b = 0, i = 1, num[n * n + 1];
	while (i <= n * n) {
		scanf("%d", &num[i]);
		i++;
	}
	int p = 1, tt;
	while (p != 0) {
		p = 0;
		i = 1;
		while (i <= n * n - 1) {
			if (num[i] > num[i + 1]) {
				tt = num[i];
				num[i] = num[i + 1];
				num[i + 1] = tt;
				p++;
			}
			i++;
		}
	}
	i = 1;
	while (b != n) {
		t[a][b] = num[i];
		if (a == n - 1) {
			a = 0;
			b++;
		} else
			a++;
		i++;
	}
	a = 0;
	b = 0;
	while (a != n) {
		printf("%d ", t[a][b]);
		if (b == n - 1) {
			printf("\n");
			b = 0;
			a++;
		} else
			b++;
	}
}