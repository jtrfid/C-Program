#include <stdio.h>

int main(void) {
	int m, n;
	scanf("%d%d", &m, &n);
	int a[m][n], b[n][m];
	int c[m][m];

	int s = n, i, j, k;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (j = 0; j < n; j++) {
		for (i = 0; i < m; i++) {
			b[j][i] = a[i][j];
		}
	}

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			c[i][j] = 0;
			for (k = 0; k < s; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}
		}
	}
	for (i = 0; i < m ; i++) {

		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
	/*for (j = 0; j < m; j++) {
		printf("%d ", c[m - 1][j]);
	}*/
	return 0;
}
