#include <stdio.h>
#include <string.h>

int main() {
	int n, k, i, j, p;
	scanf("%d", &n);
	char str[n][20], str1[n][20];
	for (i = 0; i < n; i++) {
		gets(str[i]);
	}
	scanf("%d", &k);
	int b[n];
	for (i = 0; i < n; i++) {
		scanf("%d", &b[i]);
	}
	for (i = 0; i < k; i++) {
		for (j = 0; j < n; j++) {
			strcpy(str1[b[j]], str[j]);
		}
		for (p = 0; p < n; p++) {
			strcpy(str[p], str1[p]);
		}
	}
	for (i = 0; i < n; i++) {
		printf("%s\n", str[i]);
	}
	return 0;

}