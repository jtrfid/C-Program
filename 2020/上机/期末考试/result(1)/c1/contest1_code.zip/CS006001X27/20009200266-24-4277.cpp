#include <stdio.h>

int main() {
	int n, i, j;
	scanf("%d", &n);
	struct t {
		char pai[20];
	} a[n + 1];
	int b[n], c, d[n];
	for (i = 0; i <= n; i++)
		gets(a[i].pai);
	scanf("%d", &c);
	for (i = 0; i < n; i++) {
		scanf("%d", &b[i]);
		d[i] = b[i];
	}
	for (i = 0; i < c - 1; i++) {
		for (j = 0; j < n; j++) {
			b[j] = d[b[j] - 1];

		}
		for (j = 0; j < n; j++)
			d[j] = b[j];
	}
	for (i = 0; i < n; i++)
		printf("%s\n", a[b[i]].pai);


	return 0;

}