#include <iostream>
#include <cstdio>
using namespace std;

typedef struct Card {
	char c[5];
	char col[20];
} card;

int main() {
	int n;
	cin >> n;
	card cup[55];
	card *way[55] = {0};
	card new1[55];

// ¼��ԭʼ��
	for (int i = 1; i <= n; i++) {
		scanf("%s %s", &cup[i].c, &cup[i].col);
	}

// �涨 way ��ָ�뷽ʽ(��1��ʼ������
	int m;
	cin >> m; // ϴ�ƴ���
	int p;
	for (int i = 1; i <= n; i++) {
		cin >> p;
		way[i] = &new1[p];
	}

// ��ʼϴ��Ŷ
	for (int j = 1; j <= m; j++) {
		for (int i = 1; i <= n; i++) {
			*way[i] = cup[i];
		}
		for (int i = 1; i <= n; i++) {
			cup[i] = new1[i];
		}
	}

// ��ʼ���
	for (int i = 1; i <= n; i++) {
		printf("%s %s\n", cup[i].c, cup[i].col);
	}
	return 0;
}

