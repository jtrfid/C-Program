#include <stdio.h>

int main() {
	int c, r;
	int A[100][100] = {0}, B[100][100] = {0};
	int C[100][100] = {0};
	scanf("%d%d", &c, &r);
	for (int n = 0; n < c; n++) {
		for (int m = 0; m < r; m++) {
			scanf("%d", &A[n][m]);
			B[m][n] = A[n][m];
		}
	}
	/*for (int n = 0; n < 5; n++) {
		for (int m = 0; m < 5; m++) {
			printf("%d", A[n][m]);
		}
		printf("\n");
	}
	for (int n = 0; n < 5; n++) {
		for (int m = 0; m < 5; m++) {
			printf("%d", B[n][m]);
		}
		printf("\n");
	}*/
	for (int n = 0; n < c; n++) {
		for (int m = 0; m < c; m++) {
			for (int j = 0; j < r; j++) {
				C[n][m] += A[n][j] * B[j][m];
			}
		}
	}
	for (int n = 0; n < c; n++) {
		for (int m = 0; m < c; m++) {
			printf("%d ", C[n][m]);
		}
		printf("\n");
	}
	return 0;
}