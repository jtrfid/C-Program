#include <bits/stdc++.h>
using namespace std;

struct ss {
	string s1, s2;
	int cnt = 0;
} s[300];

bool cmp(ss x, ss y) {
	return x.cnt < y.cnt;
}

int main() {
	int n, m, a[50];
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> s[i].s1 >> s[i].s2;
	}
	cin >> m;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			s[j].cnt = a[j];
		}
		sort(s + 1, s + 1 + n, cmp);
	}
	for (int i = 1; i <= n; i++) {
		cout << s[i].s1 << " " << s[i].s2 << endl;
	}
	return 0;
}