#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int a[n][n];
	int i, j;

	for (i = 0; i < n; ++i) {
		for (j = 0; j < n; ++j) {
			scanf("%d", &a[i][j]);
		}
	}

	int c, d;
	int x, y;
	int t;
	for (y = 0; y < n; ++y) {
		for (x = 0; x < n; ++x) {
			c = x;
			d = y;
			for (j = y, i = x; j < n; ++j) {
				for (i = (j == y && i == x) ? x : 0; i < n; ++i) {
					if (a[c][d] >= a[i][j]) {
						c = i;
						d = j;
					}
				}
			}



			if (a[c][d] < a[x][y]) {
				t = a[c][d];
				a[c][d] = a[x][y];
				a[x][y] = t;
			}
		}
	}

	for (i = 0; i < n; ++i) {
		for (j = 0; j < n; ++j) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}