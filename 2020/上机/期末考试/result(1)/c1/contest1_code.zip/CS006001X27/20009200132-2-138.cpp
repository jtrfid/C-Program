#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, co = 0, ce = 0, cs = 0, max;
	for (i = n; i <= pow(n, 2); i++) {
		if (i % 2 == 0) {
			co++;
		} else {
			ce++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			cs++;
		}
	}
	max = co;
	if (ce > max) {
		max = ce;
	}
	if (cs > max) {
		max = cs;
	}
	printf("%d %d %d\n%d", ce, co, cs, max);
	return 0;
}