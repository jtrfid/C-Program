#include <stdio.h>

int main() {
	int n;
	int max1, max;
	int ji, ou;
	scanf("%d", &n);
	int i = 0;
	int count = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 4 == 0 && i % 3 != 0)
			count++;
	}
	if (n % 2 == 0) {
		ji = (n * n - n) / 2;
		ou = ji + 1;
	}
	if (n % 2 != 0) {
		ji = (n * n - n) / 2 + 1;
		ou = ji - 1;
	}
	max1 = (ji > ou) ? ji : ou;
	max = (count > max1) ? count : max1;
	printf("%d %d %d\n", ji, ou, count );
	printf("%d", max);
	return 0;
}