#include <stdio.h>

int main() {
	int n;
	int i;
	int oushu = 0, jishu = 0, special = 0, max;
	//����
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			oushu++;
		if (i % 2 != 0)
			jishu++;
		if (i % 4 == 0 && i % 3 != 0) {
			special++;
		}
	}
	//�Ƚ�ͳ������С
	max = oushu;
	if (max < jishu)
		max = jishu;
	if (max < special)
		max = special;
	//���
	printf("%d %d %d\n", jishu, oushu, special);
	printf("%d", max);


	return 0;
}