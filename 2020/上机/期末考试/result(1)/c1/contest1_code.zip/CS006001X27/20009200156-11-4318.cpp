#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int m, n, i, j, e = 0, f = 0, k;
	scanf("%d %d", &m, &n);
	int a[10][10];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int b[10][10];
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			b[j][i] = a[i][j];
		}
	}
	int c[10][10] = {0};
	for (i = 0; i < m; i++) {
		for (f = 0; f < m; f++) {
			for (k = 0; k < n; k++) {
				c[i][f] = c[i][f] + (a[i][k] ) * (b[k][f]);
			}
		}

	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
			if (j == m - 1)
				printf("\n");
		}
	}
}