#include <stdio.h>

int main() {
	int m, n, i, j, k, q;
	scanf("%d%d", &m, &n);
	int a[m][n];
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			q = 0;
			for (k = 0; k < n; k++)
				q += a[i][k] * a[j][k];
			printf("%d ", q);
		}
		printf("\n");
	}




	return 0;
}