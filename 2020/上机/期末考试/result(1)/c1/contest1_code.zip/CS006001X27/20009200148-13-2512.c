#include <stdio.h>

int main() {
	int a[10][10] = {0};
	int m, n;
	int b[10][10] = {0};
	int c[10][10] = {0};
	int i, j;
	//����
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
			b[j][i] = a[i][j];
		}
	}
	//�������c
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			int temp = 1;
			int result = 0;
			int t;
			for (t = 0; t < n; t++) {
				temp = a[i][t] * b[t][j];
				result += temp;

			}
			c[i][j] = result;
		}
	}
	//���
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}


	return 0;
}