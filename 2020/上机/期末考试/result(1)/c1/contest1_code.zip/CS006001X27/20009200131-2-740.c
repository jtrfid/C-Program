#include <stdio.h>

int main(void) {
	int n, ans1 = 0, ans2 = 0, ans3 = 0, i;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			ans2++;
		} else
			ans1++;
		if (i % 4 == 0 && i % 3 != 0) {
			ans3++;
		}
	}
	printf("%d %d %d\n", ans1, ans2, ans3);
	if (ans1 < ans2)
		ans1 = ans2;
	else if (ans1 < ans3)
		ans1 = ans3;
	printf("%d", ans1);
	return 0;
}
