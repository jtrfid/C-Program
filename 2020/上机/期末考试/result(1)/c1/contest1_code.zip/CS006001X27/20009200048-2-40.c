#include <stdio.h>

int max(int a, int b) {
	return a > b ? a : b;
}

int main() {
	int odd = 0, even = 0, w = 0;
	int n, mx = 0;
	scanf("%d", &n);

	for (int i = n; i <= n * n; i++) {
		if (i % 2 == 1)
			odd++;
		else
			even++;
		if (i % 4 == 0 && i % 3 != 0)
			w++;
	}
	mx = max(max(odd, even), w);
	printf("%d %d %d\n", odd, even, w);
	printf("%d\n", mx);
	return 0;
}