#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i;
	int a = 0, b = 0, c = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 2 != 0)
			a++;
		if (i % 2 == 0)
			b++;
		if (i % 4 == 0 && i % 3 != 0)
			c++;
	}
	printf("%d %d %d\n", a, b, c);
	int max = 0;
	if (a > max)
		max = a;
	if (b > max)
		max = b;
	if (c > max)
		max = c;
	printf("%d", max);

	return 0;
}