#include <stdio.h>

int main() {

	int n, c, b[10][10], i, a[10][10], m;
	scanf("%d\n", &n);
	scanf("%d", &a[n - 1][n - 1]);
	for (i = 0; i++; i < n) {
		for (m = 0; m++; m < n) {
			if (a[0][0] > a[i][m]) {

				a[0][0] = a[i][m];


			}

		}
	}

	printf("%d", a[0][0]);


	return 0;
}