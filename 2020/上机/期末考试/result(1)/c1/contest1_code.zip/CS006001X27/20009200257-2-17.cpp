#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (!isdigit(ch))	{
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (isdigit(ch))	{
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
int n, sum, sum1, sum2, ans;

int main() {
	n = read();
	for (int i = n; i <= n * n; ++i) {
		if (i & 1)
			++sum;
		else	++sum1;
		if (i % 4 == 0 && i % 3 != 0)
			++sum2;
	}
	ans = max(sum, max(sum1, sum2));
	printf("%d %d %d\n", sum, sum1, sum2);
	printf("%d\n", ans);
	return 0;
}