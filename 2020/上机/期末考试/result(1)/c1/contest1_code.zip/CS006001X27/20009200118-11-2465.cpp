#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n, fang, shu, i, j, temp, k = 0;
	scanf("%d", &n);
	fang = n * n;
	int b[fang];
	int a[n][n];
	for (i = 0; i < fang; i++) {
		scanf("%d", &shu);
		b[i] = shu;
	}
	for (i = 0; i < fang; i++) {
		for (j = 0; j < fang - 1; j++) {
			if (b[j] > b[j + 1]) {
				temp = b[j];
				b[j] = b[j + 1];
				b[j + 1] = temp;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			a[j][i] = b[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);


		}
		printf("\n");
	}
	return 0;
}