#include <stdio.h>

int main() {
	int n, m;
	scanf("%d%d", &m, &n);

	int a[10][10] = {0}, ans[10][10] = {0};
	for (int i = 0 ; i < m ; i++) {
		for (int  j = 0 ; j < n ; j++) {
			scanf("%d", &a[i][j]);
		}
	}




	for (int i = 0 ; i < m ; i++) {
		for (int j = 0 ; j < m ; j++) {
			for (int k = 0 ; k < n ; k++) {
				ans[i][j] += a[i][k] * a[j][k];
			}
			printf("%d ", ans[i][j]);
		}
		printf("\n");
	}
	return 0;
}