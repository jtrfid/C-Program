#include <iostream>
using namespace std;
int n, a, b, c, max1;

int main() {
	cin >> n;
	for (int i = n; i <= n * n; i++) {
		if (i % 2 == 1)
			a++;
		else
			b++;
		if (i % 4 == 0 && i % 3 != 0)
			c++;
	}
	max1 = max(max1, a);
	max1 = max(max1, b);
	max1 = max(max1, c);
	cout << a << ' ' << b << ' ' << c << endl;
	cout << max1;
	return 0;
}