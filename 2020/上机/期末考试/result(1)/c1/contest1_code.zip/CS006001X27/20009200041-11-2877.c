#include <stdio.h>

int main() {
	int n;
	int a[100];
	scanf("%d", &n);
	int i;
	for (i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	int s[10][10];
	int t;
	int j;
	for (i = 0; i < n * n; i++) {
		for (j = i + 1; j < n * n; j++) {

			if (a[i] > a[j]) {
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}


		}


	}
//	for (i = 0; i < n * n; i++) {
//		printf("%d \n", a[i]);
//	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++)

		{
			s[j][i] = a[i + n * j];
		}

	}
	for (j = 0; j < n; j++) {

		for (i = 0; i < n; i++) {
			printf("%d ", s[i][j]);
		}
		printf("\n");
	}
	return 0;
}