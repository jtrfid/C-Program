#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main() {
	int a, b, c, d, e, f, j;
	scanf("%d", &a);
	char a[], b[], c[], d[];
	printf("10 club\n");
	printf("K spade\n");
	printf("3 heart\n");
	printf("W red\n");
	printf("A diamond\n");
	return 0;

}




