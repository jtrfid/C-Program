#include <stdio.h>

void paixu(int a[], int n) {
	int i, j, t;
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if (a[i] > a[j]) {
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}
	}
}

int main() {
	int n;
	scanf("%d", &n);
	int a[n * n];
	for (int i = 0; i < n * n; i++) {
		scanf("%d", &a[i]);
	}
	paixu(a, n * n);
	int b[n][n];
	int t = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			b[j][i] = a[t];
			t++;
		}
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	return 0;
}