#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	int n;
	scanf("%d", &n);
	int m = n * n;
	int i, j;
	int ji, ou, num, max;
	ji = 0;
	ou = 0;
	num = 0;
	max = 0;
	for (i = n; i <= m; i++) {
		if (i % 4 == 0 && i % 3 != 0) {
			num++;
		}
		if (i % 2 == 0) {

			ou++;

		} else {
			ji++;
		}
		if (num > max) {
			max = num;
		}
		if (ji > max) {
			max = ji;
		}
		if (ou > max) {
			max = ou;
		}
	}
	printf("%d %d %d\n", ji, ou, num);
	printf("%d", max);



	return 0;
}