#include <stdio.h>

int main() {
	int i, j, k = 1, x, y, n;
	scanf("%d", &n);
	int a[n * n];
	int b[n][n];
	for (i = 0; i < n * n; i++)
		scanf("%d", &a[i]);

	while (k != 0) {
		k = 0;
		for (i = 0; i < n * n - 1; i++) {
			if (a[i] > a[i + 1]) {
				j = a[i];
				a[i] = a[i + 1];
				a[i + 1] = j;
				k++;
			}
		}
	}

	for (i = 0; i < n * n; i++)
		b[0][i] = a[i];

	/*for (x = 0, i = 0; x < n; x++)
		for (y = 0; y < n; y++, i++)
			b[y][x] = a[i];*/

	for (x = 0; x < n; x++) {
		for (y = 0; y < n; y++) {
			printf("%d ", b[y][x]);
		}
		printf("\n");
	}

	return 0;
}