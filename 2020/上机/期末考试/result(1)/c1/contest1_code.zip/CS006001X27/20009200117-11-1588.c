#include <stdio.h>
#include <string.h>

int main() {
	int n, i, m[100], t, j, a[10][10] = {0}, k = 0;
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &m[i]);
	}
	for (i = 0; i < n * n; i++) {
		for (j = 0; j < n * n - i - 1; j++) {
			if (m[j] > m[j + 1]) {
				t = m[j];
				m[j] = m[j + 1];
				m[j + 1] = t;
			}
		}
	}
	for (i = 0; i < n ; i++) {
		for (j = 0; j < n; j++) {

			a[j][i] = m[k];
			k++;
		}
	}
	for (i = 0; i < n ; i++) {
		for (j = 0; j < n; j++) {

			printf("%d ", a[i][j]);
		}
		printf("\n");


	}

	return 0;
}