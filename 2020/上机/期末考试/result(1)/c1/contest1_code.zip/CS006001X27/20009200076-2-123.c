#include <stdio.h>

int main() {
	int n, a = 0, b = 0, c = 0;
	scanf("%d", &n);
	int i;
	for (i = n; i <= n * n; i++) {
		if (i % 2 != 0) {
			a++;
		} else {
			b++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			c++;
		}
	}
	int max;
	if (a > b && a > c) {
		max = a;
	} else if (b > a && b > c) {
		max = b;
	} else if (c > a && c > b) {
		max = c;
	}
	printf("%d %d %d\n%d", a, b, c, max);
	return 0;
}