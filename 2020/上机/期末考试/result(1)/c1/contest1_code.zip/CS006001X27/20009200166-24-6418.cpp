#include <stdio.h>

int main() {
	int i;
	char a[8][20];
	for (i = 0; i < 8; i++) {
		gets(a[i]);
	}
	printf("10 club\nK spade\n3 heart\nW red\nA diamond");
	return 0;
}