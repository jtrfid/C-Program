#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int n = 0, a = 0, b = 0, c = 0;
	scanf("%d", &n);
	for (int i = n; i <= n * n; i++) {
		if (i % 2 != 0) {
			a++;
		}
		if (i % 2 == 0) {
			b++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			c++;
		}
	}
	int max = a;
	if (b > max) {
		max = b;
	}
	if (c > max) {
		max = c;
	}
	printf("%d %d %d\n%d", a, b, c, max);
	return 0;
}











