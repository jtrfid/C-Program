#include <stdio.h>

int main() {
	int n, a = 0, b = 0, c = 0, i, m = 0;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 != 0)
			a++;
		if (i % 2 == 0)
			b++;
		if ((i % 4 == 0) && (i % 3 != 0) )
			c++;

	}
	if (a >= b)
		m = a;
	if (a < b)
		m = b;
	if (c >= m)
		m = c;

	printf("%d %d %d\n%d", a, b, c, m);
	return 0;
}