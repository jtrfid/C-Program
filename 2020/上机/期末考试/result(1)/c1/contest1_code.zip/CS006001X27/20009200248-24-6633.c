#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct pai {
	char shu[5];
	char hua[20];
};

int main() {
	struct pai a[100];
	int n, i;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%s%s", a[i].shu, a[i].hua);
	}
//	for (i = 0; i < n; i++) {
//		printf("%s %s\n", a[i].shu, a[i].hua);
//	}
	int k;
	scanf("%d", &k);
	struct pai temp;
	char e;
	int cnt = 0;
	scanf("%c", &e);
	char x[100];
	gets(x);
	int len = strlen(x);
	int xi[100] = {0};
	for (i = 0; i < len; i++) {
		if (x[i] >= '0' && x[i] <= '9') {
			xi[cnt++] = x[i] - '0';
		}
	}
	for (i = 0; i < k; i++) {

		for (i = 0; i < len; i++) {
			if (xi[i] != 0) {
				temp = a[xi[i]];
				a[xi[i]] = a[i];
				a[i] = temp;
			}
		}
	}
	for (i = 0; i < n; i++) {
		printf("%s %s", a[i].shu, a[i].hua);
	}


	return 0;
}