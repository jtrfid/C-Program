#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int sum1 = 0, sum2 = 0, sum3 = 0, summax;
	int i = 0;
	for (i = n; i < n * n + 1; i++) {
		if (i % 2 == 0) {
			sum2++;
		}
		if (i % 2 != 0) {
			sum1++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			sum3++;
		}

	}
	if (sum1 >= sum2) {
		summax = sum1;
	} else {
		summax = sum2;
	}
	if (summax >= sum3) {


	} else {
		summax = sum3;
	}
	printf("%d %d %d \n", sum1, sum2, sum3);
	printf("%d", summax);



	return 0;
}