#include <stdio.h>
#include <string.h>

int main() {
	int m, n;
	int a[10][10], b[10][10], c = 0;
	scanf("%d %d", &m, &n);
	int i, j, k, l;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int count = 0;
	for (i = 0; i < m; i++) {
		for (k = 0; k < m; k++) {

			for (j = 0; j < n; j++) {
				c += a[i][j] * a[k][j];

			}
			printf("%d ", c);
			c = 0;
			count++;
			if (count == m) {
				printf("\n");
				count = 0;
			}
		}
	}
}