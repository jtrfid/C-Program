#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int max;
	int i;
	int count1 = 0, count2 = 0, count3 = 0;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			count1++;
			if (i % 4 == 0 && i % 3 != 0) {
				count3++;
			}
		} else {
			count2++;
		}
	}
	max = count1 > count2 ? count1 : count2;
	printf("%d %d %d\n%d", count2, count1, count3, max);
}