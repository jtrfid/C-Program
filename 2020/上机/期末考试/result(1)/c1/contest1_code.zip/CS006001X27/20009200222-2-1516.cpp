#include <stdio.h>

int main() {
	int n, n2, a = 0, b = 0, c = 0, max = -1;
	scanf("%d", &n);
	n2 = n * n;
	while (n <= n2) {
		if (n % 2 != 0) {
			a++;
		}
		if (n % 2 == 0) {
			b++;
		}
		if (n % 4 == 0 && n % 3 != 0) {
			c++;
		}
		n++;
	}
	if (a > max) {
		max = a;
	}
	if (b > max) {
		max = b;
	}
	if (c > max) {
		max = c;
	}
	printf("%d %d %d\n%d", a, b, c, max);
}