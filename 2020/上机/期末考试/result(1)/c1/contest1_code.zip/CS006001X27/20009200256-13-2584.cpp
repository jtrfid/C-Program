#include <stdio.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int a[m][n];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int c[m][m], d[m * m] = {0};
	for (int i = 0, o = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			for (int k = 0; k < n; k++) {
				d[o] += a[i][k] * a[j][k];
			}
			o++;
		}
	}
	for (int i = 0; i < m * m; i++) {
		printf("%d ", d[i]);
		if ((i + 1) % m == 0) {
			printf("\n");
		}
	}
	return 0;
}