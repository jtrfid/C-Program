#include <stdio.h>

int main() {
	int a, b, c[100], d, e, h, i, g[50][50], x, y, z = 0, r, n;
	scanf("%d", &a);
	e = a * a;
	for (b = 0; b < e; b++) {
		scanf("%d", &c[b]);
	}
	for (d = 0; d < e; d++) {
		for (h = d + 1; h < e; h++) {
			if (c[h] < c[d]) {
				i = c[d];
				c[d] = c[h];
				c[h] = i;
			}
		}
	}
	for (x = 0; x < a; x++) {
		for (y = 0; y < a; y++) {
			g[y][x] = c[z];
			z += 1;
		}
	}
	for (r = 0; r < a; r++) {
		for (n = 0; n < a; n++) {
			printf("%d", g[n][r]);
		}
	}
}