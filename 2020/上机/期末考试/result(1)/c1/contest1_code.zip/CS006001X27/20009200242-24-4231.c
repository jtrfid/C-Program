#include <stdio.h>
#include <string.h>

struct pai {
	char n[5];
	char col[10];
};

int main() {
	void sort(struct pai s[], int a[], int m) ;
	int i, m, k, t, j, a[54];
	struct pai s[54], s2[54];
	scanf("%d", &m);
	for (i = 0; i < m; i++) {
		scanf("%s %s", s[i].n, s[i].col);
	}

	scanf("%d", &k);
	for (i = 0; i < m; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < k; i++) {

		for (t = 0; t < m; t++) {
			s2[a[t] - 1] = s[t];
		}
		for (t = 0; t < m; t++) {
			s[t] = s2[t];
		}









	}
	//for (t = 0; t < m; t++) {
	//	printf("%s ", s2[t].n);
//	}
	for (i = 0; i < m; i++) {
		t = strlen(s[i].n);
		if (t == 1) {
			if (s[i].n[0] >= '0' && s[i].n[0] <= '9')
				printf("%d ", s[i].n[0] - '0');

			else
				printf("%c ", s[i].n[0]);
		} else if (t == 2)
			printf("10 ");
		printf("%s\n", s[i].col);


	}



	return 0;
}

