#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int m = n * n;
	int a[m], b[n][n];
	int i, t, j;
	for (i = 0; i < m; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m; i++) //����
		for (j = 0; j < m - i - 1; j++) {
			if (a[j] > a[j + 1]) {
				t = a[j];
				a[j] = a[j + 1];
				a[j + 1] = t;
			}
		}
	/*for (i = 0; i < m; i++) {
		printf("%d ", a[i]);
	}*/



	int k = 0;
	for (j = 0; j < n, k < m; j++) {

		for (i = 0; i < n; i++) { //����

			b[i][j] = a[k++];
		}
	}



	for (i = 0; i < n - 1; i++) {

		for (j = 0; j < n; j++) { //����

			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	for (j = 0; j < n; j++) { //����

		printf("%d ", b[n - 1][j]);
	}
	return 0;
}
