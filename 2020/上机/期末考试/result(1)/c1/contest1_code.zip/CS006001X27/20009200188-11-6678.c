#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, j;
	int a[100];

	for (j = 0; j < n * n; j++)
		scanf("%d", &a[j]);


	int t, flag;
	for (i = 0; i < n * n; i++) {
		flag = 0;
		for (j = 0; j < n * n - i - 1; j++) {
			if (a[j] > a[j + 1]) {
				t = a[j];
				a[j] = a[j + 1];
				a[j + 1] = t;
				flag = 1;
			}
		}
		if (flag == 0)
			break;

	}
	int b[10][10] = {0};
	int sum = 0, cnt = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {

			b[j][i] = a[j + i + sum];
			cnt++;

		}
		if (cnt % n == 0) {
			sum += n;
		}
	}
	cnt = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
			cnt++;
			if (cnt % n == 0)
				printf("\n");
		}

	}


	return 0;
}