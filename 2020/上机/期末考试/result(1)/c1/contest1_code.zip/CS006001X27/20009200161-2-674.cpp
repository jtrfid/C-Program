#include <iostream>
#include <cstdio>
using namespace std;

int main() {
	int a[100] = {0};
	int n;
	int j = 0, o = 0, count = 0;
	cin >> n;
	for (int i = n; i <= n * n; i++) {
		if (i % 2 == 0) {
			o++;
		} else if (i % 2 != 0) {
			j ++;
		}
		if (i % 4 == 0 && i % 3 != 0) {
			count ++;
		}
	}
	printf("%d %d %d\n", j, o, count);
	int max = j;
	int b[3] = {0};
	b[0] = j;
	b[1] = o;
	b[2] = count;
	for (int i = 0; i < 2; i++) {
		if (b[i] > max) {
			max = b[i];
		}
	}
	cout << max;
	return 0;
}