#include <stdio.h>

int main() {
	int n, aa[1000] = {0};
	scanf("%d", &n);
	int i1, i2, i3 = 0, i4, i5, i6, t, f1 = 0;
	for (i6 = 0; i6 <= n * n - 1; i6++) {
		scanf("%d", &t);
		aa[i6] = t;

	}


	while (1) {
		f1 = 0;
		for (i2 = 0; i2 <= n * n - 1; i2++) {
			if (aa[i2 + 1] < aa[i2] && i2 + 1 <= n * n - 1) {
				t = aa[i1 + 1];
				aa[i2 + 1] = aa[i2];
				aa[i2] = t;
				f1 = 1;







			}
		}
		if (f1 == 0)
			break;
	}

	int bb[n][n] = {0};
	for (i2 = 0; i2 <= n - 1; i2++) {
		for (i1 = 0; i1 <= n - 1; i1++) {
			bb[i1][i2] = aa[i3];
			i3++;
		}
	}

	for (i1 = 0; i1 <= n - 1; i1++) {
		for (i2 = 0; i2 <= n - 1; i2++) {
			printf("%d ", bb[i1][i2]);
		}
		printf("\n");
	}
	return 0;
}