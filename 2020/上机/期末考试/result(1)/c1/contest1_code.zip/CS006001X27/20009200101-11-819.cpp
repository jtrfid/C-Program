#include <stdio.h>

int main () {
	int n, i, j, x = 0;
	int a[100];
	int b[10][10];
	scanf("%d", &n);
	int m = n * n;
	for (i = 0; i < m; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m - 1; i++) {
		for (j = i + 1; j < m; j++) {
			if (a[j] < a[i]) {
				int temp;
				temp = a[j];
				a[j] = a[i];
				a[i] = temp;
			}
		}
	}
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			b[i][j] = a[x];
			x++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}

	return 0;
}