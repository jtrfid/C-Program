#include <stdio.h>

int main() {
	int n, i, j, k = 0, t;
	int a[10][10], b[100];
	scanf("%d", &n);
	for (i = 0; i < n * n; i++) {
		scanf("%d", &b[i]);
	}
	for (i = 0; i < n * n; i++) {
		for (j = i + 1; j < n * n; j++) {
			if (b[j] < b[i]) {
				t = b[j];
				b[j] = b[i];
				b[i] = t;
			}
		}
	}
	/*	for (i = 0; i < n * n; i++)
			printf("%d", b[i]);*/
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			a[i][j] = 0;
		}
	}
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			a[i][j] = b[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}

	return 0;
}