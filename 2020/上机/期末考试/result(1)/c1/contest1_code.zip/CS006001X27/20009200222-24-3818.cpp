#include <stdio.h>
#include <string.h>

int main() {
	int n, m;
	scanf("%d", &n);
	char c[102][n + 1][50];
	int i = 1;
	getchar();
	while (i <= n) {
		gets(c[1][i]);
		i++;
	}
	scanf("%d", &m);
	i = 1;
	int s[n + 1];
	while (i <= n) {
		scanf("%d", &s[i]);
		i++;
	}
	int j = 1;
	while (j <= m) {
		i = 1;
		while (i <= n) {
			strcpy(c[j + 1][i], c[j][s[i]]);
			i++;
		}
		j++;
	}
	i = 1;
	while (i <= n) {
		printf("%s\n", c[j][i]);
		i++;
	}
	return 0;
}