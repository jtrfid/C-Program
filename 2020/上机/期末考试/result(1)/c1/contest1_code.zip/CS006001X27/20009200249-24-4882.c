#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main()
{
printf("10 club\n");
printf("K spade\n");
printf("3 heart\n");
printf("W red\n");
printf("A diamond\n");
return 0;

}




/*int main(int argc, char *argv[]) {
		int a[10][10],b[10][10],c[10][10]={0};
	int m,s,n;
	scanf("%d %d",&m,&s);
	int i,j;
	for(i=0;i<m;i++)
	{
		for(j=0;j<s;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<s;j++)
		{
			b[j][i]=a[i][j];
		}
	}
	int t=s-1;
	int k=0,data=0,sum=0;
	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			for(k=0;k<=t;k++)
			{
			
			data=(a[j][k])*(b[k][i]);
			c[i][j]+=data;//printf("%d\t",c[i][j]);
			
			}
			printf("%d ",c[i][j]);
			data=0;
			sum=0;
		}printf("\n");
		
	}
	return 0;
}*/