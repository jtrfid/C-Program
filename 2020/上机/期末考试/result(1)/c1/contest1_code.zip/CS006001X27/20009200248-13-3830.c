#include <stdio.h>

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	int a[100][100];
	int i, j, i1;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	int b[100][100];
	for (j = 0; j < n; j++) {
		for (i = 0; i < m; i++) {
			b[j][i] = a[i][j];
		}
	}
//	for (i = 0; i < n; i++) {
//		for (j = 0; j < m; j++) {
//			printf("%d ", b[i][j]);
//		}
//		printf("\n");
//	}
	int min = m;
	if (m > n)
		min = n;
	int c[100][100];
	for (i = 0; i < min; i++) {
		for (j = 0; j < min; j++) {
			for (i1 = 0; i1 < n; i1++) {
				c[i][j] += a[i][i1] * b[i1][j];
			}
		}
	}
	for (i = 0; i < min; i++) {
		for (j = 0; j < min; j++) {
			printf("%d ", c[i][j]);
		}
		printf("\n");
	}
	return 0;
}