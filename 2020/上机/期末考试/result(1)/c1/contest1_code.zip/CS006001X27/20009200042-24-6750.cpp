#include <stdio.h>
#include <string.h>

int main() {
	int n;
	scanf("%d", &n);
	printf("n=%d", n);
	getchar();
	int i = 0;
	int q = 0;
	int p = 0;
	int length;
	char pai[n][12];
	char copy[n][12];
	for (i = 0; i < n; i++) {
		for (q = 0; q < 10 && (pai[i][q] = getchar()) != '\n'; q++)
			;
	}
	int m = 0;
	int b[n] = {0};

	scanf("%d", &m);

	for (i = 0; i < n; i++) {
		scanf("%d", &b[i]);
	}
	for (i = 0; i < m; i++) {
		for (q = 0; q < n; q++) {
			for (p = 0; p < 12; p++) {
				copy[q][p] =	pai[q][p];
			}
		}
		for (q = 0; q < n; q++) {
			length = strlen(pai[q]);
			for (p = 0; p < length; p++) {
				pai[b[q]][p] = copy[q][p];
			}
		}
	}
	for (i = 0; i < n; i++) {
		length = strlen(pai[i]);
		for (p = 0; p < length; p++) {
			printf("%c", pai[i][p]);
		}
	}

	return 0;
}