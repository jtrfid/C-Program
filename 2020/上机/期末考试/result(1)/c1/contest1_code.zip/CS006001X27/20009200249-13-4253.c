#include <stdio.h>
#include <stdlib.h>

int main()
{
	int a[10][10],b[10][10],c[10][10]={0};
	int m,s,n;
	scanf("%d %d",&m,&s);
	int i,j;
	for(i=0;i<m;i++)
	{
		for(j=0;j<s;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<s;j++)
		{
			b[j][i]=a[i][j];
		}
	}
	int t=s-1;
	int k=0,data=0,sum=0;
	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			for(k=0;k<=t;k++)
			{
			
			data=(a[j][k])*(b[k][i]);
			c[i][j]+=data;//printf("%d\t",c[i][j]);
			
			}
			printf("%d ",c[i][j]);data=0;sum=0;
		}printf("\n");
		
	}
	
	
	
	
	
	
	
	
	
	
/*	for(i=0;i<s;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}printf("\n");
	}*/
	return 0;
}
































/*int main() 
{
	int n;
	scanf("%d",&n);
	int i,j;
	char ab[20][54];
	
		for(j=0;j<n;j++)
		{
			for(i=0;i<20;i++)
			{
				scanf("%d",&ab[i][j]);
			//	if(ab[i][j]=='\n')
				
			}
		}
	
	return 0;
}*/