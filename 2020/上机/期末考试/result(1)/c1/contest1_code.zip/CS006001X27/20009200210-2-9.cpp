#include <bits/stdc++.h>
using namespace std;

int main() {
	int n, a = 0, b = 0, c = 0, MAX = 0;
	cin >> n;
	for (int i = n; i <= n * n; i++) {
		if (i % 2 == 1)
			a++;
		if (i % 2 == 0)
			b++;
		if (i % 4 == 0 && i % 3 != 0)
			c++;
	}
	MAX = max(a, MAX);
	MAX = max(b, MAX);
	MAX = max(c, MAX);
	cout << a << " " << b << " " << c << endl;
	cout << MAX;
	return 0;
}