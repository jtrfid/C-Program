#include <stdio.h>
#include <string.h>

int main() {
	struct num {
		int place;
		char name[30];
	} p[55] = {0, 0};
	int n, i, j, k, m;
	int a[100] = {0};
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		gets(p[i].name);
		p[i].place = i;
	}
	scanf("%d", &m);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			p[j].place = a[j];
		}
	}
	for (i = 0; i < n; i++) {
		for (j = i; j < n; j++) {
			if (p[j].place < p[i].place) {
				p[55] = p[i];
				p[j] = p[i];
				p[i] = p[55];
			}
		}
	}
	for (i = 0; i < n; i++) {
		puts(p[i].name);
	}
	return 0;
}