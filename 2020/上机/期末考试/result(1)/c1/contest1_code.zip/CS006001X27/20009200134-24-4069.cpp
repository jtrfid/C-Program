#include <stdio.h>
#include <string.h>

char card[54][15] = {'\0'};
int n;

char ans[54][15] = {'\0'};

int xipai[54] = {0};

void paixu() {
	for (int i = 0 ; i < n ; i++) {
		strcpy(ans[xipai[i] - 1], card[i]);
	}
	for (int i = 0 ; i < n ; i++) {
		strcpy(card[i], ans[i]);
	}
}



int main() {
	scanf("%d", &n);

	getchar();
	for (int i = 0 ; i < n ; i++) {
		gets(card[i]);
		//puts(card[i]);
	}
	int k;
	scanf("%d", &k);


	for (int i = 0 ; i < n ; i++) {
		scanf("%d", &xipai[i]);
		//printf("%d ", xipai[i]);
	}
	//printf("\n");

	for (int i = 0 ; i < k ; i++) {
		paixu();
	}

	for (int i = 0 ; i < n ; i++) {
		//printf("��%d��\n", i);
		puts(card[i]);
		//printf("\n");
	}
	return 0;
}