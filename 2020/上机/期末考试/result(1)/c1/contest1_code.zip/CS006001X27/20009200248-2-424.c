#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int i, n;
	int sum1 = 0, sum2 = 0, sum3 = 0;
	scanf("%d", &n);
	for (i = n; i >= n && i <= n * n; i++) {
		if (i % 2 == 1)
			sum1 = sum1 + 1;
		if (i % 2 == 0)
			sum2 = sum2 + 1;
		if (i % 4 == 0 && i % 3 != 0)
			sum3 = sum3 + 1;
	}
	int max = 0;
	if (sum1 > sum2) {
		max = sum1;
	} else {
		max = sum2;
	}
	if (max < sum3)
		max = sum3;
	printf("%d %d %d\n", sum1, sum2, sum3);
	printf("%d", max);
	return 0;
}