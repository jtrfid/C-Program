#include <stdio.h>
#include <string.h>

int main() {
	int n;
	int sum1 = 0;
	int sum2 = 0;
	int sum3 = 0;
	scanf("%d", &n);
	int i;
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			sum2++;
		else
			sum1++;
		if (i % 4 == 0 && i % 3 != 0)
			sum3++;
	}
	int max = 0;
	if (sum1 > sum2 && sum1 > sum3)
		max = sum1;
	if (sum2 > sum1 && sum2 > sum3)
		max = sum2;
	if (sum3 > sum1 && sum3 > sum2)
		max = sum3;
	printf("%d %d %d\n", sum1, sum2, sum3);
	printf("%d", max);




	return 0;
}

