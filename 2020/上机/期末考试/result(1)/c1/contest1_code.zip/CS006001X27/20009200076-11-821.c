#include <stdio.h>

int main() {
	int n;
	int a[10][10];
	scanf("%d", &n);
	int b[100];
	int i;
	for (i = 0; i < n * n; i++) {
		scanf("%d", &b[i]);
	}
	int j, t;
	for (i = 0; i < n * n - 1; i++) {
		for (j = i + 1; j < n * n; j++) {
			if (b[j] < b[i]) {
				t = b[i];
				b[i] = b[j];
				b[j] = t;
			}
		}
	}
	int min = 0;
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			a[i][j] = b[min];
			min++;
		}
	}
	int count = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", a[i][j]);
			count++;
		}
		if (count == n) {
			printf("\n");
			count = 0;
		}
	}
	return 0;
}
