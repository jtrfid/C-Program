#include <stdio.h>

typedef struct {
	char pai[3];
	char hs[8];
} poker;

int main() {
	int n;
	scanf("%d", &n);
	int i, j;
	poker a[54], b[54];
	for (i = 1; i <= 5; i++) {
		scanf("%s %s", &a[i].pai, &a[i].hs);
	}
	int t;
	scanf("%d", &t);
	int order[100] = {0};
	for (i = 1; i <= n; i++) {
		scanf("%d", &order[i]);
	}
	if (t % 2 == 0) { //ż����
		for (i = 1; i <= t / 2; i++) { //����
			for (j = 1; j <= n; j++) {
				b[order[j]] = a[j];
			}
			for (j = 1; j <= n; j++) {
				a[order[j]] = b[j];
			}
		}
	}

	else { //������ϴ��
		for (i = 1; i <= (t - 1) / 2; i++) { //����
			for (j = 1; j <= n; j++) {
				b[order[j]] = a[j];
			}
			for (j = 1; j <= n; j++) {
				a[order[j]] = b[j];
			}
		}
		for (j = 1; j <= n; j++) {
			b[order[j]] = a[j];
		}
	}
	if (t % 2 == 0) {
		for (j = 1; j <= n; j++) {
			printf("%s %s\n", a[j].pai, a[j].hs);
		}
	} else {
		for (j = 1; j <= n; j++) {
			printf("%s %s\n", b[j].pai, b[j].hs);
		}
	}

}