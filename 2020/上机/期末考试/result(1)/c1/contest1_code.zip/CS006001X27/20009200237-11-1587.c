#include <stdio.h>

int main() {
	int n, i, j, k = 0, temp, t[100], s[10][10];
	scanf("%d", &n);
	for (i = 0; i < n * n; i++)
		scanf("%d", &t[i]);
	for (i = 0; i < n * n - 1; i++)
		for (j = i + 1; j < n * n; j++)
			if (t[j] < t[i]) {
				temp = t[i];
				t[i] = t[j];
				t[j] = temp;
			}
	for (i = 0; i < n ; i++)
		for (j = 0; j < n; j++) {
			s[j][i] = t[k];
			k++;
		}
	for (i = 0; i < n ; i++) {
		for (j = 0; j < n; j++)
			printf("%d ", s[i][j]);
		printf("\n");
	}
	return 0;
}