#include <stdio.h>

int main() {
	int n, m, i, j, temp, k = 0;
	scanf("%d", &n);
	m = n * n;
	int a[m], b[n][n];
	for (i = 0; i < m; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 0; i < m; i++) {
		for (j = i + 1; j < m; j++) {
			if (a[i] > a[j]) {
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			b[i][j] = a[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");

	}
	return 0;


}