#include <stdio.h>

struct card {
	char hua[8];
	char shu[2];
};

int main() {
	int n, time;
	char x;
	scanf("%d", &n);
	struct card c[n], c1;
	int i, k, s;
	for (i = 0; i < n; i++) {
		for (k = 0; k < 2; k++)
			c[i].shu[k] = '\0';
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < 8; k++)
			c[i].hua[k] = '\0';
	}
	x = getchar();
	for (i = 0; i < n; i++) {
		scanf("%s", &c[i].shu);
		x = getchar();
		gets (c[i].hua);
	}
	scanf("%d", &time);
	int way[time];
	for (i = 0; i < n; i++) {
		scanf("%d", &way[i]);
	}
	for (i = 0; i < 1; i++) {
		for (k = 0; k < n; k++) {
			c1 = c[way[k]];
			c[way[k]] = c[k];
			c[k] = c1;
		}
		for (i = 0; i < n; i++) {
			printf("%s ", c[i].shu);
		}
	}
	return 0;
}