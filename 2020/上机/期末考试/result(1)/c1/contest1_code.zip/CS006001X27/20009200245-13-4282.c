//3
#include <stdio.h>

int main() {
	int m, n, i, j, k;
	int a[100][11], b[11][100], c[100][100];
	scanf("%d%d", &m, &n);


	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);


	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++) {
			b[j][i] = a[i][j];

		}

	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			c[i][j] = 0;
			for (k = 0; k < n; k++) {
				c[i][j] += a[i][k] * b[k][j];

			}
		}
	}

	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			if (j == m - 1)
				printf("%d\n", c[i][j]);
			else
				printf("%d ", c[i][j]);
		}
	}
	return 0;
}