#include <stdio.h>

int max(int a, int b, int c) {
	if (a > b && a > c)
		return a;
	else if (b > a && b > c)
		return b;
	else if (c > a && c > b)
		return c;
	else
		return 0;
}

int main() {
	int n;
	scanf("%d", &n);
	int a = 0, b = 0, c = 0;
	for (int i = n; i <= n * n; i++) {
		if (i % 2 != 0)
			a++;
		else
			b++;
	}
	for (int i = n; i <= n * n; i++) {
		if (i % 4 == 0 && i % 3 != 0)
			c++;
	}
	printf("%d %d %d\n", a, b, c);
	printf("%d", max(a, b, c));
	return 0;
}