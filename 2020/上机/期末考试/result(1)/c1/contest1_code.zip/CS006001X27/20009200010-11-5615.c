#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
	int n;
	scanf("%d", &n);
	int ch[n * n], i, j;
	for (i = 0; i < (n * n); i++) {
		scanf("%d", &ch[i]);
	}
	for (i = 0; i < (n * n); i++) {
		for (j = i + 1; j < (n * n); j++) {
			if (ch[j] < ch[i]) {
				int num = ch[i];
				ch[i] = ch[j];
				ch[j] = num;
			}
		}

	}
	int ah[n][n], k = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			ah[j][i] = ch[k];
			k++;
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%d", ah[i][j]);
			if (j < n - 1) {
				printf(" ");
			}
			if (j == n - 1 && i != n - 1) {
				printf("\n");
			}
		}
	}

	return 0;
}