#include <stdio.h>
int num[100][100];
int b[100][100];
int c[100][100];

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, j;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &num[i][j]);

		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			b[i][j] = num[j][i];
			//printf("%d ", b[i][j]);
		}

	}//b ת�����
	int x, y;
	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			for (x = 0; x < n; x++) {

				c[i][j] += num[i][x] * b[x][j];

			}
		}
	}

	for (i = 0; i < m; i++) {
		for (j = 0; j < m; j++) {
			printf("%d ", c[i][j]);
		}
		putchar('\n');
	}



	return 0;
}