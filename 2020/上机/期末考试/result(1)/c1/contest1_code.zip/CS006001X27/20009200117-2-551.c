#include <stdio.h>
#include <string.h>

int main() {
	int n, i;
	int sum1 = 0, sum2 = 0, sum3 = 0, max;
	scanf("%d", &n);
	for (i = n; i <= n * n; i++) {
		if (i % 2 == 0)
			sum1++;
		else
			sum2++;
	}
	for (i = n; i <= n * n; i++) {
		if (i % 4 == 0 && i % 3 != 0)
			sum3++;
	}
	max = sum1;
	if (sum2 > max)
		max = sum2;
	if (sum3 > max)
		max = sum3;
	printf("%d %d %d\n", sum2, sum1, sum3);
	printf("%d", max);
	return 0;
}
