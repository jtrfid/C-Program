#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

struct Student {
	string id, bg, ed;

	bool operator<(const Student &a) const {
		return this->bg < a.bg;
	}

	bool operator>(const Student &a) const {
		return this->ed > a.ed;
	}
} stu[102], open, close;

int n;

void init() {
	open.bg = "23:59:59";
	close.ed = "00:00:00";
}

int main() {
	init();
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		cin >> stu[i].id >> stu[i].bg >> stu[i].ed;
		open = stu[i] < open ? stu[i] : open;
		close = stu[i] > close ? stu[i] : close;
	}
	cout << open.id << ' ' << close.id << endl;
	return 0;
}
