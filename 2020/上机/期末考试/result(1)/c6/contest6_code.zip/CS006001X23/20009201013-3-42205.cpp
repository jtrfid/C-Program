#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int A,B;
	scanf("%d %d",&A,&B);
	int max=A>B?A:B;
	int min=A<B?A:B;
	int MIN;
	int i=0;
	int s1=0,s2=0,s3=0;
	for(i=max;i>=min;i--)
	{
		if(i%3==0)
		s1++;
		if(i%4==0)
		s2++;
		if(i%5==0&&i%2!=0)
		s3++;
	}
	MIN=s1;
	if(s1>s2)
	MIN=s2;
	if(s1>s3)
	MIN=s3;
	if(s3>s2)
	MIN=s2;
	printf("%d %d %d\n%d",s1,s2,s3,MIN);
	
	
	return 0;
}

