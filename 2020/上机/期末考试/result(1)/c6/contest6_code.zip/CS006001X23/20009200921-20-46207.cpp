#include<stdio.h>
struct qiandao{
	char xuehao[50];
	char lai[50];
	char zou[50];
};

int main()
{
	int i,j,k,n;
    scanf("%d",&n);
	struct qiandao li[50];
	struct qiandao test;
    for(i=0;i<n;i++)
    {
    	scanf("%s %s %s",&li[i].xuehao,&li[i].lai,&li[i].zou);
    }
    for(i=0;i<9;i++)
    {
		for(j=0;j<n;j++)
    	{
    		for(k=0;k<n-j-1;k++)
    		{
    			if(i==0)
    			{
    				if(li[k].lai[i]>li[k+1].lai[i])
    				{
    				test=li[k];
    				li[k]=li[k+1];
    				li[k+1]=test;
    				}
    			}
				else if(i==1)
				{
					if(li[k].lai[i]>li[k+1].lai[i]&&li[k].lai[i-1]==li[k+1].lai[i-1])
    				{
    				test=li[k];
    				li[k]=li[k+1];
    				li[k+1]=test;
    				}
    			}
    			else
				{
					if(li[k].lai[i]>li[k+1].lai[i]&&li[k].lai[i-1]==li[k+1].lai[i-1]&&li[k].lai[i-2]==li[k+1].lai[i-2])
    				{
    				test=li[k];
    				li[k]=li[k+1];
    				li[k+1]=test;
    				}
    			}
    		}
    	}
    }
    printf("%s ",li[0].xuehao);
	for(i=0;i<9;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		for(k=0;k<n-j-1;k++)
    		{
    			if(i==0)
				{
					if(li[k].zou[i]<li[k+1].zou[i])
    				{
    				test=li[k];
    				li[k]=li[k+1];
    				li[k+1]=test;
    				}
    			}
    			else if(i==1)
    			{
    				if(li[k].zou[i]<li[k+1].zou[i]&&li[k].zou[i-1]==li[k+1].zou[i-1])
    				{
    				test=li[k];
    				li[k]=li[k+1];
    				li[k+1]=test;
    				}
    			}
    			else
    			{
    				if(li[k].zou[i]<li[k+1].zou[i]&&li[k].zou[i-1]==li[k+1].zou[i-1]&&li[k].zou[i-2]==li[k+1].zou[i-2])
    				{
    				test=li[k];
    				li[k]=li[k+1];
    				li[k+1]=test;
    				}
    			}
    			
    			
    		}
    	}
    }
    printf("%s",li[0].xuehao);
}
