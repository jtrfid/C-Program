#include<stdio.h>
#include<string.h>
int main(){
	char c[50]={'0'};
	int L,i,sum=0,count=0;
	gets(c);
	L=strlen(c);
	for(i=0;i<L;i++){
		if(c[i]>='0'&&c[i]<='8'){
			sum+=(c[i]-'0');
			count++;
		}
	}
	if(count!=0)
		printf("%d",sum);
	else
		printf("NO");
	return 0;
}

