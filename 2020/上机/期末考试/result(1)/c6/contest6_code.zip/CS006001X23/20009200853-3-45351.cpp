#include<stdio.h>
#include<string.h>
int main()
{
	int a,b,c=0,d=0,e=0,i=0,j=0,p,k=0;
     int q[1000];
	scanf("%d %d",&a,&b);
	if(a>b)
	{
	   for(i=0,k=0;i<=a-b;i++,k++)
	   {
	   	q[i]=b+k;
	   }
	   for(i=0;i<=a-b;i++)
	    {
	    	if(q[i]%3==0)
	    	{
	    		c++;
	    	}
	    	if(q[i]%4==0)
	    	{
	    		d++;
	    	}
	    	if(q[i]%5==0&&q[i]%2!=0)
	    	{
	    		e++;
	    	}
			
	    }
	   
	    if(c>d>e||d>c>e) p=e;
	    else if(d>e>c||e>d>c) p=c;
	     else if(c>e>d||e>c>d) p=d;
	}
	else
	b=j;j=a;a=b;
	{
	  for(i=0,k=0;i<=a-b;i++,k++)
	   {
	   	q[i]=b+k;
	   }
	   for(i=0;i<=a-b;i++)
	    {
	    	if(q[i]%3==0)
	    	{
	    		c++;
	    	}
	    	if(q[i]%4==0)
	    	{
	    		d++;
	    	}
	    	if(q[i]%5==0&&q[i]%2!=0)
	    	{
	    		e++;
	    	}
			
	    }
	   
	    if(c>d>e||d>c>e) p=e;
	    else if(d>e>c||e>d>c) p=c;
	     else if(c>e>d||e>c>d) p=d;  
	}
	
	printf("%d %d %d\n",c,d,e);
	printf("%d",p);
	return 0;
}
