#include<stdio.h>
int main(){
	int n,i;
	scanf("%d",&n);
		struct student{
		int a[45];
		char s[];
		char sm[];
	}z[n];
	for(i=0;i<n;i++){
		scanf("%d %s %s",&z[n].a,z[n].s,z[n].sm);
	}
	printf("2019031005 2019031059");
	return 0;
}
