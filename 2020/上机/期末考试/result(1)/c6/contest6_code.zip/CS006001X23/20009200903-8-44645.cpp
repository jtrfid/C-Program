#include<stdio.h>
#include<string.h>

int main()
{
	char s[51]={0};
	scanf("%s",&s);
	int l=strlen(s);
	int sum=0,k=0;
	for(int i=0;i<l;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			sum+=s[i]-'0';k++;
		}
		if(s[i]=='a'||s[i]=='A')
		{
			sum=sum+10;k++;
		}
		if(s[i]=='b'||s[i]=='B')
		{
			sum=sum+11;k++;
		}
		if(s[i]=='c'||s[i]=='C')
		sum=sum+12;k++;
		if(s[i]=='d'||s[i]=='D')
		sum=sum+13;k++;
		if(s[i]=='e'||s[i]=='E')
		sum=sum+14;k++;
		if(s[i]=='f'||s[i]=='F')
		sum=sum+15;k++;
	}
	if(k==0)
	{
		printf("NO");
	}
	else
	printf("%d",sum);
	return 0;
}
