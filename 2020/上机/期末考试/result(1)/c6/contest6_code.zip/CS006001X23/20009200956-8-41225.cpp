#include<stdio.h>
#include<string.h>
int main()
{
	char c[50]={0};
	int i,j=0,k=0;
	gets(c);
	for(i=0;c[i]!=0;i++)
	{
		if(c[i]=='0')
		{
			j=1;
		}
		if(c[i]>='1'&&c[i]<='9')
		{
			k+=(c[i]-'0');
		}
		if(c[i]=='a'||c[i]=='A')
		{
			k+=10;
		}
			if(c[i]=='b'||c[i]=='B')
		{
			k+=11;
		}
			if(c[i]=='c'||c[i]=='C')
		{
			k+=12;
		}
			if(c[i]=='d'||c[i]=='D')
		{
			k+=13;
		}
			if(c[i]=='e'||c[i]=='E')
		{
			k+=14;
		}
			if(c[i]=='f'||c[i]=='F')
		{
			k+=15;
		}
	}
	if(k!=0||j==1)
	{
		printf("%d",k);
	
	}
	else
	printf("NO");
	
	
	
	
	
	return 0;
}
