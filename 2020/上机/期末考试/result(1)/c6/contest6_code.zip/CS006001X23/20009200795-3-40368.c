#include<stdio.h>
int main()
{
	int i,a,min=1000,temp=0,b,three=0,four=0,five=0;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	for(i=a;i<b+1;i++)
	{
		if((i%3)==0)
		{
			three=three+1;
		}
		if((i%4)==0)
		{
			four=four+1;
		}
		if((i%5)==0&&(i%2)!=0)
		{
			five=five+1;
		}
	}
	if(three<min)
	{
		min=three;
	}
	if(four<min)
	{
		min=four;
	}
	if(five<min)
	{
		min=five;
	}
	printf("%d ",three);
	printf("%d ",four);
	printf("%d\n",five);
	printf("%d",min);
	return 0;
}
