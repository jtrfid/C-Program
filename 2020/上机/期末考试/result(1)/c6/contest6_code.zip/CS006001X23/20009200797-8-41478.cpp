#include<stdio.h>
#include<string.h>
int main()
{
	char x[50]={0};
	gets(x);
	strlwr(x);
	int sum=0;
	int i;
	for ( i=0; x; i++ ){
		if ( x[i]=='1')
		sum=sum+1;
		if ( x[i]=='2')
		sum=sum+2;
		if ( x[i]=='3')
		sum=sum+3;
		if ( x[i]=='4')
		sum=sum+4;
		if ( x[i]=='5')
		sum=sum+5;
		if ( x[i]=='6')
		sum=sum+6;
		if ( x[i]=='7')
		sum=sum+7;
		if ( x[i]=='8')
		sum=sum+8;
		if ( x[i]=='9')
		sum=sum+9;
		if ( x[i]=='a')
		sum=sum+10;
		if ( x[i]=='b')
		sum=sum+11;
		if ( x[i]=='c')
		sum=sum+12;
		if ( x[i]=='d')
		sum=sum+13;
		if ( x[i]=='e')
		sum=sum+14;
		if ( x[i]=='f')
		sum=sum+15;
	}
	
	if ( sum==0 )
	printf("NO");
	else
	printf("%d", sum);
	
	
	
	
	
	
	
	
	
	
}
