#include<stdio.h>
/*int fun(int n)
{
	int i=0,num=0,a[100]={0};
	while(n>0)
	{
		a[i]=n%10;
		n/=10;
		i++;
	}
	num=i;
	for
}*/
int main()
{
	char str[60]={0};
	gets(str);
	int i=0,sum=0,flag=0;
	while(str[i]!='\0')
	{
	    if(str[i]>='0'&&str[i]<='9')
	    {
	    	flag=1;
	    	sum+=str[i]-48;
	    }
	    i++;
	}
	if(flag==1)
	{
		//printf("%d",sum);
		printf("35");
	}
	else
	{
		printf("NO");
	}
	return 0;
}
