#include<stdio.h>
int main()
{
	int a,b,t,i,x=0,y=0,z=0,min;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		if(i%3==0)x++;
		if(i%4==0)y++;
		if(i%5==0&&i%2!=0)z++;
	}
	min=x<y?x:y;
	min=min<z?min:z;
	printf("%d %d %d\n",x,y,z);
	printf("%d",min);
	return 0;
}
