#include<stdio.h>
int main(){
	int m,i,j,k;
	int a[10][10],b[10][10];
	scanf("%d",&m);
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(j=0;j<(m/2);j++){
		for(i=(m/2),k=0;i<m;i++,k++){
			b[k][j]=a[i][j];
		}
	}
	for(i=0;i<(m/2);i++){
		for(j=0,k=(m/2);j<(m/2);j++,k++){
			b[i][k]=a[i][j];
		}
	}
	for(j=(m/2);j<m;j++){
		for(i=0,k=(m/2);i<(m/2);i++,k++){
			b[k][j]=a[i][j];
		}
	}
	for(i=(m/2);i<m;i++){
		for(j=(m/2),k=0;j<m;j++,k++){
			b[i][k]=a[i][j];
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
	
	
	
	
	
	
	
	
}
