#include<cstdio>
int a[20][20],b[20][20];
int main()
{
	int m;
	scanf("%d",&m);
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	int k=m/2;
	for(int i=1;i<=k;i++)
	{
		for(int j=1;j<=k;j++)
		{
			b[i][j]=a[i+k][j];
		}
	}
	for(int i=1;i<=k;i++)
	{
		for(int j=k+1;j<=m;j++)
		{
			b[i][j]=a[i][j-k];
		}
	}
	for(int i=k+1;i<=m;i++)
	{
		for(int j=1;j<=k;j++)
		{
			b[i][j]=a[i][j+k];
		}
	}
	for(int i=k+1;i<=m;i++)
	{
		for(int j=k+1;j<=m;j++)
		{
			b[i][j]=a[i-k][j];
		}
	}
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
}
