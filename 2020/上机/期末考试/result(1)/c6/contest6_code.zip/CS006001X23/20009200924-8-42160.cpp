#include<stdio.h>
#include<string.h>
int main(){
	char c[50]={'0'};
	int L,i,sum=0,count=0;
	gets(c);
	L=strlen(c);
	for(i=0;i<L;i++){
		if(c[i]>='0'&&c[i]<='9'){
			sum+=(c[i]-'0');
			count++;
		}else if(c[i]>='a'&&c[i]<='f'){
			sum=sum+(c[i]-'a')+10;
			count++;
		}else if(c[i]>='A'&&c[i]<='F'){
			sum=sum+(c[i]-'A')+10;
			count++;
		}
	}
	if(count!=0)
		printf("%d",sum);
	else
		printf("NO");
	return 0;
}

