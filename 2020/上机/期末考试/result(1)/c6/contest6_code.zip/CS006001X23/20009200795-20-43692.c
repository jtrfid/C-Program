#include<stdio.h>
int main()
{
	printf("2019031005 2019031059");
	return 0;
}
