#include<stdio.h>
#include<string.h>
int main(){
	char x[51]={0};
	int i,s,m,t;
	gets(x);
	m=strlen(x);
	for(i=0,s=0,t=0;i<m;i++){
		if(x[i]>='0'&&x[i]<='9'){s=s+x[i]-48;t=1;
		}
		if(x[i]=='a'||x[i]=='A'){s+=10;t=1;
		}
		if(x[i]=='b'||x[i]=='B'){s+=11;t=1;
		}
		if(x[i]=='c'||x[i]=='C'){s+=12;t=1;
		}
		if(x[i]=='d'||x[i]=='D'){s+=13;t=1;
		}
		if(x[i]=='e'||x[i]=='E'){s+=14;t=1;
		}
		if(x[i]=='f'||x[i]=='F'){s+=15;t=1;
		}
	}
	if(t==0)printf("NO");
	else printf("%d",s);
	return 0;
}
