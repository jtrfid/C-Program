#include<stdio.h>
int main()
{
	int m,i,j,a[20][20],b[20][20];
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		scanf("%d",&a[i][j]);
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(i<=(m-1)/2 && j<=(m-1)/2)
			{
				b[i][j+m/2]=a[i][j];
			}
			else if(j>(m-1)/2 && i<=(m-1)/2)
			{
				b[i+m/2][j]=a[i][j];
			}
			else if(j>(m-1)/2 && i>(m-1)/2)
			{
				b[i][j-m/2]=a[i][j];
			}
			else
			{
				b[i-m/2][j]=a[i][j];
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
}
