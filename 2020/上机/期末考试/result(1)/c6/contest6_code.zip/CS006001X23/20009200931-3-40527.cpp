#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int a,b;
	int i,temp,c1,d1,e1,e2;
	int c=0,d=0,e=0;
	int min=0;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	for(i=a;i<=b&&i>=a;i++)
	{
		c1=i%3;
		d1=i%4;
		e1=i%5;
		e2=i%2;
		if(c1==0)
		{
			c++;
		}
		if(d1==0)
		{
			d++;
		}
		if(e1==0&&e2!=0)
		{
			e++;
		}
	}
	if(c<=d&&c<=e)
	{
		min=c;
	}
	else if(d<=c&&d<=e) 
	{
		min=d;
	}
	else min=e;
	printf("%d %d %d\n",c,d,e);
	printf("%d",min);
	return 0;
}
