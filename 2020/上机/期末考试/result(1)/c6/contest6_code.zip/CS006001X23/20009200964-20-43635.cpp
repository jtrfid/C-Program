#include<stdio.h>
typedef struct{
	char num[20];
	int sth;
	int stm;
	int sts;
	int stsum;
	int endh;
	int endm;
	int ends;
	int endsum;
}student;
int main(){
	student stu[101];
	student temp;
	int n,i,j,min,max;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s %d:%d:%d %d:%d:%d",&stu[i].num,&stu[i].sth,&stu[i].stm,&stu[i].sts,&stu[i].endh,&stu[i].endm,&stu[i].ends);
	}
	for(i=0;i<n;i++)
	{
		stu[i].stsum=stu[i].sth*60*60+stu[i].stm*60+stu[i].sts;
		stu[i].endsum=stu[i].endh*60*60+stu[i].endm*60+stu[i].ends;
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(stu[j].stsum>stu[j+1].stsum)
			{
				temp=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=temp;
			}
		}
	}
	printf("%s ",stu[0].num);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(stu[j].endsum<stu[j+1].endsum)
			{
				temp=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=temp;
			}
		}
	}
	printf("%s",stu[0].num);
	return 0;
}
