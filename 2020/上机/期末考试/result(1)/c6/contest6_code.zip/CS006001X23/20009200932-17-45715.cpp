#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	int a[m][m];
	int i,j,k;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	int b[m][m];
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			b[i][j]=0;
		}
	}
		for(j=0;j<m;j++)
		{
			for(k=0;k<m;k++)
			{
				if(j<m/2&&k<m/2)
				{
					b[j][k+m/2]=a[j][k];
				}
				else if(j>=m/2&&k<m/2)
				{
					b[j-m/2][k]=a[j][k];
				}
				else if(j>=m/2&&k>=m/2)
				{
					b[j][k-m/2]=a[j][k];
				}
				else if(j<m/2&&k>=m/2)
				{
					b[j+m/2][k]=a[j][k];
				}
			}
		}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;	
}
