#include<stdbool.h>
#include<memory.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>


int main(void){
	int n=0;
	scanf("%d",&n);
	int num=0;
	int h1=0,h2=0,m1=0,m2=0,s1=0,s2=0;
	int in=84600,out=0,fi=0,fo=0;
	for(int i=0;i<n;i++){
		scanf("%d %d:%d:%d %d:%d:%d",&num,&h1,&m1,&s1,&h2,&m2,&s2);
		int x=h1*3600+m1*60+s1;
		int y=h2*3600+m2*60+s2;
		if(x<in){
			in=x;
			fi=num;
		}else{
			 ;
		}
		if(y>out){
			out=y;
			fo=num;
		}else{
			 ;
		}
	}
	printf("%d %d",fi,fo);
	
	return 0;
}
