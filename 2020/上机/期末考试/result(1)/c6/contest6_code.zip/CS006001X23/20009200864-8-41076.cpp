/*
	3A5cH5o
	3A5c5
�������1
35

��������2
GjoniuJk
�������2
NO

abcde fgh
12345 678
*/
#include<stdio.h>
int main()
{
	char a[51]={0};
	gets(a);
	int i,ans=0;
	for(i=0;a[i]!=0;i++)
	{
		if(a[i]>='0'&&a[i]<='9')
		{
			ans+=a[i]-'0';
		}
		else if(a[i]>='A'&&a[i]<='E')
		{
			ans+=a[i]-'A'+11;
		}
		else if(a[i]>='a'&&a[i]<='e')
		{
			ans+=a[i]-'a'+11;
		}
		else ;
	}
	if(ans==0) printf("NO");
	else 
	{
		printf("%d",ans);
	}
	return 0;
}

