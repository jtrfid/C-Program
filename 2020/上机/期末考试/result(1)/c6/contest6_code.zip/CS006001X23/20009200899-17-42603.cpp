#include <stdio.h>
#include <string.h>
int main()
{
	int n,a[20][20],i,j,b[20][20];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(i<n/2&&j<n/2)
			{
				b[i][j+n/2]=a[i][j];
			}
			else if(i<n/2&&j>=n/2)
			{
				b[i+n/2][j]=a[i][j];
			}
			else if(i>=n/2&&j<n/2)
			{
				b[i-n/2][j]=a[i][j];
			}
			else
			{
				b[i][j-n/2]=a[i][j];
			}
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
}
