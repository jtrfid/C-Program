#include<bits/stdc++.h>
using namespace std;
int main(void)
{ int i,n,flag=0;
 char a[51];
 gets(a);
 n=strlen(a);
 for(i=0;i<n;i++)
 {if(a[i]>='0'&&a[i]<='9')
  flag=1;
 }
 if(flag==0)
 cout<<"NO";
 return 0;
}
