#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int m,n,t,i,a=0,b=0,c=0,min;
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		t=m;
		m=n;
		n=t;
	}
	for(i=m;i<=n;i++)
	{
		if(i%3==0)
		{
			a++;
		}
	}
	for(i=m;i<=n;i++)
	{
		if(i%4==0)
		{
			b++;
		}
	}
	for(i=m;i<=n;i++)
	{
		if((i%5==0)&&(i%2!=0))
		{
			c++;
		}
	}
	min=a;
	if(a>b)
	{
		min=b;
	}
	if(min>c)
	{
		min=c;
	}
	
	printf("%d %d %d\n",a,b,c);
	printf("%d",min);
	return 0;
	
	
} 
