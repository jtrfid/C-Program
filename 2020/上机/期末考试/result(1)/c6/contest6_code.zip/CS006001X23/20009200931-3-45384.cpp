#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	char c[50]={0};
	int sum=0,i;
	for(i=0;i<50;i++)
	{
		scanf("%c",&c[i]);
		if(c[i]!='\n')
		{
			if (c[i]>='0'&&c[i]<='9')
			{
				sum=sum+c[i]-48;
			}
			else if(c[i]>='A'&&c[i]<='F')
			{
				sum=sum+c[i]-55;
			}
			else if(c[i]>='a'&&c[i]<='f')
			{
				sum=sum+c[i]-87;
			}
			else sum=sum;
		}
		else break;
		
	}
	if(sum!=0)
	{
		printf("%d",sum);
	}
	else printf("no");
	return 0;
}
