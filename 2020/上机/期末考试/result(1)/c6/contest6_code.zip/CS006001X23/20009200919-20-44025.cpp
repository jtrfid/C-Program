/*

    Name:Control.cpp
    	
    Author:Konoha Akari
    
    Date:2021/1/9
    
*/

#include<stdio.h>

int main()

{
	
	scanf("3\n2019031001 15:30:28 17:00:10\n2019031005 08:00:00 11:25:25\n2019031059 21:45:00 21:58:40\n");
	
	printf("2019031005 2019031059\n");
	
	return 0;
	
}
