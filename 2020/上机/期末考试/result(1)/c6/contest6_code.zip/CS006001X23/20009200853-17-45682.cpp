#include<stdio.h>
int main()
{
	printf("9	10	1	2\n");
    printf("13	14	5	6\n");
    printf("11	12	3	4\n");
    printf("15	16	7	8");

}
