#include<stdio.h>

int main()
{
	int a, b, t, count1 = 0, count2 = 0, count3 = 0, i;
	
	scanf("%d%d",&a, &b);
	
	if(a > b)
	{
		t = a;
		a = b;
		b = t;
	}
	
	for(i = a; i <= b; i++)
	{
		if(i % 3 == 0)
			count1 ++;
		if(i % 4 == 0)
			count2 ++;
		if(i % 5 == 0 && i % 2 != 0)
			count3 ++;
	}
	
	printf("%d %d %d\n", count1, count2,count3);
	
	t = count1 < count2 ? count1 : count2;	
	t = t < count3 ? t : count3;
	
	printf("%d", t);
	
	return 0;
}
