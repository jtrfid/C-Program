#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<cctype>
using namespace std;
char s[10001];
int main()
{
	cin>>s;
	int sum=0;
	bool pd=false;
	for(int i=0;i<strlen(s);i++)
	{
		if(isdigit(s[i]))
		{
			sum+=s[i]-'0';
			pd=true;
		}
		else if('a'<=s[i]&&s[i]<='f')
		{
			sum+=s[i]-'a'+10;
			pd=true;
		}
		else if('A'<=s[i]&&s[i]<='F')
		{
			sum+=s[i]-'A'+10;
			pd=true;
		}
	}
	if(pd)
	cout<<sum;
	else printf("NO");
}

