#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int a,b,i,x=0,y=0,z=0;
	scanf("%d %d",&a,&b);
	if(a>b) {i=a;a=b;b=i;}
	for(i=b;i>=a;i--)
	{
		if(i%3==0) x++;
		if(i%4==0) y++;
		if(i%5==0&&i%2!=0) z++;
	}
	printf("%d %d %d\n",x,y,z);
	if(x<y)
	{
		if(z<x) printf("%d",z);
		else printf("%d",x);
	}
	else
	{
		if(z<y) printf("%d",z);
		else printf("%d",y);
	}
	
	
	system("pause");
	return 0;
}
