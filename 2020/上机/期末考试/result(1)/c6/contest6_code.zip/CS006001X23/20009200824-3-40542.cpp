#include<stdio.h>


int main()
{
	int a,b,max,min,i,n,c=0,d=0,e=0;
	n=1000000;
	scanf("%d %d",&a,&b);
	
	if(a>b)
	{
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}

    for(i=max;i>=min;i--)
    {
    	if(i%3==0 )
    	{
    	c++;
    	}
    	if(i%4==0)
    	{
    	d++;
    	}
    	if(i%5==0&&i%2!=0)
    	{
    	e++;
    	}
    }
    
    if(c>d)
    {
    	n=d;
    	if(n>e)
    	{
    		n=e;
    	}

    }
    else
    {
    	n=c;
    	if(n>e)
    	{
    		n=e;
    	}
    }
    
    
    
    
    printf("%d %d %d\n%d",c,d,e,n);
    
    return 0;



	
}
