/*
	3A5cH5o
	3A5c5
�������1
35

��������2
GjoniuJk
�������2
NO

abcdef gh
012345 678
*/
#include<stdio.h>
int main()
{
	char a[51]={0};
	gets(a);
	int i,ans=0;
	int flag=0;
	for(i=0;a[i]!=0;i++)
	{
		if(a[i]>='0'&&a[i]<='9')
		{
			ans+=a[i]-'0';
			flag++;
		}
		else if(a[i]>='A'&&a[i]<='E')
		{
			ans+=a[i]-'A'+10;
			flag++;
		}
		else if(a[i]>='a'&&a[i]<='e')
		{
			ans+=a[i]-'a'+10;
			flag++;
		}
		else ;
	}
	if(flag==0) printf("NO");
	else 
	{
		printf("%d",ans);
	}
	return 0;
}

