#include<stdio.h>
int main(){
	char s[60]={0};
	gets(s);
	int i,a=0,b=0,c=0,sum=0,flag=0;
	for(i=0;s[i]!=0;i++){
		if(s[i]>='0'&&s[i]<='9'){
			a=(int)s[i]-48;
			sum+=a;
			flag=1;
		}
		if(s[i]>='A'&&s[i]<='G'){
			b=(int)s[i]-55;
			sum+=b;
			flag=1;
		}
		if(s[i]>='a'&&s[i]<='g'){
			c=(int)s[i]-87;
			sum+=c;
			flag=1;
		}
}
	
	if(sum!=0)
	printf("%d%",sum);
	if(sum==0) printf("0");
	if(sum==0&&flag==0)
	printf("NO");
	
	
	
	return 0;
}
