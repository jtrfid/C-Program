#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int m;
int a[1001][1001];
int main()
{
	cin>>m;
		for(int i=1;i<=m;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cin>>a[i][j];
			}
		}
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(i<=m/2&&j<=m/2)
			cout<<a[i+m/2][j]<<' ';
			if(i>m/2&&j<=m/2)
			cout<<a[i][j+m/2]<<' ';
			if(i<=m/2&&j>m/2)
			cout<<a[i][j-m/2]<<' ';
			if(i>m/2&&j>m/2)
			cout<<a[i-m/2][j]<<' ';
		}
		cout<<endl;
	}
	return 0;
}

