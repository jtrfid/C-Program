#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int i,j;
	int m;
	int a[10][10]={{0}},b[10][10]={{0}};
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			b[i][j+(m/2)]=a[i][j];
		}
	}
	for(i=m/2;i<m;i++)
	{
		for(j=0;j<m/2;j++)
		{
			b[i-m/2][j]=a[i][j];
		}
	}
	for(i=0;i<m/2;i++)
	{
		for(j=m/2;j<m;j++)
		{
			b[i+m/2][j]=a[i][j];
		}
	}
	for(i=m/2;i<m;i++)
	{
		for(j=m/2;j<m;j++)
		{
			b[i][j-m/2]=a[i][j];
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
}
