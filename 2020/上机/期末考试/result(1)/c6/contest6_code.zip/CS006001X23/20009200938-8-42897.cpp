#include<stdio.h>
#include<string.h>
int main()
{
	char str[100];
	int n,i,l,s=0;
	gets(str);
	l=strlen(str);
	for(i=0;i<l;i++)
	{
		if(str[i]>='0'&&str[i]<='9')
		s+=str[i]-'0';
		else if(str[i]>='a'&&str[i]<='g')
		s+=str[i]-87;
		else if(str[i]>='A'&&str[i]<='G')
		s+=str[i]-55;
	}
	if(s)
	printf("%d",s);
	else
	printf("NO");
	return 0;
}
