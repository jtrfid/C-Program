#include<stdio.h>
#include<string.h>

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	int min = a < b ? a : b;
	int max = a > b ? a : b;
	
	int c[3] = {0};
	for(int i = min; i <= max; i++)
	{
		if(i % 3 == 0) c[0]++;
		if(i % 4 == 0) c[1]++;
		if(i % 5 == 0 && i % 2 != 0) c[2]++;
	}
	
	int ans = 999999;
	for(int i = 0; i < 3; i++)
	{
		if(c[i] < ans) ans = c[i];
	}
	
	for(int i = 0; i < 3; i++)
	{
		printf("%d ", c[i]);
	}
	printf("\n%d", ans);
	
	return 0;
}
