#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int a,b;
	int temp=0;
	int x=0,y=0,z=0;
	int max=0,min=0;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}
	int i,j;
	for(i=min;i<=max;i++)
	{
		if(i%3==0)
		{
			x++;
		}
		if(i%4==0)
		{
			y++;
		}
		if(i%5==0&&i%2!=0)
		{
			z++;
		}
	}
	
	int t[3]={x,y,z};
	for(i=0;i<3;i++)
	{
		for(j=0;j<3-i-1;j++)
		{
			if(t[j]>t[j+1])
			{
				temp=t[j+1];
				t[j+1]=t[j];
				t[j]=temp;
			}
		}
	}
	printf("%d %d %d\n%d",x,y,z,t[0]);
	return 0;
	
}
