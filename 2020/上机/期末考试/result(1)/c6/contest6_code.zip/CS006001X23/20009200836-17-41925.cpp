#include<stdio.h>
#include<string.h>
int main()
{
	int m=0,row=0,line=0,a[10][10]={{0}},b[10][10]={{0}};
	scanf("%d",&m);
	for(row=0;row<m;row++)
	{
		for(line=0;line<m;line++)
		{
			scanf("%d",&a[row][line]);
		}
	}
	
	for(row=0;row<m;row++)
	{
		for(line=0;line<m;line++)
		{
			if(row<=m/2-1 && line<=m/2-1)
			{
				b[row][line+m/2]=a[row][line];
			}
			else if(row<=m/2-1 && line>m/2-1)
			{
				b[row+m/2][line]=a[row][line];
			}
			else if(row>m/2-1 && line>m/2-1)
			{
				b[row][line-m/2]=a[row][line];
			}
			else if(row>m/2-1 && line<=m/2-1)
			{
				b[row-m/2][line]=a[row][line];
			}
		}
	}
	
	for(row=0;row<m;row++)
	{
		for(line=0;line<m;line++)
		{
			printf("%d ",b[row][line]);
		}
		printf("\n");
	}
	return 0;
}
