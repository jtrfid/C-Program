#include<stdio.h>
#include<string.h>
int main()
{
	long int a[100], b[100], tar = 0;
	int n, i, mid;
	char s[100][30], t[30] = " 99", *p, *temp;
	
	scanf("%d",&n);
	
	for(i = 0; i < n; i ++)
	{
		scanf("%d",&a[i]);
		gets(s[i]);
		b[i] = a[i];
	}
	
	for(i = 0; i < n; i ++)	
		if(strcmp(s[i],t) < 0)
		{
			mid = tar;
			tar = a[i];
			a[i] = mid;
			
			strcpy(t,s[i]);
		}	
	printf("%ld ", tar);
	
	for(i = 0; i < n; i ++)	
	{
		 p = s[i] + 20;
		 temp = t + 20;
		 
		 L:
		if(*p > *temp)
		{
			mid = tar;
			tar = b[i];
			b[i] = mid;
			
			strcpy(t,s[i]);
		}
		if(*p == *temp)
		{
			p ++;
			temp ++;
			goto L;
		}		
	}	
	printf("%ld ", tar);



	return 0;
}














