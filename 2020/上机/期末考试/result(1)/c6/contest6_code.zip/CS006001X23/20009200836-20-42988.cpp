#include<stdio.h>
#include<string.h>
int main()
{
	char str[100][100]={0};
	int a[100]={0},b[100]={0};
	int n=0,i=0,j=0;
	scanf("%d\n",&n);
	for(i=0;i<n;i++)
	{
		gets(str[i]);
	}
	
	int min=0,max=0,c1=0,c2=0;
	for(i=0;i<n;i++)
	{
		for(j=11;j<=18;j++)
		{
			if(str[i][j]>='0' && str[i][j]<='9')
				a[i]=a[i]*10+str[i][j]-'0';
		}
	}
	min=a[0];
	for(i=1;i<n;i++)
	{
		if(min>a[i])
		{
			min=a[i];
			c1=i;
		}
	}
	
	
	for(i=0;i<n;i++)
	{
		for(j=20;j<=27;j++)
		{
			if(str[i][j]>='0' && str[i][j]<='9')
				b[i]=a[i]*10+str[i][j]-'0';
		}
	}
	max=a[0];
	for(i=0;i<n;i++)
	{
		if(max<b[i])
		{
			max=b[i];
			c2=i;
		}
	}
	
	for(i=0;i<10;i++)
		printf("%c",str[c1][i]);
	printf(" ");
	for(i=0;i<10;i++)
		printf("%c",str[c2][i]);
	return 0;
}
