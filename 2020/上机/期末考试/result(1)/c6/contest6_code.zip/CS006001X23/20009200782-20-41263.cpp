#include<cstdio>
#include<algorithm>
#define ctn(x) (x-'0')
using namespace std;
struct student{
	int id;
	int ha,ma,sa;
	int hb,mb,sb;
}st[200];
int cmp1(student a,student b){
	return (a.ha<b.ha)||(a.ha==b.ha&&a.ma<b.ma)||(a.ha==b.ha&&a.ma==b.ma&&a.sa<b.sa);
}
int cmp2(student a,student b){
	return (a.hb>b.hb)||(a.hb==b.hb&&a.mb>b.mb)||(a.hb==b.hb&&a.mb==b.mb&&a.sb>b.sb);
}
int main(){
	int n;
	scanf("%d",&n);
	int i;
	char sa[20],sb[20];
	for(i=0;i<n;i++){
		scanf("%d %s %s",&st[i].id,sa,sb);
		st[i].ha=ctn(sa[0])*10+ctn(sa[1]);
		st[i].ma=ctn(sa[3])*10+ctn(sa[4]);
		st[i].sa=ctn(sa[6])*10+ctn(sa[7]);
		st[i].hb=ctn(sb[0])*10+ctn(sb[1]);
		st[i].mb=ctn(sb[3])*10+ctn(sa[4]);
		st[i].sb=ctn(sb[6])*10+ctn(sa[7]);
	}
	sort(st,st+n,cmp1);
	printf("%d ",st[0].id);
	sort(st,st+n,cmp2);
	printf("%d",st[0].id);
	return 0;
}
