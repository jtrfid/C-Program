#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
int main()
{
	char id[100][11]={0};
	char a[100][11]={0};
	char l[100][11]={0};
	
	int i=0,j=0,min=0,max=0,n=0;
	scanf("%d",&n);
	for (i=0;i<n;i++)
	{
		gets(id[i]);
		gets(a[i]);
		gets(l[i]);
	}
	
	int temp=0;
	
	for(i=0;i<n;i++)
	{
		temp=strcmp(a[min],a[i]);
		if(temp>0)
		{
			min=i;
		}
	}
	for(i=0;i<n;i++)
	{
		temp=strcmp(a[max],a[i]);
		if(temp<0)
		{
			max=i;
		}
	}
	for (i=0;i<10;i++)
	{
		printf("%c",id[min][i]);
	}
	printf(" ");
	for (i=0;i<10;i++)
	{
		printf("%c",id[max][i]);
	} 
	return 0;
}
