#include<stdio.h>
#include<string.h>
int main(){
	int a=0,b=0;
	scanf("%d %d",&a,&b);
	int t=0;
	if(a>b){
		t=a;
		a=b;
		b=t;
	}
	int i=0;
	int num[3]={0};
	for(i=a;i<=b;i++){
		if(i%3==0){
			num[0]++;
		}
		if(i%4==0){
			num[1]++;
		}if(i%5==0&&i%2!=0){
			num[2]++;
		}
	}
	for(i=0;i<3;i++){
		printf("%d ",num[i]);
	}
	printf("\n");
	if(num[0]<num[1]&&num[0]<num[2]){
		printf("%d",num[0]);
	}if(num[1]<num[0]&&num[1]<num[2]){
		printf("%d",num[1]);
	}
	if(num[2]<num[1]&&num[2]<num[0]){
		printf("%d",num[2]);
	}
	return 0;
}
