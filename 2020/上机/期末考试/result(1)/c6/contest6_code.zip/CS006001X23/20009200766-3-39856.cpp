#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int a,b;
int main()
{
	cin>>a>>b;
	int l=min(a,b),r=max(a,b);
	int ans3=0,ans4=0,ans5=0;
	for(int i=r;i>=l;i--)
	{
		if(i%3==0)ans3++;
		if(i%4==0)ans4++;
		if(i%5==0&&i%2!=0)ans5++;
	}
	cout<<ans3<<" "<<ans4<<" "<<ans5<<endl;
	cout<<min(ans3,min(ans3,ans5));
}

