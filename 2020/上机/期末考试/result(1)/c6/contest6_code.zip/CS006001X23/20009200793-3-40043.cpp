#include<bits/stdc++.h>
using namespace std;
int main(void)
{int i,j,a,b,temp,an[3]={0};
 cin>>a>>b;
 if(b<a)
 {temp=a;
  a=b;
  b=temp;
 }
 for(i=a;i<=b;i++)
 { if(i%3==0)
 an[0]++;
   if(i%4==0)
   an[1]++;
   if(i%5==0&&i%2!=0)
   an[2]++;
 }
 for(i=0;i<3;i++)
 cout<<an[i]<<" ";
 for(i=0;i<3;i++)
{for(j=0;j<3-i-1;j++)
{ if(an[j]>an[j+1])
{temp=an[j+1]; 
an[j+1]=an[j];
 an[j]=temp;
 }
}
}
cout<<endl;
cout<<an[0];
return 0;
}
