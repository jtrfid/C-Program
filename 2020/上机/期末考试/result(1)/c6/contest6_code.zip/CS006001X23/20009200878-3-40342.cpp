#include<stdio.h>
int main(){
	int a,b;
	scanf("%d %d",&a,&b);
	int i,count1=0,count2=0,count3=0;
	if(a<b){
	
	for(i=a;i<b+1;i++){
		if(i%3==0){
			count1++;
		}
		if(i%4==0) count2++;
		if(i%5==0&&i%2!=0) count3++;
	}
//	printf("%d %d %d",count1,count2,count3);
	int min=count1;
	if(count2<min) min=count2;
	if(count3<min) min=count3;
	printf("%d %d %d\n%d",count1,count2,count3,min);
}
	else
	{
			for(i=b;i<a+1;i++){
		if(i%3==0){
			count1++;
		}
		if(i%4==0) count2++;
		if(i%5==0&&i%2!=0) count3++;
	}
//	printf("%d %d %d",count1,count2,count3);
	int min1=count1;
	if(count2<min1) min1=count2;
	if(count3<min1) min1=count3;
	printf("%d %d %d\n%d",count1,count2,count3,min1);
	}
//	printf("%d %d %d\n%d",count1,count2,count3,min1);
	
	
	return 0;
}
