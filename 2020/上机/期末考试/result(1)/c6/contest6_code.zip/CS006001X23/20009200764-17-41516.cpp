#include<stdio.h>
#include<string.h>
int main (){
	int m;
	scanf("%d",&m);
	int a[m][m],i,j,k,x;
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&x);
			a[i][j]=x;
		}
	}
	int b[m][m];
	for(i=0;i<m/2;i++){
		for(j=0;j<m/2;j++){
			b[i][j+m/2]=a[i][j];
			b[i+m/2][j+m/2]=a[i][j+m/2];
			b[i][j]=a[i+m/2][j];
			b[i+m/2][j]=a[i+m/2][j+m/2];
		}
	}
	for(i=0;i<m;i++){
	for(j=0;j<m;j++){
		printf("%d ",b[i][j]);
	}
	printf("\n");	
	}
	return 0;
}
