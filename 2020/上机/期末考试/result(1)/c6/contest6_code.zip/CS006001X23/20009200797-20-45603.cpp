#include<stdio.h>
int main()
{
	int n;
	int i,j;
	scanf("%d", &n);
	char hao[10][45]={0};
	char kai[9][45]={0};
	char guan[9][45]={0};
	for ( i=0; i<n; i++ ){
		scanf("%s %s %s", hao[i], kai[i], guan[i]);
	}
	
	int shi=0,fen=0,miao=0;
	int x[45]={0},y[45]={0};
	for ( i=0; i<n; i++ ){
		shi=(kai[i][0]-'0')*10+kai[i][1]-'0';
		fen=(kai[i][4]-'0')*10+kai[i][5]-'0';
		miao=(kai[i][7]-'0')*10+kai[i][8]-'0';
		x[i]=shi*3600+fen*60+miao;
	}
	for ( j=0; j<n; j++ ){
		shi=(kai[j][0]-'0')*10+kai[j][1]-'0';
		fen=(kai[j][4]-'0')*10+kai[j][5]-'0';
		miao=(kai[j][7]-'0')*10+kai[j][8]-'0';
		y[j]=shi*3600+fen*60+miao;
	}
	int min=0,max=0;
	for ( i=0; i<n; i++ ){
		if( x[min]>x[i] )
		min=i;
		if( y[max]<y[j] )
		max=j;
	}
	printf("%s %s", hao[min], hao[max]);
	
	
	
	
	return 0;
}
