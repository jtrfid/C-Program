#include<stdio.h>
#include<string.h>

int main(){
	char s[100]={0};
	gets(s);
	int i,a,b,l=strlen(s),ans=0;
	for(i=0;i<l;i++){
		if(s[i]>='a'&&s[i]<='f') ans=ans+s[i]-87;
		if(s[i]>='A'&&s[i]<='F') ans=ans+s[i]-55;
		if(s[i]>=0&&s[i]<='9') ans=ans+s[i]-48;
//		printf("%d\n",ans);
	}
	if(ans>0){
		printf("%d",ans);
	}else printf("No");
//	printf("%d",s[0]);
	
	return 0;
}
