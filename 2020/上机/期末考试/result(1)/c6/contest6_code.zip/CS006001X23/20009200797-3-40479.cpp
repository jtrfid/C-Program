#include<stdio.h>
#include<string.h>
int main()
{
	int x,y;
	int a=0,b=0,c=0;
	int i,j;
	int t=0;
	scanf("%d %d", &x, &y);
	
	if ( x>y ){
		t=y;
		y=x;
		x=t;
	}
	
	for ( i=x; i<=y; i++ ){
		if ( i%3==0 ){
			a++;
		}
		if ( i%4==0 ){
			b++;
		}
		if ( i%5==0&&i%2!=0 ){
			c++;
		}
	}
	
	int min;
	if ( a<=b&&a<=c ){
		min=a;
	}
	if ( b<=a&&b<=c ){
		min=b;
	}
	if ( c<=a&&c<=b ){
		min=c;
	}
	printf("%d %d %d\n%d" ,a, b, c, min);
	
	
	
	
	
	return 0;
}
