#include<stdio.h>
#include<string.h>
#include<stdlib.h>
		int main(){
		int i,j,temp;
		int min,max;
		for(i=0;i<8;i++)
		{
			
		}
		long int a=2019031005,b=2019031059;
		
	
printf("%ld %ld",a,b);
return 0;
}
