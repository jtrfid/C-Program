/*
*/
#include<stdio.h>

int main()
{
	int a,b,t;
	int m=0,n=0,q=0;
	int ans=0;
	int i,j;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	
	for(i=a;i<=b;i++)
	{
		if(i%3==0) m++;
		if(i%4==0) n++;
		if(i%5==0&&i%2!=0) q++;
	}
	
	if(m>n)
	{
		if(n>q) ans=q;
		else ans=n;
	}
	else 
	{
		if(m>q) ans=q;
		else ans=m;
	}
	
	printf("%d %d %d\n",m,n,q);
	printf("%d",ans);
	
	return 0;
}
