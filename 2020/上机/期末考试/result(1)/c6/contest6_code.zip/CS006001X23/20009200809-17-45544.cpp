#include<stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int num[n][n],temp[n][n];
	
	for (int i=0;i<n;i++)
	{
		for (int j=0;j<n;j++){
			scanf("%d", &num[i][j]);
			temp[i][j]=num[i][j];	}
	}
	for (int i=0;i<n;i++)
	{
		for (int j=0;j<n;j++)
		{
			if(i>=0 &&i<(n/2) && j>=0&&j<(n/2))
			{
				num[i][j]=temp[i+(n/2)][j];
			}
			else if(i>=0 &&i<(n/2) && j>=(n/2)&&j<n)
			{
				num[i][j]=temp[i][j-(n/2)];
			}
			else if(i>=(n/2) &&i<n && j>=(n/2)&&j<n)
			{
				num[i][j]=temp[i-(n/2)][j];
			}
			else if (i>=(n/2)&&i<n&&j>=0&&j<(n/2))
			{
				num[i][j]=temp[i+1][j-(n/2)];
			}
		}
	}
	for (int i=0;i<n;i++)
	{
		for (int j=0;j<n;j++){
			printf("%4.d ", num[i][j]);
		}
		printf("\n");
	}
}
