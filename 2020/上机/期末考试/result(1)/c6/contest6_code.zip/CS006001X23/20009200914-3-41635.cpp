#include<stdio.h>
int main()
{
	int a,b,c,d,i,j,k,f,e;
	scanf("%d%d",&a,&b);
	int x[1000];
	int n=a,m=b;
	int y[1000];
	j=0;
	k=0;
	f=0;
	e=0;
	if(a>b)
	{
		n=b;
		m=a;
	}
	int t=n;
	for(i=0;i<m-n+1;i++)
	{
		x[i]=t;
		t=t+1;
	}
	for(i=0;i<m-n+1;i++)
	{
		if(x[i]%3==0)
		{
			j++;
			y[e]=x[i];
			e++;
		}
		if(x[i]%4==0)
		{
			k++;
			y[e]=x[i];
			e++;
		}
		if(x[i]%5==0&&x[i]%2!=0)
		{
			f++;
			y[e]=x[i];
			e++;
		}
		
	}
	printf("%d %d %d\n",j,k,f);
	int min=j;
	if(min>f)
	{
		min=f;
	}
	if(min>k)
	{
		min=k;
	}
	printf("%d",min);
	return 0;
}
