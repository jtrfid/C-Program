#include<stdio.h>

int main(){
	int m,n,i,j,t,a,b,a3,a4,a5;
	scanf("%d %d",&a,&b);
	if(a>b){
		t=a;
		a=b;
		b=t;
	}
	a3=a4=a5=0;
	for(m=a;m <=b;m++){
		if(m%3==0) a3++;
		if(m%4==0) a4++;
		if(m%5==0&&m%2!=0) a5++;
	}
	if(a4<=a3&&a4<=a5){
		i=a4;
	}
	if(a3<=a4&&a3<=a5){
		i=a3;
	}
	if(a5<=a3&&a5<=a4){
		i=a5;
	}
	
	printf("%d %d %d",a3,a4,a5);
	printf("\n%d",i);
	
	return 0;
}
