#include<stdio.h>
#include<string.h>
int main()
{
	int m,n,i,j,k,a=0,b=0,c=0;
	
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		i=n;
		n=m;
		m=i;
	}
	for(i=m,j=0;i<=n;i++)
	{
		if(i%3==0)
		{
			a++;
		}
		if(i%4==0)
		{
			b++;
		}
		if(i%5==0&&i%2!=0)
		{
			c++;
		}
	}
	printf("%d %d %d\n",a,b,c);
	if(a>b)
	{
		i=b;
		b=a;
		a=i;
	}
	if(a>c)
	{
		i=c;
		c=a;
		a=i;
	}
	printf("%d",a);
	
	
	
	
	return 0;
}
