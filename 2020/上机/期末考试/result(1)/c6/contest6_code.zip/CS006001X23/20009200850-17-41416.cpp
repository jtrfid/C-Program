#include<stdio.h>
int  main ()
{int m;
scanf("%d",&m);
int a[m][m];
 for(int i=0;i<m;i++)
{for(int j=0;j<m;j++)
{scanf("%d ",&a[i][j]);
}
}
for(int z=0;z<m/2;z++)
{for(int i=0;i<m/2;i++)
{printf("%d ",a[z+m/2][i]);
}
for(int i=0;i<m/2;i++)
{printf("%d ",a[z][i]);
}
printf("\n");


}
for(int z=0;z<m/2;z++)
{for(int i=0;i<m/2;i++)
{printf("%d ",a[z+m/2][i+m/2]);
}
for(int i=0;i<m/2;i++)
{printf("%d ",a[z][i+m/2]);
}
printf("\n");


}
}
