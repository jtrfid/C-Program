#include<stdio.h>
#include<string.h>
int main()
{
	int n,i,j;
	scanf("%d",&n);
	char a[n][3];
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
		scanf("%s",&a[i][j]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
			printf("%s %s",a[0][0],a[n][0]);
	}
	
}
