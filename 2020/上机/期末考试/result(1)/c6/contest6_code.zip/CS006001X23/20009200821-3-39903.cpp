#include<stdio.h>
int main()
{
	int a,b;
	int max,min;
	int cnt1 = 0;
	int cnt2 = 0;
	int cnt3 = 0;
	
	scanf("%d %d",&a,&b);
	
	max = a>b ? a:b;
	min = a<b ? a:b;
	
	for(int i = min; i <= max; i++)
	{
		if(i % 3 == 0)
		cnt1++;
		if(i % 4 == 0)
		cnt2++;
		if(i % 5 == 0 && i % 2 != 0)
		cnt3++;
	}
	
	int min1 = cnt1 < cnt2 ? cnt1 : cnt2;
	int min2 = min1 < cnt3 ? min1 : cnt3;
	
	printf("%d %d %d\n%d",cnt1,cnt2,cnt3,min2);
	
	return 0;
}
