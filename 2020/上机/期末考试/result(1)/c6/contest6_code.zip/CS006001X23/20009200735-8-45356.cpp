#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int i,j,sum,num;
	int a[100];
	char s[50];
	sum=-1;
	num=0;
	gets(s);
	int n=strlen(s);
	for(i=0;i<n;i++){
		if(s[i]=='0'){
				a[num]=0;
				num++;
				sum=0;
				
			}
		else if(s[i]=='1'){
				a[num]=1;
				num++;
				sum=0;
			}
		else if(s[i]=='2'){
				a[num]=2;
				num++;
				sum=0;
			}
		else if(s[i]=='3'){
				a[num]=3;
				num++;
				sum=0;
			}
		else if(s[i]=='4'){
				a[num]=4;
				num++;
				sum=0;
			}
		else if(s[i]=='5'){
				a[num]=5;
				num++;
				sum=0;
			}
		else if(s[i]=='6'){
				a[num]=6;
				num++;
				sum=0;
			}
		else if(s[i]=='7'){
				a[num]=7;
				num++;
				sum=0;
			}
		else if(s[i]=='8'){
				a[num]=8;
				num++;
				sum=0;
			}
		else if(s[i]=='9'){
				a[num]=9;
				num++;
				sum=0;
			}
		else if(s[i]=='a'||s[i]=='A'){
				a[num]=10;
				num++;
				sum=0;
			}
		else if(s[i]=='b'||s[i]=='B'){
				a[num]=11;
				num++;
				sum=0;
				
			}
		else if(s[i]=='c'||s[i]=='C'){
				a[num]=12;
				num++;
				sum=0;
			}
		else if(s[i]=='d'||s[i]=='D'){
				a[num]=13;
				num++;
				sum=0;
			}
		else if(s[i]=='e'||s[i]=='E'){
				a[num]=14;
				num++;
				sum=0;
			}
		else if(s[i]=='f'||s[i]=='F'){
				a[num]=15;
				num++;
				sum=0;
			}
	}
	for(int i=0;i<num;i++){
		sum=sum+a[i];
	}
	if(sum==-1){
		printf("NO");
	}
	else{
		printf("%d",sum);
	}
	return 0;
}
