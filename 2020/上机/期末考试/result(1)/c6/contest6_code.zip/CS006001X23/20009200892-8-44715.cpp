#include<stdio.h>
#include<string.h>
int main(){
	char s[50]={'0'};
	int len,sum=0,i,a=0;
	gets(s);
	len=strlen(s);
	for(i=0;i<len;i++){
		if(s[i]>='0'&&s[i]<='9'){
		
		sum=sum+s[i]-'0';a=1;}
		if(s[i]>='a'&&s[i]<='f'){
		
		sum=sum+10+s[i]-'a';a=1;}
		if(s[i]>='A'&&s[i]<='F'){
		
		sum=sum+10+s[i]-'A';a=1;}
	}
	if(a==1)printf("%d",sum);
	if(a!=1)printf("NO");
	return 0;
}
