#include<stdio.h>
int main()
{
	int m,i,k;
	int j,t;
	scanf("%d",&m);
	int x[100][100];
	for(i=0;i<m;i++)
	{
		for(k=0;k<m;k++)
		{
			scanf("%d",&x[i][k]);
			
		}
	}
	for(i=0;i<(m/2);i++)
	{
		for(k=0;k<(m/2);k++)
		{
			t=x[i][k];
			x[i][k]=x[i][k+(m/2)];
			x[i][k+(m/2)]=t;
		}
	}
	for(i=0;i<(m/2);i++)
	{
		for(k=0;k<(m/2);k++)
		{
			t=x[i][k];
			x[i][k]=x[i+(m/2)][k+(m/2)];
			x[i+(m/2)][k+(m/2)]=t;
		}
	}
	for(i=0;i<(m/2);i++)
	{
		for(k=0;k<(m/2);k++)
		{
			t=x[i][k];
			x[i][k]=x[i+(m/2)][k];
			x[i+(m/2)][k]=t;
		}
	}
	for(i=0;i<m;i++)
	{
		for(k=0;k<m;k++)
		{
			printf("%d ",x[i][k]);
			
		}
		printf("\n");
	}
}
