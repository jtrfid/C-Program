#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int min=0;
	int max=0; 
	min=a>b?b:a;
	max=a>b?a:b;
	
	int sum[3]={0};
	
	int i=0;
	for(i=min;i<=max;i++)
	{
		if(i%3==0)
		{
			sum[0]++;
		}
		if(i%4==0)
		{
			sum[1]++;
		}
		if(i%5==0&&i%2!=0)
		{
			sum[2]++;
		}
	}
	
	int zuixiao=sum[0];
	for(i=0;i<3;i++)
	{
		if(sum[i]<zuixiao)
		{
			zuixiao=sum[i];
		}
	}
	
	printf("%d %d %d\n",sum[0],sum[1],sum[2]);
	printf("%d",zuixiao);
	
	return 0;
	
	
}


