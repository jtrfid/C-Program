#include<cstdio>
#include<cstring>
int ans,fl;
int main()
{
	char ch[561];
	gets(ch);
	int n=strlen(ch);
	for(int i=0;i<n;i++)
	{
		if(ch[i]>='1'&&ch[i]<='9')
		{
			ans+=ch[i]-'0';
			fl=1;
		}
		if(ch[i]>='a'&&ch[i]<='f')
		{
			ans+=ch[i]-'a'+10;
			fl=1;
		}
		if(ch[i]>='A'&&ch[i]<='F')
		{
			ans+=ch[i]-'A'+10;
			fl=1;
		}
	}
	if(fl==1)
	{
		printf("%d",ans);
	}
	else
	{
		printf("NO");
	}
}
