#include<stdio.h>
int main()
{char c[50];
scanf("%s",c);
int i,M=0;
for(i=0;;i++)
   {if(c[i]=='A'||c[i]=='a') M=M+10;
    else if(c[i]=='B'||c[i]=='b') M=M+11;
    else if(c[i]=='C'||c[i]=='c') M=M+12;
    else if(c[i]=='D'||c[i]=='d') M=M+13;
    else if(c[i]=='E'||c[i]=='e') M=M+14;
    else if(c[i]=='F'||c[i]=='f') M=M+15;
    else if(c[i]=='0') M=M+0;
    else if(c[i]=='1') M=M+1;
    else if(c[i]=='2') M=M+2;
    else if(c[i]=='3') M=M+3;
    else if(c[i]=='4') M=M+4;
    else if(c[i]=='5') M=M+5;
    else if(c[i]=='6') M=M+6;
    else if(c[i]=='7') M=M+7;
    else if(c[i]=='8') M=M+8;
    else if(c[i]=='9') M=M+9;
    else if(c[i]=='\0') break;
   }
if(M==0) printf("NO");
else printf("%d",M);
return 0;
}
