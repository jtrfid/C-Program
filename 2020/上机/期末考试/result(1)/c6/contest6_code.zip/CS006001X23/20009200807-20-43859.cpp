#include<stdio.h>
#include<string.h>

int main()
{
	int n;
	scanf("%d", &n);
	char stu[111][20] = {0};
	char in[111][20] = {0};
	char out[111][20] = {0};
	int open = 0;
	int close = 0;
	
	for(int i = 0; i < n; i++)
	{
		scanf("%s", stu[i]);
		scanf("%s", in[i]);
		scanf("%s", out[i]);
	}
	
	char tar1[20] = {0};
	char tar2[20] = {0};
	strcpy(tar1, in[0]);
	strcpy(tar2, out[0]);
	for(int i = 0; i < n; i++)
	{
		if(strcmp(in[i], tar1) < 0)
		open = i;
		if(strcmp(out[i], tar2) > 0)
		close = i;
	}
	
	printf("%s %s", stu[open], stu[close]);
	
	return 0;
}
