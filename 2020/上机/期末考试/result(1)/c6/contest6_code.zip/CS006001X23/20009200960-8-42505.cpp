#include<stdio.h>
int main()
{char c[50];
scanf("%s",c);
int i,M=0;
for(i=0;;i++)
   {if(c[i]=='A') M=M+10;
    else if(c[i]=='B') M=M+11;
    else if(c[i]=='C') M=M+12;
    else if(c[i]=='D') M=M+13;
    else if(c[i]=='E') M=M+14;
    else if(c[i]=='F') M=M+15;
    else if(c[i]<='9'&&c[i]>='0') M=M+c[i];
    else if(c[i]=='\0') break;
   }
if(M==0) printf("NO");
else printf("%d",M);
return 0;
}
