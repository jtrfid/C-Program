#include<cstdio>
int a,b,mn,x,y,z;
int main()
{
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		int t=a;
		a=b;
		b=t;
	}
	mn=b;
	for(int i=a;i<=b;i++)
	{
		if(i%3==0)
		{
			x++;
		}
		if(i%4==0)
		{
			y++;
		}
		if(i%5==0&&i%2!=0)
		{
			z++;
		}
	}
	if(mn>x)mn=x;
	if(mn>y)mn=y;
	if(mn>z)mn=z;
	printf("%d %d %d\n%d",x,y,z,mn);
}
