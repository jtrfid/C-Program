#include<stdio.h>
typedef struct 
{
	int xh=0;
	int a=0;
	char b;
	int c=0;
	char d;
	int e=0;
	int f=0;
	int g=0;
	int h=0;
	char i;
	int j=0;
	char k;
	int l=0;
	
}Student;
int main()
{
	int i=0,n,j,min,max,x,y;
	Student stu[101];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d %c %d %c %d %d %c %d %c %d",&stu[i].xh,&stu[i].a,&stu[i].b,&stu[i].c,&stu[i].d,&stu[i].e,&stu[i].h,&stu[i].i,&stu[i].j,&stu[i].k,&stu[i].l);
		
	}
	for(i=0;i<n;i++)
	{
		stu[i].f=stu[i].a*60*60+stu[i].c*60+stu[i].e;
		stu[i].g=stu[i].h*60*60+stu[i].j*60+stu[i].l;
	}
	min=stu[0].f;
	max=stu[0].g;
	for(i=0;i<n-1;i++)
	{
		if(max<stu[i].g)
		{
			max=stu[i].g;
			x=i;
		}
		if(min>stu[i].f)
		{
			min=stu[i].f;
			y=i;
		}
	}
	printf("%d %d",stu[y].xh,stu[x].xh);
}

