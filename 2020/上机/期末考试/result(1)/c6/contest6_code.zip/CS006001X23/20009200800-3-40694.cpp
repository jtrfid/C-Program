#include<bits/stdc++.h>
using namespace std;

int main()
{
	int a,b,c=0,d=0,e=0;
	scanf("%d%d",&a,&b);
	if(a>b) swap(a,b);
	int i;
	for(i=a;i<=b;i++)
	{
		if(i%3==0) c++;
		if(i%4==0) d++;
		if(i%5==0&&i%2!=0) e++;
	}
	printf("%d %d %d\n",c,d,e);
	if(c<d&&c<e) printf("%d",c);
	if(d<c&&d<e) printf("%d",d);
	if(e<c&&e<d) printf("%d",e);
	return 0;
}
