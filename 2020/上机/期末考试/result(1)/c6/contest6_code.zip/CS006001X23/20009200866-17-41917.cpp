#include<stdio.h>
int main(){
	int m,n,i,j,k=0,e;
	scanf("%d",&m);
	n=m/2,e=n;
	int s[m][m];
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&s[i][j]);
		}
	}
	for(i=n;i<=n+1;i++){
		for(j=0;j<n;j++){
			printf("%d ",s[i][j]);
		}
		for(j=0;j<n;j++){
			printf("%d ",s[k][j]);
		}printf("\n");
		k=1;
	}k=0;
	for(i=n;i<=n+1;i++){
		for(j=n;j<=n+1;j++){
			printf("%d ",s[i][j]);
		}
		for(j=n;j<=n+1;j++){
			printf("%d ",s[k][j]);
		}printf("\n");
		k=1;
	}
	return 0;
}
