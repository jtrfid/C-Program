#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <stdlib.h>

typedef struct{
	char num[11]={0};
	char start[10]={0};
	char end[10]={0};
}student;

int main(){
	student st[100];
	
	
	int n;
	scanf("%d",&n);
	getchar();
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%s %s %s",st[i].num,st[i].start,st[i].end);
		/*scanf("%s",st[i].start);
		scanf("%s",st[i].end);*/
	}  //��ʼ�� 
	
	int maxi=0;
	int mini=0;
	char min[10]={0};
	char max[10]={0};
	strcpy(min,st[0].start);
	strcpy(max,st[0].end);
	for(i=0;i<n;i++)
	{
		if(strcmp(min,st[i].start)>0)  mini=i; 
		
		if(strcmp(max,st[i].end)<0)  maxi=i;
	}
	
	printf("%s %s",st[mini].num,st[maxi].num);
	/*for(i=0;i<n;i++)
	{
		printf("%s %s %s\n",st[i].num,st[i].start,st[i].end);
	}*/
	
	return 0;
}
