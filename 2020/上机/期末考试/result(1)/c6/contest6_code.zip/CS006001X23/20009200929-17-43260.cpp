#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int m,i,j;
	scanf("%d",&m);
	int a[m][m],b[m][m];
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		} 
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(i<m/2&&j<m/2) b[i][j+m/2]=a[i][j];
			if(i<m/2&&j>=m/2) b[i+m/2][j]=a[i][j];
			if(i>=m/2&&j>=m/2) b[i][j-m/2]=a[i][j];
			if(i>=m/2&&j<m/2) b[i-m/2][j]=a[i][j];
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n"); 
	}
	
	system("pause");
	return 0;
}
