#include<stdio.h>
#include<math.h>
int main(){
	int m,n,i,j;
	m=0;
	n=0;
	scanf("%d",&m);
	n=m/2;
	int a[100][100],b[100][100];
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i][j]=a[i+n][j];
		}
		j++;
		for(j=n;j<m;j++){
			b[i][j]=a[i][j-n];
		}
	}
	i++;
	for(i=n;i<m;i++){
		for(j=0;j<n;j++){
			b[i][j]=a[i][j+n];
		}
		j++;
		for(j=n;j<m;j++){
			b[i][j]=a[i-n][j];
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	for(i=n;i<m;i++){
		for(j=0;j<m;j++){
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}	
	return 0;
}
