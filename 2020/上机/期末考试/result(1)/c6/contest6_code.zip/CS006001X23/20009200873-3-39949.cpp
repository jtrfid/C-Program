#include<bits/stdc++.h>


int main()
{
	int a,b,i,sum3=0,sum4=0,sum5=0,min = 99999;
	
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		int t = a;
		a = b;
		b = t;
	}
	
	for(i = a;i <= b;i++)
	{
		if(i%3 == 0)
		{
			sum3++;
		}
		if(i%4 == 0)
		{
			sum4++;
		}
		if(i%5 == 0 && i%2 !=0)
		{
			sum5++;
		}
	}
	
	min = sum3<sum4?sum3:sum4;
	min = sum5<min?sum5:min;
	
	printf("%d %d %d\n%d",sum3,sum4,sum5,min);
	
	return 0;
}
