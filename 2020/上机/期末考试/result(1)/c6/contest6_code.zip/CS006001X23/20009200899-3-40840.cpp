#include <stdio.h>
int main()
{
	int A,B,min,max,i,count[4],m,mi[4];
	count[1]=0;
	count[2]=0;
	count[3]=0;
	scanf("%d %d",&A,&B);
	min=A>B?B:A;
	max=A>B?A:B;
	mi[1]=max;
	mi[2]=max;
	mi[3]=max;
	for(i=max;i>=min;i--)
	{
		if(i%3==0)
		{
			count[1]++;
			mi[1]=i;
		}
		if(i%4==0)
		{
			count[2]++;
			mi[2]=i;
		}
		if(i%5==0&&i%2!=0)
		{
			count[3]++;
			mi[3]=i;
		}
	}
	for(i=1,m=count[1];i<=3;i++)
	{
		if(count[i]<m)
		{
			m=count[i];
		}
	}
	printf("%d %d %d\n%d",count[1],count[2],count[3],m);
	return 0;
}
