#include<stdio.h>
int main(){
	int A,B,i;
	scanf("%d %d",&A,&B);
	int t,count1,count2,count3;
	if(A>B){
		t=A;
		A=B;
		B=t;
	}
	for(i=A;i<=B;i++){
		if(i%3==0)
			count1++;
		if(i%4==0)
			count2++;
		if(i%5==0&&i%2!=0)
			count3++;
	}
	printf("%d %d %d\n",count1,count2,count3);
	int min=count1;
	if(count2<min)
		min=count2;
	if(count3<min)
		min=count3;
	printf("%d",min);
	return 0;
}
