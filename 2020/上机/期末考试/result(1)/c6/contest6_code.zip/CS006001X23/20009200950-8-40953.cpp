#include<stdio.h>
#include<string.h>
int main()
{
	int sum=0;
	char s[50];
	gets(s);
	int len=strlen(s);
	for(int i=0;i<len;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		sum+=s[i]-48;
		if(s[i]>='a'&&s[i]<='e')
		sum+=s[i]-87;
		if(s[i]>='A'&&s[i]<='E')
		sum+=s[i]-55;
	}
	if(sum==0)
	printf("NO");
	else printf("%d",sum);
	return 0;
}
