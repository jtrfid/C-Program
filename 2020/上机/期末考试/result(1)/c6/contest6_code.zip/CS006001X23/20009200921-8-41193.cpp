#include<stdio.h>
#include<string.h>
int main()
{
	
	char a[50]={};
	gets(a);
	int i,sum=0;
	for(i=0;i<strlen(a);i++)
	{
		if(a[i]=='1')
		sum+=1;
		else if(a[i]=='2')
		sum+=2;
		else if(a[i]=='3')
		sum+=3;
		else if(a[i]=='4')
		sum+=4;
		else if(a[i]=='5')
		sum+=5;
		else if(a[i]=='6')
		sum+=6;
		else if(a[i]=='7')
		sum+=7;
		else if(a[i]=='8')
		sum+=8;
		else if(a[i]=='9')
		sum+=9;
		else if(a[i]=='0')
		sum+=0;
		else if(a[i]=='a'||a[i]=='A')
		sum+=10;
		else if(a[i]=='b'||a[i]=='B')
		sum+=11;
		else if(a[i]=='c'||a[i]=='C')
		sum+=12;
		else if(a[i]=='d'||a[i]=='D')
		sum+=13;
		else if(a[i]=='e'||a[i]=='E')
		sum+=14;
		else if(a[i]=='f'||a[i]=='F')
		sum+=15;
	}
	if(sum==0)
	printf("NO");
	else
	printf("%d",sum);
	return 0;
}
