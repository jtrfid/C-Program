#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<memory.h>
int main()
{
	int m;
	scanf("%d",&m);
	int a[10][10]={0};
	int b[10][10]={0};
	int i=0,j=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			b[i][j]=a[i+(m/2)][j];
		}
		for(j=m/2;j<m;j++)
		{
			b[i][j]=a[i][j-(m/2)];
		}
	
	}
	for(i=m/2;i<m;i++)
	{
		for(j=0;j<m/2;j++)
		{
			b[i][j]=a[i][j+(m/2)];
		}
		for(j=m/2;j<m;j++)
		{
			b[i][j]=a[i-(m/2)][j];
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{   
		  if(j<m-1)
		  {
		  	printf("%d ",b[i][j]);
		  }
		  else
		  {
		  	printf("%d\n",b[i][j]);
		  }
			
	
		}
		
	}
	
	return 0;
}
