#include<stdio.h>
#include<string.h>
int main()
{
	char str[100]={0};
	int flag=0,sum=0,i=0;
	gets(str);
	
	for(i=0;i<strlen(str);i++)
	{
		if(str[i]>='0' && str[i]<='9')
		{
			sum+=str[i]-'0';
			flag=1;
		}
		else if(str[i]>='A' && str[i]<='F')
		{
			sum+=str[i]-'A'+11;
			flag=1;
		}
	}
	if(flag)
		printf("%d",sum);
	else
		printf("NO");
	return 0;
}
