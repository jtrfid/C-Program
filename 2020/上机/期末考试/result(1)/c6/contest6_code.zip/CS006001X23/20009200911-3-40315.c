#include<stdio.h>
#include<math.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int ma,mi;
	ma=a>b?a:b;
	mi=a<b?a:b;
	int i,e=0,f=0,g=0;
	for(i=mi;i<=ma;i++)
	{
		if(i%3==0)
		e++;
		if(i%4==0)
		f++;
		if(i%5==0&&i%2!=0)
		g++;
	}
	int min,mn;
	mn=e<f?e:f;
	min=mn<g?mn:g;
	printf("%d %d %d\n",e,f,g);
	printf("%d",min);
	
	
	
	return 0;
}
