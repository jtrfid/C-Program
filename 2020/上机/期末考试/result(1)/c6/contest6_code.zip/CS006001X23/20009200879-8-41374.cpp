#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
int main()
{
	char s[50]={0};
	gets(s);
	
	int i,j,k,n=0;
	n=strlen(s);
	int a[50]={0};
	j=0;
	for(i=0;i<n;i++)
	{
		if(s[i]>=48&&s[i]<=57)
		{
			a[j]=s[i]-48;
			j++;
		}
		else if(s[i]>=65&&s[i]<=69)
		{
			a[j]=s[i]-55;
			j++;
		}
		else if(s[i]>=97&&s[i]<=101)
		{
			a[j]=s[i]-87;
			j++;	
		}
		else
		{
		
		}
	}
	
	int sum=0;
	
	if(j==0)
	{
		printf("NO");
	}
	else
	{
		for (i=0;i<j;i++)
		{
			sum=sum+a[i];
		}
		printf("%d",sum);
	}
	
	return 0;	
} 
