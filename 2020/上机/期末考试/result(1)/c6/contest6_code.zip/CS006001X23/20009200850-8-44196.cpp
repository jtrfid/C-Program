#include<stdio.h>
#include<string.h>

int  main ()
{char a[51];
scanf("%s",&a);
int sum1=0;
int sum2=0;
int sum3=0;
int sum4=0;
int s=0;
for(int i=0;i<51;i++)
{if(a[i]>='0'&&a[i]<='9')
{sum1=sum1+a[i]-48;
s++;
}
if(a[i]>='a'&&a[i]<='f')
{sum2=sum2+a[i]-87;
s++;
}
if(a[i]>='A'&&a[i]<='F')
{sum3=sum3+a[i]-55;
s++;
}

}
sum4=sum1+sum2+sum3;
if(s==0)
{printf("NO");
}
else
{printf("%d %d %d %d",sum4,sum1,sum2,sum3);
}

}
