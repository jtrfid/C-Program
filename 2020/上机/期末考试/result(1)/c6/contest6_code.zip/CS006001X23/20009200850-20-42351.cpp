#include<stdio.h>
#include<string.h>
int main ()
{int N;
scanf("%d",&N);
char *a[3*N];
for(int i=0;i<N;i++)
{scanf("%s %s %s",&a[3*i],&a[3*i+1],&a[3*i+2]);
}
int m=0;
for(int i=0;i<N;i++)
{m=strcmp(a[3*i+2],a[3*i+4]);
 if(m!=0)
{printf("%s",a[3*i+3]);
}
}
}

