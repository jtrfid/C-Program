#include<stdio.h>
int main()
{
	char str[50];
	scanf("%s",&str);
	int number = 0;
	int flag = 0;
	
	for(int i = 0; str[i] != '\0'; i++)
	{
		//������ͳ��ʱ 
		if(str[i] >= '0' && str[i] <= '9')
		{
			flag = 1;
			number += (str[i] - 48);
		}
		else if(str[i] >= 'a' && str[i] <= 'f')
		{
			number += (str[i] -  97 + 10 );
		}
		else if(str[i] >= 'A' && str[i] <= 'F')
		{
			number += (str[i] -  65 + 10 );
		}
	}

	if(flag == 0)
	{
		printf("NO");
	}
	else
	{
		printf("%d",number);
	}
	
	return 0;
}
