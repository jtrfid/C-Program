#include<stdio.h>
int main()
{
	int a,b,i,j,t,flag=1;
	int count[3]={0};
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a; a=b; b=t;
	}
	for(i=a;i<=b;i++)
	{
		if(i%3==0)	count[0]++;
		if(i%4==0)	count[1]++;
		if(i%5==0 && i%2!=0)	count[2]++;
	}
	int min=count[0];
	for(i=1;i<3;i++)
	{
		if(min>count[i])
		{
			min=count[i];
		}
	}
	for(i=0;i<3;i++)
	{
		printf("%d ",count[i]);
	}
	printf("\n%d",min);
	
	return 0;
}
