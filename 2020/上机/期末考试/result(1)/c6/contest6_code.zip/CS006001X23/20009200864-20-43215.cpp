/*
*/
#include<stdio.h>

typedef struct
{
	char num[11];
	char timeu[9];
	int upn;
	int don;
	char timed[9];
}Re;

int main()
{
	int n;
	Re stu[100]={0};
	scanf("%d",&n);
	
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%s",stu[i].num);
		scanf("%s",stu[i].timeu);
		scanf("%s",stu[i].timed);
		stu[i].upn=(stu[i].timeu[0]*10+stu[i].timeu[1])*60+stu[i].timeu[3]*10+stu[i].timeu[4]+(stu[i].timeu[6]*10+stu[i].timeu[7])*1.0/60;
		stu[i].don=(stu[i].timed[0]*10+stu[i].timed[1])*60+stu[i].timed[3]*10+stu[i].timed[4]+(stu[i].timed[6]*10+stu[i].timed[7])*1.0/60;
	}
	
	int m=0,M=0;
	for(i=0;i<n;i++)
	{
		if(stu[i].upn<stu[m].upn)
		{
			m=i;
		}
	}
	for(i=0;i<n;i++)
	{
		if(stu[i].don>stu[M].don)
		{
			M=i;
		}
	}
	
	printf("%s %s",stu[m].num,stu[M].num);
	
	return 0;
}
