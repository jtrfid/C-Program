#include<stdio.h>

int main()
{
	float a, b;
	scanf("%f %f", &a, &b);
	int min=0, max=0, sum[3]={0};
	if (a>b)
	{
		min=b;
		max=a;
	}
	else if(a<b)
	{
		min=a;
		max=b;
	}
	for (int i=min;i<=max;i++)
	{
		if (i%3==0)
		{
			sum[0]++;
		}}
	
	for (int i=min;i<=max;i++){
		
		 if (i%4==0)
		{
			sum[1]++;
		}}
	for (int i=min;i<=max;i++){
	 if(i%5==0 &&i%2!=0)
		{
			sum[2]++;
		}
	}
	int temp=10000;
	for (int i=0;i<3;i++)
	{
		if (sum[i]<temp)
		{
			temp=sum[i];
		}
	}
	for (int i=0;i<3;i++)
	{
		printf("%d ", sum[i]);
	}
	printf("\n%d", temp);
}
