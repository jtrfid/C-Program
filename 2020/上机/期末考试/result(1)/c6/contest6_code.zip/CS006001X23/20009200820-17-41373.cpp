#include <bits/stdc++.h>
using namespace std;
#define LL long long

int m, a[12][12], tmp;

int main() {
	cin >> m;
	for(int i = 0; i < m; ++i) {
		for(int j = 0; j < m; ++j) {
			cin >> a[i][j];
		}
	}
	for(int i = 0; i < m / 2; ++i) {
		for(int j = 0; j < m / 2; ++j) {
			tmp = a[i][j];
			a[i][j] = a[i + m / 2][j];
			a[i + m / 2][j] = a[i + m / 2][j + m / 2];
			a[i + m / 2][j + m / 2] = a[i][j + m / 2];
			a[i][j + m / 2] = tmp;
		}
	}
	for(int i = 0; i < m; ++i) {
		cout << a[i][0];
		for(int j = 1; j < m; ++j) {
			cout << ' ' << a[i][j];
		}
		cout << endl;
	}
	return 0;
}
