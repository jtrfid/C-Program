#include<stdio.h>
#include<string.h>
int main()
{
	char a[100][29]={'\0'};
	int n;
	scanf("%d",&n);
	getchar();
	for(int i=0;i<n;i++)
	{
		gets(a[i]);
	}
	int min=0,x=0;//x ������˵ĺ� 
	int max=0,y=0;//y �������˵ĺ� 
	for(int i=0;i<n;i++)//x ������˵ĺ� 
	{
		int temp=(a[i][11]-'0')*10+a[i][12]-'0';
		if(temp>min)
		{
			x=i;//��С 
		}
		if(temp=min)
		{
			int temp1=(a[x][14]-'0')*10+a[x][15]-'0';
			int temp2=(a[i][14]-'0')*10+a[i][15]-'0';
			if(temp1>temp2)
			{
				x=i;
			}
			else if(temp1<temp2)
			{
				continue;
			}else
			{
				int temp3=(a[x][17]-'0')*10+a[x][18]-'0';
				int temp4=(a[i][17]-'0')*10+a[i][18]-'0';
				if(temp3>temp4)
			    {
				    x=i;
			    }
			    else if(temp3<temp4)
			    {
				    continue;
			    }
			}
		} 
	}
	//y �������˵ĺ� 
	for(int i=0;i<n;i++)
	{
		int temp=(a[i][20]-'0')*10+a[i][21]-'0';
		if(temp>max)
		{
			y=i;//��� 
		}
		if(temp=max)
		{
			int temp1=(a[y][23]-'0')*10+a[y][24]-'0';
			int temp2=(a[i][23]-'0')*10+a[i][24]-'0';
			if(temp1<temp2)
			{
				x=i;
			}
			else if(temp1>temp2)
			{
				continue;
			}
			else{
				int temp3=(a[x][26]-'0')*10+a[x][27]-'0';
				int temp4=(a[i][26]-'0')*10+a[i][27]-'0';
				if(temp3>temp4)
			    {
				    x=i;
			    }
			    else if(temp3<temp4)
			    {
				    continue;
			    }
			}
		} 
	}
	for(int i=0;i<10;i++ )
	{
		printf("%c",a[x][i]);
	}
	printf(" ");
	for(int i=0;i<10;i++ )
	{
		printf("%c",a[y][i]);
	}
	return 0;
}
