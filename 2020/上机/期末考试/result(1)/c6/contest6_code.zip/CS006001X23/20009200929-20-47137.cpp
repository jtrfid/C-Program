#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int i,j,n,flag,k=0;
	scanf("%d",&n);
	int number[n],s1[n],f1[n],m1[n],s2[n],f2[n],m2[n],t[n];
	for(i=0;i<n;i++)
	{
		scanf("%d %d:%d:%d %d:%d:%d",&number[i],&s1[i],&f1[i],&m1[i],&s2[i],&f2[i],&m2[i]);
	}
	
	for(i=0;i<n;i++)
	{
		flag=1;
		for(j=0;j<n;j++)
		{
			if(s1[i]>s1[j]) {flag=0;break;}
		}
		if(flag==1) {t[k]=i;k++;}
	}
	if(k==1) printf("%d ",number[t[0]]); 
	else
	{
		k=0;
		for(i=0;i<n;i++)
		{
		flag=1;
		for(j=0;j<n;j++)
		{
			if(f1[i]>f1[j]) {flag=0;break;}
		}
		if(flag==1) {t[k]=i;k++;}
		}
		if(k==1) printf("%d ",number[t[0]]); 
		else
		{
			k=0;
		for(i=0;i<n;i++)
		{
		flag=1;
		for(j=0;j<n;j++)
		{
			if(m1[i]>m1[j]) {flag=0;break;}
		}
		if(flag==1) {t[k]=i;k++;}
		}
		printf("%d ",number[t[0]]); 
		}
	}
	for(i=0;i<n;i++)
	{
		k=0;
		flag=1;
		for(j=0;j<n;j++)
		{
			if(s1[i]<s1[j]) {flag=0;break;}
		}
		if(flag==1) {t[k]=i;k++;}
	}
	if(k==1) printf("%d",number[t[0]]); 
	else
	{
		k=0;
		for(i=0;i<n;i++)
		{
		flag=1;
		for(j=0;j<n;j++)
		{
			if(f1[i]<f1[j]) {flag=0;break;}
		}
		if(flag==1) {t[k]=i;k++;}
		}
		if(k==1) printf("%d",number[t[0]]); 
		else
		{
			k=0;
		for(i=0;i<n;i++)
		{
		flag=1;
		for(j=0;j<n;j++)
		{
			if(m1[i]<m1[j]) {flag=0;break;}
		}
		if(flag==1) {t[k]=i;k++;}
		}
		printf("%d",number[t[0]]); 
		}
	}
	
	system("pause");
	return 0;
}
