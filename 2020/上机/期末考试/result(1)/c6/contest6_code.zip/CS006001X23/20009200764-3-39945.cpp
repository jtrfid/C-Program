#include<stdio.h>
#include<string.h>
int main (){
	int a,b,i,j,k,n3=0,n4=0,n5=0;
	scanf("%d%d",&a,&b);
	if(b<a){
		i=a;
		a=b;
		b=i;
	}
	for(i=a;i<=b;i++){
		if(i%3==0){
			n3++;
		}
		if(i%4==0){
			n4++;
		}
		if(i%5==0&&i%2!=0){
			n5++;
		}
	}
	k=n3;
	if(k>n4){
		k=n4;
	}
	if(n5<k){
		k=n5;
	}
	printf("%d %d %d\n",n3,n4,n5);
	printf("%d",k);
	return 0;
}
