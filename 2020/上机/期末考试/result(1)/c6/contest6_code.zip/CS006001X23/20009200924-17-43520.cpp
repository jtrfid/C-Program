#include<stdio.h>
int main(){
	int m,i,j;
	scanf("%d",&m);
	int num[10][10]={0};
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&num[i][j]);
		}
	}


	for(i=m/2;i>=0;i=i-m/2){
		for(j=0;j<m/2;j++){
			printf("%d ",num[i][j]);
		}
	}
	printf("\n");
	for(i=m/2+1;i>=1;i=i-m/2){
		for(j=0;j<m/2;j++){
			printf("%d ",num[i][j]);
		}
	}
	printf("\n");
	for(i=m/2;i>=0;i=i-m/2){
		for(j=m/2;j<m;j++){
			printf("%d ",num[i][j]);
		}
	}
	printf("\n");
	for(i=m/2+1;i>=1;i=i-m/2){
		for(j=m/2;j<m;j++){
			printf("%d ",num[i][j]);
		}
	}



	return 0;
}
