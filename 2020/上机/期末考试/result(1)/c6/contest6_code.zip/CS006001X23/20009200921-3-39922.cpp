#include<stdio.h>
int main()
{
	int a,b,i,j,tmp,sum1=0,sum2=0,sum3=0,max;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		tmp=a;
		a=b;
		b=tmp;
	}
	for(i=a;i<=b;i++)
	{
		if(i%3==0)
		{
			sum1+=1;
		}
	}
	for(i=a;i<=b;i++)
	{
		if(i%4==0)
		{
			sum2+=1;
		}
	}
	for(i=a;i<=b;i++)
	{
		if(i%5==0&&i%2!=0)
		{
			sum3+=1;
		}
	}
	max=sum1;
	if(sum2<max)
	max=sum2;
	if(sum3<max)
	max=sum3;
	printf("%d %d %d\n%d",sum1,sum2,sum3,max);
	return 0;
}
