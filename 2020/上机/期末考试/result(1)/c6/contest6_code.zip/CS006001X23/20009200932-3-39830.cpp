#include<stdio.h>
int main()
{
	int A,B;
	int a=0,b=0,c=0;
	int i,j;
	scanf("%d %d",&A,&B);
	for(i=A;i<=B;i++)
	{
		if(i%3==0)
		{
			a++;
		}
		if(i%4==0)
		{
			b++;
		}
		if(i%5==0&&i%2!=0)
		{
			c++;
		}
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
