#include<stdio.h>
#include<string.h>
typedef struct
{
	char a[11];
	char s[9];
	char e[9];
}stud;
int main()
{
	int n,i,j;
	stud stu[100],t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",&stu[i].a);
		scanf("%s",&stu[i].s);
		scanf("%s",&stu[i].e);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(strcmp(stu[j].s,stu[j+1].s)>0)
			{
				t=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=t;
			}
		}
	}
	printf("%s ",stu[0].a);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(strcmp(stu[j].e,stu[j+1].e)<0)
			{
				t=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=t;
			}
		}
	}
	printf("%s",stu[0].a);
	return 0;

}
