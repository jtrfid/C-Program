#include<stdio.h>
int main(){
	int m,i,j;
	scanf("%d",&m);
	int num[10][10]={0};
	int ppp[10][10]={0};
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&num[i][j]);
		}
	}



	for(i=0;i<m/2;i++){
		for(j=0;j<m/2;j++){
			ppp[i][j+m/2]=num[i][j];
		}
	}
	for(i=0;i<m/2;i++){
		for(j=m/2;j<m;j++){
			ppp[i+m/2][j]=num[i][j];
		}
	}
	for(i=m/2;i<m;i++){
		for(j=0;j<m/2;j++){
			ppp[i-m/2][j]=num[i][j];
		}
	}
	for(i=m/2;i<m;i++){
		for(j=m/2;j<m;j++){
			ppp[i][j-m/2]=num[i][j];
		}
	}


	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			printf("%d ",ppp[i][j]);
		}
		printf("\n");
	}
	return 0;
}
