#include<stdio.h>
typedef struct TIME{
	int h;
	int m;
	int s;
}time;
typedef struct STUDENT{
	char num[11]={0};
	time in;
	time out;
}student;
int main()
{
	int n,i;
	student early,late;
	student stu[100];
	
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s %d:%d:%d %d:%d:%d",&stu[i].num,&stu[i].in.h,&stu[i].in.m,
		&stu[i].in.s,&stu[i].out.h,&stu[i].out.m,&stu[i].out.s);
	}
	early=stu[0]; late=stu[0];
	for(i=1;i<n;i++)
	{
		if(early.in.h>=stu[i].in.h)
		{
			if(early.in.h>stu[i].in.h)	early=stu[i];
			else
			{
				if(early.in.m>=stu[i].in.m)
				{
					if(early.in.m>stu[i].in.m)	early=stu[i];
					else
					{
						if(early.in.s>stu[i].in.s)	early=stu[i];
					}
				}
			}
		}
		if(late.out.h<=stu[i].out.h)
		{
			if(late.out.h<stu[i].out.h)	late=stu[i];
			else
			{
				if(late.out.m<=stu[i].out.m)
				{
					if(late.out.m<stu[i].out.m)	late=stu[i];
					else
					{
						if(late.out.s<stu[i].out.s)	late=stu[i];
					}
				}
			}
		}
	}
	printf("%s %s",early.num,late.num);
	return 0;
}
