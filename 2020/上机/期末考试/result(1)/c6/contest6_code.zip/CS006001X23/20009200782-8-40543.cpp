#include<cstdio>
#include<cstring>
#define N 100
using namespace std;
char x[N]="0123456789ABCDEF";
int y[N]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
int check(char c){
	for(int i=0;i<16;i++){
		if(c==x[i])return y[i];
	}
	return -1;
}
int main(){
	char s[N];
	scanf("%s",&s);
	int len=strlen(s);
	int i;
	for(i=0;i<len;i++){
		if(s[i]>='a'&&s[i]<='z')s[i]=s[i]-'a'+'A';
	}
	int ans=0;
	int flag=0;
	int t;
	for(i=0;i<len;i++){
		t=check(s[i]);
		if(t>=0){
			flag=1;
			ans+=t;
		}
		else continue;
	}
	if(!flag)printf("NO");
	else printf("%d",ans);
	return 0;
}
