#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		int temp=a;
		a=b;
		b=temp;
	}
	int count[3]={0};
	for(int i=a;i<=b;i++)
	{
		if(i%3==0)
		count[0]++;
		if(i%4==0)
		count[1]++;
		if(i%5==0&&i%2!=0)
		count[2]++;
	}
	int result=count[0];
	for(int i=0;i<3;i++)
	{
		printf("%d ",count[i]);
		if(count[i]<result)
		result=count[i];
	}
	printf("\n");
	printf("%d",result);
	return 0;
}
