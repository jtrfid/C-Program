#include<stdio.h>
#include<string.h>

int compare(char *q, char *w)
{
	while(*q != '\0')
	{
		if(*q < *w) return -1;
		if(*q > *w) return 1;
		else
		{
			q++;
			w++;
		}
	}
	return 0;
}

int main()
{
	int n;
	scanf("%d", &n);
	char stu[111][20] = {0};
	char in[111][20] = {0};
	char out[111][20] = {0};
	int open = 0;
	int close = 0;
	
	for(int i = 0; i < n; i++)
	{
		scanf("%s", stu[i]);
		scanf("%s", in[i]);
		scanf("%s", out[i]);
	}
	
	char tar1[20] = {0};
	char tar2[20] = {0};
	strcpy(tar1, in[0]);
	strcpy(tar2, out[0]);
	for(int i = 1; i < n; i++)
	{
		if(compare(&in[i][0], &tar1[0]) == -1)
		open = i;
		if(strcmp(&out[i][0], &tar2[0]) == 1)
		close = i;
	}
	
	printf("%s %s", stu[open], stu[close]);
	
	return 0;
}
