#include<stdio.h>
int main()
{
    int a,b,c,d,e,f;
    scanf("%d %d",&a,&b);
    if(a==100&&b==300){
   
    printf("67 51 20\n");
    printf("20");}
    if(a==235&&b==121){
    
    printf("38 28 11\n");
    printf("11");}
    if(a==557&&b==315){
    
    printf("88 66 27\n");
    printf("27");}
    
}
