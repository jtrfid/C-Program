#include<bits/stdc++.h>


int main()
{
	int i = 0,sum = 0,flag = 0;
	char s[60] = {0};
	
	scanf("%s",s);
	
	for(i = 0;i < strlen(s);i++)
	{
		if(s[i]>='0' && s[i]<='9')
		{
			sum+=s[i]-'0';
			flag = 1;
		}
		else if(s[i] >= 'A' && s[i]<='F')
		{
			sum+=s[i]-'A'+10;
			flag = 1;
		}
		else if(s[i]>='a' && s[i]<='f')
		{
			sum+=s[i]-'a'+10;
			flag = 1;
		}
	}
	
	if(flag)
	{
		printf("%d",sum);
	}
	else
	{
		printf("NO");
	}
	
	return 0;
}
