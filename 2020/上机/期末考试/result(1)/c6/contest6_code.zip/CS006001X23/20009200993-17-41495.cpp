#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main()
{
	int m=0;
	scanf("%d",&m);
	int a[10][10];
	
	int i=0;
	int j=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	
	int b[10][10]={0};
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(i<=m/2-1&&j<=m/2-1)
			{
				b[i][j+m/2]=a[i][j];
			}
			else if(i<=m/2-1&&j>m/2-1)
			{
				b[i+m/2][j]=a[i][j];
			}
			else if(i>m/2-1&&j<=m/2-1)
			{
				b[i-m/2][j]=a[i][j];
			}
			else if(i>m/2-1&&j>m/2-1)
			{
				b[i][j-m/2]=a[i][j];
			}
			
		}
	}
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	
	return 0;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
