#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
int main()
{
	int a[10][10]={0};
	int b[10][10]={0};
	
	int i=0,j=0,m;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	
	int mid=m/2;
	
	for(i=0;i<m;i++)
	{
		for (j=0;j<m;j++)
		{
			if(i<mid)
			{
				if(j<mid)
				{
					b[i][j+mid]=a[i][j];
				}
				else
				{
					b[i+mid][j]=a[i][j];
				}
			}
			else
			{
				if(j<mid)
				{
					b[i-mid][j]=a[i][j];
				}
				else
				{
					b[i][j-mid]=a[i][j];
				}
			}
		}
	}
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	
	
	return 0;	
} 
