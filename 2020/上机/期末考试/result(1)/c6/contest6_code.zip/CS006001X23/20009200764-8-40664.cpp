#include<stdio.h>
#include<string.h>
int main (){
	char a[100];
	gets(a);
	int i,j=0,k=0,n,fe=0;
	n=strlen(a);
	for(i=0;i<n;i++){
		if(a[i]>='0'&&a[i]<='9'){
			j=a[i]-'0';
			fe=1;
		}
		if(a[i]>='A'&&a[i]<='F'){
			j=10+a[i]-'A';
			fe=1;
		}
		if(a[i]>='a'&&a[i]<='f'){
			j=10+a[i]-'a';
			fe=1;
		}
		k+=j;
		j=0;
	}
	if(fe==1){
		printf("%d",k);
	}
	else{
		printf("NO");
	}
	return 0;
}
