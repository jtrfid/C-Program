#include<stdio.h>
#include<string.h>

int main(){
	int n;
	scanf("%d",&n);
	struct stu{
		int num;
		char begin[50];
		char leave[50];
		int begin1;
		int leave1;
	}s[200];
	int i,j,a,b,c,t,se;
	int be[n],l[n];
	for(i=0;i<n;i++){
		scanf("%d %s %s",&s[i].num,s[i].begin,s[i].leave);
	}
	for(j=0;j<n;j++){
		for(a=0,b=0,c=0,se=0,i=0;i<8;i++){
			if(i<2){
				a=a*10+s[j].begin[i]-48;
			}
			if(i==2) c=c+a*3600;
			if(i>2&&i<5) b=b*10+s[j].begin[i]-48;
			if(i==5) c=c+b*60;
			if(i>5) se=se*10+s[j].begin[i]-48;	
		}
		s[j].begin1=c+se;
	}
	for(j=0;j<n;j++){
		for(a=0,b=0,c=0,se=0,i=0;i<8;i++){
			if(i<2){
				a=a*10+s[j].leave[i]-48;
			}
			if(i==2) c=c+a*3600;
			if(i>2&&i<5) b=b*10+s[j].leave[i]-48;
			if(i==5) c=c+b*60;
			if(i>5) se=se*10+s[j].leave[i]-48;	
		}
		s[j].leave1=c+se;
	}
	int max=s[0].leave1,min=s[0].begin1;
	for(i=0;i<n;i++){
		if(s[i].leave1>max) max=s[i].leave1;
		if(s[i].begin1<min) min=s[i].begin1;
	}
	for(i=0;i<n;i++){
		if(s[i].leave1==max) b=i;
		if(s[i].begin1==min) a=i;
	}
	printf("%d %d",s[a].num,s[b].num);
	
	
	return 0;
}
