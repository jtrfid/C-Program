#include <stdio.h>
int main()
{
	int i,m,n,temp,a=0,b=0,c=0,max=0;
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		temp=m;
		m=n;
		n=temp;
	}
	for(i=m;i<=n;i++)
	
	{
		if(i%3==0)
		{
			a++;
		}
		if(i%4==0)
		{
			b++;
		}
		if(i%5==0&&i%2!=0)
		{
			c++;
		}
	}
	max=(a<b)?a:b;
	max=(max<c)?max:c;
	printf("%d %d %d\n%d",a,b,c,max);
	
}
