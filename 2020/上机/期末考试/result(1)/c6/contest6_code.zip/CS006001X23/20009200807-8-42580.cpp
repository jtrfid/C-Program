#include<stdio.h>
#include<string.h>

int main()
{
	char str[55] = {0};
	gets(str);
	
	int i = 0;
	int sum = 0;
	int flag = 0;
	while(str[i] != '\0')
	{
		if(str[i] >= '0' && str[i] <= '9')
		{
			sum += str[i] - '0';
			flag = 1;
		}
		if(str[i] >= 'a' && str[i] <= 'f')
		{
			sum += str[i] - 87;
			flag = 1;
		}
		if(str[i] >= 'A' && str[i] <= 'F')
		{
			sum += str[i] - 55;
			flag = 1;
		}
		i++;
	}
	if(flag == 0) printf("NO");
	else printf("%d", sum);
	
	return 0;
}
