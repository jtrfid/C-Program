#include<stdio.h>
int main()
{
	int m=0;
	scanf("%d",&m);
	int str[m][m];
	int i=0,j=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&str[i][j]);
		}
	}
	int t=0;
	t=m/2;
	int a[t][t],b[t][t],c[t][t],d[t][t];
	int x=0,y=0,g=0,h=0;
	for(x=0;x<t;x++)
	{
		for(y=0;y<t;y++)
		{
			a[x][y]=str[x][y];
		}
		for(y=t;y<m;y++)
		{
			c[x][y-t]=str[x][y];
		
		}
	
	}

	for(x=t;x<m;x++)
	{
		for(y=0;y<t;y++)
		{
			b[x-t][y]=str[x][y];
	
		}
		
		for(y=t;y<m;y++)
		{
			d[x-t][y-t]=str[x][y];
		}
		
	}
	i=0;
	j=0;
	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			str[i][j]=b[i][j];
		}
		for(j=t;j<m;j++)
		{
			str[i][j]=a[i][j-t];
		}
	}
	for(i=t;i<m;i++)
	{
		for(j=0;j<t;j++)
		{
			str[i][j]=d[i-t][j];
		}
		for(j=t;j<m;j++)
		{
			str[i][j]=c[i-t][j-t];
		}
	}
	x=0;
	y=0;
	for(x=0;x<m;x++)
	{
		for(y=0;y<m;y++)
		{
			printf("%d ",str[x][y]);
		}
		printf("\n");
	}
	return 0;
}
