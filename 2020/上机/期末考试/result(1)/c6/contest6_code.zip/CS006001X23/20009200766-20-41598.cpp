#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
struct N{
	int h1,m1,s1,h2,m2,s2;
	string id;
}stu[1001],a,b;
int n;

bool pd1(N x,N y)
{
	if(x.h1!=y.h1)
	{
		return x.h1<y.h1;
	}
	else if(x.m1!=y.m1)
	{
		return x.m1<y.m1;
	}
	else return x.s1<y.s1;
}

bool pd2(N x,N y)
{
	if(x.h2!=y.h2)
	{
		return x.h2<y.h2;
	}
	else if(x.m2!=y.m2)
	{
		return x.m2<y.m2;
	}
	else return x.s2<y.s2;
}

int main()
{
	a.h1=100,a.m1=100,a.s1=100;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>stu[i].id;
		scanf("%d:%d:%d",&stu[i].h1,&stu[i].m1,&stu[i].s1);
		scanf("%d:%d:%d",&stu[i].h2,&stu[i].m2,&stu[i].s2);
		if(pd1(stu[i],a))
		{
			a=stu[i];
		}
		if(pd2(b,stu[i]))
		{
			b=stu[i];
		}
	}
	cout<<a.id<<' '<<b.id;
}

