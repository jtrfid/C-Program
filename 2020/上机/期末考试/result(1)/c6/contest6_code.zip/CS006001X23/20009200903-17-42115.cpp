#include<stdio.h>

int main()
{
	int m;
	int a[11][11],b[11][11];
	scanf("%d",&m);
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int p=0;p<m/2;p++)
	{
		for(int q=0;q<m/2;q++)
		{
			b[p][q]=a[p+m/2][q];
		}
	}
	for(int p=0;p<m/2;p++)
	{
		for(int q=m/2;q<m;q++)
		{
			b[p][q]=a[p][q-m/2];
		}
	}
	for(int p=m/2;p<m;p++)
	{
		for(int q=0;q<m/2;q++)
		{
			b[p][q]=a[p][q+m/2];
		}
	}
	for(int p=m/2;p<m;p++)
	{
		for(int q=m/2;q<m;q++)
		{
			b[p][q]=a[p-m/2][q];
		}
	}
	for(int p=0;p<m;p++)
	{
		for(int q=0;q<m;q++)
		{
			printf("%d ",b[p][q]);
		}
		printf("\n");
	}
	return 0;
}
