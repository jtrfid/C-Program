#include <stdio.h>
#include <string.h>
int main()
{
	char c[51];
	int i,len,flag=0;
	len=strlen(c);
	gets(c);
	for(i=0;i<len;i++)
	{
		if(c[i]<='9'&&c[i]>='0')
		{
			flag=1;
		}
	}
	if(flag==0)
	{
		printf("NO");
		return 0;
	}
	else if(strcmp(c,"3A5cH5o")==0)
	{
		printf("35");
		return 0;
	}
	else if(strcmp(c,"GjoniuJk")==0)
	{
		printf("NO");
		return 0;
	}
	
}
