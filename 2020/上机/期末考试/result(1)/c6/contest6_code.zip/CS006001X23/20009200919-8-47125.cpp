/*

    Name:Chars Control.cpp
    	
    Author:Konoha Akari
    
    Date:2021/1/9
    
*/

#include<stdio.h>

int main()

{
	char x[50]={0};
	
	int i,j,sum=0;
	
	scanf("%s",&x);
	
	for(j=0;j<50;j++)
	
	{
		
	if(x[j]==1)sum=1;
	
	else if(x[j]==2)sum=2;
	
	else if(x[j]==3)sum=3;
	
	else if(x[j]==4)sum=4;
	
	else if(x[j]==5)sum=5;
	
	else if(x[j]==6)sum=6;
	
	else if(x[j]==7)sum=7;
	
	else if(x[j]==8)sum=8;
	
	else if(x[j]==9)sum=9;
	
	else if(x[j]=='A'||'a')sum=10;
	
	else if(x[j]=='B'||'b')sum=11;
	
	else if(x[j]=='C'||'c')sum=12;
	
	else if(x[j]=='D'||'d')sum=13;
	
	else if(x[j]=='E'||'e')sum=14;
	
	else if(x[j]=='F'||'f')sum=15;
	
	else i++;
	
	sum+=sum;
	
	}
	
	if(i==8)printf("NO");
	
	else printf("%d",sum);
	
	return 0;
	
}
