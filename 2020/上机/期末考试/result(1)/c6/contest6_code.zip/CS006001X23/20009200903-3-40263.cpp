#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<string.h>

int main()
{
	int A,B;
	scanf("%d %d",&A,&B);
	int min,max,s=0,su=0,sum=0;
	if(A>=B)
	{
		min=B;
		max=A;
	}
	else
	{
		min=A;
		max=B;
	}
	for(int i=min;i<=max;i++)
	{
		if(i%3==0)
		s=s+1;
		if(i%4==0)
		su=su+1;
		if(i%5==0&&i%2!=0)
		sum=sum+1;
	}
	int p;
	if(s<=su&&s<=sum)
    p=s;
    if(su<=s&&su<=sum)
    p=su;
    if(sum<=s&&sum<=su)
    p=sum;
    printf("%d %d %d\n%d",s,su,sum,p);
    return 0;
}
