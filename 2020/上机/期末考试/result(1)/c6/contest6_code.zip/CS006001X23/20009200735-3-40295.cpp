#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int A,B,i,j,x,y,z,min;
	x=0;
	y=0;
	z=0;
	scanf("%d %d",&A,&B);
	if(A<B){
		for(i=A;i<=B;i++){
			if(i%3==0)x++;
			if(i%4==0)y++;
			if(i%5==0&&i%2!=0)z++;
		}
	}
	else{
		for(i=B;i<=A;i++){
			if(i%3==0)x++;
			if(i%4==0)y++;
			if(i%5==0&&i%2!=0)z++;
		}
	}	
	min=x;
	if(x>=y&&z>=y)min=y;
	if(y>=x&&z>=x)min=x	;
	if(x>=z&&y>=z)min=z	;
	printf("%d %d %d\n%d",x,y,z,min);
	return 0;
}
