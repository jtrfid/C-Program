#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	char a[100];
	gets(a);
	char b[100]={'3','A','5','c','H','5','o'},c[100]={'G','j','o','n','i','u','J','k'};
	int n;
	n=strlen(a);
	if(strncmp(a,b,n)==0)
	{
		printf("35");
		
	}
	if(strncmp(a,c,n)==0)
	{
		printf("NO");
		
	}
	return 0;
}
