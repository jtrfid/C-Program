#include<bits/stdc++.h>
using namespace std;
#define For(i,a,b) for(int i=a,i##_end=b;i<i##_end;++i)
#define foe(i,a) for(__typeof(a.end())i=a.begin();i!=a.end();++i)
#define mp make_pair
#define pb push_back
#define fi first
#define se second
typedef long long ll;
typedef pair<int,int> pii;
typedef vector<int> VI;
template<typename T>T gcd(T a,T b){while(b)a%=b,swap(a,b);return a;}
int n;
int a[111][111],b[111][111];
int main(){
#ifdef SGR
	freopen("a.txt","r",stdin);
#endif
	cin>>n;
	For(i,0,n)For(j,0,n)cin>>a[i][j];
	int m=n/2;
	For(i,0,m)For(j,0,m){
		b[i][j+m]=a[i][j];
		b[i+m][j+m]=a[i][j+m];
		b[i][j]=a[i+m][j];
		b[i+m][j]=a[i+m][j+m];
	}
	For(i,0,n)For(j,0,n)printf("%d%c",b[i][j]," \n"[j==n-1]);
}

