#include<stdio.h>
int main()
{
	int n=0;
	int i,j;
	int a[11][11]={0};
	int b[11][11]={0};
	scanf("%d", &n);
	for ( i=1; i<=n; i++ ){
		for ( j=1; j<=n; j++ ){
			scanf("%d", &a[i][j]);
		}
	}
	for ( i=1; i<=n; i++ ){
		for ( j=1; j<=n/2; j++ )
		b[i][j]=a[i][j+n/2];
	}
	for ( i=1; i<=n; i++ ){
		for ( j=n/2+1; j<=n; j++ )
		b[i][j]=a[i][j-n/2];
	}
	int t=0;
	for ( i=1; i<=n/2; i++ ){
		for ( j=1; j<=n/2; j++ ){
			t=b[i+n/2][j+n/2];
			b[i+n/2][j+n/2]=b[i][j];
			b[i][j]=t;
		}
	}
	
	
	
	
	
	
	for ( i=1; i<=n; i++ ){
		for ( j=1; j<=n; j++ ){
			printf("%d   ", b[i][j]);
		}
		printf("\n");
	}
	
	
	
	
	
	
	
	return 0;
	
}
