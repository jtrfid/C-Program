#include<stdio.h>
#include<string.h>
typedef struct{
	int a;
	char b[10];
	char c[10];
}student;
int fgo(char d[])
{
	return (((d[0]*10+d[1])*60+d[4]*10+d[5])*60+d[7]*10+d[8]);
}

int main()
{
	int m,n,i,j,l;

	student str[45],s;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s %s",&str[i].a,&str[i].b,&str[i].c);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if((fgo(str[j].b)-'0')>(fgo(str[j+1].b)-'0'))
			{
				s=str[j];
				str[j]=str[j+1];
				str[j+1]=s;
			}
		}
	}
	printf("%d ",str[0].a);
	
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if((fgo(str[j].c)-'0')<(fgo(str[j+1].c)-'0'))
			{
				s=str[j];
				str[j]=str[j+1];
				str[j+1]=s;
			}
		}
	}
		printf("%d ",str[0].a);
	
	
	
	return 0;
}
