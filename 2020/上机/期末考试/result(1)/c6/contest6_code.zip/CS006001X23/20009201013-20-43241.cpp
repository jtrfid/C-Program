#include<stdio.h>
#include<string.h>
#include<math.h>
typedef struct{
	int id;
	char come[100];
	char leave[100];
}STU;
int main()
{
	int N;
	scanf("%d",&N);
	STU stu[100];
	int one=0,last=0;
	int i=0,j=0;
	for(i=0;i<N;i++)
	{
		scanf("%d %s %s",&stu[i].id,&stu[i].come,&stu[i].leave);
	}
	for(i=0;i<=N;i++)
	{
		if(strcmp(stu[i].come,stu[i+1].come)<0)
		one=stu[i].id;
	}
	for(i=0;i<=N;i++)
	{
		if(strcmp(stu[i].come,stu[i+1].come)>0)
		last=stu[i].id;
	}
	printf("%d %d",one,last);
	
	
	
	return 0;
}

