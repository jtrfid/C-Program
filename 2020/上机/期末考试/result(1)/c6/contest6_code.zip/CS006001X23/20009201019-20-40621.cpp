#include<bits/stdc++.h>
using namespace std;
#define For(i,a,b) for(int i=a,i##_end=b;i<i##_end;++i)
#define foe(i,a) for(__typeof(a.end())i=a.begin();i!=a.end();++i)
#define mp make_pair
#define pb push_back
#define fi first
#define se second
typedef long long ll;
typedef pair<int,int> pii;
typedef vector<int> VI;
template<typename T>T gcd(T a,T b){while(b)a%=b,swap(a,b);return a;}
int n;
struct stu{
	string name,in,out;
} a[111];
int main(){
#ifdef SGR
	freopen("a.txt","r",stdin);
#endif
	cin>>n;
	For(i,0,n)cin>>a[i].name>>a[i].in>>a[i].out;
	int p=0,q=0;
	For(i,1,n)if(a[i].in<a[p].in)p=i;
	For(i,1,n)if(a[i].out>a[p].out)q=i;
	cout<<a[p].name<<" "<<a[q].name<<endl;
}

