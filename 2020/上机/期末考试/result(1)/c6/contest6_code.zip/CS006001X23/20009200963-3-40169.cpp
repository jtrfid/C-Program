#include <stdio.h>

int a, b, mini = 0x3f3f3f3f;
int cnt[5];

void swap(int &a, int &b) {
	int t = a;
	a = b, b = t;
}

bool is5(int num) {
	return (!(num % 5) && (num & 1));
}

int main() {
	scanf("%d%d", &a, &b);
	if (a > b) swap(a, b);
	for (int i = a; i <= b; i++) {
		if (!(i % 3)) cnt[0]++;
		if (!(i % 4)) cnt[1]++;
		if (is5(i)) cnt[2]++;
	}
	for (int i = 0; i < 3; i++) {
		mini = cnt[i] < mini ? cnt[i] : mini;
		printf("%d ", cnt[i]);
	}
	printf("\n%d\n", mini);
	return 0;
}
