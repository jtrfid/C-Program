#include<stdio.h>

int main()
{
	int m, a[11][11], i, j;
	
	scanf("%d", &m);
	
	for(i = 1; i <= m; i ++)
		for(j = 1; j <= m; j ++)
			scanf("%d", &a[i][j]);
////////
	for(j = 1; j <= m / 2; j ++)
	{
		for(i = 1; i <= m / 2; i ++)
			printf("%d ", a[j + m / 2][i]);
		
		for(i = 1; i <= m / 2; i ++)
			printf("%d ", a[j][i]);
		
		printf("\n");
	}
	
	for(j = 1; j <= m / 2; j ++)
	{
		for(i = 1 + m / 2; i <= m; i ++)
			printf("%d ", a[j + m / 2][i]);
		
		for(i = 1 + m / 2; i <= m; i ++)
			printf("%d ", a[j][i]);
		
		printf("\n");
	}

	
	return 0;
}
