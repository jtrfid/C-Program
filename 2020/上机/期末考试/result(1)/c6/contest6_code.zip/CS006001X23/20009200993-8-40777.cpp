#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main()
{
	char s[51]={0};
	gets(s);
	int i=0;
	int sum=0;
	 
	 int t=strlen(s);
	 int flag=0;
	 for(i=0;i<t;i++)
	 {
	 	if(s[i]>='0'&&s[i]<='9')
	 	{
	 		flag=1;
	 		sum=sum+(s[i]-'0');
	 	}
	 	else if(s[i]>='a'&&s[i]<='f')
	 	{
	 		flag=1;
	 		sum=sum+s[i]-'a'+10;
	 	}
	 	else if(s[i]>='A'&&s[i]<='F')
	 	{
	 		flag=1;
	 		sum=sum+s[i]-'A'+10;
	 	}
	 }
	 if(flag==0)
	 {
	 	printf("NO");
	 }
	 else
	 {
	 	printf("%d",sum);
	 }
	 
	 return 0;
}
