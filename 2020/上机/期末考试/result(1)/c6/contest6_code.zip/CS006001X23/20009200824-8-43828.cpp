#include<stdio.h>
#include<string.h>

int main()
{
	char c[51];
	
	gets(c);
	
	int len,n,i,a=0,b=0,sum=0;
	
	len=strlen(c);
	
	for(i=0;i<len;i++)
	{
		if(c[i]>'0'&&c[i]<'9')
		a++;
		else if(c[i]>='a'&&c[i]<='g'||c[i]>='A'&&c[i]<='G')
		b++;
	}
	if(a!=0&&b!=0)
	{
		for(i=0;i<len;i++)
		{
			if(c[i]>='0'&&c[i]<='9')
	        sum+=int(c[i]-48);
	        else if(c[i]>='A'&&c[i]<='G')
	        sum+=int(c[i]-55);
	        else if(c[i]>='a'&&c[i]<='g')
	        sum+=int(c[i]-87);
		}
	   
	   printf("%d",sum);
	}
	else
	{
		printf("NO");
	}
	
	return 0;
}
