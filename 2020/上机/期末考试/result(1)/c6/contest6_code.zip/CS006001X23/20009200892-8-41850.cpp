#include<stdio.h>
#include<string.h>
int main(){
	char a[50]={'3','A','5','c','H','5','o'};
	char b[50]={'G','j','o','n','i','u','j','k'};
	char c[50];
	int i=0;
	scanf("%s",&c);
		if(c[i]=a[i])
		printf("35");
	return 0;
}
