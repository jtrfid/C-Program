#include<stdio.h>
#include<string.h> 
int main()
{
	char s[51], *p = s;
	int  sum = 0, book = 0;
	
	gets(s);
	
	while(*p)
	{
		if(*p >= '0' && *p <= '9')
		{
			sum += *p - '0';
			book = 1;
		}				
		else		
		{
			switch(*p)
			{
				case 'a': sum += 10;book = 1; break;
				case 'b': sum += 11;book = 1; break;
				case 'c': sum += 12;book = 1; break;
				case 'd': sum += 13;book = 1; break;
				case 'e': sum += 14;book = 1; break;
				case 'f': sum += 15;book = 1; break;
				
				case 'A': sum += 10;book = 1; break;
				case 'B': sum += 11;book = 1; break;
				case 'C': sum += 12;book = 1; break;
				case 'D': sum += 13;book = 1; break;
				case 'E': sum += 14;book = 1; break;
				case 'F': sum += 15;book = 1; break;
			}			
		}	
		p ++;
	}
	
	if(book == 0)
		printf("NO");
	else
		printf("%d", sum);
	

	return 0;
}
