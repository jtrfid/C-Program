#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[10][10]={0};
	int b[10][10]={0};
	int i=0,j=0;
	int N=n/2;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
			if((i>=0&&i<N)&&(j>=0&&j<N))
			b[i][j+N]=a[i][j];
			else if((i>=N&&i<n)&&(j>=0&&j<N))
			b[i-N][j]=a[i][j];
			else if((i>=0&&i<N)&&(j>=N&&j<n))
			b[i+N][j]=a[i][j];
			else if((i>=N&&i<n)&&(j>=N&&j<n))
			b[i][j-N]=a[i][j];
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	
	
	
	
	
	return 0;
}

