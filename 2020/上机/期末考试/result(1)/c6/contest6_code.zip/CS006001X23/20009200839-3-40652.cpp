#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <stdlib.h>

int min(int a,int b)
{
	int min=0;
	if(a<b)  min=a;
	else  min=b;
	return min;
}

int main(){
	int a,b;
	scanf("%d %d",&a,&b);
	int count1=0;
	int count2=0;
	int count3=0;  //��ʼ�� 
	
	int A,B;
	if(a<b)
	{
		A=a;
		B=b;
	}
	else
	{
		A=b;
		B=a;
	}  //ȷ��A<B
	 
	int i;
	for(i=A;i<=B;i++)
	{
		if(i%3==0)  count1++;
	}
	
	for(i=A;i<=B;i++)
	{
		if(i%4==0)  count2++;
	}
	
	for(i=A;i<=B;i++)
	{
		if(i%5==0&&i%2!=0)  count3++;
	}
	
	printf("%d %d %d\n" ,count1,count2,count3);
	printf("%d",min(min(count1,count2),count3));
	return 0;
}
