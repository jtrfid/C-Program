#include<algorithm>
#include<stdbool.h>
#include<memory.h>
#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>

using namespace std;

int three(int up,int down);
int four(int up,int down);
int five(int up,int down);

int main(void){
	int x=0,y=0;
	cin>>x>>y;
	int up=max(x,y),down=min(x,y);
	int a=three(up,down),b=four(up,down),c=five(up,down);
	int d=min(min(a,b),c);
	printf("%d %d %d\n",a,b,c);
	cout<<d;
	
	return 0;
}

int three(int up,int down){
	int rtn=0;
	for(int i=down;i<=up;i++){
		if(i%3==0){
			rtn++;
		}else{
			continue;
		}
	}
	return rtn;
}

int four(int up,int down){
	int rtn=0;
	for(int i=down;i<=up;i++){
		if(i%4==0){
			rtn++;
		}else{
			continue;
		}
	}
	return rtn;
}

int five(int up,int down){
	int rtn=0;
	for(int i=down;i<=up;i++){
		if(i%5==0&&i%2!=0){
			rtn++;
		}else{
			continue;
		}
	}
	return rtn;
}
