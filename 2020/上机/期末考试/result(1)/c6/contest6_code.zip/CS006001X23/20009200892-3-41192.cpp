#include<stdio.h>
int main(){
	int a,b,t,p;
	int i,countt=0,countf=0,county=0;
	int m,n,q;
	scanf("%d %d",&a,&b);
	if(a>b){
		t=a;a=b;b=t;
	}
	p=b-a;
	for(i=0;i<=p;i++){
		if((a+i)%3==0){
			countt++;
		}
		if((a+i)%4==0){
			countf++;
		}
		if((a+i)%5==0&&(a+i)%2!=0){
			county++;
		}
	}
	printf("%d %d %d",countt,countf,county);
	printf("\n");
	int s[3]={countt,countf,county};
	for(m=0;m<2;m++){
		for(n=0;n<2-m;n++){
			if(s[n]>s[n+1]){
			q=s[n];
			s[n]=s[n+1];
			s[n+1]=q;	
			}
		}
	}
	printf("%d",s[0]);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
