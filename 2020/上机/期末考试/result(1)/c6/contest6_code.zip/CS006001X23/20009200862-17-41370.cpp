#include<stdio.h>
int main()
{int hangshu,a[11][11],temp[11][11];
scanf("%d",&hangshu);
for(int i=0;i<hangshu;i++)
for(int j=0;j<hangshu;j++)
scanf("%d",&a[i][j]);
//��ʼȡ��һ��
for(int i=0;i<(hangshu/2);i++)
for(int j=0;j<(hangshu/2);j++)
{   temp[i][j]=a[i][j];}	
//������һ������
for(int i=(hangshu/2);i<hangshu;i++)
for(int j=0;j<(hangshu/2);j++)
{a[i-(hangshu/2)][j]=a[i][j];}
//������
for(int i=(hangshu/2);i<hangshu;i++)
for(int j=(hangshu/2);j<hangshu;j++)
 a[i][j-(hangshu/2)]=a[i][j];
//������
for(int i=0;i<(hangshu/2);i++)
for(int j=(hangshu/2);j<hangshu;j++)
a[i+(hangshu/2)][j]=a[i][j];	
//��ԭ��һ��
for(int i=0;i<(hangshu/2);i++)
for(int j=0;j<(hangshu/2);j++)
a[i][j+(hangshu/2)]=temp[i][j];

for(int i=0;i<hangshu;i++)
for(int j=0;j<hangshu;j++)
{
 printf("%d ",a[i][j]);	
 if(j==hangshu-1) printf("\n");
}

}
