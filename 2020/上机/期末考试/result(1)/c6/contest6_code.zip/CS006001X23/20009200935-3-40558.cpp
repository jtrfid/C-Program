#include<stdio.h>
int q(int a,int b,int c)
{
	if(a<=b&a<=c)
	{
		return a;
	}
	else if(b<=a&b<=c)
	{
		return b;
	}
	else if(c<=a&c<=b)
	{
		return c;
	}
}
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int i,c=0,d=0,e=0;
	if(a>b)
	{
		for(i=b;i<=a;i++)
		{
			if(i%3==0)
			{
				c=c+1;
			}
			else
			{
				i=i;
			}
			if(i%4==0)
			{
				d=d+1;
			}
			else
			{
				i=i;
			}
			if(i%5==0&i%2!=0)
			{
				e=e+1;
			}
			else
			{
				i=i;
			}
		}
	}
	else if(a<b)
	{
		for(i=a;i<=b;i++)
		{
			if(i%3==0)
			{
				c=c+1;
			}
			else
			{
				i=i;
			}
			if(i%4==0)
			{
				d=d+1;
			}
			else
			{
				i=i;
			}
			if(i%5==0&i%2!=0)
			{
				e=e+1;
			}
			else
			{
				i=i;
			}
		}
	}
	else
	{
		c=c;
	}
	printf("%d %d %d\n%d",c,d,e,q(c,d,e));
	return 0;
}
