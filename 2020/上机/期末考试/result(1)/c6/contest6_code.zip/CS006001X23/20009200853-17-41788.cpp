#include<stdio.h>
#include<string.h>
int main()
{
	int i,j,n,k;
	scanf("%d",&n);
	int a[n][n],b[n][n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
		if(i>=0&&i<n/2&&j>=0&&j<n/2)
		{
		   b[i][j+n/2]=a[i][j];	
		}
		if(i>=n/2&&i<n&&j>=n/2&&j<n)
		{
			b[i][j+n/2]=a[i][j];
		}
		if(i>=0&&i<n/2&&j>=n/2&&j<n)
		{
		   b[i+n/2][j]=a[i][j];
	    }
	    if(i>=n/2&&i<n&&j>=0&&j<n/2)
	    {
	    	b[i-n/2][j]=a[i][j];
	    }
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d",b[i][j]);
		}
	}
	return 0;
}
