#include<stdio.h>
#include<string.h>

int main()
{
	char c[51];
	
	gets(c);
	
	int len,n,i,a=0,b=0;
	
	len=strlen(c);
	
	for(i=0;i<len;i++)
	{
		if(c[i]>'0'&&c[i]<'9')
		a++;
		else if(c[i]>='a'&&c[i]<='z'||c[i]>='A'&&c[i]<='Z')
		b++;
	}
	if(a!=0&&b!=0)
	{
		
	}
	else
	{
		printf("NO");
	}
	
	return 0;
}
