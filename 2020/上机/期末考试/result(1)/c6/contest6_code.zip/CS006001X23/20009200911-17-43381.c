#include<stdio.h>
int m;
	scanf("%d",&m);
	int n[m][m],i=0,j=0,a=1;
	for(i=0;i<m;i++);
	{
		for(j=0;j<m;j++)
		{
			n[i][j]=a;
			scanf("%d",&n[i][j]);
			a++;
		}
	}
	int wa[m/2][m/2]={0};
	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			w[i][j]=a+m*j;
			a++;
		}
	}
	int xa[m/2][m/2]={0};
	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			x[i][j]=a+m/2+m*j;
			a++;
		}
	}
	int ya[m/2][m/2]={0};
	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			y[i][j]=a+m*m/2+m*j;
			a++;
		}
	}
	int za[m/2][m/2]={0};
	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			z[i][j]=a+m*m/2+m/2+m*j;
			a++;
		}
	}
	printf("%d %d\n",ya[m/2][m/2],wa[m/2][m/2]);
	printf("%d %d\n",za[m/2][m/2],xa[m/2][m/2]);
	
	return 0;
}
