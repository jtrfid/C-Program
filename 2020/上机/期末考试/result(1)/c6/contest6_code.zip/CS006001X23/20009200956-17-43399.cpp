#include<stdio.h>
#include<string.h>
int main()
{
	int m,i,j,k,b,c,d;
	int a[10][10];
    scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}

	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			k=a[i][j];
			a[i][j]=a[i+m/2][j];
			b=a[i][j+m/2];
			a[i][j+m/2]=k;
			c=a[i+m/2][j+m/2];
			a[i+m/2][j+m/2]=b;
			a[i+m/2][j]=c;
			
		}
	}
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}
