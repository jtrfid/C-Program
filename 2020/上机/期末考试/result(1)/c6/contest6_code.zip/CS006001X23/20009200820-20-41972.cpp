#include <bits/stdc++.h>
using namespace std;
#define LL long long

int n;
string fid, lid, cur_id, cur_in, cur_out, 
    minin = "aa:aa:aa", maxout = "\0\0:\0\0:\0\0";

int main() {
	cin >> n;
	for(int i = 0; i < n; ++i) {
		cin >> cur_id >> cur_in >> cur_out;
		if(cur_in < minin) {
			fid = cur_id;
			minin = cur_in;
		}
		if(cur_out > maxout) {
			lid = cur_id;
			maxout = cur_out;
		}
	}
	cout << fid << ' ' << lid << endl;
	return 0;
}
