#include<stdio.h>
#include<string.h>
int main()
{
	int A=0,B=0,t=0;
	int num3=0,num4=0,num5=0;
	int i=0,j=0;
	scanf("%d%d",&A,&B);
	if(A>B)
	{
		t=A;
		A=B;
		B=A;
	}
	for(i=A;i<=B;i++)
	{
		if(i%3==0)
			num3++;
		if(i%4==0)
			num4++;
		if(i%5==0 && i%2!=0)
			num5++;
	}
	
	int a[3]={0},min=0;
	a[0]=num3;a[1]=num4;a[2]=num5;
	min=a[0];
	for(i=0;i<3;i++)
	{
		if(min>a[i])
			min=a[i];
	}
	printf("%d %d %d\n",num3,num4,num5);
	printf("%d",min);
	return 0;
}
