#include<stdio.h>
int main()
{ int m,a[20][20];
  scanf("%d",&m);
  int i,j;
  for(i=0;i<m;i++)
  { for(j=0;j<m;j++)
    {scanf("%d",&a[i][j]);
    }
  }
  int z=0,x=0;
  int b[20][20];
  int q[10][10],w[10][10],e[10][10],r[10][10];
  for(i=0;i<m/2;i++)
  {for(j=0;j<m/2;j++)
  { q[z][x]=a[i][j];
    x++;
    if(x==m/2) z++,x=0;
  }
  }
  z=0,x=0;
   for(i=0;i<m/2;i++)
  {for(j=m/2;j<m;j++)
  { w[z][x]=a[i][j];
    x++;
    if(x==m/2) z++,x=0;
  }
  }
  z=0,x=0;
  for(i=m/2;i<m;i++)
  {for(j=0;j<m/2;j++)
  { e[z][x]=a[i][j];
    x++;
    if(x==m/2) z++,x=0;
}
  }
  z=0,x=0;
  for(i=m/2;i<m;i++)
  {for(j=m/2;j<m;j++)
  { r[z][x]=a[i][j];
    x++;
    if(x==m/2) z++,x=0;
}
  }
  int c=0,v=0;
  for(i=0;i<m/2;i++)
  {for(j=0;j<m/2;j++)
  {b[i][j]=e[c][v];
    v++;
    if(v==m/2) v=0,c++;       //e
  }
  }
  c=0,v=0;
   for(i=0;i<m/2;i++)
  {for(j=m/2;j<m;j++)
  {b[i][j]=q[c][v];
    v++;
    if(v==m/2) v=0,c++;      //q
  }
  }
  c=0,v=0;
   for(i=m/2;i<m;i++)
  {for(j=0;j<m/2;j++)
  {b[i][j]=r[c][v];
    v++;
    if(v==m/2) v=0,c++;     //r
  }
  }
  c=0,v=0;
   for(i=m/2;i<m;i++)
  {for(j=m/2;j<m;j++)
  {b[i][j]=w[c][v];
    v++;
    if(v==m/2) v=0,c++;     //w
  }
  }
  for(i=0;i<m;i++)
  {for(j=0;j<m;j++)
  { printf("%d ",b[i][j]);
    if(j==m-1) printf("\n");
  }
  }
  return 0;
  }
