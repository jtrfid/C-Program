#include<algorithm>
#include<stdbool.h>
#include<memory.h>
#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>

using namespace std;

void divide(int m,int matrix[][10],int a[][5],int b[][5],int c[][5],int d[][5]);

int main(void){
	int m=0;
	int matrix[10][10]={0};
	int a[5][5]={0},b[5][5]={0},c[5][5]={0},d[5][5]={0};
	cin>>m;
	for(int i=0;i<m;i++){
		for(int j=0;j<m;j++){
			cin>>matrix[i][j];
		}
	}
	divide(m,matrix,a,b,c,d);
	/*
	int x=0,y=0;
	for(int i=0;i<m/2;i++){
		for(int j=0;j<m/2;j++){
			matrix[i][j]=c[x][y++];
		}
		x++;
	}
	x=0;
	y=0;
	for(int i=0;i<m/2;i++){
		for(int j=m/2;j<m;j++){
			matrix[i][j]=a[x][y++];
		}
		x++;
	}
	x=0;
	y=0;
	for(int i=m/2;i<m;i++){
		for(int j=0;j<m/2;j++){
			matrix[i][j]=d[x][y++];
		}
		x++;
	}
	x=0;
	y=0;
	for(int i=m/2;i<m;i++){
		for(int j=m/2;j<m;j++){
			matrix[i][j]=b[x][y++];
		}
		x++;
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<m;j++){
			printf("%d ",matrix[i][j]);
		}
		putchar('\n');
	}   cadb
	*/
	
	for(int i=0;i<m/2;i++){
		for(int j=0;j<m/2;j++){
			printf("%d ",c[i][j]);
		}
		for(int j=0;j<m/2;j++){
			printf("%d ",a[i][j]);
		}
		putchar('\n');
	}
	for(int i=0;i<m/2;i++){
		for(int j=0;j<m/2;j++){
			printf("%d ",d[i][j]);
		}
		for(int j=0;j<m/2;j++){
			printf("%d ",b[i][j]);
		}
		putchar('\n');
	}
	
	return 0;
}

void divide(int m,int matrix[][10],int a[][5],int b[][5],int c[][5],int d[][5]){
	for(int i=0;i<m/2;i++){
		for(int j=0;j<m/2;j++){
			a[i][j]=matrix[i][j];
		}
	}
	for(int i=0;i<m/2;i++){
		for(int j=m/2;j<m;j++){
			b[i][j-m/2]=matrix[i][j];
		}
	}
	for(int i=m/2;i<m;i++){
		for(int j=0;j<m/2;j++){
			c[i-m/2][j]=matrix[i][j];
		}
	}
	for(int i=m/2;i<m;i++){
		for(int j=m/2;j<m;j++){
			d[i-m/2][j-m/2]=matrix[i][j];
		}
	}
}
