#include<stdio.h>
int main()
{
	int n,m;
	int a[15][15],b[15][15];
	scanf("%d",&n);
	m=n/2;
	int i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
			b[i][j]=a[i][j];
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(i<m&j<m)
	        {
		        b[i][j]=a[i+m][j];
	        }
	        else if(i<m&j>=m)
	        {
	        	b[i][j]=a[i][j-m];
	        }
	        else if(i>=m&j<m)
	        {
	        	b[i][j]=a[i][j+m];
	        }
	        else if(i>=m&j>=m)
	        {
	        	b[i][j]=a[i-m][j];
	        }
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
}
