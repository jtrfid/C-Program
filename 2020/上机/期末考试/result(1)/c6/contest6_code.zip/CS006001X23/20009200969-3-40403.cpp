#include<stdio.h>
int main()
{
	int i,a,b,min,max,x=0,y=0,z=0,m,n;
	scanf("%d %d",&a,&b);
	max=(a>b)?a:b;min=(a<b)?a:b;
	for(i=min;i<=max;i++)
	if(i%3==0)x++;
	for(i=min;i<=max;i++)
	if(i%4==0)y++;
	for(i=min;i<=max;i++)
	if(i%5==0&&i%2==1)z++;
	m=(x<y)?x:y;
	n=(m<z)?x:z;
	printf("%d %d %d\n",x,y,z);
	printf("%d",n);
	return 0;
}
