#include<stdio.h>
int  main ()
{int a,b;
scanf("%d %d",&a,&b);
int x=0,y=0,z=0,s=10099090;
if(a>b)
{int tem;
tem=b;
b=a;
a=tem;
}
for(int i=a;i<=b;i++)
{if(i%3==0)
{x++;
}
if(i%4==0)
{y++;
}
if(i%5==0&&i%2!=0)
{z++;
}
}
if(x>y)
{s=y;
if(y>z)
{s=z;
}
if(z>y)
{s=y;
}
}
if(x<y)
{s=x;
if(x>z)
{s=z;
}
if(x<z)
{s=x;
}

}
printf("%d %d %d\n%d",x,y,z,s);
}
