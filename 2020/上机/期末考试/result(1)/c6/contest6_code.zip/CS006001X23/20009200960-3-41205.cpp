#include<stdio.h>
int main()
{int A,B,n[3]={0,0,0},i,a,b,c;
scanf("%d %d",&A,&B);
if(A>B) i=A,A=B,B=i;
for(i=A;i<=B;i++)
   {if(i%3==0) n[0]++;
   }
for(i=A;i<=B;i++)
   {if(i%4==0) n[1]++;
   }
for(i=A;i<=B;i++)
   {if(i%5==0&&i%2!=0) n[2]++;
   }
a=n[0],b=n[1],c=n[2];
if(n[0]<n[1]) i=n[1],n[1]=n[0],n[0]=i;
if(n[1]<n[2]) i=n[2],n[2]=n[1],n[1]=i;
printf("%d %d %d\n%d",a,b,c,n[2]);
return 0;
}
