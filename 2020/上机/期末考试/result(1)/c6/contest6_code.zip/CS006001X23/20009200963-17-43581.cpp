#include <stdio.h>

struct Tile {
	int a[7][7];
} tile[4][4];

int n, n2, t;

void outputLine(Tile ti, int row) {
	for (int i = 1; i <= n2; i++)
		printf("%d ", ti.a[row][i]);
}

int main() {
	scanf("%d", &n);
	int n2 = n / 2;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			scanf("%d", &t);
			if (i <= n2 && j <= n2) tile[1][2].a[i][j] = t;
			else if (i <= n2 && j > n2) tile[2][2].a[i][j - n2] = t;
			else if (i > n2 && j <= n2) tile[1][1].a[i - n2][j] = t;
			else if (i > n2 && j > n2) tile[2][1].a[i - n2][j - n2] = t;
		}
	}
	outputLine(tile[1][1], 1);
	for (int i = 1; i <= 2; i++) {
		for (int j = 1; j <= n2; j++) {
			for (int t = 1; t <= 2; t++) {
				for (int k = 1; k <= n2; k++)
					printf("%d ", tile[i][t].a[j][k]);
			}
			printf("\n");
		}
	}
	return 0;
}
