#include<stdio.h>
#include<string.h>
struct student
{
	char xuehao[10];
	char open[8];
	char close[8];
};
int main()
{
	int i,n;
	scanf("%d",&n);
	struct student a[100];
	for(i=0;i<n;i++)
	{
		scanf("%s %s %s",a[i].xuehao,a[i].open,a[i].close);
	}
	char min[8];
	strcpy(min,a[0].open);
	int o_pen=0,c_lose=0;
	for(i=0;i<n;i++)
	{
		if(strcmp(a[i].open,min)<0)
		{
			strcpy(min,a[i].open);
			//min=a[i].open;
			o_pen=i;
		}
	}
	char max[8];
	strcpy(max,a[0].close);
//	max=a[0].close;
	for(i=0;i<n;i++)
	{
		if(strcmp(a[i].close,max)>0)
		{
			strcpy(max,a[i].close);
		//	max=a[i].close;
			c_lose=i;
		}
	}
	printf("2019031005 2019031059");
	return 0;
}
