#include<stdio.h>
#include<string.h>
int main()
{
	char s[50];
	gets(s);
	int i=0;
	int sum=0;
	int count=0;
	int lenth=strlen(s);
	for(i=0;i<lenth;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			count=1;
			sum+=s[i]-'0';
		}
		else if(s[i]>='A'&&s[i]<='F')
		{
			count=1;
			sum+=s[i]-'A'+10;
		}
		else if(s[i]>='a'&&s[i]<='f')
		{
			count=1;
			sum+=s[i]-'a'+10;
		}
	}
	if(count==0)
	{
		printf("No");
	}
	else
	{
		printf("%d",sum);
	}
	return 0;
}
