#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

int main()
{
	char a[30]={0};
	int i=0,j=0,n=0;
	int sum=0;
	gets(a);
	n=strlen(a);
	for(i=0;i<n;i++)
	{
	
		if(a[i]=='0')
		{
			sum=sum+0;
		}
		else if(a[i]=='1')
		{
			sum=sum+1;
		}
		else if(a[i]=='2')
		{
			sum=sum+2;
		}
		else if(a[i]=='3')
		{
			sum=sum+3;
		}
		else if(a[i]=='4')
		{
			sum=sum+4;
		}
		else if(a[i]=='5')
		{
			sum=sum+5;
		}
		else if(a[i]=='6')
		{
			sum=sum+6;
		}
		else if(a[i]=='7')
		{
			sum=sum+7;
		}
		else if(a[i]=='8')
		{
			sum=sum+8;
		}
		else if(a[i]=='9')
		{
			sum=sum+9;
		}
		else if(a[i]=='A'||a[i]=='a')
		{
			sum=sum+10;
		}
		else if(a[i]=='B'||a[i]=='b')
		{
			sum=sum+11;
		}
		else if(a[i]=='C'||a[i]=='c')
		{
			sum=sum+12;
		}
		else if(a[i]=='D'||a[i]=='d')
		{
			sum=sum+13;
		}
		else if(a[i]=='E'||a[i]=='e')
		{
			sum=sum+14;
		}
		else if(a[i]=='F'||a[i]=='f')
		{
			sum=sum+15;
		}
	}
	if(sum>0)
	{
		printf("%d",sum);
	}
	else
	{
		printf("NO");
	}
}
