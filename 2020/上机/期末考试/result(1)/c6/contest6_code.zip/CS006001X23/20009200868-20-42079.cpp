#include<cstdio>
int a,b,c;
int mx=-1,mn=2147483640,ans1,ans2;
struct node
{
	char num[20];
	int s;
	int e;
}stu[250];
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",stu[i].num);
		scanf("%d:%d:%d",&a,&b,&c);
		stu[i].s=a*60*60+b*60+c;
		scanf("%d:%d:%d",&a,&b,&c);
		stu[i].e=a*60*60+b*60+c;
		if(stu[i].s<mn)
		{
			ans1=i;
			mn=stu[i].s;
		}
		if(stu[i].e>mx)
		{
			ans2=i;
			mx=stu[i].e;
		}
		//printf("\n%d %d %d",a,b,c);
	}
	printf("%s %s",stu[ans1].num,stu[ans2].num);
}
