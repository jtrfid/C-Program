#include<stdio.h>
int main()
{
	int i,j,m;
	int a[10][10],b[10][10];
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(i<m/2&&j<m/2)
			{
				b[i][j+2]=a[i][j];
			}
			else if(i<m/2&&j>=m/2)
			{
				b[i+2][j]=a[i][j];
			}
			else if(i>=m/2&&j<m/2)
			{
				b[i-2][j]=a[i][j];
			}
			else if(i>=m/2&&j>=m/2)
			{
				b[i][j-2]=a[i][j];
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
}
