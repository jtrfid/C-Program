#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int main(){
	int m,a[100][100],i,j,n,b[100][100]={0},count=0;
	scanf("%d",&m);
	n=m/2;
	
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i][j]=a[i+n][j];
		}
	}
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i][j+n]=a[i][j];
		}
	}
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i+n][j]=a[i+n][j+n];
		}
	}
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i+n][j+n]=a[i][j+n];
		}
	}
	
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			printf("%d",b[i][j]);
			count++;
			if(count%m==0){
				printf("\n");
			}
			else{
				printf(" ");
			}
		}
	}
	return 0;
}
