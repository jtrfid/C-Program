#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int i,j,first,last,N,stu[100],in1[100],in2[100],in3[100],out1[100],out2[100],out3[100],t1[100],t2[100];
	scanf("%d",&N);
	for(i=0;i<N;i++){
		scanf("%d %d:%d:%d %d:%d:%d",&stu[i],&in1[i],&in2[i],&in3[i],&out1[i],&out2[i],&out3[i]);
		t1[i]=in1[i]*60*60+in2[i]*60+in3[i];
		t2[i]=out1[i]*60*60+out2[i]*60+out3[i];
	}
	first=0;
	last=0;
	for(i=0;i<N;i++){
		if(t1[first]>t1[i])first=i;
		if(t2[last]<t2[i])last=i;
	}
	printf("%d %d",stu[first],stu[last]);
	
	return 0;
}
