#include<stdio.h>
#include<string.h>
int main(){
	char s[50];
	gets(s);
	int i,sum=0;
	for(i=0;i<strlen(s);i++){
		if(s[i]>='1'&&s[i]<='9') sum+=s[i];
		if(s[i]=='a'||s[i]=='A') sum+=10;
		if(s[i]=='b'||s[i]=='B') sum+=11;
		if(s[i]=='c'||s[i]=='C') sum+=12;
		if(s[i]=='d'||s[i]=='D') sum+=13;
		if(s[i]=='e'||s[i]=='E') sum+=14;
		if(s[i]=='f'||s[i]=='F') sum+=15;
	}
	printf("%d",sum);
	return 0;
}
