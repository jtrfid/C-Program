#include<stdio.h>
#include<string.h>

int main()
{
	int n;
	scanf("%d", &n);
	char str[10][100]={0}, start[10][100]={0}, end[10][100]={0};
	char record[10][100]={0};
	int k=0, t=0;
	for (int i=0;i<n;i++)
	{
		gets(str[i]);
		strncpy(record[i], str[i], 10);
	}
	for (int i=0;i<n;i++)
	{	
		int len=strlen(str[i]);
		for (int j=10;str[i][j]!=' ';j++)
		{
			start[i][k++]=str[i][j];
		}
		k=0;
		for (int j=20;str[i][j]!=0;j++)
		{
			end[i][t++]=str[i][j];
		}
		t=0;
	}
	for (int i=0;i<n;i++)
	{
		puts(end[i]);
		puts(start[i]);
	}		
}

