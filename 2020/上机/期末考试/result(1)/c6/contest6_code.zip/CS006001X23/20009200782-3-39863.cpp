#include<cstdio>
#define MIN(a,b) (a<b?a:b)
using namespace std;
int main(){
	int a,b;
	int ans1,ans2,ans3;
	scanf("%d%d",&a,&b);
	if(a>b){
		int tmp;
		tmp=a;
		a=b;
		b=tmp;
	}
	int i;
	ans1=ans2=ans3=0;
	for(i=a;i<=b;i++){
		if(!(i%3))++ans1;
		if(!(i%4))++ans2;
		if(!(i%5)&&(i%2))++ans3;
	}
	printf("%d %d %d\n",ans1,ans2,ans3);
	printf("%d",MIN(ans1,MIN(ans2,ans3)));
	return 0;
}
