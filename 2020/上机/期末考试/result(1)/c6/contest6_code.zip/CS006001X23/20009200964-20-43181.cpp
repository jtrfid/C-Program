#include<stdio.h>
typedef struct{
	char num[20];
	int sth;
	int stm;
	int sts;
	int stsum;
	int endh;
	int endm;
	int ends;
	int endsum;
}student;
int main(){
	student stu[101];
	int n,i,min,max;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s %d:%d:%d %d:%d:%d",&stu[i].num,&stu[i].sth,&stu[i].stm,&stu[i].sts,&stu[i].endh,&stu[i].endm,&stu[i].ends);
	}
	for(i=0;i<n;i++)
	{
		stu[i].stsum=stu[i].sth*60*60+stu[i].stm*60+stu[i].sts;
		stu[i].endsum=stu[i].endh*60*60+stu[i].endm*60+stu[i].ends;
	}
	min=stu[0].stsum;
	max=stu[0].endsum;
	for(i<0;i<n;i++)
	{
		if(stu[i].stsum<min)
		{
			min=stu[i].stsum;
		}
		if(stu[i].endsum>max)
		{
			max=stu[i].endsum;
		}
	}
	for(i=0;i<n;i++)
	{
		if(stu[i].stsum==min)
		{
			printf("%s ",stu[i].num);
		}
	}
	for(i=0;i<n;i++)
	{
		if(stu[i].endsum==max)
		{
			printf("%s",stu[i].num);
		}
	}
	return 0;
}
