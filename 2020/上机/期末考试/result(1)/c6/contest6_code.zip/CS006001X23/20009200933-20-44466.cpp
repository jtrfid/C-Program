#include<string.h>
#include<stdio.h>
int main(){
	int n,i,j,s,t;
	scanf("%d",&n);
	int q[n],r[n];
	char x[100][35]={0},a[30]={0};
	for(i=0;i<n;i++)gets(x[i]);
	for(i=0;i<n;i++){q[i]=(x[i][11]-48)*10*3600+(x[i][12]-48)*3600+(x[i][14]-48)*10*60+(x[i][15]-48)*60+(x[i][17]-48)*10+x[i][18]-48;
	r[i]=(x[i][20]-48)*10*3600+(x[i][21]-48)*3600+(x[i][23]-48)*10*60+(x[i][24]-48)*60+(x[i][26]-48)*10+x[i][27]-48;
	}
	for(i=1,t=0,s=q[0];i<n;i++){if(q[i]<s){t=i;s=q[i];
	}
	}
	strncpy(a,x[t],10);
	a[10]=' ';
	for(i=1,t=0,s=r[0];i<n;i++)if(r[i]>s){t=i;s=r[i];
	}
	strncpy(a,x[t],10);
	puts(a);
	return 0;
}
