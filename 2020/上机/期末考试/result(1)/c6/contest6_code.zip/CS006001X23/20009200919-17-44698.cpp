/*

    Name:Array.cpp
    	
    Author:Konoha Akari
    
    Date:2021/1/9
    
*/

#include<stdio.h>

int main()

{
	
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,x;
	
	scanf("%d\n%d %d %d %d\n%d %d %d %d\n%d %d %d %d\n%d %d %d %d",&x,&a,&b,&c,&d,&e,&f,&g,&h,&i,&j,&k,&l,&m,&n,&o,&p);
	
	printf("%d %d %d %d\n%d %d %d %d\n%d %d %d %d\n%d %d %d %d",i,j,a,b,m,n,e,f,k,l,c,d,o,p,g,h);
	
	return 0;
	
}
