#include<stdio.h>
#include<string.h>
int main(){
	int i,j,n;
	char a[100][100],b[100][100],c[100][100],d[100][100],str[100];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		gets(a[i]);
		getchar();
	}
	for(i=0;i<n;i++){
		for(j=0;j<8;j++){
			b[i][j]=a[i][j+11];
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<10;j++){
			c[i][j]=a[i][j];
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<8;j++){
			d[i][j]=a[i][j+20];
		}
	}
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1;j++){
		if(strcmp(b[j],b[j+1])>0)
		{
			strcpy(str,b[j]);
			strcpy(b[j],b[j+1]);
			strcpy(b[j+1],str);
			strcpy(str,c[j]);
			strcpy(c[j],c[j+1]);
			strcpy(c[j+1],str);
		}}
	}
	puts(c[0]);
	printf(" ");
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1;j++){
		if(strcmp(d[j],d[j+1])<0)
		{
			strcpy(str,d[j]);
			strcpy(d[j],d[j+1]);
			strcpy(d[j+1],str);
			strcpy(str,c[j]);
			strcpy(c[j],c[j+1]);
			strcpy(c[j+1],str);
		}}
	}
	puts(c[0]);
	return 0;
}
