#include<stdio.h>
#include<string.h>
int main()
{
	int i,sum=0,flag=0;
	char str[51]={0};
	scanf("%s",str);
	for(i=0;i<strlen(str);i++)
	{
		if(str[i]>='a' && str[i]<='z')
		{
			str[i]=str[i]-32;
		}
	}
	for(i=0;i<strlen(str);i++)
	{
		if(str[i]>='0' && str[i]<='9')
		{
			sum+=str[i]-'0';
			flag=1;
		}
		else if(str[i]>='A' && str[i]<='F')
		{
			sum+=str[i]-'A'+10;
			flag=1;
		}
	}
	if(flag)	printf("%d",sum);
	else	printf("NO");
	
	return 0;
}
