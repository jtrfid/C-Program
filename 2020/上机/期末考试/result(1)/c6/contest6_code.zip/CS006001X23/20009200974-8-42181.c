#include<stdio.h>
#include<string.h>
int main(){
	char s[50];
	gets(s);
	int i,sum,flag;
	for(i=0,sum=0,flag=0;s[i]!='\0';i++){
		if(s[i]>='0'&&s[i]<='9'){
		 sum+=s[i]-48;flag=1;}
		if(s[i]=='a'||s[i]=='A'){
		 sum+=10;flag=1;}
		if(s[i]=='b'||s[i]=='B'){
		 sum+=11;flag=1;}
		if(s[i]=='c'||s[i]=='C'){
		 sum+=12;flag=1;} 
		if(s[i]=='d'||s[i]=='D'){
		 sum+=13;flag=1;} 
		if(s[i]=='e'||s[i]=='E'){
		 sum+=14;flag=1;} 
		if(s[i]=='f'||s[i]=='F'){
		 sum+=15;
		 flag=1;} 
	}
	if(flag==1){
	printf("%d",sum);}
	else if(flag==0){
		printf("No");
	}
	return 0;
}
