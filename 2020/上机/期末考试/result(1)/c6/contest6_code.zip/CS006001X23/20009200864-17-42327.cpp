/*
*/
#include<stdio.h>

int main()
{
	int m=0;
	int a[11][11]={0};
	int v[6][6]={0};
	int n[6][6]={0};  //  1 2 
	int p[6][6]={0};  //  3 4
 	int q[6][6]={0};
	
	scanf("%d",&m);
	
	int i,j;
	int r,s;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	/////////////////////////////////////////////
	for(i=0,r=0;i<m/2;i++,r++)//////////1
	{
		for(j=0,s=0;j<m/2;j++,s++)
		{
			v[r][s]=a[i][j];
		}
	}
	
	for(i=0,r=0;i<m/2;i++,r++)////////////2
	{
		for(j=m/2,s=0;j<m;j++,s++)
		{
			n[r][s]=a[i][j];
		}
	}
	
	for(i=m/2,r=0;i<m;i++,r++)/////////////3
	{
		for(j=0,s=0;j<m/2;j++,s++)
		{
			p[r][s]=a[i][j];
		}
	}
	
	for(i=m/2,r=0;i<m;i++,r++)////////////4
	{
		for(j=m/2,s=0;j<m;j++,s++)
		{
			q[r][s]=a[i][j];
		}
	}
	//////////////////////////////
	for(i=0,r=0;i<m/2;i++,r++)
	{
		for(j=0,s=0;j<m/2;j++,s++)
		{
			a[i][j]=p[r][s];
		}
	}
	for(i=0,r=0;i<m/2;i++,r++)
	{
		for(j=m/2,s=0;j<m;j++,s++)
		{
			a[i][j]=v[r][s];
		}
	}
	for(i=m/2,r=0;i<m;i++,r++)
	{
		for(j=0,s=0;j<m/2;j++,s++)
		{
			a[i][j]=q[r][s];
		}
	}
	for(i=m/2,r=0;i<m;i++,r++)
	{
		for(j=m/2,s=0;j<m;j++,s++)
		{
			a[i][j]=n[r][s];
		}
	}
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
