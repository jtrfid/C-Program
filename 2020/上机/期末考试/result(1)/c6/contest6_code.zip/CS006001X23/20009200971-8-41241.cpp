#include<algorithm>
#include<stdbool.h>
#include<memory.h>
#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>

using namespace std;

void small(char str[]);
int translate(char ch);

int main(void){
	char str[55]={'0'};
	scanf("%s",str);
	int len=strlen(str),sum=0;
	int flag=-1;
	small(str);
	for(int i=0;i<len;i++){
		if((str[i]>='0'&&str[i]<='9')||(str[i]>='a'&&str[i]<='f')){
			flag=1;
		}else{
			break;
		}
	}
	if(flag==-1){
		cout<<"NO";
	}
	else if(flag==1){
		for(int i=0;i<len;i++){
			sum+=translate(str[i]);
		}
		cout<<sum;
	}
	return 0;
}

void small(char str[]){
	for(int i=0;i<strlen(str);i++){
		if(str[i]>='A'&&str[i]<='Z'){
			str[i]+=32;
		}else{
			continue;
		}
	}
}

int translate(char ch){
	int rtn=0;
	if(ch>='0'&&ch<='9'){
		rtn=ch-'0';
	}else{
		switch(ch){
			case 'a':rtn=10;break;
			case 'b':rtn=11;break;
			case 'c':rtn=12;break;
			case 'd':rtn=13;break;
			case 'e':rtn=14;break;
			case 'f':rtn=15;break;
			default:break;
		}
	}
	return rtn;
}
