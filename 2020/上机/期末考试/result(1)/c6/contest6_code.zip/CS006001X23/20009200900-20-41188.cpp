#include<stdio.h>
#include<string.h>
typedef struct{
	int num;
	char str1[10];
	char str2[10];
}stu;

int main()
{
	int n,i,j;
	char t[10];
	stu st[100],temp;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s %s",&st[i].num,&st[i].str1,&st[i].str2);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(strcmp(st[j].str1,st[j+1].str1)>0)
		    {
			    temp=st[j];
			    st[j]=st[j+1];
			    st[j+1]=temp;
			
		    }
		}
	}
	printf("%d ",st[0].num);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(strcmp(st[j].str2,st[j+1].str2)<0)
		    {
			    temp=st[j];
			    st[j]=st[j+1];
			    st[j+1]=temp;
			
		    }
		}
	}
	printf("%d ",st[0].num);
	return 0;
	
}
