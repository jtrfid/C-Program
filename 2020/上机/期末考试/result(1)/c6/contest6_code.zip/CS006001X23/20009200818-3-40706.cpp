#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int a,b;
	int temp=0;
	int x=0,y=0,z=0;
	int max=0,min=0;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}
	int i,j;
	for(i=min;i<=max;i++)
	{
		if(i%3==0)
		{
			x++;
		}
		if(i%4==0)
		{
			y++;
		}
		if(i%5==0&&i%2!=0)
		{
			z++;
		}
	}
	
	int t;
	if(x<y)
	{
		t=x;
	}
	else
	{
		t=y;
	}
	if(t<z)
	{
		t=z;
	}
	else
	{
		t=t;
	}
	printf("%d %d %d\n%d",x,y,z,t);
	return 0;
	
}
