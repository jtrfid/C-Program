#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <stdlib.h>

int main(){
	int i,j;
	int m;
	int data[10][10]={0};
	int array[10][10]={0};
	scanf("%d",&m);
	for(i=0;i<m;i++) 
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&data[i][j]);
		}
	}  //��ʼ�� 
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(i>=0&&i<m/2)
			{
				if(j>=0&&j<m/2)
				{
					array[i][j+2]=data[i][j];
				}
				else
				{
					array[i+2][j]=data[i][j];
				}
			}
			else
			{
				if(j>=0&&j<m/2)
				{
					array[i-2][j]=data[i][j];
				}
				else
				{
					array[i][j-2]=data[i][j];
				}
			}
		}
	}
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",array[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
