#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

int main()
{
	int m;
	int a[10][10]={0};
	int b[10][10]={0};
	scanf("%d\n",&m);
	int i=0,j=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(i<m/2&&j<m/2)
			{
				b[i][j+m/2]=a[i][j];
			}
			else if(i<m/2&&j>m/2)
			{
				b[i+m/2][j+m/2]=a[i][j];
			}
			else if(i>m/2&&j>m/2)
			{
				b[i][j-m/2]=a[i][j];
			}
			else if(i<m/2&&j<m/2)
			{
				b[i-m/2][j]=a[i][j];
			}
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d",b[i][j]);
		}
	}
	return 0;
}
