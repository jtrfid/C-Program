#include<stdio.h>
#include<string.h>
struct time
{
	char code[15];
	char start[15];
	char end[15];
};
int main()
{
	int N;
	scanf("%d",&N);
	struct time student[N];
	struct time temp;
	for(int i = 0; i < N; i++)
	{
		scanf("%s %s %s",student[i].code,student[i].start,student[i].end);
	}
	
	//����ʱ�� 
	for(int i = 0; i < N - 1; i++)
	{
		for(int j = 0; j < N - i - 1; j++)
		{
			if(strcmp (student[j].start , student[j+1].start) >= 0)
			{
				temp = student[j];
				student[j] = student[j+1];
				student[j+1] = temp;
			}
		}
	}
	
	printf("%s ",student[0].code);
	
		for(int i = 0; i < N - 1; i++)
	{
		for(int j = 0; j < N - i - 1; j++)
		{
			if(strcmp (student[j].end , student[j+1].end) <= 0)
			{
				temp = student[j];
				student[j] = student[j+1];
				student[j+1] = temp;
			}
		}
	}
	
	printf("%s",student[0].code);
	
	
	return 0;
}
