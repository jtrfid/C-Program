#include<stdio.h>
#include<string.h>
int main(){
	int s[10][10],k[10][10]={0},m,i,j,a,b;
	scanf("%d",&m);
	for(a=0;a<m;a++){
		for(b=0;b<m;b++){
			scanf("%d",&s[a][b]);
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			if(i<m/2&&j<m/2){
				k[i][j]=s[i+m/2][j];
			}
			if(i<m/2&&j>=m/2){
				k[i][j]=s[i][j-m/2];
			}
			if(i>=m/2&&j<m/2){
				k[i][j]=s[i][j+m/2];
			}
			if(i>=m/2&&j>=m/2){
				k[i][j]=s[i-m/2][j];
			}}}
	for(a=0;a<m;a++){
		puts("");
		for(b=0;b<m;b++){
			printf("%d ",k[a][b]);
		}}
	return 0;
}
