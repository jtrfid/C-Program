#include<stdio.h>
int main()
{
	int n,i,j,min,max,in=0,ax=0;
	scanf("%d",&n);
	char a[n][29];
	int time[n][2];
	for(i=0;i<n;i++)
	{
		for(j=0;j<29;j++)
		{
			scanf("%c",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		time[i][0]=a[i][12]*10*3600+a[i][13]*3600+a[i][15]*10*60+a[i][16]*60+a[i][18]*10+a[i][19];
		time[i][1]=a[i][21]*10*3600+a[i][22]*3600+a[i][24]*10*60+a[i][25]*60+a[i][27]*10+a[i][28]; 
	}
	min=time[0][0];
	max=time[0][1];
	for(i=1;i<n;i++)
	{
		if(time[i][0]<min)
		{
			min=time[i][0];
			in=i;
		}
		if(time[i][1]>max)
		{
			max=time[i][1];
			ax=i;
		}
	}
	for(i=1;i<11;i++)
	{
		printf("%c",a[in][i]);
	}
	printf(" ");
	for(i=1;i<11;i++)
	{
		printf("%c",a[ax][i]);
	}
	return 0;
}
