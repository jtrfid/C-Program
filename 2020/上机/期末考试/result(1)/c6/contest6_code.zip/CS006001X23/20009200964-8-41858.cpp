#include<stdio.h>
#include<string.h>
int main(){
	char str[51];
	gets(str);
	int flag=0;
	int sum=0;
	int len=strlen(str);
	for(int i=0;i<len;i++)
	{
		if((str[i]>='0'&&str[i]<='9')||(str[i]>='a'&&str[i]<'g')||(str[i]>='A'&&str[i]<'G'))
		{
			flag=1;
			if(str[i]>='0'&&str[i]<'9')
			{
				sum=sum+str[i]-'0';
			}
			else if(str[i]>='a'&&str[i]<'g')
			{
				sum=sum+str[i]-'a'+10;
			}
			else if(str[i]>='A'&&str[i]<'G')
			{
				sum=sum+str[i]-'A'+10;
			}
		}
	}
	if(flag==1)printf("%d",sum);
	else printf("no");
	return 0;
}
