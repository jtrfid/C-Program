/*

    Name:Control.cpp
    	
    Author:Konoha Akari
    
    Date:2021/1/9
    
*/

#include<stdio.h>

int main()

{
	
	int a1,a2,a3,b1,b2,b3,c1,c2,c3,d1,d2,d3,e1,e2,e3,f1,f2,f3,g1,g2,g3,x,y,z,max,min,mor,eve;
	
	scanf("%d\n%d %d:%d:%d %d:%d:%d\n%d %d:%d:%d %d:%d:%d\n%d %d:%d:%d %d:%d:%d",&x,&a1,&b1,&c1,&d1,&e1,&f1,&g1,&a2,&b2,&c2,&d2,&e2,&f2,&g2,&a3,&b3,&c3,&d3,&e3,&f3,&g3);
	
	y=b1<b2?b1:b2;
	
	min=y<b3?y:b3;
	
	if(min=b1)mor=a1;
	
	if(min=b2)mor=a2;
	
	if(min=b3)mor=a3;
	
	z=e1<e2?e1:e2;
	
	max=z<e3?z:e3;
	
	if(max=e1)eve=a1;
	
	if(max=e2)eve=a2;
	
	if(max=e3)eve=a3;
	
	printf("%d %d",mor,eve);
	
	return 0;
	
}
