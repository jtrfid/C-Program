#include <stdio.h>

int main() {
	int a = 0, b = 0, c = 0, m, n, max, min, i, d;
	scanf("%d %d", &m, &n);
	max = m > n ? m : n;
	min = m < n ? m : n;
	for (i = min; i <= max; i++) {
		if (i % 3 == 0)
			a++;
	}
	for (i = min; i <= max; i++) {
		if (i % 4 == 0)
			b++;
	}
	for (i = min; i <= max; i++) {
		if (i % 5 == 0 && i % 2 != 0)
			c++;
	}
	if (a < b) {
		d = a;
	} else {
		d = b;
	}
	if (d > c) {
		d = c;
	}
	printf("%d %d %d\n", a, b, c);
	printf("%d", d);
	return 0;
}