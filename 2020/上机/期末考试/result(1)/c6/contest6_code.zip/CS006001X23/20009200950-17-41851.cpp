#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	int a[m][m],b[m][m];
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<m;j++)
		{
			if(i<m/2&&j<m/2)
			b[i][j+2]=a[i][j];
			if(i>=m/2&&j<m/2)
			b[i-2][j]=a[i][j];
			if(i<m/2&&j>=m/2)
			b[i+2][j]=a[i][j];
			if(i>=m/2&&j>=m/2)
			b[i][j-2]=a[i][j];
		}
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
}

