#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	char a[50]={0};
	gets(a);
	int i=0,j=0,k=1;
	int sum=0;
	for(i=0;i<strlen(a);i++)
	{
		if((a[i]>='0'&&a[i]<'9')||(a[i]>'A'&&a[i]<'F'))
		{
			j=0;
			k=1;
		while(k!=0){
				sum+=(a[i]-'0')*pow(16,j);
		k=(a[i]-'0')/10;
		j++;
		}
	}
}
	if(sum==0)
	printf("NO");
	else
	printf("%d",sum);
	
	
	
	return 0;
}

