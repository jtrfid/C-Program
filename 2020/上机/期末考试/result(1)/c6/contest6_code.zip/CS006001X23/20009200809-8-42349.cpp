#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main()
{
	char str[100]={0};
	gets(str);
	int sum=0, flag=0;
	for (int i=0;str[i];i++)
	{
		if (str[i]>='a'&&str[i]<='z'){
		
		str[i]=str[i]-32;}
	}
//	puts(str);
	for (int i=0;str[i];i++)
	{
		if(str[i]>='0'||str[i]<='9'||str[i]>='A'||str[i]<='F')
		
		
			if (str[i]<='9'&&str[i]>='0')
			{
				sum=sum+(str[i]-'0');
				printf("%d\n", sum);
				flag++;
			}
			else if (str[i]>='A'&&str[i]<='F')
			{
				sum=sum+(str[i]-55);
					printf("%d\n", sum);
					flag++;
			}
		
	}
	if(flag==0)
	{
		printf("NO");
	}
	else
	{
		printf("%d", sum);
	}
	
}
