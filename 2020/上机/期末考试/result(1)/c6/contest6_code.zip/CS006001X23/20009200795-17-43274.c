#include<stdio.h>
int main()
{
	int a,i,j,half;
	scanf("%d",&a);
	int b[a][a];
	int c[a][a];
	for(i=0;i<a;i++)
	{
		for(j=0;j<a;j++)
		{
			scanf("%d",&b[i][j]);
			c[i][j]=b[i][j];
		}
	}
	half=a/2-1;
	for(i=0;i<=half;i++)
	{
		for(j=0;j<=half;j++)
		{
			b[i][j]=c[i+half+1][j];
		}
	}//���Ͻ� 
	for(i=0;i<=half;i++)
	{
		for(j=half+1;j<a;j++)
		{
			b[i][j]=c[i][j-half-1];
		}
	}//���Ͻ�
	for(i=half+1;i<a;i++)
	{
		for(j=0;j<=half;j++)
		{
			b[i][j]=c[i][j+half+1];
		}
	} //���½�
	for(i=half+1;i<a;i++)
	{
		for(j=half+1;j<a;j++)
		{
			b[i][j]=c[i-half-1][j];
		}
	} //���½� 
	for(i=0;i<a;i++)
	{
		for(j=0;j<a;j++)
		{
			
			if(j!=a-1)
			{
				printf("%d ",b[i][j]);
			}else
			{
				printf("%d\n",b[i][j]);
			}
		}
	}
	return 0;
}
