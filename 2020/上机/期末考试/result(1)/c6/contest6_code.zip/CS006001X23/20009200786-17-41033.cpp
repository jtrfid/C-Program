#include <stdio.h>

	int main()
{
	int i,j,m,n,sz[11][11],s_1[10][10],s_2[10][10],s_3[10][10],s_4[10][10];
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&sz[i][j]);
		}
	}
	n=m/2;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			s_1[i][j]=sz[i][j];
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=n;j<m;j++)
		{
			s_2[i][j-n]=sz[i][j];
		}
	}
	for(i=n;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			s_3[i-n][j]=sz[i][j];
		}
	}
		for(i=n;i<m;i++)
	{
		for(j=n;j<m;j++)
		{
			s_4[i-n][j-n]=sz[i][j];
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",s_3[i][j]);
		}
		for(j=0;j<n;j++)
		{
			printf("%d ",s_1[i][j]);
		}
		printf("\n");
	}
		for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",s_4[i][j]);
		}
		for(j=0;j<n;j++)
		{
			printf("%d ",s_2[i][j]);
		}
		printf("\n");
	}
	
	
	
	
	
}

