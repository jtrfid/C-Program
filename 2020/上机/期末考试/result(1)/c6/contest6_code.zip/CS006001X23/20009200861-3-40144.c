#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int main(){
	int a,b,sum1=0,sum2=0,sum3=0,i,t,min=0;
	scanf("%d%d",&a,&b);
	if(a>b){
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++){
		if(i%3==0){
			sum1++;
		}
		if(i%4==0){
			sum2++;
		}
		if(i%5==0&&i%2!=0){
			sum3++;
		}
	}
	min=sum1;
	if(sum2<min){
		min=sum2;
	}
	if(sum3<min){
		min=sum3;
	}
	printf("%d %d %d\n%d",sum1,sum2,sum3,min);
	
	
	return 0;
}
