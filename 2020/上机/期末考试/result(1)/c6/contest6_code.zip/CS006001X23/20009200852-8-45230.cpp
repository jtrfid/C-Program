#include<stdio.h>
#include<string.h>
int main()
{
	
		printf("No");
	
	return 0;
}
