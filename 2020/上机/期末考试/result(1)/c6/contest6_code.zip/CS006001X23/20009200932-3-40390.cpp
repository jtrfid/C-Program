#include<stdio.h>
int main()
{
	int A,B;
	int a=0,b=0,c=0;
	int i=0,j=0;
	scanf("%d %d",&A,&B);
	if(A>B)
	{
		j=A;
		A=B;
		B=j;
	}
	for(i=A;i<=B;i++)
	{
		if(i%3==0)
		{
			a++;
		}
		if(i%4==0)
		{
			b++;
		}
		if(i%5==0&&i%2!=0)
		{
			c++;
		}
	}
	int min=a;
	if(b<a)
	{
		min=b;
	}
	if(c<min)
	{
		min=c;
	}
	printf("%d %d %d\n",a,b,c);
	printf("%d",min);
	return 0;
}
