#include<stdio.h>
#include<string.h> 
int main()
{
	char s[51], *p = s;
	int  sum = 0, book = 0;
	
	gets(s);
	
	while(*p)
	{
		if(*p >= '0' && *p <= '9')
		{
			sum += *p - '0';
			book = 1;
		}	
			
		else		
		{
			switch(*p)
			{
				case 'a': sum += 10; break;
				case 'b': sum += 11; break;
				case 'c': sum += 12; break;
				case 'd': sum += 13; break;
				case 'e': sum += 14; break;
				case 'f': sum += 15; break;
				
				case 'A': sum += 10; break;
				case 'B': sum += 11; break;
				case 'C': sum += 12; break;
				case 'D': sum += 13; break;
				case 'E': sum += 14; break;
				case 'F': sum += 15; break;
			}
			book = 1;
		}	
		p ++;
	}
	
	if(book == 0)
		printf("NO");
	else
		printf("%d", sum);
	

	return 0;
}
