#include<bits/stdc++.h>

typedef struct{
	char num[15];
	int start;
	int end;
}Stu;

int main()
{
	Stu stu[101];
	char starts[10] = {0},ends[10] = {0};
	int n,i,index1,index2;
	
	scanf("%d",&n);
	for(i = 0;i < n;i++)
	{
		scanf("%s %s %s",stu[i].num,starts,ends);
		
		stu[i].start = ( (starts[0]-'0')*10 + starts[1]-'0') *3600 +  ( (starts[3]-'0')*10 + starts[4]-'0')*60 + (starts[6]-'0')*10 + starts[7]-'0';
		stu[i].end = ( (ends[0]-'0')*10 + ends[1]-'0')*3600 +  ( (ends[3]-'0')*10 + ends[4]-'0')*60 + (ends[6]-'0')*10 + ends[7]-'0';          
	}
	
	index1 = 0;
	index2 = 0;
	for(i = 1;i < n;i++)
	{
		if(stu[index1].start > stu[i].start) index1 = i;
		if(stu[index2].end < stu[i].end) index2 = i;
	}
	
	printf("%s %s",stu[index1].num,stu[index2].num);
	
	return 0;
}
