#include<stdio.h>
#include<string.h>
int main(){
	char s[50];
	gets(s);
	int i,sum=0,flag=0;
	for(i=0;i!='\0';i++){
		if(s[i]>='1'&&s[i]<='9') sum+=s[i];flag=1;
		if(s[i]=='a'||s[i]=='A') sum+=10;flag=1;
		if(s[i]=='b'||s[i]=='B') sum+=11;flag=1;
		if(s[i]=='c'||s[i]=='C') sum+=12;flag=1;
		if(s[i]=='d'||s[i]=='D') sum+=13;flag=1;
		if(s[i]=='e'||s[i]=='E') sum+=14;flag=1;
		if(s[i]=='f'||s[i]=='F') sum+=15;flag=1;
	}
	if(flag){
	printf("%d",sum);}
	else{
		printf("No");
	}
	return 0;
}
