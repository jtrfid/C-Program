#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int m,n,i,j;
	m=0;
	n=0;
	scanf("%d",&m);
	n=m/2;
	int a[10][10],b[10][10];
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i][j]=a[i+n][j];
		}
		for(j=n;j<m;j++){
			b[i][j]=a[i][j-n];
		}
	}
	for(i=n;i<m;i++){
		for(j=0;j<n;j++){
			b[i][j]=a[i][j+n];
		}
		for(j=n;j<m;j++){
			b[i][j]=a[i-n][j];
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			printf("%d",b[i][j]);
		}
	}
	return 0;
}
