#include<stdio.h>
int main(){
int m,n,max,min,shu1=0,shu2=0,shu3=0;
scanf("%d %d",&m,&n);
if(m>n) 
{
max=m;
min=n;}
else {max=n;
min=m;
}
for(int i=min;i<=max;i++)
{if(i%3==0) shu1++;
if(i%4==0) shu2++;
if(i%5==0&&i%2!=0) shu3++;
} 
printf("%d ",shu1);	
printf("%d ",shu2);		
printf("%d ",shu3);		
printf("\n");
if(shu1<shu2&&shu1<shu3) printf("%d",shu1);	
if(shu2<shu1&&shu2<shu3) printf("%d",shu2);		
if(shu3<shu2&&shu3<shu1) printf("%d",shu3);	
return 0;	
}
