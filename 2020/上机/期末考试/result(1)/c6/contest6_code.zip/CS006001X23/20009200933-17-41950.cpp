#include<stdio.h>
int main(){
	int m,i,j;
	scanf("%d\n",&m);
	int a[m][m],b[m][m];
	for(i=0;i<m;i++)for(j=0;j<m;j++)scanf("%d",&a[i][j]);
	for(i=0;i<m/2;i++)for(j=0;j<m/2;j++){
		b[i][j+m/2]=a[i][j];
	}
	for(i=0;i<m/2;i++)for(j=m/2;j<m;j++)b[i+m/2][j]=a[i][j];
	for(i=m/2;i<m;i++)for(j=m/2;j<m;j++)b[i][j-m/2]=a[i][j];
	for(i=m/2;i<m;i++)for(j=0;j<m/2;j++)b[i-m/2][j]=a[i][j];
	for(i=0;i<m;i++){for(j=0;j<m;j++)printf("%d ",a[i][j]);
	printf("\n");
	}
	return 0;
}
