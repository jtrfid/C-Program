/*

    Name:Number Counting.cpp
    	
    Author:Konoha Akari
    
    Date:2021/1/9
    
*/

#include<stdio.h>

int main()

{
	
	int a,b,c,d,max,min,i,j,k,l,m,n;
	
	scanf("%d %d",&a,&b);
	
	max=a>b?a:b;
	
	min=a<b?a:b;
	
	for(i=0,l=min;l<=max&&l>=min;l++)
		
		{if(l%3==0)i++;}
		
	for(j=0,m=min;m<=max&&m>=min;m++)
		
		{if(m%4==0)j++;}
		
	for(k=0,n=min;n<=max&&n>=min;n++)
		
		{if(n%5==0&&n%2==1)k++;}
		
	c=i<j?i:j;
	
	d=c<k?c:k;
	
	printf("%d %d %d\n%d",i,j,k,d);
	
	return 0;
	
}
