#include<stdio.h>
#include<string.h>

int main(){
	char ch[50];
	int i,sum=0;
	gets(ch);
	
	printf("No");
	return 0;
}
