#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <stdlib.h>

int main(){
	char str[50]={0};
	gets(str);
	int sum=0;  //��ʼ�� 
	
	int i;
	for(i=0;i<strlen(str);i++)
	{
		if(str[i]>='0'&&str[i]<='9')  sum+=str[i]-'0';
		else if(str[i]>='A'&&str[i]<='F')
		{
			switch(str[i])
			{
				case 'A':
					sum+=10;
					break; 
				case 'B':
					sum+=11;
					break;
				case 'C':
					sum+=12;
					break;
				case 'D':
					sum+=13;
					break;
				case 'E':
					sum+=14;
					break;
				case 'F':
					sum+=15;
					break;
				default:
					break;
			}
		}
		else if(str[i]>='a'&&str[i]<='f')
		{
			switch(str[i])
			{
				case 'a':
					sum+=10;
					break; 
				case 'b':
					sum+=11;
					break;
				case 'c':
					sum+=12;
					break;
				case 'd':
					sum+=13;
					break;
				case 'e':
					sum+=14;
					break;
				case 'f':
					sum+=15;
					break;
				default:
					break;
			}
		}
	}
	
	if(sum)  printf("%d",sum);
	else  printf("NO");
	
	return 0;
}
