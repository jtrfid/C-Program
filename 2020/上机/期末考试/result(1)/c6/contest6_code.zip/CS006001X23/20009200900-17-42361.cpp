#include<stdio.h>
int main()
{
	int m,i,j,k,a[10][10]={0};
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	k=0;
	while(k<m/2)
	{
		for(j=0;j<m/2;j++)
	    {
		printf("%d ",a[m/2+k][j]);
    	}
    	for(j=0;j<m/2;j++)
    	{
		printf("%d ",a[0+k][j]);
    	}
    	printf("\n");
    	k++;
	}
	k=0;
	while(k<m/2)
	{
		for(j=m/2;j<m;j++)
	    {
		printf("%d ",a[m/2+k][j]);
    	}
    	for(j=m/2;j<m;j++)
    	{
		printf("%d ",a[0+k][j]);
    	}
    	printf("\n");
    	k++;
	}
	return 0;
	
	
	
}
