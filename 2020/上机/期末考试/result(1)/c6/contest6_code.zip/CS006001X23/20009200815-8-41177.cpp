#include<stdio.h>
#include<string.h>
int main()
{
	char a[100]={'\0'};
	gets(a);
	int n=strlen(a);
	int sum=0;
	for(int i=0;i<n;i++)
	{
		if(a[i]>='0'&&a[i]<='9')
		{
			sum+=a[i]-'0';
		}
		else if(a[i]=='A'||a[i]=='a')
		{
			sum+=10;
		}
		else if(a[i]=='B'||a[i]=='b')
		{
			sum+=11;
		}
		else if(a[i]=='C'||a[i]=='c')
		{
			sum+=12;
		}
		else if(a[i]=='D'||a[i]=='d')
		{
			sum+=13;
		}
		else if(a[i]=='E'||a[i]=='e')
		{
			sum+=14;
		}
		else if(a[i]=='F'||a[i]=='f')
		{
			sum+=15;
		}
		else{
			sum+=0;
		}
	}
	if(sum==0)
	{
		printf("NO");
	}
	else
	{
		printf("%d",sum);
	}
	return 0;
}
