#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	int num[m][m];
	int True[m][m];
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < m; j++)
		{
			scanf("%d",&num[i][j]);
		}
	}
	
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < m; j++)
		{
			if(i <= m/2-1 && j <= m/2-1)
			True[i][j+m/2] = num[i][j];
			else if(i > m/2-1 && j <= m/2-1)
			True[i-m/2][j] = num[i][j];
			else if(i <= m/2-1 && j > m/2-1)
			True[i+m/2][j] = num[i][j];
			else
			True[i][j-m/2] = num[i][j];
		}
	}
	
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < m; j++)
		{
			printf("%d ",True[i][j]);
		}
		printf("\n");
	}
	
	return 0;
	
}
