#include<cstdio>
#define N 20 
using namespace std;
int a[N][N]={0};
int b[N][N]={0};
int main(){
	int m;
	scanf("%d",&m);
	int i,j;
	for(i=0;i<m;i++)
		for(j=0;j<m;j++)
			scanf("%d",&a[i][j]);
	int mid=m/2;
	for(i=0;i<mid;i++){
		for(j=0;j<mid;j++){
			b[i][j+mid]=a[i][j];
		}
	}
	for(i=0;i<mid;i++){
		for(j=mid;j<m;j++){
			b[i+mid][j]=a[i][j];
		}
	}
	for(i=mid;i<m;i++){
		for(j=0;j<mid;j++){
			b[i-mid][j]=a[i][j];
		}
	}
	for(i=mid;i<m;i++){
		for(j=mid;j<m;j++){
			b[i][j-mid]=a[i][j];
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
}
