#include<stdio.h>
#include<string.h>
int main()
{
	int i,tmep=0,he=0,sum=0;
	char a[51]={0};
	gets(a);
	for(i=0;i<51;i++)
	{
		if(a[i]>=48&&a[i]<=57)
		{
			he=he+a[i]-48;
			sum=sum+1;
		}else if(a[i]>=97&&a[i]<=102)
		{
			he=he+a[i]-87;
			sum=sum+1;
		}else if(a[i]>=65&&a[i]<=70)
		{
			he=he+a[i]-55;
			sum=sum+1;
		}
	}
	if(sum!=0)
	{
		printf("%d",he);
	}else if(sum==0)
	{
		printf("NO");
	}
	return 0;
}
