#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

struct student{
	int n;
	int time1;
	int time2;
};

int main()
{
	int n=0;
	scanf("%d",&n);
	int i=0;
	student a[100];
	
	for(i=0;i<n;i++)
	{
		char tool1[12]={0};
		char tool2[12]={0};
		char n[10]={0};
		char t[10]={0};
		scanf("%d %s %s",&a[i].n,&tool1,&tool2);
		
		int j=0;
		int tool=0;
		for(j=0,tool=0;j<10;j++)
		{
			if(tool1[j]!=':')
			{
				n[tool]=tool1[j];\
				tool++;
			}
		}
		for(j=0,tool=0;j<10;j++)
		{
			if(tool2[j]!=':')
			{
				t[tool]=tool2[j];
				tool++;
			}
		}
		a[i].time1=atoi(n);
		a[i].time2=atoi(t);
	}
	
	int min=a[0].time1;
	int max=a[0].time2;
	int t1=0;
	int t2=0;
	for(i=0;i<n;i++)
	{
		if(min>a[i].time1)
		{
			min=a[i].time1;
			t1=i;
		}
	} 
		for(i=0;i<n;i++)
	{
		if(max<a[i].time2)
		{
			max=a[i].time2;
			t2=i;
		}
	} 
	
	printf("%d %d",a[t1].n,a[t2].n);
	
	return 0;
}
