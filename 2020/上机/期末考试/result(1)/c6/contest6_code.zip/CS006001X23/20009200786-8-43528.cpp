#include <stdio.h>
int main()
{
	char str[51]={0};
	gets(str);
	int sum=0,k=0;
	char *p=str;
	while(*p)
	{
		if(*p>='A'&&*p<='Z')
		{
			*p=*p+32;
		}
		if(*p<='9'&&*p>='0')
		{
			sum+=*p-'0';
			k++;
		}
		else if(*p>='a'&&*p<='f')
		{
			if(*p=='a')
			{
				sum+=10;
			}
			else if(*p=='b')
			{
				sum+=11;
			}
			else if(*p=='c')
			{
				sum+=12;
			}
			else if(*p=='d')
			{
				sum+=13;
			}
			else if(*p=='e')
			{
				sum+=14;
			}
			else if(*p=='f')
			{
				sum+=15;
			}
			k++;
		}	
	
		p++;
	}
	if(k==0)
	{
		printf("NO");
	}
	else
	{
		printf("%d",sum);
	}

}
