#include<bits/stdc++.h>
using namespace std;
struct x{
 int ans;
 char t1[9];
 char t2[9];
}a[46],tmp,tmp2;
int main(void)
{ int i,j,n;
  cin>>n;
  for(i=0;i<n;i++)
  {cin>>a[i].ans>>a[i].t1>>a[i].t2;}
  for(i=0;i<n;i++)
 { for(j=0;j<n-i-1;j++)
  {  if(strcmp(a[i].t1,a[i+1].t1)>0)
    {   tmp=a[i+1];
        a[i+1]=a[i];
        a[i]=tmp;
    }
  }
}
cout<<a[0].ans<<" ";
for(i=0;i<n;i++)
 { for(j=0;j<n-i-1;j++)
  {  if(strcmp(a[i].t2,a[i+1].t2)>0)
    {   tmp2=a[i+1];
        a[i+1]=a[i];
        a[i]=tmp2;
    }
  }
}
cout<<a[2].ans;
return 0;
}
