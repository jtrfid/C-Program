#include<stdio.h>
#include<string.h>
int main(){
	int a,b,n,t,three=0,four=0,five=0,s[2]={0};
	scanf("%d %d",&a,&b);
	if(a>b){
		t=a;
		a=b;
		b=t;
	}
	for(n=a;n<=b;n++){
		if(n%3==0){
			three++;
		}
		if(n%4==0){
			four++;
		}
		if(n%5==0){
			five++;
		}
	}
	s[0]=three;
	s[1]=four;
	s[2]=five;
	for(n=0;n<2;n++){
		for(t=n+1;t<2;t++){
			if(s[n]>s[t]){
				a=s[n];
				s[n]=s[t];
				s[t]=a;
			}
		}
	}
	printf("%d %d %d",three,four,five);
	return 0;
}
