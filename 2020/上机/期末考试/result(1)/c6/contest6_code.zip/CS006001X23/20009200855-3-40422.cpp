#include<stdio.h>
int main()
{ int A,B;
  scanf("%d%d",&A,&B);
  int min,max;
  min=A<B?A:B;
  max=A>B?A:B;
  int i,j=0,o=0,p=0;
  for(i=min;i<=max;i++)
  { int u=i%3;
    if(u==0) j++;
    int y=i%4;
    if(y==0) o++;
    int t=i%5,r=i%2;
    if(t==0&&r!=0) p++;
  }
  int sum1,sum2;
  sum1=j<o?j:o;
  sum2=sum1<p?sum1:p;
  printf("%d %d %d\n%d",j,o,p,sum2);
  return 0;
}
