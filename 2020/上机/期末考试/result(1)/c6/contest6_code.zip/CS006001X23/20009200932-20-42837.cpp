#include<stdio.h>
#include<string.h>
typedef struct
{
	char num[10];
	char time1[8];
	char time2[8];
}check;

int main()
{
	int n;
	scanf("%d",&n);
	check a[n];
	int i=0,j;
	check tmp={0,0,0};
	for(i=0;i<n;i++)
	{
		scanf("%s",a[i].num);
		scanf("%s",a[i].time1);
		scanf("%s",a[i].time2);
	}
	check em={0,0,0};
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(strcmp(a[i].time1,a[i+1].time1)>0)
			{
				tmp=a[i];
				a[i]=a[i+1];
				a[i+1]=	tmp;
			}
		}
	}
	printf("%s ",a[0].num);

	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(strcmp(a[i].time2,a[i+1].time2)>0)
			{
				em=a[i];
				a[i]=a[i+1];
				a[i+1]=em;
			}
		}
	}
	printf("%s",a[n-1].num);
	return 0;
}
