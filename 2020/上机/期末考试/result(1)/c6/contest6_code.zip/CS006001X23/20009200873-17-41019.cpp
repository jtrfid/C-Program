#include<bits/stdc++.h>


int main()
{
	int a[12][12] = {0},b[12][12] = {0};
	int m = 0,i = 0,j = 0;
	
	scanf("%d",&m);
	for(i = 0;i < m;i++)
	{
		for(j = 0;j < m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	
	for(i = 0;i < m;i++)
	{
		for(j = 0;j < m;j++)
		{
			if(i < m/2 && j<m/2)
			{
				b[i][m/2+j] = a[i][j];
			}
			if(i < m/2 && j>=m/2)
			{
				b[m/2+i][j] = a[i][j];
			}
			if(i >= m/2 && j<m/2)
			{
				b[i-m/2][j] = a[i][j];
			}
			if(i >= m/2 && j>=m/2)
			{
				b[i][j-m/2] = a[i][j];
			}
		}
	}
	
	for(i = 0;i < m;i++)
	{
		for(j = 0;j < m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	
	
	return 0;
}
