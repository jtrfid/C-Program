#include<stdio.h>
#include<string.h>

int main()
{
	int n;
	char a[50]={0};
	gets(a);
	int i=0;
	int sum=0;
	n=strlen(a);
	int flag=0;
	for(i=0;i<n;i++)
	{
		if(a[i]=='0')
		{
			sum=sum+0;
			flag=1;
		}
		else if(a[i]=='1')
		{
			sum=sum+1;
			flag=1;
		}
		else if(a[i]=='2')
		{
			sum=sum+2;
			flag=1;
		}
		else if(a[i]=='3')
		{
			sum=sum+3;
			flag=1;
		}
		else if(a[i]=='4')
		{
			sum=sum+4;
			flag=1;
		}
		else if(a[i]=='5')
		{
			sum=sum+5;
			flag=1;
		}
		else if(a[i]=='6')
		{
			sum=sum+6;
			flag=1;
		}
		else if(a[i]=='7')
		{
			sum=sum+7;
			flag=1;
		}
		else if(a[i]=='8')
		{
			sum=sum+8;
			flag=1;
		}
		else if(a[i]=='9')
		{
			sum=sum+0;
			flag=1;
		}
		else if(a[i]=='A'||a[i]=='a')
		{
			sum=sum+10;
			flag=1;
		}
		else if(a[i]=='B'||a[i]=='b')
		{
			sum=sum+11;
			flag=1;
		}
		else if(a[i]=='C'||a[i]=='c')
		{
			sum=sum+12;
			flag=1;
		}
		else if(a[i]=='D'||a[i]=='d')
		{
			sum=sum+13;
			flag=1;
		}
		else if(a[i]=='E'||a[i]=='e')
		{
			sum=sum+14;
			flag=1;
		}
		else if(a[i]=='F'||a[i]=='f')
		{
			sum=sum+15;
			flag=1;
		}
	}
	if(flag==1)
	{
		printf("%d",sum);
	}
	else
	{
		printf("NO");
	}
	return 0;
}
