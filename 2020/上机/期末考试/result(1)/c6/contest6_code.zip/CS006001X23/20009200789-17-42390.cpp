#include<stdio.h>
#include<string.h>

int main(){
	int m;
	scanf("%d",&m);
	int s[m][m],s1[m][m];
	int a,b,c,i,j;
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a);
			s[i][j]=a;
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			if(i<m/2&&j<m/2) s1[i][j+m/2]=s[i][j];
			if(i<m/2&&j>=m/2) s1[i+m/2][j]=s[i][j];
			if(i>=m/2&&j>=m/2) s1[i][j-m/2]=s[i][j];
			if(i>=m/2&&j<m/2) s1[i-m/2][j]=s[i][j];
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<m;j++){
			printf("%d ",s1[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
