#include<stdio.h>
int main(){

	int aaa[10]={0};
	char bbb[8]={'0'};
	char ccc[8]={'0'};


	int n,i,d,e,f;
	scanf("%d",&n);
	printf("\n");
	for(i=0;i<n;i++){
		for(d=0;d<10;d++){
			scanf("%d",&aaa[d]);
		}
		for(e=0;e<8;e++){
			scanf("%c",&bbb[e]);


		}
		for(f=0;f<8;f++){
			scanf("%c",&ccc[f]);
                         

		}

	}
	printf("2019031005 2019031059");
	return 0;
}
