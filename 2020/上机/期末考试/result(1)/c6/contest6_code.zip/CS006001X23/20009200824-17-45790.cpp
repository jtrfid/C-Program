#include<stdio.h>

int main()
{
	int n,i,j,k;
	int a[10][10];
	
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	
	
	
    for(i=n/2;i<n;i++)
	{
		for(k=0;k<n/2;k++)
		{
		for(j=0;j<n/2;j++)
	    {
		printf("%d",a[i][j]);
		}

		for(j=0;j<n/2;j++)
	    {
		printf("%d",a[k][j]);
		}
		 printf("\n");
		}
	   

	}
	
	
	for(i=n/2;i<n;i++)
	{
		for(k=0;k<n/2;k++)
		{
		for(j=n/2;j<n;j++)
	    {
		printf("%d",a[i][j]);
		}

		for(j=n/2;j<n;j++)
	    {
		printf("%d",a[k][j]);
		}
		printf("\n");
		}
	    

	}
	
   return 0;
}
