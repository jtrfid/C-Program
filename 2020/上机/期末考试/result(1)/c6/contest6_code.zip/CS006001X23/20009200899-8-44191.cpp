#include <stdio.h>
#include <string.h>
int main()
{
	char c[60];
	int i,len,count=0;
	gets(c);
	len=strlen(c);
	
	for(i=0;i<len;i++)
	{
		if(c[i]>='0'&&c[i]<='9')
		{
			count=count+(c[i]-'0');
		}
		else if(c[i]>='a'&&c[i]<='f'||c[i]>='A'&&c[i]<='F')
		{
			switch(c[i])
			{
				case 'a':
					count=count+10;
					break;
				case 'A':
					count=count+10;
					break;
				case 'b':
					count=count+11;
					break;
				case 'B':
					count=count+11;
					break;
				case 'c':
					count=count+12;
					break;
				case 'C':
					count=count+12;
					break;
				case 'd':
					count=count+13;
					break;
				case 'D':
					count=count+13;
					break;
				case 'e':
					count=count+14;
					break;
				case 'E':
					count=count+14;
					break;
				case 'f':
					count=count+15;
					break;
				case 'F':
					count=count+15;
					break;
				
			}
		}
	}
	if(count==0)
	{
		printf("NO");
		return 0;
	}
	else
	{
		printf("%d",count);
		return 0;
	}
}
