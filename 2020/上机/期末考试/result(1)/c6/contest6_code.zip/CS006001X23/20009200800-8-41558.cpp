#include<bits/stdc++.h>
using namespace std;

int main()
{
	char str[50];
	int num[50]={-1},k=0;
	gets(str);
	int lenth=strlen(str);
	for(int i=0;i<lenth;i++)
	{
		if(isdigit(str[i]))
		{
			num[k++]=str[i]-'0';
		}
		if(str[i]=='a'||str[i]=='A') num[k++]=10;
		if(str[i]=='b'||str[i]=='B') num[k++]=11;
		if(str[i]=='c'||str[i]=='C') num[k++]=12;
		if(str[i]=='d'||str[i]=='D') num[k++]=13;
		if(str[i]=='e'||str[i]=='E') num[k++]=14;
		if(str[i]=='f'||str[i]=='F') num[k++]=15;
	}
	int sum=0;
	for(int i=0;i<k;i++)
	{
		sum+=num[i];
	}
	if(num[0]!=-1) printf("%d",sum);
	if(num[0]==-1) printf("NO");
	return 0;	
}
