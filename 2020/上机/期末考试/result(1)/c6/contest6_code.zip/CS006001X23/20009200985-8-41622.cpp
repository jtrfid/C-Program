#include <stdio.h>
#include <string.h>

int main() {
	char a[50] = {0};
	scanf("%s", a);
	int i, n = 0, sum = 0;
	for (i = 0; i < 50; i++) {
		if (a[i] == '0') {
			sum += 0;
			n++;
		}
		if (a[i] == '1') {
			sum += 1;
			n++;
		}
		if (a[i] == '2') {
			sum += 2;
			n++;
		}
		if (a[i] == '3') {
			sum += 3;
			n++;
		}
		if (a[i] == '4') {
			sum += 4;
			n++;
		}
		if (a[i] == '5') {
			sum += 5;
			n++;
		}
		if (a[i] == '6') {
			sum += 6;
			n++;
		}
		if (a[i] == '7') {
			sum += 7;
			n++;
		}
		if (a[i] == '8') {
			sum += 8;
			n++;
		}
		if (a[i] == '9') {
			sum += 9;
			n++;
		}
		if (a[i] == 'A' || a[i] == 'a') {
			sum += 10;
			n++;
		}
		if (a[i] == 'B' || a[i] == 'b') {
			sum += 11;
			n++;
		}
		if (a[i] == 'C' || a[i] == 'c') {
			sum += 12;
			n++;
		}
		if (a[i] == 'D' || a[i] == 'd') {
			sum += 13;
			n++;
		}
		if (a[i] == 'E' || a[i] == 'e') {
			sum += 14;
			n++;
		}
		if (a[i] == 'F' || a[i] == 'f') {
			sum += 15;
			n++;
		}
	}
	if (n != 0) {
		printf("%d", sum);
	} else {
		printf("NO");
	}
	return 0;
}