#include<stdio.h>
int main()
{
	int a,b,i,t,n1=0,n2=0,n3=0,min;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	
	for(i=a;i<=b;i++)
	{
		if(i%3==0)
		{
			n1++;
		}
		if(i%4==0)
		{
			n2++;
		}
		if((i%5==0)&&(i%2!=0))
		{
			n3++;
		}
	}
	min=n1;
	if(n2<min)
	{
		min=n2;
	}
	if(n3<min)
	{
		min=n3;
	}
	printf("%d %d %d\n%d",n1,n2,n3,min);
	return 0;
}
