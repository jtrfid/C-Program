#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	char c[50]={0};
	int sum=0,i,flag=0;
	for(i=0;i<50;i++)
	{
		scanf("%c",&c[i]);
		if(c[i]!='\n')
		{
			if (c[i]>='0'&&c[i]<='9')
			{
				sum=sum+c[i]-48;
				flag=1;
			}
			else if(c[i]>='A'&&c[i]<='F')
			{
				sum=sum+c[i]-55;
				flag=1;
			}
			else if(c[i]>='a'&&c[i]<='f')
			{
				sum=sum+c[i]-87;
				flag=1;
			}
			else sum=sum;
		}
		else break;
		
	}
	if(sum==0&&flag==0)
	{
		printf("no");
	}
	else printf("%d",sum);
	return 0;
}
