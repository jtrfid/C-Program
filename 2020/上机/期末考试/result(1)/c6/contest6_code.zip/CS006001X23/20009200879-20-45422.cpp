#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
int main()
{
	char id[100][11]={0};
	char a[100][9]={0};
	char l[100][9]={0};
	
	int i=0,j=0,min=0,max=0,n=0;
	scanf("%d",&n);
	for (i=0;i<n;i++)
	{
		scanf("%s",id[i]);
		scanf("%s",a[i]);
		scanf("%s",l[i]);
	}
	
	double temp=0.0;
	
	for(i=0;i<n;i++)
	{
		temp=strcmp(a[min],a[i]);
		if(temp>0)
		{
			min=i;
		}
	}
	for(i=0;i<n;i++)
	{
		temp=strcmp(a[max],a[i]);
		if(temp<0)
		{
			max=i;
		}
	}
	printf("%s %s",id[min],id[max]);
	return 0;
}
