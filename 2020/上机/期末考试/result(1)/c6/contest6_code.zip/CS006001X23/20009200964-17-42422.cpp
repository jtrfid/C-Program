#include<stdio.h>
#include<string.h>
int main(){
	int a[11][11];
	int b1[11][11];
	int b2[11][11];
	int b3[11][11];
	int b4[11][11];
	int n,i,j,x,y,x1=0,x2=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(x1=n/2,x2=0;x1<n,x2<n/2;x1++,x2++)
	{
		for(y=0;y<n/2;y++)
		{
			printf("%d ",a[x1][y]);
		}
		for(y=0;y<n/2;y++)
		{
			printf("%d ",a[x2][y]);
		}
		printf("\n");
	}
	for(x1=n/2,x2=0;x1<n,x2<n/2;x1++,x2++)
	{
		for(y=n/2;y<n;y++)
		{
			printf("%d ",a[x1][y]);
		}
		for(y=n/2;y<n;y++)
		{
			printf("%d ",a[x2][y]);
		}
		printf("\n");
	}
	return 0;
}
