#include<stdio.h>
#include<string.h>
int main()
{
	char str[1000];
	int x[1000]={0};
	gets(str);
	int i=0,j=0,temp=0;
	int sum=0;
	int n=strlen(str);
	for(i=0;i<n;i++)
	{
		if(str[i]>=48&&str[i]<=57)
		{
			x[j]=str[i]-48;
			j++;
			temp=1;
		}
		if(str[i]>=65&&str[i]<=70)
		{
			x[j]=str[i]-55;
			j++;
			temp=1;
		}
		if(str[i]>=97&&str[i]<=102)
		{
			x[j]=str[i]-87;
			j++;
			temp=1;
		}
	}
	for(i=0;i<j;i++)
	{
		sum=sum+x[i];
	}
	if(temp==1)
	{
		printf("%d",sum);
	}
	else
	{
		printf("NO");
	}
}
