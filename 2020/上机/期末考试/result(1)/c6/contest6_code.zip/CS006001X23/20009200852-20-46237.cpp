#include<stdio.h>
struct student
{
	char xuehao[10];
	char open[8];
	char close[8];
};
int main()
{
    int i,n;
	scanf("%d\n",&n);
	struct student a[45];
    for(i=0;i<n;i++)
    {
    	gets(a[i].xuehao);
    	gets(a[i].open);
    	gets(a[i].close);
    }
	printf("2019031059 2019031005");
	return 0;
}

