#include <stdio.h>

int main() {
	int m, n, i, j;
	scanf("%d\n", &m);
	int a[m][m];
	int b[m / 2][m / 2];
	int c[m / 2][m / 2];
	int d[m / 2][m / 2];
	int e[m / 2][m / 2];
	int f[m][m];
	for (i = 0; i < m; i++) {
		if (i > 0)
			scanf("\n");
		for (j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			b[i][j] = a[i][j];
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			c[i][j] = a[i][j + m / 2];
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			d[i][j] = a[i + m / 2][j];
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			e[i][j] = a[i + m / 2][j + m / 2];
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			f[i][j] = d[i][j];
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			f[i][j + m / 2] = b[i][j];
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			f[i + m / 2][j] = e[i][j];
		}
	}
	for (i = 0; i < m / 2; i++) {
		for (j = 0; j < m / 2; j++) {
			f[i + m / 2][j + m / 2] = c[i][j];
		}
	}
	for (i = 0; i < m; i++) {
		if (i > 0)
			printf("\n");
		for (j = 0; j < m; j++) {
			printf("%d ", f[i][j]);
		}
	}
	return 0;
}