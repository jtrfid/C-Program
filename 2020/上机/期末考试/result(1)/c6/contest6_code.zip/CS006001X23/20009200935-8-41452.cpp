#include<stdio.h>
#include<string.h>
int main()
{
	char str[100];
	gets(str);
	int i,n,j=0,k=0;
	n=strlen(str);
	for(i=0;i<n;i++)
	{
		if(str[i]>=48&str[i]<=57)
		{
			j=j+str[i]-48;
			k=k+1;
		}
		else if(str[i]>=65&str[i]<=69)
		{
			j=j+str[i]-55;
			k=k+1;
		}
		else if(str[i]>=97&str[i]<=101)
		{
			j=j+str[i]-87;
		}
		else
		{
			i=i;
		}
	}
	if(k>0)
	{
		printf("%d",j);
	}
	else
	{
		printf("NO");
	}
	return 0;
	return 0;
}
