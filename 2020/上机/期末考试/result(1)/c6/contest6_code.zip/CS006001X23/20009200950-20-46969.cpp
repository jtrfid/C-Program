#include<stdio.h>
struct Com{
	int code;
	char coming_time[9];
	char leaving_time[9];
};
struct C_time{
	int hour;
	int min;
	int second;
};
struct L_time{
	int hour;
	int min;
	int second;
};
int main()
{
	int n;
	scanf("%d",&n);
	Com stu[n],temp;
	C_time p[n];
	L_time q[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d %s %s",&stu[i].code,stu[i].coming_time,stu[i].leaving_time);
	}
	for(int i=0;i<n;i++)
	{
		p[i].hour=(stu[i].coming_time[0]-48)*10+stu[i].coming_time[1]-48;
		p[i].min=(stu[i].coming_time[3]-48)*10+stu[i].coming_time[4]-48;
		p[i].second=(stu[i].coming_time[6]-48)*10+stu[i].coming_time[7]-48;
		q[i].hour=(stu[i].leaving_time[0]-48)*10+stu[i].leaving_time[1]-48;
		q[i].min=(stu[i].leaving_time[3]-48)*10+stu[i].leaving_time[4]-48;
		q[i].second=(stu[i].leaving_time[6]-48)*10+stu[i].leaving_time[7]-48;
	}
	//printf("%d \n%d \n%d",stu[1].code,p[0].hour,q[0].hour);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-2;j++)
		{
			if(p[j].hour>p[j+1].hour)
			{
				temp=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=temp;
			}
		}
	}
	printf("%d ",stu[0].code);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i;j++)
		{
			if(q[j].hour>q[j+1].hour)
			{
				temp=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=temp;
			}
		}
	}
	printf("%d ",stu[n-1].code);
	return 0;
}
