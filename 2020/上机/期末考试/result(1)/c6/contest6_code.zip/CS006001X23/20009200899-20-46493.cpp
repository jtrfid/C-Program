#include <stdio.h>
#include <string.h>
int main()
{
	int N,i,j,c[200],min,max,k,K,count[200];
	char a[200][30];
	scanf("%d\n",&N);
	for(i=0;i<N;i++)
	{
		gets(a[i]);
	}
	for(i=0;i<N;i++)
	{
		count[i]=(a[i][11]-'0')*10*10*10*10*10+(a[i][12]-'0')*10*10*10*10+(a[i][14]-'0')*10*10*10+(a[i][15]-'0')*10*10+(a[i][17]-'0')*10+(a[i][18]-'0');
		c[i]=(a[i][20]-'0')*10*10*10*10*10+(a[i][21]-'0')*10*10*10*10+(a[i][23]-'0')*10*10*10+(a[i][24]-'0')*10*10+(a[i][26]-'0')*10+(a[i][27]-'0');
	}
	for(i=0,min=count[0],k=0,max=c[0],K=0;i<N;i++)
	{
		if(min>count[i])
		{
			min=count[i];
			k=i;
		}
		if(max<c[i])
		{
			max=c[i];
			K=i;
		}
	}
	printf("%c%c%c%c%c%c%c%c%c%c %c%c%c%c%c%c%c%c%c%c",a[k][0],a[k][1],a[k][2],a[k][3],a[k][4],a[k][5],a[k][6],a[k][7],a[k][8],a[k][9],a[K][0],a[K][1],a[K][2],a[K][3],a[K][4],a[K][5],a[K][6],a[K][7],a[K][8],a[K][9]);
	return 0;
	
}
