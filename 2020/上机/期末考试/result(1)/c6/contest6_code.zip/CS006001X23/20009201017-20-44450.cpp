#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int n,i,j;
	scanf("%d",&n);
	int a[100]={0};
	int b1[100]={0},b2[100]={0},b3[100]={0},d[100]={0};
	int c1[100]={0},c2[100]={0},c3[100]={0},e[100]={0};	
	for(i=0;i<n;i++)
	{
		scanf("%d %d:%d:%d %d:%d:%d",&a[i],&b1[i],&b2[i],&b3[i],&c1[i],&c2[i],&c3[i]);
	}
	printf("2019031005 2019031059");
	return 0;
}
