#include<stdio.h>
int main()
{
	int i,j,n,a[255][255],b[255][255]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	for(j=0;j<n;j++)
	{
		scanf("%d",&a[i][j]);
	}	
	}
	
	
	for(i=0;i<n/2;i++)
	{
		for(j=0;j<n/2;j++)
		{
			b[i][j+n/2]=a[i][j];
		}
	}
	for(i=0;i<n/2;i++)
	{
		for(j=n/2;j<n;j++)
		{
			b[i+n/2][j]=a[i][j];
		}
	}
	for(i=n/2;i<n;i++)
	{
		for(j=n/2;j<n;j++)
		{
			b[i][j-n/2]=a[i][j];
		}
	}
	for(i=n/2;i<n;i++)
	{
		for(j=0;j<n/2;j++)
		{
			b[i-n/2][j]=a[i][j];
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
}
