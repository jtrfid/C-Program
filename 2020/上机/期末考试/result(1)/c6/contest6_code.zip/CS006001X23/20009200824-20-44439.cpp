#include<stdio.h>

int main()
{
   
    int n,i,j,temp;
    int num[100]={0},a[100],b[100],c[100],d[100],e[100],f[100],sum[100]={0};
    
    scanf("%d\n",&n);
    
    for(i=0;i<n;i++)
    {
    	scanf("%d %d:%d:%d %d:%d:%d",&num[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
    }
    
    for(i=0;i<n;i++)
    {
    	sum[i]=num[i];
    	
    } 
    for(i=0;i<n-1;i++)
    {
    	for(j=0;j<n-1-i;j++)
    	{
    		if(a[j]>a[j+1])
    		{
    		temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
            
            temp=num[j];
            num[j]=num[j+1];
            num[j+1]=temp;
    		}
    		
    	}
    }
    for(i=0;i<n-1;i++)
    {
    	for(j=0;j<n-1-i;j++)
    	{
    		if(d[j]<d[j+1])
    		{
    		temp=d[j];
            d[j]=d[j+1];
            d[j+1]=temp;
            
            temp=sum[j];
            sum[j]=sum[j+1];
            sum[j+1]=temp;
    		}
    		
    	}
    }
    
   printf("%d %d",num[0],sum[0]);
    
    return 0;

}
