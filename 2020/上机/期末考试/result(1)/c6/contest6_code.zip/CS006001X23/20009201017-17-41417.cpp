#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int m,i,j,s;
	scanf("%d",&m);
	int a[10][10]={0},b[10][10]={0};
	for(i=0;i<m;i++)
  {
	for(j=0;j<m;j++)
	{
		scanf("%d",&a[i][j]);
	}
  }
    s=m/2;
    for(i=0;i<s;i++)
    {
    	for(j=0;j<s;j++)
    	{
    		b[i][j+s]=a[i][j];
    	}
    }
    for(j=s;j<m;j++)
    {
    	for(i=0;i<s;i++)
    	{
    		b[i+s][j]=a[i][j];
    	}
    }
	for(i=s;i<m;i++)
    {
    	for(j=s;j<m;j++)
    	{
    		b[i][j-s]=a[i][j];
    	}
    }
    for(j=0;j<s;j++)
    {
    	for(i=s;i<m;i++)
    	{
    		b[i-s][j]=a[i][j];
    	}
    }
    
    for(i=0;i<m;i++)
{
	for(j=0;j<m;j++)
	{
		printf("%d ",b[i][j]);
	}
	printf("\n");
	
}
    return 0;
    
    
    
    
    
    
    
    
    
    
}
