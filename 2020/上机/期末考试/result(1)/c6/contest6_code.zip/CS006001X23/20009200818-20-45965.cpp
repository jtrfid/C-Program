#include<stdio.h>
#include<string.h>

typedef struct student
{
	int b;
	int c;
	int d;
	int e;
	int x;
	int y;
	int z;
}Stu[45];

int main()
{
	int n,i,j;
	scanf("%d\n",&n);
	student a[n];
	student ch;
	for(i=0;i<n;i++)
	{
		scanf("%d%d:%d:%d%d:%d:%d\n",&a[i].b,&a[i].c,&a[i].d,&a[i].e,&a[i].x,&a[i].y,&a[i].z);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(a[j].c>=a[j+1].c)
			{
					ch=a[j];
					a[j]=a[j+1];
					a[j+1]=ch;
			}
		}
	}
	printf("%d %d",a[0].b,a[n-1].b);
	
	return 0;
}
