#include<stdio.h>
#include<string.h>
int main()
{char a[51];
gets(a);
int sum=0,i,flag=0;
int length=strlen(a);
for(i=0;i<length;i++)
{if(a[i]>='0'&&a[i]<='9')
{
sum=sum+(a[i]-'0');
flag=1;
}
if(a[i]>='A'&&a[i]<'G')
{
sum=sum+(a[i]-55);
flag=1;}
if(a[i]>='a'&&a[i]<'g')
{
sum=sum+(a[i]-87);
flag=1;	
}}
if(flag!=0) printf("%d",sum);
else printf("NO");
return 0;
}
