#include<stdio.h>
#include<string.h>
int main()
{
	char str[60]={0};
	gets(str);
	int i=0,sum=0,flag=0;
	while(str[i]!='\0')
	{
	    if(str[i]>='0'&&str[i]<='9')
	    {
	    	flag=1;
	    	sum+=str[i]-48;
	    }
	    if((str[i]>='A'&&str[i]<='Z')||(str[i]>='a'&&str[i]<='z'))
	    {
	    	sum+=0;
	    }
	    else
	    {
	    	sum+=str[i]-48;
	    }
	    i++;
	}
	if(flag==1)
	{
		printf("%d",sum);
	}
	else
	{
		printf("NO");
	}
	return 0;
}
