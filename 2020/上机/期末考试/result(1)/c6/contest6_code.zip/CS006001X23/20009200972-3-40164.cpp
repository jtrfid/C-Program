#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<memory.h>
int main()
{
	int a,b;
	int a1=0,a2=0,a3=0;
	scanf("%d %d",&a,&b);
	int i=0;
	if(a>=b)
	{
		for(i=b;i<=a;i++)
		{
			if(i%3==0)
			{
				a1++;
			}
			if(i%4==0)
			{
				a2++;
			} 
			if(i%5==0&&i%2!=0)
			{
				a3++;
			}
		}
	
	}
	if(a<b)
	{
		for(i=a;i<=b;i++)
		{
			if(i%3==0)
			{
				a1++;
			}
			if(i%4==0)
			{
				a2++;
			} 
			if(i%5==0&&i%2!=0)
			{
				a3++;
			}
		}
	}
	int result=0;
	if(a1<=a2&&a1<=a3)
	{
		result=a1;
	}
	if(a2<=a1&&a2<=a3)
	{

	
		result=a2;
	}
	if(a3<=a2&&a3<=a1)
	{
		result=a3;
	}
	printf("%d %d %d\n%d",a1,a2,a3,result);
	return 0;
}
