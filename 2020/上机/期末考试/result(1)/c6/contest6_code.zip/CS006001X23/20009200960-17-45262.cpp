#include<stdio.h>
int main()
{int m,i,k,c;
scanf("%d",&m);
char n[m][m];
for(i=0;i<m;i++)
   {for(k=0;k<m;k++)
       {scanf("%d",&n[i][k]);
       }
   }
for(i=0;i<m/2;i++)
   {for(k=0;k<m/2;k++)
       {c=n[i][k];
        n[i][k]=n[i][k+m/2];
        n[i][k+m/2]=c;
       }
   }
for(i=0;i<m/2;i++)
   {for(k=0;k<m/2;k++)
       {c=n[i][k];
        n[i][k]=n[i+m/2][k+m/2];
        n[i+m/2][k+m/2]=c;
       }
   }
for(i=0;i<m/2;i++)
   {for(k=0;k<m/2;k++)
       {c=n[i][k];
        n[i][k]=n[i+m/2][k];
        n[i+m/2][k]=c;
       }
   }
for(i=0;i<m;i++)
   {for(k=0;k<m;k++)
       {printf("%d ",n[i][k]);
       }
    printf("\n");
   }
return 0;
}
