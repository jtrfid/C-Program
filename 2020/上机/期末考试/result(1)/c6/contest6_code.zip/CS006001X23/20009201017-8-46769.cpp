#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	char a[100];
	int n,s=0,i;
	gets(a);
	n=strlen(a);
	for(i=0;i<n;i++)
	{
		if(a[i]>='0'&&a[i]<='9')
		{
			s=s+a[i]-'0';
		}
		if(a[i]>='a'&&a[i]<='g')
		{
			s=s+a[i]-87;
		}
		if(a[i]>='A'&&a[i]<='G')
		{
			s=s+a[i]-55;
		}
	}
	if(s!=0)
	{
	
	printf("%d",s);
   }
   else
   {
   	printf("NO");
   	
   }
   return 0;
}
