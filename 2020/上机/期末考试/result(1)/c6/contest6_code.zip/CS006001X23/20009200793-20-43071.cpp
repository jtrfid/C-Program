#include<bits/stdc++.h>
using namespace std;
struct x{
 long long int ans;
 char t1[9];
 char t2[9];
}a[102],tmp,tmp2;
int main(void)
{ int i,j,n;
  cin>>n;
  for(i=0;i<n;i++)
  {cin>>a[i].ans>>a[i].t1>>a[i].t2;}
  for(i=0;i<n;i++)
 { for(j=0;j<n-i-1;j++)
  {  if(strcmp(a[j].t1,a[j+1].t1)>0)
    {   tmp=a[j+1];
        a[j+1]=a[j];
        a[j]=tmp;
    }
  }
}
cout<<a[0].ans<<" ";
for(i=0;i<n;i++)
 { for(j=0;j<n-i-1;j++)
  {  if(strcmp(a[j].t2,a[j+1].t2)>0)
    {   tmp2=a[j+1];
        a[j+1]=a[j];
        a[j]=tmp2;
    }
  }
}
cout<<a[2].ans;
return 0;
}
