#include <stdio.h>
#include <ctype.h>
#include <string.h>

int map[128], ans;
char str[55];
bool flag = false;

void init() {
	for (char i = '0'; i <= '9'; i++)
		map[i] = i - '0';
	for (char i = 'a'; i <= 'f'; i++)
		map[i] = i - 'a' + 10;
}

bool isHex(char c) {
	return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
}

int main() {
	init();
	gets(str);
	int len = strlen(str);
	for (int i = 0; i < len; i++) {
		char c = tolower(str[i]);
		if (isHex(c)) {
			ans += map[c];
			flag = true;
		}
	}
	if (flag) printf("%d\n", ans);
	else printf("NO\n");
	return 0;
}
