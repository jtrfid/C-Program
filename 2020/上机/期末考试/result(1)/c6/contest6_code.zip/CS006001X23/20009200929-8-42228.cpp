#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int i,n,flag=0,sum=0;
	char s[100]={'\0'};
	gets(s);
	for(i=0;s[i]!='\0';i++)
	{
		if(s[i]>='0'&&s[i]<='9'||s[i]>='a'&&s[i]<='f'||s[i]>='A'&&s[i]<='F')
		{
			if(s[i]>='0'&&s[i]<='9') sum=sum+s[i]-'0';
			if(s[i]>='a'&&s[i]<='f') sum=sum+10+s[i]-'a';
			if(s[i]>='A'&&s[i]<='F') sum=sum+10+s[i]-'A';
			flag=1;
		}
	}
	if(flag==0) printf("NO");
	else printf("%d",sum);
	
	
	system("pause");
	return 0;
}
