#include<stdio.h>
int main(){
	int a,b,c,i,j,k;
	scanf("%d %d",&a,&b);
	if(a>b){
		c=a;
		a=b;
		b=c;
	}
	int sum1=0,sum2=0,sum3=0;
	for(i=a;i<=b;i++){
		if(i%3==0){		
			sum1++;}
				}
	for(k=a;k<=b;k++){
		if(k%4==0){
		sum2++;	}
		}
    for(j=a;j<=b;j++){
	if(j%5==0&&j%2!=0){
	       	sum3++;}
		}   

	if(sum1<=sum2&&sum1<=sum3){
		printf("%d %d %d\n",sum1,sum2,sum3);
		printf("%d",sum1);
	}
	if(sum2<=sum1&&sum2<=sum3){
		printf("%d %d %d\n",sum1,sum2,sum3);
		printf("%d",sum2);
	}
	if(sum3<=sum1&&sum3<=sum2){
		printf("%d %d %d\n",sum1,sum2,sum3);
		printf("%d",sum3);
	}
	
	
	
	
	
	
	
	
	
	return 0;
}
