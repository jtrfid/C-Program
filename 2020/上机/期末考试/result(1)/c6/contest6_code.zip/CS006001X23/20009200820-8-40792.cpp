#include <bits/stdc++.h>
using namespace std;
#define LL long long

char buf[60];
int len, ans;
bool det;

int main() {
	gets(buf);
	len = strlen(buf);
	for(int i = 0; i < len; ++i) {
		if(isdigit(buf[i])) {
			ans += buf[i] - '0';
			det = true;	
		}else if(buf[i] >= 'a' && buf[i] <= 'f') {
			ans += buf[i] - 'a' + 10;
			det = true;	
		}else if(buf[i] >= 'A' && buf[i] <= 'F') {
			ans += buf[i] - 'A' + 10;
			det = true;
		}
	}
	if(det) {
		cout << ans;
	}else {
		cout << "NO";
	}
	cout << endl;
	return 0;
}
