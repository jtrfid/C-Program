#include<stdio.h>
#include<string.h>
typedef struct
{char xuehao[11]={0};
 char jin[9]={0};
 char chu[9]={0}; 
}jilu;

int main()
{int n;
jilu a[100],temp;
scanf("%d",&n);
for(int i=0;i<n;i++)
{scanf("%s %s %s",a[i].xuehao,a[i].jin,a[i].chu);	
}
for(int i=0;i<n-1;i++)
for(int j=0;j<n-1-i;j++)
{if(strcmp((a[i].jin),(a[i+1].jin))>0)
 {temp=a[i];
 a[i]=a[i+1];
 a[i+1]=temp;
 }	
}
printf("%s ",a[0].xuehao);
for(int i=0;i<n-1;i++)
for(int j=0;j<n-1-i;j++)
{if(strcmp((a[i].chu),(a[i+1].chu))>0)
 {temp=a[i];
 a[i]=a[i+1];
 a[i+1]=temp;
 }	
}
printf("%s",a[n-1].xuehao);
return 0;		
}
