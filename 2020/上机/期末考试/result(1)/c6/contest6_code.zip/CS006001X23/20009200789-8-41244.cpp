#include<stdio.h>
#include<string.h>

int main(){
	char s[100]={0};
	gets(s);
	int i,a=0,b,l=strlen(s),ans=0;
	for(i=0;i<l;i++){
		if(s[i]>='a'&&s[i]<='f') ans=ans+s[i]-87;
		else if(s[i]>='A'&&s[i]<='F') ans=ans+s[i]-55;
		else if(s[i]>=0&&s[i]<='9') ans=ans+s[i]-48;
 		else {
 			a++;
 		}
	}
	if(a==l){
		printf("No");
	}else {
		printf("%d",ans);
	}
	
	return 0;
}
