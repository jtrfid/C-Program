#include <bits/stdc++.h>
using namespace std;
#define LL long long

int a, b, ans3, ans4, ans5;

int main() {
	cin >> a >> b;
	if(a > b) swap(a, b);
	for(int i = a; i <= b; ++i) {
		if(!(i % 3)) ++ans3;
		if(!(i % 4)) ++ans4;
		if(!(i % 5) && (i & 1)) ++ans5;
	}
	cout << ans3 << ' ' << ans4 << ' ' << ans5 << endl;
	cout << min(ans3, min(ans4, ans5)) << endl;
	return 0;
}
