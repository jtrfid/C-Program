#include<stdio.h>
#include<string.h>

int main()
{
	char s[51]={0};
	scanf("%s",&s);
	int l=strlen(s);
	int sum=0,k=0;
	for(int i=0;i<l;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			sum+=s[i]-'0';k=k+1;
		}
		else if(s[i]=='a'||s[i]=='A')
		{
			sum=sum+10;k=k+1;
		}
		else if(s[i]=='b'||s[i]=='B')
		{
			sum=sum+11;k=k+1;
		}
		else if(s[i]=='c'||s[i]=='C')
		{
		sum=sum+12;k=k+1;}
		if(s[i]=='d'||s[i]=='D')
		{
		sum=sum+13;k=k+1;}
		if(s[i]=='e'||s[i]=='E')
		{
		sum=sum+14;k=k+1;}
		if(s[i]=='f'||s[i]=='F')
		{
		sum=sum+15;k=k+1;}
	}
	if(k>0)
	printf("%d",sum);
	else if(k==0)
	printf("NO");
	return 0;
}
