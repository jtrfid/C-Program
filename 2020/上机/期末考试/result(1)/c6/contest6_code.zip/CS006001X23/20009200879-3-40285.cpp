#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	
	int temp=0;
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	
	int i,s1=0,s2=0,s3=0;
	
	for(i=a;i<=b;i++)
	{
		if(i%3==0)
		s1++;
		if(i%4==0)
		s2++;
		if(i%5==0&&i%2!=0)
		s3++;
	}
	printf("%d %d %d",s1,s2,s3);
	printf("\n");
	
	int min=0;
	
	min=s1<s2?s1:s2;
	min=min<s3?min:s3;
	
	printf("%d",min);
	
	return 0;	
} 
