#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	int i,j;
	int a[10][10],b[10][10];
	for(i=0;i<m;i++)
	{
	    for(j=0;j<m;j++)
	    {
	    	scanf("%d",&a[i][j]);
	    }
	}
	
	for(i=0;i<m/2;i++)
	{
		for(j=0;j<m/2;j++)
		{
			b[i][j]=a[i+m/2][j];
		}
	}
	for(i=m/2;i<m;i++)
	{
		for(j=0;j<m/2;j++)
		{
			b[i][j]=a[i][j+m/2];
		}
	}
	for(i=0;i<m/2;i++)
	{
		for(j=m/2;j<m;j++)
		{
			b[i][j]=a[i][j-m/2];
		}
	}
	for(i=m/2;i<m;i++)
	{
		for(j=m/2;j<m;j++)
		{
			b[i][j]=a[i-m/2][j];
		}
	}
	int count=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(count==4)
			{
				printf("\n");
				count=0;
			}
			printf("%d ",b[i][j]);
			count++;
		}
	}
	return 0;
}
