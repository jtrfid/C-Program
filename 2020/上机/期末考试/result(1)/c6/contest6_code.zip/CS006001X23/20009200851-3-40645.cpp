#include<stdio.h>
int main()
{
	int a=0,b=0;
	scanf("%d %d",&a,&b);
	int i=0,j=0,x=0,y=0,q=0,w=0;
	if(a>b)
	{
		q=b;
		w=a;
	}
	else 
	{
		q=a;
		w=b;
	}
	for(i=q;i<=w;i++)
	{
		if(i%3==0)
		{
			j++;
		}
		if(i%4==0)
		{
			x++;
		}
		if(i%5==0&&i%2!=0)
		{
			y++;
		}
	}
	printf("%d %d %d",j,x,y);
	printf("\n");
	int c[3]={0};
	int r=0,t=0,k=0,g=0,h=0;
	c[0]=j;
	c[1]=x;
	c[2]=y;
	for(r=0;r<2;r++)
	{
		for(g=r+1,k=r;g<3;g++)
		{
			if(c[g]<c[k])
			{
				k=g;
			}
		}
		if(k!=r)
		{
			t=c[k];
			c[k]=c[r];
			c[r]=t;
		}
		printf("%d",c[0]);
		return 0;
	}
	
		
}
