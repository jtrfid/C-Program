#include<stdio.h>
int main()
{
	int x,a,b,m;
	scanf("%d",&x);
	m=x;a=0;b=9;
	for(;m>0;m=(int)m/10)
	{
	  	a=(m%10)>a?(m%10):a;
	  	b=(m%10)<b?(m%10):b;
	}
	printf("%d %d",a,b);
	return 0;
}
