#include<stdio.h>
#include<math.h>
int main(){
    float a,b,c,t,m,n;
    scanf("%f %f %f",&a,&b,&c);
    t=b*b-4*a*c;
    m=(-b+sqrt(t))/(2*a);
    n=(-b-sqrt(t))/(2*a);
	if(t>0){
    	printf("%.1f %.1f",m,n);
    }
    if(t==0){
    	printf("%.1f",m);
    }
    if(t<0)
	    printf("no");
	return 0;
}
