#include<stdio.h>
#include<math.h>
int main()
{
	long int i,a=0,n,d,b=2,y;

	scanf("%ld",&n);
	
for(d=3;d<n;d++){

	for(i=2;i<d;i++)//is d a su?
	{
		if(d%i==0)//d isn't su
		{b++;break;}
	};
	
}
y=n-b;
if(n==2)
y=1;
	printf("%ld",y);
	
	return 0;
}
