#include <stdio.h>

int main() {
    float a,b,c,x,y,z;
	scanf("%f %f %f",&a,&b,&c);
	z=b*b-4*a*c;
	if(z>0)  {x=(-b+z)/(2*a);y=(-b-z)/(2*a);}
	if(z==0) printf("%.1f",-b/2/a);
	   else if(z<0) printf("no");
	if (z>0)  printf("%.1f %.1f",x,y);
	return 0;
}

