#include <stdio.h>

int main()
{
	int n,i,j;
	int s=0,K,m;
	scanf("%d",&n);
	for(i=n;i>1;i--)
	{
		K=0;
		for(j=i-1;j>1;j--)
		{
			m=i%j;
			if(m!=0) K++;
		}
		if(K==i-2) s++;
	}
	printf("%d",s);
}
