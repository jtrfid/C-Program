#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int n,x,sum=0,i,j;
    scanf("%d",&n);
    for(j=1;j<n;j++)
    {
    	for(i=2;i<j;i++)
    	{
    		if(j%i==0)
    		{
    			x=1;
    			break;
    		}
    		else x=0;
    	}
    	if(x==0)sum++;
    	x=0;
    }
    printf("%d",sum);
    return 0;
}
