#include<stdio.h>
int main()
{int a,m=0,i;
scanf("%d",&a);
for(i=1;i<a;i++)
{if(a%i==0)
m=m+i;
}
printf("%d",m);
}
