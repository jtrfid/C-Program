#include<stdio.h>
#include<math.h>
int main ()
{
	double a,b,c,disc,p,q;
	scanf("%lf %lf %lf",&a,&b,&c);
	disc=b*b-4*a*c;
	p=-b/(2*a);
	q=sqrt(disc)/(2*a);
	if(disc<0)
	 printf("no");
	else if(disc==0)
	 printf("%.1f",p);
	else if(disc>0)
	 printf("%.1f %.1f",p+q,p-q);
	return 0;
}
