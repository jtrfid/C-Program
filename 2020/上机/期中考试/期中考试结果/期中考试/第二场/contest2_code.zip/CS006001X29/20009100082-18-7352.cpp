#include<iostream>
using namespace std;
#include<string>
string s;
char m1='0',m2='9'+1;
int main()
{
	cin>>s;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]>m1) m1=s[i];
		if(s[i]<m2) m2=s[i];
	}
	cout<<m1<<" "<<m2;
	return 0;
}
