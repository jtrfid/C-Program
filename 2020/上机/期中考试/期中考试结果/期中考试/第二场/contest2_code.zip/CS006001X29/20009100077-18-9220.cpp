#include <stdio.h>
#include <math.h>
int main(){
	int n,min=9,max=0;
	scanf("%d",&n);
	while(n>0){
		int p=n%10;
		if(p<min){
			min=p;
		}
		if(p>max){
			max=p;
		}
		n=(n-p)/10;
	}
	printf("%d %d",max,min);
	return 0;
}
