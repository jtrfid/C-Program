#include<stdio.h>
int main(void)
{
	int n,s=0,i;
	scanf("%d",&n);
	for (i=1;i<=n-1;i++)
	{
		if (n%i==0) s=s+i;
	}
	printf("%d",s);
	return 0;
}
