#include<iostream>
using namespace std;
#include<iomanip>
#include<math.h>
double a,b,c;
int main()
{
	cin>>a>>b>>c;
	double p=b*b-4*a*c;
	if(p<0) cout<<"no";
	else if(p==0) cout<<fixed<<setprecision(1)<<-b/(2*a);
	else cout<<fixed<<setprecision(1)<<(-b+sqrt(p))/(2*a)<<" "<<fixed<<setprecision(1)<<(-b-sqrt(p))/(2*a);
	return 0;
}
