#include <stdio.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    float a,b,c,d,e,f,x1,x2,x;
    scanf("%f %f %f",&a,&b,&c);
    d=b*b-4.0*a*c;
    e=0-b/(2*a);
    
    if(d>0)
    {
    f=sqrt(d);
	x1=(f/(2.0*a))+e;
	x2=e-(f/(2.0*a));
	printf("%.1f %.1f",x1,x2);
    }
    
    if(d==0.0)
    {
    	printf("%.1f",e);
    }
    
    if(d<0)
    {
    	printf("no");
    }
	return 0;
}
