#include<stdio.h>
#include<math.h>
int main()
{
	float a ,b,c,k;
	scanf("%f %f %f",&a,&b,&c);
	k=b*b-4*a*c;
	if(k<0)	printf("no");
	if(k==0) printf("%.1f",(-b/(2.0*a)));
	if(k>0)	printf("%.1f %.1f",((-b+sqrt(k))/(2.0*a)),((-b-sqrt(k))/(2.0*a)));
	return 0;
	
	
	
	
	
}
