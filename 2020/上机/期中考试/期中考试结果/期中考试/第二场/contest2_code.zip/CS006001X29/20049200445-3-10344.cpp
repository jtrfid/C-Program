#include<stdio.h>
#include<math.h>
int main()
{   long double a,b,c,d,e,f=4,g=2,h,i,j=0;
	scanf("%lf %lf %lf",&a,&b,&c);
	d=b*b-f*a*c;
	if(d<j)
	{
	printf("no");}
	else
	    if(d==j)
	   {
	    e=(-b)/(d*g);
    	printf("%.1f",e);}
    	else
	        if(d>j)
        	{
        	h=(-b+d)/(d*g);
        	i=(-b-d)/(d*g);
        	printf("%.1f %.1f",h,i);}
	return 0;
}
