#include<stdio.h>
#include<math.h>
int main()
{int a,c=0,d;
	scanf("%d",&a);
	for(int i=1;i<a;i++)
	{for(int b=i-1;b>0;b--)
	{d=i%b;
	 if((d==0)&&(b>1))
	 break;
	 else
	 if(b=1)
	 c=c+1;
	}
	}
	if(a<4)
	c=a;
	printf("%d",c);
	return 0;
}
