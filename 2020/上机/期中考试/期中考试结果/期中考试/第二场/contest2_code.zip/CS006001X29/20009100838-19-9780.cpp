#include<stdio.h>
int main()
{
	int n,i,k,flag=0;
	int sum=0;
	int sum1=0;
	scanf("%d",&n);
	for(i=3;i<n;i++)
	{
		sum=0;
			for(k=2;k<i;k++)
			{
				if(i%k!=0) sum++;
			}
		if(sum==i-2)
		{
			sum1++;
		}
	}
	
	printf("%d",sum1+1);
;	return 0;
}
