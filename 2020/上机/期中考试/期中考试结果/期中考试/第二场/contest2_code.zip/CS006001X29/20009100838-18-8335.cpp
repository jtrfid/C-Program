#include<stdio.h>
int main()
{
	int n;
	int max=0;
	int min=0;
	scanf("%d",&n);
	while(n>0)
	{
		if(n%10>=max) max=n%10;
		if(n%10<=min) min=n%10;
		n=n/10;
	}
	printf("%d %d",max,min);
	return 0;
		
		
		
	}
	
	
	
	
	


