#include <stdio.h>
#include <math.h>
int main(){
	int n;
	scanf("%d",&n);
	int sum=1;
	for(int i=2;i<=n-1;i++){
		if(n%i==0)sum=sum+i;
	}
	printf("%d",sum);
	return 0;
}
