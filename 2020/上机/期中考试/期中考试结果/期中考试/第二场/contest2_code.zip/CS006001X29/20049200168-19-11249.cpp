#include<stdio.h>
int main()
{int a,i,m=0,n,z;
scanf("%d",&a);
for(i=2,z=0;i<=a;i++)
{for(n=2;n<i;n++)
{if(i%n!=0)
z=1;}
if(z==1)
m=m+1;
}
printf("%d",m);
return 0;
}
