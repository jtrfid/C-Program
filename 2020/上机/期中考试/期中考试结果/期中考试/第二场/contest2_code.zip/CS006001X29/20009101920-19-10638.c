#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,c,d,e,f;
	scanf("%d",&a);
	b=2;
	c=1;
	e=0;
	f=0;
	if(a==1||a==2)
	printf("0");
	else
	{
	while(b<a)
	{while(c<b)
	{if(b%c==0)
	e=e+1;
	c=c+1;
	}
	
	if(e==1)
	f=f+1;
	b=b+1;
	c=1;
	e=0;
	}
	printf("%d",f);
    }
	return 0;
}
