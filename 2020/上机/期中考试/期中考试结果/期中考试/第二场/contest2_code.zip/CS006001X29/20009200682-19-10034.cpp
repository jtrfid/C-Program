#include<stdio.h>
#include<math.h>
int main(){
	int n;
	scanf("%d",&n);
	int i,j,x;
	x=0;
	for(j=3;j<=n;j++){
	for(i=2;i<j;i++){
		if(j%i==0)break;
		if(i==j-1)x+=1;
	}
}
printf("%d",x+1);
return 0;
}
