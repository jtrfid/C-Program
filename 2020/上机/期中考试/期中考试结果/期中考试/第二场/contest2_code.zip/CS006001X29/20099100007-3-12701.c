# include <stdio.h>
# include <math.h>
int main(){
	float a,b,c,d,x,X,m,n,k;
	scanf("%lf %lf %lf",&a,&b,&c);
	d=b*b-4*a*c;m=sqrt(d);k=2*a;
	x=((-b)-m)/k;X=((-b)+m)/k;n=-b/k;
	if(d<0) printf("no");
	else if(d==0) printf("%.1f",n);
	else printf("%.1f %.1f",x,X);
}
