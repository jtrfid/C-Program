# include <stdio.h>
# include <math.h>
int main(){
	double a,b,c,d,x,X,m,n;
	scanf("%lf %lf %lf",&a,&b,&c);
	d=b*b-4*a*c;m=sqrt(d);
	x=((-b)-m)/(2*a);X=((-b)+m)/(2*a);n=-b/(2*a);
	if(d<0) printf("no");
	else if(d==0) printf("%.1f",n);
	else printf("%.1f %.1f",x,X);
}
