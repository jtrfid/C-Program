#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cmath>
using namespace std;
template <class T> inline void swap(T &x, T &y) {
	T tmp = x; x = y; y = tmp;
}
inline void judge() {
	freopen("test.in", "r", stdin);
	//freopen("test.out", "w", stdout);
}
int n, ans;
inline bool is_prime(int x) {
	if (x == 1) return 0;
	if (x == 2) return 1;
	int s = (int)sqrt(x);
	for (int i = 2; i <= s; ++i) if (x % i == 0) return 0;
	return 1;
}
int main() {

	//judge();

	scanf("%lld", &n);
	for (int i = 1; i <= n; ++i) if (is_prime(i)) ans++;
	printf("%d", ans);
	return 0;
}
