#include<stdio.h>
#include<math.h>
int main()
{int a,c=0,b;
	scanf("%d",&a);
	for(int i=1; i<=a-1;i++)
	{b=a%i;
	  if(b==0)
	  c=c+i;
	}
	printf("%d",c);
	return 0;
}
