#include<stdio.h>
#include<math.h>
int main()
{
	long int i,n,y=0;

	scanf("%ld",&n);
	
	for(i=1;i<n;i++)
	{
		if(n%i==0)
		y=y+i	
	;};
	
	printf("%ld",y);
	
	return 0;
}
