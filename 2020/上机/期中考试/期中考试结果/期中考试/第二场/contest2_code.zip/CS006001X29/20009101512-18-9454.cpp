#include <stdio.h>

int main() {
	int y,max,min,a;
	min=9;max=0;
	long x;
	scanf("%d",&x);
	for (y=0;;)
	{a=x%10;
	if(a==0&&(x/10==0)) break;
	 max=(a>max)?a:max;
	 min=(a<min)?a:min;
	 x=x/10;
	}
	printf("%d %d",max,min);
	return 0;
}
