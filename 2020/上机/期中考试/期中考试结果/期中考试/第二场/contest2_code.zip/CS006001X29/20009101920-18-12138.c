#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char a,b,c,d;
	b='@';
	while(scanf("%c",&a))
	{if(a=='\n')
	break;
	
	if(a>b)
	c=a;
	if(a<b)
	d=a;
	b=a;
	
	}
	printf("%c %c",c,d);
	
	
	return 0;
	return 0;
}
