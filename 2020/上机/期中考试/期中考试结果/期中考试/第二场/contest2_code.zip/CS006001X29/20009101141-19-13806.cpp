#include <stdio.h>
#include <math.h>
int main()
{int x,n=0,i,j;
 scanf("%d",&x);
 for(j=x;j>2;j--)
 {for(i=2;i<=j;i++)
 if(j%i==0)
  n=n+1;
 
 }
 n=n+2;
 printf("%d",n);
 return 0;
 
}
