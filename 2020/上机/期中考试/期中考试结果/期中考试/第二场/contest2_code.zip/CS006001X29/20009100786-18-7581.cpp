#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cmath>
using namespace std;
template <class T> inline void swap(T &x, T &y) {
	T tmp = x; x = y; y = tmp;
}
inline void judge() {
	freopen("test.in", "r", stdin);
	//freopen("test.out", "w", stdout);
}
long long n;
int Max, Min;
int main() {

	//judge();

	scanf("%lld", &n);
	Min = 100;
	for (int now; n; n /= 10) {
		now = n % 10;
		if (now > Max) Max = now;
		if (now < Min) Min = now;
	}
	printf("%d %d", Max, Min);
	return 0;
}
