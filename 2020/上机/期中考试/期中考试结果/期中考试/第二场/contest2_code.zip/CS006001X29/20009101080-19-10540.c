#include<stdio.h>
#include<math.h>
int main ()
{
    int n,i,j,count=0;
    scanf("%d",&n);
    for(i=1;i<n;i++)
    {
    	for(j=2;j<n;j++)
    	 if(i%j==0)
    	  break;
      if(j==i)
       count++;
    }
    printf("%d",count);
	return 0;
}
