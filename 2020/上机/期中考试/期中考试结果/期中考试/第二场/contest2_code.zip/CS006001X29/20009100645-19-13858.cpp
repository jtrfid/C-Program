#include <stdio.h>
#include <math.h>
int main ()
{
	int n,t,i,sum=0;
	scanf("%d",&n);
	for(t=n;t>=2;t--)
	{
	for(i=2;i<t;i++)
	if(t%i==0)
	{
	sum=sum+1;
	break;
	}
	}
sum=n-sum;
	printf("%d",sum-1);

}


