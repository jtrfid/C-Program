#include <stdio.h>

int main(){
	int n,s,i,j,t,M=0,m,l,x;
	scanf("%d",&n);
	
	for(s=10;s>=0;s--){
		for(l=1,t=1;l<=s;l++)t=t*10;
	//	t=pow(10,s);
		if((n/t)!=0)break;
	}
	
	
	j=n/10;
	m=n-10*j;
	
	for(i=s;i>=0;i--){
		for(l=1,x=1;l<=i+1;l++)x=x*10;
		j=n/x;
	//	j=n/pow(10,i+1);
	    for(l=1,x=1;l<=i;l++)x=x*10;
	    t=n/x-10*j;
	//	t=n/pow(10,i)-10*j;
		if(t>M)M=t;
		if(t<m)m=t;
	}
	
	printf("%d %d",M,m);
	return(0);
}
