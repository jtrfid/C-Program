#include<stdio.h>
#include<math.h>
int main(void)
{
	double a,b,c,dll,x1,x2,dl;
	scanf("%lf %lf %lf",&a,&b,&c);
	dll=b*b-4*a*c;
	if (dll<0) printf("no");
	else if (dll==0) 
	{
		x1=-b/2.0/a;
		printf("%.1f",x1);
	}
	else 
	{
		dl=sqrt(dll);
		x1=(-b+dl)/2.0/a; x2=(-b-dl)/2.0/a;
		printf("%.1f %.1f",x1,x2);
	}
	return 0;
}
