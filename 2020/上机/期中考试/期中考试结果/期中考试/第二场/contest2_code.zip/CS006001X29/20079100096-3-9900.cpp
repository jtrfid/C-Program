#include<stdio.h>
#include<math.h>
int main(){
	float a,b,c,d,x1,x2,x;
	
	scanf("%f %f %f",&a,&b,&c);
	d=b*b-4*a*c;
	if(d<0) {
	printf("no");}
	else if(d==0)
{
	x=-b/(2*a);
	printf("%.1f",x);}
	else {x1=(-b+sqrt(d))/(2*a);
	x2=(-b-sqrt(d))/(2*a);
	 printf("%.1f %.1f",x1,x2);
	 }
	
	
return 0;	
}
