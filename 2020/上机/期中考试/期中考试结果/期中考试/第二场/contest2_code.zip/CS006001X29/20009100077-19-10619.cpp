#include <stdio.h>
int test(int n){
	int sum=0;
	for(int i=2;i<n;i++){
		if(n%i==0&&n!=i)sum++;
	}
	if(sum==0)return 1;
	if(sum!=0)return 0;
}
int main(){
	int n,sum=0;
	scanf("%d",&n);
	if(n==1)printf("%d",sum);
	else if(n==2)printf("%d",sum+1);
	else if(n==3)printf("%d",sum+2);
	else{
		sum=sum+1;
	for(int i=3;i<=n-1;i++){
		if(test(i)==1)sum++;
	}
	printf("%d",sum);
}
	return 0;
}
