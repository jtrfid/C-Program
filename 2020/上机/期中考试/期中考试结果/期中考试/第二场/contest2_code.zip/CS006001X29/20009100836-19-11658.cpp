#include<stdio.h>
#include<math.h>
int main()
{
	long int i,a=0,n,d,b=2,y;

	scanf("%ld",&n);
	if(n>=0&&n<=10000){
	
	for(d=3;d<n;d++){
	
		for(i=2;i<d;i++)//is d a su?
		{
			if(d%i==0)//d isn't su
			{b++;break;}
		};
		
	}
	y=n-b;
	if(y<0)
	y=0;
	printf("%ld",y);
}
	return 0;
}
