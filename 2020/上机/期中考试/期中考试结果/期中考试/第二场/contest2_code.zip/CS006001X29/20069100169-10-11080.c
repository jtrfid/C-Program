#include<stdio.h>
int main(){
    int a,i,ans=0;
    scanf("%d",&a);	
	for(i=1;i<a;i++){
		if(a%i==0&&i!=(a/i)){
    	    ans=ans+i;
    }
        if(a%i==0&&i==(a/i))
        	ans=ans+i;
        }
        printf("%d",ans);
	return 0;
}
