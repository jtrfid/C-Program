#include <stoid.h>
int main()
{
	int n,sum;
	0<=n&&n<=10000
	
}

