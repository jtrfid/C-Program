#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int max(int n);
int min(int n);
int main(int argc, char *argv[]) {
	long int x;

	scanf("%ld",&x);
	printf("%d %d",max(x),min(x));
	return 0;
}
int max(int n)
{
	int max,i=n%10;
	max=i;
	while(n)
	{
		n=n/10;
		i=n%10;
		if(i>max)
		{
			max=i;
		}
	}
	return max;
}
int min(int n)
{
	int min,i=n%10;
	min=i;
	while(n)
	{
		n=n/10;
		i=n%10;
		if(i<min)
		{
			min=i;
		}
	}
	return min;
}
