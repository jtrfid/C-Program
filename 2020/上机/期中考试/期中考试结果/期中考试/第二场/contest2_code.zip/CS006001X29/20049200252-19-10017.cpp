#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j,k,sum;
	scanf("%d",&n);
	sum=0;
	for(i=2;i<n;i++)
	{ k=0;
	  for(j=2;j<i;j++)
	  {
	  	if(i%j==0)
	  	k=1;
	  	else ;
	  }
	  if(k==0) sum=sum+1;
	  else ;
    }
    printf("%d",sum);
    return 0;
}
