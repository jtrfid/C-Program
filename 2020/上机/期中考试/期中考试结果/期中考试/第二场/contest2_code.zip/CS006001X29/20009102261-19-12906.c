#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	long n,i,m,x,max,y;
	scanf("%d",&x);
	max=0;
	for(n=1;n<x;n++)
{
	m=0;
	for(i=1;i<=n;i++)
	{
		if(n%i==0)
		{
			m=m+1;
		}
    }
    
    if(m==2)
    {
    max=max+1;
}
}
	printf("%d",max);
	
	return 0;
}
