#include<stdio.h>
int main(){
	int a;
	scanf("%d",&a);
	int n;
	int fb(int d){
		int h=0;
		int q;
		for(q=2;q<d;q++){
			if(d%q==0){
			h=1;
			break;	
			}
			
		}
		return h;
	}
	
	int num,c,q,e;
	q=0;
	num=0;
	if(a==1||a==2){
		printf("0");
}
	else {
	for(c=3;c<=a;c++){
		e=fb(c);
		if(e==0){
			num++;
		}
		}
	
	
	
	printf("%d",num+1;}

}

	

