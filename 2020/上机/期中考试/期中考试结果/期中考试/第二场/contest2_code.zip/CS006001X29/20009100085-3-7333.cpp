#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,disc,x1,x2;
	scanf("%f %f %f",&a,&b,&c);
	disc=b*b-4*a*c;
	if(disc==0) printf("%.1f",(-b)/2*a);
	if(disc>0) {x1=(-b-sqrt(disc))/(2*a);x2=(-b+sqrt(disc))/(2*a);printf("%.1f %.1f",x1,x2);}
	if(disc<0) printf("no");
	return 0;
	
	
}
