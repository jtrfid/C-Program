#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,a=0;
	scanf("%d",&n);
	for(i=n-1;i>0;i--)
	{if(n%i==0){a=a+i;}}

	printf("%d",a);
	return 0;
	
}
