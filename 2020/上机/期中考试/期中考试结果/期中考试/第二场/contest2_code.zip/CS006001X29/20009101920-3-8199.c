#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	double a,b,c,d,e,f,g;
    scanf("%lf %lf %lf",&a,&b,&c);
    d=b*b-4*a*c;
	e=sqrt(d);
	f=(-b+e)/(2*a);
	g=(-b-e)/(2*a);
    if(d==0)
    printf("%.1f",f);
    if(d<0)
    printf("no");
    if(d>0)
    printf("%.1f %.1f",f,g);
    
	return 0;
}
