#include<stdio.h>
#include<math.h>
int main(){
	long int a;
	int max=0,min=9,t;
	scanf("%d",&a);
	do{
	    t=a%10;
	    if(t>max){
	    	max=t;
	    }
	    if(t<min){
	    	min=t;
	    }
		a=a/10;
	}
	while(a!=0);
	printf("%d %d",max,min);

 
	return 0;
}
