#include<stdio.h>
#include<math.h>
int main ()
{
    int x,a,c=0,d=10;
    scanf("%d",&x);
    for(;x>=1;)
    {
    	a=x%10;
    	x=x/10;
    	if(a>c)
    	 c=a;
    	if(a<d)
    	 d=a;
    }
    printf("%d %d",c,d);
	return 0;
}
