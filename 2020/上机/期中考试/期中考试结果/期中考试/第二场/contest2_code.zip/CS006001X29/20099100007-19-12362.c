# include <stdio.h>
# include <math.h>
int main(){
	int a,i,j,sum,p,s;
	scanf("%d",&a);
	for(i=3,sum=0;i<a;i++)
	{
		for(j=2,s=0;j<i;j++)
		{
			p=i%j;
			if(p==0) break;	
			else s=s+1;
		}
		if(s==i-2) sum=sum+1;
	}
	printf("%d",sum+1);
}
