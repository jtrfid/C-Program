#include<stdio.h>
#include<math.h>
int main()
{   float a,b,c,d,h,m,x1,x2;
    scanf("%f %f %f",&a,&b,&c);
    d=pow(b,2);
    h=(-b)/(2*a);
    if(d-4*a*c<0)
    {
    printf("no");
    }
	if(d-4*a*c==0)
    {
    printf("%.1f",h);
    }
	if(d-4*a*c>0)
    {
    m=sqrt(d-4*a*c);
    x1=(-b+m)/(2*a);
    x2=(-b-m)/(2*a);
    printf("%.1f %.1f",x1,x2);
	}
	return 0; 
}
