#include <stdio.h>
#include <math.h>
int main()
{
	unsigned int x,max=0,min=9,m,n,j;
	float p;
	int i=1;
	scanf("%d",&x);
	n=x;
	p=x;
	while(i)
	{

		j=x/pow(10,i-1);
		n=x/pow(10,i);
		p=p/pow(10,i);
		if(p<0.1) break;
		m=j-n*10;
		
		if(m==9) max=9;
		else if(m==0) min=0;
		else
		{
			if(m>max) max=m;
			if(m<min) min=m;
		}
		i++;
		
	}
	printf("%d %d",max,min);
}
