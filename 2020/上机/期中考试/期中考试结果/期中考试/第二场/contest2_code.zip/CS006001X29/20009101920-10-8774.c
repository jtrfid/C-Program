#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,c;
	scanf("%d",&a);
	b=1;
	c=0;
	while(b<a)
	{if(a%b==0)
	c=c+b;
	b=b+1;
	}
	printf("%d",c);
	return 0;
}
