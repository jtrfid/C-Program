#include<stdio.h>
int main(void)
{
	int x,x1,n=1,i,p,max=0,min=9;
	scanf("%d",&x);
	x1=x;
	while (x1/10!=0)
	{
		n=n+1;
		x1=x1/10;
	}
    for (i=1;i<=n;i++)
     {
     	p=x%10;
     	if (p>max) max=p;
     	if (p<min) min=p;
     	x=x/10;
     }
     printf("%d %d",max,min);
	return 0;
}
