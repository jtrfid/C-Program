#include<stdio.h>
#include<math.h>
int main(){
	int n;
	scanf("%d",&n);
	int i,z;
	z=0;
	for(i=1;i<n;i++){
		if(n%i==0)z+=i;
	}
	printf("%d",z);
	return 0;
}
