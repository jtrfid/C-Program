#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a,b,c,x1,x2,delta;
	scanf("%f %f %f",&a,&b,&c);
	
	delta = b*b-4*a*c;
	
	if(delta<0)
		printf("no");
	else{
		if(delta > 0){
				x1 = (-1*b+sqrt(delta))/2*a;
	            x2 = (-1*b-sqrt(delta))/2*a;
	            printf("%.1f %.1f",x1,x2);
				} 
	    else {
	    	x1 = -1*b/2*a;
	    	printf("%.1f ",x1);
             }       
		
	}
	return 0;
}
