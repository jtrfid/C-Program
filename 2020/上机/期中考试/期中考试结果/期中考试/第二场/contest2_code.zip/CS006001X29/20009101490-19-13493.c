#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,i,j,sum=0,c=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
	for(j=2;j<i;j++)
	{if(i%j!=0)
	continue;
	sum++;}}
	if(sum==0) c++;
	printf("%d",n-1-c);
	return 0;
}
