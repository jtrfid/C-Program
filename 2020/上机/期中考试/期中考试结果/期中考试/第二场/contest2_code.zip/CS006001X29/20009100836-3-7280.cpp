#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,x1,x2,de;

	scanf("%f%f%f",&a,&b,&c);
	de=b*b-4*a*c;
	if(de==0)
	{
		x1=(-b)/2/a;
		printf("%.1f",x1);
		
	}
	else if(de>=0){
		x1=(-b+sqrt(de))/2/a;
		x2=(-b-sqrt(de))/2/a;
		printf("%.1f %.1f",x1,x2);
	}
	else 
	printf("no");
	
	return 0;
}
