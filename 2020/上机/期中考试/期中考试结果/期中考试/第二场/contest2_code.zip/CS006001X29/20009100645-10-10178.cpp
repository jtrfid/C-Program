#include <stdio.h>
#include <math.h>
int main ()
{
	int n,i,sum=0,a;
	scanf("%d",&n);
	for(i=1;i<n;i++)
		{a=n%i;
		if(a==0)
		sum=sum+i;
		}
	printf("%d",sum);
	return 0;
}

