#include<stdio.h>
#include<math.h>
int main(){
	long x;
	scanf("%d",&x);
	int i,max,min,z;
	max=0;
	min=9;
	for(i=0;x>0;i++){
		z=x%10;
		x=x/10;
		max=max>z?max:z;
		min=min<z?min:z;
	}
	printf("%d %d",max,min);
	return 0;
}
