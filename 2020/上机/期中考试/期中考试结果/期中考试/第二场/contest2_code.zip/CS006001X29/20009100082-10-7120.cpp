#include<iostream>
using namespace std;
int n;
int ans=0;
int main()
{
	cin>>n;
	for(int i=1;i<n;i++)
	{
		if(n%i==0) ans+=i;
	}
	cout<<ans;
	return 0;
}
