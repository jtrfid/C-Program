#include <stdio.h>
#include <math.h>
int main()
{
	float a,b,c,z,x1,x2,x;
	scanf("%f%f%f",&a,&b,&c);
	z=b*b-4*a*c;
	if(z<0)
	{
		 printf("no");
	}
	else if(z==0)
	{
		 printf("%.1f",-b/2*a);
	}
	else 
	{
		x=pow(z,0.5);
		x1=(-b-x)/2*a;
		x2=(-b+x)/2*a;
		printf("%.1f %.1f",x2,x1);
	}
	return 0;
}
