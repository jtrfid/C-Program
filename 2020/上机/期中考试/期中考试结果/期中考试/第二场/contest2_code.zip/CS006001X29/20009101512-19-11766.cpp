#include <stdio.h>
#include <math.h>
int main() {
    int x,y,i,m,k;
    i=0;
    scanf("%d",&x);
    for(m=2;m<x;m++)
    {for (y=1,k=0;y<=sqrt(m);y++)
        {if (m%y==0) k++;
		 if (k>1) break; 
        }
    if (k==1) i++;
	}
	printf("%d",i);
	return 0;
}
