#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cmath>
using namespace std;
template <class T> inline void swap(T &x, T &y) {
	T tmp = x; x = y; y = tmp;
}
inline void judge() {
	freopen("test.in", "r", stdin);
	//freopen("test.out", "w", stdout);
}
double a, b, c, delta;
int main() {

	//judge();

	scanf("%lf%lf%lf", &a, &b, &c);
	delta = b * b - 4.0 * a * c;
	if (delta < 0) {
		puts("no");
	} else if (fabs(delta) < 1e-7) {
		printf("%.1lf", (-b + sqrt(delta)) / (2 * a));
	} else {
		printf("%.1lf %.1lf", (-b + sqrt(delta)) / (2 * a), (-b - sqrt(delta)) / (2 * a));
	}
	return 0;
}
