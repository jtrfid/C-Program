#include <stdio.h>
#include <math.h>
int main ()
{
	long int x,y;
	int a,b,c,d;
	scanf("%d",&x);
	y=x;
	a=x%10;
	for(;x>=10;)
	{
		x=x/10;
		b=x%10;
		if(a<b)
		a=b;
	}
	c=y%10;
	for(;y>=10;)
	{
		y=y/10;
		d=y%10;
		if(c>d)
		c=d;
	}
	printf("%d %d",a,c);
	return 0;
}

