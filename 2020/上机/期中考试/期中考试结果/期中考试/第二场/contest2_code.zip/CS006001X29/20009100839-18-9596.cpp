#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int n,max,min,b,c,d,i;
    scanf("%d",&n);
    max=n%10;min=n%10;
    n=n/10;
    for(i=1;i<=100000000;i++)
    {
    	if(n==0)break;
    	else 
    	{
    		b=n%10;
    		if(b>max)
    		{
    			c=b;
    			b=max;
    			max=c;
    		}
    		if(b<min)
    		{
    			d=b;
    			b=min;
    			min=d;
    		}
    	}
    	n=n/10;
    	
    }
    printf("%d %d",max,min);
    return 0;
}
