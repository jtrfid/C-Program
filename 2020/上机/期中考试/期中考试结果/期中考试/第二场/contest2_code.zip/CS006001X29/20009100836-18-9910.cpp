#include<stdio.h>
#include<math.h>
int main()
{
	long int i,a,x[10],n;

	scanf("%ld",&n);
	

	for(i=0;n!=0;)
	{
		x[i]=n%10;
		i++;
		n/=10;
	};
	
	for(a=0;a<i;a++)
{
		if(x[a]>x[0])
		x[0]=x[a];
		
		if(x[a]<x[9])
		x[9]=x[a];
	
};
	printf("%ld %ld",x[0],x[9]);
	
	return 0;
}
