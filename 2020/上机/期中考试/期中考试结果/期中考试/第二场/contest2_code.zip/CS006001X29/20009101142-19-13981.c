#include <stdio.h>

int sushu(int x)
{
	int u,k=0;
	for(u=x-1;u>1;u--)
	{
		if(x%u==0) break;
		else k++;
	}
	if(k==x-2) return 1;
	else return 0; 
}

int main()
{
	int n,i;
	int s=0;
	scanf("%d",&n);
	for(i=n-1;i>1;i--)
	{
		if(sushu(i)==1) s++;
	}
	printf("%d",s);
}
