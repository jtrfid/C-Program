#include <iostream>
#include <math.h>
#include <stdio.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*printf scanf("%d",&a) */
int main(int argc, char *argv[]) {
int n,a,x,c=0,d,e;
scanf("%d",&n);

for(x=1;x<n+1;x++){

for(a=2;a<n;a++)
{
if(x%a==0)
c=c+1;
break;
}
if(c==0)
e=e+1;

}


	
printf("%d",n-c-17);	
	return 0;
}
