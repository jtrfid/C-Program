#include <iostream>
#include <math.h>
#include <stdio.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*printf scanf("%d",&a) */
int main(int argc, char *argv[]) {
	float a,b,c;
	float x,n,x1,x2,n1;
	scanf("%f %f %f",&a,&b,&c);
	n=b*b-4*a*c;
	
	n1=pow(n,0.5);
	x1=(-b+n1)/(2*a);
	x2=(-b-n1)/(2*a);
	if(n<0)
	printf("no");
	if(n==0)
    printf("%.1f",x=-b/(2*a));
	if(n>0)
	printf("%.1f %.1f",x1,x2);	
	return 0;
}
