#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,a,b,c,d,e;
	scanf("%d",&n);
	if(n>0 & n<10)
	{
		printf("%d %d",n,n);
	}
	if(n>=10 & n<100)
	{
		a=n/10;
		b=n%10;
		if(a>b)
		printf("%d %d",a,b);
		else printf("%d %d",b,a);
		
	}

	return 0;
}
