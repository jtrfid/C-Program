#include<stdio.h>
int main(){
	int n,i,x,j;
	scanf("%d",&n);
	x=0;
	for(i=1;i<n;i++)
	{for(j=2;j<i;j++)
	{if (i%j==0)  break;}
	if(j==i) x=x+1;
	}
	printf("%d",x);
	return 0;
	
}

