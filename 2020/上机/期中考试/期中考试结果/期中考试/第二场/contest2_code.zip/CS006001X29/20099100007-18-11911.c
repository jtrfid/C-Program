# include <stdio.h>
# include <math.h>
int main(){
	int b,max,min,i,j,sum,a[10],k,p;
	scanf("%d",&b);
	for(i=0;i<=9;i++)
	{
		p=b/pow(10,i);
		a[i]=p%10;
	while(sum<9)
		for(j=1;j<=10;j++)
		{
			for(i=0;i<=9;i++)
			{
			if(a[j]>=a[i]) sum=sum+1;
			}
		}
	max=j;
	while(sum<9)
		for(k=1;k<=10;k++)
		{
			for(i=0;i<=9;i++)
			{
			if(a[k]<=a[i]) sum=sum+1;
			}
		}
	min=k;
}
	printf("%d %d",max,min);
}
