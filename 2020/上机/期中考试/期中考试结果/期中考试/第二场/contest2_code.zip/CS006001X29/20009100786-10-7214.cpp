#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cmath>
using namespace std;
template <class T> inline void swap(T &x, T &y) {
	T tmp = x; x = y; y = tmp;
}
inline void judge() {
	freopen("test.in", "r", stdin);
	//freopen("test.out", "w", stdout);
}
int n, ans;
int main() {

	//judge();

	scanf("%d", &n);
	for (int i = 1; i < n; ++i) 
		if (n % i == 0) ans += i;
	printf("%d", ans);
	return 0;
}
