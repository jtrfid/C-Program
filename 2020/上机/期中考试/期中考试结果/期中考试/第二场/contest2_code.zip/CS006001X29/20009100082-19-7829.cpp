#include<iostream>
using namespace std;
#include<cstring>
bool isprime[10001];
int prime[10001];
int cnt=0;
int n;
void Prime()
{
	memset(isprime,1,sizeof(isprime));
	for(int i=2;i<=n;i++)
	{
		if(isprime[i]) prime[++cnt]=i;
		for(int j=1;j<=cnt&&i*prime[j]<=n;j++)
		{
			isprime[i*prime[j]]=0;
			if(i%prime[j]==0) break;
		}
	}
}
int main()
{
	cin>>n;
	Prime();
	cout<<cnt;
	return 0;
}
