#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,d=0,e,f,g;
	scanf("%f %f %f",&a,&b,&c);
	d=(b*b-4*a*c);
	if(d<0)printf("no");
	else 
	{  
	      e=pow(d,0.5);
	      f=((-b-e)/(2*a));
	      g=((-b+e)/(2*a));
	      if(f!=g)printf("%.1f %.1f ",f,g);
	      else printf("%.1f",f);
	}
	return 0;
}
