#include <stdio.h>
#include <math.h>
int main(){
	float a,b,c;
	scanf("%f %f %f",&a,&b,&c);
	float d=b*b-4*a*c;
	if(d<0) printf("no\n");
	else if(d==0)printf("%.1f",-b/(2*a));
	else{
		printf("%.1f %.1f",(-b+pow(d,0.5))/(2*a),(-b-pow(d,0.5))/(2*a));
	}
	return 0;
}
