#include<stdio.h>
int su(int x);
int main(void)
{
	int n,s=0,i;
	scanf("%d",&n);
	for (i=2;i<=n-1;i++)
	{
		if (su(i)==1) s=s+1;
	}
	printf ("%d",s);
	return 0;
}
int su(int x)
{
 int i,s=0;
 for (i=1;i<=x-1;i++)
	{
		if (x%i==0) s=s+i;
	}
	return s;
}
