#include<stdio.h>
#include<math.h>
int main(){
    int a,i,j,ans=0,flag;
    scanf("%d",&a);
	for(j=2;j<=a;j++){
	    flag=1;
	for(i=2;i<=sqrt(j);i++){
		if(j%i==0){
			flag=0;
    	    break;
    }
        }
        if(flag==1){
           ans++;}
        }
        printf("%d",ans);
	return 0;
}
