# include <stdio.h>
# include <math.h>
int main(){
	int a,i,j,sum,p,s;
	scanf("%d",&a);
	for(i=2,sum=0;i<=a;i++)
	{
		for(j=1;j<i;j++)
		{
			p=i%j;
			if(p==0) continue;
			else s=s+1;
			
		}
		 if(s==i-2) sum=sum+1;
	}
	printf("%d",sum);
}
