#include<stoid.h>
int main()
{int a,b,c;
scanf %3.1f,&
if(b*b-4*a*c)>=
     	if
     }
{if b*b-4*a*c=0
prinft(%3f,&-b/(2*a))
else prinft("1")
}
 
else prinft("no")


}
