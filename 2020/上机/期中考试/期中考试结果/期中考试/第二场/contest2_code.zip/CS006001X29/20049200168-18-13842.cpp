#include<stdio.h>
int main()
{int a,b=100,q,w,t,s;
scanf("%d",a);
s=a%10;
w=a%10;
while(b<a)
{t=a%b;
b=b*10;
if(t>s)
s=t;}
while(b<a)
{q=a%b;
b=b*10;
if(q<w)
w=q;}
printf("%d %d",s,w);
return 0;
}
