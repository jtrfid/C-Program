#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a,b,c,d;
	scanf("%f %f %f",&a,&b,&c);
	d=b*b-4*a*c;
	if(d<0)printf("no");
	else if(d==0)printf("%.1f",-b/(2*a));
	else printf("%.1f %.1f",(-b+sqrt(d))/(2*a),(-b-sqrt(d))/(a*2));
	return 0;
}
