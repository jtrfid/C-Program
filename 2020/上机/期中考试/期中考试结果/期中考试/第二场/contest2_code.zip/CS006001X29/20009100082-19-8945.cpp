#include<iostream>
using namespace std;
#include<math.h>
int n;
bool judge(int &x)
{
	for(int i=2;i<=sqrt(x);i++)
	{
		if(x%i==0) return false;
	}
	return true;
}
int main()
{
	cin>>n;
	int ans=0;
	for(int i=2;i<n;i++)
	{
		if(judge(i)) ans++;
	}
	cout<<ans;
	return 0;
}
