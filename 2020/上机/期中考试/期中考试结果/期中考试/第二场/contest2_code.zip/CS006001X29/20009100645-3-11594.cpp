#include <stdio.h>
#include <math.h>
int main ()
{
	float a,b,c,det,x1,x2,d;

	scanf("%f %f %f",&a,&b,&c);
	det=b*b-4*a*c;
	d=sqrt(det);
	if(det==0)
		{
		x1=(0-b)/(2*a);
		printf("%.1f",x1);
		}
	else if(det>0)
	 {x1=((0-b)-d)/(2*a);
	 x2=((0-b)+d)/(2*a);
	printf("%.1f %.1f",x1,x2);
	 }
	 else 
	 printf("no");
	return 0;
}


