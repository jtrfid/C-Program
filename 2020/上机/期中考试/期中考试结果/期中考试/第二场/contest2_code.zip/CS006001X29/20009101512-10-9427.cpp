#include <stdio.h>

int main() {
	int x,y,i;
	scanf("%d",&x);
	for(i=1,y=0;i<x;i++)
	{if(x%i==0) y+=i;
	}	
	printf("%d",y);
	return 0;
}
