#include <stdio.h>

int main(){
	int n,i,j,t=0,m=0;
	scanf("%d",&n);
	for(i=2;i<n;i++){
		t=2;
		for(j=2;j<i;j++){
			if(i%j==0)break;
			t=t+1;
		}
		if(t==i)m=m+1;
	}
	
	printf("%d",m);
	return(0);
}
