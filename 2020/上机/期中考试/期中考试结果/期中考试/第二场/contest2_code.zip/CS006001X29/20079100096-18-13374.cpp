#include<stdio.h>
int main(){
	int x,i,max=9,min=0,n,t;
	scanf("%d",&x);
while(x>0){
	n=x%10;
	if(max>n){t=max;max=n;n=t;}
	n=x%10;
		if(min<n){t=min;min=n;n=t;}
	
	
	x=x/10;
	
}
	printf("%d %d",min,max);
	return 0;
	
	
}
