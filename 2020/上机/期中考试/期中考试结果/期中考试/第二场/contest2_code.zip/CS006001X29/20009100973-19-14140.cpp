#include<stdio.h>
int main()
{
	int n,i,j;
	scanf("%d",&n);
	if(n<3)
		printf("0");
	else
	{
		int m=0;
		for(i=2;i<n;i++)
		{int a=0;
		for(j=1;j<i;j++)
		if(i%j==0)
		a=j;
		if(a==1)
		m+=1;
		}
		printf("%d",m);
	}
	return 0;
}
