#include<stdio.h>
#include<math.h>
int main(){
	double a,b,c;
	scanf("%lf %lf %lf",&a,&b,&c);
	double d,e,f,g,h,i;
	d=b*b-4*a*c;
	i=2.0*a;
	if(d<0){
		printf("no");
	}else if(d==0){
	e=(b*-1.0)+sqrt(d);
	f=e/i;
	printf("%.1f",f);
	}else{
	e=(b*-1.0)+sqrt(d);
	f=e/i;
	g=(b*-1.0)-sqrt(d);
	h=g/i;
	printf("%.1f %.1f",f,h);
	}
}
