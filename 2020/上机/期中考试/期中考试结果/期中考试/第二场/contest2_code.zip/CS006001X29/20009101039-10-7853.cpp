#include <iostream>
#include <math.h>
#include <stdio.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*printf scanf("%d",&a) */
int main(int argc, char *argv[]) {
	int n,a=0,b,i;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
	if(n%i==0)
	a=a+i;	
}

printf("%d",a);
	return 0;
}
