#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,i,m,sum = 0,k = 0;
	scanf("%d",&n);
	
	for(i=1;i<n;i++){
		for(m = 2,sum = 0;m <i;m++){
			if(i%m !=  0) sum++ ;
		}
		if (sum == i-2) k++;
	} 
	printf("%d",k);
	return 0;
}
