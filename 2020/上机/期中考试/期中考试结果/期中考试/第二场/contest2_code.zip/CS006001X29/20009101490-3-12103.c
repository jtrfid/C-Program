#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
		float a,b,c,d,x,x1,x2;
	scanf("%f %f %f",&a,&b,&c);
	d=b*b-4*a*c;
	if(a==0)
	{
	x=(-c)/b;
	printf("%.1f",&x);}
	else
	{if(d<0)
	printf("no");
	else if(d==0)
	{x=(-1)*b/2*a;
	printf("%.1f",x);
	}
	else
	{x1=((-1)*b+pow(d,1/2))/2*a;
	x2=((-1)*b-pow(d,1/2))/2*a;
	printf("%.1f %.1f",x1,x2);}}
	return 0;
}
