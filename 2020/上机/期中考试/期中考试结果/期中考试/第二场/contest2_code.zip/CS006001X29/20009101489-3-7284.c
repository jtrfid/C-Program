#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a,b,c,dt,x1,x2;
	scanf("%f %f %f",&a,&b,&c);
	dt=b*b-4*a*c;
	if(dt<0)
	{
		printf("no");
	}
	else if(dt==0)
	{
		printf("%.1f",-1.0*b/(2*a));
	}
	else if(dt>0)
	{
	    x1=(-1*b+sqrt(dt))/(2*a);
	    x2=(-1*b-sqrt(dt))/(2*a);
	    printf("%.1f %.1f",x1,x2);
	}
	return 0;
}
