#include<stdio.h>
#include<math.h>
int main(){
	int n;
	scanf("%d",&n);
	int i,j,x;
	if(n==1)printf("0");
	else if(n==2)printf("1");
	else if(n==3)printf("2");
	else if(n==4)printf("2");
	else{
	x=0;
	for(j=4;j<n;j++){
	for(i=2;i<j;i++){
		if(j%i==0)break;
		if(i==j-1)x+=1;
	}
}
printf("%d",x+2);
}
return 0;
}
