#include<stdio.h>
int main(){
	int a;
	int c;
	
	scanf("%d",&a);
	c=a;
	int n,max,min;
	n=0;
	while(a>0){
		a/=10;
		n++;
	}
    int b[n];
    int i,w,k;
    for(i=0;i<n;i++){
    	b[i]=c%10;
    	c/=10;
    }
    max=b[0];
    min=b[0];
    for(w=0;w<n;w++){
    	if(b[w]>max){
    		max=b[w];
    	}if(b[w]<min){
    		min=b[w];
    	}
    }
    printf("%d %d",max,min);
}
   
