#include<stdio.h>
#include<math.h>
int main()
{   double a,b,c,d,e,f=4,g=2,h,i;
	scanf("%lf %lf %lf",&a,&b,&c);
	d=b*b-f*a*c;
	if(d<0)
	printf("no");
	else
	if(d==0)
	e=(-b)/(d*g);
	printf("%.1f",e);
	if(d>0)
	h=(-b+d)/(d*g);
	i=(-b-d)/(d*g);
	printf("%.1f %.1f",h,i);
	return 0;
}
