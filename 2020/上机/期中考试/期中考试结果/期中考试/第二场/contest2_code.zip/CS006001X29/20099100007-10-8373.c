# include <stdio.h>
# include <math.h>
int main(){
	int n,i,sum;
	scanf("%d",&n);
	for(i=1,sum=0;i<n;i++)
	{
		if(n%i==0)	sum=sum+i;
	
	}
	printf("%d",sum);
}
