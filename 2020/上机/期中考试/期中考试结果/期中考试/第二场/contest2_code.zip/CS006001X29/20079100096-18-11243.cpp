#include<stdio.h>
int main(){
	int x,i,max=0,min=9,n,t;
	scanf("%d",&x);
while(x){
	n=x%10;
	if(max<n){t=max;max=n;n=t;
	}
		if(min>n){t=min;min=n;n=t;}
	
	
	x=x/10;
	
}
	printf("%d %d",max,min);
	return 0;
	
	
}
