#include<stdio.h>
#include<math.h>
int main(){
    int a,i,ans=0;
    scanf("%d",&a);
	for(i=1;i<=sqrt(a);i++){
		if(a%i==0&&i!=(a/i)){
    	    ans=ans+i;
    	    ans=ans+a/i;
    }
        if(a%i==0&&i==(a/i))
        	ans=ans+i;
        }
        printf("%d",ans-a);
	return 0;
}
