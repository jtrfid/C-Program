#include<stdio.h>
#include<math.h>
int main()
{float a,b,c,m,n,t;
scanf("%f %f %f",&a,&b,&c);
m=b*b-4*a*c;
n=-b/(2*a);
t=sqrt(m)/(2*a);
if(m<0)
printf("no");
else if(m==0)
printf("%.1f",n);
else
printf("%.1f %.1f",n+t,n-t);
return 0;
}
