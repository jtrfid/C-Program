#include<stdio.h>
int main()
{
	int n;
	int max,min;
	scanf("%d",&n);
	max=n%10;
		min=max;
	while(n>0)
	{
		
		if(n%10>=max) max=n%10;
		if(n%10<=min) min=n%10;
		n=n/10;
	}
	printf("%d %d",max,min);
	return 0;
		
		
		
	}
	
	
	
	
	


