#include <stdio.h>

int main(){
	int n,s,i,j,t,M=0,m;
	scanf("%d",&n);
	
	for(s=10;s>=0;s--){
	//	t=pow(10,s);
		if((n/t)!=0)break;
	}
	
//	j=n/pow(10,1);
//	m=n/pow(10,0)-10*j;
	
	for(i=s;i>=0;i--){
//		j=n/pow(10,i+1);
//		t=n/pow(10,i)-10*j;
		if(t>M)M=t;
		if(t<m)m=t;
	}
	
	printf("%d %d",M,m);
	return(0);
}
