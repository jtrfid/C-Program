#include<stdio.h>
int main()
{
	int n,i,count=0,j;
	scanf("%d",&n);
	if(n==3) count=0;
	else if(n==1) count=-1;
	else if(n==2) count=-1;
	else 
{
	for(i=3;i<n;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)break;
			if(j==i-1)count++;
		}
	}
}
	printf("%d",count+1);
	return 0;
}
