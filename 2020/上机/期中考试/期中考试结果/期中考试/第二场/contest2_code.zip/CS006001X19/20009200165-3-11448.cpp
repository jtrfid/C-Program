#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c;
	scanf("%lf %lf %lf",&a,&b,&c);
	if(b*b-4.0*a*c<0)
		printf("no");
	if(b*b-4.0*a*c==0)
		printf("%.1f",(squa(b*b-4.0*a*c)-b)/2);
	if(b*b-4.0*a*c>0)
		printf("%.1f %.1f",(squa(b*b-4.0*a*c)-b)/2,-(squa(b*b-4.0*a*c)-b)/2);
	return 0;
}
