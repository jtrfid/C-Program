#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c;
	scanf("%lf%lf%lf",&a,&b,&c);	//ax2+bx+c=0
	double delta;
	delta = b*b-4.0*a*c;
	if (delta<0)
	{
		printf("no");
	}
	else if (delta==0)
	{
		double root;
		root = -b/(2*a);
		printf("%.1f",root);
	}
	else
	{
		double root1,root2;
		root1 = (-b+sqrt(delta))/(2.0*a);
		root2 = (-b-sqrt(delta))/(2.0*a);
		printf("%.1f %.1f",root1,root2);
	}
	return 0;
}
