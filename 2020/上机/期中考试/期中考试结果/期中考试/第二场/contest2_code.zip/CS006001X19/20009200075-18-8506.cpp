#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,min,max,x;
	scanf("%d",&n);
	max=n%10;
	min=n%10;
	while(n!=0)
{   x=n%10;
	n/=10;
	if (x>max) max=x;
	if (x<min) min=x;
}
	printf("%d %d",max,min);
	return 0;
}
