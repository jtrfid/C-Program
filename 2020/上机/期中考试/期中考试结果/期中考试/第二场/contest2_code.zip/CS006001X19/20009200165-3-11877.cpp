#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,d;
	scanf("%lf %lf %lf",&a,&b,&c);
	d=b*b-4.0*a*c;
	if(d<0)
		printf("no");
	if(d==0)
		printf("%.1f",(pow(d,0.5)-b)/2);
	if(d>0)
		printf("%.1f %.1f",(pow(d,0.5)-b)/2,(-pow(d,0.5)-b)/2);
	return 0;
}
