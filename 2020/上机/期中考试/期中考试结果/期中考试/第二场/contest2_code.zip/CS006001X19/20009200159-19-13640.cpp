#include<stdio.h>
int pan(int b)
{
	int j,d=1;
	for(j=1;j<=b;j++)
	{
		if(b%j==0)
		{
           if(j!=1&&j!=b)
           {
           	 d=0;
           	 break;
           }
		} 
	}
	if(d==1)
	return 1;
	if(d==0)
	return 0;
}
int main()
{
	int a,i,count=0;
	scanf("%d",&a);
	for(i=1;i<=a;i++)
	{
		if(pan(i)==1)
		{
			count++;
		}
	}
	printf("%d",count-1);
	return 0;
}
