#include<stdio.h>
#include<math.h>
int main()
{
	double a , b , c, x1 , x2;
    scanf("%lf %lf %lf",&a,&b,&c);
    double delta;
	delta=1.0*b*b-4.0*a*c;
    if(delta==0){
    	x1=x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1lf",x1=x2);
    }
    else if(delta>0){
    	x1=(-b-sqrt(delta))/2.0*a;
    	x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1lf %.1lf",x2,x1);
    }
    else if(delta<0){
    	printf("no");
    }
	return 0;
}

