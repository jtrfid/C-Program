#include<stdio.h>
int main()
{
	int n , digit=0;
	scanf("%d",&n);
	for(int i=2;i<n;i++){
		int key=1;
		for(int m=2;m<i;m++){
			if(i%m==0){
				key=2;
			}
		}
		if(key==1){
			digit++;
		}
	}
	printf("%d",digit);
	return 0;
}

