#include <stdio.h>
#include <math.h>
int main()
{
	float a,b,c,x1,x2,d;
	scanf("%f%f%f",&a,&b,&c);
	d=b*b-4*a*c;
	if (d<0)
	{
		printf("no");
	}
	else
	{
		x1=(-b+sqrt(d))/(2*a);
		x2=(-b-sqrt(d))/(2*a);
		if(d==0)
		{
			printf("%.1f",x1);
		}
		else
		{
			printf("%.1f %.1f",x1,x2);
		}
	}
	return 0;
}
