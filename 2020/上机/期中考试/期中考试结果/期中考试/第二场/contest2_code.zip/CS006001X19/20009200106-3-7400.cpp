#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c;
	scanf("%lf %lf %lf",&a,&b,&c);
	if(a==0)
	{
		printf("���Ƕ��κ���");
	}
	else
	{
		double D;
		D=b*b-4*a*c;
		if(D==0)
		{
			printf("%.1lf",-b/(2*a));
		}
		else if(D>0)
		{
			printf("%.1lf %.1lf",(-b+sqrt(D))/(2*a),(-b-sqrt(D))/(2*a));
		}
		else
		{
			printf("no");
		}
	}
	return 0;
}
