#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,x1,x2,k,k0;
	scanf("%f%f%f",&a,&b,&c);
	k=b*b-4*a*c;
	if(k<0) printf("no");
	else if(k==0)
	{
		k0=sqrt(k);
		x1=(-b+k0)/(2*a);
		printf("%.1f",x1);
	}
	else
	{
		k0=sqrt(k);
		x1=(-b+k0)/(2*a);
		x2=(-b-k0)/(2*a);
		printf("%.1f %.1f",x1,x2);
	}
	return 0;
}
