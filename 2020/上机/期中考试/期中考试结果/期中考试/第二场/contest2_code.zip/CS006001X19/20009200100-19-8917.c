#include<stdio.h>
int issushu(int n)
{
	int i;
	if(n==1)
	{
		return 0;
	}
	else if(n==2)
	{
		return 1;
	}
	else
	{
		for(i=2;i<n;i++)
		{
			if(n%i==0)
			{
				return 0;
				break;
			}
		}
		if(i==n)
		{
			return 1;
		}
	}
}
int main()
{
	int n,i,sum=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		if(issushu(i))
		{
			sum++;
		}
	}
	printf("%d",sum);
	return 0;
}
