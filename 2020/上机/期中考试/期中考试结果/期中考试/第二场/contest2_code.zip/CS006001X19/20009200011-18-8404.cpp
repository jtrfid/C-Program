#include<stdio.h>
int main()
{
	long int x,i,max,min;
	scanf("%d",&x);
	min=10;
	max=0;
	while(x>0)
	{
		i=x%10;
		if(i<=min)
		   min=i;
		if(i>=max)
		   max=i;
		x=x/10;      
	}
	printf("%d %d",max,min);
	return 0;
}
