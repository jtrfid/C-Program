#include<stdio.h>
int main()
{
	int n,i,k=0,sum=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		k=n%i;
		if(k==0)
		{
			sum +=i;
		}
	}
	printf("%d",sum);
	return 0;
}
