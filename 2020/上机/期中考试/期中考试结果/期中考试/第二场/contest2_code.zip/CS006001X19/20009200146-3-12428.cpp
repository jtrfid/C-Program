#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,d,anw,anw2;
	
	scanf("%lf%lf%lf",&a,&b,&c);
	
	d=b*b-(4*a*c);
	if(d<0)
	{
		printf("no");
	}
	else if(d==0)
	{
		anw=(-b)/(2*a);
		printf("%.1f",anw);
	}
	else
	{
		anw=(-b+sqrt(d))/(2*a);
		anw2=(-b-sqrt(d))/(2*a);
		
		printf("%.1f%.1f",anw,anw2);
		
		
	}
	return 0;
	
}
