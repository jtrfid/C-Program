#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,x1,x2,x;
	scanf("%lf %lf %lf",&a,&b,&c);
	if(b*b-4*a*c>0)
	{
		x=sqrt(b*b-4*a*c);
		x1=(-b+x)/(2*a);
		x2=(-b-x)/(2*a);
		printf("%.1f %.1f",x1,x2);
	}
	else if(b*b-4*a*c==0)
	{
		x1=(-b)/(2*a);
		printf("%.1f",x1);
	}
	else printf("no");
	return 0 ;
}
