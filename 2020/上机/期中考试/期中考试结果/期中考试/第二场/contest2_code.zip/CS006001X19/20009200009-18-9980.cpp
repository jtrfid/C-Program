#include<stdio.h>
int main()
{	int n,p,q,i=0,min,max;
	scanf("%d",&n);
	p=n;
	while(p>0)
	{	q=p%10;
		p /=10;
		i++;
		if(i==1)
		{min=q;
		max=q;
		}
		if(q<min)
		{min=q;
		}
		if(q>max)
		{max=q;
		}
	}
	printf("%d %d",max,min);
	
	return 0;
}
