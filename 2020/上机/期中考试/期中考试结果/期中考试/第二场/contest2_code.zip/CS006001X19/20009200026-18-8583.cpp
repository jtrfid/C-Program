#include<stdio.h>
int main(){
	char ch[100];
	scanf("%s",ch);
//printf("%s\n",ch);
	int max=ch[0],min=ch[0];
//	printf("%c %c\n",max,min);
	for(int i=0;;i++){
		if(ch[i]=='\0') break;
		if(ch[i]>max) max=ch[i];
		if(ch[i]<min) min=ch[i];
	}
	printf("%c %c",max,min);
	return 0;
}

