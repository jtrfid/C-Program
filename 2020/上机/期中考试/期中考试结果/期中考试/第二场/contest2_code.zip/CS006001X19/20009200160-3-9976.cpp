#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,u,x1=0,x2=0,t,p;
	scanf("%f%f%f",&a,&b,&c);
	u=b*b-4*a*c;
	if(u<0)
	{printf("no");}
	if(u==0)
	{printf("%.1f",-b/2*a);}
	if(u>0)
	{
		t=sqrt(u);
	x1=(-b+t)/(2*a);
	x2=(-b-t)/(2*a);
	printf("%.1f %.1f",x1,x2);
	}
	return 0;
}
