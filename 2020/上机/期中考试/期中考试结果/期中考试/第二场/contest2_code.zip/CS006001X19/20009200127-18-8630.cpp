#include<stdio.h>
int main()
{
	int x,y,n,a,b,m;
	scanf("%d",&n);
	m=n;
	a=0,b=0;
	while(1)
	{
		a=n%10;
		n=n/10;
		if(a>b)
		{
			b=a;
		}
		
		if(n/10==0)
		{
			a=n%10;	
			if(a>b)
			{
				b=a;
			}
			break;
		}
	}
	x=0,y=1000;
	while(1)
	{
		
		x=m%10;
		m=m/10;
		if(x<y)
		{
			y=x;
		}
		if(m/10==0)
		{
			x=n%10;
			if(x<y)
			{
				y=x;
			}
			break;
		}
	}
	printf("%d %d",b,y);
	return 0;
}
