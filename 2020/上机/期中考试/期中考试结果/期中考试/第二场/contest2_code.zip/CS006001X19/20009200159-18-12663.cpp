#include<stdio.h>
int main()
{
	int a,i,b,max=1,min=1;
	scanf("%d",&a);
	for(i=1;i>0;i++)
	{
		b=a%10;
		if(a==0)
		break;
		if(b>=max)
		max=b;
		if(b<=min)
		min=b;
		a=a/10;
	}
	printf("%d %d",max,min);
	
	return 0;
}
