#include<stdio.h>
#include<math.h>
int main(){
	float a,b,c,d,e,f;
	scanf("%f %f %f",&a,&b,&c);
	d=b*b-4*a*c;
	if(d<0){
		printf("no");
	}
	else if(d==0){
	   e=-b/(2*a);
	   printf("%.1f",e);	
	}else{
	   e=(-b-sqrt(d))/(2*a);
	   f=(-b+sqrt(d))/(2*a);
	   printf("%.1f %.1f",e,f);
		
	}
	return 0;
}
