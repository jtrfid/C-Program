#include<stdio.h>
int main()
{
	long int x,a[20],i=0,min,max,count=0;
	scanf("%ld",&x);
	while(x!=0)
	{a[i]=x%10;
	i++;
	count++;
	x/=10;
	}
	min=a[0]; max=a[0];
	for(i=1;i<count;i++)
	{if(a[i]>max)
	   {max=a[i];}
	   if(a[i]<min)
	   {min=a[i];}
	}
	printf("%d %d",max,min);
	return 0;
}
