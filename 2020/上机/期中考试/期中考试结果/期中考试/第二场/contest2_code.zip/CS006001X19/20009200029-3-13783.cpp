#include<stdio.h>
#include<math.h>
int main()
{
	double a , b , c;
	float x1=0.0, x2=0.0;
    scanf("%lf %lf %lf",&a,&b,&c);
    double delta;
	delta=b*b-4*a*c;
	x1=(-b-sqrt(delta))/2.0*a;
    x2=(-b+sqrt(delta))/2.0*a;
    if(delta==0){
    	x1=x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1f",x1=x2);
    }
    else if(delta>0){
    	x1=(-b-sqrt(delta))/2.0*a;
    	x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1f %.1f",x2,x1);
    }
    else if(delta<0){
    	printf("no");
    }
	return 0;
}
