#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,ret=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
{   if(n%i==0) ret+=i;
}
	printf("%d",ret);
	return 0;
}
