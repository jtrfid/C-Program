#include<stdio.h>
int main()
{
	int m,n,i,j,cnt=0;
	scanf("%d",&n);
	if(n<=2)
	printf("0");
	else{ 
	for(i=1;i<=n;i++)
	{
		for(m=2;m<i;m++)
		{
			if(i%m==0)
			break;
		}
		if(i==m)
		{
			cnt++;
		}
	}
	printf("%d",cnt);
	} 
	return 0;
}
