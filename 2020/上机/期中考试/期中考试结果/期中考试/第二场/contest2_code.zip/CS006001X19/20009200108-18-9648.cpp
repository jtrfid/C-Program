#include<stdio.h>
int main()
{
	unsigned int x;
	int l;
	int min=9,max=0;
	scanf("%u",&x);
	for(;x>=10;x/=10)
	{
		l=x%10;
		if(l<=min)	min=l;
		if(l>=max)	max=l;
	}
	printf("%d %d",max,min);
	return 0;
}
