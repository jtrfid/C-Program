#include<stdio.h>
#include<math.h>
int pd(int n)
{
	int i=0,count=0,k=1;
	for(i=2;(k<=n);k++)
	{
		i=2;
		for(;(i<=k);i++)
		{
			if((k%i)==0)
			break;
			
		}
		
		if(i==k)
		count++;
	}
	return count;
}
int main()
{
	int n,s;
	scanf("%d",&n);
	s=pd(n);
	printf("%d",s);
	return 0;
}
