#include<stdio.h>
int main()
{
	int n,i,j,count,num;
	scanf("%d",&n);
	num=0;
	for(i=2;i<n;i++)
	{
		count=0;
		for(j=1;j<=n;j++)
		{
			if(i%j==0)
			  count++;
		}
		if(count==2)
		   num++;
	}
	printf("%d",num);
	return 0;
}
