#include<stdio.h>
int main()
{
	unsigned n;
	scanf("%d",&n);
	int max,min;
	
	int y;
	max=n%10;
	min=n%10;
	n/=10;
	
	do{
		y=n%10;
		if(y>max)
		max=y;
		if(y<min)
		min=y;
		
		n/=10;
	}while(n>0);
	
	printf("%d %d",max,min);
	return 0;
}
