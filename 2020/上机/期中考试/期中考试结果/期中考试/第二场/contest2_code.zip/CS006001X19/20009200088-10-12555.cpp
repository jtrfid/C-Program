# include <stdio.h>
# include <math.h>
int main ()
{
	double a,b,c,m,x1,x2;
	scanf("%lf %lf %lf",&a,&b,&c);
	
	m=b*b-4*a*c;
	if (m < 0)
	{
		printf ("no");
	}
	else if (m == 0)
	{
		x1=x2=-b/(2*a);
		printf("%.1lf",x1);
	}
	else if (m > 0)
	{
		x1=((-b)+sqrt(b*b-4*a*c))/(2*a);
		x2=((-b)-sqrt(b*b-4*a*c))/(2*a);
		printf("%.1lf %.1lf",x1,x2);
	}
	
	return 0;
}
