#include<cstdio>
#include<cmath>
#define N 10000
using namespace std;

int IsPrime(int i);

int main()
{   
	int n,i,j,count=0;
	scanf("%d",&n);
	if(n==1||n==2)
	printf("0");
	else
	{
	
	for(i=3;i<n;i++)
	  {
	  	if(IsPrime(i)==1)
	  	count++;
	  }
    }
    printf("%d",count+1);

	return 0;
}
int IsPrime(int i)
{	
        int j;
		for(j=2;j<i;j++)
		{
			if(i%j==0)
			return 0;
		}
		return 1;	
}


