#include<stdio.h>
int main(){
	int n,a[10005]={0,0,1,1},sum=0;
	for(int i=2;i<10000;i++){
		for(int j=2;j<i;j++){
			if(i%j==0) break;
			if(j==i-1) a[i]=1;
		}
	}
	scanf("%d",&n);
	for(int i=1;i<n;i++)
	   if(a[i]) sum++;
	printf("%d",sum);
	return 0;
}

