#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,x1,x2,m,n;
	scanf("%f %f %f",&a,&b,&c);
	n=(b*b-4*a*c);
	m=sqrt(b*b-4*a*c);
	if(n==0)
	{
		printf("%.1f",(-b+m)/(2*a));
	}
	if(n<0)
	{
		printf("no");
		
	}
	if(n>0)
	{
		printf("%.1f %.1f",(-b+m)/(2*a),(-b-m)/(2*a));
		
	}
	return 0;
}
