#include<stdio.h>
int main()
{
	int n,sum=0,i,x;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		x=n%i;
		if(x==0)
		{sum+=i;}
	}
	printf("%d",sum);
	return 0;
}
