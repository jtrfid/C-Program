#include<stdio.h>
#include<math.h>
int main()
{
	double a , b , c;
	double x1 , x2;
    scanf("%lf %lf %lf",&a,&b,&c);
    double delta;
	delta=b*b-4*a*c;
	x1=(-b-sqrt(delta))/2.0*a;
    x2=(-b+sqrt(delta))/2.0*a;
    if(delta==0){
    	x1=x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1lf",x1=x2);
    }
    if(delta>0){
    	x1=(-b-sqrt(delta))/2.0*a;
    	x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1lf %.1lf",x2,x1);
    }
    if(delta<0){
    	printf("no");
    }
	return 0;
}
