#include<stdio.h>
int main()
{
	int n,i,count=0,j;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)break;
			if(j==i-1)count++;
		}
	}
	printf("%d",count+1);
	return 0;
}
