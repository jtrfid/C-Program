#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,x1,x2,con;
	scanf("%lf %lf %lf",&a,&b,&c);
	con=b*b-4*a*c;
	if(con<0)
	   printf("no");
	else if(con==0)
	{
		x1=-b/(2*a);
		printf("%.1f",x1);
	}
	else
	{
		x1=(-b+sqrt(con))/(2*a);
		x2=(-b-sqrt(con))/(2*a);
		printf("%.1f %.1f",x1,x2);
	}
	return 0;   
}
