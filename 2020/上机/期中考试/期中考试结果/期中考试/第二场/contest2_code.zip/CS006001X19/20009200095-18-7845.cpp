#include<stdio.h>
int main()
{
	int n ;
	scanf("%d",&n);
	int max=0,min=9;
	int i,x;
	for(i=1;n!=0;i++)
	{
		x=n%10;
		if(x>max)max=x;
		if(x<min)min=x;
		n=n/10;
	}
	printf("%d %d",max,min);
	return 0 ;
}
