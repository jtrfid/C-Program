#include<stdio.h>
int main(){
	int c,b,max,min,i;
	i=0;
	b=1;
	int a[i];
	scanf("%d",&c);
	a[i]=c%10;
	while(c/10>=1){
		c=c/10;
		i++;
		a[i]=c%10;
		b++;
	}
	for(i=0;i<b-1;i++){
		max=a[i];
		if(a[i+1]>a[i]){
			max=a[i+1];
		}else
		break;
	}
	for(i=0;i<b-1;i++){
		min=a[i];
		if(a[i+1]<a[i]){
			min=a[i+1];
		}
		else
		break;
	}
	printf("%d %d",max,min);
	
	return 0;
}
