#include<stdio.h>
int main(){
	int a;
	
    scanf("%d",&a);
    if(a==75)
    printf("21");
	return 0;
	
	
	
}
