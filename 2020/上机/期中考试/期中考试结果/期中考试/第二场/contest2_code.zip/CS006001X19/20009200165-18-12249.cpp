#include<stdio.h>
int main()
{
	int X,min,max,a,b;
	scanf("%d",&X);
	min=X%10;
	max=X%10;
	b=X/10;
	a=b%10;
	while(b>0)
	{
		if(a<min)
		{
			int temp;
			temp=a;
			a=b;
			min=temp;
		}
		b=b/10;
		a=b%10;
	}
	b=X/10;
	a=b%10;
	while(b>0)
	{
		if(a>max)
		{
			int temp;
			temp=a;
			a=b;
			max=temp;
		}
		b=b/10;
		a=b%10;
	}
	printf("%d %d",max,min);
	return 0;
}
