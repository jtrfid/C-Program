#include<stdio.h>
int sushu(int a)
{
	int i;
	for(i=2;i<a;i++)
	{
		if(a%i==0) break;
	} 
	if(i==a) return 1;
	else return -1;
}
int main()
{
	int n,sum=0,i;
	scanf("%d",&n);
	for(i=2;i<n;i++)
	{
		if(sushu(i)==1) sum++;
	}
	printf("%d",sum);
	return 0;
} 
