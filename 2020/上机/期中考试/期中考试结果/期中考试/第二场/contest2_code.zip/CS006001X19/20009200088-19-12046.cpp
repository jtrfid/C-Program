# include <stdio.h>
int main ()
{
	int n,i=2,k=1,cnt;
	scanf("%d",&n);
	cnt=n-1;
	if ( n>0 && n<10000)
	{
		for(k=1;k<=n-1;k++)
		{
		   for(i=2;i<=k-1;i++)
	     	{
			 if (k%i==0)
			{
				cnt=cnt-1;
				break;
			}
	        }
	        
	    }
	    
		printf ("%d",cnt);
	}
	return 0;
}
