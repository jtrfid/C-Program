#include<stdio.h>
int main()
{
	int x;
	scanf("%d",&x);
	int min=999999,max=-1;;
	
	while(x!=0)
	{
		int m;
		m=x%10;
		x/=10;
		min=min<m?min:m;
		max=max>m?max:m;
	}
	printf("%d %d",max,min);
	return 0;
	
}
