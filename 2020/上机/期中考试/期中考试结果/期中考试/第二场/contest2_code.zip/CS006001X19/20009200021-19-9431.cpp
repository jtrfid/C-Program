#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i, count=0;
	if(n<=2)
		printf("%d\n",count);
	else
	{
		for(i=2;i<n;i++)
		{
			if(i==2||i==3||i==5||i==7)
				count ++;
			else if(i%2!=0&&i%3!=0&&i%5!=0&&i%7!=0)
				count ++;
		}
	printf("%d\n",count);
	}
	
	return 0;
}
