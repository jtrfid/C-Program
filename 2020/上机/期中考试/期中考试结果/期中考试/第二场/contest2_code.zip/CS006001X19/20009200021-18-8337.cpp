#include<stdio.h>
int main()
{
	int x;
	scanf("%d",&x);
	int temp, max=0, min=9;
	while(x!=0)
	{
		temp = x % 10;
		x /= 10;
		if(temp>max)
			max = temp;
		if(temp<min)
			min = temp;
	}
	printf("%d %d\n",max,min);
	return 0;
}
