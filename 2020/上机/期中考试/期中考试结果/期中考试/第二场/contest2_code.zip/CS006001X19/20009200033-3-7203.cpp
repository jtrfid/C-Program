#include <stdio.h>
#include <math.h> 
int main()
{
  float a,b,c,t;
  scanf("%f %f %f",&a,&b,&c);
  if (b*b-4*a*c<0)
  printf("no");
  else if(b*b-4*a*c==0)
  printf("%.1f",-1*b/2/a);
  else if(b*b-4*a*c>0)
  {
  	t=sqrt(b*b-4*a*c);
  	printf("%.1f %.1f",(t-b)/2/a,-1*(t+b)/2/a);
  }	
	
	
  return 0;	
}

