#include <stdio.h>

int main()
{
	int n,i,a,m,max,min;
	scanf("%d",&n);
	max=n%10;
	min=max;
	m=n;
	for(i=1;i<=n;i++)
	{
		a=m%10;
		m=m/10;
		if (a>max)max=a;
		if (a<min)min=a;
		if (m==0)break;
	}
	printf("%d %d",max,min);
	return 0;
}
