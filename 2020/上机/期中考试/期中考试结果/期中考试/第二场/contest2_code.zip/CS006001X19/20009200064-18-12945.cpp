#include<stdio.h>
int main()
{
	int x,i=0,max=0,min=0,a,b,c[100000000]={'0'},j;
	scanf("%d",&x);
	for(i=0;i>=0;i++)
	{
		if(a==0&&b==0)
			break;
		b=(x/10);	
		a=(x%10);
		x=b;
		c[i]=a;
	}
	for(j=0;j<=i;j++)
	{
		 if(max<c[j])
		{
			max=c[j];
		}	
	}
	for(j=0;j<=i;j++)
	{
		if(min>c[j])
		{
			min=c[j];
		}	
	}
	printf("%d %d",max,min);
	return 0;
}

