#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i, j, temp, count=0;
	if(n<=2)
	{
		printf("%d\n",count);
	}
	else
	{
		for(i=2;i<n;i++)
		{
			for(j=2;j<=i;j++)
			{
				if(i%j==0)
				{
					temp = j;
					break;
				}
			}
			if(temp==i)
				count ++;
		}
		printf("%d\n",count);
	}
	
	return 0;
}
