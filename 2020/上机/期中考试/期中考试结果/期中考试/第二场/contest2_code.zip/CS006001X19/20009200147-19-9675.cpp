#include<stdio.h>
#include<math.h>
int main()
{
	int n,s=0,t=0,i,a;
	scanf("%d",&n);
	for (i=2;i<n;i++)
	{
		t=0;
		for (a=1;a<=i;a++)
		{
			
			
		if (i%a==0)
		{
			t++;
		}
		
		
		}
		if (t==2)
		s++;
	}
	printf("%d",s);
	
	
	return 0;
}
