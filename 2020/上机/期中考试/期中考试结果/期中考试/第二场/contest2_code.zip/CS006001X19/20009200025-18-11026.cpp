#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<string.h>
int main()
{
    int a;
    char m[1000000];
    scanf("%d",&a);
    sprintf(m,"%d",a);
    int n=strlen(m);
    int maxn=m[0]-'0';
    int mini=9;
    for(int i=0; i<n; i++)
    {
        if(m[i]=='0')
            mini=0;
    }
    if(mini==0)
    {
        for(int i=0; i<n; i++)
        {
            if(maxn<(m[i+1]-'0'))
            {
                maxn=(m[i+1]-'0');
            }
        }
    }
    else if(mini!=0)
    {
        for(int i=0; i<n; i++)
        {
            if(maxn<(m[i+1]-'0'))
            {
                maxn=(m[i+1]-'0');
            }
        }
        for(int j=0; j<n-1; j++)
        {
            if(mini>(m[j]-'0'))
            {
                mini=(m[j]-'0');
            }
        }
    }
    printf("%d %d",maxn,mini);
}
