#include<stdio.h>
#include<math.h>
int main()
{	double a,b,c,x1,x2,d,e;
	scanf("%lf%lf%lf",&a,&b,&c);
	e=b*b-4*a*c;
	if(e<0)
	{	printf("no");
	}
	else 
	{
		d=sqrt(e);
		if(a!=0)
		{
		x1=(-b+d)/2*a;
		x2=(-b-d)/2*a;
		}
		if(a==0&&b!=0)
		{	x1=-c/b;
			x2=-c/b;
		}
		if(x1==x2)
		{	printf("%.1lf",x1);
		}
		else if(x1!=x2)
		{	printf("%.1lf  %.1lf",x1,x2);
		}
	}
	return 0;
}
