#include <stdio.h>
int main()
{
	int n,i,t=1,j,a;
	scanf("%d",&n);
	if(n>=3)
	{
		for(i=3;i<n;i++)
	 {
		for(j=i-1;j>1;j--)
		{   a=2; 
			if(i%j==0)
			{
				a=1;
				break;
			}
			
		}
		if(a==2)
			t+=1;
		
	 }
	printf("%d",t);
	}
	if(n==1||n==2)
	printf("0");
	
	return 0;
}
