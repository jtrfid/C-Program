#include<stdio.h>
int main()
{
	int n,max,min;
	scanf("%d",&n);
	max=n%10;
	min=n%10;
	n/=10;
	while(n!=0)
	{
		if(max<(n%10)) max=n%10;
		if(min>(n%10)) min=n%10;
		n/=10;
	}
	printf("%d %d",max,min);
	return 0;
}
