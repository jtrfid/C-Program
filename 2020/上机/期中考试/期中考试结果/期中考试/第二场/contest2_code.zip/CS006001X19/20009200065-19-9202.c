#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	
	int cnt=0;
	int i;
	for(i=2;i<n;i++)
	{
		int t,w=0;
		for(t=2;t<i;t++)
		{
			if(i%t==0)
			w=1;
		}
		if(w==0)
		cnt++;
	}
	printf("%d",cnt);
	return 0;
}
