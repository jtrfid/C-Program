#include<cstdio>
#include<cmath>
#define N 10000
using namespace std;
int main()
{
	float x1,x2,a,b,c;
	scanf("%f %f %f",&a,&b,&c);
	if(b*b-4*a*c<0)
	printf("no");
	else if(b*b-4*a*c==0)
	printf("%.1f",-b/2*a);
	else
	{
		x1=(-b+sqrt(b*b-4*a*c))/2*a;
	    x2=(-b-sqrt(b*b-4*a*c))/2*a;
	  printf("%.1f %.1f",x1,x2);
	}
	return 0;
}
