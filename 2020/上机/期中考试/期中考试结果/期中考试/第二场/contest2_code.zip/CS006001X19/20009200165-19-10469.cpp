#include<stdio.h>
int sushu(int i);
int main()
{
	int n,i,re;
	re=0;
	scanf("%d",&n);
	for(i=n-1;i>0;i--)
	{
		if(sushu(i)!=0)
			re++;	
	}
	printf("%d",re);
	return 0;
}
int sushu(int i)
{
	int b;
	for(b=2;b<i;b++)
	{
		if(i%b==0)
			return 0;
		if(b=i-1||i%(b-1)!=0)
			return i;
	}
}
