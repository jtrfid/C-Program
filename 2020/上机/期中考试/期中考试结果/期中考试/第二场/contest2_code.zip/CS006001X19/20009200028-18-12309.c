#include<stdio.h>
int main()
{
	int a,b,m,n,x;
	int max=999999,min=-1;
	scanf("%d",&x);
	while(x!=0)
	{
		int m;
		m=x%10;
		x/10;
		min=min<m?min:m;
		max=max>m?max:m;
	}
	printf("%d %d",max,min);
	
	return 0;
}
