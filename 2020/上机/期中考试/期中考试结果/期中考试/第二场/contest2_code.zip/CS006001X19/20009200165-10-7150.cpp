#include<stdio.h>
int main()
{
	int n,i,re;
	re=0;
	scanf("%d",&n);
	for(i=n-1;i>0;i--)
	{
		if(n%i==0)
		re+=i;
	}
	printf("%d",re);
	return 0;
}
