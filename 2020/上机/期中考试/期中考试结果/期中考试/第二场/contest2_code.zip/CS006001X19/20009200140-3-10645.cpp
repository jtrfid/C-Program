#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c;
	scanf("%f %f %f",&a,&b,&c);
	float del;
	del=b*b-4*a*c;
	if(del>0)
	{
		float x1,x2;
		x1=(-b+sqrt(b*b-4*a*c))/(2.0*a);
		x2=(-b-sqrt(b*b-4*a*c))/(2.0*a);
		printf("%.1f %.1f",x1,x2);
	}
	else if(del==0)
	{
		float x1;
		x1=-b/(2.0*a);
		printf("%.1f",x1);
	}
	else if(del <0)
	{
		printf("no");
	}
	return 0;
}
