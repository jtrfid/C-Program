#include<stdio.h>
#include<math.h>
int main()
{
	float a , b , c;
	float x1 , x2;
    scanf("%f %f %f",&a,&b,&c);
    float delta;
	delta=1.0*b*b-4.0*a*c;
	x1=(-b-sqrt(delta))/2.0*a;
    x2=(-b+sqrt(delta))/2.0*a;
    if(delta==0.0){
    	x1=x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1f",x1=x2);
    }
    if(delta>0.0){
    	x1=(-b-sqrt(delta))/2.0*a;
    	x2=(-b+sqrt(delta))/2.0*a;
    	printf("%.1f %.1f",x2,x1);
    }
    if(delta<0.0){
    	printf("no");
    }
	return 0;
}

