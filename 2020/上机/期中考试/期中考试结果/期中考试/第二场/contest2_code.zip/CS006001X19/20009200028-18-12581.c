#include<stdio.h>
int main()
{
	int m,n,x;
	int min=99999,max=-1;
	scanf("%d",&x);
	while(x!=0)
	{
		m=x%10;
		x/=10;
		min=min<m?min:m;
		max=max>m?max:m;
	}
	printf("%d %d",max,min);
	
	return 0;
}
