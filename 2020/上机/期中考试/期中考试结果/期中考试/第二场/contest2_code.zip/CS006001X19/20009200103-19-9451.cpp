#include<stdio.h>
int num(int n)
{
	int i;
	if(n<2) return -1;
	for(i=2;i<n;i++)
	{
		if(n%2==0) return -1;
	}
	return 0;
}
int main()
{
	int n,i,count=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	if(num(i)==0) count++;
	printf("%d",count);
	return 0;
}
