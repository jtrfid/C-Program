#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int count=0;
	int x=0;
	for(int i=2;i<=n;i++)
	{
		for(int j=2;j<=i;j++)
		{
			if(i%j==0)
			{
				if(j!=i)
			    x++;
				break;	
			}
		}
		if(x==1)
		{
			x=0;
			continue;
		}
		else
		{
			x=0;
			count++;
			continue;
		}
	}
	printf("%d",count);
	return 0;
}
