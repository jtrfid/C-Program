#include<stdio.h>
int main()
{
	int n,i=1;
	double sum=0;
	scanf("%d",&n);
	for(;i<n;i++)
	{
		if(n%i==0)
		{
			sum+=i;
		}
	}
	printf("%.0f",sum);
	return 0;
}
