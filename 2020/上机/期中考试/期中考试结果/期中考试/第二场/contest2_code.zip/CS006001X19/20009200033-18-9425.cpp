#include <stdio.h>
#include <math.h>
int main()
{
	int x,i,min=9,max=0,t,m;
	scanf("%d",&x);
	for(i=0;i>=0;i++)
	{
		m=x/pow(10,i);
		if(m==0)
		break;
		t=m%10;
		if(t<min)
		min=t;
	    if(t>max)
		max=t;
		
	}
	printf("%d %d",max,min);
	return 0;
}
