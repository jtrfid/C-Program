#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,m,n;
	scanf("%f %f %f",&a,&b,&c);
	if(a!=0)
{
	if(b*b-4*a*c>0)
	{
		m=(-b+sqrt(b*b-4*a*c))/(2*a);
		n=(-b-sqrt(b*b-4*a*c))/(2*a);
		printf("%.1f %.1f",m,n);
	}
	else if(b*b-4*a*c==0)
	{
		m=-(b/(2*a));
		printf("%.1f",m);
	}
	else 
	{
		printf("no");
	}
}
   else{
   		m=-(b/c);
		printf("%.1f",m);
   }
	return 0;
}
