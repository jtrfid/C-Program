#include<stdio.h>
int main()
{
	int n,i,sum;
	scanf("%d",&n);
	for(i=1,sum=0;i<=n;i++)
	{
		if(n%i==0)
		{
			sum=sum+i+(n/i);
		}
	}
	sum=sum/2;
	sum=sum-n;
	printf("%d",sum);
	return 0;
	
}
