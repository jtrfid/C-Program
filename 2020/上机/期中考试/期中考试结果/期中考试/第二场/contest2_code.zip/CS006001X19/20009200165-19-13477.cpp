#include<stdio.h>
int sushu(int i);
int main()
{
	int n,i,re;
	re=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		if(sushu(i)!=0)
			re++;	
	}
	printf("%d",re);
	return 0;
}
int sushu(int i)
{
	int b=2;
	while(b<i)
	{
		if(i%b==0)
			return 0;
		b++;
	}
	if(i%b!=0)
		return i;
}
