#include<stdio.h>

int clear(int a)
{
	int k,m;
	for(k=2;k<a/2;k++)
	{
		m = a%k;
		if(m==0)
		{
			return 0;
		}
		else continue;
	}
	return 1;
}

int main()
{
	int n,i;
	int count=0;
	
	scanf("%d",&n);
	for(i=3;i<n;i++)
	{
		if(clear(i))
		{
			count ++;
		}
	}
	printf("%d",count);
	return 0;
}
