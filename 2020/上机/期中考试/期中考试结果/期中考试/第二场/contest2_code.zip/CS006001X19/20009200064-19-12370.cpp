#include<stdio.h>
int main()
{
	int i,c=1,x,j,a;
	scanf("%d",&x);
	if(x==1)
	{
		printf("0");
		return 0;
	}
	if(x==2)
	{
		printf("0");
		return 0;
	}
	for(j=3;j<x;j++)
	{
		
		for(i=2;i<j;i++)
		{
			if(j%i!=0)
			a=1;
			else
			{
				a=0;
				break;	
			}			
		}
		if(a==1)
		{
		c=c+1;
		}
    }
	printf("%d",c);
	return 0;
}
