#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<string.h>
int syd(int n)
{
    if(n==1)
        return 1;
    if(n==2)
        return 1;
   else
   {for(int i=2; i<=(n-1); i++)
    {
        if(n%i==0)
        {
            return 0;
        }
    }
   }
    return 1;
}
int main()
{
    int n;
    scanf("%d",&n);
    int sum=0;
    if(n==1)
        printf("%d",sum);
        else if(n==2)
            printf("%d",sum);
       else if(n==3)
        printf("%d",sum);
    else
    {
        for(int i=2; i<=(n-1); i++)
        {
            if(syd(i)==1)
                sum++;
        }
        printf("%d",sum);
    }
    return 0;
}
