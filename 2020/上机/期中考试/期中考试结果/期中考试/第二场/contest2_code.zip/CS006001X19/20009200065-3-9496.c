#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c;
	scanf("%f %f %f",&a,&b,&c);
	
	float deta;
	deta=b*b-4*a*c;
	
	if(deta<0)
	{
		printf("no");
	}else if(deta==0)
	{
		printf("%.1f",-b/2*a);
	}else if(deta>0)
	{
		printf("%.1f %.1f",(-b+sqrt(deta))/2*a,(-b-sqrt(deta))/2*a);
	}
	return 0;
}
