#include<stdio.h>
int main()
{	int n,i,sum=0;
	scanf("%d",&n);
	if(n==1)
	{	sum=1;
	}
	for(i=1;i<n;i++)
	{	if(n%i==0)
		{	sum +=i;
		}
	}
	printf("%d",sum);
	return 0;
}
