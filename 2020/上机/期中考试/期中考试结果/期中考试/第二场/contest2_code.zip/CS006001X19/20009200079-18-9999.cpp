#include<stdio.h>
int main()
{
	int x,g,w=0;
	
	scanf("%d",&x);
	g=x;
	
	while((x/10)>0)
	{
		if((x%10)>w) w=x%10;
		x = x/10;
	}
	if (x>w) w=x;
	printf("%d ",w);
	w=9;
	
	while((g/10)>0)
	{
		if((g%10)<w) w=g%10;
		g = g/10;
	}
	if(g<w) w=g;
	printf("%d",w);
	
	return 0;
}
