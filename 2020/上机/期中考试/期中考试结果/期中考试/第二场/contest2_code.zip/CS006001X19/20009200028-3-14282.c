#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,x,y,z;
	scanf("%lf %lf %lf",&a,&b,&c);
	if(b*b-(4.0*a*c)<0)
	{
		printf("no");
	}
	else if(b*b-(4.0*a*c)==0)
	{
		x=-b/2.0*a;
		printf("%.1f",x);
	}
	else if(b*b-(4.0*a*c)>0)
	{
		z=sqrt(b*b-4*a*c);
		x=(-b+z)/2.0*a;
		y=(-b-z)/2.0*a;
		printf("%.1f %.1f",x,y);
	}
	return 0;
}
