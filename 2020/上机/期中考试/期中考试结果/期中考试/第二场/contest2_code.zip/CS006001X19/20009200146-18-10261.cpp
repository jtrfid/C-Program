#include<stdio.h>
int main()
{
	int n,a,max=0,min=0,t,b;
	
	scanf("%d",&n);
	a=n;
	b=n;
	max=b%10;
	min=b%10;
	while(a>0)
	{
		t=a%10;
		if(t>max)
		{
			max=t;
		}
		if(t<min)
		{
			min=t;
		}
		a=a/10;
		
	}
	printf("%d %d",max,min);
	return 0;
	
}
