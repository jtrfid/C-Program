#include<stdio.h>
#include<math.h>
int main()
{
	int n,a,i;
	scanf("%d",&n);
	int d=0,x=9;
	for (i=1;n!=0;i++)
	{
		a=n%10;
		n=n/10;
		if(x>a)
		{
			x=a;
		}
		if(d<a)
		{
			d=a;
		}
	}
	printf("%d %d",d,x);
	
	
	return 0;
}
