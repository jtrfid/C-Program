#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,d,e,f;
	scanf("%lf %lf %lf",&a,&b,&c);
	e=b*b-4*a*c;
	if(e<0)
	printf("no")
	if(e=0)
	{
		d=(-1*b)/(2*a);
		printf("%.1f",d);
	}
	return o;
}
