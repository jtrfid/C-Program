#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int count=0;
	int i,j,x;
	if(n>=2)count++;
	for(i=3;i<n;i++)
	{
		j=2;
		while(i%j!=0)
		{
			j++;
		}
		if(j==i)count++;
	}
	
	printf("%d",count);

	return 0 ;
}
