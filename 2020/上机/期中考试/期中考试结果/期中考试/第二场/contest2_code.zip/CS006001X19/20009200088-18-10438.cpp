# include <stdio.h>
# include <math.h>
int main ()
{
	int x,max=0,min=0,s;
	scanf ("%d",&x);
	if (x<pow(2,32))
	{
		while (x>0)
		{
		    s=x%10;
			if(s>max)
			{
				max=s;
			}
		
			if(s<min)
			{
				min=s;
			}
			x=x/10;
	
		}
		printf("%d %d",max,min);
	}
	return 0;
}
