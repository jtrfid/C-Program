#include<stdio.h>
int main()
{
	int n;
	int a,max=0,min=9;
	scanf("%d",&n);
	while(n>0)
	{
		a=n%10;
		if(a>max){
			max=a;
		}
		else if (a<min){
			min=a;
		}
		n/=10;
	}
	printf("%d %d",max,min);
	return 0;
}
