#include<stdio.h>
int main()
{
	int n;
	int max,min,i;
	int k1,k2,k;
	
	scanf("%d",&n);
	k1 = n%10;
	n = (n-k1)/10;
	k2 = n%10;
	n = (n-k2)/10;
	if(k1<k2)
	{
		max = k2;
		min = k1;
	}
	else if(k1>k2)
	{
		max = k1;
		min = k2;
	}
	else
	{
		max = k1;
		min = k2;
	}
	while(n!=0)
	{
		k = n%10;
		n = (n-k)/10;
		if(k>max)
		{
			max = k;
		}
		else if(k<min)
		{
			min = k;
			
		}
		else continue;
	}
	printf("%d %d",max,min);
	return 0;
}
