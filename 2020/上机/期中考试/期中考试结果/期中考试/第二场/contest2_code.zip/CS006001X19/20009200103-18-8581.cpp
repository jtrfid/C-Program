#include<stdio.h>
int main()
{
	int n,a[18],i=0,max,min,j;
	scanf("%d",&n);
	while(n!=0)
	{
		a[i]=n%10;
		n/=10;
		i++;
	}
	max=a[0];
	min=a[0];
	for(j=0;j<i;j++)
	{
		if(a[j]>max) max=a[j];
		if(a[j]<min) min=a[j];
	}
	printf("%d %d",max,min);
	return 0;
}
