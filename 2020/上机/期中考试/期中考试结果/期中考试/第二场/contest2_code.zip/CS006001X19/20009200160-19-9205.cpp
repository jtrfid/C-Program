#include<stdio.h>
int main()
{
	int n,i,j,k,count=0,x;
	scanf("%d",&n);
	if(n==1)
	{count=0;}
	if(n==2)
	{count=1;}
	if(n>=3)
	{count=1;
	for(i=3;i<=n;i++)
	{
		for(k=2;k<i;k++)
		{
			x=i%k;
			if(x==0)
			{break;}
			if(k==i-1)
			{count++;}
		}
	}
    }
	printf("%d",count);
	return 0;
}
