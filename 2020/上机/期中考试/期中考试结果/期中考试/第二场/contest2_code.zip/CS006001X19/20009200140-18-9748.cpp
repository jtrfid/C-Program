#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[10],i=0;
	int min=9,max=0;
	while(n!=0)
	{
		int tn=n%10;
		n/=10;
		if(tn<min)
		{
			min=tn;
		}
		if(tn>max)
		{
			max=tn;
		}
	}
	printf("%d %d",max,min);
	return 0;
}
