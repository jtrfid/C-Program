#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,derta;
	double x1,x2;
	
	scanf("%f %f %f",&a,&b,&c);
	derta = b*b-4*a*c;
	if(derta<0)
	{
		printf("no");
	}
	else if(derta==0)
	{
		x1 = b*(-1)/(a*2);
		printf("%f",x1);
	}
	else
	{
		x1 = derta+b*(-1)/2*a;
		x2 = derta+b*(-1)/2*a;
		printf("%.1f %.1f",x1,x2);
	}
	return 0;
}
