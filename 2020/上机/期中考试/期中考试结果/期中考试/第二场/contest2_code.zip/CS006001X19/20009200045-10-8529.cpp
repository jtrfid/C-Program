#include<cstdio>
#include<cmath>
#define N 10000
using namespace std;
int main()
{
	int x,i=0;
	int a[N];
	int max=0,min=10;
	
	scanf("%d",&x);
	
	while(x>0)
	{
		a[i]=x%10;
		x/=10;
		if(a[i]>max)
		max=a[i];
		if(a[i]<min)
		min=a[i];
		i++;
	}
	printf("%d %d",max,min);
	
	

	return 0;
}
