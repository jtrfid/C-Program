#include<stdio.h>
int main()
{
	long int x,count=0,j;
	scanf("%d",&x);
	for(int i=1;i<=x;i++)
	{
		for( j=2;j<i;j++)
		{
			if(i%j==0)
			break;
		}
		if(j==i)
		{
			count++;
		}
	
	}
	printf("%d",count);
	return 0;
}
