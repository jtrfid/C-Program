#include<stdio.h>
int main()
{
	int x,max,d,min;
	scanf("%d",&x);
	max=x%10;
	min=x%10;
	while(x)
	{
		d=x%10;
		if(d>max)
		{
			max=d;
		}
		if(d<min)
		{
			min=d;
		}
		x/=10;
	}
	printf("%d %d",max,min);
	return 0;
}
