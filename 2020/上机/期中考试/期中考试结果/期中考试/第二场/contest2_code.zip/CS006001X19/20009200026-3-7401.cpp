#include<stdio.h>
#include<math.h>
int main(){
	float a,b,c,delta=0;
	scanf("%f%f%f",&a,&b,&c);
	delta=b*b-4*a*c;
	//printf("%f %f %f %f\n",a,b,c,delta);
	if(delta>0){
		printf("%.1f %.1f",((-b+sqrt(delta))/(2*a)),((-b-sqrt(delta))/(2*a)));
	}
	else if(delta==0)printf("%.1f",-b/(2*a));
	else printf("no");
	return 0;
}

