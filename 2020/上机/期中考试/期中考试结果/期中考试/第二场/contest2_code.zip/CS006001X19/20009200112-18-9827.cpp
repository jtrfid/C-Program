#include<stdio.h>
#include<math.h>
int main()
{
	int n,s,max,min;
	scanf("%d",&n);
	s=0;
	s=n%10;
	n=(n-s)/10;
	
	min=s;
	max=s;
	for(;n!=0;)
	{
		n=(n-s)/10;
		s=n%10;
		if(s>max)
		max=s;
		if(s<min)
		min=s;
	}
	printf("%d %d",max,min);
	return 0;
}
