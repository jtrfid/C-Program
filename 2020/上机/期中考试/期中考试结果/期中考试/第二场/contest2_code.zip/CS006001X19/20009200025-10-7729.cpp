#include<stdio.h>
#include<math.h>
#include<algorithm>
int main()
{
   int a;
   scanf("%d",&a);
   int sum=0;
   for(int i=1;i<=(a-1);i++)
   {
       if(a%i==0)
       {
           sum=sum+i;
       }
   }
   printf("%d",sum);
    return 0;
}
