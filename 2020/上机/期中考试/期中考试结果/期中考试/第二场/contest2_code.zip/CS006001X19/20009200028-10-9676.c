#include<stdio.h>
int main()
{
	int m,n,i,sum=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		m=n%i;
		if(m==0)
		{
			sum+=i;
		}
	}
	printf("%d",sum);
	return 0;
}
