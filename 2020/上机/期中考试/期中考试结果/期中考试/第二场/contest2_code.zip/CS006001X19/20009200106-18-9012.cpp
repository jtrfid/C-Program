#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[20];
	int i=0;
	while(n!=0)
	{
		a[i]=n%10;
		i++;
		n=n/10;
	}
	int max=a[0];
	int min=a[0];
	for(int j=1;j<i;j++)
	{
		if(a[j]>max)
		{
			max=a[j];
		}
	}
	for(int j=1;j<i;j++)
	{
		if(a[j]<min)
		{
			min=a[j];
		}
	}
	printf("%d %d",max,min);
	
	return 0;
}
