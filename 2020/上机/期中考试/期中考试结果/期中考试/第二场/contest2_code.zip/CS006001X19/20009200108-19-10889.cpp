#include<stdio.h>
int factor(int p);
int main()
{
	int n,i=1;
	int sum=0;
	scanf("%d",&n);
	if (n==1)	printf("0");
	else{	
		while(1)
		{
			sum+=factor(i);	
			i++;
			if(i==n)
			{
				printf("%d",sum-1);
				break;
			}
		}
	}
	return 0;
}
int factor(int p)
{
	int c;
	for(c=2;c<p;c++)
	{
		if (p%c==0)
		return 0;
	}
	return 1;
}
