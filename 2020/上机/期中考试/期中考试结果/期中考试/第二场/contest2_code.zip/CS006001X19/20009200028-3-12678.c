#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,x,y;
	scanf("%lf %lf %lf",&a,&b,&c);
	if(b*b-(4*a*c)<0)
	{
		printf("no");
	}
	if(b*b-(4*a*c)==0)
	{
		x=-b/2.0*a;
		printf("%.1f",x);
	}
	if(b*b-(4*a*c)>0)
	{
		x=(-b+pow((b*b-4*a*c),1/2))/2.0*a;
		y=(-b-pow((b*b-4*a*c),1/2))/2.0*a;
		printf("%.1f %.1f",x,y);
	}
	return 0;
}
