#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,d,r1,r2;
	
	scanf("%f%f%f",&a,&b,&c);
	d=b*b-4*a*c;
	if (d<0)
	{
		printf("no");
		
	}
	else if(d==0)
	{
		r1=(-b/2)/a;
		printf("%.1f",r1);
	}
	else if(d>0)
	{
		d=sqrt(d);
		r1=((-b+d)/2)/a;
		r2=((-b-d)/2)/a;
		printf("%.1f %.1f",r1,r2);
	}
	
	
	return 0;
}
