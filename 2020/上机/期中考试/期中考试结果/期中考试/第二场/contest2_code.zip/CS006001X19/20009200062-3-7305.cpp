#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,m,n;
	scanf("%lf %lf %lf",&a,&b,&c);
	if(b*b-4*a*c>0)
	{
		m=(-b+sqrt(b*b-4*a*c))/2*a;
		n=(-b-sqrt(b*b-4*a*c))/2*a;
		printf("%.1lf %.1lf",m,n);
	}
	else if(b*b-4*a*c==0)
	{
		m=-b/2*a;
		printf("%.1lf",m);
	}
	else {
		printf("no");
	}
	return 0;
}
