#include <stdio.h>

int main()
{
	int n,i,j,m=1,a=1;
	scanf("%d",&n);
	if(n==1)printf("0");
	else if(n==2)printf("1");
	else if(n==3)printf("2");
	else
	{
	for (i=3;i<n;i++)
	{
		for(j=2;j<i;j++)
		{
			if (i%j==0)
			break;
			if (j==i-1)
			m++;
		}
	}
	printf("%d",m);
	}
	return 0;
}
