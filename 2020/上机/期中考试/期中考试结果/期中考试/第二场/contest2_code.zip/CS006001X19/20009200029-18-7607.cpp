#include<stdio.h>
int main()
{
	int n ,max,min,digit=0,t;
	scanf("%d",&n);
	t = n;
	while(n!=0){
		n/=10;
		digit++;
	}
	n = t;
	int a[digit];
	max=n%10;
	min=n%10;
    for(int i=0;i<digit;i++){
	    a[i]=n%10;
	    n/=10;
	    if(max<a[i]){
	    	max=a[i];
	    }
	    if(min>a[i]){
	    	min=a[i];
	    }
        }
	printf("%d %d",max,min);
	return 0;
}

