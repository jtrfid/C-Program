#include<stdio.h>
int main()
{
	int n,i,j,sum;
	scanf("%d",&n);
	for(i=2,sum=0;i<n;i++)
	{
		sum++;
		for(j=2;j<=i-1;j++)
		{
			if(i%j==0)
			{
				sum--;
				break;
			}
			
		}
	}
	printf("%d",sum);
	return 0;
	
	
}
