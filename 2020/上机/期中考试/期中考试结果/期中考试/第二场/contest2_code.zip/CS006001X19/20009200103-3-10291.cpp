#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,x1,x2,delt;
	scanf("%lf%lf%lf",&a,&b,&c);
	if(a==0&&b==0)
	{
		printf("no");
		return 0;
	} 
	if(a==0&&b!=0)
	{
		printf("%.1f",-c/b);
		return 0;
	} 
	delt=b*b-4*a*c;
	if(delt==0)
	{
		x1=x2=(-b+pow(delt,0.5))/(2*a);
		printf("%.1f",x1);
	}
	if(delt<0) printf("no");
	if(delt>0)
	{
		x1=(-b+pow(delt,0.5))/(2*a);
		x2=(-b-pow(delt,0.5))/(2*a);
		printf("%.1f %.1f",x1,x2);
	}
	return 0;
}
