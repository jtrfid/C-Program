#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,d,e,f;
	scanf("%f %f %f",&a,&b,&c);
	d=b*b-4*a*c;
	if(d<0)
	printf("no");
	if(d==0)
	printf("%.1f",-b/(2*a));
	if(d>0)
	{
		e=(-b+sqrt(d))/(2*a);
		f=(-b-sqrt(d))/(2*a);
		printf("%.1f %.1f",e,f);
	}
	return 0;
}
