#include<stdio.h>
#include<math.h>
#include<algorithm>
int main()
{
   double a,b,c;
   scanf("%lf %lf %lf",&a,&b,&c);
double m=b*b-4*a*c;
   if(m<0)
   {
       printf("no");
   }
   else if(m==0)
   {
       printf("%.1lf",-b/2*a);

   }
   else
    {
        printf("%.1lf %.1lf",(-b+sqrt(m))/(2*a),(-b-sqrt(m))/(2*a));
    }
    return 0;
}
