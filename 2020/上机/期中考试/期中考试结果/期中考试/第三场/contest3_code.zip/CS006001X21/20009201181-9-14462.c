#include<stdio.h>
int main()
{
	int n,sum=0,i;
	scanf("%d",&n);
	for(i=0;i<10;i++)
	{
		sum+=n%10;
		n=n/10;
	}
	printf("%d",sum);
	return 0;
}
