#include <cstdio>
#include <cstring>
#include <cctype>

char buf[10000000];
int main() {
  int n; scanf("%d", &n);
  // int len = strlen(buf);
  int odd = 0, even = 0;
  while(true) {
    char c = getchar();
    if(c == '!') break;
    if(!isalpha(c)) continue;
    // if(buf[i] < 'a' || buf[i] > 'z') continue;
    int remainder = (int(c)) % n;
    if(remainder & 1) {
      odd ++;
    } else {
      even ++;
    }
  }
  printf("%d %d\n", odd, even);
  return 0;
}
