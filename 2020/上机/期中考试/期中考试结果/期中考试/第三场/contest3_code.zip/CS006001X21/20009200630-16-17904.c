#include<stdio.h>
int main(){
	int N,y,z,sum1=0,sum2=0;
	char x;
	scanf("%d\n",&N);
	do{
		scanf("%c",&x);
		z=(int)x;
		if(x>='a'&&x<='b'){
		y=z%N;
		if(y%2){
		sum1++;	
		}
		if(y%2==0){
		sum2++;
	    }
	  }
	}while(x!='!');
	printf("%d %d",sum1,sum2);
	return 0;
}
