#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int s=0,i;
	for(i=0;i<9;i++){
		if(n!=0){
			s+=n%10;
			n=n/10;
		}
		
	}
	printf("%d",s);
	return 0;
}
