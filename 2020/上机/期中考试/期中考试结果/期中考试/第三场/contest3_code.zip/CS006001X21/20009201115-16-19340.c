#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	int t;
	int sum1=0;
	int sum2=0;
	char a;
	while(a!='!'){
		scanf("%c",&a);
		if(a<='z'&&a>='a'||a<='Z'&&a>='A'){
			t=a%n;
			if(t%2==0){
				sum1++;
			}else{
				sum2++;
			}
		}
	}
			
	printf("%d %d",sum2,sum1);
	return 0;
}
