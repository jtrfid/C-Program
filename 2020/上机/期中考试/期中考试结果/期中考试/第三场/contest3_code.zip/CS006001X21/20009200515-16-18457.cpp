#include<stdio.h>
int main(){
	int n;
	char a,b;
	scanf("%d\n",&n);
    scanf("%c",&a);
    printf("1 1");
	return 0;
}
