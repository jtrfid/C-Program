#include<stdio.h>
int main(){
	char c;
	int j=0,ou=0,pan=0,n;
	scanf("%d",&n);
	while(1)
	{	 
		scanf("%c",&c);
		if(c=='!')
		{break;}
		if(('A'<=c&&c<='Z')||('a'<=c&&c<='z'))
		 {pan=c%n;
		 pan=pan%2;
			if(pan==1)
			{j++;
			}
			else
			{
			ou++;
			}
		 }	
	
}
		printf("%d %d",j,ou);
  return 0;
}
