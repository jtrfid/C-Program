#include<stdio.h>
int main(){
	char c;
	int j=0,ou=0,pan;
	while(1)
	{
		scanf("%c",&c);
		if(c=='!')
			{break;}
		if('a'<=c<='z'||'A'<=c<='Z')
			{pan=c%2;
			if(pan==1)
			{j++;
			}
			else{
			ou++;
			}
		}
	}
		printf("%d%d",j,ou);
return 0;
}
