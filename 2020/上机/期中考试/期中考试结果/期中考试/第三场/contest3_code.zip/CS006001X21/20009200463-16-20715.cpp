#include<stdio.h>
#define N 10000

int main(){
	int q,i=0,m=0,j=0,k=0;
	char a[N];
	scanf("%d",&q);
	while(i<N){
		scanf("%c",&a[i]);
		m++;
		if(a[i]=='!') break;
		i++;
	}
	for(i=0;i<m;i++){
		if(a[i]>96&&a[i]<124){
			if((a[i]/q)%2==0) k++;
			else j++;
		}
		if(a[i]>64&&a[i]<81){
			if((a[i]/q)%2==0) k++;
			else j++;
		}
	}
	printf("%d %d",j,k);
	return 0;
}
