#include <stdio.h>
int main(){
	int a,n,s,b;
	scanf("%d %d",&a,&n);
	int i=2;
	b=a;
	s=a;
	for (i=1;i<n;i++){
		b=b*10+a;
		s=s+b;
	}
	printf("%d",s);
	
	return 0;
}

