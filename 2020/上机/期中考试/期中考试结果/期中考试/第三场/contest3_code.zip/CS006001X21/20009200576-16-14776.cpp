#include <cstdio>
#include <cstring>
#include <cctype>

char buf[1000000];
int main() {
  int n; scanf("%d%s", &n, buf);
  int len = strlen(buf);
  int odd = 0, even = 0;
  for(int i = 0; i < len; i ++) {
    if(!isalpha(buf[i])) continue;
    int remainder = (int(buf[i])) % n;
    if(remainder & 1) {
      odd ++;
    } else {
      even ++;
    }
  }
  printf("%d %d\n", odd, even);
  return 0;
}
