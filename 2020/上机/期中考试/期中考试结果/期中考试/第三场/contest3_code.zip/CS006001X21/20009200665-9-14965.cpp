#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d",&n);
	int sum=0;
	while(n)
	{
		m=n%10;
		n=n/10;
		sum+=m;
	} 
	printf("%d\n",sum);
	return 0;
}
