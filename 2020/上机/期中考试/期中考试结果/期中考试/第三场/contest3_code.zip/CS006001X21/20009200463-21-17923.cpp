#include<stdio.h>

int main(){
	int s,t=0,a,n,i,j=0,m=1;
	scanf("%d %d",&a,&n);

		for(i=1;i<n;i++){
		m=10*m+1;
		t+=m;
		}
		t+=1;

	s=a*t;
	printf("%d",s);
	return 0;
}
