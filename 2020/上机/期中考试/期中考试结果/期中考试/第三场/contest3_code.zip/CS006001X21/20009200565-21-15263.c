#include<stdio.h>
int main()
{
	int a,b,n,s=0;
	scanf("%d %d",&a,&n);
	b=a;
	while(n>0){
		
    s=s+a;
	a=a*10+b;
	n--;
	}
	printf("%d",s);
	return 0;
}
