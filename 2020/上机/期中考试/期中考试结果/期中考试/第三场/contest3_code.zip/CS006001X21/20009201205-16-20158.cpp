#include<stdio.h>
int main()
{
	int a,b,c;
	int d=0,e=0;
	scanf("%d %d",&a,&b);
	for(c=0;c<b;b++)
	{
		d=d*10+a;
		e=e+d;
		
	}
	printf("%d",e);
	return 0;
	
}
