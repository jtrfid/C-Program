#include<stdio.h>
int main()
{
	char a;
	int n=0,i,b,m=0;
	scanf("%d",n);
	for(i=1;i>=0;i++)
	{
		scanf("%c",&a);
		if(a=='!') break;
		else if(a>=97&&a<=(97+26))
		{
			if((a%n)%2==0) m=m+1;
			else n==n+1;
		}
		else if(a>=(97+32)&&a<=(97+26+32))
		{
			if((a%n)%2==0) m=m+1;
			else n==n+1;
		}
		else continue;
	}
	printf("%d %d",n,m);
	return 0;
}
