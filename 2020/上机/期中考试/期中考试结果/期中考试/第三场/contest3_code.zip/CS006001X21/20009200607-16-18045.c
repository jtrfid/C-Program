#include <stdio.h>
int main(){
	int N,m,x,y;
	x=0;
	y=0;
	char ch;
	scanf("%d",&N);
	int i;
	for(i=0;i<9;i++){
		scanf("%c",&ch);
	     if(ch>='a'&&ch<='z'){
			if((ch%N)%2==0)
			x++;
			else
			y++;
		}
		else if(ch>='A'&&ch<='Z'){
			if((ch%N)%2==0)
			x++;
			else
			y++;
		}
		else if(ch=='!')
		break;
		else x=x;
		y=y;
	}
	printf("%d %d",y,x);
	return 0;
	}
