#include<stdio.h>
#include<math.h>
int main()
{
	int i,a,b,c,n;
	b=0;
	scanf("%d%d",&a,&n);
	c=a;
	for(i=1;i<=n;i++)
	{
		b=b+c;
		c=c*10+a;
	}
	printf("%d",b);
	return 0;
}
