#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c=0,i,sum=0;
	scanf("%d%d",&a,&b);
	for(i=1;i<=b;i++){
		c=a;
		a=a*10+a;
		sum=sum+c;
	}
	printf("%d",sum);
	
	
	return 0;
}
