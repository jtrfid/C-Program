#include<stdio.h>
int main()
{
	int N,i,j,c=0,d=0;
	scanf("%d",&N);
	char a[100];
	scanf("%c%c%c%c%c",&a[1],&a[2],&a[3],&a[4],&a[5]);
	for(j=0;j<=4;j++){
		if(a[j]%N==0){
			c++;
		} else if(a[j]%N==1){
			d++;
		}
	}
	printf("%d %d",d,c);
	return 0;
}
