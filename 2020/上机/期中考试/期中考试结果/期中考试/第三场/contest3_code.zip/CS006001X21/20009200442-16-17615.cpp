#include<iostream>
#include<cstdio>
#include<string>
#define maxn 1005
using namespace std;

int main(){
	int a[5],t,yu;
	a[0]=0;a[1]=0;
	string s;
	int i;
	cin>>yu;
	getline(cin,s);
	getline(cin,s);
	for(i=0;i<s.size();i++){
		if(s[i]=='!')break;
		if((s[i]>='a'&&s[i]<='z')){
			t=s[i]-'A'+65;
			t=t%yu;
			t=t%2;
			a[t]++;
		}
	}
	printf("%d %d",a[1],a[0]);
	return 0;
}
