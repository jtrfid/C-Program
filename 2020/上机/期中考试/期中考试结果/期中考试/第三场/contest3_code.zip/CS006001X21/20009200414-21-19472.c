#include<stdio.h>
#include<math.h>
int f(int a,int n)
{
	int i,k,sum;
	for(i=0,sum=0;i<=n;i++)
	{
		k=a*pow(10,i);
		
		sum+=k;
	}
	return sum/10;
}
int main()
{
	int n,a,sn,sn1;
	scanf("%d %d",&a,&n);
	sn=f(a,n);
	sn1=sn+sn/10+sn/100+sn/1000+sn/10000+sn/100000+sn/1000000+sn/10000000+sn/100000000+sn/1000000000;
	printf("%d",sn1);
	return 0;
	
	
}
