#include<iostream>
#include<cstdio>

using namespace std;

int main()
{
	int a, n, t;
	scanf("%d%d", &a, &n);
	long long ans=0;
	t=a;
	while(n--)
	{
		ans+=a;
		a=a*10+t;
	}
	cout<<ans;
	return 0;
}
