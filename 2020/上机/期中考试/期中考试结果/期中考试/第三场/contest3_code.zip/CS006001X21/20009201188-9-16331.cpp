#include<math.h>
#include<stdio.h>
int main()
{
  int i,n,sum=0,t;
  scanf("%d",&n);
  for(i=0;i<9;i++)
  {
  	t=n/pow(10,i);
  	sum=sum+t%10;
  } 	
  printf("%d",sum);
  return 0;
}
