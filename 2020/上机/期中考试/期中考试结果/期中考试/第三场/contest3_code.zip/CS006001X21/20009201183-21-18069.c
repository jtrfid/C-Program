#include<stdio.h>
#include<math.h>
int main(){
	int a,n,i=0,sum=0,b;
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++){
		b=a*pow(10,i);
		sum=sum+b;
		b=0;
}
   sum=sum+2;
	printf("%d",sum);
	return 0;
}
