#include <stdio.h>

int main(){
	int N,i,c,d,b[100];
	char a[100];
	scanf("%d",&N);
	for(i=0;i<N;i++){
		scanf("%c",&a[i]);
	}
	while(a[i]!='!'){
		for(i=0;i<N,a[i]!='!';i++){
			if((a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')){
				b[i]=a[i]%N;
			}
		}
	}
	for(i=0;i<N;i++){
		if(b[i]%2==0) c++;
		if(b[i]%2!=0) d++;
	}
	printf("%d %d",d,c);
	return 0;
}
