#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum = 0;
    long int a,n,i = 1;
    scanf("%d %d",&a,&n);
    int k = a;
    while(i <= n)
    {
        sum += a;
        a = (a * 10) + k;
        i++;
    }
    printf("%d",sum);
    return 0;
}
