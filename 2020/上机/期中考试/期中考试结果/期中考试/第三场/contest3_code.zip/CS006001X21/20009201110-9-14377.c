#include<stdio.h>
int main()
{
	int m=0,n,i;
	scanf("%d",&n);
	for(i=1;i>=0;i++)
	{
		if(n<1) break;
		else
		{
			m=m+n%10;
			n=n/10;
		}
	}
	printf("%d",m);
	
	return 0;
}
