#include<stdio.h>
int main()
{
	int N, i=0, a=0, b=0, g;
	char c[300];
	scanf("%d",&N);
	scanf("%d",&c[i]);
	while(c[i]!='!')
	{
		if(c[i]>=97&&c[i]<=122)
		{
			g=c[i]%N;
			if(g%2==0)
			b++;
			else
			a++;
		}
		i++;
		scanf("%d",&c[i]);
	}
	printf("%d %d",a,b);
	return 0;
}
