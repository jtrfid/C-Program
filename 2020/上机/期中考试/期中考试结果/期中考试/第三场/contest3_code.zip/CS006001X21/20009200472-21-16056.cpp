#include<stdio.h>
int main()
{
	int a,n;
	int i,j;
	int sn=0,b=0;
	scanf("%d %d",&a,&n);
	for(j=1;j<=n;j++){
		b=b*10+a;
		sn=sn+b;
	}
	printf("%d",sn);
	return 0;
}
