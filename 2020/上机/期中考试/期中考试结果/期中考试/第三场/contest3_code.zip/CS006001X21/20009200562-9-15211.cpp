#include<stdio.h>
int main()
{
	int n,i,j,sum=0,w;
	scanf("%d",&n);
	if(n==0)
	{
		sum=0;
	}
	else
	{
	
	while(n>0)
	{
		w=n%10;
		sum=sum+w;
		n=n/10;
	}
    }
	printf("%d",sum);
	
    
	
	
	
	return 0;
}
