#include<stdio.h>
int main(){
	int n,a,i,sum=0,y=0; 
	scanf("%d %d",&a,&n);
	for(i=1;i<=n;i++){
		y=10*y+a;
		sum+=y;
	}
	printf("%d",sum);
	return 0;
}
