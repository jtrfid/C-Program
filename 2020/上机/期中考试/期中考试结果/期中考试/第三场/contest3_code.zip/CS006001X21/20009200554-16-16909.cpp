#include<stdio.h>
int main()
{
	int s,n,ji=0,ou=0,y;
	char a;
	 scanf("%d",&n);

	while(1)
	{    
	 scanf("%c",&a);
		if(a=='!')
		    break;
		if(a<='z'&&a>='a'||(a<='Z'&&a>='A'))
		//  
		   {
		   	   y=a%n;
		   	   if(y%2==0)
		   	   ou++;
		   	   if(y%2==1)
		   	   ji++;
		   }
		
	}
	printf("%d %d",ji,ou);
	return 0;
	
}
