#include <stdio.h>

int main(){
	int n,sum=0,i,t;
	scanf("%d",&n);
	for(i=0;i<=9;i++){
		t=n%10;
		sum=sum+t;
		n=n/10;
	}
	printf("%d",sum);
	return 0;
}
