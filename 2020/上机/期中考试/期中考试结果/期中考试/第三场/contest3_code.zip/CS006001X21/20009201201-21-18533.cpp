#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c,d,h=0,f=0,t;
	scanf("%d%d",&a,&b);
	for(c=1;c<=b;c++)
	{
	    d=pow(10,(c-1));
	    h+=d;
	    t=h;
	    f+=t;
	}
	if(b>2)
	{
		f=f+(b-2);
	}
	printf("%d",a*f);
	return 0;
}
