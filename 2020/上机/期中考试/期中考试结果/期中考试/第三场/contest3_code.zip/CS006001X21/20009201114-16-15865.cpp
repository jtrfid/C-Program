#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>


int main()
{
	char ch[100000];
	int f=1,N;
	scanf("%d",&N);
	while(1)
	{
		scanf("%c",&ch[f]);
		if(ch[f]=='!')break;
		f++;
	} 
	int j=0,o=0;//����ż�� 
	for(int i=1;i<=f;i++)
	{
		if(ch[i]<65 || ch[i]>122 || (90<ch[i] && ch[i]<97))continue;
		int ans=(ch[i]%N)%2;
		if(ans)j++;
		else o++;
	}
	printf("%d %d",j,o);
	return 0;
}
