#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c,d,e=0,f;
	scanf("%d%d",&a,&b);
	for(c=1;c<=b;c++)
	{
	    if(c==1)
	    {
	    	e=a;
	    }
	    else
	    {
		d=a+a*pow(10,(c-1));
		e+=d;
	    }
	}
	printf("%d",e);
	return 0;
}
