#include <stdio.h>
int main(){
	int N,m;
	char a[10];
	scanf("%d",&N);
	int i;
	for(i=0;i<9;i++){
		scanf("%c",&a[i]);
		if(a[i]=='!')
		break;
	}
	int j,x,y;
	x=0;
	y=0;
	for(j=0;j<i;j++){
		if(a[j]>='a'&&a[j]<='z'){
		if(a[j]%2==0)
		x++;
		else y++;
		}
		if(a[j]>='A'&&a[j]<='Z'){
			if(a[j]%2==0)
			x++;
			else
			y++;
		}
		else x=x;
		y=y;
	}
	printf("%d %d",y,x);
	return 0;
}
