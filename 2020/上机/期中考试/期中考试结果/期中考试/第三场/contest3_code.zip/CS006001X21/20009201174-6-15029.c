#include<stdio.h>
#include<math.h>

int main()
{
	float lirun=0.0,jiangjin=0.0,p1=0.0,p2=0.0,p3=0.0,p4=0.0;
	
	p1=100000*0.1;
	p2=100000*0.075;
	p3=200000*0.05;
	p4=400000*0.03;
	
	scanf("%f",&lirun);
	
	if(lirun<=100000)
		jiangjin=lirun*0.1;
	else if(lirun<=200000)
		jiangjin=p1+(lirun-100000)*0.075;
	else if(lirun<=400000)
		jiangjin=p1+p2+(lirun-200000)*0.05;
	else if(lirun<=800000)
		jiangjin=p1+p2+p3+(lirun-400000)*0.03;
	else
		jiangjin=p1+p2+p3+p4+(lirun-800000)*0.01;
	
	printf("%.1f\n",jiangjin);
	
	return 0;
	
}
