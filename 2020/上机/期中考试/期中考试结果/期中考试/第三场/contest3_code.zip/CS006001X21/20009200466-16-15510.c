#include<stdio.h>
int main(){
	char c;
	int n,res;
	int a = 0,b = 0;
	scanf("%d",&n);
	while(1){
		scanf("%c",&c);
		if(c == '!'){
			break;
		}
		if(c>='A'&&c<='z'){
			res = c % n;
			if(res%2 == 0){
				b+=1;
			}else{
				a+=1;
			}
		}
	}
	printf("%d %d",a,b);
	return 0;
}