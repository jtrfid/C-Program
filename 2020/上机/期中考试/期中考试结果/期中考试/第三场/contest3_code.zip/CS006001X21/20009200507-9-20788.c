#include<stdio.h>
int main()
{
	int a,n,sn=0,sum,c;
	int i;
	scanf("%d %d",&a,&n);
	for(i=2;i<=n;i++)
	{
		sum=10^i*a;
		c=c+sum;
	}
	sn=sn+c+a;
	printf("%d",sn);
	return 0;
	
}
