#include <stdio.h>

int main(){
	int a,n,i;
	scanf("%d %d",&a,&n);
	int sum=0,b;
	b=a;
	for(i=1;i<=n;i++){
		sum=sum+b;
		b=b*10+a;
	}
	printf("%d",sum);
	return 0;
}
