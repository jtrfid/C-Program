#include <stdio.h>
int main ()
{
	int N,a,i=0,j=0,k;
	scanf("%d\n",&N);
	char ch;
	for(k=0;k>=0;k++)
	{
		ch=getchar();
	  if(ch>=65&&ch<=90)
	 {
		   if(ch!='!')
	    {
		    a=ch%N;
		    if(a%2==1)
		    j++;
		    if(a%2==0)
	     	i++;
	    }
    }
    if(ch>=97&&ch<=122)
	 {
		   if(ch!='!')
	    {
		    a=ch%N;
		    if(a%2==1)
		    j++;
		    if(a%2==0)
	     	i++;
	    }
	       }
	     if(ch==33)
		  break; 
    }
	printf("%d %d",j,i);
	return 0;
	
}
