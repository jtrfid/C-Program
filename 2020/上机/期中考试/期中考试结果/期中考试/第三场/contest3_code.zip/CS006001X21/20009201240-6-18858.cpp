#include<stdio.h>
int main()
{
	float x,n;
	scanf(" %f",&x);
	if(x<=100000){
		n=x*0.1;
		printf("%.1f",n);
	} 
	else if(100000 <x&&x<=200000){
		n=(n-100000)*0.075;
		printf("%.1f",n=n+10000);
	}
    else if(200000 <x&&x<=400000){
    	n=(n-200000)*0.05;
    	printf("%.1f",n=n+17500);
    }
    else if(400000 <x&&x<=800000){
    	n=(n-400000)*0.03;
    	printf("%.1f",39500.0);
    }
    else if(800000 <x){
    	n=(n-800000)*0.01;
    	printf("%.1f",n=n+39500);
    }
	return 0;
}
