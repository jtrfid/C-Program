#include <stdio.h>
#include <stdlib.h>
int main(void)
{float a,b;
printf("��������");
scanf("%d",&a);

if(a<=100000)
b=a*0.1;
if(a>=100000&&a<=200000)
b=10000+(a-100000)*0.75;
if(a>=200000&&a<=400000)
b=17500+(a-200000)*0.5;
if(a>=400000&&a<=800000)
b=27500+(a-400000)*0.3;
if(a>=800000)
b=39500+(a-800000)*0.1;

printf("Ӧ���Ž���%.1f",b);
return 0;
}
