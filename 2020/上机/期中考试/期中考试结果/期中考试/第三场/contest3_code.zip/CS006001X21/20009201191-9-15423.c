#include<stdio.h>
int main(){
	int n,t,sum=0;
	scanf("%d",&n);
	while(n>9){
		t=n%10;
		sum=t+sum;
		n=n/10;
	}
	printf("%d",sum+n);
	return 0;
}
