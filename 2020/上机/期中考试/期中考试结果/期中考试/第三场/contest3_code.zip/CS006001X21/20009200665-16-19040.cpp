#include<stdio.h>
int main()
{
	int n;
	char ch;
	scanf("%d",&n);
	int count1=0,count2=0;
	int m;
	while(1)
	{
		scanf("%c",&ch);
		if(ch!='!')
		{
			if((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z'))
			{
				m=int(ch)%n;
				if(m%2!=0) count1++;
				else count2++;
			}
		}
		else break;
	}
	printf("%d %d\n",count1,count2);
	return 0;
}

