#include<stdio.h>
int main()
{
int a,n,Sn=0,sum=0,i;
scanf("%d%d",&a,&n);
for(i=1,i<=n,i++;;)
{sum=sum*10+a;Sn=Sn+sum;
};
printf("%d",&Sn);
return 0;
}
