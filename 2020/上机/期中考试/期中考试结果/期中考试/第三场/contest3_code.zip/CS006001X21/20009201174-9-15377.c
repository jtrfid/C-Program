#include<stdio.h>
#include<math.h>

int main()
{
	long m=0,sum=0;
	
	scanf("%ld",&m);
	
	while(m)
	{
		sum+=(m%10);
		m/=10;	
	}
	
	printf("%ld\n",sum);
	
	return 0;
}
