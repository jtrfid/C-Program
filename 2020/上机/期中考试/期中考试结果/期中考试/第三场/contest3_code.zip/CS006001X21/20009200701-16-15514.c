#include<stdio.h>

int main()
{
	int n,i,j,t,b1,b2;
	b1=b2=0;
	char a[200];
	scanf("%d",&n);
	for(i=1;;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!')
			break;
	}
	for(j=1;j<=i;j++)
	{
		if((a[j]>='A'&&a[j]<='Z')||(a[j]>='a'&&a[j]<='z'))
		{
			t=a[j]%n;
			if(t%2==0)
				b2++;
			else
				b1++;
		}
	}
	printf("%d %d",b1,b2);
	return 0;
}
