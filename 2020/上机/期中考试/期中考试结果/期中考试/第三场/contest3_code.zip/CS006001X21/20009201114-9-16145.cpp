#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>


int main()
{
	int n;
	scanf("%d",&n);
	int add=0;
	while(n)
	{
		add+=(n%10);
		n/=10;
	} 
	printf("%d",add);
	return 0;
}
