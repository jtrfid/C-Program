#include<stdio.h>
#include<math.h>
int main()
{
	int n,a,i,sn=0,z=0;
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++)
	{
		z=z+pow(10,i);
		sn=sn+z*a;
	}
	printf("%d",sn);
	return 0;
	
}
