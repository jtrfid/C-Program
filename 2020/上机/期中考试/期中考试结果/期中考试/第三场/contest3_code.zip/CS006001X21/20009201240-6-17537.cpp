#include<stdio.h>
int main()
{
	float x,n;//x��ʾ����
	scanf(" %f",&x);
	if(x<=100000){
		n=x*0.1;
		printf("%.1f",n);
	} 
	else if(100000<x&&x<=200000){
		n=10000+(n-100000)*0.075;
		printf("%.1f",n);
	}
    else if(200000<x&&x<=400000){
    	n=17500+(n-200000)*0.05;
    	printf("%.1f",n);
    }
    else if(400000<x&&x<=800000){
    	n=27500+(n-400000)*0.03;
    	printf("%.1f",n);
    }
    else if(800000<x){
    	n=39500+(n-800000)*0.01;
    	printf("%.1f",n);
    }
	return 0;
}
