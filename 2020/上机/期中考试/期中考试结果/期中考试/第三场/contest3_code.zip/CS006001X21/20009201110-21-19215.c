#include<stdio.h>
int main()
{
	int i;
	long int a,n,u;
	scanf("%ld %ld",&a,&n);
	u=a;
	for(i=2;i<=n;i++)
	{
		a=a*10;
		u=u*2+a;
	}
	printf("%ld",u);
	return 0;
}
