#include<stdio.h>
int main(){
	int a,b,sum;
	scanf("%d",&a);
	while(a>0){
		sum+=a%10;
		a=a/10;
	}
	b=sum-2;
	printf("%d",b);
	return 0;
}
