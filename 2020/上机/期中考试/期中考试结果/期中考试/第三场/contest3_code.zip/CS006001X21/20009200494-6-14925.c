#include<stdio.h>
int main()
{
	float n;
	int i,j;
	scanf("%f",&n);
	if(n<=100000)printf("%.1f",n/10);
	if(n>100000&&n<=200000)printf("%.1f",10000+0.075*(n-100000));
	if(n>200000&&n<=400000)printf("%.1f",17500+0.05*(n-200000));
	if(n>400000&&n<=800000)printf("%.1f",27500+0.03*(n-400000));
	if(n>800000&&n<=2000000)printf("%.1f",39500+0.01*(n-800000));
	return 0;
}
