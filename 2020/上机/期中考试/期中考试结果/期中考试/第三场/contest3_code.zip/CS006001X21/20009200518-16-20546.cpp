#include<stdio.h>
int main()
{
	int N;
	scanf("%d",N);
	return 0;
}
