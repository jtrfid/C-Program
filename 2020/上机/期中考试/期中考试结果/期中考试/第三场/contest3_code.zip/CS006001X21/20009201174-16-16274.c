#include<stdio.h>
#include<math.h>

int main()
{
	int n=0,i=0,j=0,t=0;
	char c;
	
	scanf("%d",&n);
	
	while((c=getchar())!='!')
	{
		if(((c>='a')&&(c<='z'))||((c>='A')&&(c<='Z')))
		{
			t=c%n;
			if(t%2==1)
				i++;
			else if(t%2==0)
				j++;
		}
	}
	printf("%d %d\n",i,j);
	return 0;
}
