#include<stdio.h>
int main()
{
	int i,a,b,n;
	b=0;
	scanf("%d%d",&a,&n);
	for(i=1;i<=n;i++)
	{
		b=b+a;
		a=a*10+a;
	}
	printf("%d",b);
	return 0;
}
