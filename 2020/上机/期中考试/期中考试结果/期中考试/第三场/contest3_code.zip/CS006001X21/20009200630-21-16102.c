#include<stdio.h>
int main(){
	int a,n,Sn=0,i=1;
	scanf("%d %d",&a,&n);
	int b[n];
	for(i=0;i<n;i++){
		b[0]=a;
		b[i]=10*b[i-1]+a;
		Sn+=b[i];
	}
	printf("%d",Sn);
	return 0;
}
