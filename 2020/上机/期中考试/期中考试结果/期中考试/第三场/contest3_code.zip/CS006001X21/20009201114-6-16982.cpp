#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>


int main()
{
	float val;
	scanf("%f",&val);
	float ans=0;
	if(val<=100000)ans=val*0.1;
	if(100000<val && val<=200000)ans=10000.0+(val-100000.0)*0.075;
	if(200000<val && val<=400000)ans=17500.0+(val-200000.0)*0.05;
	if(400000<val && val<=800000)ans=27500.0+(val-400000.0)*0.03;
	if(800000<val)ans=39500.0+(val-800000.0)*0.01;
	printf("%.1f",ans);
	
	return 0;
}
