#include<stdio.h>
int main()
{
	int a,n,Sn=0,i,t;
	scanf("%d %d",&a,&n);
	t=a;
	for(i=0;i<n;i++)
	{
		Sn+=t;
		t=t*10+a;
	}
	printf("%d",Sn);
	return 0;
}
