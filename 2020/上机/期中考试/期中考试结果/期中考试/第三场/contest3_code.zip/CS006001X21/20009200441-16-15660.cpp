#include<stdio.h>
int pd(char x)
{
	if((x>'a' && x<'z') ||(x>'A' && x<'Z')) return 1;
	else return 0 ;
}
int main()
{
	int n ,i=0 , l;
	int sj=0 ,so=0 ;
	scanf("%d",&n);
	char a[100];
	while(1)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!') break;
		i++;
	}
	l=i+1;
	for(i=0;i<l;i++)
	{
		if(pd(a[i])==1)
		{
			if((a[i]%n)%2==1) sj++;
			if((a[i]%n)%2==0) so++;
			
		}
	}
	
	printf("%d %d",sj,so);
	return 0;
}
