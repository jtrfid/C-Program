#include <stdio.h>

int main(){
	int N,i,c,d,b[100];
	char ch;
	scanf("%d\n",&N);
	scanf("%c",&ch);
	while(ch!='!'){
		for(i=0;i<20,ch!='!';i++){
			if((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z')){
				b[i]=ch%N;
			}
		}
	}
	for(i=0;i<N;i++){
		if(b[i]%2==0) c++;
		if(b[i]%2!=0) d++;
	}
	printf("%d %d",d,c);
	return 0;
}
