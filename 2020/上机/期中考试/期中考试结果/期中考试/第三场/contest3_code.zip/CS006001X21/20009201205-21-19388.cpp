#include<stdio.h>
#include<math.h>
int main()
{
	int i,a,n,b=0,c=0,sum=0;
	scanf("%d %d",&a,&n);
	for(i=1;i<=n;i++)
	{
		if(i=1) b=0;
	    if(i!=1)
		b=pow(10,i-1)*a+b;
		c=b+a;
		sum=sum+c;
    }
	printf("%d",sum);
	return 0;
	
}
