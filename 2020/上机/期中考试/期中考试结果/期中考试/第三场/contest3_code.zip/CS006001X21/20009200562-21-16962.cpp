#include<stdio.h>

int main()
{
	int a,b=0,c=0,i,sum=0;
	scanf("%d%d",&a,&b);
	for(i=1;i<=b;i++){
		c=a;
		
		a=(a*10)+a+a/10+a/100+a/1000+a/10000+a/100000+a/1000000+a/10000000+a/100000000+a/10000000000;
		sum=sum+c;
	}
	printf("%d",sum);
	
	
	return 0;
}
