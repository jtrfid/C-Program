#include<stdio.h>
int main()
{
	int a,n;
	int sum,c;
	sum=0;
	int i;
	scanf("%d %d",&a,&n);
	c=a;
	for(i=0;i<n;i++){
		sum=sum+a;
		a=a*10+c;
	}
	printf("%d",sum);
	return 0;
}
