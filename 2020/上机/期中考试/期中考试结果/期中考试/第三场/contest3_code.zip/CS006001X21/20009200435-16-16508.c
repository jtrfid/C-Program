#include<stdio.h>
int main()
{
	int n,a=0,b=0;
	char t;
	scanf("%d",&n);
	do
	{
		scanf("%c",&t);
		if(t>=97&&t<=122)
		{
			if((t%n)%2!=0)
			{
				a+=1;
			}
			else
			{
				b+=1;
			}
		}
		else if(t>=65&&t<=90)
		{
			if((t%n)%2!=0)
			{
				a+=1;
			}
			else
			{
				b+=1;
			}
		}
	}
	while(t!=33);
	printf("%d %d",a,b);
	return 0;
}
