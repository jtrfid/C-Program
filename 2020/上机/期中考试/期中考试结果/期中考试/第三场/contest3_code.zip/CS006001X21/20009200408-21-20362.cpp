#include<stdio.h>
int main()
{
int a,n,Sn=0,sum=0,i=1;
scanf("%d",&n);
do (sum=sum*10+a,Sn=Sn+sum,i++);
while (i<=n);
printf("%d\n",Sn);
return 0;
}
