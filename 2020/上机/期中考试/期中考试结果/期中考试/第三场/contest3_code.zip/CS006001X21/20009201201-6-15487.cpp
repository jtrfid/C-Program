#include<stdio.h>
int main()
{
	float a,b,c;
	scanf("%f",&a);
    if(a<=100000)
	{
		printf("%.1f",0.1*a);
	}
	else if(a>100000&&a<=200000)
	{
		printf("%.1f",10000+0.075*(a-100000));
	}
	else if(a>200000&&a<=400000)
	{
		printf("%.1f",17500+0.05*(a-200000));
	}
	else if(a>400000&&a<=800000)
	{
		printf("%.1f",27500+0.03*(a-400000));
	}
	else
	{
		printf("%.1f",39500+0.01*(a-800000));
	}	
	return 0;
}
