#include<stdio.h>
int main(void)
{
	float money,sal;
	scanf("%f",&money);
	if(money<=100000)
	{
		sal=money*0.1;
	}
	else if(money>100000&&money<=200000)
	{
		sal=10000+0.075*(money-100000);
	}
	else if(money>200000&&money<=400000)
	{
		sal=17500+0.05*(money-200000);
	}
	else if(money>400000&&money<=800000)
	{
		sal=27500+0.03*(money-400000);
	}
	else
	{
		sal=39500+0.01*(money-800000);
	}
	printf("%.1f",sal);
	return 0;
}
