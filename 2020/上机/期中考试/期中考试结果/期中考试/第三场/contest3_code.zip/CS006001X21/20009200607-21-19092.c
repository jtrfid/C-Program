#include <stdio.h>
int main(){
	int sn,a,n;
	int x=0;
	sn=0;
	scanf("%d %d",&a,&n);
	for(n=n;n>=0;n--){
		sn=sn+x;
		x=a+x*10;
	}
	printf("%d",sn);
	return 0;
}
