#include<stdio.h>
int main()
{
	int a,n,s;
	printf("");
	scanf("%d %d",&a,&n);
	for(n=1;n++)
	s=n*a+(n-1)*10*a+(n-2)*100*a;
	printf("%d %d\n",a,n);
	printf("%d",s);
	return 0;
}
