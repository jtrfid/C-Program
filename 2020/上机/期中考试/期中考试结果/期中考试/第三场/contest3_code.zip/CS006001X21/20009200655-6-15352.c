#include<stdio.h>
int main(){
	double x,y;
	scanf("%lf",&x);
	if(x<=100000) y=0.1*x;
	else if(x<=200000) y=10000+0.075*(x-100000);
	else if(x<=400000) y=17500+0.05*(x-200000);
	else if(x<=800000) y=27500+0.03*(x-400000);
	else y=39500+0.01*(x-800000);
	printf("%.1f",y);
	return 0;
}
