#include<stdio.h>
int main(){
	int a,n;
	int sum = 0;
	scanf("%d %d",&a,&n);
	int i = 1,cnt,temp1,temp2;
	for(;i <= n;i++){
		cnt = 1;
		for(temp1 = 0,temp2=a;cnt <=i;cnt++){
			temp1 += temp2;
			temp2 *= 10;
		}
		sum += temp1;
		
	}
	printf("%d",sum);
	return 0;
}