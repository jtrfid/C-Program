#include<stdio.h>

int main()
{
	int a,n,i,j,b[20]={0},sum=0,x;
	scanf("%d %d",&a,&n);
	for(i=1;i<=n;i++)
	{
		for(j=1,x=1;j<=i;j++,x*=10)
		{
			b[i]+=x*a;
		}
		sum+=b[i];
	}
	printf("%d",sum);
	return 0;
}
