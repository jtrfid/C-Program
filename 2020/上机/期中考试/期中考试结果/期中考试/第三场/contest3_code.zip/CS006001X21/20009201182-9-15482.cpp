#include<stdio.h>
int main()
{
	int n,sum=0,i,m;
	scanf("%d",&n);
	for(;n!=0;)
	{
		m=n%10;
		sum+=m;
		n/=10;
	}
	printf("%d",sum);
	return 0;
}
