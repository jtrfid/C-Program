#include<stdio.h>
int main()
{
	int y,x,n,m,i,j;
	int a=0,b=0;
	char s[1000];
	scanf("%d/n",&n);
	for(i=0;s[i]!='i';i++){
	scanf("%c",s[i]);
	x=(int)s[i]/n;
	y=x/2;
	if(y=0)
	{a++;}
	if(y=1)
	{b++;}
	}
	printf("%d%d",a,b);
}

