#include<stdio.h>
int main()
{
	int num=0,sum=0,i=0;
	scanf("%d",&num);
	while(num!=0){
		sum+=(num%10);
		num/=10;
	}
	printf("%d",sum);
	return 0;
}
