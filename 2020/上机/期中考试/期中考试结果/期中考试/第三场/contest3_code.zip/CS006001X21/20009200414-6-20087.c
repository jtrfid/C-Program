#include<stdio.h>
int main()
{
	float lr,jj;
	scanf("%f",&lr);
	//if(0<=lr<=100000) 
	//{
	    //jj=lr*0.1;
	
    //}
	if(100000<lr<=200000) 
	{
		    jj=10000+0.075*(lr-100000);
	}
	else if(200000<lr<=400000) 
	{
	        jj=17500+0.05*(lr-200000);
	}
	else if(400000<lr<=800000) 
	{
	        jj=25700+0.03*(lr-400000);
	}
	else 
	{
	        jj=37700+0.01*(lr-800000);
	}
	printf("%.1f",jj);
	return 0;
}
