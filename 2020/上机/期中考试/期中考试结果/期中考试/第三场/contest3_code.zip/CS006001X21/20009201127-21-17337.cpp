#include<stdio.h>
int main(){
	int a,b,sum=0,i,c=0;
	scanf("%d %d",&a,&b);
	for(i=0;i<b;i++){
		sum=sum*10+a;
		c+=sum;
	
	}
	printf("%d",c);
	return 0;
}
