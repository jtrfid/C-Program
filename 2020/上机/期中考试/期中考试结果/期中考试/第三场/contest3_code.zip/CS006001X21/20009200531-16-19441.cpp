#include<stdio.h>
int main()
{
	int n,i,q,p,w,k;
	scanf("%d",&n);
	
	q=0;
	p=0;
	w=0;
	
	char a[9999];
	int b[9999];
	for(i=0;i<9999;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!') break;
		else  if ((a[i]<'z'&&a[i]>'a')||(a[i]<'Z'&&a[i]>'A'))
	{
	b[i]=a[i]%n;
	w++;
		}
		else continue;
	
	}
	for(i=0;i<w;i++)
	{
		if(b[i]%2==1)
		q++;
		else p++;
	}
	
	printf("%d %d",q,p);
	

	

		
	


	
	
	
	
	
	return 0;
}
