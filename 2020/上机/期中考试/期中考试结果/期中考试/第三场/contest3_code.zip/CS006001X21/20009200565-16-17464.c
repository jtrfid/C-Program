#include<stdio.h>
int main()
{   char a;
   int c1=0,c2=0;
	int N,t,flag=1;
	scanf("%d\n",&N);
	
	while(flag) {
		scanf("%c",&a);
		if((a>='a'&&a<='z')||(a>='A'&&a<='Z')){
			int d=a;
		    t=d%N;
			if(t%2==0) c1++;
		    else if(t%2==1) c2++;
		    
		}
		if(a!='!') continue;
		if(a='!'){
			flag=0;
			break;
		}
	}
	printf("%d %d",c2,c1);
	return 0;
	
}
