#include<stdio.h>
#define N 10000
int main(){
	int q,i=0,m=0,j=0,k=0,g;
	char a[N];
	scanf("%d",&q);
	while(i<N){
		scanf("%c",&a[i]);
		m++;
		if(a[i]=='!') break;
		i++;
	}
	for(i=0;i<m;i++){
		g=a[i];
		if(g>96&&g<124){
			if((g%q)%2==0) k++;
			else j++;
		}
		if(g>64&&g<81){
			if((g%q)%2==0) k++;
			else j++;
		}
	}
	printf("%d %d",j,k);
	return 0;
}
