#include<stdio.h>
int main(){
	int a,n,i=1,b=0,c=1,d,sn=0;
	scanf("%d %d",&a,&n);
	while(i<=n){
		b+=a*c;
		c=c*10;
		i++;
		sn+=b;
	}
	printf("%d",sn);
	return 0;
}
