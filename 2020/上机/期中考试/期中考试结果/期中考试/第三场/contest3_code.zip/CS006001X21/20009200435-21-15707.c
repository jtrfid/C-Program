#include<stdio.h>
#include<math.h>
int plus(int a,int n)
{
	int s=0;
	for(n=n-1;n>=0;n-=1)
	{
		s+=a*pow(10,n);
	}
	return s;
}
int main()
{
	int a,n,sum=0;
	scanf("%d %d",&a,&n);
	for(;n>0;n-=1)
	{
		sum+=plus(a,n);
	}
	printf("%d",sum);
	return 0;
}
