#include<stdio.h>
int main(){
	float a,b;
	scanf("%f",&a);
	if(a<=100000){b=0.1*a;
	}
	else if(a<=200000){b=10000+0.075*(a-100000);
	}
	else if(a<=400000){b=10000+7500+(a-200000)*0.05;
	}
	else if(a<=800000){b=27500+0.03*(a-400000);
	}
	else{b=27500+12000+(a-800000)*0.01;
	}
	printf("%.1f",b);
	
	return 0;
	
}
