#include<iostream>
#include<cstdio>
#include<string>
#define maxn 1005
using namespace std;

int main(){
	int t,yu,flag=1;
	int a[maxn]={0};
	string s;
	int i;
	cin>>yu;
	getline(cin,s);
	getline(cin,s);
	for(i=0;i<s.size();i++){
		if(s[i]=='!')break;
		if((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')){
			t=s[i]-'A'+65;
			a[t]=1;
		}
	}
	for(i=65;i<128;i++){
		if(a[i]){
			t=i%yu;
			t=t%2;
			a[t]++;
		}
	}
	printf("%d %d",a[1],a[0]);
	return 0;
}
