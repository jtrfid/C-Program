#include<stdio.h>
int main()
{
	char a;
	int n,i,b=0,m=0;
	scanf("%d",n);
	for(i=1;i>=0;i++)
	{
		scanf("%c",&a);
		if(a=='!') break;
		else if(a>=97&&a<=122)
		{
			if((a%n)%2==0) m=m+1;
			else b=b+1;
		}
		else if(a>=65&&a<=90)
		{
			if((a%n)%2==0) m=m+1;
			else b=b+1;
		}
		else continue;
	}
	printf("%d %d",b,m);
	return 0;
}
