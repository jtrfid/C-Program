#include<stdio.h>
int main()
{
	long long a,r,s,i,n;
	scanf("%lld %lld",&a,&n);
	s=0;r=a;
	for(i=1;i<=n;i++){
		s+=r;
		r=r*10+a;
	}
	printf("%lld",s);
	return 0;
}
