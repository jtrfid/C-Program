#include<stdio.h>
int main()
{
	double a,b;
	scanf("%lf",&a);
	if(a<=100000){
	 b=0.1*a;
}
	else if(a>100000&&a<=200000){
	 b=b+(a-100000)*0.75;
}
	else if(a>200000&&a<=400000){
	 b=b+(a-200000)*0.05;
}
	else if(a>400000&&a<=800000){
	 b=b+(a-40000)*0.03;
}
	else{
		b=10000+7500+10000+12000+(a-800000)*0.01;

	}
	printf("%.lf",b);
	return 0;
	
}
