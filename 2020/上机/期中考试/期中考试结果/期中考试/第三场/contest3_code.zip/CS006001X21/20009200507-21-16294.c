#include<stdio.h>
int main()
{
	int a,n,sn=0,sum;
	int i;
	scanf("%d %d",&a,&n);
	for(i=0;i<=n;i++)
	{
		sum=(i-1)*a*10+a;
		sn=sn+sum;
	}
	printf("%d",sn);
	return 0;
	
}
