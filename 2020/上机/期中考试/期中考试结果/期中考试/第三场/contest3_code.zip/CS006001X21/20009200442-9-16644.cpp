#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int a,b,s=0;
	cin>>a;
	int i;
	while(a>0){
		s+=a%10;
		a/=10;
	}
	cout<<s;
	return 0;
}
