#include<stdio.h>
int main(){
	int m,n;
	int b;
	scanf("%d %d",&m,&n);
	for(int i=1;i<m;i++)
	b=n%10;
	n=n/10;
	b+=b;
	while(n==0)
		printf("%d",b);
	
	
	
}
