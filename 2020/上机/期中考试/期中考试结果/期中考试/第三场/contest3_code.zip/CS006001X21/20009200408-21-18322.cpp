#include<stdio.h>
int main()
{
	int Sn=0,n,sum=0,a,i;
	scanf("%d%d",&a,&n);
	for(i=1,i<=n,i++;;)
	{sum=sum*10+a;
	  Sn=Sn+sum;
	}
	printf("%d",Sn);
	return 0;
}
