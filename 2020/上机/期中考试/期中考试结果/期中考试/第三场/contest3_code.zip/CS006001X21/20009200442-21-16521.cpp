#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int a,b,s=0;
	cin>>a>>b;
	int i;
	for(i=1;i<=b;i++){
		s+=pow(10,i)/9*a;
	}
	cout<<s;
	return 0;
}
