#include<stdio.h>
int main(){
	int a,n,t,sum=0,i;
	scanf("%d%d",&a,&n);
	t=a;
	for(i=1;i<=n;i++)
	{
	   sum+=t;
	   t=t*10+a;
	}
	printf("%d",sum);
	return 0;
}
