#include <stdio.h>
int main(){
	long a;
	int b;
	scanf("%d",&a);
	b=a%10+a%100/10+a%1000/100+a%10000/1000+a%100000/10000+a%1000000/100000+a%10000000/1000000+a%100000000/10000000;
	printf("%d",b);
	return 0;
}

