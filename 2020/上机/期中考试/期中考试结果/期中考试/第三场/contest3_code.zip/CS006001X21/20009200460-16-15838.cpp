#include<stdio.h>
int main()
{
	int n,js,os;
	char x;
	scanf("%d",&n);
	js=0;os=0;
	while(~scanf("%c",&x)){
		if(x=='!'){
			break;
		}
		else{
			if((x-'a')>=0&&(x-'a')<=25||(x-'A')>=0&&(x-'A')<=25){
				if((x%n)%2==1){
					js+=1;
				}
				else{
					os+=1;
				}
			}
		}
	}
	printf("%d %d",js,os);
	return 0;
}
