#include<stdio.h>
#include<math.h>
int main()
{
	int a, n, Sn, i=0, A=0, N=0;
	scanf("%d %d",&a,&n);
	while(N<n)
	{
		while(i<=N)
		{
			A=A+a*pow(10,i);
			i++;
		}
		Sn=Sn+A;
		N++;
	}
	printf("%d",Sn);
	return 0;
}
