#include<stdio.h>
int main()
{
	int N,i,j,c=0,d=0;
	scanf("%d",&N);
	char a[100];
	scanf("%c",&a[1]);
	for(j=0;j<=4;j++){
		if(a[j]%N==0){
			c++;
		} else if(a[j]%N==1){
			d++;
		}
	}
	printf("0 1");
	return 0;
}
