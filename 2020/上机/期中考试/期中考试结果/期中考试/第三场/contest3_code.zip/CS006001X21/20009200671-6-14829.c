#include<stdio.h>
int main()
{
	float a,b;
	scanf("%f",&a);
	if(a<=100000)
	{
		b=a*0.1;
	}
	else if(a>100000&&a<=200000)
	{
		b=10000+(a-100000)*0.075;
	}
	else if(a>200000&&a<=400000)
	{
		b=17500+(a-200000)*0.05;
	}
	else if(a>400000&&a<=800000)
	{
		b=27500+(a-400000)*0.03;
	}
	else
	{
		b=39500+(a-800000)*0.01;
	}
	printf("%.1f",b);
	return 0;
}
