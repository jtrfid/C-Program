#include<iostream>
#include<cstdio>

using namespace std;

const int N=100000;
double calc(double base)
{
	double ans=0;
	if(base>N)
		ans+=N*0.1, base-=N;
	else return base*0.1;
	if(base>N)
		ans+=N*0.075, base-=N;
	else return ans+base*0.075;
	if(base>2*N)
		ans+=2*N*0.05, base-=2*N;
	else return ans+base*0.05;
	if(base>4*N)
		ans+=4*N*0.03, base-=4*N;
	else return ans+base*0.03;
	return ans+base*0.01;
}

int main()
{
	double base;
	scanf("%lf", &base);
	printf("%.1lf", calc(base));
	return 0;
}
