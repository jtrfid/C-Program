#include<stdio.h>
int main(){
	int n,a,b;
	scanf("%d",&n);
	while(n<10){
	b=b+n%10;
	n=n/10;
}
printf("%d",b);
return 0;
}
