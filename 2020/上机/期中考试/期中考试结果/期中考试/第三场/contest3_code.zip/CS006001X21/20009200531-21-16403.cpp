#include<stdio.h>
int main()
{
	int a,s,n,i,k,m,j;
	s=0;
	m=1;
	j=0;
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++)
	{
		
		
			
			j=m+j;
			s=j*a+s;
			m=m*10;
		
	}
	printf("%d",s);
	
	
	
	return 0;
}
