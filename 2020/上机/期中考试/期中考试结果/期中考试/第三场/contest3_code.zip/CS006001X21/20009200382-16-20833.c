#include <stdio.h>

int main(){
	int N,i,c,d,b[100],n;
	char ch,a[20];
	scanf("%d\n",&N);
	scanf("%d\n",&n);
	for(i=0;i<20;i++){
		scanf("%c",&a[i]);
	}
	for(i=0;a[i]!='!';i++){
		if(a[i]=='a') a[i]=97;
		if(a[i]=='b') a[i]=98;
		b[i]=a[i]%N;
	}
	for(i=0;i<N;i++){
		if(b[i]%2==0) c++;
		if(b[i]%2!=0) d++;
	}
	printf("%d %d",d,c);
	return 0;
}
