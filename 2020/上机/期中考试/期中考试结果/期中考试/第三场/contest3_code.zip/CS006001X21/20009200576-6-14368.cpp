#include <cstdio>

int main() {
  double x; scanf("%lf", &x);
  double ans = 0;
  if(x <= 100000) {
    ans = x * 0.1;
  } else if(x <= 200000) {
    ans = 100000 * 0.1 + (x - 100000) * 0.075;
  } else if(x <= 400000) {
    ans = 100000 * 0.1 + 100000 * 0.075 + (x - 200000) * 0.05;
  } else if(x <= 800000) {
    ans = 100000 * 0.175 + 200000 * 0.05 + (x - 400000) * 0.03;
  } else {
    ans = 100000 * 0.175 + 200000 * 0.05 + 400000 * 0.03 + (x - 800000) * 0.01;
  }
  printf("%.1f\n", ans);
  return 0;
}
