#include<stdio.h>
int main()
{
	int n,ji=0,ou=0,x;
	char a;
	scanf("%d",&n);
	do
	{
		scanf("%c",&a);
		if((a>=65&&a<=90)||a>=97&&a<=122)
		{
		x=a%n;
		if(x%2==1)
		ji++;
		else if(x%2==0) 
		ou++;
		}
		else
		continue;
	}while(a!='!');
	printf("%d %d",ji ,ou);
	return 0;
}
