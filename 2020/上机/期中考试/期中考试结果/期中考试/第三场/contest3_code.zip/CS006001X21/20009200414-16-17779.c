#include<stdio.h>
int main()
{
	int n,jigeshu=0,ougeshu=0;
	char b;
	scanf("%d",&n);
	
	while(1)
	{
		
		scanf("%c",&b);
		if(b='!') break;
		if(b%2!=0){
			jigeshu++;
		}
		if(b%2==0){
			ougeshu++;
		}
		
		
	}
	printf("%d %d",jigeshu,ougeshu);
	return 0;
}
