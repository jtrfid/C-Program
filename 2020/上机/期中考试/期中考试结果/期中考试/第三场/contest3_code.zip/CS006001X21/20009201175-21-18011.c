#include<stdio.h>
#include<math.h>
int main(){
	int a,n,i,x,y,sn;
	scanf("%d%d",&a,&n);
	x=a;
	for(y=0,sn=0,i=1;i<=n;i++){
		x=a*pow(10,i-1);
			y+=x;
			sn+=y;
	}
	printf("%d",sn);
	return 0;
}
