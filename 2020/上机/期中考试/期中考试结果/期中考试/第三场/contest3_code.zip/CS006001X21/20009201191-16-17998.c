#include<stdio.h>
int main(){
	int N,sum=0,o=0,j=0;
	char c;
	int flag=0;
	scanf("%d",&N);
	while(c!= '!'){
		scanf("%c",&c);
		if(c>=97&&c<=103||c>=65&&c<=91){
			if((c%N)%2!=0){
				o=o++;
			}else{
				j=j++;
			}
		}
	}
	printf("%d %d",o,j);
}
