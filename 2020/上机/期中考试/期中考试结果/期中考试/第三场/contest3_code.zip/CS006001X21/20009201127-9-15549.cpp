#include<stdio.h>
int main(){
	int a,c,sum=0;
	scanf("%d",&a);
	while(a>0){
		c%=10;
		sum+=c;
		a/=10;
	}
	printf("%d",sum);
	return 0;
}
