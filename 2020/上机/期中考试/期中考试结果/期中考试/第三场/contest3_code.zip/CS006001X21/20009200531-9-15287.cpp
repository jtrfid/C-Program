#include<stdio.h>
int main()
{
	int n,sum,k,i,m;
	scanf("%d",&n);
	sum=0;
	m=n;
	for(i=0;i<9;i++)
	{
		k=m%10;
		m=m/10;
		sum=sum+k;
	}
	
	printf("%d",sum);
	
	
	return 0;
}
