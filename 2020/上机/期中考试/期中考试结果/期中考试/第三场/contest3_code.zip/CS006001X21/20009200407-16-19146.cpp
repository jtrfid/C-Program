#include<stdio.h>
int main(){
	int n,b,x,u,v=0;
	char a;
	scanf("%d\n",&n);
	while(1){
		scanf("%c",&a);
		if(a=='!');
		break;
	}
    if(97<a&&a<122||65<a&&a<90){
    	b=a%n;
    	x=b%2;
    	if(x==1){
    		u=u+1;
    	}
    	else if(x==0){
    		v=v+1;
    	}
}else{
	u=u;
	v=v;
}
	printf("%d %d",u,v);
    return 0;
}

