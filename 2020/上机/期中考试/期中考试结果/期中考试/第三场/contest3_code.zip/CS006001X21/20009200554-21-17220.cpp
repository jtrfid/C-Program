#include<stdio.h>
int main()
{
	int a,n,sum=0,i,j=1;
	scanf("%d%d",&a,&n);
	for(i=0;i<n;i++)
	{
		
		
		sum+=a;
		a+=10*a;
	}
	printf("%d",sum);
	return 0;
}
