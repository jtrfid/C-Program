#include<stdio.h>
int main()
{
	int a,f1,f2,s1,s2,s3,s4,sum;
	scanf("%d",&a);
	f1=a/10000; f2=a-f1*10000;
	s1=f1/100; s2=f1-s1*100;
	s3=f2/100; s4=f2-s3*100;
	sum=s1/100+(s1-s1/100*100)/10+s1%10+s2/10+s2%10+s3/10+s3%10+s4/10+s4%10;
	printf("%d",sum); 
	return 0;
}
