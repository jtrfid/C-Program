#include<stdio.h>
int main(){
	int n,t,i;
	scanf("%d",&n);
	i=0;
	while(t!=0||n!=0)
	 {t=n%10;
	  n=n/10;
	  i+=t;
	 }
	printf("%d",i);
	return 0; 
}
