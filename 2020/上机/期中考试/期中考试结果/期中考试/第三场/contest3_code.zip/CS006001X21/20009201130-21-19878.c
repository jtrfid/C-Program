#include<stdio.h>
int main()
{
	int a[10],n,sn;
	int i;
	scanf("%d %d",&a[i],&n);
	for(i=0;i<n-1;i++)
	{
	sn=a^n+a;	
	}
	return 0;
}
