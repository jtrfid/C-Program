#include<stdio.h>
int main()
{
	int a,sum;
	char b[500];
	scanf("%d\n",&a);
	for(sum=0,i=0;;i++)
	{
		scanf("%c",&b[i]);
		if(b[i]==!)
		break;
		
	}
    
}
