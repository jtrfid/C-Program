#include<stdio.h>
int main()
{
	int a,n,i,j;
	scanf("%d %d",&a,&n);
	if(n==1)i=1;
	else if(n==2)i=12;
	else if(n==3)i=123;
	else if(n==4)i=1234;
	else if(n==5)i=12345;
	else if(n==6)i=123456;
	else if(n==7)i=1234567;
	else if(n==8)i=12345678;
	else if(n==9)i=123456789;
	printf("%d",i*a);
	
	return 0;
}
