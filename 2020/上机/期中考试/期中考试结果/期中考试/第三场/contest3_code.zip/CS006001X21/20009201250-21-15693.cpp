#include<iostream>
using namespace std;
long long ans;
int a,n;
int main()
{
	cin>>a>>n;
	ans+=a;
	for(int i=2;i<=n;i++)
	{
		a=a*10+a;
		ans+=a;

	}
	cout<<ans;
}
