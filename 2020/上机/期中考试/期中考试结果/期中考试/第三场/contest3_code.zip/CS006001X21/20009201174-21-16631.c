#include<stdio.h>
#include<math.h>

int main()
{
	long sn=0,sum=0;
	int a=0,n=0,i=0,j=0;
	
	scanf("%d %d",&a,&n);
	
	for(i=1;i<=n;i++)
	{
		for(j=1,sum=0;j<=i;j++)
		{
			sum=sum*10+a;
		}
		sn+=sum;
	}
	printf("%ld\n",sn);
	return 0;
}
