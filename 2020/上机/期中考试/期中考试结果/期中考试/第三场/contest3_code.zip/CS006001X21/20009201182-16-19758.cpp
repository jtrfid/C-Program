#include<stdio.h>
int main()
{
	int N,i=0,t,j;
	char n;
    scanf("%d\n",&N);
    do
    {  
    	scanf("%c",&n);
    	i++;
    }
    while('n'!='!');
    for(t=0;(n%N)%2==0;t++)
    for(j=0;(n%N)%2!=0;j++)
    if(j+t==i) break;
	printf("%d %d",j,t);
	return 0;
}
