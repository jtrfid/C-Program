#include<stdio.h>
int main()
{
	double i,j; 
	scanf("%f",i);
	do (j=i*0.1);
	while (i<=100000);
	do (j=10000+(i-100000)*(0.075));
	while (100000<i<=200000);
	do (j=17500+(i-200000)*(0.05));
	while (200000<i<=400000);
	do (j=27500+(i-400000)*(0.03));
	while (400000<i<=800000);
	do (j=39500+(i-800000)*(0.01));
	while (800000<i);
	printf("%f\n",j);
	return 0;
}
