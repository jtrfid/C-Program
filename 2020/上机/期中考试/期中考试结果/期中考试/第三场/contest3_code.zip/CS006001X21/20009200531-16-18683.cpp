#include<stdio.h>
int main()
{
	int n,i,q,p,k;
	scanf("%d",&n);
	
	q=0;
	p=0;
	
	char a[n];
	for(i=0;i<9999;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!') break;
		else  if ((a[i]<'z'&&a[i]>'a')||(a[i]<'Z'&&a[i]>'A'))
	{
		k=a[i]%n;
		if(k%2==1) q=q+1;
		else p=p+1;
		}
		else continue;
	
	}
	
	printf("%d %d",q,p);
	

	

		
	


	
	
	
	
	
	return 0;
}
