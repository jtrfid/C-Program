#include<stdio.h>
#include<math.h>
int main(){
	int a,n;
	scanf("%d %d",&a,&n);
	int b[n];
	int i,j,s=0;
	for(i=0;i<n;i++){
		for(j=0;j<i+1;j++){
			b[i]+=a*pow(10,j);
		}	
	}
	for(i=0;i<n;i++){
		s+=b[i];
	}
	printf("%d",s);
	return 0;
}
