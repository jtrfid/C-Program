#include<stdio.h>
int main(){
	int N,t,i=0,j=0;
	char a;
	scanf("%d\n",&N);
	scanf("%c",&a);
	while(a!='!')
	  {if('A'<=a&&a<='Z'||'a'<=a&&a<='z')
	   {t=a%N;
       }
       else {t=0;i=i-1;}
	   if(t%2==0){i++;
	             }
	    else {j++;
	         }  
	   
        scanf("%c",&a);
    
	  }
	  printf("%d %d",j,i);
	return 0;
}
