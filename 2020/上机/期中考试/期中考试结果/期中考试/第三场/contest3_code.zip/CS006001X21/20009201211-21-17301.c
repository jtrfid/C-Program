#include<stdio.h>
int main()
{
	int i,a,n,sn,arr[10],b[10]={1,11,111,1111,11111,111111,1111111,11111111,111111111,1111111111};
	scanf("%d %d",&a,&n);
	sn=0;
	for(i=0;i<n;i++)
	{
		arr[i]=a*b[i];
		sn+=arr[i];
	}
	printf("%d",sn);
	return 0;
}
