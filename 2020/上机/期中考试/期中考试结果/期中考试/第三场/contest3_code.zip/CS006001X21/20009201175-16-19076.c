#include<stdio.h>
int main(){
	int b,a,N;
	char x;
	scanf("%d%d",&N,&a);
	a=98;
	b=N%a;
	if(b%2==0){
		printf("0 1");
	}
	return 0;
}
