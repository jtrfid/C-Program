#include<cstdio>
#include<iostream>
using namespace std;

int a, n;
long long ans;

int main(){
	cin >> a >> n;
	for(int i = 1; i <= n; ++i){
		ans += a;
		int tmp = a;
		a *= 10;
		a += tmp;
	}
	cout << ans;











	return 0;
}

