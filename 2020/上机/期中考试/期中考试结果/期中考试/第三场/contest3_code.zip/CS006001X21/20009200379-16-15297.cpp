#include<iostream>
#include<cstdio>

using namespace std;

int main()
{
	int temp, n, ans1=0, ans2=0;
	cin>>n;
	char c;
	while((c=getchar())!='!')
	{
		if(c>='A' && c<='z')
		{
			temp=c%n%2;
			if(temp) ans1++;
			else ans2++;
		}
	}
	cout<<ans1<<ans2;
	return 0;
}
