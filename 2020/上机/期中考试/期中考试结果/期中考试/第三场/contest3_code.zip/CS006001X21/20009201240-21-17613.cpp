#include<stdio.h>

int main()
{
	int a,n,Sn;
	scanf("%d %d",&a,&n);
	int i=0,j=0;
	Sn=0;
	for(i=0;i<n;i++){
		j=10*j+a;
		Sn=j+Sn;
	}
	printf("%d",Sn);
	return 0;
}
