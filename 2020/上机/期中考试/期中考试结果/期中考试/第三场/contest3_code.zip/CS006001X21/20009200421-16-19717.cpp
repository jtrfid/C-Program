#include<stdio.h>
int main()
{
	char a;
	int b,c=0,d=0,n,i;
	scanf("%d",&n);
	for(i=1;a!=33;i++)
	{
		scanf("%c",&a);
		int a;
		if(a>=97&&a<=122||a>=65&&a<=90)
		{
		if(a==33) break;
		else
		 {
		b=a%n;
		if(b%2==1) c++;
		else d++;
	     }
	    }
	    else continue;
	}
	printf("%d %d",c,d+1);
	return 0;
}
