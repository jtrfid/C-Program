#include<stdio.h>
#include<math.h>
int main(){
	int a,n,sum,b,i;
	scanf("%d %d",&a,&n);
	b=a;
	sum=a;
	//(a<pow(10,n))
	for(i=0;i<n-1;i++)
	{
	a=a*10+b;
	sum=sum+a;
    }
	printf("%d",sum);
return 0;
}
