#include<stdio.h>
int main()
{int n;
scanf("%d",&n);
int countodd=0;
int counteven=0;
char x;
for( ;x!='!';)
	{scanf("%c",&x);
	if((x>='A'&&x<='Z')||(x>='a'&&x<='z'))
		{if((x%n)%2==0)
			{counteven++;
			}
		else if((x%n)%2!=0)
			{countodd++;
			}
		}
	else continue;
	}
printf("%d %d",countodd,counteven);
return 0;

}
