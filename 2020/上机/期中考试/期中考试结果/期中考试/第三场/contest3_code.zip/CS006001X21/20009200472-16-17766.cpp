#include<stdio.h>
int main()
{
	int N,i,j,c=0,d=0;
	scanf("%d",&N);
	char a[100];
	for(i=0;;i++){
		scanf("%c",&a[i]);
		if(a[i]=='!')
			break;
	}
	for(j=0;j<=i-1;j++){
		if(a[j]%N==0){
			c++;
		} else if(a[j]%N==1){
			d++;
		}
	}
	printf("%d %d",d,c);
	return 0;
}
