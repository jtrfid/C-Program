#include<stdio.h>
#include<math.h>
int main(){
	int a,n,sum=0,b;
	scanf("%d %d",&a,&n);
	b=a;
	if(a!=0){
	while(a<pow(10,n))
	{
	sum=sum+a;
	a=a*10+b;
    }
	}
	else{sum=0;
	}
	printf("%d",sum);
return 0;
}
