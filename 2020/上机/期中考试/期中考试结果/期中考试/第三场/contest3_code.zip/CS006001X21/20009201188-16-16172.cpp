#include<stdio.h>
int main()
{
    int i,N,A;
    int jishu=0,oushu=0;
	char t;
	scanf("%d",&N);
	for(i=0;;i++)
	{
		scanf("%c",&t);
		if(t=='!')
		{
			break;
		}
		else if((t>='a'&&t<='z')||(t>='A'&&t<='Z'))
		{
		    A=t%N;
			if(A%2==0)
			{
				oushu++;
			}	
			else
			{
				jishu++;
			}
		}
		
	}
	printf("%d %d",jishu,oushu);
	return 0;
}
