#include<stdio.h>
int main()
{int a,n;
int i;
scanf("%d %d",&a,&n);
int an=0;
int sum=0;
int k=1;
for(i=0;i<n;i++)
	{an+=k*a;
	sum+=an;
	k*=10;
	
	}
printf("%d",sum);
return 0;


}
