#include<stdio.h>
int main()
{
	float n,m;
	scanf("%f",&n);
	if(n<=1e5)
	{
		m=n*0.1;
	}
	if(n>1e5&&n<=2e5)
	{
		m=1e4+(n-1e5)*0.075;
	}
	if(n>2e5&&n<=4e5)
	{
		m=1e4+7.5e3+(n-2e5)*0.05;
	}
	if(n>4e5&&n<8e5)
	{
		m=2.75e4+(n-4e5)*0.03;
	}
	if(n>8e5)
	{
		m=3.95e4+(n-8e5)*0.01;
	}
    
	printf("%.1f",m);
	return 0;
}
