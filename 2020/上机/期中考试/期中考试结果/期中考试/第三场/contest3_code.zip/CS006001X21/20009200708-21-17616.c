#include<stdio.h>
int main()
{
	int a,n;
	int sum;
	sum=0;
	int i;
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++){
		sum=sum+a;
		a=a*10+a;
	}
	printf("%d",sum);
	return 0;
}
