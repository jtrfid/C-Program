#include<stdio.h>

int main(){
	int s,t=0,a,n,i=1,j=0,m=1;
	scanf("%d %d",&a,&n);
	if(n=1) t=m;
	else{
		while(i<n){
			m=10*m+1;
			t+=m;
			i++;
		}
		t=t+1;
	}
	s=a*t;
	printf("%d",s);
	return 0;
}
