#include <stdio.h>
int main(){
	int n, sum = 0;
	scanf("%d", &n);
	for(n; n > 0; ){
		sum = sum + n % 10;
		n /= 10;
	}
	printf("%d", sum);
}
