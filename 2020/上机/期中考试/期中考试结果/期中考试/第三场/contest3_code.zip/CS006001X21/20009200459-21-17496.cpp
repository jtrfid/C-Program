#include<stdio.h>
#include<math.h>
int main(){
	int a,n;
	scanf("%d %d",&a,&n);
	long long sum=a;
	int i;
	for(i=0;i<n;i++){
		sum=sum+a*(n-i)*pow(10,i);
	}
	printf("%lld",sum);
	return 0;
}
