#include<stdio.h>
#include<math.h>
int main(){
	int a,n,i=0,b,c,sum;
    pow(10,i);
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++){
		b=pow(10,i);
		sum=sum+b;
		b=0;
	}
	c=a*sum;
	printf("%d",c);
	return 0;
} 
