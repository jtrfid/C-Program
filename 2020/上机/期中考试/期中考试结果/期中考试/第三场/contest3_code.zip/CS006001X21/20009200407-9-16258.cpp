#include<stdio.h>
int main(){
	int n,sum=0;
	int a,b,c,d,e,f,g,h,i,j,l,x,k,q,u,y,p,v=0;
	scanf("%d",&n);
    b=n;
    d=n;
    f=n;
    h=n;
    j=n;
    l=n;
	x=n;
	q=n;
	u=n;
	a=b%10;
    c=(d/10)%10;
    e=(f/100)%10;
	g=(h/1000)%10;
	i=(j/10000)%10;
	k=(l/100000)%10;
	y=(x/1000000)%10;
	p=(q/10000000)%10;
	v=(u/100000000)%10;
	sum=a+c+e+g+i+k+y+p+v;
	printf("%d",sum);
	return 0;
}
