#include<stdio.h>
int main()
{
	int n ;
	double m ;
	scanf("%d",&n);
	if(n<=100000)
	{
	m=n*0.1;
	}
	else if(n<=200000)
	{
	m=10000+(n-100000)*0.075;
	}
	else if(n<=400000)
	{
	m=10000+7500+(n-200000)*0.05;
	}
	else if(n<=800000)
	{
	m=10000+7500+10000+(n-400000)*0.03;
	}
	else
	{
	m=10000+7500+10000+12000+(n-800000)*0.01;
	}
	printf("%.1f",m);
	
	return 0;
}
