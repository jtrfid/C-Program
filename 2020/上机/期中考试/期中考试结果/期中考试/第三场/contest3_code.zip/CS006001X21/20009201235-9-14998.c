#include<stdio.h>
int main(){
	int n,sum=0,a;
		scanf("%d",&n);
		do{
			a=n%10;
			sum+=a;
			n/=10;
		}while(n>0);
		printf("%d",sum);
return 0;
}
