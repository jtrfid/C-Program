#include<stdio.h>
int main()
{
	float n,m;
	scanf("%f",&n);
	if(n<=100000)
	{
		m=0.1*n;
		printf("%.1f",m);
	}
	else if(n>100000&&n<=200000)
	{
		n-=100000;
		m=10000+0.075*n;
		printf("%.1f",m);
	}
	else if(n>200000&&n<=400000)
	{
		n-=200000;
		m=17500+0.05*n;
		printf("%.1f",m);
	}
	else if(n>400000&&n<=800000)
	{
		n-=400000;
		m=27500+0.03*n;
		printf("%.1f",m);
	}
	else
	{
		n-=800000;
		m=39500+0.01*n;
		printf("%.1f",m);
	}
	return 0;
}
