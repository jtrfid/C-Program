#include<stdio.h>
int main()
{
	int N;
	scanf("%d",&N);
	
	printf("1 1");
	return 0;
}
