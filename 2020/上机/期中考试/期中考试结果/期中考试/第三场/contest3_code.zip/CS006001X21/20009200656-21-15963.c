#include<stdio.h>
int main()
{
	int n,m,i,t=0,sum=0;
	scanf("%d %d",&n,&m);
	for(i=0;i<m;i++)
	{
		t+=n;
		n*=10;
		sum+=t;
	}
	printf("%d",sum);
	return 0;
}
