#include<stdio.h>
int main()
{
	int n,m=0,i,j=0,h=0;
	char a[100];
	scanf("%d",&n);
	for(i=0;;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!')break;
		if(a[i]>=97&&a[i]<=122||a[i]>=65&&a[i]<=90)
		{
			m=a[i]%n;
			if(m%2==0)
			{
				h++;
			}
			if(m%2==1)
			{
				j++;
			}
		}
	}
	printf("%d %d",j,h);
	return 0;
}
