#include<stdio.h>
int main()
{
	int N,i,t,j;
	char n;
    scanf("%d\n%c",&N,&n);
    for(i=0;n!='!';i++)
    {  
    	scanf("%c",&n);
    }
    for(t=0;(n%N)%2==0;t++)
    for(j=0;(n%N)%2!=0;j++)
    if(j+t==i) break;
	printf("%d %d",j,t);
	return 0;
}
