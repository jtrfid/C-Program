#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	char b[99999];
	int i;
	for(i=0;i<99999;i++){
		b[i]=getchar();
		if(b[i]=='!'){break;
		}
	}
	int p;
	int j=0;
	int o=0;
	for(p=0;p<i;p++){
		if(b[p]>='a'&&b[p]<='z'||b[p]>='A'&&b[p]<='Z'){
			if((b[p]%n)%2==1){j=j+1;
			}else{o=o+1;
			}
		}
	}
	printf("%d %d",j,o);
	return 0;
	
;
}
