#include <stdio.h>
int main(){
	int i,n,s,b,c,d;
	char zimu[1000];
	b=0;c=0;
	scanf("%d",&n);
	for(i=0;;i++){
	scanf("%c",&zimu[i]);

	if(zimu[i]=='!'){
		d=i;
		break;
	}
	}
	for(i=0;i<d;i++){
	s=zimu[i]%n;
	
	if(s%2==1){
		b++;
	}
	if(s%2==0){
		c++;
	}
}
	printf("%d %d",b,c);
	return 0;
}

