#include<stdio.h>
int main()
{
	int a,b,c;
	c=0;
	scanf("%d",&a);
	while(a!=0)
	{
		b=a%10;
		c=c+b;
		a=(a-b)/10;
	}
	printf("%d",c);
	return 0;
}
