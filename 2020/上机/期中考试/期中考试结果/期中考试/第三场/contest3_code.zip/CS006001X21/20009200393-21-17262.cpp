#include<stdio.h>
#include<math.h>
int main()
{	
	int a,n;
	scanf("%d %d",&a,&n);
	int i;
	int sum1=0;
	int ret=0;
	for(i=1;i<pow(10,n);i*=10){
		sum1+=a*i;
		ret+=sum1;
	}
	printf("%d",ret);
	return 0;
}
