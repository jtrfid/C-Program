#include <cstdio>

int main() {
  int a, n; scanf("%d%d", &a, &n);
  int ans = 0, las = 0;
  for(int i = 1; i <= n; i ++) {
    las = las * 10 + a;
    ans += las;
  }
  printf("%d\n", ans);
  return 0;
}
