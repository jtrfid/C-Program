#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>


int main()
{
	int a,n,Sn=0;
	scanf("%d%d",&a,&n);
	for(int i=1;i<=n;i++)
	{
		int b=0; 
		for(int j=1;j<=i;j++)//���㵱ǰ�м���a 
		{
			b=b*10; 
			b=b+a;
		} 
		Sn+=b;
	}
	printf("%d",Sn);
	return 0;
}
