#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c=0,i,sum=0,d=0,e;
	scanf("%d%d",&a,&b);
	for(i=0;i<=b-1;i++){
	d=(b-i)*a;
	a=a*10;
	sum=sum+d;
	
	
	}
	printf("%d",sum);
	
	
	return 0;
}
