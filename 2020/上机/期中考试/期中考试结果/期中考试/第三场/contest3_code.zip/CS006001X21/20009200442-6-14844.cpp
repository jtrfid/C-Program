#include<iostream>
#include<cstdio>
#define maxn 1005
using namespace std;

int main(){
	double a,b;
	int i;
	cin>>a;
	if(a>800000){b+=(a-800000.0)*0.01;a=800000.0;}
	if(a>400000){b+=(a-400000.0)*0.03;a=400000.0;}
	if(a>200000){b+=(a-200000.0)*0.05;a=200000.0;}
	if(a>100000){b+=(a-100000.0)*0.075;a=100000.0;}
	b+=a*0.1;
	printf("%.1f",b);
	return 0;
}
