#include <stdio.h>
int main(){
	int i,a,m=0;
	scanf("%d",&a);
	for(i=0;i<9;i++){
		m=a%10+m;
		a=a/10;
	}
	printf("%d",m);
	return 0;
}
