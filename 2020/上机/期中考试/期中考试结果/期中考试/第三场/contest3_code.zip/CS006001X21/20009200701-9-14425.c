#include<stdio.h>

int main()
{
	int n,a;
	scanf("%d",&n);
	for(a=0;n>0;n/=10)
	{
		a+=n%10;
	}
	printf("%d",a);
	return 0;
}
