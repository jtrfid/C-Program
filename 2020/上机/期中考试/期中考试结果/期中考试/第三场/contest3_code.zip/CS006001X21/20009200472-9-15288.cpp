#include<stdio.h>
int main()
{
	long n,i,a=0;
	scanf("%d",&n);
	while(n>0){
		i=n%10;
		n=n/10;
		a=a+i;
	}
	printf("%d",a);
	return 0;
}
