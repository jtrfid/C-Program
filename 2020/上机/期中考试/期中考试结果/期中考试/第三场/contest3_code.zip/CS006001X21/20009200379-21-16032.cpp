#include<iostream>
#include<cstdio>

using namespace std;

int main()
{
	int a, n;
	scanf("%d%d", &a, &n);
	long long ans=0;
	while(n--)
	{
		ans+=a;
		a=a*10+a;
	}
	cout<<ans;
	return 0;
}
