#include<stdio.h>
int main()
{
	double W,JJ;
	scanf("%lf",&W);
	    if(W<=100000)
	    {
		JJ=W*0.1;
	    }
	    else
	    {if(W>100000&&W<=200000)
		JJ=(W-100000)*0.075+10000;
		else
		{if(W>200000&&W<=400000)
		JJ=(W-200000)*0.05+17500;
		else
		{if(W>400000&&W<=800000)
		JJ=(W-400000)*0.03+27500;
		else
		{if(W>800000)
			{JJ=(W-800000)*0.01+39500;
			}
				}
		}
		}
	    }
	printf("%.1f\n",JJ);
	return 0;
}
