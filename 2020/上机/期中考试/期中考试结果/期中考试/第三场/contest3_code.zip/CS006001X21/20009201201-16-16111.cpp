#include<stdio.h>
int main()
{
	int a,b,c,d,e=0,f=0;
	scanf("%d",&a);
	for(b=1;b<10000;b++)
	{
		char x;
		scanf("%c",&x);
		if(x=='!')
		{
			break;
		}
		d=x%a;
		if(d%2!=0)
		{
			e++;
		}
		else
		{
			f++;
		}
	}
	printf("%d %d",e,f);
	return 0;
}
