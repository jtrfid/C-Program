#include<iostream>
#include<cstdio>

using namespace std;

int main()
{
	int a, n;
	scanf("%d%d", &a, &n);
	long long ans=0;
	for(int i=1; i<=n; i++)
	{
		ans+=a;
		a=a*10+a;
	}
	cout<<ans;
	return 0;
}
