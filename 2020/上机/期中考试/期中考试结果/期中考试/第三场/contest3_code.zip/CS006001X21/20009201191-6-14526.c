#include<stdio.h>
int main(){
	double a,b;
	scanf("%lf",&a);
	if(a<=100000){
		printf("%.1lf",0.1*a);
	}else if(a>100000&&a<=200000){
		printf("%.1lf",10000+(a-100000)*0.075);
	}else if(a>200000&&a<=400000){
		printf("%.1lf",10000+7500+(a-200000)*0.05);
	}else if(a>400000&&a<=800000){
		printf("%.1lf",10000+7500+10000+(a-400000)*0.03);
	}else if(a>800000){
		printf("%.1lf",10000+7500+10000+12000+(a-800000)*0.01);
	}

	return 0;
}
