#include<stdio.h>
int main()
{
	int a,b,c,d,e=0,f=0;
	scanf("%d",&a);
	for(b=1;b<10000;b++)
	{
	    char x;
		scanf("%c",&x);
		if(x=='!')
		{
			break;
		}
	if('a'<=x&&x<='z')
	{
		d=x%a;
		if(d%2!=0)
		{
			e++;
		}
		else
		{
			f++;
		}

	}
	else if('A'<=x&&x<='Z')
	{
		d=x%a;
		if(d%2!=0)
		{
			e++;
		}
		else
		{
			f++;
		}
	}
	else
	{
	   continue;	
	}
}
	printf("%d %d",e,f);
	return 0;
}
