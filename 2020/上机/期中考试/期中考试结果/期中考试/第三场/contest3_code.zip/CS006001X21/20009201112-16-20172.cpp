#include<stdio.h>
int main()
{
	int N;
	scanf("%d\n",&N);
	char a[1000],i=0;
    for(i=0;;i++){
    		scanf("%d",a[i]);
    		if(a[i]=='!')
    		break;
    	}
    int b[1000],t=0;
    if(a[i]>=65&&a[i]<=90||a[i]>=97&&a[i]<=122){
    for(;i>0;i--){
    	b[i]=a[i]%N%2;
    	t++;
    }
	}
    int x=0,y=0;
    for(i=0;i<=t;i++){
    	if(b[i]==0)
    	x++;
    	else
    	y++;
    }
    printf("%d %d",x,y);
    return 0;
}
