#include<stdio.h>
int main()
{
	int a,n,Sn,i,m,sum=0;
	scanf("%d %d",&a,&n);
	for(i=0,m=a;i<n;i++)
	{
		sum+=m;
		m=m*10+a;
		
	}
	Sn=sum;
	printf("%d",Sn);
	return 0;
}
