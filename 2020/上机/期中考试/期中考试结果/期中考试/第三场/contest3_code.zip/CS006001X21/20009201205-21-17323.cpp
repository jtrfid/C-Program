#include<stdio.h>
#include<math.h>
int main()
{
	int i,a,n,b,c,sum=0;
	scanf("%d %d",&a,&n);
	for(i=1;i<=n;i++)
	{
		b=10*(i-1)*a;
		c=a+b;
		sum=sum+c;
	}
	printf("%d",sum);
	return 0;
	
}
