#include<stdio.h>
int main()
{
	int n, sum=0, a=0;
	scanf("%d",&n);
	while(n>=10)
	{
	    a=n%10;
		sum+=a;
		while(n==10)
		{
			sum+=1;
		}		
		n=n/10;
	}
	printf("%d",sum);
	return 0;
}
