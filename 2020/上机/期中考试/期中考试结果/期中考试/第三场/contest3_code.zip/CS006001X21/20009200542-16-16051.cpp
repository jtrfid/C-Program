#include<cstdio>
#include<iostream>
using namespace std;

int n, ans1, ans2;
char c;

int main(){
	cin >> n;
	c = getchar();
	while(c != '!'){
		if('a' <= c && c <= 'z' || 'A' <= c && c <= 'Z'){
			if(c%n%2 == 1) ++ans1;
			if(c%n%2 == 0) ++ans2;
		}
		c = getchar();
	}
	cout << ans1 << " " << ans2;











	return 0;
}

