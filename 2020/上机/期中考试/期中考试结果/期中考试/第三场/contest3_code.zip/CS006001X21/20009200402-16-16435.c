#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	char c;
	int j=0,o=0;
	c=getchar();
	
	while(c!='!')
	{
		if((c>='A'&&c<='Z')||(c>='a'&&c<='z'))
		{
			if(c%n%2==0)
			++o;
			else
			++j;
		}
		c=getchar();
	}
	printf("%d %d",j,o);
	return 0;
}

