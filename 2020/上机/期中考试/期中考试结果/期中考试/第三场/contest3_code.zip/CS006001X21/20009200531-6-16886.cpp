#include<stdio.h>
int main()
{
	double x,y;
	scanf("%lf",&x);
		if(x<=100000) y = x/10;
	else if (x<=200000) y = 10000+(x-100000)*75/1000;
	else if ( x<=400000) y = 17500+ (x-200000)*5/100;
	else if (x<=800000) y = 27500+(x-400000)*3/100;
	else y=39500+(x-800000)/100;
	
	printf("%.1f",y); 
	
	
	
	return 0;
}
