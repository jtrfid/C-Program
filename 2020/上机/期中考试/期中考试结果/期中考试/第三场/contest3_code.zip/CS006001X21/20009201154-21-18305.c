#include <stdio.h>
int main ()
{
	int n,a,i,j,c,t,b,d=0;
	scanf("%d %d",a,n);
	for(i=1;i<=n;i++)
	{
		t=1;
		c=0;
		for(j=1;j<=i;j++)
		{
			b=a*t;
			c+=b;
			t*=10;
		}
		d+=c;	
	}
	printf("%d",d);
	return 0;
}
