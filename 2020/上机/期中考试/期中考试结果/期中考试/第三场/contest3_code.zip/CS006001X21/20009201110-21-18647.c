#include<stdio.h>
int main()
{
	int a,n,i,u;
	scanf("%d %d",&a,&n);
	u=a;
	for(i=2;i<=n;i++)
	{
		a=a*10;
		u=u*2+a;
	}
	printf("%d",u);
	return 0;
}
