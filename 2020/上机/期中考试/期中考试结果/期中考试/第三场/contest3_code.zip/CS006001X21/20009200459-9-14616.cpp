#include<stdio.h>
int main(){
	long long a;
	scanf("%lld",&a);
	int sum=0;
	while((a/10)!=0){
		sum=sum+a%10;
		a=a/10;
	}
	sum=sum+a;
	printf("%d",sum);
	
	
	return 0;
	
}
