#include<stdio.h>
int main(){
	int n;
	int b=0;
	int x=0;
	int u=0;
	int v=0;
	char a;
	scanf("%d\n",&n);
	while(1){
		scanf("%c",&a);
		if(a=='!');
		break;
	}
    if(97<a&&a<122||65<a&&a<90){
    	x=a%n%2;
    	if(x==1){
    		u++;
    	}
    	if(x==0){
    		v++;
    	}
    }else{
	u=u;
	v=v;
}
 printf("%d %d",u,v);
    return 0;
}

