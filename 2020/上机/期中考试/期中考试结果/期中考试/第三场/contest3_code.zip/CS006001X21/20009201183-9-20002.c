#include<stdio.h>
int main(){
	int n,a,b;
	scanf("%d",&n);
while(n>10){
	b=n%10;
	n=n/10;
	a=a+b;
	b=0;
}	
   printf("%d",a);
   return 0;
}
