#include <cstdio>

int main() {
  int x; scanf("%d", &x);
  int ans = 0;
  while(x) {
    ans += x % 10;
    x /= 10;
  }
  printf("%d\n", ans);
  return 0;
}
