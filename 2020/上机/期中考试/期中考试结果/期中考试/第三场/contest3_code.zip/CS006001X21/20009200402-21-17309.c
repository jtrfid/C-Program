#include<stdio.h>
int main()
{
	double a,n;
	scanf("%lf %lf",&a,&n);
	double sum=0,i,m;
	m=a;
	for(i=0;i<n;i++)
	{
		sum=sum+a;
		a=a*10+m;
	}
	printf("%.0f",sum);
	return 0;
}
