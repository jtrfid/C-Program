#include<stdio.h>
int main()
{
	int a,b,f;
	scanf("%d %d",&a,&b);
        if(b==1)
    {
    	f=1;
    }
        if(b==2)
    {
    	f=12;
    }
        if(b==3)
    {
    	f=123;
    }
        if(b==4)
    {
    	f=1234;
    }
        if(b==5)
    {
    	f=12345;
    }
        if(b==6)
    {
    	f=123456;
    }
        if(b==7)
    {
    	f=1234567;
    }
        if(b==8)
    {
    	f=12345678;
    }
        if(b==9)
    {
    	f=123456789;
    }
        if(b==10)
    {
    	f=1234567900;
    }
	printf("%d",a*f);
	return 0;
}

