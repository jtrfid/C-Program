#include <stdio.h>
int main()
{
	int a,n;
	scanf("%d %d",&a,&n);
	int sum=a;
	int t=a;
	int i;
	for(i=1;i<n;i++){
		a=10*a+t;
		sum+=a;
	}
	printf("%d",sum);
	return 0;
}
