#include<iostream>
using namespace std;
long long ans;
int a,n;
long long p;
int main()
{
	cin>>a>>n;
	for(int i=1;i<=n;i++)
	{
		p=p*10+a;
		ans+=p;
	}
	cout<<ans;
}
