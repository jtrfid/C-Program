#include<stdio.h>
int main()
{
	int n=0,i=0,A[9]={0},s=0;
	scanf("%d",&n);
	for(i=0;i<9;i++)
	{
		if(n>9)
		{
			A[i]=n%10;
			n/=10;
		}
	}
	for(i=0;i<9;i++)
	{
		s+=A[i];
	}
	s+=n;
	printf("%d",s);
	return 0;
}
