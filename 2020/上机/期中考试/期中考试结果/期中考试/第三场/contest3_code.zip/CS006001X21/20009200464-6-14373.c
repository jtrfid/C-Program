#include<stdio.h>
int main(){
	float y,n;
	scanf("%f",&n);
	if(n<=100000){
		y=0.1*n;
	}else if(n<=200000){
		y=10000+(n-100000)*0.075;
	}else if(n<=400000){
		y=17500+(n-200000)*0.05;
	}else if(n<=800000){
		y=27500+(n-400000)*0.03;
	}else{
		y=27500+400000*0.03+(n-800000)*0.01;
	}
	 printf("%.1f",y);
	return 0;
}
