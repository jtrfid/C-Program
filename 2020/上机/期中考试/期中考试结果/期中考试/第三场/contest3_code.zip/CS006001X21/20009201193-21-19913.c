#include<stdio.h>
#include<math.h>
int main(){
	int a,n,Sn,t,i,l,j;
	l=0;
	Sn=0;
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++)
	 {
	  for(j=0;j<=i;j++)
	   {t=a*pow(10,j);
        l=l+t;
	   }
	   Sn=Sn+l;
     }
	printf("%d",Sn);
	return 0;
}
