#include<stdio.h>
int main()
{
	int a,n,Sn,i;
	scanf("%d%d",&a,&n);
	i=1;
	while(i<=n)
	{
		int p,q,s;
		p=i;
		q=1;
		s=0;
		while(q<=p)
		{
			s=s+a*(1e(q-1));
		    q++;
		}
		Sn=Sn+s;
		i++;
	}
	printf("%d",Sn);
	return 0;
}
