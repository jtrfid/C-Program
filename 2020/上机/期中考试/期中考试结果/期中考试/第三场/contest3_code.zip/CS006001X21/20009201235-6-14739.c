#include<stdio.h>
int main()
	{
	float n,jiang;
	scanf("%f",&n);
	if(n<=100000)
	{jiang=n*1.1;
	}
	else if(n<=200000)
	{jiang=110000+(n-100000)*1.075;
	}
	else if(n<=400000)
	{jiang=110000+107500+(n-200000)*1.05;
	}
	else if(n<=800000)
	{jiang=110000+107500+210000+(n-400000)*1.03;
	}
	else{
		jiang=110000+107500+210000+412000+(n-800000)*1.01;
	}
	jiang=jiang-n;
		printf("%.1f",jiang);
return 0;
}
