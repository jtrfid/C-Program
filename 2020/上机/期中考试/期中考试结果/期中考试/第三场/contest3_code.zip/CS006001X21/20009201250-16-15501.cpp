#include<iostream>
#include<cstdio>
using namespace std;
int n;
char s;
int zhi;
int ou,ji;
int main()
{
		cin>>n;
		while(cin>>s)
		{
			if(s=='!')
				break;
			if((s<='z'&&s>='a')||(s<='Z'&&s>='A'))
			{
				zhi=int(s);
				if(s%n&1)
					ji++;
				else
					ou++;
			}
		}
		cout<<ji<<" "<<ou;
}
