#include<stdio.h>
int main(void)
{
	int n,j=0,o=0,y;
	char c;
	scanf("%d",&n);
	while(c!='!')
	{
		scanf("%c",&c);
		if((c>=97&&c<=122)||(c>=65&&c<=90))
		{
			y=c%n;
			if(y%2==0)
			o++;
			else if(y%2==1)
			j++;
		}
	}
	printf("%d %d",j,o);
	return 0;
}
