#include<stdio.h>
int main()
{
    int a,b[9],n,i,j,sum;
    scanf("%d %d",&a,&n);
    for(b[0]=a,i=1;i<n;i++)
    {
    	b[i]=b[i-1]*10+a;
    }
    for(sum=0,j=0;j<n;j++)
    {
    	sum+=b[j];
    }
    printf("%d",sum);
	return 0;
} 
