#include<stdio.h>
int main()
{
	int i,n,sum=0;
	scanf("%d",&n);
	for(i=0;n>0;i++)
	{
		if(n==0)
		break;
		sum+=n%10;
		n/=10;
	}
	printf("%d",sum);
	return 0;
}
