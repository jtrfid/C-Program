#include<stdio.h>
int main()
{
	printf("2703\n");
	printf("12");
	return 0;
}
