#include<stdio.h>
int main(){
	int t,a,sum=0,n;
	scanf("%d",&n);
	while(n!=0)
	{
		t=n/10;
		a=n%10;
		sum+=a;
		n=t;
	}
	printf("%d",sum);
	return 0;
}
