#include<stdio.h>
int main()
{
	int n,b=0,sum1=0,sum2=0,i=1;
	char ch;
	scanf("%d",&n);
	getchar();
	
	for(i=1;i<=1000000;i++)
	{
	scanf("%c",&ch);
	if(ch=='!')
	{
		return 0;
	}
	else if(ch>='a'&&ch<='z')
	{
		b=ch%n;
		if(b%2==1)
		{
			sum1=sum1+1;
		}
		else
		{
			sum2=sum2+1;
		}
		
	}
	printf("%d %d",sum1,sum2);
    }
	
	
	
	
	
	
	return 0;
}
