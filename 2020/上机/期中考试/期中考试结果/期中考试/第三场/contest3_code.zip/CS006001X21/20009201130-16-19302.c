#include<stdio.h>
int main()
{
	int N,sum=0,k=0,a,c;
	int i;
	char ch[i];
	scanf("%d",&N);
	c=ch-'0';
	a=c%N;
	for(i=0;i<a-1;i++)
	{
	if(a%2==0)
	{
	sum++;
    }
	printf("%d\n",sum);
	printf("%c",ch[i]);	
	if(a%2!=0)
	{
     k++;
    }
     printf("%d\n",k);
     printf("%c",ch[i]);
    }
    return 0;
}
