#include <stdio.h>
#include <stdlib.h>

int main()
{
    double money,x;
    scanf("%lf",&money);
    if(money <= 100000)
        x = money * 0.1;
    else if(100000 < money&&money <= 200000)
        x = 10000 + (money - 100000) * 0.075;
    else if(200000 < money&&money <= 400000)
        x = 17500 + (money - 200000) * 0.05;
    else if(400000 < money&&money <= 800000)
        x = 27500 + (money - 400000) * 0.03;
    else if(80000 < money)
        x = 39500 + (money - 800000) * 0.01;
    printf("%.1lf",x);
    return 0;
}
