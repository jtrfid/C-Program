#include<stdio.h>
int main(){
	int N,y,z,sum1=0,sum2=0;
	char x;
	scanf("%d\n",&N);
	do{
		scanf("%c",&x);
		z=(int)x;
		if(z>=97&&z<=112||z>=65&&z<=90){
		y=z%N;
		if(y%2){
		sum1+=y;	
		}
		else sum2+=y;
	}
	}while(x!='!');
	printf("%d %d",sum1,sum2);
	return 0;
}
