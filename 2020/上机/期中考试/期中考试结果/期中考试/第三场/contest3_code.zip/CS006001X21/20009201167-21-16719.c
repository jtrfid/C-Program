#include <stdio.h>
#include <stdlib.h>

int main()
{
    long int sum = 0;
    int a,n,i;
    scanf("%d %d",&a,&n);
    for(i = 1;i <= n;i++)
    {
        sum += a;
        a = a * 10 + a;
    }
    printf("%d",sum);
    return 0;
}
