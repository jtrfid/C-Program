#include <stdio.h>
int main ()
{
	unsigned int n,m,p=0;
	scanf("%u",&n);
	while(n)
	{
		m=n%10;
		p+=m;
		n=(n-m)/10;
	}
	printf("%u",p);
	return 0;
	
}
