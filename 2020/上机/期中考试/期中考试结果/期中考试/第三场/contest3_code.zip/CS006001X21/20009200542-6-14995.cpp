#include<cstdio>
#include<iostream>
using namespace std;

double input, ans;

int main(){
	cin >> input;
	if(input <= 100000)	ans = input*0.1;
	if(100000 < input && input <= 200000) ans = 10000 + 0.075*(input-100000);
	if(200000 < input && input <= 400000) ans = 10000 + 0.075*100000 + 0.05*(input-200000);
	if(400000 < input && input <= 800000) ans = 10000 + 0.075*100000 + 0.05*200000 + 0.03*(input-400000);
	if(input > 800000) ans = 10000 + 0.075*100000 + 0.05*200000 + 0.03*400000 + 0.01*(input-800000);
	printf("%.1f", ans);
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
