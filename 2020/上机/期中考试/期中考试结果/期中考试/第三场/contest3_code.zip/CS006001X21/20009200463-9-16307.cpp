#include<stdio.h>

int main(){
	int a,q=0;
	scanf("%d",&a);
	while(a>0){
		q+=a%10;
		a/=10;
	}
	printf("%d",q);
	return 0;
}
