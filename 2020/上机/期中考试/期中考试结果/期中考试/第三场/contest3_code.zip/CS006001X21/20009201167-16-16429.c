#include <stdio.h>
#include <stdlib.h>

int main()
{
    char letters[1000] = {0};
    int i = 0,n,j,sum1,sum2,k;
    sum1 = 0;
    sum2 = 0;
    scanf("%d",&n);
    while(1)
    {
        char x;
        x = getchar();
        if('a' <= x&&x <= 'z'||'A' <= x&&x <='Z'){
            letters[i] = x;
            i++;
        }
        if(x == '!')
            break;
    }
    for(j = 0;j < i;j++)
    {
        k = letters[j] % n;
        if(k % 2 == 0)
            sum2++;
        else
            sum1++;
    }
    printf("%d %d",sum1,sum2);
    return 0;
}
