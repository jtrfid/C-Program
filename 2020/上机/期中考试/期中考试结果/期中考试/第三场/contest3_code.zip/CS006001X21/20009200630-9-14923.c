#include<stdio.h>
#include<math.h>
int main(){
	int n,i=8,sum=0,a,b;
	scanf("%d",&n);
	for(i=8;i>=0;i--){
		a=pow(10,i);
		b=n/a;
		n=n%a;
		sum+=b;
	}
	printf("%d",sum);
	return 0;
}
