#include<stdio.h>
int main()
{
	double a,b;
	int c=100000;
	scanf("%lf",&a);
	if(a<=1*c){
		b=0.1*a;
	} else if(a>1*c&&a<=2*c){
		b=0.1*c+(a-c)*0.075;
	} else if(a>2*c&&a<=4*c){
		b=0.1*c+c*0.075+(a-2*c)*0.05;
	} else if(a>4*c&&a<=8*c){
		b=0.1*c+c*0.075+2*c*0.05+(a-4*c)*0.03;
	} else {
		b=0.1*c+c*0.075+2*c*0.05+4*c*0.03+(a-8*c)*0.01;
	}
	printf("%.1f",b);
	return 0;
}
