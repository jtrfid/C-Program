#include<stdio.h>
int main()
{
	int n,s1=0,s2=0,t;
	char ch;
	scanf("%d",&n);
	scanf("%c",&ch);
	while(ch!='!')
	{
		if(ch>70&&ch<123)
		{
			t=ch%n;
			if(t%2!=0)
			  s1++;
			else
			  s2++;
		}
		scanf("%c",&ch);
	}
	printf("%d %d",s1,s2);
	return 0;
}
