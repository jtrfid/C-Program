#include<stdio.h>
int main()
{
	int m,n,l;
	char ch;
	scanf("%d/n %c",&l);
	while(ch<='z'&&ch>='a'||ch>='A'&&ch<='Z')
	{if((int)ch%l%2!=0)
	m++;
	else if((int)ch%l%2==0)
	n++;
	}
	printf("%d %d",m,n);
	return 0;
}
