#include <stdio.h>
int main(){
	int a, n;
	scanf("%d %d", &a, &n);
	int i = 0, sum = 0, end = 0;
	for(i = 0;i < n;i++){
		sum = sum * 10 + a;
		end += sum;
	}
	printf("%d", end);
	return 0;
}
