#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int sum=0;
	int t;
	do{
		t=n%10;
		n/=10;
		sum+=t;
	}while(n>0);
	printf("%d",sum);
		
	return 0;
}
