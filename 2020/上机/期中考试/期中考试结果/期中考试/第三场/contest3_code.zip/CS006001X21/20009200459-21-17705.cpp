#include<stdio.h>
#include<math.h>
int main(){
	int a,n;
	scanf("%d %d",&a,&n);

	int i;
	long long an[n];
	an[0]=a;
	long long sum=a;
	for(i=1;i<n;i++){
		an[i]=an[i-1]*10+a;
		sum=sum+an[i];
	}
	printf("%lld",sum);
	return 0;
}
