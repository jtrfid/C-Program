#include<stdio.h>
int main()
{
	int n,m,i,a[10];
	scanf("%d",&n);
	m=0;
	if(n==0)
	{
	printf("0");	
	}
	else
	{
		while(n>0)
		{
			m+=n%10;
			n/=10;
		}
		printf("%d",m);	
	}
	return 0;
}
