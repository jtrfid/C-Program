#include<stdio.h>
#include<math.h>
int p (int a,int n)
{
	int i ,m=0;
	for(i=1;i<=n;i++)
	{
		m+=pow(10.0,i-1)*a;
	}
	return m;
}
int main()
{
	int a,n,i,sum=0;
	scanf("%d %d",&a,&n);
	for(i=1;i<=n;i++)
	{
		sum+=p(a,i) ;
	}
	printf("%d",sum);
	return 0;
}
