#include<stdio.h>
int main()
{
	int N,o=0,j=0,a=0;
	char c;
	scanf("%d",&N);
	while((c=getchar())!='!'){
		if((c>='a'&&c<='z')||(c>='A'&&c<='Z')){
			a=(int)c%N;
			if(a%2==0){
				o++;
			}else{
				j++;
			}
		}
	}
	printf("%d %d",j,o);
	return 0;
}
