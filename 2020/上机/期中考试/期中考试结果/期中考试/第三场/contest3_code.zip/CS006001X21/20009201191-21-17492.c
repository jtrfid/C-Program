#include<stdio.h>

int main(){
	int a,n,Sn=0,i,sum=0;
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++){
		Sn=Sn*10+a;
		sum=Sn+sum;
		
	}printf("%d",sum);
}
