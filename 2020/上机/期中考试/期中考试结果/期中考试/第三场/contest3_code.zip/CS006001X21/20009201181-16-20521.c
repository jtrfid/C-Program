#include<stdio.h>
int main()
{
	int N;
	scanf("%d",&N);
	char m;
	int x,y,i;
	while(m!='!')
	{
		scanf("%c",&m);
		if(m>=97&&m<=122) continue;
		else if(m>=65&&m<=90) continue;
	}
	for(i=0,x=0,y=0;i<20;i++)
	{
		if((m%N)%2==0)    x++;
		else              y++;
	}
	printf("%d %d",x,y);
	return 0;
}
