#include<stdio.h>
int main()
{
	float a,sum;
	int i;
	scanf("%f",&a);
	if(a>0&&a<=100000){
		i=1;
	}else if(a>100000&&a<=200000){
		i=2;
	}else if(a>200000&&a<=400000){
		i=3;
	}else if(a>400000&&a<=800000){
		i=4;
	}else if(a>800000){
		i=5;
	}
	switch(i){
		case(1):sum=a*0.1;
		break;
		case(2):sum=10000+(a-100000)*0.075;
		break;
		case(3):sum=17500+(a-200000)*0.05;
		break;
		case(4):sum=27500+(a-400000)*0.03;
		break;
		case(5):sum=39500+(a-800000)*0.01;
		break;
	}
	printf("%.1f",sum);
	return 0;
}
