#include<stdio.h>
int main()
{
	int n,S;
	scanf("%d",n);
	S=n%10+(n%100)/10+(n%1000)/100+(n%10000)/1000+(n%100000)/10000+(n%1000000)/100000;
	printf("%d",a);
	return 0;
}
