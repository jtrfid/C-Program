#include<stdio.h>
int main()
{
	int N,i,j,c,d;
	scanf("%d",&N);
	char a[100];
	for(i=0;;i++){
		scanf("%c",&a[i]);
		if(a[i]='!')
			break;
	}
	for(j=0;j<=i;j++){
		if(a[j]%N==0){
			c=c+a[j];
		} else if(a[j]%N==1){
			d=d+a[j];
		}
	}
	printf("%d %d",d,c);
	return 0;
}
