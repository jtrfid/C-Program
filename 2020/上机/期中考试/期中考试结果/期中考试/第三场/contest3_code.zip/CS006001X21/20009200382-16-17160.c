#include <stdio.h>

int main(){
	int N,i,c,d,b[100];
	char a[100];
	scanf("%d",&N);
	for(i=0;i<N;i++){
		scanf("%c",&a[i]);
	}
	for(i=0;i<N,a[i]!='!';i++){
		for(i=0;i<N;i++){
			if(a[i]>='a'&&a[i]<='z'){
				b[i]=a[i]%N;
			}
		}
	}
	for(i=0;i<N;i++){
		if(b[i]%2==0) c++;
		if(b[i]%2!=0) d++;
	}
	printf("%d %d",d,c);
	return 0;
}
