#include<stdio.h>
int main(){
	int N;
	scanf("%d",&N);
	char s;
	scanf("%ch",&s);
}
