#include <stdio.h>
int main(){
	double x;
	scanf("%lf", &x);
	if(x <= 100000)
	printf("%.1lf", x * 0.1);
	else if(x <= 200000)
	printf("%.1lf", 10000 + (x - 100000) * 0.075);
	else if(x <= 400000)
	printf("%.1lf", 17500 + (x - 200000) * 0.05);
	else if(x <= 800000)
	printf("%.1lf", 27500 + (x - 400000) * 0.03);
	else printf("%.1lf", 39500 + (x - 800000) * 0.01);
	return 0;
}
