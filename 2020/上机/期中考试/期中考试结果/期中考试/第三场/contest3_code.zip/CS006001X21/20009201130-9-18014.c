#include<stdio.h>
int main()
{
    int n;
	int a,i;
	scanf("%d",&n);
	if(n%10!=0)
	{
    for(i=0;i<n-1;i++)
	{
	a=a+n%10;
	n=n/10;
    }
    }
    else
    {
     for(i=1;i<n-2;i++)
	{
	a=a+n%10;
	n=n/10;
    }
    }
	printf("%d",a);
	return 0;
}
