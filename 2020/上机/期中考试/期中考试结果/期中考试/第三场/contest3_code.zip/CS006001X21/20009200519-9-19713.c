#include<stdio.h>
int main()
{
	int n;
	int x,y[11],i;
	scanf("%d",n);
	if(n<10)
	printf("%d",n);
	if(n>10)
	{
	 for(x=10,i=0;x<n;x=x*10,i++)
	 {
		y[i]=n/x;
		
	 }
    }

} 


