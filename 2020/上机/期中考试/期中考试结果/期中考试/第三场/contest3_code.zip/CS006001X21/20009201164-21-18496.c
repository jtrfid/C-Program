#include<stdio.h>
int main()
{int a,n,Sn;
printf("����a��") ;
scanf("%d",&a);
printf("����n��");
scanf("%d",&n);
switch(n)
{case 1 :Sn=a;break;
case 2 :Sn=12*a;break;
case 3:Sn= 113*a;break;
case 4:Sn=1114*a;break;
case 5:Sn=11115*a;break;
case 6:Sn=111116*a;break;
case 7:Sn=1111117*a;break;
case 8:Sn=11111118*a;break;
case 9:Sn=111111119*a;break;
case 10:Sn=11111111110*a;break;
default:Sn;
}
printf("Sn=%d",Sn);
return 0;
}
