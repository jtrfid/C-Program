#include<stdio.h>
int main()
{
	int a,sum;
	scanf("%d\n",&a);
    for(sum=0;;)
    {
    	
    }
}
