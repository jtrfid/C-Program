#include<stdio.h>
int main(){
	int a,b=0,d=0;
	char data;
	scanf("%d",&a);
	while(1){
		scanf("%c",&data);
		if(data=='!')
		break;
		if((data<='Z'&&data>='A')||(data<='z'&&data>='a')){
		if((data%a)%2==0)
		b++;
		else
		d++;
		}
	}
	printf("%d %d",d,b);
	return 0;
}
