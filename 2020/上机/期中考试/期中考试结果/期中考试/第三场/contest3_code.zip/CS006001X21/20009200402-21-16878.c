#include<stdio.h>
int main()
{
	int a,n;
	scanf("%d %d",&a,&n);
	int sum=0,i;
	for(i=0;i<n;i++)
	{
		sum=sum+a;
		a=a*10+a;
	}
	printf("%d ",sum);
	return 0;
}
