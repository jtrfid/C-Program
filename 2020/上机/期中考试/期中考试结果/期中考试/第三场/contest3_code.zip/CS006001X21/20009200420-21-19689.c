#include<stdio.h>
#include<math.h>
int main()
{
	int a,n,sum,i,k;
	scanf("%d %d",&a,&n);
	for(sum=0,i=a,k=1;k<=n;k++)
	{
		sum=sum+i;
		i=i+a*pow(10,k);
		
	}

	printf("%d",sum);
	return 0;
	
	
}
