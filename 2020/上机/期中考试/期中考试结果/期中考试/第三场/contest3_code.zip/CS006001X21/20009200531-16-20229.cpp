#include<stdio.h>
int main()
{
	int n,i,q,p,w,k;
	scanf("%d",&n);
	
	q=0;
	p=0;
	w=0;
	
	char a[9999];
	int b[w];
	for(i=0;i<9999;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!') break;
		else  if ((a[i]<'z'&&a[i]>'a')||(a[i]<'Z'&&a[i]>'A'))
	{
		k=a[i]%n;
		w=k%2;
		if(w==1)
		q++;
		else if(w==0) p++;
		}
		else continue;
	
	}
	
	
	printf("%d %d",q,p);

	

		
	


	
	
	
	
	
	return 0;
}
