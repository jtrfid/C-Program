#include<stdio.h>
int main()
{
	int N,x,y,z;
	printf("");
	scanf("%d\n",&N);
	y=putchar(x);
	z=y%N;
	printf("N\n");
	return 0;
}
