#include<stdio.h>
int main()
{
	int N,o=0,j=0;
	char c;
	scanf("%d",&N);
	while((c=getchar())!='!'){
		if((c>'a'&&c<'z')||(c>'A'&&c<'Z')){
			if(c%2==0){
				o++;
			}else{
				j++;
			}
		}
	}
	printf("%d %d",j,o);
	return 0;
}
