#include<stdio.h>
int main(){
	int n;
	int b,x;
	int u=0;
	int v=0;
	char a;
	scanf("%d\n",&n);
	while(1){
		scanf("%c",&a);
		if(a=='!');
		break;
	}
    if(97<a&&a<122||65<a&&a<90){
    	b=a%n;
    	x=b%2;
    	if(x==1){
    		u++;
    	}
    	else if(x==0){
    		v++;
    	}
    }else{
	u=u;
	v=v;
}
 printf("%d %d",u,v);
    return 0;
}

