#include<stdio.h>
int main()
{
	int a,n,Sn=0,i;
	scanf("%d %d",&a,&n);
	for(i=0;i<n;i++)
	{
		Sn+=a;
		a=a*10+2;
	}
	printf("%d",Sn);
	return 0;
}
