#include<stdio.h>
int main(){
	int N,sum=0,o=0,j=0,t;
	char c;
	scanf("%d",&N);
	while(c!= '!'){
		scanf("%c",&c);
		t=c;
		if(t>=97&&t<=103){
			if((t%N)%2!=0){
				j=j++;
			}else{
				o=o++;
			}
		}else if(t>=65&&t<=91){	
			if((t%N)%2!=0){
				j=j++;
			}else{
				o=o++;
			}
	}
	printf("%d %d",j,o);
}
}
