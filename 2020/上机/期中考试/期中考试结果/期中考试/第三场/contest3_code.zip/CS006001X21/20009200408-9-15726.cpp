#include<stdio.h>
int main()
{
	int n,x;
	scanf("%d",n);
	x=n%10+(n%100)/10+(n%1000)/100+(n%10000/1000);
	printf("%d\n",x);
	return 0;
		
}
