#include <stdio.h>
int main(){
	int n;
	scanf("%d", &n);
	char a[5];
	int i = 0;
	for(i = 0;i < 5;i++){
		scanf("%c", &a[i]);
	}
	scanf("!");//����
	int j = 0, t, ji = 0, ou = 0;
	for(j = 0;j < 5;j++){
		if(a[j] >= 65&& a[j] <= 90||a[j] >= 97&&a[j] <= 122){
			t = a[j] % n;
			if(t % 2 == 0) ou++;
			else ji++;
		}
	}
	printf("%d %d", ji, ou);
	return 0;
}
