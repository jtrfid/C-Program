#include<stdio.h>

int main(){
	float a,b;
	scanf("%f",&a);
	if(a<=100000) b=a*0.1;
	else if(a>100000&&a<=200000) b=10000+0.075*(a-100000);
	else if(a>200000&&a<=400000) b=17500+0.05*(a-200000);
	else if(a>400000&&a<=800000) b=27500+0.03*(a-400000);
	else b=39500+0.01*(a-800000);
	printf("%.1f",b);
	return 0;
}
