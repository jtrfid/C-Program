#include<stdio.h>
int main()
{
	int a,n,Sn=0,i;
	int m[10]={0};
	scanf("%d %d",&a,&n);
	m[0]=a;
	for(i=1;i<n;i++){
		m[i]=m[i-1]*10+a;
	}
	for(i=0;i<n;i++){
		Sn+=m[i];
	}
	
	printf("%d",Sn);
	return 0;
}
