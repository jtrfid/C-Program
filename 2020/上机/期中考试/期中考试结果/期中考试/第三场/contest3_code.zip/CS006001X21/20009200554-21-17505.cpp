#include<stdio.h>
int main()
{
	int a,c,n,sum=0,i,j=1;
	scanf("%d%d",&a,&n);
	c=a;
	for(i=0;i<n;i++)
	{
		
		sum+=a;
		
		a=10*a+c;
	}
	printf("%d",sum);
	return 0;
}
