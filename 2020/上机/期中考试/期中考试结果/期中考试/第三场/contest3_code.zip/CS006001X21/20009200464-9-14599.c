#include<stdio.h>
int main(){
	int a[10];
	int i,n,sum=0;
	scanf("%d",&n);
	for(i=1;n>0;i++){
		a[i]=n%10;
		sum+=a[i];
		n/=10;
	}
	printf("%d",sum);
	return 0;
}
