#include<stdio.h>
int main(){
	int n,i=1,n1=0,n2=0;
	char a[100];
	scanf("%d",&n);
	for(;;i++){
		scanf("%c",&a[i]);
		if(a[i]=='!'){break; }
		if(a[i]>='a'&&a[i]<='z'||a[i]>='A'&&a[i]<='Z'){
			if((a[i]%n)%2==1){
				n1++;
			}else{
				n2++;
			}
		}
	}
	printf("%d %d\n",n1,n2);
	return 0;
}
