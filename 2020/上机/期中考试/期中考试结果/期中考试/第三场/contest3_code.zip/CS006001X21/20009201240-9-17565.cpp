#include<stdio.h>
int main()
{
	long int n,i=0;
	int j=1,sum=0;
	scanf("%d",&n);
    for(i=0;i<10;i++){
    	j=n%10;
    	n=n/10;
    	sum=sum+j;
    } 
	printf("%d",sum);
	return 0;
}
