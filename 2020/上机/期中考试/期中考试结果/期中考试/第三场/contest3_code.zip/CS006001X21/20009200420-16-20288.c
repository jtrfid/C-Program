#include<stdio.h>
int main()
{
	int a,n,sum,i,k,m;
	scanf("%d %d",&a,&n);
	for(sum=0,i=a,k=1,m=1;k<=n;k++)
	{
		sum=sum+i;
		m=10*m;
		i=i+a*m;
		
	}

	printf("%d",sum);
	return 0;
	
	
}
