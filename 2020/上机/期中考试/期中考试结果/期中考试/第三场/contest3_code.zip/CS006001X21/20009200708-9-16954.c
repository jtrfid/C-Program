#include<stdio.h>
int main()
{
	//����λ�� 
	int a,n,cnt,c;
	n=1;
	cnt=0;
	scanf("%d",&a);
	c=a;
	do{
		a=a/10;
		n=n*10;
		cnt++;
	}while(a>0);
	n=n/10;
	//printf("%d,%d\n",n,cnt);
	
	//��ʼ���� 
	int b,sum,i;
	sum=0;
	for(i=0;i<cnt;i++){
		b=c/n;
		c=c%n;
		n=n/10;
		sum=sum+b;
	}
	printf("%d",sum);
	return 0;
}
