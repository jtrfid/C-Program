#include<stdio.h>
#include<math.h>
int function(int a,int i)
{
	int ret=0,j;
	for(j=i-1;j>=0;j--)
	{
		ret+=a*pow(10,j);
	}
	return ret;
}
int main(void)
{
	int sum=0,a,n;
	scanf("%d %d",&a,&n);
	while(n>0)
	{
		sum+=function(a,n);
		n--;
	}
	printf("%d",sum);
	return 0;
}
