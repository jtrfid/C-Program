#include<stdio.h>
int main(){
	int N,sum=0,o=0,j=0;
	char c;
	scanf("%d",&N);
	scanf("%c",&c);
	while(c!= '!'){
		scanf("%c",&c);
		if(c>=97&&c<=103||c>=65&&c<=91){
			if((c%N)%2!=0){
				j=j++;
			}else{
				o=o++;
			}
		}
	}
	printf("%d %d",j,o);
}
