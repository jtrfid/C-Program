#include<stdio.h>
int main()
{	
	int j=0,o=0;
	int n;
	scanf("%d",&n);
	char ch;
	while(ch=getchar()!='!'){
		int nn=ch%n;
		if(((nn%2)!=0)&&((ch>=65&&ch<=90)||(ch>=97&&ch<=122)) ){
			j++;
		}else if(((nn%2)==0)&& ((ch>=65&&ch<=90)||(ch>=97&&ch<=122)) ){
			o++;
		}
	}
	printf("%d %d",j,o);
	return 0;
}
