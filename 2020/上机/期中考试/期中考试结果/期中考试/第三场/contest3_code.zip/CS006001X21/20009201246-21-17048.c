#include<stdio.h>
int main()
{
	int a,b,n,s,i;
	scanf("%d %d",&a,&n);
	b=a;
	for(i=0;i<n;i++)
	{
		s=a;
		a=a*10+b;
	}
	printf("%d",s);
	return 0;
}
