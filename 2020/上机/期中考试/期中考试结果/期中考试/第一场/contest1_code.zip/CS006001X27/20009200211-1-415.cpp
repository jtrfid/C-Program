#include <stdio.h>

int main() {
	char c;
	scanf("%c", &c);
	if (c <= 'z' && c >= 'a') {
		printf("%c", c + 'A' - 'a');
	} else if (c <= 'Z' && c >= 'A') {
		printf("%c", c + 'a' - 'A');
	} else if (c <= '9' && c >= '0') {
		printf("%c������", c);
	} else {
		printf("%c�������ַ�", c);
	}
	return 0;
}