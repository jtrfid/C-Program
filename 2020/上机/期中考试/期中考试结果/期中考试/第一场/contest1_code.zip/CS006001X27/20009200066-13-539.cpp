#include <stdio.h>

int main() {
	int N, A, B;
	scanf("%d %d %d", &N, &A, &B);
	int i, count = 0;
	for (i = 1; i <= N; i++) {
		int x;
		scanf("%d", &x);
		if ((x >= A) && (x <= B)) {
			count++;
		}
	}
	printf("%d", count);
	return 0;
}