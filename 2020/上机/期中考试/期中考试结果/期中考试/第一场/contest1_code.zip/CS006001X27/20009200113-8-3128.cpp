#include <stdio.h>

int main() {
	int m, n, i, k, s = 0;
	scanf("%d %d", &m, &n);
	for (i = m; i <= n; i++) {
		k = i * i;
		s = s + k;
	}
	printf("%d", s);
	return 0;
}