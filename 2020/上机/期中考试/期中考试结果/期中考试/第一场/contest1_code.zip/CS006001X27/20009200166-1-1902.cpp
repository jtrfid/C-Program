#include <stdio.h>

int main() {
	char a;
	a = getchar();
	if (a >= 'a' && a <= 'z') {
		printf("%c", a - 'a' + 'A');
	} else if (a >= 'A' && a <= 'Z') {
		printf("%c", a - 'A' + 'a');
	} else if (a >= '0' && a <= '9') {
		printf("%c������", a);
	} else {
		printf("%c�������ַ�", a);
	}
	return 0;
}