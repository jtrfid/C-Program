#include <stdio.h>
int max();

int main() {
	int n;
	int i;
	int k;
	int cnt = 0;
	scanf("%d", &n);
	for (i = 1; i <= n ; i++) {
		int sum1 = 0;
		int j;
		for (j = 1; j < i; j++) {
			if (i % j == 0)
				sum1 += j;
		}
		for (k = 1; k < n; k++) {
			int sum2 = 0;
			int j2;
			for (j2 = 1; j2 < k; j2++) {
				if (k % j2 == 0)
					sum2 += j2;
			}
			if (sum1 == k && sum2 == i && sum1 != i && sum2 != k) {
				int max1 = 0;
				int min1 = 0;

				if (i < k) {
					min1 = i;

					max1 = k;
				}
				if (i > k) {
					min1 = k;
					max1 = i;
				}
				printf("(%d,%d)", min1, max1);
				cnt++;
			}

		}
	}
	printf("\n");
	if (cnt == 0) {
		printf("nothing" );
	}
	printf("\n");






	return 0;
}




