#include <stdio.h>
#include <windows.h>
#include <math.h>

int main() {
	int n, a, b, sum = 0;
	scanf("%d %d %d", &n, &a, &b);
	int h[n] = {0};
	for (int i = 0 ; i < n ; i++) {
		scanf("%d", &h[i]);
		if (h[i] <= b && h[i] >= a)
			sum++;
	}

	printf("%d", sum);


	//system("pause");
	return 0;
}