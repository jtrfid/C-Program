#include<stdio.h>
int q(int x)
{
	int i,sum;
	sum=0;
	for(i=1;i<x;i++)
	if(x%i==0)
		sum+=i;
		return sum;
}
int main()
{
	int i,j,n;
	scanf("%d",&n);
	if(n<=284)
		printf("nothing");
	for(i=1;i<n;i++){
		for(j=i+1;j<n;j++)
			if(q(i)==j&&q(j)==i)
				printf("(%d,%d)",i,j);
	}
	return 0;
}
