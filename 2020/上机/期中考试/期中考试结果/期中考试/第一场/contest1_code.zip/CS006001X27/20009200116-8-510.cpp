#include <stdio.h>

int main() {
	int m, n, t;
	int sum = 0;

	scanf("%d %d", &m, &n);

	for (t = m; t <= n; t++) {
		sum += t * t;
	}
	printf("%d", sum);

	return 0;
}

