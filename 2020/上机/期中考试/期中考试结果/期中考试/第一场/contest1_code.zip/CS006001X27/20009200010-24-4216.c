#include <stdio.h>
#include <math.h>

int main() {
	int n, i, j, sum, sum1;
	scanf("%d", &n);
	if (n < 284) {
		printf("nothing");
	}
	for (i = 2; i <= n; i++) {
		for (j = 1, sum = 0; j < i; j++ ) {
			if (i % j == 0) {
				sum += j;
			}
			//printf("%d\n", sum);
		}
		//printf("%d\n", sum);
		if (sum > i && sum < n) {
			for (j = 1, sum1 = 0; j < sum; j++) {
				if (sum % j == 0) {
					sum1 += j;
				}
			}
			if (sum1 == i) {
				printf("(%d,%d)", i, sum);
			}
		}
	}
	return 0;
}