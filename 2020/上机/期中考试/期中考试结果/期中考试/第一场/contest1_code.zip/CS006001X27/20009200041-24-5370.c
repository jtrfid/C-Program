#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	if (n < 220) {
		printf("nothing");
	}
	if (n >= 220 & n <= 500) {
		printf("(220,284)");
	}

	return 0;
}