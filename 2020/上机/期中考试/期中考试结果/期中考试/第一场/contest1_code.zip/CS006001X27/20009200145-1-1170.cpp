#include <iostream>
#include <cstdio>

int main() {
	char a;
	scanf("%c", &a);
	int b = a;

	int _A = 'A';
	int _a = 'a';
	if (b >= 48 && b <= 57) {
		printf("%c������", a);

	} else if (b >= 65 && b <= 90) {
		printf("%c", a - _A + _a);

	} else if (b >= 97 && b <= 122) {
		printf("%c", a - _a + _A);
	} else {
		printf("%c�������ַ�", a);
	}




	return 0;

}