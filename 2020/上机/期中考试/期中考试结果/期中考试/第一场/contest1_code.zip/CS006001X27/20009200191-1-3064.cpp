#include <stdio.h>

int main() {
	int N, A, B;
	int count = 0;
	int a[N + 1];
	scanf("%d %d %d", &N, &A, &B);

	for (int i = 1; i <= N; i++) {

		scanf("%d", &a[i]);


		if (a[i] <= B && a[i] >= A) {
			count++;
		}
		break;
	}
	printf("%d", count);

	return 0;
}