#include <stdio.h>

int main() {
	int n;
	scanf("%c", &n);
	if (n >= 'a' || n <= 'z') {
		printf("%c", n - 'a' + 'A');
		return 0;
	}
	if (n >= 'A' || n <= 'Z') {

		printf("%c", n - 'A' + 'a');
		return 0;
	}
	if (n >= 0 || n < +9) {

		printf("%c ������", n);
		return 0;
	} else {

		printf("%c �������ַ�", n);
		return 0;
	}

}