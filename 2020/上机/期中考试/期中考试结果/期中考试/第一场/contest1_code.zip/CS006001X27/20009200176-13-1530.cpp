#include <stdio.h>

int main() {
	int N, A, B,  i, sum = 0;
	scanf("%d %d %d", &N, &A, &B);
	int c[N];
	for (i = 1; i <= N; i++) {
		scanf("%d", &c[i]);
	}
	for (i = 1; i <= N; i++) {
		if (c[i] <= B && c[i] >= A)

		{
			sum += 1;
		}
	}
	printf("%d", sum);










	return 0;
}