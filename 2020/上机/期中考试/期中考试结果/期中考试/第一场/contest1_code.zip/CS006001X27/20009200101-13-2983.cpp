#include <stdio.h>

int main() {
	int N, A, B, i, grade, count = 0;

	scanf("%d %d %d\n", &N, &A, &B);


	for (i = 1; i <= N; i++) {
		scanf("%d", &grade);


		if (grade > B) {
			count++;
		}
		if (grade < A) {
			count++;
		}
		if (grade >= A && grade <= B)
			continue;
	}

	printf("%d", count);
	return 0;
}