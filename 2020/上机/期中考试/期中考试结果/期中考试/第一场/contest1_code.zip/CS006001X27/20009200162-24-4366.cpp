#include<stdio.h>
int q(int x)
{
	int i,sum;
	sum=0;
	for(i=1;i<x;i++)
	if(x%i==0)
		sum+=i;
		return sum;
}
int main()
{
	int i,j,n;
	scanf("%d",&n);
	for(i=2;i<n-1;i++){
		for(j=i+1;j<n;j++)
			if(q(i)==j&&q(j)==i&&i<j)
				printf("(%d,%d)",i,j);
	}
	return 0;
}
