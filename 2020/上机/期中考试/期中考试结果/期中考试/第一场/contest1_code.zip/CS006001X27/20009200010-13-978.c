#include <stdio.h>
#include <math.h>

int main() {
	int n, a, b, num, i, j = 0, min, max;
	scanf("%d %d %d", &n, &a, &b);
	max = (a >= b) ? a : b;
	min = (a <= b) ? a : b;
	for (i = 1; i <= n; i++) {
		scanf("%d", &num);
		if (num >= min && num <= max) {
			j++;
		}
	}
	printf("%d", j);
	return 0;
}