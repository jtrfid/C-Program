#include <stdio.h>

int main() {
	char n;
	int a;
	scanf("%c", &n);
	if (n >= 65 && n <= 96) {
		n = n + 32;
		printf("%c", n);
	} else if (n >= 97 && n <= 122)
		n = n - 32;
	printf("%c", n);






}