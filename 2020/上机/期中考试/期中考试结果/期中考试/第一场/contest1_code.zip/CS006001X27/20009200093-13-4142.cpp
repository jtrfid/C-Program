#include <stdio.h>

int main() {
	int N, A, B, sum, i, m;
	scanf("%d%d%d", &N, &A, &B);
	for (i = 0, sum = 0; i < N; i++) {
		scanf("%d", &m);
		if ((A <= m) && (m <= B)) {
			sum = sum + 1;
		}
	}
	printf("%d", sum);
	return 0;
}