#include <stdio.h>

int main() {
	int n, a, b, i, sum = 0;
	scanf("%d %d %d", &n, &a, &b);
	int c[n];
	for (i = 0; i < n; i++) {
		scanf("%d", &c[i]);
	}
	for (i = 0; i < n; i++) {
		if (c[i] >= a && c[i] <= b) {
			sum += 1;
		}
	}
	printf("%d", sum);
	return 0;
}