#include <stdio.h>


int main () {
	char c ;
	scanf("%c", &c);
	if (c >= 65 && c <= 90) {
		c += 32;
		printf("%c", c);
	} else if (c >= 97 && c <= 122) {
		c -= 32;
		printf("%c", c);
	} else if (c >= 48 && c <= 57) {
		printf("%c������", c);
	} else
		printf("%c�������ַ�", c);

	return 0;

}