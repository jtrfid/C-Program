#include <stdio.h>

int yinzihe(int n) {
	int sum = 0;
	int i;
	for (i = 1;  i < n; i++) {
		if (n % i == 0) {
			sum += i;
		}
	}
	return sum;
}

int main() {
	int n;
	scanf("%d", &n);
	int i, x, y, a, b, count = 0;
	int r[100], e = 0, q;
	for (i = 0; i < 100; i++) {
		r[i] = 0;
	}
	for (i = 1; i <= n; i++) {
		x = yinzihe(i);
		y = yinzihe(x);
		if (y == i && x != i && x <= n) {
			a = x < i ? x : i;
			b = x < i ? i : x;
			for (q = 0; q < 100; q++) {
				if (a == r[q])
					goto here;
			}
			r[e] = a;
			r[e + 1] = b;
			e += 2;
			printf("(%d,%d)", a, b);
here:
			count++;
		}
	}
	if (count == 0) {
		printf("nothing");
	}
	return 0;
}