#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main() {
	char n;
	cin >> n;
	if ('A' <= n && n <= 'Z') {
		n += 32;
		printf("%c", n);
		return 0;
	}
	if ('a' <= n && n <= 'z') {
		n -= 32;
		printf("%c", n);
		return 0;
	}
	if ('0' <= n && n <= '9') {
		cout << n << "������";
		return 0;
	}
	cout << n << "�������ַ�";
	return 0;
}