#include <stdio.h>

int main() {
	int	sum3 = 0, n, a, i;
	scanf("%d", &n);
	for (i = 2; i < n ; i++) {
		int sum1 = 0, sum2 = 0;
		for (a = 1; a < i; a++) {
			if (i % a == 0)
				sum1 += a;
		}


		for (a = 1; a < sum1; a++)

			if (sum1 % a == 0)
				sum2 += a;




		if (i == sum2 && sum2 < sum1) {
			sum3++;
			printf("(%d,%d)", sum2, sum1);
		}
	}
	if (sum3 == 0)
		printf("nothing");
	return 0;
}