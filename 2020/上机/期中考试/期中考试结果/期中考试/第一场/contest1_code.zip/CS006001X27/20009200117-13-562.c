#include <stdio.h>

int main() {
	int n, a, b, score, sum = 0, i;
	scanf("%d %d %d", &n, &a, &b);
	for (i = 1; i <= n; i++) {
		scanf("%d", &score);
		if (score >= a && score <= b)
			sum++;
	}
	printf("%d", sum);

	return 0;
}