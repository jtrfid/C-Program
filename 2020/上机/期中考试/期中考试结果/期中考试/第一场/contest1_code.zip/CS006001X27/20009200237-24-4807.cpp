#include <stdio.h>

int main() {
	int n, sum1 = 0, sum2 = 0, count = 0, mark = 0;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= i; j++) {
			if (i % j == 0)
				sum1 += j;
		}
		sum1 -= i;
		for (int k = 1; k <= sum1; k++) {
			if (sum1 % k == 0)
				sum2 += k;
		}
		sum2 -= sum1;
		if (sum2 == i && sum1 != sum2 && sum2 != mark) {
			printf("(%d,%d)", sum2, sum1);
			count++;
			mark = sum1;
		}
		sum1 = 0;
		sum2 = 0;
	}
	if (count == 0)
		printf("nothing");
	return 0;
}