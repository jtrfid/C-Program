#include <stdio.h>

int main() {
	int n, a, b, i, j, k, s, m = 0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {

		for (j = 1; j < n; j++) {
			if (n % j == 0)

				s = s + j;
		}
	}
	for (k = 1; k < s; k++) {

		if (s % k == 0)
			m = m + k;
	}
	if (m = i)
		printf("(%d,%d)", i, s);
	return 0;

}