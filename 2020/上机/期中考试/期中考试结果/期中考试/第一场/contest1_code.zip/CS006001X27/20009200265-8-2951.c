#include <stdio.h>

int main() {
	int m, n, i, sum;
	scanf("%d %d", &n, &m);
	for (i = n, sum = 0; i <= m; i++) {
		sum = sum + i * i;
	}
	printf("%d", sum);
	return 0;
}