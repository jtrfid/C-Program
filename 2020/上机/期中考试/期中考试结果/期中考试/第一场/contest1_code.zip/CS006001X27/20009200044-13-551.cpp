#include <iostream>
using namespace std;

int main() {
	int n, a, b;
	cin >> n >> a >> b;
	int c, count = 0;
	for (int i = 0; i < n; ++i) {
		cin >> c;
		if (c <= b && c >= a)
			++count;
	}
	cout << count;

}