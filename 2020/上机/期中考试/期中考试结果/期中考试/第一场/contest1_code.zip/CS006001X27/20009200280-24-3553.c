#include <stdio.h>

int main() {
	int n, x, y, t, sumx, sumy, m = 0;
	scanf("%d", &n);
	for (x = 2; x <= n; x++) {
		for (sumx = 0, t = 1; t < x; t++) {
			if (x % t == 0)
				sumx += t;
		}
		for (y = 1; y < x; y++) {
			for (sumy = 0, t = 1; t < y; t++) {
				if (y % t == 0)
					sumy += t;
			}
			if (sumx == y && sumy == x) {
				m++;
				printf("(%d,%d)", y, x);
			}
		}
	}
	if (m == 0)
		printf("nothing");
	return 0;
}