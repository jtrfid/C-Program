#include <iostream>
using namespace std;

int main() {
	char ch;
	cin >> ch;
	if (ch >= 'A' && ch <= 'Z') {
		cout << char(ch + ('a' - 'A'));
		return 0;
	}
	if (ch >= 'a' && ch <= 'z') {
		cout << char(ch - ('a' - 'A'));
		return 0;
	}
	if (ch >= '0' && ch <= '9') {
		cout << ch << "������";
		return 0;
	}
	cout << ch << "�������ַ�";
	return 0;

}