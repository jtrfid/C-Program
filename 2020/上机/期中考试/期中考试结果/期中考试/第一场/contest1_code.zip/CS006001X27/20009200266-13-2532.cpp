#include <stdio.h>

int main() {
	int i, n, a, b, sum = 0, c;
	scanf("%d", &n);
	scanf("%d%d", &a, &b);

	for (i = 1; i <= n; i++) {
		scanf("%d", &c);
		if (c >= a && c <= b)
			sum++;



	}
	printf("%d", sum);
	return 0;






}