#include <stdio.h>

int qiuhe(int n) {
	int i, sum = 0;
	for (i = 1; i < n; i++) {
		if (n % i == 0)
			sum = sum + i;
	}
	return sum;

}

int main() {
	int n;
	int a = 2;
	scanf("%d", &n);
	int i, j;
	for (i = 1; i <= n; i++) {
		for (j = i + 1; j < n; j++) {
			if (qiuhe(i) == j && qiuhe(j) == i) {
				printf("(%d,%d)", i, j);

				a = 1;
			}
		}
	}
	if (a != 1)
		printf("nothing");


}