#include <stdio.h>

int main() {
	int a;
	scanf("%d", &a);

	if (a < 284)

	{
		printf("nothing");
	} else
		printf("(200,284)");

}