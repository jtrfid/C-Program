#include <stdio.h>

int main(void) {
	int n, a, b, x, y, s;
	x = 0;
	s = 0;
	scanf("%d %d %d\n", &n, &a, &b);
	int at[n];
	while (x < n) {
		scanf("%d ", &at[x]);
		x++;
	}
	for (y = 0; y < n; y++) {
		if (at[y] >= a && at[y] <= b) {
			s++;
		}
	}


	printf("%d", s);
}