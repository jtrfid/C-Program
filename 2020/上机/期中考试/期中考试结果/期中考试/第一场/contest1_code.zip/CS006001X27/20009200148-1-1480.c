#include <stdio.h>

int main() {
	char c;
	scanf("%c", &c);
	if ((c >= 'A') && (c <= 'Z')) {
		c = 'a' + (c - 'A');
		printf("%c", c);
	} else if (c >= 'a' && c <= 'z') {
		c = 'A' + (c - 'a');
		printf("%c", c);
	} else if (c >= '0' && c <= '9')
		printf("%c������", c);
	else
		printf("%c�������ַ�", c);

}