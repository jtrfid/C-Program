#include <stdio.h>

int main() {
	int n, i, j, count = 0, a[1], b[1];
	a[1] = -10000;
	b[1] = -10000;
	scanf("%d", &n);
	for (i = 2; i <= n; i++) {
		int suma = 0, sumb = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				suma = suma + j;
				//printf("%d", suma);
			}
		}
		if (suma == i) {
			continue;
		}
		for (j = 1; j < suma; j++) {
			if (suma % j == 0) {
				sumb = sumb + j;
			}
		}
		if (sumb == i) {
			a[1] = i;
			b[1] = suma;
			if (suma < i) {
				for (j = 1; j <= count; j++) {
					if (a[count] == suma || b[count] == i) {
						break;
					} else {
						printf("(%d,%d)", i, suma);
						count++;

					}

				}

			}

		}

	}
	if (count == 0) {
		printf("nothing");
	}
	return 0;
}
