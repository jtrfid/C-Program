#include <stdio.h>

int main() {
	char m, n, t, c;
	//ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz
	scanf("%c", &m);
	t = m;
	if (m >= 'A' && m <= 'Z') {
		n = m + 32;
		printf("%c", n);
	} else if (m >= 'a' && m <= 'z') {
		n = m - 32;
		printf("%c", n);
	}

	else	if (m < 'A') {
		printf("%c������", m);
	} else if (m > 'Z' && m < 'z') {
		printf("%c�������ַ�", m);
	} else if (m > 'z') {
		printf("nothing");
	}

	return 0;
}