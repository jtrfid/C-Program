#include <stdio.h>

int main() {
	int n, a, b, i, point, sum = 0;
	scanf("%d", &n);
	scanf("%d%d", &a, &b);
	for (i = 0; i < n; i++) {
		scanf("%d", &point);
		if (point >= a && point <= b) {
			sum++;
		}
	}
	printf("%d", sum);

	return 0;
}