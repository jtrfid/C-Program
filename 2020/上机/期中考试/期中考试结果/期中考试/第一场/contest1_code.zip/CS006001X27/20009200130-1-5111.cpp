#include <stdio.h>

int main() {
	char a;
	int i = 0;
	scanf("%c", &a);
	if (a >= 'A' && a <= 'z') {

		if (a >= 'A' && a <= 'Z') {
			a += 32;
		} else if (a >= 'a' && a <= 'z') {
			a -= 32;
		}
		printf("%c", a);
		i += 1;
	}
	if (a < 'A' || a > 'a') {
		printf("%d������", a);
		i += 1;
	}
	if (i == 0) {

		printf("%c�������ַ�", a);
	}


	return 0;
}