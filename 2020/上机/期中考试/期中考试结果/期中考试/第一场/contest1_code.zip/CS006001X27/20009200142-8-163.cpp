#include <stdio.h>

int main() {
	int m, n, a, i, d, b = 0;
	scanf("%d %d", &m, &n);
	if (n < m) {
		a = n;
		a = a;
		m = a;
	}
	for (i = m; i <= n; i++) {
		d = i * i;
		b = b + d;
		d = 0;
	}
	printf("%d", b);
}