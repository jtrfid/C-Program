#include <stdio.h>

int main() {
	int n, a, b;
	scanf("%d %d %d", &n, &a, &b);
	int i, num, count = 0;
	for (i = 0; i < n; i++) {
		scanf("%d", &num);
		if (num >= a && num <= b)
			count++;
		else
			continue;
	}
	printf("%d", count);
}