#include <stdio.h>

int main() {
	char i;
	scanf("%s", &i);
	if (i <= 'Z' && i >= 'A') {
		i = 'i' - 26;
		printf("%s", i);

	} else if (i <= 'z' && i >= 'a') {
		i = 'i' + 26;
		printf("%s", i);
	}

	return 0;

}