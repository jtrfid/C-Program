#include <stdio.h>

int main() {
	int i, k, M;
	char a[i], g;

	scanf("%c",&g);
	M = g;
	printf("%d",M);
	if (48<=M<=57)
		printf("%c������",M);

	if (65<=M<=90)
		printf("%c",M+32);
	if (97<=M<=122)
		printf("%c",M-32);




	return 0;
}