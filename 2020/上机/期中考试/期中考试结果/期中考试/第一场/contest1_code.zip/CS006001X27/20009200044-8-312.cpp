#include <iostream>
using namespace std;

int main() {
	int a, b, c = 0;
	cin >> a >> b;
	for (int i = a; i <= b; ++i)
		c += i * i;
	cout << c;

}