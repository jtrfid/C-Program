#include <stdio.h>
#include <math.h>

int sum() {
	scanf("%d, m, n&& 0 <= m <= n <= 100");
	sum = [m ^ 2 + (m + 1) ^ 2 + ... + n ^ 2;
	         printf("%d, sum");
	         return 0;
  }