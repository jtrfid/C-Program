#include <stdio.h>

int main() {
	int n, x = 0;
	int a, b, sum2, k;
	scanf("%d", &n);
	for (a = 1; a <= n; a++) {
		int i;
		if (a == k) {
			continue;
		}
		int sum1 = 0;
		for (i = 1; i < a; i++) {

			if (a % i == 0) {
				sum1 += i;
			}
			b = sum1;
		}
		if (b == a) {
			continue;
		}
		int j, sum2 = 0;
		for (j = 1; j < b; j++) {
			if (b % j == 0) {
				sum2 += j;
			}
		}

		if (sum2 == a) {
			x++;
			k = b;
			printf("(%d,%d)", a, b);
		}
	}
	if (x == 0) {
		printf("nothing");
	}
	return 0;
}