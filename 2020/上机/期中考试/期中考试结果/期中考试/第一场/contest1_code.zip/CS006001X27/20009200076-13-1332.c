#include <stdio.h>


int main () {
	int N, A, B, i, t;
	int count = 0;
	scanf("%d %d %d", &N, &A, &B);
	for (i = 1; i <= N; i++) {
		scanf("%d", &t);
		if (t >= A && t <= B)
			count++;
	}
	printf("%d", count);

	return 0;

}