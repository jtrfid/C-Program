#include <stdio.h>

int main() {
	int a, b, c, d, e, sum;
	scanf("%d %d", &a, &b);
	for (c = a; c <= b; c++) {
		d = c * c;
		e += d;
	}
	sum = e ;
	printf("%d", sum);
	return 0;
}
