#include <stdio.h>

int main() {
	int N, A, B, i, j = 0, x;
	scanf("%d %d %d", &N, &A, &B);
	for (i = 1; i <= N; i++) {
		scanf("%d", &x);
		if (x >= A && x <= B) {
			j = j + 1;
		} else {
			j = j;
		}
	}
	printf("%d", j);
	return 0;
}