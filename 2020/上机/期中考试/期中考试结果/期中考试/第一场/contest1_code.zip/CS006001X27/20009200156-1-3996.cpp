#include <stdio.h>

int main() {
	char n;
	scanf("%c", &n);
	if ('A' <= n <= 'Z') {
		printf("%c", n + 32);

	} else if ('a' <= n <= 'z') {
		printf("%c", n - 32);
	}
	n = (int)(n);
	if (48 <= n <= 57) {
		printf("%c������", n);
	} else if (57 < n < 65 || 97 > n > 91 || n > 123 || n < 48) {
		printf("%c�������ַ�", n);
	}
	return 0;
}