#include <stdio.h>

int main() {
	int n, a, b, i, c, j = 0;
	scanf("%d", &n);
	scanf("%d", &a);
	scanf("%d", &b);
	i = a;
	while (i <= n) {
		scanf("%d", &c);
		if (c <= b && c >= a) {
			j++;
		}

		i++;
	}
	printf("%d", j);
	return 0;
}