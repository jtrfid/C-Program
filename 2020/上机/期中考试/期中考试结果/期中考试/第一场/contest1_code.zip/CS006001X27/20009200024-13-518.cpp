#include <stdio.h>

int main() {
	int n, a, b;
	scanf("%d %d %d", &n, &a, &b);
	int c, i, cot = 0;
	for (i = 1; i <= n; i++) {
		scanf("%d", &c);
		if (c >= a && c <= b) {
			cot++;
		}
	}
	printf("%d", cot);
	return 0;
}