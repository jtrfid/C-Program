#include <stdio.h>

int main() {
	int m, n, i, j, sum;
	scanf("%d%d", &m, &n);
	for (i = m, sum = 0; i <= n; i++) {
		sum = sum + i * i;
	}
	printf("%d", sum);
	return 0;
}