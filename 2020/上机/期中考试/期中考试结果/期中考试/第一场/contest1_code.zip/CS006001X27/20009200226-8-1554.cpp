#include <stdio.h>

int main() {
	int  m, n, i;
	int sum = 0;
	scanf("%d %d", &m, &n);
	for (i = m; i <= n; i++) {
		sum += i * i;
	}
	printf("%d", sum);
	return 0;
}