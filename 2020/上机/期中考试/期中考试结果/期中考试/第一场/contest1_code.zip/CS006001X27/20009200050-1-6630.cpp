#include <stdio.h>

int main() {
	char t;
	char x, y;
	scanf("%c", &t);
	int m = t;
	int h, j;
	if (m >= 97 && m <= 122) {
		h = m - 32;
		x = h;
		printf("%c", x);
	}

	if (m >= 65 && m <= 90) {
		j = m + 32;
		y = j;
		printf("%c", y);
	}
	return 0;
}