#include <stdio.h>

int main(void) {
	int a, b, n, sum;
	int i, min, max, sum1;
	scanf("%d", &n);
	int e = 1;
	for (a = 2; a <= n; a++) {
		sum = 0;
		for (i = 1; i < a; i++) {
			if (a % i == 0) {
				sum += i;
			}
		}
		b = sum;
		sum1 = 0;
		for (i = 1; i < b; i++) {
			if (b % i == 0) {
				sum1 += i;

			}
		}
		if (sum1 == a && a != b) {

			e = 0;

			if (a < b) {
				min = a, max = b;
				printf("(%d,%d)", min, max);
			}
		}
	}
	if (e) {
		printf("nothing");
	}


	return 0;

}

