#include <stdio.h>

int main() {
	int n, a, b, i, sum = 0;
	scanf("%d %d %d", &n, &a, &b);
	for (i = 0; i < n; i++) {
		int s = 0;
		scanf("%d", &s);
		if (s >= a && s <= b)
			sum++;
	}
	printf("%d", sum);
	return 0;
}