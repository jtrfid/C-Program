#include <stdio.h>

int main() {
	int c = 0, d = 0, n, a = 2, b, i = 0;
	scanf("%d", &n);
	while (a <= n) {
		for (b = 1; b < a; b++) {
			if (a % b == 0) {
				c += b;
			}
		}
		for (b = 1; b < c; b++) {
			if (c % b == 0) {
				d += b;
			}
		}
		if (d == a && a != c && a < c) {
			printf("(%d,%d)", a, c);
			i += 1;
		}
		c = 0;
		d = 0;
		a++;


	}
	if (i == 0)
		printf("nothing");






	return 0;
}