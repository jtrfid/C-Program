#include <stdio.h>

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	int i = m;
	int sum = 0;
	for (; i <= n; i++) {
		sum += i * i;
	}
	printf("%d", sum);
	return 0;
}