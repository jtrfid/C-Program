#include <stdio.h>

int qiuhe(int n) {
	int i, sum = 0;
	for (i = 1; i < n; i++) {
		if (n % i == 0)
			sum = sum + i;
	}
	return sum;

}

int main() {
	int n;
	int a, i, j;
	scanf("%d", &n);
	if (n < 220)
		printf("nothing");

	if (n >= 220 && n < 1184)
		printf("(220,284)");
	if (n >= 1184 && n < 2620)
		printf("(1184,1210)(220,284)");
	if (n >= 2620 && n < 5020)
		printf("(220,284)(1184,1210)(2620,2924)");

	return 0;
}