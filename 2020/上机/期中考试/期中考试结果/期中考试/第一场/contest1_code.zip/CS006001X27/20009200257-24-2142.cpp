#include <bits/stdc++.h>
using namespace std;
int n, f;
int a[100010];

inline int gg(int x) {
	int sum = -x;
	for (int i = 1; i <= sqrt(1.0 * x); ++i) {
		if (x % i == 0)
			sum += i + x / i;
	}
	return sum;
}

int main() {
	scanf("%d", &n);
	for (int i = 200; i <= n; ++i)
		a[i] = gg(i);
	for (int i = 200; i <= n; ++i)
		for (int j = i + 1; j <= n; ++j)
			if (a[i] == j && a[j] == i)
				f = 1, printf("(%d,%d)", i, j);
	if (!f)
		printf("nothing");
	return 0;
}