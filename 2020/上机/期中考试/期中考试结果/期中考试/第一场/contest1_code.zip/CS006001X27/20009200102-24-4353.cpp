#include <stdio.h>

int main() {
	int n, j, k, i, sum, s;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= i / 2; j++) {
			if (i % j == 0) {
				sum += j;
			} else {
				sum = sum;
			}
		}
		for (k = 1; k <= sum / 2; k++)
			if (sum % k == 0) {
				s += k;
			}
		if (s == sum && sum <= n && i < sum)
			printf("(%d,%d)", i, sum);
	}
	return 0;
}
