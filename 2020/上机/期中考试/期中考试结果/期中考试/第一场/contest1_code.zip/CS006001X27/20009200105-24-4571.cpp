#include <stdio.h>
#include <math.h>

int main() {
	int a, b, n, c, d, e, f, g, i, s;
	g = 0;
	s = 0;
	f = 0;
	scanf("%d", &n);
	for (i = 1; i < n; i++) {
		for (a = 1; a < i; a++) {
			b = i % a;
			if (b == 0) {
				s = s + a;
			}
		}
		for (c = 1; c < n; c++) {
			for (d = 1; d < c; d++) {
				e = c % d;
				if (e == 0) {
					f = f + d;
				}
			}
			if ((f == s) && (i != c)) {
				printf("(%d,%d)", i, c);
				g = g + 1;
			}
		}
	}
	if (g == 0) {
		printf("nothing");
	}
	return 0;
}