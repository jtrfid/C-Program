#include <bits/stdc++.h>
using namespace std;
int n, m, sum;

int main() {
	scanf("%d%d", &n, &m);
	for (int i = n; i <= m; ++i)
		sum += i * i;
	printf("%d\n", sum);
	return 0;
}