#include <stdio.h>

int main() {
	int a, b, c = 0, i, j, n, x;
	int o[10000];
	int p[10000];
	scanf("%d", &a);
	for (i = 1; i <= a; i++) {
		p[i] = i;
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				c = c + j;
				o[i] = c;

			}
		}
		c = 0;
		for (x = i - 1; x > 0; x--) {
			if (o[i] == p[x] && o[x] == p[i])
				printf("(%d,%d)", p[x], p[i]);
		}

	}



}