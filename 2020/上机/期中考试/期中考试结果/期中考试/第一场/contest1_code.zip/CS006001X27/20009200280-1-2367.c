#include <stdio.h>
#include <ctype.h>

int main() {
	char n;
	scanf("%c", &n);
	if (isupper(n)) {
		n += 32;
		printf("%c", n);
	}
	if (islower(n)) {
		n -= 32;
		printf("%c", n);
	}
	if (isdigit(n)) {
		printf("%c������", n);
	}
	if (isupper(n) || islower(n) || isdigit(n))
		;
	else
		printf("%c�������ַ�", n);
	return 0;
}