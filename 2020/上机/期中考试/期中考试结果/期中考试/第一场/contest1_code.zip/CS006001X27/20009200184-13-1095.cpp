#include <iostream>
using namespace std;

int main() {
	int n, a, b, mark;
	cin >> n >> a >> b;
	int sum = 0;
	for (int i = 1; i <= n; i++) {
		cin >> mark;
		if (mark <= b && mark >= a)
			sum++;
	}
	cout << sum;
	return 0;
}