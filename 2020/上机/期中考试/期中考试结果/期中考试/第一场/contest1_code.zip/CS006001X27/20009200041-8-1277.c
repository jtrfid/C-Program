#include <stdio.h>

int main() {
	int m, n, i, sum = 0, a;
	scanf("%d %d", &m, &n);
	for (i = m; i <= n; i++) {
		a = i * i;
		sum = a + sum;
	}

	printf("%d", sum);

	return 0;
}