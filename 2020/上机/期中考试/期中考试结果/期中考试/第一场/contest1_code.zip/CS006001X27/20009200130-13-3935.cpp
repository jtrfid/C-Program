#include <stdio.h>

int main() {
	int i, n, a, b, c;
	scanf("%d %d %d", &n, &a, &b);
	for (i = 1; i <= n; i++) {
		scanf("%d", &c);
		if (c <= b && c >= a) {
			printf("%d", c);
		}
	}











	return 0;
}