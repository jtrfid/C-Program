#include<stdio.h> 
int main()
{
	int n,a,b,i,t,suma=0,sumb=0;
	scanf("%d",&n);
	for(a=1;a<=n;a++)
	for(b=2;b<=n;b++)
	for(i=1;i<a;i++)
	{
	if(a%i==0)
	suma+=i;
	for(t=1;t<b;t++){
	
	if(b%i==0)
	sumb+=t;
	if(suma==b&&sumb==a)
	printf("(%d,%d)",a,b);
	
	}
	
}
	

	
	return 0;
		
}
	

