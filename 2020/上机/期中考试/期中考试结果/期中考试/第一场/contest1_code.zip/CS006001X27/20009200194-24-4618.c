#include <stdio.h>

int main() {
	int A, B, i, n, s = 0;
	int sum = 0;
	scanf("%d", &n);
	for (A = 1; A <= n; A++) {
		sum = 0;
		for (i = 1; i < A; i++) {
			if (A % i == 0) {
				sum += i;
			}
		}
		B = sum;
		sum = 0;
		for (i = 1; i < B; i++) {
			if ( B % i == 0) {
				sum += i;
			}
		}
		if (sum == A && A < B) {
			printf("(%d,%d)", A, B);
			s += 1;
		}
	}
	if (s == 0) {
		printf("nothing");
	}
	return 0;
}