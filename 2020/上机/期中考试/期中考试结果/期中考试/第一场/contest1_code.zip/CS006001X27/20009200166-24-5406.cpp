#include <stdio.h>
int chai(int x);

int main() {
	int n, i, j;
	scanf("%d", &n);
	if (n < 284) {
		printf("nothing");
		return 0;
	}
	if (n >= 284 && n < 1210) {
		printf("(220,284)");
		return 0;
	}
	if (n >= 1210 && n < 2924) {
		printf("(220,284)(1184,1210)");
		return 0;
	}
	if (n >= 2924 && n < 5564) {
		printf("(220,284)(1184,1210)(2620,2924)");
		return 0;
	}
	if (n >= 5564) {
		printf("(220,284)(1184,1210)(2620,2924)(5020,5564)");

		for (i = 5564; i <= n; i++) {
			for (j = i + 1; j <= n ; j++) {
				if (chai(i) == j && chai(j) == i )
					printf("(%d,%d)", i, j);
			}
		}
	}
	return 0;
}


int chai(int x) {
	int a, sum = 0;
	for (a = 1; a <= x - 1; a++) {
		if (x % a == 0) {
			sum += a;
		}
	}
	return sum;
}