#include <stdio.h>

int main() {
	int n, i, j, sum, sum1;
	int count = 0;
	scanf("%d", &n);
	for (i = 2; i < n + 1; i++) {
		sum = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				sum += j;
			}
		}//������
		sum1 = 0;

		for (j = 1; j < sum; j++) {
			if (sum % j == 0) {
				sum1 += j;
			}
		}//�����͵�������
		if (sum < n + 1 && sum1 < n + 1 && sum == sum1 && i != sum1) {
			if (sum > i) {
				printf("(%d,%d)", i, sum);
			} else {
				printf("(%d,%d)", sum, i);
			}
			count = 1;
		}
	}
	//�ж���������

	if (count == 0)
		printf("nothing");
	return 0;
}