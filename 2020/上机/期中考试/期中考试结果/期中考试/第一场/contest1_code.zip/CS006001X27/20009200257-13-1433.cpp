#include <bits/stdc++.h>
using namespace std;
int n, a, b, ans, x;

int main() {
	scanf("%d%d%d", &n, &a, &b);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &x);
		if (x >= a && x <= b)
			++ans;
	}
	printf("%d\n", ans);
	return 0;
}