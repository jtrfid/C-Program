#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main() {
	long long int m, n, i, s = 0;
	cin >> m >> n;
	for (i = m; i <= n; i++) {
		s += i * i;
	}
	cout << s;
	return 0;
}