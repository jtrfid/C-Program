#include <stdio.h>

int main() {
	int n, k = 0, a, b, i, m, x[10000];
	scanf("%d %d %d", &n, &a, &b);
	for (i = 1; i <= n; i++) {
		scanf("%d", &x[i]);

	}

	for (m = 1; m <= n; m++) {
		if (x[m] >= a && x[m] <= b)
			k = k + 1;
		else
			k = k;
	}


	printf("%d", k);
	return 0;
}