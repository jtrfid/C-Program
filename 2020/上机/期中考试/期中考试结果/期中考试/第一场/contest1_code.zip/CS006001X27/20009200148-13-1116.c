#include <stdio.h>

int main() {
	int N;
	int A, B;
	scanf("%d %d %d", &N, &A, &B);
	int i, j;
	int sum = 0;
	for (i = 1; i <= N; i++) {
		scanf("%d", &j);
		if (j >= A && j <= B) {
			sum++;
		}
	}
	printf("%d", sum);
	return 0;

}