#include <stdio.h>

int main() {
	int n, a, b, i, j = 0;
	scanf("%d %d %d", &n, &a, &b);
	int num[n];

	for (i = 0; i < n; i++) {
		scanf("%d", &num[i]);
		if (num[i] >= a && num[i] <= b)
			j++;
	}


	printf("%d", j);


	return 0;

}