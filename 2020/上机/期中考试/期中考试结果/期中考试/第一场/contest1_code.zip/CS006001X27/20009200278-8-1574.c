#include <stdio.h>

int main() {
	int m, n, min, max;
	scanf("%d %d", &m, &n);
	if (m < n) {
		min = m;
		max = n;
	} else {
		min = n;
		max = m;
	}
	int sum = 0, i, pow;
	for (i = min; i <= max; i++) {
		pow = i * i;
		sum += pow;
	}
	printf("%d", sum);
	return 0;
}