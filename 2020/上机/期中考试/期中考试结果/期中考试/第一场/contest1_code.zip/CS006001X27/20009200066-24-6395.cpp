#include <stdio.h>

int main() {
	int n, A, B, sum1, sum2;
	scanf("%d", &n);
	if (n < 284)
		printf("nothing");
	for (A = 0; A <= n; A++) {
		int j, s = 0;
		sum1 = 0;
		for (j = 1; j < A; j++) {
			if (A % j == 0)
				s = s + j;
		}
		sum1 += s;
		B = sum1;
		if (B <= n) {
			int i, m = 0;
			sum2 = 0;
			for (i = 1; i < B; i++) {
				if (B % i == 0)
					m = m + i;
			}
			sum2 += m;
			if (sum2 == A && A < B)
				printf("(%d,%d)", A, B);
		}
	}
	return 0;
}