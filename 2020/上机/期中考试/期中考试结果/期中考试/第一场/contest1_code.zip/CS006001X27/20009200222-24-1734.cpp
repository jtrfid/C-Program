#include <stdio.h>

int main() {
	int a = 2, b, i = 1, j = 1, s = 0, ss = 0, vk = 0;
	scanf("%d", &b);
	while (a <= b) {
		while (i < a) {
			if (a % i == 0)
				s = s + i;
			i++;
		}
		while (j < s) {
			if (s % j == 0)
				ss = ss + j;
			j++;
		}
		if (ss == a && s != a && a < s) {
			printf("(%d,%d)", a, s);
			vk++;
		}
		a++;
		i = 1;
		j = 1;
		s = 0;
		ss = 0;
	}
	if (vk == 0)
		printf("nothing");
	return 0;
}