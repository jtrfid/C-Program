#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, j, k, l, sum, sum2 = 0, sum3 = 0;
	for (i = 2; i < n; i++) {
		int sum = 0;
		int sum2 = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				sum += j;
			}
		}
		for (k = n; k > i; k--) {
			if (sum == k) {
				for (l = 1; l < k; l++) {
					if (k % l == 0) {
						sum2 += l;
					}
				}
				if (sum2 == i) {
					printf("(%d,%d)", i, sum);
					sum3++;
				}
			}

		}

	}
	if (sum3 == 0) {
		printf("nothing");
	}



	return 0;
}
