#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int sum1[n] = {0};
	int sum2[n] = {0};
	int i, j, k, x, y, z;
	i = j = k = x = y = z = 1;
	for (i = 1; i <= n; i++) {
		for (k = 1; k < i; k++) {
			if (i % k == 0) {
				sum1[i] += k;
				sum2[i] += k;
				//printf("%d ?    ", k);
			}

		}
		//printf("%d %d\n", i, sum1[i]);
	}//����
	for (x = 1; x <= n; x++) {
		for (y = 1; y <= n; y++) {
			if (sum1[x] == y && sum2[y] == x && sum1[x] != x && (x < y)) { //����
				printf("%d %d\n", x, y);
			}
		}

	}
	return 0;
}
