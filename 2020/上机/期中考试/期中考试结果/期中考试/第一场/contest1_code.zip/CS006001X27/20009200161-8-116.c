#include <stdio.h>

int main() {
	int a, b, i, sum = 0;
	scanf("%d %d", &a, &b);
	for (i = a; i < b + 1; i++) {
		sum += i * i;
	}
	printf("%d", sum);
	return 0;
}