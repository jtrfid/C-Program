#include <stdio.h>

int main() {
	int m, n, a, sum;
	scanf("%d %d", &m, &n);
	a = m;
	while (a <= n) {
		sum += (a * a);
		a++;
	}
	sum -= 1;
	printf("%d", sum);
	return 0;
}