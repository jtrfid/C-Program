#include <stdio.h>

int main() {

	char a, b;
	scanf("%c", &a);
	if ('A' <= a && a <= 'Z') {

		b = a - 'A' + 'a';
		printf("%c", b);
	} else if ('a' <= a && a <= 'z') {
		b = a - 'a' + 'A';
		printf("%c", b);
	} else if ('0' <= a && a <= '9')
		printf("%c������", a);
	else
		printf("%c�������ַ�", a);
	return 0;
}