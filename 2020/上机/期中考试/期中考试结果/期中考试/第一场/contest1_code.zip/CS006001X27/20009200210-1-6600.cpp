#include <bits/stdc++.h>
using namespace std;
char c;

int main() {
	scanf("%c", &c);
	if (c >= 'a' && c <= 'z') {
		c = c - 32;
		cout << c;
		return 0;
	}
	if (c >= 'A' && c <= 'Z') {
		c = c + 32;
		cout << c;
		return 0;
	}
	if (c >= '0' && c <= '9') {
		cout << c << "������";
		return 0;
	}
	cout  << "?�������ַ�";
	return 0;

}
