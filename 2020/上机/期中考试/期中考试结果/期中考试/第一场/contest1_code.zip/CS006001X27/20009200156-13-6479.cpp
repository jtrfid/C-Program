#include <stdio.h>
#include <math.h>

int main() {
	int n, a, b, x, s = 0, i = 0;
	char h;
	scanf("%d %d %d", &n, &a, &b);

	for (i = 0; i <= n; i++) {
		scanf("%d", &x);
		if (a <= x <= b) {
			s = s + 1;
		}
	}

	printf("%d", s);
	return 0;
}