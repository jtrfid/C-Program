#include <stdio.h>

int main() {
	char a;
	int b;
	if (scanf("%c", &a ) == 1) {
		if (65 <= a <= 90)
			printf("%c", a - 32);
		else if (97 <= a <= 122)
			printf("%c", a + 32);
		else
			printf("%c�������ַ�", a);
	} else if (scanf("%d", &b) == 1)
		printf("%d", b);


	return 0;
}