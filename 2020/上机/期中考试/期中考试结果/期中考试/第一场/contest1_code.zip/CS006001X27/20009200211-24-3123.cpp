#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	if (n <= 220) {
		printf("(220,284)");
	}
	if (n < 220) {
		printf("nothing");
	}
	return 0;
}
