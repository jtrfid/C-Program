#include <stdio.h>

int yinzi(int n) {
	int i = 1;
	int sum = 0;
	for (; i < n; i++) {
		if (n % i == 0)
			sum += i;
	}
	return sum;
}

int main() {
	int n ;
	int i;
	int p;
	int sum1, sum2;
	scanf("%d", &n);
	for (i = 2; i < n; i++) {
		sum1 = yinzi(i);
		for (p = 2; p < n; p++) {
			sum2 = yinzi(p);
			if (sum1 == p && sum2 == i && i < p)
				printf("(%d,%d)", i, p);
		}
	}
	return 0;
}