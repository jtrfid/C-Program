#include <stdio.h>

int main() {
	int n, sumi, sumb, i, j, k = 0;

	scanf("%d", &n);

	i = 1;
	while (i <= n) {
		j = 1, sumi = 0;
		while (j < i) {
			if (i % j == 0) {
				sumi += j;
			}
			j++;
		}

		j = 1, sumb = 0;
		while (j < sumi) {
			if (sumi % j == 0) {
				sumb += j;
			}
			j++;
		}

		if (sumb == i && sumi != i && sumi < i) {
			printf("(");
			printf("%d,%d", sumi, i);
			printf(")");
			k++;
		}
		i++;
	}

	if (k == 0) {
		printf("nothing");
	}

	return 0;
}