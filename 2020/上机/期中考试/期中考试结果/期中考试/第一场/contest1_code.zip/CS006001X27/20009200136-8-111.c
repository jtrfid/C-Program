#include <stdio.h>
int a, b;
int ans = 0;


int main() {
	scanf("%d%d", &a, &b);
	for (int i = a; i <= b; i++) {
		ans += i * i;
	}
	printf("%d", ans);
	return 0;
}