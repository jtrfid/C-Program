#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i;
	int j, t1, t2;
	int sum1;
	int cnt = 0;
	for (i = 1; i <= n; i++) {
		int a = i;
		sum1 = 0;
		for (j = 1; j < a; j++) {
			if (a % j == 0) {
				sum1 += j;
				t1 = a;
			}
		}
		int b = sum1;
		int sum2 = 0;
		for (j = 1; j < b; j++) {
			if (b % j == 0) {
				sum2 += j;
			}
		}
		int t;
		if (sum2 == t1 && a != b && a + b != t) {
			printf("(%d,%d)", a, b);
			t = a + b;
			cnt++;
		}
	}
	if (cnt == 0) {
		printf("nothing");
	}

	return 0;
}