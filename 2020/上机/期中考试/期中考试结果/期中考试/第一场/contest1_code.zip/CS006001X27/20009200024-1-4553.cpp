#include <stdio.h>

int main() {
	char m, n, t, c;
	//ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz
	scanf("%c", &m);
	t = m;
	if (m >= 'A' && m <= 'Z') {
		n = m + 32;
		printf("%c", n);
	} else if (m >= 'a' && m <= 'z') {
		n = m - 32;
		printf("%c", n);
	} else {

		printf("%c�������ַ�", t);
	}


	return 0;
}