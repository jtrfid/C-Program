#include <stdio.h>

int main() {
	char m, n, t, c;
	//ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz
	scanf("%c", &m);
	if (m >= 'A' && m <= 'Z') {
		n = m + 32;
		printf("%c", n);
	} else if (m >= 'a' && m <= 'z') {
		n = m - 32;
		printf("%c", n);
	}

	else	if (m < 'A' || m >= '0') {
		printf("%c������", m);
	} else {
		printf("%c�������ַ�", m);
	}


	return 0;
}