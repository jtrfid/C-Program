#include <stdio.h>

int con[100000], k = 0;

int num(int n) {
	int i, sum = 0;
	for (i = 1; i < n; i++) {
		if (n % i == 0)
			sum += i;
	}
	return sum;
}

int conf(int n) {
	int i;
	for (i = 0; i <= k; i++) {
		if (n == con[i])
			return 0;
	}
	return 1;
}

int main() {
	int n, m, max, i, yes = 0;
	scanf("%d", &max);
	for (i = 1; i <= max; i++) {
		int m = num(i);
		if (m <= max && num(m) == i && m != i ) {
			if (conf(i) && conf(m)) {
				printf("(%d,%d)", i, m);
				yes = 1;
				con[k++] = i;
			}
		}
	}
	if (!yes) {
		printf("nothing");
	}
	return 0;
}