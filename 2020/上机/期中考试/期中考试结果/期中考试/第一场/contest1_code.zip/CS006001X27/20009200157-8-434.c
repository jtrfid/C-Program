#include <stdio.h>

int main() {
	int n, m, sum = 0, i;
	scanf("%d %d", &n, &m);
	for (i = n; i <= m; i++) {
		int squa = 1, j;
		for (j = 0; j < 2; j++) {
			squa *= i;
		}
		sum += squa;
	}
	printf("%d", sum);
	return 0;
}