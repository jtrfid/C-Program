#include <stdio.h>

int main() {
	int n, max, min, sum = 0;
	scanf("%d", &n);
	scanf("%d", &min);
	scanf("%d", &max);
	int a[n + 1];
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		if (a[i] >= min && a[i] <= max) {
			sum += 1;
		}
	}
	printf("%d", sum);
	return 0;
}