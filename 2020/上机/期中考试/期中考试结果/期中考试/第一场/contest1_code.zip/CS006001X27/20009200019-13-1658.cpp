#include <stdio.h>

int main() {
	int n, a, b;
	scanf("%d%d%d", &n, &a, &b);
	int x, i;
	int count = 0;
	for (i = 0; i < n; i++) {
		scanf("%d", &x);
		if (x >= a && x <= b)
			count++;
	}
	printf("%d", count);
	return 0;
}