#include <stdio.h>

int main(void) {
	int n, i, j, k, m = 1, p = 1, sum1 = 0, sum2 = 0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= i; j++) {
			if (i % j == 0)
				sum1 = sum1 + j;
			for (k = 1; k <= n; k++) {
				for (m; m <= k; m++)
					if (k % m == 0)
						sum2 = sum2 + m;
			}
		}
		if (sum1 == sum2)
			printf("(%d,%d)", sum1, sum2);
	}
	return 0;
}