#include <stdio.h>

int main() {
	char a;
	scanf("%c", &a);
	if (a >= 'A' && a <= 'Z') {
		a = a - 'A' + 'a' ;
		printf("%c", a);
	} else if (a >= 'a' && a <= 'z') {
		a = a + 'A' - 'a';
		printf("%c", a);
	} else if (a >= '0' && a <= '9')
		printf("%c������", a);
	else
		printf("%c�������ַ�", a);
	return 0;
}