#include <stdio.h>

int main() {
	int m, n, sum = 0, a = 1;
	scanf("%d %d", &m, &n);
	for (int i = 0; i <= n - m; i++) {
		a = (m + i) * (m + i);
		sum = a + sum;
	}
	printf("%d", sum);
	return 0;
}