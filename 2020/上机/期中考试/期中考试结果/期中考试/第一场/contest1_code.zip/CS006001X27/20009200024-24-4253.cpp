#include <stdio.h>

int main() {
	int a, b, n, m, i, cot = 0;
	int s = 0, t = 0;
	scanf("%d", &n);
	for (a = 200; a <= n; a++) {
		for (i = 1; i < a; i++) {
			if (a % i == 0) {
				t = t + i;
			}

		}

		for (b = 200; b <= n; b++) {
			for (m = 1; m < b; m++) {
				if (b % m == 0) {
					s = s + m;
				}
			}
			if (t == b && s == a && (a < b) ) {
				cot++;
				printf("(%d,%d)", s, t);
			}

			s = 0;
		}
		t = 0;
	}
	if (cot == 0) {
		printf("nothing");
	}
	return 0;
}