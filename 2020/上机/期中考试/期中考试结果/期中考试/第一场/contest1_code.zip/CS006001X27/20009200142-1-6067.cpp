#include <stdio.h>

int main() {
	char x, n, b;
	scanf("%c", &x);
	n = 'A' - x;
	b = 'a' - n;
	printf("%c", b);





}