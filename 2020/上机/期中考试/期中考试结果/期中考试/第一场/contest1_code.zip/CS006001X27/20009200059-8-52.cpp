#include <stdio.h>

int main() {
	int m, n, sum, a;
	sum = 0;
	scanf("%d %d", &m, &n);
	for (a = m; a <= n; a++)
		sum += a * a;




	printf("%d", sum);
	return 0;
}