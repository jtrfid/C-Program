#include <stdio.h>
int chai(int x);

int main() {
	int n, i, j;
	scanf("%d", &n);
	for (i = 3; i <= n; i++) {
		for (j = 3; j <= n; j++) {
			if (chai(i) == j && chai(j) == i && i != j && i < j)
				printf("(%d,%d)", i, j);
		}
	}
	if (n < 284)
		printf("nothing");
	return 0;
}


int chai(int x) {
	int a, sum = 0;
	for (a = 1; a <= x - 1; a++) {
		if (x % a == 0) {
			sum += a;
		}
	}
	return sum;
}