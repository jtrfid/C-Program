#include <stdio.h>
#include <math.h>

int main() {
	char ch;
	ch = getchar();
	if ((ch >= 'a') && (ch <= 'z')) {
		putchar(ch + 'A' - 'a');
	} else if ((ch >= 'A') && (ch <= 'Z')) {
		putchar(ch - 'A' + 'a');
	} else if ((ch >= '0') && (ch <= '9')) {
		printf("%c", ch);
		printf("������");
	} else {
		putchar(ch);
		printf(" �������ַ�");
	}
	return 0;
}