#include <stdio.h>

int main(void) {
	char ch;
	scanf("%c", &ch);
	if (ch >= 'a' && ch <= 'z') {
		printf("%c\n", ch - 32);
	} else if (ch >= 'A' && ch <= 'Z') {
		printf("%c\n", ch + 32);
	} else if (ch >= '0' && ch <= '9') {
		printf("%c������\n", ch);
	} else {
		printf("%c�������ַ�\n", ch);
	}
	return 0;
}