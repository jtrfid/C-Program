#include <stdio.h>

int main() {
	int n, a, b, score, i, sum = 0;
	scanf("%d %d %d\n ", &n, &a, &b);
	for (i = 1; i <= n; i++) {
		scanf("%d", & score);
		if (score >= a && score <= b)
			sum += 1;
		else
			continue;
	}
	printf("%d", sum);
	return 0;
}