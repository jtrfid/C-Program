#include <stdio.h>

int main() {
	int n, a, b, i = 0, vk = 1;
	scanf("%d %d %d", &n, &a, &b);
	int s[n + 1];
	while (vk <= n) {
		scanf("%d", &s[vk]);
		vk++;
	}
	while (vk >= 1) {
		if (a <= s[vk] && b >= s[vk]) {
			i++;
		}
		vk--;
	}
	printf("%d", i);
	return 0;
}