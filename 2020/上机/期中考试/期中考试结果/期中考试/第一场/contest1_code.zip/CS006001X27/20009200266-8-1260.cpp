#include <stdio.h>

int main() {
	int sum = 0, a, b, i;
	scanf("%d%d", &a, &b);
	for (i = a; i <= b; i++)
		sum += i * i;
	printf("%d", sum);
	return 0;






}