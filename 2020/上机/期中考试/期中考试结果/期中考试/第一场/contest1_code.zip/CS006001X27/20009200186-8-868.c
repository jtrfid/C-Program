#include <stdio.h>

int main() {
	int min, max;
	int n, sum = 0;
	scanf("%d%d", &min, &max);
	for (n = min; n <= max; n++) {
		sum += n * n;
//		printf("%d->%d\n", n, sum);
	}
	printf("%d", sum);
	return 0;
}