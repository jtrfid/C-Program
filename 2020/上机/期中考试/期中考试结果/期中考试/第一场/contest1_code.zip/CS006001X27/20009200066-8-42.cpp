#include <stdio.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, b, sum = 0;
	for (i = m; i <= n; i++) {
		b = i * i;
		sum += b;
	}
	printf("%d", sum);
	return 0;
}