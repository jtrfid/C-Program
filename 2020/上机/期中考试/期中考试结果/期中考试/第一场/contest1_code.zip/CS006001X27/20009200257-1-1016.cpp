#include <bits/stdc++.h>
using namespace std;
char a;

//a 97 A 65 32
int main() {
	cin >> a;
	if (a >= 'a' && a <= 'z')
		printf("%c\n", a - 32);
	else if (a >= 'A' && a <= 'Z')
		printf("%c\n", a + 32);
	else if (a >= '0' && a <= '9')
		printf("%c������\n", a);
	else
		printf("%c�������ַ�\n", a);
	return 0;
}