#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char letter;

	scanf("%c", &letter);
	if (65 <= letter && letter <= 90) {
		letter = letter + 32;
		printf("%c", letter);
	} else if (97 <= letter && letter <= 122) {
		letter = letter - 32;
		printf("%c", letter);
	} else if (0 <= letter && letter <= 9) {
		printf("%c������", letter);

	} else {
		printf("%c��������", letter);
	}

	return 0;
}