#include <stdio.h>

int main() {
	int a, b, i, c, sum = 0;
	scanf("%d %d", &a, &b);
	for (i = a; i <= b; i++) {
		c = i * i;
		sum += c;
	}
	printf("%d", sum);








	return 0;
}