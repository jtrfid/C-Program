#include <stdio.h>


int main() {
	char a;
	scanf("%c", &a);
	if (a <= 'Z' && a >= 'A') {
		a = a + 32;
		printf("%c", a);
	}
	if (a <= 'z' && a >= 'a') {
		a = a - 32;
		printf("%c", a);
	}
	if (a > 'Z' || a < 'a' || (a > 'z' && a < 'A')) {

		printf("%c�������ַ�", a);
	}

	return 0;
}