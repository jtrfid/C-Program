#include <stdio.h>

int main() {
	int n, i, j, sum = 0, sum1 = 0, count = 0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		sum = 0;
		sum1 = 0;
		for (j = 1; j < i; j++) {
			while (i % j == 0) {
				sum += j;
				//printf("%d", sum);
			}
		}
		if (sum == i) {
			continue;
		}
		for (j = 1; j < sum; j++) {
			while (sum % j == 0) {
				sum1 += j;
			}
		}
		if (sum1 == i && sum1 <= n) {
			count++;
			printf("(%d,%d)", i, sum);
		}
	}
	if (count == 0) {
		printf("nothing");
	}
	return 0;
}
