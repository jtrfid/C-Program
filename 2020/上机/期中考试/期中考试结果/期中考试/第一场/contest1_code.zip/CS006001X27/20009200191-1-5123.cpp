#include <stdio.h>

int main() {
	char n;
	int a, b, c;
	scanf("%c", &n);
	if ("n" <= "Z" && "n" >= "A")

	{
		a = n + ("a" - "A");
		printf("%c", a );
	} else if ("n" <= "z" && "n" >= "a") {
		b = n - ("a" - "A");
		printf("%c", b);
	}


	else if ("n" <= "0" && "n" >= "1") {
		printf("%c������", n);
	}

	else {
		printf("%c�������ַ�", n);
	}



	return 0;
}