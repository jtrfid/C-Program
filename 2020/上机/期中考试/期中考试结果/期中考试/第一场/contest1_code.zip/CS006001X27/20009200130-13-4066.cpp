#include <stdio.h>

int main() {
	int i, n, a, b, c, d = 0;
	scanf("%d %d %d", &n, &a, &b);
	for (i = 1; i <= n; i++) {
		scanf("%d", &c);
		if (c <= b && c >= a) {
			d += 1;
		}
	}
	printf("%d", d);










	return 0;
}