#include <stdio.h>

int main() {
	int N, A, B;
	scanf("%d %d %d", &N, &A, &B);
	int i, grade, sum = 0;
	for (i = 1; i <= N; ++i) {
		scanf("%d", &grade);
		sum += grade >= A && grade <= B ? 1 : 0;
	}
	printf("%d", sum);
	return 0;

}