#include <stdio.h>

int main() {
	char sign;
	scanf("%c", &sign);
	if (sign >= 'a' && sign <= 'z') {
		printf("%c", sign + 'A' - 'a');
	} else 	if (sign >= 'A' && sign <= 'Z')  {
		printf("%c", sign - 'A' + 'a');
	} else 	if (sign >= '0' && sign <= '9*')  {
		printf("%c������", sign );
	} else {
		printf("%c�������ַ�", sign );
	}
	return 0;
}
