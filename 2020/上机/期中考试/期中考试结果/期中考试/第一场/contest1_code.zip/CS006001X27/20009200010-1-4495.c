#include <stdio.h>
#include <math.h>

int main() {
	char letter;
	letter = getchar();
	if (letter >= 'A' && letter <= 'Z') {
		letter = letter + ('a' - 'A');
		printf("%c", letter);
	} else if (letter >= 'a' && letter <= 'z') {
		letter = letter - ('a' - 'A');
		printf("%c", letter);
	} else if (letter >= '0' && letter <= '9') {
		printf("%c������", letter);
	} else {
		printf("%c�������ַ�", letter);
	}
	return 0;
}