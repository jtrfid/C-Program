#include <stdio.h>

int main() {
	int n, i, j, b, sum1, point;
	int count = 0;
	scanf("%d", &n);
	for (i = 2; i < n + 1; i++) {
		if (i == point) {
			continue;
		}
		b = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				b += j;
			}
		}//������
		sum1 = 0;

		for (j = 1; j < b; j++) {
			if (b % j == 0) {
				sum1 += j;
			}
		}//�����͵�������
		if (b < n + 1 && sum1 < n + 1 && i == sum1 && i != b ) {
			if (b > i) {
				printf("(%d,%d)", i, b);
			} else {
				printf("(%d,%d)", b, i);
			}
			count = 1;
			point = b;
		}
	}
	//�ж���������

	if (count == 0)
		printf("nothing");
	return 0;
}