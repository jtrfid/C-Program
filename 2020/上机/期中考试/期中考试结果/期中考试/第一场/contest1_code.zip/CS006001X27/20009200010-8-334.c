#include <stdio.h>
#include <math.h>

int main() {
	int a, b, sum = 0, square, max, min;
	scanf("%d %d", &a, &b);
	max = (a > b) ? a : b;
	min = (a < b) ? a : b;
	for (; min <= max; min++) {
		square = min * min;
		sum += square;
	}
	printf("%d", sum);
	return 0;
}