#include <stdio.h>

int main(void) {
	int n, a, b, x, y, s;
	x = 1;
	s = 1;
	scanf("%d %d %d\n", &n, &a, &b);
	int at[n];
	while (x < n) {
		scanf("%d ", &at[x]);
		x++;
	}
	for (y = 1; y < n; y++) {
		if (at[y] >= a && at[y] <= b) {
			s++;
		}
	}
	printf("%d", s);
}