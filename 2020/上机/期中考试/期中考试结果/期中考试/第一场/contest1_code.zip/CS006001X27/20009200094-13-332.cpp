#include <stdio.h>

int main() {
	int n, a, b;
	scanf("%d %d %d", &n, &a, &b);
	int i;
	int sum = 0;
	int k;
	for (int i = 1; i <= n; i++) {
		scanf("%d", &k);
		if (k >= a && k <= b) {
			sum++;
		}

	}
	printf("%d", sum);
	return 0;
}
