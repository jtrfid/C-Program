#include <stdio.h>

int main() {
	int n, a, b, c, i = 1, j = 0;

	scanf("%d%d%d", &n, &a, &b);

	while (i <= n) {
		scanf("%d", &c);
		if (c >= a && c <= b) {
			j += 1;
		}
		i++;
	}

	printf("%d", j);

	return 0;
}