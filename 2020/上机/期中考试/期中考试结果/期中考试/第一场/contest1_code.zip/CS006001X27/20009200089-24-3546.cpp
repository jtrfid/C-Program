#include <stdio.h>

int main() {
	int n, i, k, sa, sb, a, b, s = 0;
	scanf("%d", &n);
	for (i = 1; i < n ; i++) {
		sa = 0;
		for (a = 1; a < i; a++) {
			if (i % a == 0)
				sa += a;
		}
		for (k = i + 1; k <= n; k++) {
			sb = 0;
			for (b = 1; b < k; b++) {
				if (k % b == 0)
					sb += b;
			}
			if (sa == k && sb == i) {
				printf("(%d,%d)", i, k);
				s++;
			}

		}
	}
	if (s == 0)
		printf("nothing");
	return 0;
}