#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i,j,k,h;
	int sum=0;
	int sum2=0;
	int n;
 int hhh=0;
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		for(j=1;j<i;j++)
		{
			if(i%j==0)
			{
				sum=sum+j;
			}
			
		}
		for(k=1;k<n;n++)
		{
			for(h=1;h<k;h++)
			{
				if(k%h==0)
				{
					sum2=sum2+h;
				}
			}
			if(sum==k&&sum2==i&&k!=i)
			{
				printf("(%d,%d)",k,i);
			}
			else
			{
			hhh=78;
			}
		}	
		
	}
	if(hhh=78)
	printf("nothing");
	
	return 0;
}