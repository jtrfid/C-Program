#include <stdio.h>

int main() {
	int n, min, max, x, y, i;
	scanf("%d%d%d", &n, &min, &max);
	for (i = 1, y = 0; i <= n; i++) {
		scanf("%d", &x);
		if (x >= min && x <= max)
			y++;
	}
	printf("%d", y);


	return 0;
}