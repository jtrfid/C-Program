#include <stdio.h>

int main() {
	int  b, n, count = 0;
	int i, j, sum;
	scanf("%d", &n);
	for (i = 1; i < n; i++) {
		sum = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				sum += j;
			}
		}
		b = sum;
		sum = 0;
		for (j = 1; j < b; j++) {
			if (b % j == 0) {
				sum += j;
			}
		}
		if (sum == i && i != b && i < b) {
			count++;
			printf("(%d,%d)", i, b);
		}
	}
	if (count == 0)
		printf("nothing");
	return 0;
}