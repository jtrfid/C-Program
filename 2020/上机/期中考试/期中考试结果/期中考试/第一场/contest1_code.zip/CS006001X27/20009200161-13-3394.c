#include <stdio.h>

int main() {
	int n, a, b, i, count = 0;
	scanf("%d %d %d ", &n, &a, &b);
	int c[100] = {0};
	for (i = 0; i < n; i++) {
		scanf("%d", c[i]);

	}
	for (i = 0; i < n; i++) {
		if (c[i] >= a && c[i] <= b) {
			count++;
		}
		printf("%d", count);
		return 0;
	}
}