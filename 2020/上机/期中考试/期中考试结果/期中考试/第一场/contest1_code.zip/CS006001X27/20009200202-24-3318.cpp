#include <stdio.h>

int main() {
	int n, a, b, i, sum1, sum2, y;
	scanf("%d", &n);
	for (a = 2; a <= n; a++) {
		for (b = a + 1; b <= n; b++) {
			y = 0;
			for (i = 1, sum1 = 0; i < a; i++) {
				if (a % i == 0)
					sum1 = sum1 + i;
			}
			for (i = 1, sum2 = 0; i < b; i++) {
				if (b % i == 0)
					sum2 = sum2 + i;
			}
			if (sum1 == b && sum2 == a) {
				printf("(%d,%d)", a, b);
			}
		}
	}


	return 0;
}