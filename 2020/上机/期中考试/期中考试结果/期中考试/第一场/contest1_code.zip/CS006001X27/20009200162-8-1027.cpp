#include<stdio.h>
int main()
{
	int x,y,z,sum;
	scanf("%d %d",&x,&y);
	for(sum=0;x<=y;x++){
		z=x;
		sum=sum+z*z;
	}
	printf("%d",sum);
	return 0;
}
