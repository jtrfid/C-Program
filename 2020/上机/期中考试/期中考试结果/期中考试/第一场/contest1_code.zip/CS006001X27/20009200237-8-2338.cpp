#include <stdio.h>

int main() {
	double n, m;
	int a, b, sum = 0;
	scanf("%lf %lf", &n, &m);
	for (int i = 0; i < n; i++)
		a = i + 1;
	for (int i = 0; i <= m; i++)
		b = i;
	for (int i = a; i <= b; i++)
		sum += i * i;
	printf("%d", sum);
	return 0;
}