#include <stdio.h>

int main() {
	int N, A, B;
	scanf("%d%d%d", &N, & A, & B);
	int i;
	int cnt = 0;
	for (i = 1; i <= N; i++) {
		int n;
		scanf("%d", &n);
		if (n >= A && n <= B) {
			cnt++;
		}
	}
	printf("%d", cnt);





	return 0;
}




