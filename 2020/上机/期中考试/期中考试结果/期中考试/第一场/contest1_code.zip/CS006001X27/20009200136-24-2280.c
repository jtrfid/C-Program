#include <stdio.h>

int mark[1000100] ;
int n;
int flag;
int solve(int k) {
	int sum = 0;
	for (int i = 1; i < k; i++) {
		if (k % i == 0)
			sum += i;
	}
	return sum;

}




int main() {
	int flag = 0;
	for (int i = 1; i <= 10; i++)
		mark[i] = 0;
	scanf("%d", &n);
	//printf("%d", solve(n));
	for (int i = 1; i <= n; i++) {
		if (mark[i] == 1)
			continue;
		mark[i] = 1;
		int j = solve(i);
		mark[j] = 1;
		if (j > n)
			continue;
		if (i == j)
			continue;
		if (solve(j) == i) {
			printf("(%d,%d)", i, j);
			flag = 1;

		}
	}
	if (flag == 0)
		printf("nothing");
	return 0;
}