#include <iostream>
using namespace std;

int main() {
	int n, a, b, de = 0;
	cin >> n;
	int count[n] = {0};
	for (int i = 1; i <= n; ++i) {
		for (int q = 1; q < i; ++q) {
			if (i % q == 0)
				count[i - 1] += q;
		}
	}
	for (int i = 1; i <= n; ++i) {
		for (int q = i + 1; q <= n; ++q) {
			if (count[i - 1] == count[q - 1] && (count[i - 1 ] != 1)) {
				cout << "(" << i << "," << q << ")";
				de = 1;
			}
		}
	}
	if (!de)
		cout << "nothing";
}