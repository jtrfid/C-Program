#include <stdio.h>

int main() {
	int N, A, B, t, n = 0;
	scanf("%d %d %d", &N, &A, &B);
	for (; N > 0; N--) {
		scanf("%d", &t);
		if (t >= A && t <= B) {
			n++;
		}
	}
	printf("%d", n);
	return 0;
}