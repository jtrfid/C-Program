#include <stdio.h>

int main() {
	int n, i, j, m, t;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		int sum = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0)
				sum += j;
		}
		for (m = i + 1; m <= n; m++) {
			int sum1 = 0;
			for (t = 1; t < m; t++) {
				if (m % t == 0)
					sum1 += t;
				if (sum == m && sum1 == i) {
					printf("(%d,%d)", i, m);
					break;
				}
			}

		}


	}
	//if (i > n)
	//	printf("nothing");
	return 0;
}