#include <stdio.h>

int main() {
	int n, m, n1, cout = 0;
	scanf("%d %d %d\n", &n, &m, &n1);
	for (; n > 0; n--) {
		int a;
		scanf("%d", &a);
		if (a >= m && a <= n1) {
			cout++;
		}

	}
	printf("%d", cout);
	return 0;
}