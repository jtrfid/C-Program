#include <stdio.h>

int main() {
	int N, A, B;
	scanf("%d %d %d", &N, &A, &B);
	int i, t, count = 0;
	for (i = 0; i < N; i++) {
		scanf("%d", &t);
		if (t >= A && t <= B)
			count++;
	}
	printf("%d", count);
	return 0;
}
