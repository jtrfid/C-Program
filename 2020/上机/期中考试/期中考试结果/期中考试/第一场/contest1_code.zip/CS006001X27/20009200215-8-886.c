#include <stdio.h>

int pf(int n) {
	int sum;
	sum = n * n;
	return sum;
}

int main() {
	int i1, i2, i3, i4, i5, sum = 0;
	scanf("%d", &i1);
	scanf("%d", &i2);
	i3 = i1;
	for (; i3 <= i2; i3++) {
		sum += pf(i3);
	}
	printf("%d", sum);
	return 0;
}