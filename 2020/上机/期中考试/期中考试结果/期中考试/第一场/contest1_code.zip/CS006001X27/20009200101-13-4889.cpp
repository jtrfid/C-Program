#include <stdio.h>

int main() {
	int N, A, B, i, grade, count = 0;

	scanf("%d %d %d\n", &N, &A, &B);


	for (i = 1; i <= N; i++) {
		scanf("%d", &grade);


		if (grade > B) {
			continue;
		}
		if (grade < A) {
			continue;
		}
		if (grade >= A && grade <= B)
			count++;
	}

	printf("%d", count);
	return 0;
}