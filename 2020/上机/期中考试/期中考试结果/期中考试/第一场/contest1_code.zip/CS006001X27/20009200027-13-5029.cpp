#include <stdio.h>

int main(void) {
	int a, b, c, g, n = 0, i = 1;
	scanf("%d %d %d", &a, &b, &c);
	for (i; i <= a; i++) {
		scanf("%d", &g);
		if (g >= b && g <= c)
			n++;
	}
	printf("%d\n", n);
	return 0;
}