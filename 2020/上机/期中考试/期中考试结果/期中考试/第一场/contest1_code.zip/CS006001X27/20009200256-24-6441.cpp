#include <stdio.h>

int ysh(int a) {
	int sum = 0;
	for (int i = 1; i < a; i++) {
		if (a % i == 0) {
			sum += i;
		}
	}
	return sum;
}

int main() {
	int n, num = 0;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (ysh(i) == j && ysh(j) == i) {
				printf("(%d,%d)", i, j);
				num += 1;
			}
		}
	}
	if (num == 0) {
		printf("nothing");
	}
	return 0;
}