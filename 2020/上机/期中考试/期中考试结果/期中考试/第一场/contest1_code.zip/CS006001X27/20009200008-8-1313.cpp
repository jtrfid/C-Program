#include <stdio.h>

int main(void) {
	int n, a, b;
	long sum;
	scanf("%d %d", &a, &b);
	sum = 0;
	n = a;
	while (n <= b) {
		sum = sum + n * n;
		n++;
	}
	printf("%d", sum);
}