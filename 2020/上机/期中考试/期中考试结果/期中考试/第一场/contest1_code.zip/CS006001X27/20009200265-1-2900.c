#include <stdio.h>
#include <ctype.h>

int main() {
	char c ;

	while (scanf("%c", &c) != EOF)

	{


		getchar();

		if (c >= '0' && c <= '9')

			printf("%c������", c);

		else if (c >= 'a' && c <= 'z' )

			printf("%c", toupper(c));
		else if (c >= 'A' && c <= 'Z')
			printf("%c", tolower(c));

		else
			printf("%c�������ַ�\n", c);
	}
	return 0;

}