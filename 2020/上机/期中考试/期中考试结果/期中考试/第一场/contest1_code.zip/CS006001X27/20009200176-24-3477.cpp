#include <stdio.h>
int qwe(int a);

int main() {
	int a, i, j, g = 0;
	scanf("%d", &a);
	for (i = 1; i <= a; i++) {
		for (j = 1; j <= a; j++) {
			if (qwe(i) == j && qwe(j) == i && i < j) {
				printf("��%d,%d��", i, j);
				g += 1;

			}
		}
	}
	if (g == 0) {
		printf("nothing");
	}











	return 0;
}

int qwe(int a) {
	int c, b, sum = 0;
	for (c = 1; c < a; c++) {
		for (b = 1; b < a; b++) {
			if (c * b == a) {
				sum = sum + c + b;
			}
		}
	}
	return (sum / 2 + 1);
}