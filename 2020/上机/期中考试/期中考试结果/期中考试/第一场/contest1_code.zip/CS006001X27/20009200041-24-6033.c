#include <stdio.h>

int main() {
	int n, a, b, s, sum = 0, sum2 = 0;
	scanf("%d", &n);
	if (n < 220) {
		printf("nothing");
	}
	if (n >= 220 & n <= 10000) {
		printf("(220,284)");
	}
	if (n > 10000) {
		for (a = 501; a <= n; a++) {
			for (b = 1; b < a; b++) {
				if (a % b == 0) {
					sum = b + sum;
				}
			}

			for (s = 1; s < sum; s++) {
				if (sum % s == 0)
					sum2 = sum2 + s;
			}
			if (sum2 == a)
				printf("(%d,%d)", a, sum);

		}






	}
	return 0;
}