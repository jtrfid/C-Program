#include <stdio.h>

int main() {
	int n, a, b;
	scanf("%d %d %d", &n, &a, &b);
	int i = 1;
	int number, count = 0;
	for (; i <= n; i++) {
		scanf("%d", &number);
		if (number >= a && number <= b)
			count++;
	}
	printf("%d", count);
	return 0;
}