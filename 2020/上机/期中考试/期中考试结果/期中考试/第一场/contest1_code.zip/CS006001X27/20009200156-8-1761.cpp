#include <stdio.h>

int main() {
	int sum = 0, m, n, i;
	scanf("%d %d", &m, &n);
	i = m;
	for (i = m; i < n + 1; i++) {
		sum += i * i;
	}
	printf("%d", sum);
	return 0;
}