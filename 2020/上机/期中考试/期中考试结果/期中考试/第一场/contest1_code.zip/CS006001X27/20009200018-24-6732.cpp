#include <stdio.h>

int main() {
	int a, b, c, d = 0, f, g, h = 0, sum;
	scanf("%d", &a);
	for (b = 2; b++; b <= a) {


		for (c = 1;  c < b; c++) {
			if (b % c == 0)
				d += c;



			for (h = 1;  h < d; h++) {
				if (d % h == 0)
					g += h;

			}


		}
		if (b = g && a >= 284 && b < d )
			printf("(%d,%d)", b, d);
		if (a < 284)
			printf("nothing");
	}
	return 0;
}
