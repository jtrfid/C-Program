#include<stdio.h>
int main()
{
	int n,a,b,c,d;
	scanf("%d %d %d",&n,&a,&b);
	d=0;
	for(;n>0;n--){
		scanf("%d",&c);
		if(c>=a&&c<=b)
			d++;
	}
	printf("%d",d);
	return 0;
}
