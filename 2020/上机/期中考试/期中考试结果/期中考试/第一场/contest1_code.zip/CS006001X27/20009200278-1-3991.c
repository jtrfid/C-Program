#include <stdio.h>

int main() {
	char zifu;
	scanf("%c", &zifu);
	int cha = 'a' - 'A';
	if (zifu > 'a' && zifu < 'z') {
		printf("%c", zifu - cha);
	} else if (zifu > 'A' && zifu < 'Z') {
		printf("%c", zifu + cha);
	} else if (zifu > '1' && zifu < '9') {
		printf("%d������", zifu - 48);
	} else {
		printf("! �������ַ�");
	}

	return 0;
}