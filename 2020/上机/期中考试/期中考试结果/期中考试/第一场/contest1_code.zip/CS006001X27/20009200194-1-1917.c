#include <stdio.h>

int main() {
	char c;

	c = getchar();
	if (c >= 97 && c <= 122) {
		printf("%c", c - 32);
	} else if (c >= 56 && c <= 90) {
		printf("%c", c + 32);
	} else if (c >= 49 && c <= 55 ) {
		printf("%c ������", c);
	} else {
		printf("%c �������ַ�", c);
	}
	return 0;
}