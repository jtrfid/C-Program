#include <stdio.h>

int main() {
	int n, a = 2, b = 2, x = 1, suma = 0, sumb = 0, i = 0;
	scanf("%d", &n);
	while (a <= n) {
		while (x < a) {
			if (a % x == 0) {
				suma += x;
			}
			x++;
		}
		x = 1;
		while (b <= n) {
			while (x < b) {
				if (b % x == 0) {
					sumb += x;
				}
				x++;
			}
			if (suma == b && sumb == a) {
				printf("(%d,%d)", a, b);
				i = 1;
			}
			x = 1;
			sumb = 0;
			b++;
		}
		suma = 0;
		a++;
	}
	if (i = 0) {
		printf("nothing");
	}
	return 0;

}