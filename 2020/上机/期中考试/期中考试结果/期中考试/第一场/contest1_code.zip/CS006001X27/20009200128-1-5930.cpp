#include <stdio.h>

int main() {
	char n, result;
	scanf("%c", &n);
	if (n >= 'A' && n <= 'Z') {
		result = n - ('A' - 'a');
		printf("%c", result);
	}
	if
	(n >= 'a' && n <= 'z') {
		result = n + ('A' - 'a');
		printf("%c", result);
	}

	if  (n < 'A')
		printf("n������");
	if (n > 'z')
		printf("n�������ַ�");

	return 0;

}
