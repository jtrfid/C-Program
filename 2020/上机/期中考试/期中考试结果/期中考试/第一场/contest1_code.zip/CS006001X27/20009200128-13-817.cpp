#include <stdio.h>

int main() {
	int n, a, b, c;
	int i;
	int sum = 0;
	scanf("%d %d %d\n", &n, &a, &b);
	for (i = 1; i <= n; i++) {
		scanf("%d", &c);
		if (c >= a && c <= b)
			sum++;
	}
	printf("%d", sum);
}