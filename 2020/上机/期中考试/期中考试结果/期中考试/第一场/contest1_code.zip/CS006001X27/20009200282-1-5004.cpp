#include <stdio.h>


int main() {
	char a;
	int i = 1;
	scanf("%c", &a);
	while (i <= 1) {
		if (a <= 'Z' && a >= 'A') {
			a = a + 32;
			printf("%c", a);
			break;
		}
		if (a <= 'z' && a >= 'a') {
			a = a - 32;
			printf("%c", a);
			break;
		}
		if (a > 'z' || a < 'A' || (a > 'Z' && a < 'a') && (a > 48 && a < 57)) {

			printf("%c�������ַ�", a);
			break;

			if (a > 48 && a < 57) {
				printf("%c�������ַ�");
				break;
			}

		}
	}

	return 0;
}