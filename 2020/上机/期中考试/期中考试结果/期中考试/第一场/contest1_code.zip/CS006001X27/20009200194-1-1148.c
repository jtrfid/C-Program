#include <stdio.h>

int main() {
	char c;
	int i;
	c = getchar();
	if (c >= 97 && c <= 122) {
		printf("%c", c - 32);
	} else if (c >= 56 && c <= 90) {
		printf("%c", c + 32);
	} else {
		printf("%c �������ַ�", c);
	}
	return 0;
}