#include <stdio.h>

int qhs(int a, int b) {
	int sum1 = 0, sum2 = 0;
	for (int i = 1; i < a; i++) {
		if (a % i == 0) {
			sum1 += i;
		}
	}
	for (int j = 1; j < b; j++) {
		if (b % j == 0) {
			sum2 += j;
		}
	}
	if (sum1 == b && sum2 == a) {
		return 1;
	} else
		return 0;
}

int main() {
	int n, num = 0;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (qhs(i, j) == 1) {
				printf("(%d,%d)", i, j);
				num += 1;
			}
		}
	}
	if (num == 0) {
		printf("nothing");
	}
	return 0;
}