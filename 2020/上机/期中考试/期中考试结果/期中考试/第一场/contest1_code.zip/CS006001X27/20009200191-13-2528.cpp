#include <stdio.h>

int main() {
	int n, c, b;
	int count = 0;
	int a[n + 1];
	scanf("%d %d %d", &n, &c, &b);

	for (int i = 1; i <= n; i++) {
		{
			scanf("%d ", &a[i]);
		}

		if (a[i] <= b && a[i] >= c) {
			count++;
		}

	}
	printf("%d", count);

	return 0;
}