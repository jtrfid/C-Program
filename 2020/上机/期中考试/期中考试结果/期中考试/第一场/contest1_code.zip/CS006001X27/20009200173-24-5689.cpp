#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);

	int a[n];
	int m = 0;
	for (int i = 2; i <= n; i++) {
		for (int j = 1; j < i; j++) {
			if ((i % j) == 0) {
				m += j;
			} else
				continue;
		}
		a[i] = m;
		m = 0;
	}

	int b;
	int i, j;
	int s = 0;
	for (i = 2; i < n; i++) {
		b = a[i];
		for (j = 3; j < n ; j++) {
			if (i == j)
				break;
			if (a[j] == i && a[i] == j) {
				if (i > j) {
					printf("(%d,%d)", j, i);
					s++;
					;
				} else {
					printf("(%d,%d)", i, j);
					s++;
				}

			} else
				continue;
		}
	}
	if (s == 0) {
		printf("nothing");
	}
	return 0;
}