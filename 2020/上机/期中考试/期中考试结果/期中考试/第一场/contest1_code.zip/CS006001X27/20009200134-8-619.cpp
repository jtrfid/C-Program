#include <stdio.h>
#include <windows.h>
#include <math.h>

int main() {
	int m = 0, n = 0, i = 0, sum = 0;
	scanf("%d %d", &m, &n);

	for (i = m ; i <= n ; i++) {
		sum += i * i;
	}

	printf("%d", sum);
	//system("pause");
	return 0;
}