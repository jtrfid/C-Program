#include <stdio.h>

int z(int n) {
	int i1 = 1, i2, i3, i4;
	int sum = 0, c = 0;
	while (i1 < n) {
		if (n % i1 == 0) {
			sum += i1;
		}
	}
	return sum;
}

int main() {
	int n, i1, i2, i3, i4, f = 0;
	scanf("%d", &n);
	for (i1 = 1; i1 <= n; i1++) {
		for (i2 = 1; i2 <= n; i2++) {
			printf("i2=%d ", i2);
			printf("i1=%d ", i1);
			if (z(i1) == i2 && z(i2) == i1) {
				if (i1 != i2) {
					printf("%d,%d", i1, i2);
					f = 1;
				}

			}
		}
	}
	if (f == 0) {
		printf("nothing");
		return 0;
	}
}



