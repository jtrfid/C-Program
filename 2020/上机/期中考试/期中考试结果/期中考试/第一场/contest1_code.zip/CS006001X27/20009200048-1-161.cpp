#include <stdio.h>

int main() {
	char ch;
	scanf("%c", &ch);

	if (ch >= 'A' && ch <= 'Z') {
		char temp = ch + 32;
		printf("%c\n", temp);
		return 0;
	} else if (ch >= 'a' && ch <= 'z') {
		printf("%c\n", ch);
		return 0;
	} else if (ch >= '0' && ch <= '9') {
		printf("%c������\n", ch);
	} else {
		printf("%c�������ַ�\n", ch);
	}


	return 0;
}