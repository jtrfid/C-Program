#include <stdio.h>

int main() {
	int a, b, c, i, d, e = 0, n;
	scanf("%d %d %d", &a, &b, &c);
	if (c < b) {
		n = c;
		c = c;
		b = n;
	}
	for (i = 0; i < a; i++) {
		scanf("%d", &d);
		if (d >= b && d <= c) {
			e++;
		}
	}
	printf("%d", e);
}