#include <iostream>
#include <cstdio>

int main() {
	int n, a, b;
	scanf("%d %d %d", &n, &a, &b);
	int i;
	int score, j;
	for (i = 0, j = 0; i < n; i++) {
		scanf("%d", &score);
		if (score >= a && score <= b) {
			j++;
		}
	}
	printf("%d", j);
	return 0;




}