#include <stdio.h>

int main() {
	int m, n, a, b, c, sum = 0;
	scanf("%d %d", &m, &n);
	for (b = m; b <= n; b++) {
		sum += b * b;
	}
	printf("%d", sum);
	return 0;
}