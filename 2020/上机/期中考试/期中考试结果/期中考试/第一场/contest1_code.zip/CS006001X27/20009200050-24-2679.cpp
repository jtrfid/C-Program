#include <stdio.h>

int main() {
	int n;
	int sua = 0;
	int sub;
	int num;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		for (int j = i + 1; j <= n; j++) {
			sua = 0;
			sub = 0;
			for (int m = 1; m < i; m++) {
				if (i % m == 0) {
					sua = sua + m;
				}
			}
			for (int h = 1; h < j; h++) {
				if (j % h == 0) {
					sub = sub + h;
				}
			}
			if (sua == j && sub == i) {
				printf("(%d,%d)", i, j);
				num++;
			}
		}
	}
	if (num == 0) {
		printf("nothing");
	}


	return 0;
}