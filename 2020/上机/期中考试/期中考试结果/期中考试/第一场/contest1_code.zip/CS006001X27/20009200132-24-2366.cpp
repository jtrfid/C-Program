#include <stdio.h>
#include <math.h>

int main() {
	int n, i, j, count = 0;
	scanf("%d", &n);
	int a[n + 1] = {0};
	for (i = 1; i <= n; i++) {
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				a[i] += j;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if (a[i] == j && a[j] == i) {
				if (a[i] < a[j])
					printf("(%d,%d)", a[i], a[j]);
				if (a[i] > a[j])
					printf("(%d,%d)", a[j], a[i]);
				count++;
			}
		}
	}
	if (count == 0)
		printf("nothing");
	return 0;
}