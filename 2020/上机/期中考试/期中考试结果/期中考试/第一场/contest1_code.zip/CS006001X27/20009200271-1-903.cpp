#include <iostream>
using namespace std;

int main() {
	char c;
	cin >> c;
	if (c >= 65 && c <= 90) {
		c += 32;
		cout << c;
	} else if (c >= 97 && c <= 122) {
		c -= 32;
		cout << c;
	} else if (c >= 48 && c <= 57) {
		cout << c << "������";
	} else {
		cout << c << "�������ַ�";
	}
	return 0;
}