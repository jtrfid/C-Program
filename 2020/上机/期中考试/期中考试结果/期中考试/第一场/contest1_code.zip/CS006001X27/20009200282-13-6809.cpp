#include <stdio.h>

int main() {
	int i, j, sum = 0, sum1 = 0;
	int a, b = 0, c = 1, d = 1, x = 1, y = 1;
	scanf("%d", &a);
	for (i = 1; i <= a; i++, sum = 0) {
		c = i;
		while (x < c) {
			if (c % x == 0) {
				sum += x;
				x++;
			}
		}
		for (j = i; j <= a; j++, sum1 = 0) {
			while (y < j) {
				if (j % y == 0) {
					sum1 += y;
					y++;
				}
				if (sum1 == c && sum == j) {
					printf("(%d,%d)", c, j);
					b = 1;
				}
			}
		}
	}

	if (b == 0)
		printf("nothing");
	return 0;
}