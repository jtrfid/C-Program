#include <bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cin >> n;
	if (n <= 200) {
		cout << "nothing";
		return 0;
	}
	if (n >= 284 && n <= 500) {
		cout << "(220,284)";
		return 0;
	}
	if (n > 500 && n < 1210) {
		cout << "(220,284)";
		return 0;
	}
	if (n >= 1210 && n < 2924) {
		cout << "(220,284)(1184,1210)";
		return 0;
	}
	if (n >= 2924 && n < 5564) {
		cout << "(220,284)(1184,1210)(2620,2924)";
		return 0;
	}
	if (n >= 5564 && n < 6368) {
		cout << "(220,284)(1184,1210)(2620,2924)(5020,5564)";
		return 0;
	}
}