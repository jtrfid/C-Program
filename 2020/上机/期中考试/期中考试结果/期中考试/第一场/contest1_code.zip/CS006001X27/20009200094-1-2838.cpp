#include <stdio.h>

int main() {
	char n;
	scanf("%c", &n);
	if (n >= 'a' && n <= 'z') {
		printf("%c", n + 'A' - 'a');
	}
	if (n >= 'A' && n <= 'z') {
		printf("%c", n + 'a' - 'A');
	}
	if (n >= 0 && n <= 9) {
		printf("%d������", n);
	}
	return 0;
}
