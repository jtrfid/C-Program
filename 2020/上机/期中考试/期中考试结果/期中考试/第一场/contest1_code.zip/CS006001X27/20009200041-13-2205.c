#include <stdio.h>

int main() {
	int n, a, b, i, s, sum = 0;
	scanf("%d %d %d", &n, &a, &b);
	for (i = 1; i <=  n; i++) {
		scanf("%d", & s);
		if (s >= a & s <= b)
			sum++;
	}
	printf("%d", sum);



	return 0;
}