#include <stdio.h>

int main() {
	int n, i1, i2, i3, i4, i5, i6;
	int q1, q2;
	scanf("%d", &n);
	scanf("%d", &q1);
	scanf("%d", &q2);
	int count = 0, t;
	for (i1 = 1; i1 <= n; i1++) {
		scanf("%d", &t);
		if (t >= q1 && t <= q2) {
			count++;

		}
	}
	printf("%d", count);
	return 0;
}