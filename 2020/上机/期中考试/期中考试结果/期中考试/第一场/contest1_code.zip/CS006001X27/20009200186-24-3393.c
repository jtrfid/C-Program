#include <stdio.h>

int fun(int n) {
	int m, sum = 0;
	for (m = 1; m <= n / 2; m++) {
		if (n % m == 0)
			sum += m;
	}
	return sum;
}

int ch(int m, int *date) {
	int n = 0;
	for (n = 0; n < 10; n++)
		if (date[n] == m) {
			return -1;
		}
	return 1;
}

int main() {
	int count = 0, n, a;
	int max;
	int date[10] = {0}, d = 0;
	scanf("%d", &max);
	for (n = 2; n < max; n++) {

		a = 0;
		a = fun(n);
		if (fun(a) == n && a != n) {
			date[d++] = a;
			if (ch(n, date) == 1)
				printf("(%d,%d)", n, a);
			count++;
		}
	}
	if (count == 0)
		printf("nothing");
	return 0;

}