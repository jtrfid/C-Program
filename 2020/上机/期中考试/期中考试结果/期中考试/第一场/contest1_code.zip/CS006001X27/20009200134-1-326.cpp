#include <stdio.h>
#include <windows.h>
#include <math.h>

int main() {
	int n, k, i = 0;
	char a;
	scanf("%c", &a);
	if (a <= 122 && a >= 97) {
		printf("%c", a - 32);
	} else if (a <= 57 && a >= 48) {
		printf("%c������", a);
	} else if (a <= 90 && a >= 65) {
		printf("%c", a + 32);
	} else {
		printf("%c�������ַ�", a);
	}


	//printf("%d", a);




	//system("pause");
	return 0;
}

/*

printf("%d" , );

for( ; i < n ; i++)
{

}

if()
{

}
else if()
{

}

scanf("%d" , &);

double a;//.5lf
char a;//c s

double u = pow(double a , double b);
double u = sqrt(a);

max = a > b ? a : b;


a:97
z:122
0:48
9:57
A:65
Z:90
*/