#include <stdio.h>

int main() {
	int n, a, b, i = 1, c, j = 0;
	scanf("%d", &n);
	scanf("%d", &a);
	scanf("%d", &b);
	printf("\n");
	while (i <= n) {
		scanf("%d", &c);
		if (c <= b && c >= a) {
			j++;

		}

		i++;
	}
	printf("%d", j);
	return 0;
}