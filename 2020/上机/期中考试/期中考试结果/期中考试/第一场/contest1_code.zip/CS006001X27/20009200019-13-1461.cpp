#include <stdio.h>

int main() {
	int n, a, b;
	scanf("%d%d%d", &n, &a, &b);
	int cj[n];
	int count = 0;
	for (int i = 0; i < n; i++) {
		scanf("%d", &cj[i]);
		if (cj[i] >= a && cj[i] <= b)
			count++;
	}
	printf("%d", count);
	return 0;
}