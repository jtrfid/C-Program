#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int N,A,B;
	int i;
	int count=0;
	int grade;
	scanf("%d",&N);
	scanf("%d",&A);
	scanf("%d",&B);
	for(i=0;i<N;i++)
	{
		scanf("%d",&grade);
		if(A<=grade&&grade<=B)
		{
			count++;
		}
		
	}
	printf("%d",count);
	return 0;
}