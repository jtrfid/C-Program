#include <stdio.h>

int main() {
	int sum = 0;
	int N, A, B, i, fen;
	scanf("%d%d%d", &N, &A, &B);
	for (i = 0; i < N; i++) {
		scanf("%d", &fen);
		if (fen >= A && fen <= B) {
			sum += 1;
		}
	}
	printf("%d", sum);
	return 0;
}