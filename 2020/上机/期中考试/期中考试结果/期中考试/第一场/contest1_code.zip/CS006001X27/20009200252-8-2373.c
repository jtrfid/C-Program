#include <stdio.h>

int main() {
	int num, m, n, sum;
	scanf("%d %d", &m, &n);
	for (num = m, sum = 0; num <= n; ++num)
		sum += num * num;
	printf("%d", sum);
	return 0;
}