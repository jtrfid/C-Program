#include <stdio.h>

int main() {
	char c;
	c = getchar();

	if (c >= 'a' && c <= 'z') {
		printf("%c", c - 32);
	} else if (c >= 'A' && c <= 'Z') {
		printf("%c", c + 32);
	} else if (c >= 49 && c <= 57 ) {
		printf("%c������", c);
	}  else {
		printf("%c�������ַ�", c);
	}

	return 0;
}