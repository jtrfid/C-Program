#include <stdio.h>

int main() {
	int n, A, B, i, j, sum1, sum2, max, min;
	sum1 = 0;
	sum2 = 0;
	max = 0;
	min = 0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		sum1 = 0;
		sum2 = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0)
				sum1 += j;
		}
		A = i;
		B = sum1;
		if (A == B)
			continue;
		for (j = 1; j < B; j++) {
			if (B % j == 0)
				sum2 += j;
		}
		if (A == sum2 && i != min) {

			max = sum2;
			min = sum1;
			printf("(%d,%d)", A, B);


		}



	}
	if (max == 0 && min == 0)
		printf("nothing");
	return 0;
}