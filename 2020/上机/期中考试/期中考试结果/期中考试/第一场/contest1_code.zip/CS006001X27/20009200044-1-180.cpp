#include <iostream>
using namespace std;

int main() {
	char a, b;
	cin >> a;
	if (a <= 'Z' && a >= 'A') {
		b = a - 'A' + 'a';
		cout << b;
	} else if (a <= 'z' && a >= 'a') {
		b = a + 'A' - 'a';
		cout << b;
	} else if (a <= '9' && a >= '0') {
		cout << a << "������";
	} else
		cout << a << "�������ַ�";

}