#include <stdio.h>

int main() {
	char w;
	scanf("%c", &w);
	if (w >= 'A' && w <= 'Z') {
		printf("%c", w + 'a' - 'A');
	} else if (w >= 'a' && w <= 'z') {
		printf("%c", w - 'a' + 'A');
	} else if (w >= '0' && w <= '9') {
		printf("%c������", w);
	} else {
		printf("%c�������ַ�", w);
	}
	return 0;
}