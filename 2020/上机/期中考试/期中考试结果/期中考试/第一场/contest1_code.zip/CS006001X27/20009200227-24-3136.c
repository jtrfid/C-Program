#include <stdio.h>

int main() {
	int n, i = 0, sum = 0, nm, nl, he = 0;


	scanf("%d", &n);
	for (i = 2; i <= n; i++) {
		for (nm = 1; nm < i; nm++) {
			if (i % nm == 0) {
				sum = nm + sum;
			}
		}

		for (nl = 1; nl < sum; nl++) {
			if (sum % nl == 0)
				he = he + nl;

		}
		if (he == i) {
			if (sum > i) {

				printf("(%d,%d)", i, sum);
				i = sum ;
			} else if (i > sum) {

				printf("(%d,%d)", sum, i);

			}
		}
		he = 0;
		sum = 0;


	}


	return 0;
}