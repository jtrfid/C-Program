#include <stdio.h>

int main() {
	int m, date;
	int count = 0;
	int n, a, b;
	scanf("%d%d%d", &n, &a, &b);
	for (m = 0; m < n; m++) {
		scanf("%d", &date);
		if (date >= a && date <= b) {
			count++;
			printf("%d->%d\n", date, count);
		}
	}
//	printf("%d", count);
	return 0;
}