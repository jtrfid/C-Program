#include <stdio.h>

int fun(int n) {
	int m, sum = 0;
	for (m = 1; m <= n / 2; m++) {
		if (n % m == 0)
			sum += m;
	}
	return sum;
}

int main() {
	int count = 0, n, a;
	int max;
	scanf("%d", &max);
	for (n = 2; n < max / 2; n++) {
		a = 0;
		a = fun(n);
		if (fun(a) == n && a != n) {
			printf("(%d,%d)", n, a);
			count++;
		}
	}
	if (count == 0)
		printf("nothing");
	return 0;

}