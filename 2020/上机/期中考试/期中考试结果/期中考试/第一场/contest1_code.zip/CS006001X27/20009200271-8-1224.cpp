#include <iostream>
using namespace std;

int main() {
	int m, n;
	cin >> m >> n;
	int sum = 0;
	for (int i = m; i <= n; i++) {
		sum += i * i;
	}
	cout << sum;
	return 0;
}