#include <stdio.h>

int main() {
	char n;
	scanf("%c", &n);
	if (n >= 'a' && n <= 'z') {
		printf("%c", n - 32);
	} else if (n >= 'A' && n <= 'Z') {
		printf("%c", n + 32);

	} else if (n >= '0' && n <= '9') {
		printf("%c������", n);
	} else
		printf("%c�������ַ�", n);
	return 0;
}