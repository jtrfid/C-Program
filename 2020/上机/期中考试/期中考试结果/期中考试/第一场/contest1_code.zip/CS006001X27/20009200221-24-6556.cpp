#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int p(int n) {
	long long int sum = 0;
	for (long long int i = 1; i <= n  && i != n; i++) {
		if (n % i == 0)
			sum += i;
	}
	return sum;
}

int main() {
	long long int  i, n, j, a[10000], b[10000], count = 0;
	scanf("%d", &n);
	for (i = n; i >= 1; i -= 2 ) {
		int s = p(i);
		if (p(s ) == i && (s != i)) {
			a[++count]
			    = i;
			b[count] = p(i);
		}
	}
	if (count > 0) {
		for (i = 1; i <= count; i += 2 ) {
			printf("(%d,%d)", b[i], a[i]);
		}
		return 0;
	} else {
		cout << "nothing";
		return 0;
	}
}