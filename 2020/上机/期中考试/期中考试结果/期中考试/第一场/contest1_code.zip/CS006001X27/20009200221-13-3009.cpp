#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main() {
	int n, a, b, i, now[10000], count = 0;
	cin >> n >> a >> b;
	for (i = 1; i <= n; i++) {
		cin >> now[i];
		if (now[i] >= a && now[i] <= b) {
			count++;
		}
	}
	cout << count;
	return 0;
}