#include <stdio.h>

int main() {
	int n, i, j;
	scanf("%d", &n);
	int sum1 = 0, sum2 = 0;
	int m, h;
	if (n <= 2)
		printf("nothing");
	else {
		for (i = 2; i < n; i++)
			for (m = 2; m < n; m++) {
				sum1 = 0;
				for (j = 1; j < i; j++)
					if (i % j == 0)
						sum1 += j;
			}
		{
			sum2 = 0;
			for (h = 1; h < n; h++)
				if (m % h == 0)
					sum2 += h;
		}
		if (sum1 == sum2 && m != i)
			printf("(%d,%d)", i, m);
		else
			printf("nothing");
	}
	return 0;
}