#include <stdio.h>

int main() {
	char c;
	scanf("%c", &c);
	if (c >= '0' && c <= '9')
		printf("%c������", c);
	else if (c >= 'a' && c <= 'z')
		printf("%c", c - 32);
	else if (c >= 'A' && c <= 'Z')
		printf("%c", c + 32);
	else
		printf("%c�������ַ�", c);
	return 0;
}