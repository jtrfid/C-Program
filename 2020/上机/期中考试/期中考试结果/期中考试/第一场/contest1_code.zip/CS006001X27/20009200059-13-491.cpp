#include <stdio.h>

int main() {
	int N, A, B, c, i, sum;
	sum = 0;
	scanf("%d %d %d\n", &N, &A, &B);
	for (i = 1; i <= N; i++) {
		scanf("%d", &c);
		if (c >= A && c <= B)
			sum++;
	}
	printf("%d", sum);
	return 0;

}