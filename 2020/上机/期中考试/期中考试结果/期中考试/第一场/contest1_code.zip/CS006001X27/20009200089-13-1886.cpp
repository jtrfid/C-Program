#include <stdio.h>

int main() {
	int n, a, b, score, i, sum;
	scanf("%d %d %d\n ", n, a, b);
	scanf("%d", score);
	for (i = 2; i <= n; i++) {
		scanf("%d", score);
		if (score >= a && score <= b)
			sum++;
		else
			continue;
	}

	printf("%d", sum);
	return 0;
}