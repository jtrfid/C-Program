#include <stdio.h>

int main() {
	char x;
	scanf("%c", &x);
	if (x >= 65 && x <= 90) {
		printf("%c", x + 32);
	} else if (x >= 97 && x <= 122) {
		printf("%c", x - 32);
	} else if (x >= 48 && x <= 57) {
		printf("%c������", x);
	} else
		printf("%c�������ַ�", x);

	return 0;
}