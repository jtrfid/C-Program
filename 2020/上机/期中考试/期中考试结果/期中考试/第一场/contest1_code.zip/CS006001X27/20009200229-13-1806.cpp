#include<stdio.h> 
int main()
{
	int n,a,b,c,sum;
	scanf("%d %d %d\n",&n,&a,&b);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&c);
		if(a<=c&&c<=b)
		sum++;
	}
	printf("%d",sum); 
	return 0;
}
