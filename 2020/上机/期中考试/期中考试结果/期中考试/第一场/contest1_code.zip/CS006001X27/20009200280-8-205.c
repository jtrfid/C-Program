#include <stdio.h>

int main() {
	int m, n, sum;
	scanf("%d %d", &m, &n);
	for (sum = 0; m <= n; m++) {
		sum += m * m;
	}
	printf("%d", sum);
	return 0;
}