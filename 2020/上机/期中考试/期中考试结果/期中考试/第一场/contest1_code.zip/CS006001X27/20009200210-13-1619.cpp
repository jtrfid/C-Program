#include <bits/stdc++.h>
using namespace std;

int main() {
	int n, a, b;
	cin >> n >> a >> b;
	if (a > b)
		swap(a, b);
	int cnt, sum = 0;
	for (int i = 1; i <= n; i++) {
		cin >> cnt;
		if (cnt >= a && cnt <= b)
			sum++;
	}
	cout << sum;
	return 0;
}