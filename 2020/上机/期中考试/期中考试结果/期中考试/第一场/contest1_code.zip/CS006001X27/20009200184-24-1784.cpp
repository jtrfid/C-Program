#include <iostream>
using namespace std;
int sum[10005];

int son(int n) {
	int ans = 1;
	for (int i = 2; i * i <= n; i++)
		if (n % i == 0)
			ans += i + n / i;
	return ans;
}

int main() {
	int n;
	cin >> n;
	int f = true;
	for (int i = 2; i <= n; i++)
		sum[i] = son(i);
	for (int i = 2; i < n; i++)
		for (int j = i + 1; j <= n; j++)
			if (sum[i] == j && sum[j] == i) {
				cout << '(' << i << ',' << j << ')';
				f = false;
			}
	if (f)
		cout << "nothing";
	return 0;
}