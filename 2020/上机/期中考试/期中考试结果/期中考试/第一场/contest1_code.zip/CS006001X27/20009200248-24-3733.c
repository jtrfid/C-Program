#include <stdio.h>

int main() {
	int n;
	int i;
	int k;
	int cnt = 0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		int sum1 = 0;
		int j;
		for (j = 1; j < i; j++) {
			if (i % j == 0)
				sum1 += j;
		}
		for (k = 1; k < n; k++) {
			int sum2 = 0;
			int j2;
			for (j2 = 1; j2 < k; j2++) {
				if (k % j2 == 0)
					sum2 += j2;
			}
			if (sum1 == k && sum2 == i && sum1 != i && sum2 != k) {
				int max = (i > k) ? i : k;
				int min = (i > k) ? k : i;
				printf("(%d,%d)\n", max, min);
				cnt++;
			}

		}

	}
	if (cnt == 0)
		printf("nothing\n" );






	return 0;
}




