#include <stdio.h>

int main() {
	int i, n, a, b;
	scanf("%d %d %d", &n, &a, &b);
	int ch, sum = 0;
	for (i = 0; i < n; i++) {
		scanf("%d", &ch);
		if (ch <= b && ch >= a) {
			sum++;
		}
	}
	printf("%d", sum);
	return 0;
}