#include <stdio.h>
#include <windows.h>
#include <math.h>

int sum(int a) {
	int h = 0;
	for (int j = 1 ; j <= a / 2 ; j++) {
		if (a % j == 0) {
			h += j;
		}
	}

	return h;
}

int main() {
	int n, a = 0, b = 0;
	scanf("%d", &n);

	//printf("%d", sum(n));

	for (int i = 1 ; i <= n ; i++) {
		a = sum(i);
		if (i == sum(a) && i < a) {
			printf("(%d,%d)", i, a);
			b = 1;
		}
	}

	if (b == 0)
		printf("nothing");

	//system("pause");
	return 0;
}