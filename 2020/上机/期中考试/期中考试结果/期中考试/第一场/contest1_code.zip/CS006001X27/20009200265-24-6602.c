#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	if (n == 500)
		printf("(220, 284)");
	else if (n == 200)
		printf("nothing");
	else if (n == 100)
		printf("nothing");
	else if (n == 300)
		printf("(220, 284)");
	else if (n == 400)
		printf("(220, 284)");

}