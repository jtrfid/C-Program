#include <stdio.h>

int main() {
	char n;
	scanf("%c", &n);
	if ('a' <= n && n <= 'z') {
		printf("%c", n + 'A' - 'a');
	} else if ('A' <= n && n <= 'Z') {
		printf("%c", n - 'A' + 'a');
	} else if ('0' <= n && n <= '9') {
		printf("%c������", n);
	} else {
		printf("%c �������ַ�", n);
	}
	return 0;
}