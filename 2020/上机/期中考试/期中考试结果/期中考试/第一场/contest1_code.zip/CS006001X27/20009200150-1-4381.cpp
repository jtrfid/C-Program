#include <stdio.h>

int main() {
	char n;
	scanf("%c", &n);
	if (n >= '0' && n <= '0' + 9) {
		printf("%c������", n);
	} else if (n >= '0' + 17 && n <= '0' + 43) {
		printf("%c", n + 32);
	} else if (n >= '0' + 50 && n <= '0' + 76) {
		printf("%c", n - 32);
	} else {
		printf("%c �������ַ�", n);
	}
	return 0;
}