#include <stdio.h>

int main() {
	int m, n, a, sum = 0;
	scanf("%d %d", &m, &n);
	a = m;
	while (a <= n) {
		sum += (a * a);
		a++;
	}
	printf("%d", sum);
	return 0;
}