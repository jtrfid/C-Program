#include <iostream>
#include <cstdio>

int yinzihe(int a) {
	int i;
	int sum = 0;
	for (i = 1; i < a; i++) {
		if (a % i == 0) {
			sum += i;
		}
	}
	return sum;


}

int main() {
	int n;
	scanf("%d", &n);
	int geshu[n + 10];
	int i, j;
	int num = 0;
	for (i = 1; i <= n; i++) {
		geshu[i] = yinzihe(i);
	}

	for (i = 1; i <= n / 2; i++) {
		for (j = i + 1; j <= n; j++) {
			if (geshu[j] == i && geshu[i] == j) {
				printf("(%d,%d)", i, j);
				num++;

			}
		}
	}
	if (num == 0) {
		printf("nothing");
	}
	return 0;

}