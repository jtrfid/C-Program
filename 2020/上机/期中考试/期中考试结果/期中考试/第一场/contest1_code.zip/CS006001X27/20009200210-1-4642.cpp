#include <bits/stdc++.h>
using namespace std;
char a;

int main() {
	cin >> a;
	if (a >= 'a' && a <= 'z') {
		a = a - 32;
		cout << a;
		return 0;
	}
	if (a >= 'A' && a <= 'Z') {
		a = a + 32;
		cout << a;
		return 0;
	}
	if (a >= '0' && a <= '9') {
		cout << a << "������";
		return 0;
	}
	cout << '!' << "�������ַ�";
	return 0;

}
