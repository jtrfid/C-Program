#include <stdio.h>
int rel(int n);

int main() {
	int n, a, b, i, j, num = 0;
	scanf("%d", &n);

	for (i = 1; i <= n; i++) {
		a = rel(i);
		for (j = i + 1; j <= n; j++) {
			b = rel(j);
			if (a == j && b == i) {
				printf("(%d,%d)", i, j);
				num++;
			}
		}
	}
	if (num == 0)
		printf("nothing");


	return 0;
}

int rel(int n) {
	int i, sum = 0;
	for (i = 1; i < n; i++) {
		if (n % i == 0)
			sum += i;
	}
	return sum;
}