#include <stdio.h>

int s[100100];
int n, a, b;
int ans = 0;

int main() {
	scanf("%d%d%d", &n, &a, &b);
	for (int i = 1; i <= n; i++) {
		int x;
		scanf("%d", &x);
		if (x <= b && x >= a)
			ans++;
	}
	printf("%d", ans);

	return 0;
}