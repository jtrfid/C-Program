#include <stdio.h>

int main() {
	int n, a, b, x, count = 0;
	scanf("%d %d %d", &n, &a, &b);
	for (int i = 0; i < n; i++) {
		scanf("%d", &x);
		if (x >= a && x <= b)
			count++;
	}
	printf("%d", count);
	return 0;
}