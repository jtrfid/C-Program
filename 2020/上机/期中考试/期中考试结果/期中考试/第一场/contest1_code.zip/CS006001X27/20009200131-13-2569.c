#include <stdio.h>

int main(void) {
	int n, a, b, i, z, j;
	j = 0;
	scanf("%d%d%d", &n, &a, &b);
	for (i = 0; i < n; i++) {
		scanf("%d", &z);
		if (z >= a && z <= b) {
			j++;
		}

	}
	printf("%d", j);

	return 0;
}
