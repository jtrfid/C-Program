#include <stdio.h>
#include <math.h>

int main() {
	int n, a, b, x, sum = 0, i = 0, c = 0, s[n];
	char h;
	scanf("%d %d %d", &n, &a, &b);
	scanf("%d", &s[n]);
	for (i = 0; i <= n; i++) {
		c = s[i];
		if (a <= c <= b)
			sum++;
	}
	sum = sum - 3;
	printf("%d", sum);
}