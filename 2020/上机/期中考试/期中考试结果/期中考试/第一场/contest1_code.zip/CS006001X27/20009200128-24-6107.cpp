#include <stdio.h>

int main() {
	int sum = 0;
	int y1 = 0;
	int y2 = 0;
	int a, b, n, i, j;
	scanf("%d", &n);
	for (a = 2; a <= n; a++) {
		for (b = 2; b <= n; b++) {
			for (i = 0; i < a; i++) {
				if (a % i == 0)
					y1 = y1 + i;
			}
			for (j = 0; j < b; j++) {
				if (b % j == 0)
					y2 = y2 + j;
			}
			if (y1 == b && y2 == a && (a != b)) {
				printf("(%d,%d)", a, b);
				sum++;
			}
			y1 = 0;
			y2 = 0;
			break;
		}
	}
	if (sum == 0)
		printf("nothing");
	return 0;
}
