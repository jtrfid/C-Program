#include<stdio.h> 
int main()
{
	int m,n,
	 sum,i;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++)
	{
		sum+=i*i;
	}
	printf("%d",sum);
	return 0;
}

	

