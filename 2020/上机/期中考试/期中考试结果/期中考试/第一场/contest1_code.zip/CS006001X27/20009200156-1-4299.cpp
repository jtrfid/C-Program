#include <stdio.h>

int main() {
	char n;
	scanf("%c", &n);
	if ('A' <= n <= 'Z') {
		printf("%c", n + 32);

	} else if ('a' <= n <= 'z') {
		printf("%c", n - 32);
	} else if ('0' <= n <= '9') {
		printf("%c������", n);
	} else
		printf("%c�������ַ�", n);

	return 0;
}