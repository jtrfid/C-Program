#include <stdio.h>

char a;


int main() {
	a = getchar();
	if (a >= 48 && a <= 57)
		printf("%c������", a);
	else if (a >= 65 && a <= 90)
		printf("%c", a + 32);
	else if (a >= 97 && a <= 122)
		printf("%c", a - 32);
	else
		printf("%c�������ַ�", a);
	//printf("%c", a);
}