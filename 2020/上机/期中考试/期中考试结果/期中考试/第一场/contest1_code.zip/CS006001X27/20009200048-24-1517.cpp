#include <stdio.h>
#include <stdlib.h>

int sum_factors(int a) {
	int i, ans = 0;

	for (i = 1; i < a; i++) {
		if (a % i == 0) {
			ans += i;
		}
	}
	return ans;


}

int main() {
	int i, n;
	int exist = 0;
	scanf("%d", &n);

	for (i = 1; i <= n / 2; i++) {
		int temp = sum_factors(i);
		if (sum_factors(temp) == i && i < temp) {
			printf("(%d,%d)", i, temp);
			exist = 1;
		}
	}
	if (exist == 0)
		printf("nothing\n");



	return 0;
}