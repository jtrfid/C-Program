#include <stdio.h>

int main() {
	int N, A, B;
	int i;
	int count = 0;
	scanf("%d %d %d\n", &N, &A, &B);
	int a[N];
	for (i = 0; i < N; i++) {
		scanf("%d", &a[i]);
		if (a[i] >= A && a[i] <= B) {
			count++;
		} else
			continue;
	}
	printf("%d", count);
	return 0;

}