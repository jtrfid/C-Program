#include <stdio.h>

int he(int n) {
	int i1 = 1, sum = 0;
	while (i1 < n) {
		if (n % i1 == 0) {
			sum += i1;
		}
		return sum;
	}
}


int main() {
	int n, i1, i2, i3, i4, i5, f = 0;
	scanf("%d", &n);
	if (n <= 200) {
		printf("nothing");
		return 0;
	}
	i1 = 201;
	i2 = 2;
	while (i1 <= n) {
		while (i2 <= n) {
			//printf("i1=%d ", i1);
			//printf("i2=%d ", i2);
			if ((he(i1) == i2) && he(i2) == i1) {
				printf("(%d,%d)", i1, i2);
				f = 1;
			}
			i2++;
		}
		i1++;
		i2 = 2;
	}
	if (f == 0) {
		printf("nothing");

	}
	return 0;


}