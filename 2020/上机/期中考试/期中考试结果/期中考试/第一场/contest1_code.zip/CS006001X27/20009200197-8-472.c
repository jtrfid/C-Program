#include <stdio.h>

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	int i, j;
	i = m;
	j = n;
	int sum = 0;
	for (i = m; i <= j; i++) {
		sum += i * i;
	}
	printf("%d", sum);
	return 0;
}