#include <stdio.h>

int main() {
	int N, A, B, count = 0, i, n;
	scanf("%d%d%d", &N, &A, &B);
	for (i = 1; i <= N; i++) {
		scanf("%d", &n);
		if (n <= B && n >= A) {
			count++;
		}
	}
	printf("%d", count);
	return 0;
}