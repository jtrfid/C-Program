#include <iostream>
#include <cstdio>

int yinzihe(int a) {
	int i;
	int sum = 0;
	for (i = 1; i < a; i++) {
		if (a % i == 0) {
			sum += i;
		}
	}
	return sum;


}

int main() {
	int n;
	scanf("%d", &n);
	int i, j;
	int num = 0;
	for (i = 1; i <= n / 2; i++) {
		int c = yinzihe(i);
		for (j = i + 1; j <= n; j++) {
			int d = yinzihe(j);
			if (d == i && c == j) {
				printf("(%d,%d)", i, j);
				num++;

			}
		}
	}
	if (num == 0) {
		printf("nothing");
	}
	return 0;

}