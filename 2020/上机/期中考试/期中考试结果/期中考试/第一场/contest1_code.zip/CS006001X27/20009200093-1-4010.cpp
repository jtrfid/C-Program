#include <stdio.h>

int main() {
	int i, k, M;
	char g;

	scanf("%c", &g);
	M = g;

	if ((48 <= M) && (M <= 57))

		printf("%c������", M);

	else if ((65 <= M) && (M <= 90))
		printf("%c", M + 32);
	else if ((97 <= M) && (M <= 122))
		printf("%c", M - 32);
	else
		printf("%c�������ַ�", M);



	return 0;
}