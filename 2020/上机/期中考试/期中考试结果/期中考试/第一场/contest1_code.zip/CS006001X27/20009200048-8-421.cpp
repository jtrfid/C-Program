#include <stdio.h>

int main() {
	int m, n;
	int i;
	int sum = 0;
	scanf("%d %d", &m, &n);

	for (i = m; i <= n; i++) {
		sum += i * i;
	}
	printf("%d\n", sum);
	return 0;
}