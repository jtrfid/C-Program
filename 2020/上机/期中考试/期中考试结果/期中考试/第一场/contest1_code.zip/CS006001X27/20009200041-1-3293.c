#include <stdio.h>

int main() {
	char z, b, c, a;
	scanf("%c", &a);
	b = a - 64;
	if (b <= (-7)&b >= (-16)) {
		printf("%c������", a);
	}
	if (b >= 0 & b <= 26) {
		c = a + 32;
		printf("%c", c);
	}
	if (b >= 32 & b <= 58) {
		c = a - 32;
		printf("%c", c);
	} else if (b > 58 || b < (-7) || b > 26 & b < 32 || b > (-7 & b < 0) ) {
		printf("%c�������ַ�", a);
	}
	return 0;
}