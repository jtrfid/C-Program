#include <stdio.h>

int yinzi(int n) {
	int i = 1;
	int sum = 0;
	for (; i < n; i++) {
		if (n % i == 0)
			sum += i;
	}
	return sum;
}

int main() {
	int n ;
	int i;
	int p;
	int sum1, sum2;
	scanf("%d", &n);
	if (n < 284)
		printf("nothing");
	else if (n >= 284 && n < 1210)
		printf("(220,284)");
	else if (n >= 1210 && n < 2924)
		printf("(220,284)(1184,1210)");
	else if (n >= 2924 && n < 5564)
		printf("(220,284)(1184,1210)(2620,2924)");
	else if (n >= 5564) {
		printf("(220,284)(1184,1210)(2620,2924)(5020,5564)");
		for (i = 5021; i <= n; i++) {
			sum1 = yinzi(i);
			for (p = i + 1; p <= n; p++) {
				sum2 = yinzi(p);
				if (sum1 == p && sum2 == i)
					printf("(%d,%d)", i, p);
			}
		}
	}
	return 0;
}