#include <stdio.h>
#include <math.h>

int main() {
	int a, b, n, c, d, e, f, g, i, s, h;
	g = 0;
	s = 0;
	f = 0;
	h = 0;
	scanf("%d", &n);
	for (i = 1; i < n; i++) {
		for (a = 1; a < i; a++) {
			b = i % a;
			if (b == 0) {
				s = s + a;
				h = h + a;
			}
		}
		if (h < n) {
			for (c = 1; c < h; c++) {

				e = h % c;
				if (e == 0) {
					f = f + d;
				}

			}
		}
		if ((f == i ) && (h != i)) {
			printf("(%d,%d)", i, h);
			g = g + 1;
		}
	}
	if (g == 0) {
		printf("nothing");
	}
	return 0;
}