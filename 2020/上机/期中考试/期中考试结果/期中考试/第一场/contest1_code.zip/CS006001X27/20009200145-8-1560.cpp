#include <iostream>
#include <cstdio>

int main() {
	int a, b;
	int i;
	scanf("%d %d", &a, &b);
	int sum = 0;
	for (i = a; i <= b; i++) {
		sum += i * i;
	}
	printf("%d", sum);
	return 0;









}