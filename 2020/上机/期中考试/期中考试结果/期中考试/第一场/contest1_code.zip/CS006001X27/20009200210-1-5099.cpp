#include <bits/stdc++.h>
using namespace std;
char c;

int main() {
	cin >> c;
	if (c >= 'a' && c <= 'z') {
		c = c - 32;
		cout << c;
		return 0;
	}
	if (c >= 'c' && c <= 'Z') {
		c = c + 32;
		cout << c;
		return 0;
	}
	if (c >= '0' && c <= '9') {
		cout << c << "������";
		return 0;
	}
	cout << c << "�������ַ�";
	return 0;

}
