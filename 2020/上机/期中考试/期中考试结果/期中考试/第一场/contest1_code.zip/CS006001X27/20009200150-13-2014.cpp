#include <stdio.h>

int main() {
	int x, N, A, B, i = 0, sum = 0;
	while (i < 3) {
		scanf("%d", &x);
		if (i == 0) {
			N = x;
		}
		if (i == 1) {
			A = x;
		}
		if (i == 2) {
			B = x;
		}
		i++;
	}
	i = 0;
	x = 0;
	while (i < N) {
		scanf("%d", &x);
		if (x >= A && x <= B) {
			sum += 1;
		}
		i++;
	}
	printf("%d", sum);
	return 0;

}