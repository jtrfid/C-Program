#include <stdio.h>

int main() {
	int a;
	scanf("%d", &a);

	if (a < 284)

	{
		printf("nothing");
	} else if (a >= 284 && a < 1184)
		printf("(200,284)");
	else
		printf("(200,284)(1184,1210)");

}