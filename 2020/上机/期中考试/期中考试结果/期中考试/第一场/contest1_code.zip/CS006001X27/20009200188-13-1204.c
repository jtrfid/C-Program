#include <stdio.h>

int main() {
	int n, a, b;
	scanf("%d %d %d", &n, &a, &b);
	int i;
	int x, cnt = 0;
	for (i = 0; i < n; i++) {
		scanf("%d", &x);
		if (x >= a && x <= b) {
			cnt++;
		}
	}
	printf("%d", cnt);
	return 0;
}