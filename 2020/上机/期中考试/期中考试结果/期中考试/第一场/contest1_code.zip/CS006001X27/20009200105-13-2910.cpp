#include <stdio.h>
#include <math.h>

int main() {
	int a, b, c, d, e, i;
	e = 0;
	scanf("%d%d%d", &a, &b, &c);
	for (i = 0; i < a; i++) {
		scanf("%d", &d);
		if ((d >= b) && (d <= c))
			e = e + 1;
	}
	printf("%d", e);
	return 0;
}