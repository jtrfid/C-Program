#include <stdio.h>


int main () {
	int n, i, sum = 0, sum1 = 0, count = 0;
	int t;
	scanf("%d", &n);
	for (t = 1; t <= n; t++) {
		int sum = 0, sum1 = 0;
		for (i = 1; i < t; i++) {
			if (t % i == 0) {
				sum += i;
			}
		}
		for (i = 1; i < t; i++) {
			if (sum % i == 0) {
				sum1 += i;
			}
		}
		if (t == sum1 && t != sum && t < sum) {
			printf("(%d,%d)", t, sum);
			count++;
		}
	}
	if (count == 0) {
		printf("nothing");
	}

	return 0;

}