#include <stdio.h>

int main() {
	int N, A, B;
	int a[1001];
	scanf("%d %d %d", &N, &A, &B);

	for (int i = 0; i < N; i++) {
		scanf("%d", &a[i]);
	}

	int num = 0;
	for (int j = 0; j < N; j++) {
		if (a[j] >= A && a[j] <= B)
			num++;
	}

	printf("%d", num);
	return 0;
}