#include <stdio.h>

int main() {
	int n, a, b, i, count = 0;
	scanf("%d %d %d ", &n, &a, &b);
	int c[100] = {0};
	for (i = 0; i < n + 1; i++) {
		scanf("%d", &c[i]);
		if (c[i] == 0)
			break;
	}
	for (i = 0; i < n; i++) {
		if (c[i] >= a && c[i] <= b) {
			count++;
		}
	}
	printf("%d", count);
	return 0;
}
