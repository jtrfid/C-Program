#include <stdio.h>

int yinzi(int n) {
	int i;
	int sum = 0;
	for (i = 1; i < n; i++) {
		if (n % i == 0) {
			sum += i;
		}
	}
	return sum;
}

int main() {
	int n;
	scanf("%d", &n);
	int i, j;
	int flag = 0;
	for (i = 1; i <= n; i++) {
		for (j = 1; j < i; j++) {
			if (yinzi(i) == j && yinzi(j) == i) {
				printf("(%d,%d)", j, i);
				flag = 1;
			}
		}
	}
	if (flag == 0) {
		printf("nothing");
	}
	return 0;
}
