#include <stdio.h>

int main() {
	int a, b, sum = 0, i;
	scanf("%d", &a);
	scanf("%d", &b);
	for (i = a; i <= b; i++) {
		sum = i * i + sum;
	}
	printf("%d", sum);
	return 0;
}