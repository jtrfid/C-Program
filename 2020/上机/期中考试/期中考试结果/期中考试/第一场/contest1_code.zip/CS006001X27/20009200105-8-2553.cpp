#include <stdio.h>
#include <math.h>

int main() {
	int m, n, i, s, t;
	scanf("%d%d", &m, &n);
	s = 0;
	i = m;

	t = n + 1;
	while (i != t) {
		s = s + (i * i);
		i = i + 1;

	}
	printf("%d", s);
	return 0;
}