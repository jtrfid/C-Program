#include <stdio.h>

int main() {
	int n, i, j, count = 0;
	scanf("%d", &n);
	for (i = 2; i <= n / 2; i++) {
		int suma = 0, sumb = 0;
		for (j = 1; j < i; j++) {
			if (i % j == 0) {
				suma = suma + j;
				//printf("%d", suma);
			}
		}

		if (suma == i) {
			continue;
		}
		for (j = 1; j < suma; j++) {
			if (suma % j == 0) {
				sumb = sumb + j;
			}
		}
		if (sumb == i) {
			printf("(%d,%d)", i, suma);
			count++;
		}

	}
	if (count == 0) {
		printf("nothing");
	}
	return 0;
}
