#include <stdio.h>

int main() {
	int N, A, B, a[100];
	int i, x = 0;
	scanf("%d%d%d", &N, &A, &B);
	for (i = 0; i < N; i++) {
		scanf("%d", &a[i]);
		if (a[i] >= A && a[i] <= B) {
			x += 1;
		}

	}
	printf("%d", x);

	return 0;
}