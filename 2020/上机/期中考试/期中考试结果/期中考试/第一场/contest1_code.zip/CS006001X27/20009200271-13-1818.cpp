#include <iostream>
using namespace std;

int main() {
	int n, a, b;
	cin >> n >> a >> b;
	int c[n];
	for (int i = 0; i < n; i++) {
		cin >> c[i];
	}
	int sum = 0;
	for (int i = 0; i < n; i++) {
		if (c[i] >= a && c[i] <= b)
			sum++;
	}
	cout << sum;
	return 0;
}