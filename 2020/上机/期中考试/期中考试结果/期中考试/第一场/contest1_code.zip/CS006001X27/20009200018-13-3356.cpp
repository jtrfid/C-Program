#include <stdio.h>

int main() {
	int a, b, c, d[1000], f, sum = 0;
	scanf("%d %d %d/n", &a, &b, &c);

	for (f = a; f--; f > 0) {
		scanf("%d", &d[f]);
		if (d[f] <= c && d[f] >= b)
			sum++;
	}



	printf("%d", sum);
	return 0;
}
