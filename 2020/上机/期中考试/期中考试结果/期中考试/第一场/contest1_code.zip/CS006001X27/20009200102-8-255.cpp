#include <stdio.h>

int main() {
	int m, n, a, i, sum = 0;
	scanf("%d %d", &m, &n);
	for (i = m; i <= n; i++) {
		a = i * i;
		sum += a;
	}
	printf("%d", sum);
	return 0;
}