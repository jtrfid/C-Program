#include <stdio.h>

int main() {
	int n, a, b, c, count, i;
	scanf("%d %d %d", &n, &a, &b);
	for (i = 0, count = 0; i < n; i++) {
		scanf("%d", &c);
		if (c <= b && c >= a)
			count++;
	}
	printf("%d", count);
	return 0;

}