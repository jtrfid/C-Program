#include <stdio.h>

int main() {
	char n;
	int sum = 0;
	scanf("%c", &n);
	if (n >= 'a' && n <= 'z') {
		printf("%c", n + 'A' - 'a');
		sum++;
	}
	if (n >= 'A' && n <= 'z') {
		printf("%c", n + 'a' - 'A');
		sum++;
	}
	if (n >= '0' && n <= '9') {
		printf("%c������", n);
		sum++;
	}
	if (sum == 0) {
		printf("%c�������ַ�", n);
	}

	return 0;
}
