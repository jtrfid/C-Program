#include <stdio.h>

int main() {
	int N, A, B;
	scanf("%d %d %d", &N, &A, &B);
	int i;
	int m;
	int k = 0;
	for (i = 0; i < N; i++) {
		scanf("%d", &m);
		if (A <= m && m <= B) {
			k++;
		}
	}
	printf("%d", k);
	return 0;
}