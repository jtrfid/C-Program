#include <stdio.h>

int main() {
	int m, n, sum = 0;
	scanf("%d", &m);
	scanf("%d", &n);
	for (int i = m; i <= n; i++) {
		sum += i * i;
	}
	printf("%d", sum);
	return 0;
}