#include <stdio.h>

int main() {
	int i = 1, N, A, B, c = 0;
	scanf("%d %d %d", &N, &A, &B);
	int a[N];
	for (i = 1; i <= N; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 1; i <= N; i++) {
		if (a[i] <= B && a[i] >= A) {
			c += 1;
		}
	}
	printf("%d", c);





	return 0;
}