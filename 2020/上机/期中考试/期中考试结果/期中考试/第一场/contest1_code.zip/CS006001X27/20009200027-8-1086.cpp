#include <stdio.h>

int main(void) {
	int a, b, sum = 0;
	scanf("%d %d", &a, &b);
	for (a; a <= b; a++) {
		sum = sum + a * a;
	}
	printf("%d\n", sum);
	return 0;


}