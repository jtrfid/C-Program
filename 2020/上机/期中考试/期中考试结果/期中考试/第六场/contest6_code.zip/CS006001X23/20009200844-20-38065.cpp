#include<stdio.h>
int main(){
	int m=0,n=0;
	int t=0;
	scanf("%d %d",&m,&n);
	if(m<n){
		t=m;
		m=n;
		n=t;
	}
	int i=0;
	for(i=n;i>0;i--){
		if(m%i==0&&n%i==0)
		break;
	}
	int u=0;
	u=m*n/i;
	printf("%d %d",i,u);
	
	
	
	return 0;
}
 
