#include<Cstdio>
#include<iostream>
#include<algorithm>
#include<cstdlib>
using namespace std;
int main()
{
	int m,n;
	int anw1=0;
	scanf("%d%d",&m,&n);
	for(int i=2;i<=min(m,n);i++)
	{
		if(m%i==0 and n%i==0)
		{
			if(i>anw1)
			{
				anw1=i;
			}
		}
	}
	printf("%d ",anw1);
	for(int i=max(m,n);i<=m*n;i++)
	{
		if(i%m==0 and i%n==0)
		{
			printf("%d",i);
			break;
		}
	}
	return 0;
}
