#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	
	int min;
	int i,gcd;
	for(i=m>=n?n:m;i>0;i--)
	{
		if(m%i==0 && n%i==0)
		{
			gcd=i;
			break;
		}
	}
	
	min=m*n/gcd;
	
	printf("%d %d",gcd,min);
 
	
	
	
	
	
	
	
	
	return 0;
}
