#include<stdio.h>
void main()
{
	int m,n;
	int i=0,t=0;
	int xiao,max,min;
	scanf("%d %d",&m,&n);
	if(m>=n){
		xiao=n;
	}else{
		xiao=m;
	}
	for(i=0;i<=xiao;i++){
		if(m%i==0&&n%i==0){
			max=i;
		}
	}
	max=min*(m/max)*(n/max);
	printf("%d %d",max,min);
}
