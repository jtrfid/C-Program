#include<stdio.h>
#include<math.h>
int main(){
	int n;
	double s;
	scanf("%d",&n);
	if(n<=20&&n>=0){
		s=0;
	}
	else if(n>=21&&n<=300){
		s=(n-20)*0.5;
	}
	else if(n>=301&&n<=600){
		s=140.0+(n-300)*0.6;
	}
	else{
		s=320.0+(n-600)*0.8;
	}
	printf("%.1f",s);
		return 0;
}
