#include<stdio.h>
int main (){
	int a,b,i=1,j,k,x=1,y,fe=0;
	scanf("%d %d",&a,&b);
	if(a<b){
		k=b;
		b=a;
		a=k;
	}
	y=a*b;
	for(i=1;i<a;i++){
		if(a%i==0&&b%i==0){
			x=i;
			for(j=2;j<i;j++){
				if(i%j==0){
				fe=1;
				break;	
				}
			}
			if(fe==0){
				y=y/i;
			}
		}
		fe=0;
	}
	printf("%d %d",x,y);
}
