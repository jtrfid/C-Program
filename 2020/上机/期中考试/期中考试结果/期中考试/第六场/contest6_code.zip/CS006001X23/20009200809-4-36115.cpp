#include<stdio.h>

int main()
{
	int n;
	float charge;
	scanf("%d", &n);
	if (n<=20)
	{
		charge=0;
	}
	else if (n>21 && n<=300)
	{
		charge=(n-20)*0.5;
	}
	else if (n>300 && n<=600) 
	{
		charge=280*0.5+(n-300)*0.6;
	}
	else
	{
		charge=140+(600-300)*0.6+(n-600)*0.8;
	}
	printf("%.1f", charge);
	return 0;
}
