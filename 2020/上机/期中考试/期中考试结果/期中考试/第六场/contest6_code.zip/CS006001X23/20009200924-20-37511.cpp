#include<stdio.h>
int main()
{
	int m,n,a,b,t=0;
	scanf("%d %d",&m,&n);
	a=m;
	b=n;
	while(t!=0){
		t=m%n;
		m=n;
		n=t;
	}
	printf("%d %d",n,a*b/n);
	return 0;
}
