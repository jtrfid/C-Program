#include<stdio.h>

int main()
{
	int a,b,sum;
	
	scanf("%d %d",&a,&b);
	
	sum=0;
	
	while(a>9)
	{
		sum+=a%10;
		a=a/10;
	}
    sum=sum+a;
	
	if(b%sum==0)
	{
		printf("%d %d",sum,b/sum);
	}
	else
	{
		printf("%d No",sum);
		
	}
	
	return 0;
}
