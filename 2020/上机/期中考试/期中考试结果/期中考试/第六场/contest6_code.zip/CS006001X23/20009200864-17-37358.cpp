/*
*/
#include<stdio.h>

int pow(int a,int b)
{
	int i,ans=1;
	for(i=0;i<b;i+=1)
	{
		ans*=a;
	}
	return ans;
}
int main()
{
	int m,n,t=0,i;
	
	scanf("%d%d",&m,&n);
	
	for(i=0;i<=10;i+=1)
	{
		t+=m%pow(10,i+1)/pow(10,i);
	}
	printf("%d ",t);
	
	if(t%n==0) printf("%d",t/n);
	else printf("No");
	
	return 0;
} 
