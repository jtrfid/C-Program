#include <stdio.h>

int calc(int n) {
	int sum = 0;
	for (; n; n /= 10)
		sum += n % 10;
	return sum;
}

int main() {
	int a, b, ans;
	scanf("%d%d", &a, &b);
	ans = calc(a);
	printf("%d ", ans);
	if (ans % b) printf("No\n");
	else printf("%d\n", ans / b);
	return 0;
}
