#include <stdio.h>
int main()
{
	int n,b,s,sum,x;
	
	sum=0;
	scanf("%d %d",&n,&b);
	while(n>0)
	{
		s=n%10;
		n=n/10;
		sum=sum+s;
	}
	printf("%d ",sum);
	if(sum%b==0)
	{
		x=sum/b;
		printf("%d",x);
	}
	else
	printf("No");
    return 0;
}

