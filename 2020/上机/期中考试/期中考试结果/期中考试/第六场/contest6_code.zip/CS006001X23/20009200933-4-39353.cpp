#include<stdio.h>
int main(){
	int x;
	double w;
	scanf("%d",&x);
	if(x<=20)w=0.0;
	if(x>20&&x<=300)w=(x-20)*0.5;
	if(x>300&&x<=600)w=280*0.5+(x-300)*0.6;
	if(x>600)w=280*0.5+300*0.6+(x-600)*0.8;
	printf("%.1lf",w);
	return 0;
}
