#include<stdio.h>
int main()
{
	int A,B,t;
	scanf("%d%d",&A,&B);
	int sum=0;
	while(A!=0)
	{
		t=A%10;
		sum+=t;
		A/=10;
	}
	if(sum%B==0)
	{
		printf("%d %d",sum,sum/B);
	}
	else
	{
		printf("%d No",sum);
	}
	return 0;
}
