#include <stdio.h>
int main()
{
	int n;
	double fee;
	scanf("%d",&n);
	if(n<=20)
	{
		fee=0;
	}
	else if(n>=21&&n<=300)
	{
		fee=(n-20)*0.5;
	}
	else if(n>=301&&n<=600)
	{
		fee=140+(n-300)*0.6;
	}
	else
	{
		fee=140+180+(n-600)*0.8;
	}
	printf("%.1f",fee);
	return 0;
}
