#include<stdio.h>
#include<math.h>
int main(){
	int a;
	double b;
	scanf("%d",&a);
	if(a<21)
	{
		b=0*0.1;
	}
	else if(a>20&&a<301)
	{
		b=(a-20)*0.5;
	}
	else if(a>300&&a<601)
	{
		b=140+(a-300)*0.6;
	}
	else
	{
		b=320+(a-600)*0.8;
	}
	printf("%.1lf",b);
	return 0;
	
}
