#include<stdio.h>
int main()
{
	int n;
	float x;
	scanf("%d",&n);
	if(n<=20)
	{
		x=0.0;
	}
	else if(n>20&&n<=300)
	{
		x=0.50*(n-20);
	}
	else if(n>300&&n<=600)
	{
		x=140.0+0.60*(n-300);
	}
	else if(n>600)
	{
		x=320.0+0.80*(n-600);
	}
printf("%.1f",x);
return 0;
}
