/*
*/
#include<stdio.h>

int main()
{
	int m,n,i,c=0,d;
	scanf("%d%d",&m,&n);
	
	if(m==1||n==1)
	{
		printf("1 %d",n+m-1);
	} 
	else 
	{
		for(i=2;i<=n;i+=1)
		{
			if(m%i==0&&n%i==0) c=i;
		}
	
		d=m*n/c;
	
		printf("%d %d",c,d);
	}
	return 0;
}
