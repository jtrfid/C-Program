#include<stdio.h>
void main()
{
	double n,i;
	double s=0;
	scanf("%lf",&n);
	i=1;
	while(i<=n){
		s=s+1+(1/i);
		i++;
	}
	printf("%.1f",s);
}
