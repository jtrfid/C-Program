#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main(void)
{int n,k;
double sum=0;
scanf("%d",&n);
for(k=1;k<=n;k++)
 sum=sum+1.0+(1.0/k);
printf("%.1lf",sum);
	
	
	
return 0;	
}
