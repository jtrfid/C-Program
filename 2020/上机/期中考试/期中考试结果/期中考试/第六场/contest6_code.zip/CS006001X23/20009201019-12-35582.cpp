// By FengChang 2020-11-21
#include<bits/stdc++.h>
using namespace std;
#define foe(i,a) for(__typeof(a.end())i=a.begin();i!=a.end();++i)
int gcd(int a,int b){while(b)a%=b,a^=b^=a^=b;return a;}
int main(){
#ifdef flukehn
	freopen("a.txt","r",stdin);
#endif
	int n;
	cin>>n;
	double ans=n;
	for(int i=1;i<=n;++i)ans+=1.0/i;
	printf("%.1f\n",ans);
}
