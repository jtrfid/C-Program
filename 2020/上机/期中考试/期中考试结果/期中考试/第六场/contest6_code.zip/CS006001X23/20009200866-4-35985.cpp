#include<stdio.h>
int main(){
int a;
double b,c,d;
scanf("%d",&a);
if(a>=0&&a<=20){
	printf("0.0");
}else if(a>20&&a<=300){
	b=(a-20)*0.5;
	printf("%.1f",b);
}else if(a>300&&a<=600){
	c=(a-300)*0.6+140;
	printf("%.1f",c);
}else if(a>600){
	d=(a-600)*0.8+140+180;
	printf("%.1f",d);
}



return 0;
}
