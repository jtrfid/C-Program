#include<stdio.h>
int main(){
	float sum=0;
	int i;
	int n=0;
	scanf("%d",&n);
	float a=0;
	for(i=1;i<=n;i++){
		a=1+(1.0/i);
		sum=sum+a;
	}
	printf("%.1f",sum);
	
	return 0;
}
