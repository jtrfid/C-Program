#include<stdio.h>
int main()
{
	int n;//��ʾ�õ���
	double m;//��ʾǮ��
	
	scanf("%d",&n);
	
	if(0<=n && n<=20)
	{
		printf("0.0");
	} 
	if(21<=n && n<=300)
	{
		m=0.5*n;
		printf("%.1lf",m);
	}
	if(301<=n && n<=600)
	{
		m=140+0.6*(n-300);
		printf("%.1lf",m);
	}
	if(601<=n) 
	{
		m=320+0.8*(n-600);
		printf("%.1lf",m);
		
	}
	return 0;
}
