#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int c,d=0,e;
	while(a!=0)
	{
		c=a%10;
		a=a/10;
		d+=c;
	}
	if(d%b==0)
	{
		e=d/b;
		printf("%d %d",d,e);
	}
	else if(d%b!=0)
	{
		printf("%d ",d);
		printf("no");
	}
	return 0;
}
