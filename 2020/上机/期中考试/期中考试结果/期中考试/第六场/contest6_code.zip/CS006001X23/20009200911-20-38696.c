#include<stdio.h>
int main()
{
	int m,n; 
	scanf("%d %d",&m,&n);
	int min,i;
	int gcd,b;
	min=m<n?m:n;
    int max;
	max=m>n?m:n;
	if(m!=1&&n!=1)
	  {
        for(i=2;i<=min;i++)
	{
		if(m%i==0&&n%i==0)
		{
			gcd=i;
			b=(m*n)/gcd;
		}
	}
	printf("%d %d",gcd,b);}
	
	else
	{
		printf("%d %d",min,max);
	}
	
	return 0;
}
