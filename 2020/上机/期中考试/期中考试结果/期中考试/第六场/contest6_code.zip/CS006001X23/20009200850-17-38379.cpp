#include<stdio.h>
int main (){
	int a,b,c=0;
	scanf("%d %d",&a,&b);
	for(;a>0;)
	{c=c+a%10;
	a=a/10;
	}

	printf("%d ",c);
	if(b%c==0)
	printf("%d",b/c);
	else if(b%c!=0)
	printf("No");
}
