#include<stdio.h>

int main()
{
	int A,B;
	scanf("%d %d",&A,&B);
	int sum=0,t,a;
	while(A>0)
	{
		t=A/10;
		a=A%10;
		sum=sum+a;
		A=t;
	}
	if(sum%B==0)
	{
		printf("%d %d",sum,sum/B);
	}
	else
	{
		printf("%d NO",sum);
	}
	return 0;
}
