#include<stdio.h>
void main()
{
	int pow;
	double sum=0;
	scanf("%d",&pow);
	if(pow<=20){
		printf("%.1f",sum);
	}
	if(21<=pow&&pow<=300){
	sum=(pow-20)*0.5;
    }
    if(301<=pow&&pow<=600){
	sum=280*0.5+(pow-300)*0.6;
    }
    if(601<=pow){
	sum=280*0.5+300*0.6+(pow-600)*0.8;
    }
    printf("%.1f",sum);
}
