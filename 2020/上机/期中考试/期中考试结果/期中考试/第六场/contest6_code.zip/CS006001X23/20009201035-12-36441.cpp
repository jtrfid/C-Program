#include<stdio.h>
int main(){
	int n;
	double m;
	scanf("%d",&n);
	for(int i=1;i<n+1;i++){
		m+=(1.0+1.0/i)*1.0;
	}
	printf("%.1f",m);
}
