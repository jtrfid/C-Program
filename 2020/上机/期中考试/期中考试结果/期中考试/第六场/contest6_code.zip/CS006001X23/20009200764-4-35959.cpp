#include<stdio.h>
int main(){
	double a,x;
	scanf("%lf",&a);
	if(a<=20){
		printf("0.0");
	}
	else if(a>20&&a<=300){
		x=0.5*(a-20);
		printf("%.1f",x);
	}
	else if(a>300&&a<=600){
		x=0.6*(a-300)+0.5*(300-20);
		printf("%.1f",x);
	}
	else{
		x=(a-600)*0.8+0.6*(600-300)+0.5*(300-20);
		printf("%.1f",x);
	}
	return 0;
}
