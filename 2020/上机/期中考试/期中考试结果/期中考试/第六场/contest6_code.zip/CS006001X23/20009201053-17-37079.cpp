#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
	int A=0,B=0,sum=0,c=0;//cΪ�м���� 
	scanf("%d %d",&A,&B);
	c=A;
	while(c!=0)
	{
		sum+=c%10;
		c=c/10;
	}
	if(sum%B==0)
	{
		printf("%d %d",sum,sum/B);
	}
	else if(sum%B!=0)
	{
		printf("%d %s",sum,"No");
	}
	return 0;
}
	
