#include<stdio.h>
int main(){
	int x,y,z;
	scanf("%d %d",&x,&y);
	if(x<y){
	z=x;
	x=y;
	y=z;
	}
	int i,m,n;
	m=x*y;
	n=x%y;
	while(n!=0){
		x=y;
		y=n;
		n=x%y;
	}
	i=m/y;
	
	printf("%d %d",y,i);
	
	
	
	return 0;
}
