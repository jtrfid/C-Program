#include<stdio.h>
int main()
{
	int a;
	float b;
	scanf("%d",&a);
	if(a<=20)
	{
		b=0;
	}
	else if(20<a&a<=300)
	{
		b=(a-20)*0.5;
	}
	else if(300<a&a<=600)
	{
		b=140+(a-300)*0.6;
	}
	else if(600<a)
	{
		b=320+(a-600)*0.8;
	}
	printf("%.1f",b);
	return 0;
}
