#include<stdio.h>
int main(){
	int m,n,min,a,b,i=1,c,d;
	scanf("%d %d",&m,&n);
	min=m<n?m:n;
	while(i<=min){
		if(m%i==0&&n%i==0){
			a=i;
		}
		i++;
	}
	c=m/a;
	d=n/a;
	b=a*d*c;
	printf("%d %d",a,b);
	return 0;
}
