#include<stdio.h>
int main()
{
	long a;
	int b,sum=0,c;
	scanf("%d %d",&a,&b);
	while(a>0)
	{
		sum+=a%10;
		a/=10;
	}
	if(sum%b==0){
		c=sum/b;
		printf("%d %d\n",sum,c);
	}
	else printf("%d No\n",sum);
	return 0;
}
