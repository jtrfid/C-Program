#include<stdio.h>
int main()
{
  int a,i;
  float t,s=0.0;
  scanf("%d",&a);
  for(i=0;i<a;i++)
  {
  	t=1+1/(i+1.0);
  	s+=t;
  }
  printf("%.1f",s);
	return 0;
	
}
