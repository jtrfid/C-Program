#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main(void)
{int a,b,s=0,c;
scanf("%d %d",&a,&b);
while(a!=0)
{s=s+a%10;
 a=a/10;}
c=s/b;
if(s%b==0)
{printf("%d %d",s,c);}
if(s%b!=0)
{printf("%d No",s);
}	
	
return 0;	
}
