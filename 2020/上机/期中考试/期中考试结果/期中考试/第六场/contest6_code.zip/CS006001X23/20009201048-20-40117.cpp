#include<stdio.h>
int main()
{
	int a,b,t,flag=0;
	scanf("%d %d",&a,&b);
	if(a<b){
		t=a;a=b;b=t;
	}
	if(b==1){
		printf("1 %d\n",a);
		flag=1;
	}
	else for(int i=b;i>1;i--){
		if(a%i==0 && b%i==0){
			printf("%d %d\n",i,a*b/i);
			flag=1;
			break;
		}
	}
	if(flag==0) printf("1 %d\n",a*b);
	return 0;
}
