#include<Cstdio>
int main()
{
	int n;
	scanf("%d",&n);
	double anw=0;
	for(double i=1;i<=n;i++)
	{
		anw++;
		anw+=(1/i);
	}	
	printf("%.1lf",anw);
	return 0;
}
