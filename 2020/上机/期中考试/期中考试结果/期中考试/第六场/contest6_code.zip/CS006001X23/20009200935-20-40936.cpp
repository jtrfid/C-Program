#include<stdio.h>
int q(int a,int b)
{
	int i,c,d,f;
	i=1;
	while(i<=a|i<=b)
	{
		c=a%i;
		d=b%i;
		if(c==0&d==0)
		{
			f=i;
			i=i+1;
		}
		else
		{
			i=i+1;
		}
	}
	return f;
}
int main()
{
	int m,n,o,p;
	scanf("%d %d",&m,&n);
	o=q(m,n);
	p=m*n/o;
	printf("%d %d",o,p);
	return 0;
}


