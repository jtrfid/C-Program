#include<stdio.h>
int main()
{
	int a;
	float m;
	scanf("%d",&a);
	if(a>=0&&a<=20)
		m=0.0;
	else if(a>=21&&a<=300)
		m=(a-20.0)*0.5;
	else if(a>=301&&a<=600)
		m=(a-300.0)*0.6+140.0;
	else m=(a-600.0)*0.8+320.0;
	printf("%.1f",m);
	return 0;
}
