#include<cstdio>
int main()
{
	int n;
	double s=0.0,k=0.0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		k=1.0/i;
		s=s+1+k;
	}
	printf("%.1f",s);
}
