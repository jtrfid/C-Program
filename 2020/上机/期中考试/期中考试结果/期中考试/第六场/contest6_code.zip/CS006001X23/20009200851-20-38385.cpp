#include<stdio.h>
int main()
{
	int n,m;//n>0,m>0,n<10000,m<10000 
	scanf("%d %d",&n,&m);
	int min,i,c,d;
	min=n<m?n:m;
	for(i=1;i<=min;i++)
	{
		if(n%i==0&&m%i==0)
		{
			c=i;
		}
	}

	d=m*n/c;
	printf("%d %d",c,d);
	return 0;
	
}
