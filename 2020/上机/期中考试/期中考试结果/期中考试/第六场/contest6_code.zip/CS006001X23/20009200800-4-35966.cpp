#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	scanf("%d",&n);
	if(n>=0&&n<=20) printf("0.0");
	if(n>20&&n<=300) printf("%.1f",(float)(n-20)*0.5);
	if(n>300&&n<=600) printf("%.1f",(float)140+(n-300)*0.6);
	if(n>600) printf("%.1f",(float)320+(n-600)*0.8);
	return 0;
}
