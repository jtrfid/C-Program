#include<stdio.h>
int main(){
	double i,sum=0;
	int j,n;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
	sum+=1+1/i;	
	}
	printf("%.1f",sum);
	return 0;
}
