#include<stdio.h>
int main()
{
	int a,b,c,d;
   scanf("%d %d",&a,&b);
   for(c=b;c>1;c--)
   {
   	if(a%c==0&&b%c==0)
   	{
   		break;
   	}
   }
   d=a*b/c;
   printf("%d %d",c,d);
   return 0;
}
