#include<stdio.h>
int main(){
	int n;
	int i=1;
	scanf("%d",&n);
	double sum=0;
	double j;
	while(i<=n){
		j=1.0/i;
		sum=sum+1+j;
		i++;
	}
	printf("%.1f",sum);
	return 0;
}
