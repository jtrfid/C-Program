#include<stdio.h>
int main()
{
	int a,b,i,m,n,flag=0;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
	i=b;
	m=a;
}
	else
	{
	i=a;
	m=b;}
	n=i;
    while(flag==0)
    {
    if(a%i==0&&b%i==0)
    flag=1;
    else
    i--;
	}
	printf("%d %d",i,n/i*m);
	
}
