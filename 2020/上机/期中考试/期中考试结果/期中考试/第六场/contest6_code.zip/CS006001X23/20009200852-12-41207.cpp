#include<stdio.h>
int main()
{
	int n;
	double m;
	scanf("%d",&n);
	m=n+2.1;
	printf("%.1lf",m);
	return 0;
}
