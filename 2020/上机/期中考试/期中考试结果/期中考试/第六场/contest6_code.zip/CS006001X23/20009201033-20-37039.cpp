#include <stdio.h>

int main()
{
	int a1,a2,yue=1,bei,i;
	scanf("%d %d",&a1,&a2);
	if(a1>a2)
	{
		int temp;
		temp=a1;a1=a2;a2=temp;
	}
	if(a2%a1==0){yue=a1;}
	else
	{
		for(i=1;i<a1;i++)
		{
			if(a1%i==0&&a2%i==0){yue=i;}
		}
	}
	if(yue==1){bei=a1*a2;}
	else if(yue!=1)
	{
		int m;
		m=a2/yue;
		bei=m*a1;
	}
	printf("%d %d",yue,bei);
	
	return 0;
}
