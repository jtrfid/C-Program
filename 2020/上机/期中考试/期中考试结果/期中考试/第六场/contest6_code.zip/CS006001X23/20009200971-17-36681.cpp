#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int total(int a);

int main(void){
	int a=0,b=0;
	scanf("%d %d",&a,&b);
	int x=total(a);
	if(x%b==0){
		printf("%d %d",x,x/b);
	}else{
		printf("%d no",x);
	}
	
	return 0;
}

int total(int a){
	int rtn=0;
	while(a!=0){
		rtn +=a%10;
		a /=10;
	}
	return rtn;
}
