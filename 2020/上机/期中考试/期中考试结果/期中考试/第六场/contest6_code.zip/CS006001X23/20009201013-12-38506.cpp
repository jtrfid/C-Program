#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	float Sn=0;
	int i=0;
	for(i=1;i<=n;i++){
		Sn=Sn+(1+1.0/i);
	}
	printf("%.1f",Sn);
	return 0;
}
