#include<stdio.h>
int main()
{int mowei,i=0,a,b,sum,temp;
scanf("%d %d",&a,&b);
for(sum=0,temp=a;temp>0;temp=temp/10)
{mowei=temp%10;
sum=sum+mowei;
}
if(a%b==0)
{printf("%d %d",sum,a/b);}
else printf("%d No",sum);
return 0;
}

