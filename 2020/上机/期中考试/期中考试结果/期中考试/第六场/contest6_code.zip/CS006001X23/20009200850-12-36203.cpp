#include<stdio.h>
int main (){
	int n;
	float cur=0.0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{cur=cur+1.0+1.0/i;
	}
	printf("%.1f",cur);
}
