#include<stdio.h>
int main()
{
  int a,b,t,x,s=0;
  scanf("%d %d",&a,&b);
  while(a>0)
  {
  	t=a%10;
  	a/=10;
  	s+=t;
  }
  if(s%b==0)
  {
  	x=s/b;
  	printf("%d %d",s,x);
  }
  else
  printf("%d No",s);
	return 0;
	
}
