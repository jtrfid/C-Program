#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	float sum=0.0;
	for(float i=1;i<=n;i++)
	{
		sum+=1+1/i;
	}
	printf("%.1f",sum);
	return 0;
}
