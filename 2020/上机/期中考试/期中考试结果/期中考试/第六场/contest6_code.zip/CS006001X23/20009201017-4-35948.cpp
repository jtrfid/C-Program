#include <stdio.h>
int main()
{
   int n;
   float s;
   scanf("%d",&n);
   if(n>=0&&n<=20)
   {
   	s=0;
   }
	else if(n>=21&&n<=300)
	{
	s=0.5*(n-20.0);	
	}
	else if(n>=301&&n<=600)
	{
		s=0.6*(n-300.0)+140.0;
	}
	else
	{
	s=320.0+0.8*(n-600);	
	}
	printf("%0.1f",s);
	return 0;
}
