#include<stdio.h>
int main()
{int n,i=1;
float s;
scanf("%d",&n);
while(i<=n)
     {s=1.0/i+1+s;
      i=i+1;
     }
printf("%.1f",s);
return 0;
}
