#include<stdio.h>
int main()
{
	int e;
	double m;
	scanf("%d",&e);
	if(e>=0&&e<=20)
	m=0;
	if(e>=21&&e<=300)
	m=0.5*(e-20);
	if(e>=301&&e<=600)
	m=0.5*280+0.6*(e-300);
	if(e>=601)
	m=0.5*280+0.6*300+0.8*(e-600);
	printf("%.1lf",m); 
	return 0;
}
