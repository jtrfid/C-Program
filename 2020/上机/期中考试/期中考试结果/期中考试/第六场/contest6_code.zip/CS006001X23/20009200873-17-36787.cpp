#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main()
{
	int a,b,t,sum = 0;
	
	scanf("%d %d",&a,&b);
	
	t = a;
	while(t != 0)
	{
		sum+= t%10;
		t = t/10;
	}
	
	if(sum % b == 0) printf("%d %d",sum,sum/b);
	else printf("%d NO",sum);
	
	return 0;
}
