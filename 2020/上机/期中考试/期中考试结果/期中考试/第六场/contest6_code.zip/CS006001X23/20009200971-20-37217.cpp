#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int gcd(int a,int b);

int main(void){
	int a=0,b=0;
	scanf("%d %d",&a,&b);
	int c=gcd(a,b);
	if(c<0){
		 ;
	}else{
		int d=a*b/c;
		printf("%d %d",c,d);
	}
	
	return 0;
}

int gcd(int a,int b){
	int x=(a<b)?a:b;
	int rtn=-1;
	for(int i=x;i>0;i--){
		if(a%i==0&&b%i==0){
			rtn=i;
			break;
		}else{
			continue;
		}
	}
	return rtn;
}
