#include<stdio.h>
int main()
{
	int a;
	double w;
	scanf("%d",&a);
	if(a<=20)
	{
		w=0;
	}
	else if(a>20&&a<=300)
	{
		w=(a-20)*0.5;
	}
	else if(a>300&&a<=600)
	{
		w=280*0.5+(a-300)*0.6;
	}
	else if(a>600)
	{
		w=280*0.5+300*0.6+(a-600)*0.80;
	}
	printf("%0.1f",w);
	return 0;
}
