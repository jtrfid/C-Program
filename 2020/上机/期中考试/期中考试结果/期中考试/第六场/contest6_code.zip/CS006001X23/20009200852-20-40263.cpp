#include<stdio.h>
int main()
{
	int n,b,a,i,j,J;
	scanf("%d %d",&n,&b);
	if(n>b)
	{
		a=n;
		n=b;
		b=a;
	}
	J=n*b;
	for(i=n;i>0;i--)
	{
		if(n%i==0&&b%i==0)
		printf("%d %d",i,J/i);
		break;
	}
	return 0;
}
