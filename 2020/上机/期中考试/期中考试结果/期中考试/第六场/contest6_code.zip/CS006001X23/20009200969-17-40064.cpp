#include<stdio.h>
int main()
{
	int a,b,c,n,s=0;
	scanf("%d %d",&a,&b);
	for(;a!=0;a/=10)
	{
		n=a%10;
		s+=n;
	}
	
	if(s%b==0)
	{
		c=s/b;
		printf("%d %d",s,c);
	}
	else{
	
	printf("%d No",s);
	}
	return 0;
}
