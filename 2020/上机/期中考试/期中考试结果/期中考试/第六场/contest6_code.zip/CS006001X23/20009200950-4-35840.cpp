#include<stdio.h>
int main()
{
	int power;
	float cost;
	scanf("%d",&power);
	if(power>=0&&power<=20)
	{
		printf("0.0");
	}
	if(power>20&&power<=300)
	{
		cost=(power-20)*0.5;
		printf("%.1f",cost);
	}
	if(power>300&&power<=600)
	{
		cost=(power-300)*0.6+140;
		printf("%.1f",cost);
	}
	if(power>600)
	{
		cost=(power-600)*0.8+320;
		printf("%.1f",cost);
	}
	
	return 0;
}
