#include<stdio.h>
int main(){
	int x;
	float money=0;
	scanf("%d",&x);
	if(x>=0&&x<=20){
		money=0;
	}
	else if(x>=21&&x<=300){
		money=(x-20)*0.5;
	}
	else if(x>=301&&x<=600){
		money=0.6*x-40;
	}
	else if(x>600){
		money=0.8*x-160;
	}
	printf("%.1f",money);
	
	
	
	return 0;
}
