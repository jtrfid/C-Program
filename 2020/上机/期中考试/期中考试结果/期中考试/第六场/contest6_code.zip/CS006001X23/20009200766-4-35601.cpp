#include<cstdio>
#include<iostream>
using namespace std;
int e;
int main()
{
	cin>>e;
	if(e<=20)
	{
		printf("0.0");
	}
	else if(e<=300)
	{
		printf("%0.1f",(e-20)*0.5);
	}
	else if(e<=600)
	{
		printf("%0.1f",(e-300)*0.6+140);
	}
	else
	{
		printf("%0.1f",(e-600)*0.8+320);
	}
	return 0;
}
