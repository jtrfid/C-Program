#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	int min,i,c=0,d;
	min=n<m?n:m;
	for(i=2;i<=min;i++)
	{
		if(n%i==0&&m%i==0)
		{
			c=i;
		}
	}
	printf("%d ",c);
	d=m*n/c;
	printf("%d",d);
	return 0;
	
}
