#include<stdio.h>
int main()
{int a,b;
  scanf("%d %d",&a,&b);
  int c=a%10;
  int d=a/10;
  int sum=0;
  while(c!=0||d!=0)
  { sum=sum+c;
    c=d%10;
    d=d/10;
  }   
  int q=sum%b;
  int w=sum/b;
  if(q==0)
  {printf("%d %d",sum,w);
  }
  else
  {printf("%d No",sum);
  }
  return 0;
}
