#include<stdio.h>
int main()
{int gy,gb,max,min,a,b,i,n;
scanf("%d %d",&a,&b);
a>b?max=a,min=b:max=a,min=b;
for(gy=min;gy>0;gy--)
{if(max%gy==0&&min%gy==0)
break;
else continue;}
gb=(max*min)/gy;
printf("%d %d",gy,gb);
	return 0;
}
