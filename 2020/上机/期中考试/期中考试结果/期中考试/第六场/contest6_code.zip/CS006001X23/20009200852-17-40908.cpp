#include<stdio.h>
int main()
{
	int c,b,i,sum=0;
	scanf("%d%d",&c,&b);
	int a[100000];
	for(i=1; ;i++)
	{
		a[i]=c%10;
		c=c/10;
		sum=sum+a[i];
	}
	
	if(sum%b==0) printf("%d",sum/b);
	else printf("No");
	return 0;
}
