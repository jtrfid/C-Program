#include <stdio.h>
int main()
{
	int n,i;
	float s,sum;
	sum=0.0;
	scanf("%d",&n);
	for(i=1;i<n+1;i++)
	{
		s=1.0+1.0/i;
		sum=sum+s;
		
	}
	printf("%0.1f",sum);
	return 0;
}
