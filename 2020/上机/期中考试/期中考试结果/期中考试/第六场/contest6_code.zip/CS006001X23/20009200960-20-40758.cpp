#include<stdio.h>
int main()
{int m,n,i,k;
scanf("%d %d",&m,&n);
for(i=m;i<=m;)
   {if(m%i==0,n%i==0) break;
    else i=i-1;
   }
k=m*n/i;
printf("%d %d",i,k);
return 0;
}
