#include<stdio.h>
int main(){
	int a;
	scanf("%d",&a);
	double fee;
	if(a<=20) fee=0.0;
	else if(a>20&&a<=300) fee=0.5*(a-20);
	else if(a>300&&a<=600) fee=140+0.6*(a-300);
	else if(a>600) fee=320+0.8*(a-600);
	printf("%.1f",fee);
	return 0;
}
