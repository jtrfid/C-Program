#include<stdio.h>
int main()
{
	int m,n,a,b,max,min;
	scanf("%d %d",&m,&n);
	max=(m>n)?m:n;
	for(a=max;;a++)
	if(a%m==0&&a%n==0)
	break;
	min=(m<n)?m:n;
	for(b=min;b>=1;b--)
	if(m%b==0&&n%b==0)
	break;
	printf("%d %d",b,a);
	return 0;
}
