#include<stdio.h>
int main()
{
	int a,b,c=0;
	scanf("%d %d",&a,&b);
	for(int i=0;a>0;i++)
	{
		c=c+a%10;
		a=a/10;
	}
	if(c%b==0)
	{
		printf("%d %d",c,c/b);
		
	}
	else
	printf("%d No",c);
	return 0;
}
