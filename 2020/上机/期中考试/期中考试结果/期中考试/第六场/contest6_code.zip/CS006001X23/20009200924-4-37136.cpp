#include<stdio.h>
int main()
{
	double n;
	scanf("%lf",&n);
	if(n>=0&&n<=20)
		printf("0.0");
	else if(n>20&&n<=300)
		printf("%.1lf",(n-20)*0.50);
	else if(n>300&&n<=600)
		printf("%.1lf",140.00+(n-300)*0.60);
	else if(n>600)
		printf("%.1lf",140.00+180.00+(n-600)*0.80)
	return 0;
}