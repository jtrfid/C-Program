#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	float a[n];
	float sum=0;
	
	int i,j;
	for(i=1,j=0;i<=n;i++,j++)
	{
			a[j]=1.0/i;
	}
	
	
	for(i=0;i<n;i++)
	{
		sum+=(1+a[i]);
	}
	
	printf("%.1f",sum);
	
	return 0;
}
