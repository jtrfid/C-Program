#include<stdio.h>
int main(){
	int n,m;
	scanf("%d%d",&n,&m);
	if(m>n){
		int t=m;
		m=n;
		n=t;
	}
	for(int i=n;i;i--){
		if(m%i==0&&n%i==0){printf("%d ",i);
		break;
		} 
	}
	for(int j=1;j;j++){
		if(j%m==0&&j%n==0){printf("%d",j);
		break;
		} 
	}
	return 0;
}
