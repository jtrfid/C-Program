#include <stdio.h>

int main()
{
	int n;
	double all=0.0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		all=all+1.0+(1.0/i);
	}
	printf("%.1f",all);
	
	return 0;
}
