#include<stdio.h>
int main()
{
  int a,b,m,n,i,t;
  scanf("%d %d",&a,&b);
  if(a>b)
  {
  	m=a,n=b;
  }
  else{
  	m=b,n=a;
  }
  while(n!=0)
  {
  	t=m%n;
  	m=n;
  	n=t;
  }
  i=a*b/m;
  printf("%d %d",m,i);
	return 0;
	
}
