#include<stdio.h>

int main()

{
	int n,i;
	float m;
	m=0;
	scanf("%d",&n);
	
	for(i=1;i<=n;i++)
	{
		m+=1.0+1.0/i;
	}
	
	printf("%.1f",m);
	
	return 0;
	
	
	
}
