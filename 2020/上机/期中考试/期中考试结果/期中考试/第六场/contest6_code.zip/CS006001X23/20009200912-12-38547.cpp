#include<stdio.h>
int main()
{
	int n , i ;

	double target = 0.0 ;
	
	scanf("%d", &n );
	
	for( i = 1 ; i <= n ; i ++ )
		target += ( 1 + (double)1 / n ) ;
	
	printf("%.1f", target );
	
	
	
	
	return 0 ;
}
