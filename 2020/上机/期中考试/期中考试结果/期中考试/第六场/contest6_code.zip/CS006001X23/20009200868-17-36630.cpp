#include<cstdio>
int main()
{
	int a,b,k=0;
	scanf("%d%d",&a,&b);
	while(a!=0)
	{
		k+=a%10;
		a/=10;
	}
	printf("%d ",k);
	if(k%b==0)
	{
		printf("%d",k/b);
	}
	else
	{
		printf("No");
	}
}
