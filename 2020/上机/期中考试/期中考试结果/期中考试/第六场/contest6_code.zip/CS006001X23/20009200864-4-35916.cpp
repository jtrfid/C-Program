/*
*/
#include<stdio.h>

int main()
{
	int n;
	double ans=0;
	
	scanf("%d",&n);
	
	if(n<=20) ans=0;
	else if(n<=300) ans=0.5*(n-20);
	else if(n<600) ans=140+0.6*(n-300);
	else ans=140+180+0.8*(n-600);
	
	printf("%.1f",ans);
	
	return 0;
}
