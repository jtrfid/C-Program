#include<stdio.h>
int main(){
	
	int a, b, c, sum = 0;
	int m = 1;
	scanf("%d%d", &a, &b);
	for(int i = 0; i < 999; i++){
	sum += a % (m * 10) / m;
	m *= 10;
	if(a / m == 0){
	    break;
	    }
    }
	c = sum / b;
	if(sum % b == 0){
		printf("%d %d", sum, c);
	}
	else{
		printf("%d No", sum);
	}
	
	return 0;
}
