#include<stdio.h>
int main()
{
 int n,m,i,a,b,c,d;
 scanf("%d %d",&n,&m);
 for(a=n;a>=1;a--)
 {
 	if(n%a==0&&m%a==0)
 	break;
 }
 for(b=m;b<=m*n;b++)
 {
 	if(b%n==0&&b%m==0)
 	break;
 }
 	printf("%d %d",a,b);
 	return 0;
}
