#include<stdio.h>
int main()
{
	int m , n , sum ;
	
	scanf("%d%d" , &m , &n );
	
	sum = n * m ;
	
	while( m != n )
	{
		if( m > n )
			m = m - n ;
		else
			n = n - m ;
	}
	
    n = sum / n ;

    printf("%d %d", m, n );
	
	
	
	return 0 ;
}
