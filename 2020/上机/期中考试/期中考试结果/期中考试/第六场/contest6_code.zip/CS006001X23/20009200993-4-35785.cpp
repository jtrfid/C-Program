#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main()
{
	int n;
	scanf("%d",&n);
	
	if(n<=20)
	{
		printf("0.0");
	}
	if(20<n&&n<=300)
	{
		printf("%.1f",(n-20)*0.5);
	}
	
	if(300<n&&n<=600)
	{
		printf("%.1f",140+(n-300)*0.6);
	}
	
	if(600<n)
	{
		printf("%.1f",320+(n-600)*0.8);
	}
	
	return 0;
	
	
}
