#include<stdio.h>
int main()
{   int m,n;
   scanf("%d%d",&m,&n);
   int i;
   if(m>n)        //mΪСֵ 
   { i=m;
     m=n;
     n=i;
   }
   else{m=m;
   n=n;
   } 
   int s=m;
   int a=m%s;
   int b=n%s;
   while(a!=0||b!=0)
   {  s--;
     a=m%s;
     b=n%s;
   }
   int d=m*n/s;
   printf("%d %d",s,d);
   return 0;
}
