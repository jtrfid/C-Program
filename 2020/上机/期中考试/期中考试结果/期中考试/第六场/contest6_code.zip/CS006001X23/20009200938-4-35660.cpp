#include<stdio.h>
int main()
{
	int a;
	float f;
	scanf("%d",&a);
	if(a<=20)
	f=0;
	else if(a>20&&a<=300)
	f=0.5*(f-20);
	else if(a>300&&a<=600)
	f=140+(a-300)*0.6;
	else
	f=320+(a-300)*0.8;
	printf("%.1f",f);
	return 0;
	
}
