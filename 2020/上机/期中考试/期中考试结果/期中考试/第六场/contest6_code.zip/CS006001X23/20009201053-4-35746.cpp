#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
	int num=0;
	double price=0;
	scanf("%d",&num);
	if(num>0&&num<=20)
	{
		price=0;
	}
	else if(num>20&&num<=300)
	{
		price=(num-20)*0.5;
	}
	else if(num>300&&num<=600)
	{
		price=280*0.5+(num-300)*0.6;
	}
	else if(num>600)
	{
		price=280*0.5+300*0.6+(num-600)*0.8;
	}
	printf("%.1lf",price);
	return 0;
}

