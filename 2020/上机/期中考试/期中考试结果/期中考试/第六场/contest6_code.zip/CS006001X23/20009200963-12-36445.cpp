#include <stdio.h>

double calc(int n) {
	double sum = 0;
	for (int i = 1; i <= n; i++)
		sum += 1 + 1.0 / i;
	return sum;
}

int main() {
	int n;
	scanf("%d", &n);
	printf("%.1lf\n", calc(n));
	return 0;
}
