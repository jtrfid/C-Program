#include<stdio.h>
int main()
{ int i; 
  double n,sum=0,dangxiang;
  scanf("%lf",&n);
  for(i=1;i<=n;i++)
  {dangxiang=1.0+1.0/i;
  sum=sum+dangxiang;
  }
  printf("%.1lf",sum);
  return 0;
}
