#include<cstdio>
using namespace std;
int main(){
	int x;
	double tot;
	tot=0;
	scanf("%d",&x);
	if(x<=20)tot=0;
	else if(x<=300)tot+=((x-20)*0.5);
	else if(x<=600)tot=140+((x-300)*0.6);
	else {
		tot=320+((x-600)*0.8);
	}
	printf("%.1lf",tot);
	return 0;
}
