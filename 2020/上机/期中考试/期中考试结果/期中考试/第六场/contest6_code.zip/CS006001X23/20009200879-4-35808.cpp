#include <stdio.h>
#include <math.h>

int main() {
	int a;
	float b;

	scanf("%d", &a);

	if (a <= 20) {
		b = 0.0;
	} else if (a > 20 && a <= 300) {
		b = (a - 20) * 0.5;
	} else if (a > 300 && a <= 600) {
		b = 0.0 + (300 - 20) * 0.5 + (a - 300) * 0.6;
	} else {
		b = 0.0 + (300 - 20) * 0.5 + (600 - 300) * 0.6 + (a - 600) * 0.8;
	}

	printf("%.1f", b);

	return 0;
}