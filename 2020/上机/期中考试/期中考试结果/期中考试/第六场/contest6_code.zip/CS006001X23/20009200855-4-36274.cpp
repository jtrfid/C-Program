#include<stdio.h>
int main()
{   int a;
    scanf("%d",&a);
    double s;
    if(a<=20)
    { s=0.0;
      printf("%.1f",s);
    }
    if(a>=21&&a<=300)
    {s=0.0+(a-20)*0.5;
    printf("%.1f",s);
    }
    if(a>=301&&a<=600)
    { s=0.0+(300-20)*0.5+(a-300)*0.6;
    printf("%.1f",s);
    }
    if(a>=601)
    { s=0.0+(300-20)*0.5+(600-300)*0.6+(a-600)*0.8;
    printf("%.1f",s);
    }
    return 0;
}
