#include<stdio.h>
int main()
{
	int A,B;
	scanf("%d %d",&A,&B);
	int sum,s;
	for(sum=0;A!=0 ; )
	{
		s=A%10;
		sum+=s;
		A=A/10;
	}
	if(sum%B==0)
	{
		printf("%d %d",sum,sum/B);
	}
	if(sum%B!=0)
	{
		printf("%d No",sum);
	}
	return 0;
}
