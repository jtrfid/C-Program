#include<stdio.h>
int main()
{
	int a,b,c;
	double x;
	scanf("%d",&a);
	if(a>=0&&a<=20)
	{
		x=0.0;
	}
	if(a>=21&&a<=300)
	{
		x=(a-20)*0.5;
	}
	if(a>=301&&a<=600)
	{
		x=140+(a-300)*0.6;
	}
	if(a>=601)
	{
		x=320+(a-600)*0.8;
	}
	printf("%.1lf",x);
	return 0;
}
