#include<stdio.h>
int main()
{
	int a,b;
	int sum=0;
	scanf("%d %d", &a, &b);
	while( a>0 ){
		sum = a%10+sum;
		a = a/10;
	}
	printf("%d ",sum); 
	if ( sum%b==0 ){
		printf("%d", sum/b);
	}
	else 
	printf ("no");
	return 0;
}
