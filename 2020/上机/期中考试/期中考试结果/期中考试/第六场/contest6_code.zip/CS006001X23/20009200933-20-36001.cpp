#include<stdio.h>
int main(){
	int m,n,yue,i;
	scanf("%d%d",&m,&n);
	for(i=1;i<m;i++){
		if(m%i==0&&n%i==0){yue=i;
		}
	}
	for(i=m;;i++){
		if(i%m==0&&i%n==0){break;
		}
	}
	printf("%d %d",yue,i);
	return 0;
}
