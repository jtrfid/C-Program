#include<stdio.h>
#include<math.h>
int main(){
	int a[10],b;
	int n,sum=0,i,m;
	scanf("%d %d",&a[0],&b);
	for(i=0;i<10;i++)
	{
		while(a[i]>0)
		{
			sum+=a[i]%10;
			a[i]/=10;
		}
	}
	n=sum%b;
	if(n==0)
	{
		m=sum/b;
		printf("%d %d",sum,m);	
	}
	else
	{
		printf("%d No",sum);
	}
	return 0;
}
