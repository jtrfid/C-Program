#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	double Sn;
	for(i=1;i<=n;i++)
	{
		Sn=(1+1.0/i)+Sn;
	}
	printf("%0.1f",Sn);
	
	return 0;
}
