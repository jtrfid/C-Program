#include<stdio.h>

int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int i,min,s;
	min=a<b?a:b;
	for(i=min;i>1;i--)
	{
		if(a%i==0&&b%i==0)
		break;
	}
	s=(a*b)/i;
	printf("%d %d",i,s);
	return 0;
}
