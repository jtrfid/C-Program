#include<stdio.h>
int main()
{
	int n,i;
	double m,j;
	scanf("%d",&n);
	for(i=1,j=0;i<=n;i++)
	{
		j=j+1/i;
	}
	m=n+j;
	printf("%.1lf",m);
	return 0;
}
