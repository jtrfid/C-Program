#include<stdio.h>
int main (){
	int a,b,c=0;
	scanf("%d %d",&a,&b);
	for(;a>0;)
	{c=c+a%10;
	a=a/10;
	}

	printf("%d ",c);
	if(c<b)
	printf("No");
	else{
	
	if(c%b==0)
	printf("%d",b/c);
	else if(c%b!=0)
	printf("No");
}
}
