#include<stdio.h>
int main()
{
	int a,b,i,min,c;
	scanf("%d%d",&a,&b);
	if(a<b)
	{
		min=a;
	}
	else
	{
		min=b;
	}
	for(i=min-1;i>0;i--)
	{
		if(a%i==0&b%i==0)
		{
			break;
		}
	
	}
	c=(a*b)/i;
	printf("%d %d",i,c);
	return 0;
}
