#include <stdio.h>
int main()
{
	int n;
	double r;
	scanf("%d",&n);
	if(n<=20)
	{
		r=0.0;
	}
	else if(n>=21&&n<=300)
	{
		r=(n-20)*0.5;
	}
	else if(n>=301&&n<=600)
	{
		r=140+0.6*(n-300);
	}
	else
	{
		r=320+0.8*(n-600);
	}
	printf("%.1f",r);
}
