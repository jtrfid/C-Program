#include<stdio.h>

int main()
{
	int a;
	float b;
	scanf("%d",&a);
	
	if(a>=0&&a<=20)
	{
		b=0.0;
	}
	if(a>=21&&a<=300)
	{
		b=(a-20.0)*0.5;
	}
	if(a>=301&&a<=600)
	{
		b=(a-300.0)*0.6+140.0;
	}
	if(a>=601)
	{
		b=(a-600.0)*0.8+320.0;
	}
	printf("%.1f",b);
	return 0;
}
