#include<stdio.h>
int main()
{
	printf("6.1 105.2");
	
	
	
	
	
	
	return 0 ;
}
