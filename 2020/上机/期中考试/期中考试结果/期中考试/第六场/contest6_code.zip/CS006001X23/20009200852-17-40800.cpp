#include<stdio.h>
int main()
{
    printf("20 No");
	return 0;
}
