#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int max=0,min=0,x=0;
	int i;
	if(m>=n){
		x=n;
	}else{
		x=m;
	}
	for(i=0;i<=x;i++){
		if(m%i==0 && n%i==0){
			max=i;
		}else{
			max=max;
		}
	}
	min = max*(m/max)*(min/max);
	printf("%d %d",max,min);
	return 0;
}
