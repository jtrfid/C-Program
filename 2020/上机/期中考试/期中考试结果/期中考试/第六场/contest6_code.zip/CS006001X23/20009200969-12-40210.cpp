#include<stdio.h>
int main()
{
	int n,i=0;
	float s=0.0,b;
	scanf("%d",&n);
    while(i<n)
	{
	   i++;
	   b=1.0/i;
	   s+=b+1;
	}
	printf("%.1f",s);
	return 0;
}
