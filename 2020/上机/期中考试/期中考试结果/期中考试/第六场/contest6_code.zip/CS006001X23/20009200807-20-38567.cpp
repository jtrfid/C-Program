#include<stdio.h>
int main(){
	
	int m ,n, yue, bei;
	int min;
	scanf("%d%d", &m, &n);
	min = m < n ? m : n;
	for(int i = min; i > 0; i--){
		if(m % i == 0 && n % i == 0){
			yue = i;
			break;
		}
	}
	bei = m * n / yue;
	printf("%d %d", yue, bei);
	
	return 0;
}
