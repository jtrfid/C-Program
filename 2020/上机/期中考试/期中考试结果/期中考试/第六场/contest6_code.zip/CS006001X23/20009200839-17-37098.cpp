#include <stdio.h>

int main(){
	int A,B;
	scanf("%d%d",&A,&B);
	
	int sum=0;
	for(;A!=0;A=A/10)
	{
		sum+=A%10;
	}
	if(sum%B==0)
	     printf("%d %d",sum,sum/B);
	else
	     printf("%d No",sum);
	     return 0;
}
