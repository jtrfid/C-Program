#include<stdio.h>
int main()
{
	double n,sum;
	scanf("%lf",&n);
	if(n<=20)
	{
		sum=0;
	}
	else if(n>20&&n<=300)
	{
		sum=(n-20)*0.5;
	}
	else if(n>300&&n<=600)
	{
		sum=140+(n-300)*0.6;
	}
	else
	{
		sum=320+(n-600)*0.8;
	} 
	printf("%.1lf",sum);
	return 0;
		
}
