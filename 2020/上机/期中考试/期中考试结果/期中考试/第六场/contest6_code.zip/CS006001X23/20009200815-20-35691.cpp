#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int min,i;
	min=a>b?b:a;
	for(i=min;i>0;i--)
	{
		if(a%i==0&&b%i==0)
		{
			
			break;
		}
	}
	printf("%d %d",i,a*b/i);
	return 0;
}
