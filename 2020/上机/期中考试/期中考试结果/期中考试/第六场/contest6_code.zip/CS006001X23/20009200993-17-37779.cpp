#include<stdio.h>


int pow(int n,int t)
{
	int i;
	int sum=1;
	for(i=0;i<t;i++)
	{
		sum=sum*n;
	}
	return sum;
} 
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	
	int i;
	int sum=0;
	for(i=1;i<30;i++)
	{
		int tool=(a%(int)pow(10,i))/(int)pow(10,i-1);
		sum=sum+tool;
	}
	
	if(a%b==0)
	{
		printf("%d %d",sum,sum/b);
	}
	else
	{
		printf("%d No",sum);
	}
	
	return 0;
}
