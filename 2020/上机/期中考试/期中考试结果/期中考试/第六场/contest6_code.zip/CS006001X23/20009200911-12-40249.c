#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	float temp,s=0;
	for(i=1;i<=n;i++)
	{
	    temp=1+1/i;
		s+=temp;
	}
	printf("%.1f",s);
	 return 0; 
}
