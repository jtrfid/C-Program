#include<stdio.h>
#include<math.h>
int main(){
	int n;
	double s=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		double h=i;
		s=s+1.0+1.0/h;
	}
	printf("%.1f",s);
	return 0;
}
