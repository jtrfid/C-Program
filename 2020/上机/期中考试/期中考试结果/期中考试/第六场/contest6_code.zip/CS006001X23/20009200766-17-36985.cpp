#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	int sum=0;
	while(a)
	{
		sum+=a%10;
		a/=10;
	}
	if(sum%b==0)
	{
		cout<<sum<<' '<<sum/b;
	}
	else
	{
		cout<<sum<<' '<<"No";
	}
}
