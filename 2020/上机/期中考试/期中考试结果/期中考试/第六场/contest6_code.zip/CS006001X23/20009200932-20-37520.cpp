#include <stdio.h>
int main()
{
	int a,b;
	int min,max;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		min=b;
	}
	else
	{
		min=a;
	}
	int i;//�����Լ�� 
	for(i=min;i>0;i--)
	{
		if(a%i==0&&b%i==0)
		{
			printf("%d ",i);
			break;
		}
	}
	if(a<b)
	{
		max=b;
	}
	else
	{
		max=a;
	}
	for(i=max;i>0;i++)
	{
		if(i%a==0&&i%b==0)
		{
			printf("%d",i);
			break;
		}
	}
	return 0;
}
