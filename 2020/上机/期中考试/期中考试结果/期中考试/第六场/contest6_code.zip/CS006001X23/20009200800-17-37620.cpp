#include<bits/stdc++.h>
using namespace std;

int main()
{
	int a,b;
	int sum=0;
	scanf("%d%d",&a,&b);
	while(a>0)
	{
		sum+=a%10;
		a/=10;
	}
	//printf("%d",sum);
	if(b%sum==0) printf("%d %d",sum,(b/sum));
	else printf("%d No",sum);
	return 0;
}
