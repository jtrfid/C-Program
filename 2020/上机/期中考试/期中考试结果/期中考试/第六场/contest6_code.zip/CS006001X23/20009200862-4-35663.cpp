#include<stdio.h>
int main()
{int a;
double dianfei;
scanf("%d",&a);
if(a<=20)
{dianfei=0;}
if(a>20&&a<=300)
{dianfei=(a-20)*0.5;}
if(a>300&&a<=600)
{dianfei=140+(a-300)*0.6;}
if(a>600)
{dianfei=320+(a-600)*0.8;}
printf("%.1lf",dianfei);
return 0;		
} 
