#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int a=1,b=1,i,gy=1,gb=a*b;
	scanf("%d",&a);
	scanf("%d",&b);
	for(i=2;i<=a&&i<=b;i++)
	{
		if(a%i==0&&b%i==0) gy=i;
	}
	for(i=a*b-1;i>=a&&i>=b;i--)
	{
		if(i%a==0&&i%b==0) gb=i;
	}
	if(gb==1) gb=a*b;
	printf("%d %d",gy,gb);
	
	
	
	
	
	system("pause");
	return 0;
}
