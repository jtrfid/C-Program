#include<stdio.h>
int main()
{
    double i,a,b,c;
    scanf("%lf",i);
    a=1,c=1;
    while(a<=i)
    {
    	b=1/i;
    	c=c*(1+b);
    	a=a+1;
    }
    printf("%lf",c);
	return 0;
}
