#include<stdio.h>
int main()
{
	int m,n,i,min,k,j;
	scanf("%d %d",&m,&n);
	if(m>n)
	{
		min=n;
	
	}
	else if(m<n)
	{
		min=m;
	
	}
	else if(m==n)
	{
		k=m;
		j=m*n/k;
		printf("%d %d",k,j);
	}
	for(i=min;i>0;i=i-1)
	{
		if(m%i==0&&n%i==0)
		{
			k=i;
			j=m*n/k;
			printf("%d %d",k,j);
			break;
		}
		else
		{
			continue;
		}
	}
	return 0;
}
