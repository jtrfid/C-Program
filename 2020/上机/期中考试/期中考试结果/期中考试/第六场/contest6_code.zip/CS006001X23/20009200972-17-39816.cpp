#include<stdio.h>
int main()
{
	int a,b,i,j,k,sum=0,sin=0;
	scanf("%d %d",&a,&b);
	for(j=a;j!=0;j=j/10)
	{
		k=j%10;
		
		sum=k+sum;
		
	}
	
	
	
	
	if(sum%b==0)
	{
		sin=sum/b;
		printf("%d %d",sum,sin);
	}
	else
	{
		printf("%d No",sum);
	}
	return 0;
}
