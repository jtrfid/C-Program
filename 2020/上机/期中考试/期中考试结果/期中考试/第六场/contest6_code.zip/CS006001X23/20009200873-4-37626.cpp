#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main()
{
	int a;
	double m;
	
	scanf("%d",&a);
	
	if(a <= 20) m = 0;
	else if(a <= 300) m = (a - 20)*0.5;
	else if(a <= 600) m = (300-20)*0.5 + (a - 300)*0.6;
	else m = (300-20)*0.5 + (600 - 300)*0.6 + (a - 600)*0.8;
	
	printf("%.1lf",m);
	
	return 0;
}
