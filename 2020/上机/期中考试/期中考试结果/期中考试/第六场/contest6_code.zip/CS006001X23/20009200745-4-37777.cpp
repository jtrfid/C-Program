#include<stdio.h>
int main()
{
	int e;
	float fee;
	
	scanf("%d",&e);
	
	if(e>=0 && e<=20)
	fee=0.0;
	else if(e>=21 && e<=300)
	fee=(e-20)*0.5;
	else if(e>=301 && e<=600)
	fee=(e-300)*0.6+280*0.5;
	else if(e>=601)
	fee=280*0.5+300*0.6+(e-600)*0.8;
	
	printf("%.1f",fee);
	
	return 0;
}
