#include<stdio.h>

int main(){
	int a,b,t,sum;
	a=b=t=sum=0;
	scanf("%d%d",&a,&b);
	
	while(a!=0){
		t=a%10;
		sum+=t;
		a=a/10;
	}
	if(b%sum==0){
		printf("%d %d",sum,b/sum);
	}
	else{
		printf("%d No",sum);
	}
	return 0;
}
