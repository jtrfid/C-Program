#include<stdio.h>
int main()
{
	float s=0; 
	int n;
	scanf("%d",&n);
	for(float i=1;i<n+1;i++)
	{
		s=1+(1/i)+s;
	}
	printf("%.1f",s);
	return 0;
}
