#include<stdio.h>
int main (){
	int n;
	scanf("%d",&n);
	if(n<=20)
	printf("0.0");
	if(n>20&&n<=300)
	printf("%.1f",(n-20.0)*0.5);
	if(n>300&&n<=600)
	printf("%.1f",140+(n-300.0)*0.6);
	if(n>600)
	printf("%.1f",320+(n-600.0)*0.8);
}
