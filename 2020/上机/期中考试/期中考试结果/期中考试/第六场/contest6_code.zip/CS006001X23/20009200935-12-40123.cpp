#include<stdio.h>
int main()
{
	double a,b,c,d;
	scanf("%lf",&a);
	b=1,d=0;
	while(b<=a)
	{
		d=d+1+1/b;
		b=b+1;
	}
	printf("%.1f",d);
	return 0;
}

