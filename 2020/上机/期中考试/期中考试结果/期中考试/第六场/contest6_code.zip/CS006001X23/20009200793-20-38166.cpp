#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main(void)
{int a,b,i,tmp,max=0,d;
scanf("%d %d",&a,&b);
if(a>b)
{tmp=b;
 b=a;
 a=tmp;
}
for(i=1;i<=a;i++)
{
if(a%i==0&&b%i==0)
   {
     if(i>=max) max=i;
   }
}
d=a*b/max;
printf("%d %d",max,d);
return 0;

	
	
	
	
	
	
return 0;	
}
