#include<stdio.h>

int main(){
	int n,k=1;
	scanf("%d",&n);
	float Sn,x;
	for(;k<=n;k++){
		x=1+1.0/k;
		Sn=Sn+x;
	}
	printf("%.1f",Sn);
	
	return 0;
}
