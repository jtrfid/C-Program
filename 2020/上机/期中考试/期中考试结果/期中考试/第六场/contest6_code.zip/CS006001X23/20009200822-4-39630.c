#include<stdio.h>
int main()
{
	int e,f;
    scanf("%lf",&e);
    if(e>=0,e<=20);
    f=0;
	
	if(e>=21,e<=300);
	f=(e-20)*0.5;

	if(e>=301,e<=600);

	f=280*0.5+(e-300)*0.6;

	if(e>=601);
	f=280*0.5+300*0.6+(e-600)*0.8;
	printf("f=%2.lf\n",f);
	return 0;
}
