#include<stdio.h>
int main(){
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=2;i<1000;i++){
		if(m%i==0&&n%i==0){printf("%d ",i);
		break;
		} 
	}
	for(int j=1000;j;j--){
		if(j%m==0&&j%n==0){printf("%d",j);
		break;
		} 
	}
}
