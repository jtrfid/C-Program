#include<stdio.h>
int main()
{
	int a;  //���
	double charge1=0.5;
	double charge2=0.6;
	double charge3=0.8;
	double fee;
	scanf("%d",&a);
	if(a>=0&&a<=20)
	{
		fee=0.0;
	}
	if(a>=21&&a<=300)
	{
	fee=(a-20)*charge1;	
	}
	if(a>=301&&a<=600)
	{
		fee=280*charge1+(a-300)*charge2;
	}
	if(a>=601)
	{
		fee=280*charge1+300*charge2+(a-600)*charge3;
	}
	printf("%.1f",fee);
	return 0;
}
