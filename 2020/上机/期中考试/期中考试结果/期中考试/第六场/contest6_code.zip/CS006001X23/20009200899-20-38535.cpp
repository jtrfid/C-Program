#include <stdio.h>
int main()
{
	int a,b,min,max,i,r,R;
	scanf("%d %d",&a,&b);
	min=a>b?b:a;
	for(i=min;;i--)
	{
		if(a%i==0&&b%i==0)
		{
			r=i;
			break;
		}
	}
	max=a>b?a:b;
	for(i=max;;i++)
	{
		if(i%a==0&&i%b==0)
		{
			R=i;
			break;
		}
	}
	printf("%d %d",r,R);
	return 0;
}
