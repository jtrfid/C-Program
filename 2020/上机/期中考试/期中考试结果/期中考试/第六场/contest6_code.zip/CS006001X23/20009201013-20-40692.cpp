#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int min;
	min=a<b?a:b;
	int i=min;
	for(i=min;i>1;i--){
		if(a%i==0&&b%i==0) break;
	}
	int x,y;
	x=i;
	y=a*b/x;
	printf("%d %d",x,y);
	return 0;
}
