#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int a,b,sum=0,p;
	scanf("%d %d",&a,&b);
	while(a!=0)
	{
		p=a%10;
		a=a/10;
		sum+=p;
		
	}
	if(sum%b==0) printf("%d %d",sum,sum/b);
	else printf("%d No",sum);
	
	
	
	
	
	
	
	system("pause");
	return 0;
}
