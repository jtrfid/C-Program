#include<stdio.h>
int main()
{
	int n;
	float pay=0;
	scanf("%d",&n);
	if(n<=20)
	{
		pay=0;
	}
	else if(n>=21&&n<301)
	{
		pay=(n-20)*0.5;
	}
	else if(n>=301&&n<601)
	{
		pay=280*0.5+(n-300)*0.6;
	}
	else if(n>=601)
	{
		pay=280*0.5+300*0.6+(n-600)*0.8;
	}
	printf("%.1f",pay);
	return 0;
}
