#include<stdio.h>

int main()
{
	int a, b;
	int rem=0,sum=0;
	scanf("%d %d", &a, &b );
	int i=0;
	
	while (!(rem==0 && a==0 ))
	{
		rem = a%10;
		sum = sum +rem;
		a = a/10;
	}
	int shang;
	if (sum%b==0)
	{
		shang = sum/b;
		printf("%d ", shang);
	}
	else
	{
		printf("No");
		
	}

	return 0;	
}
