#include<stdio.h>
int main(){
	double s;
	int n,i;
	scanf("%d",&n);
	for(s=0,i=1;i<=n;i++){
		s=s+1+1.0/i;
	}
	printf("%.1lf",s);
	return 0;
}
