#include<stdio.h>

int main(){
	int m,n,r,a,m1,n1;
	scanf("%d%d",&m,&n);
	m1=m;
	n1=n;
	do{
		r=m%n;
		m=n;
		n=r;
	}while(r!=0);
	a=m1*n1/m;
	printf("%d %d",m,a);
	return 0;
}
