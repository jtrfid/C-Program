#include <stdio.h>
int sum(int n)
{
	if(n<10)
	return n;
	else
	return n%10+sum(n/10);
}
int main()
{
	int A,B,c;
	scanf("%d %d",&A,&B);
	c==sum(A);
	if(B%c==0)
	{
		printf("%d %d",c,B/c);
	}
	else
	{
		printf("%d No",c);
	}
	return 0;
}
