#include<stdio.h>
int main()
{
	int a,b,i,j,temp=0,temp1,temp2,c=0,d=0;
	scanf("%d %d",&a,&b);
	if(b>a){
		temp=a;
		a=b;
		b=temp;
	}
	for(i=1;i<b;i++)
	{
		temp1=a%i;
		temp2=b%i;
		if(temp1==0&&temp2==0){
			c=i;
		}
	}
	if (c==0){
		d=a*b;
	}else{
	d=(a*b)/c;}
	printf("%d %d",c,d);
	return 0;
}
