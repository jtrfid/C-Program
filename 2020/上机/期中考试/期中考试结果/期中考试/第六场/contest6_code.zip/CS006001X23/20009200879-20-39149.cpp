#include <stdio.h>
#include <math.h>

int main() {
	int a, b;

	scanf("%d %d", &a, &b);

	int i, j;

	for (i = 10000; i > 0; i--) {
		if (a % i == 0 && b % i == 0) {
			break;
		}
	}

	for (j = 1; j <= a * b; j++) {
		if (j % a == 0 && j % b == 0) {
			break;
		}
	}

	printf("%d %d", i, j);

	return 0;
}