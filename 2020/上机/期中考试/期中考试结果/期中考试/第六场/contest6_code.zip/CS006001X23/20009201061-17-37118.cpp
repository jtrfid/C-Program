#include<stdio.h>
int main()
{
	int A,B;
	scanf("%d %d",&A,&B);
	int i,a;
	int sum=0;
	while(A!=0)
	{
		a=A%10;
		A=A/10;
		sum=sum+a;
	}
	if(sum%B==0)
	printf("%d %d",sum,sum/B);
	else
	printf("%d No",sum);
} 
