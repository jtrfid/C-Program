#include<stdio.h>
int main()
{
	int m,n,min,gy;
	scanf("%d%d",&m,&n);
	min=m<n?m:n;
	for(int i=1;i<=min;i++)
	{
		if(m%i==0&&n%i==0)
		{
			gy=i;
		}
	}
	printf("%d %d",gy,m*n/gy);
	return 0;
}
