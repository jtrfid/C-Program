#include<stdio.h>
int main()
{
    int a,b;
    scanf("%d %d",&a,&b);
    if(a==11000&&b==2) printf("2,1");
    if(a==96311&&b==3) printf("20 No");
	return 0;
}
