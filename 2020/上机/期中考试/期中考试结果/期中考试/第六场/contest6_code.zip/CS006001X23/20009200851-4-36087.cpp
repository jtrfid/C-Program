#include<stdio.h>
int main()
{
	int n;
	float a;
	scanf("%d",&n);
	if(n>=0&&n<=20)
	{
		a=0.0;
	}
	else if(n>=21&&n<=300)
	{
		a=(n-20.0)*0.5;
	}
	else if(n>=301&&n<=600)
	{
		a=(300.0-20.0)*0.5+(n-300.0)*0.6;
	}
	else if(n>=601)
	{
		a=(300.0-20.0)*0.5+300.0*0.6+(n-600.0)*0.8;
	}
	printf("%.1f",a);
	return 0;
}
