#include<stdio.h>
int main()
{
	int m,n;
	int i,t,a,b;
	
	scanf("%d%d",&m,&n);
	
	if(m>n)
	{
		t=m;
		m=n;
		n=t;
	}
	
	for(i=1;i<m;i++)
	{
		if(m%i==0 && n%i==0)
			a=i;
	}
	b=n;
	while(b%m!=0 || b%n!=0)
	{
		b++;
	}
	
	printf("%d %d",a,b);
	
	return 0;
}
