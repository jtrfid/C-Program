#include<cstdio>
int main()
{
	int n,a;
	float fe=0.0;
	scanf("%d",&n);
	if(n>600)
	{
		a=n-600;
		fe+=a*0.8;
		n=n-a;
	}
	if(n>300)
	{
		a=n-300;
		fe+=a*0.6;
		n=n-a;
	}
	if(n>20)
	{
		a=n-20;
		fe+=a*0.5;
	}
	printf("%.1f",fe);
}
