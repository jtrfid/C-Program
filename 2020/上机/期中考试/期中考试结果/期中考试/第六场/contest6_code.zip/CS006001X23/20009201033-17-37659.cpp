#include <stdio.h>

int main()
{
	long int n;
	int all=0,m,s;
	long int t;
	scanf("%ld %d",&n,&m);
	t=n;
	while(t!=0)
	{
		all+=t%10;
		t/=10;
	}
	if(all%m==0){printf("%d %d",all,all/m);}
	else if(all%m!=0){printf("%d No",all);}
	
	return 0;
}
