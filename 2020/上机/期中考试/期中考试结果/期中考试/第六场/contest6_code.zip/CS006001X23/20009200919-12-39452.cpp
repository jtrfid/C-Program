/*
    
    Name:12.cpp
 
    Author:Konoha Akari
 
    Date:2020/11/21

*/

    #include<stdio.h>
    
	int main()
    
	{
		double s,sum,n,i;
		
		scanf("%Lf",&n); //����һ������n��0<n<=100��
		
		i=1;
		
		for(;i<=n;i++)
		
		{
			
		s=1+1/i;
		
		sum+=s;
		
		}
		
		printf("%.1f",sum); 
		
		return 0;
		
    }
