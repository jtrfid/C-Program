#include<stdio.h>
int main()
{
	int a,b,i,n,sum=0;
	scanf("%d %d",&a,&b);
    n=a;
	for(i=0;a!=0;i++)
	{
		sum+=a%10;
		a=a/10;
	}
	if(sum%b==0)
	printf("%d %d",sum,sum/b);
	else
	printf("%d No",sum);
	return 0;
} 
