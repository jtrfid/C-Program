#include <stdio.h>
int main()

{
	int a,b,sum=0;
	scanf("%d %d",&a,&b);
	for(;a>0;a=a/10)
	{
		sum+=a%10;
	}
	if(sum%b==0)
	{
		printf("%d %d",sum,sum/b);
	}
	else
	{
		printf("%d No",sum);
	}
}
