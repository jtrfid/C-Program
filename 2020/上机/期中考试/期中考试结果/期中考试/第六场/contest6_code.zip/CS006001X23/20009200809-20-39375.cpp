#include<stdio.h>

int main()
{
	int m, n, a, gcd;
	scanf("%d %d", &m, &n);
	
	if (m>n)
	{
		a=n;
	}
	else if (m<n)
	{
		a=m;
	}
	else{a=m=n;
	}
	int i=0;
	for(i=a;i!=1;i--)
	{
		if (m%i==0 && n%i==0)
		{
			gcd=i;
			break;
		}		
	}
	int s=m*n/gcd;
	
	printf("%d %d", gcd, s);
	return 0;
	
}
