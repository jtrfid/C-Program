#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d %d", &m, &n);
	int i;
	int min;
	if ( m<=n )
	min = m;
	else
	min = n;
	for ( i=min; i>=1; i--){
		if ( m%i==0&&n%i==0 )
		break;
	}
	printf("%d ",i);
	printf("%d",m*n/i);
	return 0;
}
