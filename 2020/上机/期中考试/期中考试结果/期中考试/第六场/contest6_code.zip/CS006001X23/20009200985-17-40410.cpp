#include<stdio.h>
int main(){
	int a,b,sum=0,c;
	scanf("%d %d",&a,&b);
	int i=1;
	while(i<=1000000000){
		sum=sum+a/i%10;
		i=i*10;
	}
	if(sum%b==0){
		c=sum/b;
		printf("%d %d",sum,c);
	}
	else{
		printf("%d No",sum);
	}
	return 0;
	}
	
