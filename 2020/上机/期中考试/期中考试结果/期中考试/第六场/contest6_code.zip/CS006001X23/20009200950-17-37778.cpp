#include<stdio.h>
int main()
{
	long int a,b;
	scanf("%d %d",&a,&b);
	int sum=0,n;
	for(int i=0;a>=1;i++)
	{
		n=a%10;
		a=a/10;
		sum+=n;
	}
	if(sum%b==0)
	{
		printf("%d %d",sum,sum/b);
	}
	else{
		printf("%d No",sum);
	}
	return 0;
}
