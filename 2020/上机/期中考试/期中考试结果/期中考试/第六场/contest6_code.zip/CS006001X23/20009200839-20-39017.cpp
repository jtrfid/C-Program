#include <stdio.h>

int main(){
	int m,n;
	scanf("%d%d",&m,&n);
	
	int temp1;
	if(m<n)
	{
		temp1=m;
		m=n;
		n=temp1;
	}
	else
	{
	}
	
	int temp2=m;
	int temp3=n;
	int temp4;
	if(m==1||n==1)
	{
		temp4=1;
	}
	else{
	if(m%n==0)
	{
		temp4=n;
	}
	else
	{
		for(;;)
		{
			temp4=m%n;
			if(n%temp4==0)
			    break;
			else
			{
				m=n;
				n=temp4;
			}
		}
	}
    }
	printf("%d %d",temp4,(temp2*temp3)/temp4);
	return 0;
}
