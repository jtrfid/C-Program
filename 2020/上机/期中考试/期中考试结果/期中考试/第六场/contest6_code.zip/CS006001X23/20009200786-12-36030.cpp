#include <stdio.h>
int main()

{
	int n,i=0;
	float sum=0.0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		sum+=(1.0+1.0/i);
	}
	printf("%.1f",sum);
	return 0;
}
