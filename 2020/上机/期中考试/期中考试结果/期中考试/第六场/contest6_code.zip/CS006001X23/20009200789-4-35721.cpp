#include<stdio.h>

int main(){
	int n;
	float money;
	scanf("%d",&n);
	if(n<=20){
		money=0.0;
	}else if(n<=300){
		money=(n-20)*0.5;
	}else if(n<=600){
		money=140+(n-300)*0.6;
	}else{
		money=320+(n-600)*0.8;
	}
	printf("%.1f",money);
	
	
	return 0;
}
