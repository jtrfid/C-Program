#include<cstdio>
using namespace std;
int main(){
	int n;
	double ans=0.0;
	scanf("%d",&n);
	int i;
	for(i=1;i<=n;i++)
		ans+=(1.0+1.0/i);
	printf("%.1lf",ans);
	return 0;
}
