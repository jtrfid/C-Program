#include <stdio.h>
#include <math.h>

int main() {
	int n, i;
	float a[100];
	float s;

	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		a[i] = 1 + 1 / i;
	}

	for (i = 0; i < n; i++) {
		s += a[i];
	}

	printf("%.1f", s);

	return 0;
}