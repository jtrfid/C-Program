#include<bits/stdc++.h>
using namespace std;

int main()
{
	int m,n;
	int x=1;
	scanf("%d%d",&m,&n);
	if(m<=n) swap(m,n);
	if(m%n==0) printf("%d %d",m,n);
	else while(x++)
	{
		if((m%x==0)&&(n%x==0)) break;
	}
	printf("%d %d",x,x*(m/x)*(n/x));
	return 0;
}
