#include<stdio.h>
int cal(int a)
{
	int sum=0;
	while(a>0)
	{
		sum=sum+a%10;
		a=a/10;
	}
	return sum;
}
int main()
{
	int a,b,c;
	scanf("%d%d",&a,&c);
	b=cal(a);
	if(b%c==0)
	{
		printf("%d %d",b,b/c);
	}
	else
	{
		printf("%d No",b);
	}
	return 0;
}
