#include <stdio.h>
int main()
{
	int A,B,v,sum;
	scanf("%d %d",&A,&B);
	for(v=A,sum=0;v>=1;)
	{
		sum=sum+v%10;
		v/=10;
	}
	if(B%sum==0)
	{
		printf("%d %d",sum,B/sum);
	}
	else
	{
		printf("%d ",su);
		printf("No");
		
	}
	return 0;
}
