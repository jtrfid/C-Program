#include<stdio.h>
int main(){
   int x;
   float y;
   scanf("%d",&x);
   if(x<=20){
     y=0.0;
       }
    else if(21<=x<=300){
    	 y=(x-20)*(0.5);
    }   
   else if(301<=x<=600){
   	 y=140+(x-300)*0.6;
   }
   else if(x>600){
   	 y=320+(x-600)*0.8;
   }
 printf("%.f",y);
   
   
   return 0;
}

