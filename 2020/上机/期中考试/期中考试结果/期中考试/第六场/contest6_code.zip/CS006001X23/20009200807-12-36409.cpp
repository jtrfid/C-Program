#include<stdio.h>
int main(){
	
	int n;
	double sn = 0;
	scanf("%d", &n);
	for(double i = 1;i <= n;i++){
		sn += 1 + 1 / i;
	}
	printf("%.1f", sn);
	
	return 0;
}
