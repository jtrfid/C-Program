#include<stdio.h>
int main()
{
	int a;
	float fee;
	scanf("%d",&a);
	if(a<=20)
	{
		fee=0.0;
	}
	if(a>=21&&a<=300)
	{
		fee=(a-20)*0.5;
	}
	if(a>=301&&a<=600)
	{
		fee=(300-20)*0.5+(a-300)*0.6;
	}
	if(a>=601)
	{
		fee=(300-20)*0.5+(600-300)*0.6+(a-600)*0.8;
	}
	printf("%.1f",fee);
	return 0;
}
