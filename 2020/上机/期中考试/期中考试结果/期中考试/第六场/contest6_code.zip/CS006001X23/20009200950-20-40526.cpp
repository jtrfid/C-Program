#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int c=a*b;
	if(a<b)
	{
		int temp;
		temp=a;
		b=a;
		a=temp;
	} 
	int max;
	for(int i=1;i<=b;i++)
	{
		if(a%i==0&&b%i==0)
		max=i;
	}
	int min=c/max;
	printf("%d %d",max,min);
	return 0;
}
