#include<stdio.h>
int main()
{   int n;
    scanf("%d",&n);
	double s=0.0;
	int i;
	for(i=1;i<=n;i++)
	{ s=s+1+1.0/i;
	} 
	printf("%.1f",s);
	return 0;
}
