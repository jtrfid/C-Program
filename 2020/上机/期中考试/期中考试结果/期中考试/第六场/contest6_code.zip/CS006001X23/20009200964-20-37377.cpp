#include<stdio.h>
int main()
{
	int i,a,b,max,min,gongbei,gongyue;
	scanf("%d %d",&a,&b);
	min=a;
	max=b;
	if(a>b)
	{
		min=b;
		max=a;
	}
		for(i=min; ;i--)
	{
		if(a%i==0&&b%i==0)
		{
			printf("%d ",i);
			break;
		}
	}
	for(i=max; ;i++)
	{
		if(i%a==0&&i%b==0)
		{
			printf("%d ",i);
			break;
		}
		
	}
	return 0;
	
	
}
