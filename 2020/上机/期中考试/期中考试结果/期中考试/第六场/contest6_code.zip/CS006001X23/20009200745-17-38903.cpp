#include<stdio.h>
int main()
{
	int b,x=0;
	unsigned int a;
	
	scanf("%d%d",&a,&b);
	
	while(a!=0)
	{
		x+=a%10;
		a/=10;
	}
	if(x%b==0)
		printf("%d %d",x,x/b);
	else
		printf("%d No",x);
	
	return 0;
}
