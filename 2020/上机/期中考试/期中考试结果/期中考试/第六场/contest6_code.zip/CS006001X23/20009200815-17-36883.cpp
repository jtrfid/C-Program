#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int c=a;
	int sum=0;
	while(c/10!=0)
	{
		sum+=c%10;
		c/=10;
	}
	sum+=c;
	if(sum%b==0)
	{
		printf("%d %d",sum,sum/b);
		
	}
	else
	{
		printf("%d No",sum);
	}
	return 0;
}
