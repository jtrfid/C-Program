#include<stdio.h>
int main()
{
	double n,i=0,sum=0,t;
	scanf("%lf",&n);
	for(i=1;i<=n;i++){
		t=1+1/i;
		sum+=t;
	}
	printf("%.1lf",sum);
	return 0;
}