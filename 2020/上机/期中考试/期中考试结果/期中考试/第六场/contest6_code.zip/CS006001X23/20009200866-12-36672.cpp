#include<stdio.h>
int main(){
int a,i;
double b,c;
scanf("%d",&a);
b=a;
for(i=1;i<=a;i++){
	c=c+1+(1.0/i);
}
printf("%.1f",c);


return 0;
}

