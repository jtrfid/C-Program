#include<stdio.h>
int main(){
int a,b=0,c,i;
scanf("%d%d",&a,&c);
for(i=1;a>0;i++){
	b=a%10+b;
	a=a/10;
}if(b%c==0)
printf("%d %d",b,b/c);
else
printf("%d No",b);

return 0;
}

