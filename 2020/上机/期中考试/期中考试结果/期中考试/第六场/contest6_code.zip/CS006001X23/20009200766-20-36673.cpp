#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int a,b;
int main()
{
	cin>>a>>b;
	int x=__gcd(a,b),y=a*b/x;
	cout<<x<<' '<<y;
}
