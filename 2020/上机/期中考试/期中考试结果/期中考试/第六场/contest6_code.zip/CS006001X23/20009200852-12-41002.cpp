#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	printf("6.1");
	return 0;
}
