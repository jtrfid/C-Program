#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main(void)
{int a;
double s;
scanf("%d",&a);
if(a<=20) s=0;
if(a>=21&&a<=300) s=0.5*(a-20);
if(a>=301&&a<=600)s=140+0.6*(a-300);
if(a>=601) s=320+0.8*(a-600);
printf("%.1lf",s);
return 0;	
}
