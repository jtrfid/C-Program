#include<stdio.h>

int main()
{
	int a,b,c,d,min,i;
	scanf("%d%d",&a,&b);
	
	if(min=a<b?a:b)
	{
		for(i=min;i>=1;i--)
		{
			if(a%i==0&&b%i==0)
			{
				c=i;
				break;
			}
		}
	}
	d=a*b/c;
	printf("%d %d",c,d);
	return 0;
}
