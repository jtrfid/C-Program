#include<stdio.h>

int main()

{
	int a;
	float b;
	
	scanf("%d",&a);
	
	if(a<=20)
	{
		b=0.0;
	}
	if(a>20&&a<=300)
	{
	    b=0.5*(a-20)  ;	
	}
	if(a>300&&a<=600)
	{
		b=0.6*(a-300)+140.0;
	}
	if(a>600)
	{
		b=0.8*(a-600)+320;
	}
	
	printf("%.1f",b);
	
	return 0;
}

