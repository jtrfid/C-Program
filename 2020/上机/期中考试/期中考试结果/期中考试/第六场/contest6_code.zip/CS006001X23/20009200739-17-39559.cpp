#include <stdio.h>

int main() {
	int A, B, SUM;
	scanf("%d %d", &A, &B);
	for (SUM = 0; A != 0;) {
		SUM += A - (A / 10) * 10;
		A = A / 10;
	}
	if (SUM % B == 0) {
		printf("%d %d", SUM, (SUM / B));
	} else {
		printf("%d NO", SUM);
	}
	return 0;
}