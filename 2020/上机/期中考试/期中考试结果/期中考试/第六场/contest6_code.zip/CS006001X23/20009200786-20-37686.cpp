#include <stdio.h>
int main()
{
	int a,b,i,m,n,temp;
	scanf("%d %d",&a,&b);
	if(a<b)
	{
		a=temp;
		a=b;
		b=temp;
	}
	for(i=1;i<=b;i++)
	{
		if(a%i==0 && b%i==0)
		{
			m=i;
		}
	}
	for(i=a;;i++)
	{
		if(i%a==0 && i%b==0)
		
		{
			n=i;
			break;
		}
	}
	printf("%d %d",m,n);
}
