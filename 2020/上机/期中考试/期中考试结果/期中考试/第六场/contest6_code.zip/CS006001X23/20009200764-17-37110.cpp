#include<stdio.h>
int main(){
	int a,b,i=0,j,k,x;
	scanf("%d %d",&a,&b);
	while(a!=0){
		i+=a%10;
		a=a/10;
	}
	if(i%b==0){
		printf("%d %d",i,i%b);
	}
	else{
		printf("%d No",i);
	}
	return 0;
}
