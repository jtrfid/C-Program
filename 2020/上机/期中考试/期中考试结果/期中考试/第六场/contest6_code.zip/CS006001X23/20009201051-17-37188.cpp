#include<cstdio>
int bitsum(long n)
{
	if(n<10)
		return n;
	else
		return n%10+bitsum(n/10);
}
int main()
{
	long a;
	int b;
	scanf("%ld%d",&a,&b);
	int sum=bitsum(a);
	printf("%d ",sum);
	if(sum%b==0)
	{
		printf("%d",sum/b);
	}
	else
	{
		printf("NO");
	}
	return 0;
}
