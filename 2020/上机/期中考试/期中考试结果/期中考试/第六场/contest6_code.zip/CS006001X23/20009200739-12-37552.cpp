#include <stdio.h>

int main() {
	int n, i;
	float S[100] = {0}, Sn;
	scanf("%d", &n);
	for (i = 1; i < n + 1; i++) {
		S[i] = 1 + 1.0 / i;
		Sn += S[i];
	}
	printf("%.1f", Sn);
	return 0;
}