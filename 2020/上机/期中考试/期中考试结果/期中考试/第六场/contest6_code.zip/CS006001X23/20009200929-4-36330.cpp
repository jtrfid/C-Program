#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	float e,r;
	scanf("%f",&e);
	if(e<=20) r=0;
	else if(e>=21&&e<=300) r=(e-20)*0.5;
	else if(e>=301&&e<=600) r=140+(e-300)*0.6;
	else if(e>600) r=140+180+(e-600)*0.8;
	printf("%.1f",r);
	
	
	
	
	
	
	system("pause");
	return 0;
}
