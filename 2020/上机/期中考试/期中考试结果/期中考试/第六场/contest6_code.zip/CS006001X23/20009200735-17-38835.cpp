#include<stdio.h>
#include<math.h>
int main(){
	int A,B,D;
	int C=0;
	scanf("%d %d",&A,&B);
	D=10;
	for(int i=1;i<=10;i++){
		C=C+A%D;
		A=A/D;
	}
	if (C%B==0){
		printf("%d %d",C,C/B);
	}
	else{
		printf("%d No",C);
	}
	return 0;
}
