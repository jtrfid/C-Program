#include<stdio.h>
int main()
{
	int A,B;
	scanf("%d%d",&A,&B);
	
	int C;
	C=A;

	int sum=0;
	while(A>0)
	{
		sum+=A%10;
		A=A/10;
	}
	
	if(C%B==0)
	{
		printf("%d %d",sum,C/B);
	}
	else
	{
		printf("%d No",sum);
	}
	
	
	
	
	return 0;
}
