#include<stdio.h>
int main(){
	long n,m,p,q=0;
	double k;
	scanf("%ld%ld",&n,&m);
	p=n;
	for(int i=0;p;i++){
		q+=p%10;
		p/=10;
	}
	printf("%d ",q);
	if(q%m==0) printf("%d",q/m);
	if(q%m!=0) printf("No");
	
}
