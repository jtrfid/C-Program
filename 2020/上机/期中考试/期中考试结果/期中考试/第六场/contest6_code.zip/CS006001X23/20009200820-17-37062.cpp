#include<stdio.h>
#include<ctype.h>

int main() {
	int a = 0, b, sum = 0;
	char c = getchar();
	while(isdigit(c)) {
		a += c - '0';
		c = getchar();
	}
	scanf("%d", &b);
	printf((a % b) ? "%d No\n" : "%d %d\n", a, a / b);
	return 0;
}
