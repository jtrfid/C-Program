#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
long int a,b;
string s;
int main()
{
	cin>>s>>b;
	for(int i=0;i<s.length();i++)
	{
		a+=s[i]-'0';
	}
	if(a%b==0)
	{
		cout<<a<<' '<<a/b; 
	}
	else cout<<a<<' '<<"No";
	return 0;
}
