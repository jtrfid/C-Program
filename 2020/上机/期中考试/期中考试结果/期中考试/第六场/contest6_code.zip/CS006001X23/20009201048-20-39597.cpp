#include<stdio.h>
int main()
{
	int a,b,t;
	scanf("%d %d",&a,&b);
	if(a<b){
		t=a;a=b;b=t;
	}
	if(b==1) printf("1 %d\n",a);
	else for(int i=b;i>1;i--){
		if(a%i==0 && b%i==0){
			printf("%d %d\n",i,a*b/i);
			break;
		}
	}
	return 0;
}
