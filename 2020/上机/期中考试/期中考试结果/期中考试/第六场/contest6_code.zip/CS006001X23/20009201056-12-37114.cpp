#include<stdio.h>

int main(){
	int n=0;
	int i;
	float b=0.0;
	float sn=0.0;
	scanf("%d",&n);
	
	for(i=1;i<=n;i++){
		b=1+(1.0/i);
		sn+=b;
	}
	printf("%.1f",sn);
	return 0;
}
