#include<stdio.h>
int main(){
	int A,B;
	scanf("%d %d",&A,&B);
	int i;
	int sum=0;
	while(A!=0){
		i=A%10;
		A/=10;
		sum=sum+i;
	}
	if(sum%B==0){
		printf("%d %d",sum,sum/B);
	}
	else
	{
	printf("%d No",sum);
}
	return 0;
}
