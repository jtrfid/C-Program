#include<stdio.h>
#include<math.h>
int main(){
	int a,b,c,d,max,min;
	scanf("%d %d",&a,&b);
	c=a;
	d=b;
	if(a<=b){
		for(int i=1;i!=0;i++){
			c=a;
			if(b%c==0&&a%c==0){
				i=0;
			}
			else{
				c=c-1;
			}
		}
		max=c;
		for(int h=1;h!=0;h++){
			d=b;
			if(d%b==0&&d%a==0){
				h=0;
			}
			else{
				d=d+1;
			}
		}
		min=d;
	}
	else{
	    for(int i=1;i!=0;i++){
		if(b%c==0&&a%c==0){
		i=0;
		}
		else{
			d=d-1;
		}
	    }
	    max=d;
		for(int h=1;h!=0;h++){
			if(c%b==0&&c%a==0){
				h=0;
			}
			else{
				c=c+1;
			}
		}
		min=c;
	}
	printf("%d %d",max,min);
	return 0;
}
