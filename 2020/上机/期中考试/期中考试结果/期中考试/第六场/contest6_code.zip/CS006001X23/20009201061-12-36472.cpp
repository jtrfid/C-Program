#include<stdio.h>
int main()
{
	int n,k;
	scanf("%d",&n);
	float Sn=0.0;
	for(k=1;k<=n;k++)
	{
		Sn=Sn+(1+1.0/k);
	}
	printf("%.1f",Sn);
	return 0;
} 
