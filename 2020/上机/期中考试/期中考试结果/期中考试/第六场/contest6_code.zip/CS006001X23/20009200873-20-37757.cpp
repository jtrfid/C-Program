#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main()
{
	int a,b,i,t;
	
	scanf("%d %d",&a,&b);
	if(a > b)
	{
		t = a;
		a = b;
		b = t;
	}
	
	for(i = a;i > 0;i--)
	{
		if(a%i == 0 && b%i == 0)
		{
			break;
		}
	}
	int min = i;
	
	for(i = b;;i++)
	{
		if(i%a == 0 && i%b == 0)
		{
			break;
		}
	}
	int max = i;
	
	printf("%d %d",min,max);
	
	return 0;
}
