#include<stdio.h>

int main(){
	long int a,b,sum=0,m,n;
	scanf("%d %d",&a,&b);
	m=a;
	for(;m>0;){
		n=m%10;
		sum=sum+n;
		m=m/10;
	}
	if(sum%b==0){
		printf("%d %d",sum,sum/b);
	}else printf("%d No",sum);
	
	return 0;
}
