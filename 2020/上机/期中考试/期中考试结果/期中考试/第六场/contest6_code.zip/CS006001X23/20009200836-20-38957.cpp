#include<stdio.h>
int main()
{
	int m,n,i;
	scanf("%d%d",&m,&n);
	for(i=n;i>0;i--)
	{
		if(m%i==0 && n%i==0)
		{
			break;
		}
	}
	
	printf("%d %d",i,m*n/i);
	return 0;
}
