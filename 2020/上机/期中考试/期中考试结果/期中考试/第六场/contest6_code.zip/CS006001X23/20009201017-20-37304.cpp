#include <stdio.h>
int main()
{
	int a,b,i,max,min,s,x;
	scanf("%d %d",&a,&b);
	max=(a>b)?a:b;
	min=(a<b)?a:b;
	for(i=max;;i++)
	{
		if(i%max==0&&i%min==0)
		{
			s=i;
			break;
		}
	}
	for(i=min;;i--)
	{
		if(max%i==0&&min%i==0)
		{
			x=i;
			break;
		}
	}
	printf("%d %d",x,s);
	return 0;
}
