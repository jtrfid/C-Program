#include <stdio.h>
#include <math.h>

int main() {
	int a, b;
	scanf("%d %d", &a, &b);

	int c, d;
	d = a / 10000000000 + (a / 100000000 - a / 1000000000 * 10) + (a / 10000000 - a / 100000000 * 10) +
	    (a / 1000000 - a / 1000000 * 10) + (a / 100000 - a / 1000000 * 10) + (a / 10000 - a / 100000 * 10) +
	    (a / 1000 - a / 10000 * 10) + (a / 100 - a / 1000 * 10) + (a / 10 - a / 100 * 10) + (a - a / 10 * 10);

	if (d % b == 0) {
		c = d / b;
		printf("%d %d", d, c);

	} else {
		printf("%d No", d);
	}



	return 0;
}