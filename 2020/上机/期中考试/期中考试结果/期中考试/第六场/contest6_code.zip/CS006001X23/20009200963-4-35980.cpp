#include <stdio.h>

double calc(int use) {
	if (use <= 20) return 0;
	if (use <= 300) return (use - 20) * 0.5;
	if (use <= 600) return 140 + (use - 300) * 0.6;
	else return 320 + (use - 600) * 0.8;
}

int main() {
	int n;
	scanf("%d", &n);
	printf("%.1lf\n", calc(n));
	return 0;
}
