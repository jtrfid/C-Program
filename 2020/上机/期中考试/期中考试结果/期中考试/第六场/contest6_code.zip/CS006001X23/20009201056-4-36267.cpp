#include<stdio.h>

int main(){
	int a;
	float b;
	a=b=0.0;
	scanf("%d",&a);
	
	if(a>20&&a<=300){
	  b=(a-20)*0.5;
	}
	  
	else if(a<=600){
		b=(a-300)*0.6+140;
	}
	else{
		b=(a-600)*0.8+140+180;
	}
	printf("%.1f",b);
	return 0;
}
