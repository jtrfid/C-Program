#include<stdio.h>
int main (){
	int a,b,i=1,j,k,x=1,y,fe=0,t;
	scanf("%d %d",&a,&b);
	if(a<b){
		k=b;
		b=a;
		a=k;
	}
	y=a*b;
	t=b;
	for(i=1;i<=b;i++){
		if(a%i==0&&b%i==0){
			x=i;
			
		}	
	}
	printf("%d %d",x,y/x);
}
