#include <stdio.h>

int main() {
	int num;
	float T;
	scanf("%d", &num);
	if (num > 0 && num <= 20) {
		T = 0;
	} else if (num >= 21 && num <= 300) {
		T = (num - 20) * 0.5;
	} else if (num >= 301 && num <= 600) {
		T = (num - 300) * 0.6 + 140.0;
	} else {
		T = (num - 600) * 0.8 + 320.0;
	}
	printf("%.1f", T);
	return 0;
}