#include<stdio.h>
int main()
{
	double n;
	scanf("%lf",&n);
	double i;
	double x,sum;
	for(i=1;i<=n;i++)
	{
		x=1/i;
		sum+=x;
	}
	printf("%.1f",n+sum);
	return 0;
}
