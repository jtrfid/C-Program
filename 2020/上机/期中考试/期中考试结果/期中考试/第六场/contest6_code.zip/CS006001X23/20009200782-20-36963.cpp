#include<cstdio>
using namespace std;
int gcd(int x,int y){
	if(y==0)return x;
	gcd(y,x%y);
}
int main(){
	int x,y;
	scanf("%d%d",&x,&y);
	int a=gcd(x,y);
	printf("%d %d",a,x*y/a);
	return 0;
}
