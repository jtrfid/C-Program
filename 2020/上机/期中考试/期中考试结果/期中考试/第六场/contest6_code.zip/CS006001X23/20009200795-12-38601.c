#include<stdio.h>
int main()
{
	int n,i=0;
	float sn=0;
	scanf("%d",&n);
	while(i<n){
		i=i+1;
		sn=sn+1.0+(1.0/i);
	}
	printf("%.1f",sn);
	return 0;
	 
}
