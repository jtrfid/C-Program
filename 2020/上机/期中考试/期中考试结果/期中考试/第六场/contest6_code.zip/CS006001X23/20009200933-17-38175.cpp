#include<stdio.h>
int main(){
	int A,B,x,i,s;
	scanf("%d%d",&A,&B);
	for(i=10,s=0;A!=0;){
		s+=A%i;
		A=A/10;
	}
	if(s%B==0){printf("%d %d",s,B/s);
	}
	else{printf("%d No",s);
	}
	return 0;
}
