#include<stdio.h>
int main()
{
	int n;
	double cost;
	scanf("%d",&n);
	if(n<=20)
	{
		cost=0.0;
	}
	else if(n>20&&n<=300)
	{
		cost=(n-20)*0.5;
	}
	else if(n>300&&n<=600)
	{
		cost=280.0*0.5+(n-300)*0.6;
	}
	else if(n>600)
	{
		cost=280.0*0.5+300.0*0.6+(n-600)*0.8;
	}
	printf("%.1lf",cost);
	return 0;
}
