#include<stdio.h>
int main(){
	int a,b,i,m,n,t,min;
	scanf("%d %d",&a,&b);
	if(a>b){min=b;
	}
	else
	{min=a;
	}
	for(i=1;i<=min;i++){
		if(a%i==0&&b%i==0)
		m=i;
		else
		m=m;
	}
	n=m*(a/m)*(b/m);
	printf("%d %d",m,n);
	return 0;
}
