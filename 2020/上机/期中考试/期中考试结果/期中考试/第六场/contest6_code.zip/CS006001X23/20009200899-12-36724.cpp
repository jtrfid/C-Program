#include <stdio.h>
int main()
{
	int n,i;
	double s,r;
	scanf("%d",&n);
	for(s=0.0,i=1;i<=n;i++)
	{
		s=s+1.0*1/i;
	}
	r=s+n;
	printf("%.1f",r);
	return 0;
}
