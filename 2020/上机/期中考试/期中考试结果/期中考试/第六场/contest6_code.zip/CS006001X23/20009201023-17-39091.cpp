#include<stdio.h>
int main()
{
	int a,b,c,m,sum,i;
	scanf("%d %d",&a,&b);
	m=a%10;
	sum=m;
	while(a>=1)
	{
		a=a/10;
		m=a%10;
	    sum+=m;
	}
	printf("%d ",sum);
	if(sum%b==0)
	{
		printf("%d",sum/b);
	}
	else
	{
		printf("No");
    }
	return 0;
}
