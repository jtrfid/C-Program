#include<stdio.h>

int main()
{
	int n , i = 1;

	float target = 0.0 ;
	
	scanf("%d", &n );
		
	while( i <= n  )
	{
		target += 1.0/n ;
		
		i ++ ;
	}
	
	printf("3.5", target + n );
	

	return 0 ;
}
