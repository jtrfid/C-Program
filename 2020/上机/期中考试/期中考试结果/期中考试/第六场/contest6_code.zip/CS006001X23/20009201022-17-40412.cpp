#include<stdio.h>
int main()
{
	int A,B;
	scanf("%d%d",&A,&B);
	
	int C;
	C=A;
	
	int i;
	int sum=0;
	for(i=0;i<100000000;i++)
	{
		sum+=A%10;
		A=A/10;
	}
	
	if(sum%B==0)
	printf("%d %d",sum,sum/B);
	else
	printf("%d No",sum);

	return 0;
}
