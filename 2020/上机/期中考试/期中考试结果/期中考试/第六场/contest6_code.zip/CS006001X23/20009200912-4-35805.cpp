#include<stdio.h>
int main()
{
	int elec  ;
	float price ; 
	
	scanf("%d", &elec );
	
	if( elec <= 20 )
		price = 0.0 ; 
	else if( elec <= 300 )
		price = ( elec - 20 ) * 0.5 ;
	else if( elec <= 600 )
		price = 140 + ( price - 300 ) * 0.6 ;
	else 
		price = 140 + ( 600 - 300 ) * 0.6 + ( price - 600 ) * 0.8 ;
		
	printf("%.1f", price ) ;

	return 0 ;
}
