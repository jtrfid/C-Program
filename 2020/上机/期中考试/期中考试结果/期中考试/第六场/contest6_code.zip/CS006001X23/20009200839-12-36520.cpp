#include <stdio.h>

int main(){
	int n;
	scanf("%d",&n);
	
	int i;
	float sum;
	for(i=1,sum=0;i<=n;i++)
	{
		sum+=1+1.0/i;
	}
	printf("%.1f",sum);
	return 0;
}
