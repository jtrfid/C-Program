#include<stdio.h>
int main(){
	int A,B,i,s;
	scanf("%d%d",&A,&B);
	for(i=0,s=0;i<=15;i++){
		s=s+A%10;
		A/=10;
	}
	if(s%B==0)printf("%d %d",s,s/B);
	else printf("%d No",s);
	return 0;
}
