#include<bits/stdc++.h>
using namespace std;

int f(int x)
{
	for(int i=2;i<x;i++)
	{
		if(x%i==0) return 0;break;
		continue; 
	}
	return 1;
}

int main()
{
	int m,n;
	int x=1;
	scanf("%d%d",&m,&n);
	if(m<=n) swap(m,n);
	if(m%n==0) printf("%d %d",n,m);
	else if(f(m)&&f(n)) printf("1 %d",(m*n));
	else if(f(m)||f(n))
	{
		while(x++)
		{
			if((m%x==0)&&(n%x==0)) printf("%d %d",x,x*(m/x)*(n/x));
		}
	}
	//printf("%d %d",x,x*(m/x)*(n/x));
	return 0;
}
