#include<stdio.h>
int main()
{
	double n,i,sum;
	scanf("%lf",&n);
	for(i=1;i<=n;i++)
	{
		sum=sum+(1+(1/i));
	}
	printf("%.1lf",sum);
	return 0;
	
}
