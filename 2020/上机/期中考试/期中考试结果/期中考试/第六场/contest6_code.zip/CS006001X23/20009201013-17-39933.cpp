#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int i=0,sum=0;
	while(a!=0){
		sum=sum+a%10;
		a=a/10;
	}
	printf("%d ",sum);
	if(sum%b==0){
	printf("%d",sum/b);
}
	else  printf("No");
	return 0;
}
