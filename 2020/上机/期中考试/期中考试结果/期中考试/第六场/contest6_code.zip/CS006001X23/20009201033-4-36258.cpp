#include <stdio.h>

int main()
{
	int n;
	double all;
	scanf("%d",&n);
	if(n>=0&&n<=20){all=0.0;}
	else if(n>20&&n<=300){all=(n-20)*0.5;}
	else if(n>300&&n<=600){all=140.0+(n-300)*0.6;}
	else if(n>600){all=320.0+(n-600)*0.8;}
	printf("%.1f",all);
	
	return 0;
}
