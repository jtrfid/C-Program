#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
	int n=0,k=1;
	double Sn=0,i=1;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		Sn+=(1+1.0/i);
	}
	printf("%.1lf",Sn);	
	return 0;
}
