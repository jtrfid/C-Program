#include<stdio.h>
int main(){
	int n;
	float sum=0.0;
	scanf("%d",&n);
	if(n<=20){
		sum=0.0;
	}
	else if(n>=21&&n<=300){
		sum=(n-20.0)*0.50;
	}
	else if(n>=301&&n<=600){
		sum=140.0+(n-300.0)*0.6;
	}
	else{
		sum=320.0+(n-600.0)*0.80;
	}							
	printf("%.1f",sum);
	
return 0;
}
