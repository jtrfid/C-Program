#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main(void){
	int n=0;
	double sum=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		sum +=1.0/i;
	}
	printf("%.1lf",sum+n);
	
	return 0;
}
