#include<stdio.h>
#include<math.h>
int main(){
	int m,n,min,max;
	int i,p,a,b;
	scanf("%d %d",&m,&n);
	if(m<n)
	{
		p=m;
		n=m;
		m=p;
	}
	for(i=n;i>0;i--)
	{
		a=m%i;
		b=n%i;
		if(a==0&&b==0)
		{
			min=i;
			max=(m*n)/i;
			break;
		}
	}
	printf("%d %d",min,max);
	return 0;
	
}
