#include <stdio.h>

int main() {
	int m, n, q, p, max, min;
	scanf("%d %d", &m, &n);
	max = m > n ? m : n;
	min = m < n ? m : n;
	for (q = min; m % q != 0 || n % q != 0; q--) {
	}
	for (p = max; p % m != 0 || p % n != 0; p++) {
	}
	printf("%d %d", q, p);
	return 0;
}