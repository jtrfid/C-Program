#include<cstdio>
using namespace std;
int main(){
	int x,y;
	scanf("%d%d",&x,&y);
	int sum=0;
	while(x){
		sum+=(x%10);
		x/=10;
	}
	printf("%d ",sum);
	if(!(sum%y))printf("%d",sum/y);
	else printf("No");
	return 0;
}
