#include<stdio.h>
int main()
{
	int n;
	double price;
	scanf("%d",&n);
	
	if(n>=0 && n<=20)
	{
		price=0;
	}
	else if(n>=21 && n<=300)
	{
		price=0.5*n;
	}
	else if(n>=301 && n<=600)
	{
		price=280*0.5+0.6*(n-300);
	}
	else if(n>=601 && n<=2000)
	{
		price=280*0.5+300*0.6+(n-600)*0.8;
	}
	
	printf("%.1lf",price);
	return 0;
}
