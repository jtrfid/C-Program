#include <stdio.h>
int main()
{
	int n,b,s,sum,x,k;
	
	sum=0;
	scanf("%d %d",&n,&b);
	k=n;
	while(n>0)
	{
		s=n%10;
		n=n/10;
		sum=sum+s;
	}
	printf("%d ",sum);
	n=k;
	if(n%b==0)
	{
		x=n/b;
		printf("%d",x);
	}
	else
	printf("No");
    return 0;
}

