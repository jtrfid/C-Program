#include <stdio.h>
int main()
{
	int n;//��¼����
	double sum=0.0;
	int i;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		sum+=1.0+(1.0/i);
	} 
	printf("%.1f",sum);
	return 0;
} 
