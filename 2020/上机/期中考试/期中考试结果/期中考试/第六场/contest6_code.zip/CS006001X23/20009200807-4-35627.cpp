#include<stdio.h>
int main(){
	
	int a;
	double s;
	scanf("%d", &a);
	if(a <= 20){
		s = 0;
	}
	else if(a <= 300){
		s = (a - 20) * 0.5;
	}
	else if(a <= 600){
		s = 140 + (a - 300) * 0.6;
	}
	else{
		s = 320 + (a - 600) * 0.8;
	}
	printf("%.1f", s);
	
	return 0;
}
