#include<stdio.h>
int main(){
	int s;
	float t;
	scanf("%d",&s);
	if(s>=0&&s<=20){
		t=0.0;
		printf("%.1f",t);
	}
	if(s>=21&&s<=300){
		t=(s-20)*0.5;
		printf("%.1f",t);
	}
	if(s>=301&&s<=600){
		t=140+(s-300)*0.6;
		printf("%.1f",t);
	}
	if(s>=601){
		t=320+(s-600)*0.8;
		printf("%.1f",t);
	}
	return 0;
	
}
