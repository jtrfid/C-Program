#include<stdio.h>
int main()
{
	int n;
	double s=0.0;
	scanf("%d",&n);
	for(int i=1;i<n+1;i++)
	{
		s=s+1.0*(1+1.0/i);
	}
	printf("%.1f",s);
	return 0;
}
