#include<stdio.h>
int main()
{
	int a,b,i,t=0,n,y;
	scanf("%d %d",&a,&b);
	n=a;
	for(i=0;a>0;i++){
		y=a%10;
		a=a/10;
		t+=y;
	}
	if(t%b==0)
		printf("%d %d",t,t/b);
	else
		printf("%d No",t);

	return 0;
	
}
