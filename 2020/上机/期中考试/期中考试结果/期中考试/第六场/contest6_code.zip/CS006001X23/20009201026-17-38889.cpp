#include <stdio.h>
int sum(int n)
{
	if(n<10)
	{
		return n;
	}
	else
	{
		return n%10+sum(n/10);
	}
}
int main()
{
	int A,B,x;
	scanf("%d %d",&A,&B);
	x=sum(A);
	if(B%x==0)
	{
		printf("%d %d",x,B/x);
	}
	else
	{
		printf("%d No",x);
	}
	return 0;
}
