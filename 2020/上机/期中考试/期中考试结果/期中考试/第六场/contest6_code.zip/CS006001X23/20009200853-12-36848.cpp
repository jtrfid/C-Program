#include<stdio.h>
int main()
{
	int n;
	float x,sum,i;
	sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		x=1+1/i;
		sum=sum+x;
	}
	printf("%.1f",sum);
	return 0;
}
