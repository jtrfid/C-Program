#include<stdio.h>
int main(){
int a,b,i,c,d,t,e,f;
scanf("%d%d",&a,&b);

if(a<b){
	t=a;
	a=b;
	b=t;
}c=a;d=b;
for(i=1;a>0;i++){
	a=a%b;
	if(a<b&&a!=0){
		t=a;
		a=b;
		b=t;
	}

}e=d/b;
f=c*e;
printf("%d %d",b,f);



return 0;
}

