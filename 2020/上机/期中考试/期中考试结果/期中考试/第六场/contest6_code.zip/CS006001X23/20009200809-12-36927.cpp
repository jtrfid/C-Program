#include<stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int i=0;
	float sum = 0,An;
	for (i=1;i<=n;i++)
	{
		An = 1+1.0/i;
		sum = sum +An;
	}
	printf("%.1f", sum);
	return 0;
	
}
