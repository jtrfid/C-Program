#include<stdio.h>
int main(){
	long int a=0,b=0;
	scanf("%ld %ld",&a,&b);
	int sum=0,t=0;
	while(a!=0){
		t=a%10;
		sum=sum+t;
		a=a/10;
	}
	if(b%sum==0){
		printf("%d %d",sum,b/sum);
	}
	else{
		printf("%d No",sum);
	}
	
	
	return 0;
}
