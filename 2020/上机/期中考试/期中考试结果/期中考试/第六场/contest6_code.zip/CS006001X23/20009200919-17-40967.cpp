/*
    
    Name:17.cpp
 
    Author:Konoha Akari
 
    Date:2020/11/21

*/

    #include<stdio.h>
    
	int main()
    
	{
		int a,b,c,d,e,f,g,sum;
		
		scanf(" %d %d",&a,&b); //��������������A��B���Կո�ָ�
		
		c=(a-a%10000)/10000;
		
		d=(a%10000-a%10000%1000)/1000;
		
		e=(a%10000%1000-a%10000%1000%100)/100;
		
		f=(a%10000%1000%100-a%10000%1000%100%10)/10;
		
		g=a%10000%1000%100%10;
		printf("%d %d %d %d %d\n",c,d,e,f,g);
		sum=c+d+e+f+g;
		
		if(sum%b==0)
		
		printf("%d %d",sum,sum%b); 
		
		if(sum%b!=0)
		
		printf("%d No",sum);
		
		return 0;
		
    }
