#include<stdio.h>
int main()
{
	int n;
	float sum=0,i;
	
	scanf("%d",&n);
	
	for(i=1.0;i<=n;i++)
	{
		sum=sum+1.0+1.0/i;
	}
	
	printf("%.1f",sum);
	
	return 0;
}
