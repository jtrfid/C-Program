#include<stdio.h>

int main()
{
	int n;
	double p;
	scanf("%d",&n);
	if(n>=0&&n<=20)
	{
		p=0;
	}
	else if(n>20&&n<=300)
	{
		p=(n-20)*0.50;
	}
	else if(n>300&&n<=600)
	{
		p=280*0.5+(n-300)*0.60;
	}
	else if(n>600)
	{
		p=280*0.5+300*0.6+(n-600)*0.80;
	}
	printf("%.1f",p);
	return 0;
}
