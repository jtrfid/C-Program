#include<stdio.h>
int main()
{
	int a;
	float b;
	scanf("%d",&a);
	if(a<=20)
	{
	b=0.0;
	}
	else if(a<=300)
	{
		b=0.5*a-10.0;
	}
	else if(a<=600){
		b=0.6*(a-300)+140;
	}
	else if(a>600)
	{
		b=0.8*(a-600)+0.6*(a-300)+140;
	}
	printf("%.1f",b);
	return 0;
}
