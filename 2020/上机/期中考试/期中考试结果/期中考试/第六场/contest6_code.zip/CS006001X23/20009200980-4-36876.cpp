#include<stdio.h>
int main()
{
	int dian;
	scanf("%d",&dian);
	double charge;
	if(dian<=20)
	printf("0.0");
	else if(dian>20&&dian<=300)
	printf("%.1f",(dian-20)*0.5);
	else if(dian>300&&dian<=600)
	printf("%.1f",(dian-300)*0.6+140);
	else if(dian>600)
	printf("%.1f",(dian-600)*0.8+320);
	return 0;
}
