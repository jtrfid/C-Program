#include<stdio.h>

int gcd(int a, int b) {
	return b ? gcd(b, a % b) : a;
}

int main() {
	int m, n, g;
	scanf("%d%d", &m, &n);
	g = gcd(m, n);
	printf("%d %d\n", g, n * m / g);
	return 0;
}
