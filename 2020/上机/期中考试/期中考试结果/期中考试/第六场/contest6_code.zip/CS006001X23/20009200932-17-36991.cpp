#include <stdio.h>
int main()
{
	int a,b;
	int sum=0; //��ʾ��λ���ֺ� 
	scanf("%d %d",&a,&b);
	if(a<10)
	{
		sum=a;
	}  
	while(a!=0)
	{
		sum+=a%10;
		a/=10;
	}
	printf("%d ",sum);
	if(sum%b==0)
	{
		printf("%d",sum/b);
	}
	else
	{
		printf("No");
	}
	return 0;
}
