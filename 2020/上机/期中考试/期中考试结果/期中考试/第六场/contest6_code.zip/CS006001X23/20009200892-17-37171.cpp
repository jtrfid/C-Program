#include<stdio.h>
int main(){
	int a,b,t,m,n,i=0,sum=0;
	scanf("%d %d",&a,&b);
	while(a!=0){
		t=a%10;
		a=a/10;
		sum=sum+t;
		i++;
	}
	printf("%d ",sum);
	n=sum%b;
	if(n==0){
		m=sum/b;
		printf("%d",m);
	}
	else
	printf("No");
	return 0;
}
