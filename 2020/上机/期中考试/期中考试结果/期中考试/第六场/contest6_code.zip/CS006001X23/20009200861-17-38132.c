#include<stdio.h>
int main(){
	int A,B;
	scanf("%d %d",&A,&B);
	int sum=0;
	int n=A;
	int t;
	while(A>0){
		n=A%10;
		sum+=n;
		A/=10;
	}
	if(sum%B==0){
		t=sum/B;
		printf("%d %d",sum,t);
	}
	else{
		printf("%d No",sum);
	}
	return 0;
}
