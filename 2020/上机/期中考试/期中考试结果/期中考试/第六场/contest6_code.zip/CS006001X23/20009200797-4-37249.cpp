#include<stdio.h>
int main()
{
	int n=0;
	double sum=0;
	scanf("%d", &n);
	if ( n<=20 ){
		sum=0.0;
	}
	else if ( n>20&&n<=300 ){
		sum = (n-20)*0.5;
	}
	else if ( n>300&&n<=600 ){
		sum = (n-300)*0.6+140;
	}
	else if ( n>600 ){
		sum = (n-600)*0.8+320;
	}
	
	printf("%.1lf", sum);
	
	
	return 0;
}
