#include<stdio.h>

int main() {
	int n;
	double ans = 0;
	scanf("%d", &n);
	printf("%.1lf\n", (n > 20 ? (n - 20) * 0.5 : 0) + (n > 300 ? (n - 300) * 0.1 : 0) + (n > 600 ? (n - 600) * 0.2 : 0));
	return 0;
}
