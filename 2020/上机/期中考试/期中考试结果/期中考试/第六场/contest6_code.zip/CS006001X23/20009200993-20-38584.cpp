#include<stdio.h>

int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	
	int i=a<=b?a:b;
	for(;0<i;i--)
	{
		int m,n;
		m=a%i;
		n=b%i;
		if(m==0&&n==0)
		{
			break;
		}
	}
	
	int j=a>=b?a:b;
		for(;;j++)
	{
		int m,n;
		m=j%a;
		n=j%b;
		if(m==0&&n==0)
		{
			break;
		}
	}
	printf("%d %d",i,j);
	
	return 0;
}
