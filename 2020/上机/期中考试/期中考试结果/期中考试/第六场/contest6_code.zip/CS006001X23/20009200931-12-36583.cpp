#include<stdio.h>
#include<math.h>
int main(){
	int n,i;
	double s,a[100];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		a[i]=1+1.0/(i+1);
		s+=a[i];
	}
	printf("%.1lf",s);
	return 0;
	
	
}
