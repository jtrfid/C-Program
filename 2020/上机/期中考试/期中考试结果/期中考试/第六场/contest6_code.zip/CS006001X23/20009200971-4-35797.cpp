#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main(void){
	int used=0;
	scanf("%d",&used);
	double cost=0;
	if(used>=0&&used<=20){
		cost=0;
	}
	else if(used>=21&&used<=300){
		cost=(used-20)*0.5;
	}
	else if(used>=301&&used<=600){
		cost=(used-300)*0.6+140;
	}
	else if(used>=601){
		cost=(used-600)*0.8+180+140;
	}
	printf("%.1lf",cost);
	
	return 0;
}
