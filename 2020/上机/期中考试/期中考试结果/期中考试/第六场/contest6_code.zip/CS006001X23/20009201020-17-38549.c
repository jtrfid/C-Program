#include<stdio.h>
void main()
{
	int A,B;
	scanf("%d %d",&A,&B);
	int i,sum=0;
	while(A>=10){
		sum=sum+A%10;
		A=A/10;
	}
	sum=sum+A;
	if(sum%B==0){
		printf("%d %d",sum,sum/B);
	}else{
		printf("%d NO",sum);
	}
}
