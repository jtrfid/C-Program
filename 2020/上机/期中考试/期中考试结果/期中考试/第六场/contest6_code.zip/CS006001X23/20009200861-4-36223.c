#include<stdio.h>
int main(){
	double fee;
	int t;
	scanf("%d",&t);
	if(t>=0&&t<=20){
		fee=0;
	}
	else if(t>=21&&t<=300){
		fee=(t-20)*1.0/2;
	}
	else if(t>=301&&t<=600){
		fee=140+(t-300)*0.6;
	}
	else{
		fee=320+(t-600)*0.8;
	}
	printf("%.1lf",fee);
	return 0;
}
