#include<stdio.h>
int main()
{
	int a,b,h=0,i=0,j,temp;
	scanf("%d %d",&a,&b);
	int c[a];
	temp=a;
	while(temp!=0){
		c[i]=temp%10;
		temp=temp/10;
		i=i+1;
	}
	for(j=0;j<i;j++){
		h=h+c[j];
	}
	printf("%d ",h);
	if((a%b)==0){
		printf("%d",(a/b));
	}else{
		printf("No");
	}
	
	return 0;
}
