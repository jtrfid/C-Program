#include<cstdio>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	int n,m;
	if(a<b)
	{
		int t=a;
		a=b;
		b=t;
	}
	int x=a*b;
	for(int i=a;i<=x;i++)
	{
		if(i%a==0&&i%b==0)
		{
			m=i;
			break;
		}
	}
	n=a%b;
	while(n!=0)
	{
		a=b;
		b=n;
		n=a%b;
	}
	n=b;
	printf("%d %d",n,m);
}
