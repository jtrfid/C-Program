#include<stdio.h>
int main(){
	int m,n;
	scanf("%d %d",&m,&n);
	int t;
	int i=m*n;
	int c;
	while(n>0){
		t=m%n;
		m=n;
		n=t;
	}
	c=i/m;
	printf("%d %d",m,c);
	return 0;
}
