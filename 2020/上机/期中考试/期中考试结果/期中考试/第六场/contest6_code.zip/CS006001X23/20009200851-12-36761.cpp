#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	float a=0.0,s=0.0;
	for(i=1;i<=n;i++)
	{
		a=1.0+1.0/i;
		s+=a; 
	}
	printf("%.1f",s);
	return 0;
}
