#include<stdio.h>
int main()
{
	int a,b,x=0,y;
	scanf("%d%d",&a,&b);
	y=a;
	do
	{
		x+=y%10;
		y/=10;
	}
	while(y!=0);
	if(x%b==0)
	{
		printf("%d %d",x,x/b);
	}
	else
	{
		printf("%d No",x);
	}
	return 0;
}
