#include<stdio.h>
int main()
{
	int n;
	double sum=0.0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		sum+=1+(double)1/i;
	printf("%.1lf\n",sum);
	return 0;
}
