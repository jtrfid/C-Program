#include<stdio.h>
int main()
{
	int n;
	double s=0;
	scanf("%d", &n);
	int i;
	for ( i=1; i<=n; i++ ){
		s=s+1.0/i+1;
	}
	printf("%.1lf", s );
	return 0;
}
