#include<stdio.h>
int main(){
	int n;
	double Sn=0.0;
	double t;
	scanf("%d",&n);
	int i;
	for(i=1;i<=n;i++){
		t=1+1.0/i;
		Sn+=t;
	}
	printf("%.1lf",Sn);
	return 0;
}
