#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main()
{
	int a,b,i,t;
	
	scanf("%d %d",&a,&b);
	if(a > b)
	{
		t = a;
		a = b;
		b = t;
	}
	
	for(i = 2;i <= a;i++)
	{
		if(a%i == 0 && b%i == 0)
		{
			break;
		}
	}
	
	int max = a*b / i;
	
	printf("%d %d",i,max);
	
	return 0;
}
