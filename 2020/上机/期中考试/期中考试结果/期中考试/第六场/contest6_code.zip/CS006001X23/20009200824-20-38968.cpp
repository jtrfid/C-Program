#include<stdio.h>

int main()
{
	int a,b,min,i,j,gcd,bcd;
	
	scanf("%d %d",&a,&b);
	
	min=a>b?b:a;
	
	for(i>0;i<+min;i++)
	{
		if(a%i==0&&b%i==0)
		{
			gcd=i;
		}
		
	}
	
	for(j=a*b;j>=min;j--)
	{
		if(j%a==0&&j%b==0)
		{
			bcd=j;
		}
	}
	
	printf("%d %d",gcd,bcd);
	

}
