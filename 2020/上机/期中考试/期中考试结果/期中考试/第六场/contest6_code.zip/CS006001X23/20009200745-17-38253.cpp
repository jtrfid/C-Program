#include<stdio.h>
int main()
{
	int a,b,x=0,i;
	
	scanf("%d%d",&a,&b);
	
	while(a!=0)
	{
		x+=a%10;
		a/=10;
	}
	if(b%x==0)
		printf("%d %d",x,b/x);
	else
		printf("%d No",x);
	
	return 0;
}
