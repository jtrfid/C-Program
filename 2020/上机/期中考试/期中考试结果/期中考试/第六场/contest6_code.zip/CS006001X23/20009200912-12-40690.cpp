#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n , i = 1;

	float target = 0.0 ;
	
	scanf("%d", &n );
		
	while( i <= n  )
	{
		target += 1.0 / n ;
		
		i ++ ;
	}
	
	printf("7.3", target + n);
	

	return 0 ;
}
