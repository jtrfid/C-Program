#include<stdio.h>

int main() {
	int n;
	double ans = 0;
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i) {
		ans += 1 + 1.0 / i;
	}
	printf("%.1lf\n", ans);
	return 0;
}
