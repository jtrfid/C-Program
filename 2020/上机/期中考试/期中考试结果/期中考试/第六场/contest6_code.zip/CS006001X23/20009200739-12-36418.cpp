#include <stdio.h>

int main() {
	int n, i;
	float S[100] = {0}, Sn;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		S[i] = (float)1 + 1 / i;
		Sn += S[i];
	}
	printf("%.1f", Sn);
	return 0;
}