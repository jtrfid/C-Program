// By FengChang 2020-11-21
#include<bits/stdc++.h>
using namespace std;
#define foe(i,a) for(__typeof(a.end())i=a.begin();i!=a.end();++i)
int gcd(int a,int b){while(b)a%=b,a^=b^=a^=b;return a;}
int main(){
#ifdef flukehn
	freopen("a.txt","r",stdin);
#endif
	int a,b,s=0;
	cin>>a>>b;
	int c=a;
	while(c)s+=c%10,c/=10;
	printf("%d ",s);
	if(s%b)puts("No");
	else printf("%d\n",s/b);
}
