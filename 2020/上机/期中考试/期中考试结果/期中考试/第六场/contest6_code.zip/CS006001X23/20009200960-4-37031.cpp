#include<stdio.h>
int main()
{int x;
float y;
scanf("%d",&x);
if(x<21) y=0.0;
else if(x<301) y=0.5*x-10;
else if(x<601) y=0.6*x-40;
else if(x>600) y=0.8*x-160;
printf("%.1f",y);
return 0;
}
