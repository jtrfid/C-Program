#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
int k;
double sum;
int main()
{
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		sum+=1+1.0/i;
	}
	printf("%.1f",sum);
	return 0;
}
