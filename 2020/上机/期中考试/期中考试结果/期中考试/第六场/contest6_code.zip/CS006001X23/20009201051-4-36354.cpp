#include<cstdio>
int main()
{
	int n;
	double anw=0;
	scanf("%d",&n);
	if(n>20)
	{
		n-=20;
		if(n>280)
		{
			anw+=280*0.5;
			n-=280;
			if(n>300)
			{
				anw+=300*0.6;
				n-=300;
				if(n>0)
				{
					anw+=n*0.8;
				}	
			}
			else
			{
				anw+=n*0.6;
			}
		}
		else
		{
			anw+=n*0.5;
		}
	}
	else
	{
		anw=0;
	}
	printf("%.1lf",anw);
	return 0;
}
