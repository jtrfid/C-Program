#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int i,n;
	scanf("%d",&n);
	float S=0,a[101],k;
	for(i=0;i<n;i++)
	{
		k=i;
		a[i]=1+1/(k+1);
	}
	for(i=0;i<n;i++)
	{
		S+=a[i];
	}
	printf("%.1f",S);
	
	
	
	
	
	
	system("pause");
	return 0;
}
