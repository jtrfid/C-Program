#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int c=a;
	int sum=0;
	while(c/10!=0)
	{
		sum+=c%10;
		c/=10;
	}
	sum+=c;
	if(a%b==0)
	{
			printf("%d %d",sum,a/b);
		
	}
	else
	{
		printf("%d No",sum);
	}

	return 0;
}
