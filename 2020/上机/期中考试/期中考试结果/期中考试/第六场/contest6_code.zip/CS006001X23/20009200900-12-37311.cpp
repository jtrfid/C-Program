#include<stdio.h>
int main()
{
	
	int k,n;
	scanf("%d",&n);
	double sn=0.0;
	for(k=1;k<=n;k++)
	{
		sn=sn+1.0+1.0/k;
	}
	printf("%.1lf",sn);
	return 0;
}
