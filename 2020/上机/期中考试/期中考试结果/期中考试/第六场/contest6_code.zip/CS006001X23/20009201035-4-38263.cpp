#include<stdio.h>
int main(){
	int n;
	double m;
	scanf("%d",&n);
	if(n<=20&&n>=0) m=0;
	if(n>20&&n<=300) m=(n-20)*0.5;
	if(n>300&&n<=600) m=(n-300)*0.6+140;
	if(n>600) m=(n-600)*0.8+140+180;
	printf("%.1f",m);
}
