#include<stdio.h>
int main() 
{
	int n;
	float f;
	scanf("%d",&n);
	if(n<=20)
	f=0;
	else if(n>20&&n<=300)
	f=0.5*(n-20);
	else if(n>300&&n<=600)
	f=0.5*280+0.6*(n-300);
	else
	f=0.5*280+0.6*300+0.8*(n-600);
	printf("%.1f",f);
	return 0;
}
