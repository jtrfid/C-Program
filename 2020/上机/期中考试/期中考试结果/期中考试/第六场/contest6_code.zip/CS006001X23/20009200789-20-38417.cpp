#include<stdio.h>

int main(){
	int a,b;
	scanf("%d %d",&a,&b);
	int beishu,yueshu=1,m;
	for(m=1;m<=a,m<=b;m++){
		if(a%m==0&&b%m==0){
			yueshu=m;
			//printf("%d\n",yueshu);
		}
	}
	beishu=a*b/yueshu;
	printf("%d %d",yueshu,beishu);
	
	return 0;
}
