#include<stdio.h>
int main()
{
	int n,b,a,i,j,p;
	scanf("%d %d",&n,&b);
	p=n*b;
	if(n>b)
	{
		a=n;
		n=b;
		b=a;
	}
	for(i=n;i>0;i--)
	{
		if(n%i==0&&b%i==0)
		printf("%d %d",i,p/i);
		break;
	}
	return 0;
}
