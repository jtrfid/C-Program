#include<stdio.h>

int main(){
	int a,b,t,sum;
	a=b=t=sum=0;
	scanf("%d%d",&a,&b);
	
	while(a!=0){
		t=a%10;
		a=a/10;
		sum+=t;	
	}
	
	if(sum%b==0){
		printf("%d %d",sum,sum/b);
	}
	else{
		printf("%d No",sum);
	}
	return 0;
}
