#include<stdio.h>
int main()
{
	int a,b,m,i,j,p;
	scanf("%d %d",&a,&b);
	p=a*b;
	if(a>b)
	{
		m=a;
		a=b;
		b=m;
	}
	for(i=a;i>0;i--)
	{
		if(a%i==0&&b%i==0)
		{printf("%d %d ",i,p/i);
		break;
		}
	
	}
		return 0;
}
