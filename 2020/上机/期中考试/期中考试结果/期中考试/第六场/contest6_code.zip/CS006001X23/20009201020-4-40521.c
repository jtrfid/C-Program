#include<stdio.h>
void main()
{
	int d;
	double sum=0;
	scanf("%d",&d);
	if(0<=d&&d<=20){
		sum=0;
		printf("%.1f",sum);
	}
	if(20<d&&d<=300){
		sum=(d-20)*0.50;
		printf("%.1f",sum);
	}
	if(300<d&&d<=600){
		sum=280*0.5+(d-300)*0.60;
		printf("%.1f",sum);
	}
	if(600<d){
		sum=280*0.5+300*0.6+(d-600)*0.80;
		printf("%.1f",sum);
	}
}
