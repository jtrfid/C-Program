#include <stdio.h>
int main()
{
	int A,B,v,sum,t;
	scanf("%d %d",&A,&B);
	for(v=A,sum=0;v>=1;)
	{
		sum=sum+v%10;
		v/=10;
	}
	if(B%sum==0)
	{
		t=B/sum;
		printf("%d %d",sum,t);
	}
	else
	{
		printf("%d ",sum);
		printf("No");
		
	}
	return 0;
}
