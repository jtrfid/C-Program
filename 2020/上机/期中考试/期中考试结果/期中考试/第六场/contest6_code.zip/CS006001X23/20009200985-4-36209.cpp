#include<stdio.h>
int main(){
	int n;
	double sum;
	scanf("%d",&n);
	if(n>=0&&n<=20){
		sum=0;
	}else if(n>=21&&n<=300){
		sum=0.5*(n-20);
	}else if(n>=301&&n<=600){
		sum=0.5*(300-20)+0.6*(n-300);
	}else{sum=0.5*(300-20)+0.6*(600-300)+0.8*(n-600);
	}
	printf("%.1f",sum);
	return 0;
}
