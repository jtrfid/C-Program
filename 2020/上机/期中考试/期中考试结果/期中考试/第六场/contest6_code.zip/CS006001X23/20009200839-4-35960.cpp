#include <stdio.h>

int main(){
	int temp;
	scanf("%d",&temp);
	float pay;
	if(temp>=0&&temp<=20)
	{
		pay=0.0;
	}
	else if(temp>=21&&temp<300)
	{
		pay=(temp-20)*0.5;
	}
	else if(temp>=301&&temp<600)
	{
		pay=140.0+(temp-300)*0.6;
	}
	else
	{
		pay=320.0+(temp-600)*0.8;
	}
	printf("%.1f",pay);
	return 0;
}
