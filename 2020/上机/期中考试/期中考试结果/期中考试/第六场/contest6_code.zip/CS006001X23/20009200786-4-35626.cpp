#include <stdio.h>
int main()
{
	int n;
	float a=0.0;
	scanf("%d",&n);
	if(n<=20)
	{
		printf("%.1f",a);
	}	
	else if(n>20 && n<=300)
	{
		a=((n-20)*0.5);
		printf("%.1f",a);
		
	}
	else if(n>301 && n<=600)
	{
		a=((n-300)*0.6+280*0.5);
		printf("%.1f",a);
		
	}
	else if(n>600)
	{
		a=((n-600)*0.8+280*0.5+300*0.6);
		printf("%.1f",a);
		
	}
	return 0;
}
