#include<stdio.h>
int main()
{
	int n;
	float s;
	scanf("%d",&n);
	if(n<=20){
		s=0;
	}else if(n>=21&&n<=300){
		s=(n-20.0)*(0.5);
	}else if(n>=301&&n<=600){
		s=140+(n-300.0)*(0.6);
	}else if(n>=601){
		s=320+(n-600.0)*(0.8);
	}
	printf("%.1f",s);
	return 0;
}
