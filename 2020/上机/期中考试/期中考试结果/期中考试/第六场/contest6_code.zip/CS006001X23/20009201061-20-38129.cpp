#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int i;
	int max,min;
	int yue,bei;
	if(m>n)
	{
		max=m;
		min=n;
	}
	else
	{
		max=n;
		min=m;
	}
	for(i=min;i>=1;i--)
	{
		if(max%i==0&&min%i==0)
		{
		yue=i;
		break;
	}
	}
	for(i=max;i<=(m*n);i++)
	{
		if(i%max==0&&i%min==0)
		{
		bei=i;
		break;
	}
	}
	printf("%d %d",yue,bei);
	return 0;
	
}
