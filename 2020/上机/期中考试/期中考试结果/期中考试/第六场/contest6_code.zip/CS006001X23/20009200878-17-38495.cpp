#include<stdio.h>
int main(){
	int a,b,sum=0,x=0,temp=0;
	scanf("%d %d",&a,&b);
	while(a/10!=0){
		temp=a%10;
		sum+=temp;
		a/=10;
		
		
	}
	sum=sum+a;
//	printf("%d",sum);
	if(sum%b!=0){
		printf("No");
	}
	else {
		printf("%d %d",sum,sum/b);
	}
	return 0;
}
