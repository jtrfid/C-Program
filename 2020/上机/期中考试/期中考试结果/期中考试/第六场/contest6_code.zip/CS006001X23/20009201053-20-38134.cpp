#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
	int a=0,b=0;
	int m,n,temp,j=0,k=0;//�м����
	scanf("%d %d",&a,&b);
	if(a<=b) 
	{
		temp=a;
		a=b;
		b=temp;
	}
	m=a;
	n=b;
	if(a%b!=0)
	{
		while(m%n!=0)
		{
			j=m%n;
			m=n;
			n=j;
		}
		printf("%d %d",n,a*b/n);
	}
	if(a%b==0)
	{
		printf("%d %d",b,a);
	}
	return 0;
}
