// By FengChang 2020-11-21
#include<bits/stdc++.h>
using namespace std;
#define foe(i,a) for(__typeof(a.end())i=a.begin();i!=a.end();++i)
int gcd(int a,int b){while(b)a%=b,a^=b^=a^=b;return a;}
double F(int n){
	if(n<=20)return 0;
	if(n<=300)return 0.5*(n-20);
	double ret=0.5*(300-20);
	if(n<=600)return ret+0.6*(n-300);
	ret+=0.6*(600-300);
	return ret+0.8*(n-600);
}
int main(){
#ifdef flukehn
	freopen("a.txt","r",stdin);
#endif
	int n;
	cin>>n;
	printf("%.1f\n",F(n));
}
