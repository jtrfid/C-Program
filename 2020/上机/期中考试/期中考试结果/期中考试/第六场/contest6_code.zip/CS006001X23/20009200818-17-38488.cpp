#include<stdio.h>

int main()
{
	int A,B,c,d;
	int i=0,sum=0;
	scanf("%d%d",&A,&B);
	while(A>0)
	{
		i=A%10;
		A=A/10;
		sum=sum+i;
	}
	c=sum%B;
	d=sum/B;
	if(c==0)
	{
		printf("%d %d",sum,d);
	}
	else
	{
		printf("%d No",sum);
	}
	return 0;
}
