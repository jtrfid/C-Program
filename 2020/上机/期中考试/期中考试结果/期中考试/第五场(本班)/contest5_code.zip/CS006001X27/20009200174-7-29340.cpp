#include<stdio.h>
int main ()
{
	int a,b,n;

	scanf("%d",&n);
	for(a=2;a<=n;a+=2)	
	{	b=a*a;
		printf("%d %d\n",a,b);
		
	}
	
	
	
}
