#include<stdio.h>
int main ()
{
	char n;
	int a=0,b=0,c=0,d;
	while(d!=33)
	{
		scanf("%c",&n);
		d=(int)n;
		if(d>=65&&d<=90)
	   {
	   	a++;
	   }
	   if(d>=48&&d<=57)
	   {
	   	c++;
	   }
	   if(d>=97&&d<=122)
	   {
	   	b++;
	   }
	}
	 printf("%d %d %d",a,b,c);
    return 0;
}
