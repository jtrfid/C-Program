#include<stdio.h>
int main()
{
	int sum,n,a;
	scanf("%d",&n);
	for(a=1;a<=n;a++)
	{
		if(a%2==0)
		{
			sum=a*a;
			printf("%d %d\n",a,sum);
		}

	}
	return 0;
}
