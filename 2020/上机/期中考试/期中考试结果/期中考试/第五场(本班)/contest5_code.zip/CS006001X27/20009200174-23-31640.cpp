#include<stdio.h>

int MIN(int a,int b)
{
	if(a>b) return b;
	else return a;
	
	
}
int main()
{
	int a,i,j,min=1000,x,y;
	scanf("%d",&a);
	for(i=2;i<=a/2;i++)
	{
		for(j=2;i%j!=0;)
		{
		j++;
		}
		if(i==j)
		{
			for(j=2;(a-i)%j!=0;)
			{
				j++;
			}	
			if((a-i)==j) 
			{
			
			x=i;y=a-i;
			min=MIN(y-x,min);
			}
			
		}
		
		
		
	}
	printf("%d %d",x,y);
	
	
	
}
