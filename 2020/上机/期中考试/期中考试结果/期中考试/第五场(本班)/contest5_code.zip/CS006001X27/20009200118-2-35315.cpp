#include<stdio.h>
int main ()
{
	int a,b,c,s;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b<=c||a+c<=b||b+c<=a)
	{
		printf("no");
	}
	else if(a*a+b*b==c*c||a*a+c*c==b*b||b*b+c*c==a*a&&a+b!=c&&a+c!=b&&b+c!=a)
	{   if(a==1,b==1,c==2||c==1,b==1,a==2||a==1,b==2,c==1)
	{
		printf("no");
	}
		if(a>=c&&a>=b)
		{
			s=b*c*1/2;
		}
		else if(b>=a&&b>=c)
		{
			s=a*c*1/2;
		}
		else(c>=a&&c>=b);
   		{
			s=a*b*1/2;
		}
		printf("%d",s);
	}
	else
	{
		printf("normal");
	}
	return 0;
}
