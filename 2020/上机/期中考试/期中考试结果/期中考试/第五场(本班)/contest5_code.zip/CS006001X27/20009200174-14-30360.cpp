#include<stdio.h>
int main ()
{	char a;
	int daxie=0,xiaoxie=0,shuzi=0,b;
	while(1)
	{
		scanf("%c",&a);
		b=(int)a;
		if(b==33) break;
		if(b>=65&&b<=90) daxie++;
		if(b>=97&&b<=122) xiaoxie++;
		if(b>=48&&b<=57) shuzi++;
		
		
	}
	printf("%d %d %d",daxie,xiaoxie,shuzi);
	
	
}
