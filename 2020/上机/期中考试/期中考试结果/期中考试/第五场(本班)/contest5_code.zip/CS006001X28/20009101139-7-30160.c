#include <stdio.h>

int main() {
	int a, i, j;
	scanf("%d", &a);
	for (i = 1; i <= a; i++) {
		if (i % 2 == 0) {
			j = i * i;
			printf("%d %d\n", i, j);
		}
	}
	return 0;
}