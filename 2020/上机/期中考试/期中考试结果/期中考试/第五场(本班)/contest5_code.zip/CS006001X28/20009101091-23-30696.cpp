#include <stdio.h>

int main() {
	int a, i, j, k, x1 = 100000, x2, m1, m2;
	scanf("%d", &a);
	for (i = 2; i <= a / 2; i++) {
		for (j = 2; j < i; j++) {
			if (i % j == 0) {
				break;
			}
		}
		if (j == i) {
			k = a - i;
			for (j = 2; j < k; j++) {
				if (k % j == 0) {
					break;
				}
			}
			if (j == k) {
				x2 = k - i;
				{
					if (x2 < x1) {
						x1 = x2;
						m1 = i;
						m2 = k;
					}
				}
			}
		}
	}
	printf("%d %d", m1, m2);
	return 0;
}