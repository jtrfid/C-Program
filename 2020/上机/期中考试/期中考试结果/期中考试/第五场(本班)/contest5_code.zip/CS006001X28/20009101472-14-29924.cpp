#include <stdio.h>

int main() {
	char str[] = {0};
	int i, num1 = 0, num2 = 0, num3 = 0;
	gets(str);
	for (i = 0; str[i] != '!'; i++) {
		if (str[i] > 64 && str[i] < 91)
			num1++;
		else if (str[i] > 96 && str[i] < 123)
			num2++;
		else
			num3++;
	}
	printf("%d %d %d", num1, num2, num3);
	return 0;
}