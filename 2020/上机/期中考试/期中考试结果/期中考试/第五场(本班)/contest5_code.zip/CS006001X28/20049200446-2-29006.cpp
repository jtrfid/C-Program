#include <stdio.h>

int main() {
	int a, b, c;
	int S;
	scanf("%d%d%d", &a, &b, &c);
	if ((a + b > c) && (a + c > b) && (b + c > a)) {
		if (a * a + b * b == c * c) {
			printf("%d", S = 0.5 * a * b);
		} else if (a * a + c * c == b * b) {
			printf("%d", S = 0.5 * a * c);
		} else if (c * c + b * b == a * a) {
			printf("%d", S = 0.5 * b * c);
		} else
			printf("normal");
	} else
		printf("no");
	return 0;

}