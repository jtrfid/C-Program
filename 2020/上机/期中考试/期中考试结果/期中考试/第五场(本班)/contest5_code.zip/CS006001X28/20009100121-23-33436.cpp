#include <stdio.h>

int main() {
	int n, i, j, flag = 1, cnt = 0, a = 0;
	int sushu[1000];
	scanf("%d", &n);

	for (i = 1; i < n; i++) {
		flag = 1;
		for (j = 2; j < i; j++) {
			if (i % j == 0) {
				flag = 0;
				break;
			}
		}
		if (flag == 1) {

			sushu[cnt] = i;
			cnt++;
		}
	}

	if (cnt % 2 == 0) {
		for (i = cnt / 2; i >= 0; i--) {
			for (j = cnt / 2; j <= cnt; j++) {
				if (sushu[i] + sushu[j] == n) {
					printf("%d %d", sushu[i], sushu[j]);
					a = 1;
					break;
				}
				if (a)
					break;
			}
			if (a)
				break;
		}
	} else {
		for (i = cnt / 2 + 1; i >= 0; i--) {
			for (j = cnt / 2 + 1; j <= cnt; j++) {
				if (sushu[i] + sushu[j] == n) {
					printf("%d %d", sushu[i], sushu[j]);
					a = 1;
					break;
				}
				if (a)
					break;
			}
			if (a)
				break;
		}
	}


	return 0;
}