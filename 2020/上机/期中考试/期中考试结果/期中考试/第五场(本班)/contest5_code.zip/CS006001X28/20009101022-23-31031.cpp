#include <stdio.h>

int main() {
	int a[1000],n,i,j,count=0,flag,b=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		flag=1;
		for(j=2;j<i;j++)
		if(i%j==0) flag=0;
		if(flag)
		{
			a[count]=i;
			count++;
		}
	}
	for(i=count/2;i>=0;i--)
	{
		for(j=i;j<=count;j++)
		if(a[i]+a[j]==n)
		{
			printf("%d %d",a[i],a[j]);
			b=1;
		}
		if(b==1)
		break;
	}
	return 0;
}