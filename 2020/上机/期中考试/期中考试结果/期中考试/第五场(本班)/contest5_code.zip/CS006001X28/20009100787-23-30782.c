#include <stdio.h>

int main(void) {
	int n;
	int c, ans = 0, ans0 = 0;
	int i;
	scanf("%d", &n);
	c = n / 2;
	for (c; ans0 == 0; c++) {
		ans = 0;
		for (i = 2; i < c; i++) {
			if (c % i == 0) {
				ans = 1;
				break;
			}
		}
		for (i = 2; i < n - c && ans == 0; i++) {
			if ((n - c) % i == 0) {
				ans0 = 0;
				break;
			}
			ans0 = 1;
		}
	}
	c--;
	printf("%d %d", n - c, c);
	return 0;
}