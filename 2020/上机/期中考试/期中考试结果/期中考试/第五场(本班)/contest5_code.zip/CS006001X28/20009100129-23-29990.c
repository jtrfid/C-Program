#include <stdio.h>

int IsPrime(int a) {
	int i = 2;
	for (i = 2; i < a; i++) {
		if (a % i == 0) {
			return 0;
		}
	}
	return 1;
}

int main() {
	int n;
	int cha = 1000;
	struct shu {
		int i;
		int j;
	} x;
	int i, j;
	scanf("%d", &n);
	for (i = 2; i < n; i++) {
		for (j = i; j < n; j++) {
			if (IsPrime(i) && IsPrime(j) && i + j == n) {
				if (j - i < cha) {
					x.i = i;
					x.j = j;
				}
			}
		}
	}
	printf("%d %d", x.i, x.j);
	return 0;
}