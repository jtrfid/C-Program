#include <stdio.h>

int main() {
	char b;
	int c = 0, d = 0, e = 0, i = 0;
	while (b != '!') {
		scanf("%c", &b);
		i++;
		if (b >= 48 && b <= 57)
			c++;
		if (b >= 65 && b <= 90)
			d++;
		if (b >= 97 && b <= 122)
			e++;


	}
	printf("%d %d %d", d, e, c);
	return 0;
}