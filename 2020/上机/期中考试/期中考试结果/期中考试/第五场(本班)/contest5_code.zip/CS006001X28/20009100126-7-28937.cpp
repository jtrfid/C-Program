#include <stdio.h>
#include <math.h>

int main() {
	int a, b;
	scanf("%d", &a);
	for (b = 2; b <= a; b += 2) {
		printf("%d %d\n", b, b * b);
	}
	return 0;
}