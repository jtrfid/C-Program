#include <stdio.h>

int main() {
	int a, b, c, s ;
	scanf("%d%d%d", &a, &b, &c);
	if (a + b > c && a + c > b && b + c > a) {
		if (a * a == b * b + c * c) {
			s =  0.5 * b * c;
			printf("%d", s);
		} else if (b * b == a * a + c * c) {
			s = 0.5 * a * c;
			printf("%d", s);
		} else if (c * c == a * a + b * b) {
			s = 0.5 * a * b;
			printf("%d", s);
		} else
			printf("normal");
	} else
		printf("no");
	return 0;
}