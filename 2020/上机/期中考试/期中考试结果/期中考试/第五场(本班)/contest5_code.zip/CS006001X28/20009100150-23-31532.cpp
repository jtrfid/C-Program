#include <stdio.h>
#include <math.h>

int main() {
	int Su(int x);
	int n, a, b, i, j, t;
	scanf("%d", &n);
	t = n / 2;
	for (i = t; i > 1; i--) {
		j = n - i;
		if (Su(i) && Su(j)) {
			a = i;
			break;
		}
	}
	b = n - a;
	printf("%d %d", a, b);

	return 0;
}

int Su(int x) {
	int i, t;
	if (x == 1)
		return 0;
	else if (x == 2)
		return 1;
	else {
		for (i = 2, t = 0; i < x; i++)
			if (x % i == 0)
				t = t + 1;
		if (t == 0)
			return 1;
		else
			return 0;
	}
}
