#include <stdio.h>

int main(void) {
	int i, n;
	scanf("%d", &n);
	for (i = 2; i <= n; i += 2) {
		printf("%d %d\n", i, i * i);
	}
	return 0;
}