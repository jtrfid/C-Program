#include <stdio.h>

int main() {
	int a, i, j, h, flag = 0;
	scanf("%d", &a);
	i = a / 2;
	if (i % 2 == 0) {
		j = i + 1;
		h = i - 1;
		flag = 1;
	}
	if (flag == 1)
		printf("%d %d", h, j);
	else
		printf("%d %d", i, i);
	return 0;
}