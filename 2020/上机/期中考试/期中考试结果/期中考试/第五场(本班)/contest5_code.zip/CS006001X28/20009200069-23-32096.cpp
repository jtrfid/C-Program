#include <stdio.h>

int main() {
	int i, a, b, j, flag = 0;
	scanf("%d", &a);
	for (i = a / 2; 1 <= a - 1; i++) {
		b = a - i;
		for (j = 2; j < i / 2; j++)
			flag = 0;
		if (i % j == 0)
			flag = 1;
		else {
			for (j = 2; j < b / 2; j++)
				flag = 0;
			if (b % j == 0)
				flag = 1;
			if (flag == 0) {
				printf("%d %d", i, b);
				break;
			}
		}
	}


	return 0;
}