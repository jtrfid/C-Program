#include <stdio.h>

int main() {
	char ch[100];
	int a, b, c, i, j;
	i = 1;
	a = 0;
	b = 0;
	c = 0;
	scanf("%c", &ch[0]);
	while (ch[i - 1] != '!') {
		scanf("%c", &ch[i]);
		i++;
	}
	for (j = 0; j < i; j++) {
		if (ch[j] >= 'A' && ch[j] <= 'Z') {
			a++;
		} else if (ch[j] >= 'a' && ch[j] <= 'z') {
			b++;
		} else if (ch[j] >= '0' && ch[j] <= '9') {
			c++;
		}
	}
	printf("%d %d %d", a, b, c);
	return 0;
}