#include <stdio.h>

int sushu(int b) {
	int j, i, flag;
	for (j = 2; j < b; j++) {
		if (b % j == 0) {
			flag = 0;
			break;
		} else
			flag = 1;
	}
	return flag;
}

int main() {
	int a, i, j, h;
	scanf("%d", &a);
	i = a / 2;
	int sushu(int b);
	if (sushu(i) == 1)
		printf("%d %d", i, i);
	else {
		j = i - 1;
		h = 1 + i;
	}
	while (sushu(j) != 1 || sushu(h) != 1) {
		j--;
		h++;
	}
	printf("%d %d", j, h);
	return 0;
}