#include <stdio.h>

int main() {
	int n, i;
	scanf("%d", &n);
	for (i = 1; i < n + 1; i++) {
		if (i % 2 == 0)
			printf("%d %d\n", i, i * i);
	}
	return 0;
}