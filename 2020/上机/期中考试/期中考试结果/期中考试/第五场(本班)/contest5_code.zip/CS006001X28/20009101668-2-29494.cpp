# include <stdio.h>

int main (void) {
	int a, b, c;
	scanf("%d%d%d", &a, &b, &c);
	if (a + b <= c || a + c <= b || b + c <= a)
		printf("no\n");
	else {
		if (a * a + b * b == c * c)
			printf("%d\n", a * b / 2);
		else if (a * a + c * c == b * b)
			printf("%d\n", a * c / 2);
		else if (b * b + c * c == a * a)
			printf("%d\n", b * c / 2);
		else
			printf("normal\n");
	}
	return 0;
}