#include <stdio.h>

int main() {
	int i, a, n;
	scanf("%d", &n);
	for (i = 2; i <= n; i += 2) {
		printf("%d %d\n", i, i * i);
	}
	return 0;
}
