#include <stdio.h>

int main() {
	char d;
	int a = 0, b = 0, c = 0, i;
	for (i = 1;; i++) {
		scanf("%c", &d);
		if (d <= 'Z' && d >= 'A')
			a++;
		else if (d <= 'z' && d >= 'a')
			b++;
		else if (d <= '9' && d >= '0')
			c++;
		else if (d == '!')
			break;
	}
	printf("%d %d %d", a, b, c);
	return 0;
}