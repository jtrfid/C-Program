#include <stdio.h>

int main() {
	int n, flag;
	scanf("%d", &n);
	for (int i = n / 2; i > 0; i--) {
		flag = 1;
		for (int j = 2; j < i; j++) {
			if (i % j == 0) {
				flag = 0;
				break;
			}
		}
		if (flag == 0)
			continue;
		for (int j = 2; j < n - i; j++) {
			if (i % j == 0) {
				flag = 0;
				break;
			}
		}
		if (flag == 0)
			continue;
		printf("%d %d", i, n - i);
		break;
	}
	return 0;
}