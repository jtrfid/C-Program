#include <stdio.h>

int main () {
	int a, b, c, j, i, n, min, t, mina, minb, flag, k, s;
	scanf("%d", &n);
	k = n / 2;
	mina = k;
	minb = k;
	flag = 0;
	for (i = 2; i <= k; i++) {
		for (j = 2; j < i; j++)
			if (i % j == 0 || (n - i) % j == 0)
				flag = 1;

	}
	t = mina - minb;
	s = n - 2 * i;
	if (flag == 0 && s < t) {

		mina = n - i;

		minb = i;
	}

	printf("%d %d", mina, minb);
	return 0;
}