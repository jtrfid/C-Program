#include <stdio.h>

int main() {
	int n, flag, i, j;
	scanf("%d", &n);
	for (i = n / 2; ; i--) {
		flag = 1;
		for (j = 2; j < i; j++) {
			if (i % j == 0)
				flag = 0;
		}
		if (flag == 0)
			continue;
		for (j = 2; j < (n - i); j++) {
			if ((n - i) % j == 0)
				flag = 0;
		}
		if (flag == 0)
			continue;
		printf("%d %d", i, n - i);
		break;
	}
	return 0;
}