# include<stdio.h>
int main() 
{
	char m;int a=0;int b=0;int c=0;
	while(m!='!')
	{
		scanf("%c",&m);
		if(m>='A'&&m<='Z') a++;
		else if(m>='a'&&m<='z') b++;
		else if (m>='0'&&m<='9') c++;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}