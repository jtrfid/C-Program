#include <stdio.h>

int main() {
	char count1 = 0, count2 = 0, count3 = 0;
	while (getchar() != '!') {
		if (getchar() >= 'A' && getchar() <= 'Z')
			count1++;
		else if (getchar() >= 'a' && getchar() <= 'z')
			count2 ++;
		else if (getchar() >= '0' && getchar() <= '9')
			count3 ++;
	}
	if (getchar() == '!')
		printf("%d %d %d", count1, count2, count3);
	return 0;
}