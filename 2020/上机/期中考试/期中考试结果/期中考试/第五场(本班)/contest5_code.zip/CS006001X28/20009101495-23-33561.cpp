#include <stdio.h>

int main() {
	int a, i, f1 = 1, f2 = 1, m;
	scanf("%d", &a);
	for (m = a / 2; m > 0; m--) {
		f1 = 1;
		f2 = 1;
		for (i = 2; i < m - 1; i++) {
			if (m % i == 0)
				f1 = 0;


		}
		if (f1 == 1) {
			for (i = 2; i < a - m - 1; i++) {
				if ((a - m) % i == 0)
					f2 = 0;
				break;

			}
			if ( f2 == 1)
				break;
		}
	}
	printf("%d %d", m, a - m);
	return 0;
}