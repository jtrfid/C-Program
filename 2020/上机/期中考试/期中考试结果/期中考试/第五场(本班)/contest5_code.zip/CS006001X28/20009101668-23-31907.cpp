# include <stdio.h>

int fun(int i) {
	int n, flag = 1;
	for (n = 2; n < i; n++) {
		if (i % n == 0) {
			flag = 0;
			break;
		} else
			continue;
	}
	return flag;
}

int main (void) {
	int fun(int i);
	int a, i;
	scanf("%d", &a);
	for (i = a / 2; i <= a; i++) {
		if (fun(i) == 0)
			continue;
		if (fun(i) == 1) {
			if (fun(a - i) == 0)
				continue;
			if (fun(a - i) == 1)
				break;
		}
	}
	printf("%d %d\n", a - i, i);
	return 0;
}