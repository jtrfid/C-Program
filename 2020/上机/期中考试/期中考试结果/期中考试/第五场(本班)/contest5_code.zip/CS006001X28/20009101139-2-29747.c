#include <stdio.h>

int main() {
	int flag = 0, a[3], temp, i;
	int sum;
	scanf("%d%d%d", &a[0], &a[1], &a[2]);
	for (i = 0; i < 2; i++) {
		if (a[i] > a[i + 1]) {
			temp = a[i];
			a[i] = a[i + 1];
			a[i + 1] = temp;

		}
	}
	if (a[0]*a[0] + a[1]*a[1] == a[2] * a[2])
		flag = 1;
	if ((a[0] + a[1]) > a[2]) {
		if (flag == 1) {
			sum = a[0] * a[1] / 2.0;
			printf("%d", sum);
		} else
			printf("normal");
	} else
		printf("no");
	return 0;
}