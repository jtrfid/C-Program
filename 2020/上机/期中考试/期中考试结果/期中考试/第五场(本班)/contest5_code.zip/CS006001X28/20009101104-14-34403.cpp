#include <stdio.h>

int main() {
	char a[1000];
	char x;
	int n;
	int cnt = 0;
	int i = 0, j = 0, k = 0;
	for (n = 0; x != '!'; n++) {
		scanf("%c", x);
		a[n] = x;
		cnt++;
	}

	for (n = 0; n < cnt; n++) {
		if (a[cnt - 1] >= '0' && a[cnt - 1] <= '9') {
			i++;
		} else if (a[cnt - 1] <= 'Z' && a[cnt - 1] >= 'A') {
			j++;
		} else if (a[cnt - 1] <= 'z' && a[cnt - 1] >= 'a') {
			k++;
		}
	}
	printf("%d %d %d", j, k, i);
	return 0;
}