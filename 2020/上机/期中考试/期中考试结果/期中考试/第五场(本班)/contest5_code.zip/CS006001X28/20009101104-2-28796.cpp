#include <stdio.h>

int main() {
	int a, b, c;
	int s = (a + b + c) / 2;
	scanf("%d %d %d", &a, &b, &c);
	if (a + b > c && a + c > b && c + b > a) {
		if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a) {
			if (a > b && a > c) {
				printf("%d", b * c / 2);
			} else if (b > c && b > a) {
				printf("%d", a * c / 2);
			} else if (c > a && c > b) {
				printf("%d", a * b / 2);
			}
		} else {
			printf("normal");
		}
	} else {
		printf("no");
	}
	return 0;
}