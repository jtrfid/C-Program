#include <stdio.h>

int main() {
	char zf;
	int count1 = 0, count2 = 0, count3 = 0;
	scanf("%c", &zf);
	while (zf != '!') {
		if (zf >= 'A' && zf <= 'Z')
			count1++;
		else if (zf >= 'a' && zf <= 'z')
			count2 ++;
		else if (zf >= '0' && zf <= '9')
			count3 ++;
		scanf("%c", &zf);
	}
	if (zf == '!')
		printf("%d %d %d", count1, count2, count3);
	return 0;
}