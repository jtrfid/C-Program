#include <stdio.h>

int gan(int a) {
	int xo = 0;
	if (a == 2) {
		xo = 1;
	} else {
		for (int i = 2; i < a; i++) {
			if (a % i == 0) {
				xo = 0;
				break;
			} else {
				xo = 1;
			}
		}
	}
	return xo;
}

int main() {
	int n;
	scanf("%d,&n");
	if (n % 2 == 0 && n != 2) {
		for (int i = n / 2; i >= 2; i--) {
			if (gan(i) == 1 && gan(n - i) == 1) {
				printf("%d %d", i, n - i);
				break;
			}
		}
	}
	return 0;
}