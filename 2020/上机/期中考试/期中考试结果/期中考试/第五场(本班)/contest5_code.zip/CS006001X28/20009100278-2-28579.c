#include <stdio.h>

int main() {
	int a, b, c, d;
	scanf("%d%d%d", &a, &b, &c);
	if (a > c) {
		d = a;
		a = c;
		c = d;
	}
	if (a > b) {
		d = a;
		a = b;
		b = d;
	}
	if (b > c) {
		d = b;
		b = c;
		c = d;
	}
	if (a + b <= c)
		printf("no");
	else {
		if (a * a + b * b == c * c)
			printf("%d", a * b / 2);
		else
			printf("normal");
	}
	return 0;
}
//(int)(a/b);
