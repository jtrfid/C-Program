#include <stdio.h>

int main() {
	int n, i, j, flag, k;

	scanf("%d", &n);

	for (i = n / 2; i > 0; i++) {
		flag = 1;
		for (j = 2; j < i; j++) {
			if (i % j == 0) {
				flag = 0;
				break;
			}
		}
		if (flag == 1) {

			for (k = i; k < n; k++) {
				flag = 1;
				for (j = 2; j < k; j++) {
					if (k % j == 0) {
						flag = 0;
						break;
					}
				}

				if (flag == 1 && k + i == n) {
					printf("%d %d", i, k);
				}

			}
		}
	}

	return 0;
}