#include <stdio.h>

int main() {
	int a, b, c;
	scanf("%d%d%d", &a, &b, &c);
	if (a + b <= c)
		printf("no");
	else if (a * a + b * b == c * c)
		printf("%.0f", 0.5 * a * b);
	else if (a * a + c * c == b * b)
		printf("%.0f", 0.5 * a * c);
	else if (c * c + b * b == a * a)
		printf("%.0f", 0.5 * c * b);
	else
		printf("normal");
	return 0;
}