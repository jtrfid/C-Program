#include <stdio.h>

int main() {
	int da = 0, xiao = 0, shu = 0;
	char x;
	int i;

	scanf("%c", &x);
	i = x;

	while (i != 33) {
		if (i >= 97 && i <= 122) {
			xiao ++;
		} else if (i >= 65 && i <= 90) {
			da ++;
		} else if (i >= 48 && i <= 57) {
			shu ++;
		}



		scanf("%c", &x);
		i = x;
	}

	printf("%d %d %d", da, xiao, shu);
	return 0;
}