#include <stdio.h>

int main() {
	int a, b, c, q;
	scanf("%d%d%d", &a, &b, &c);
	if ((a + b) > c && (a + c) > b && (b + c) > a) {
		if (a * a + b * b != c * c || a * a + c * c != b * b || b * b + c * c != a * a) {
			if (a < b && c < b)
				q = a * c * 0.5;
			else if (a < c && b < c)
				q = a * b * 0.5;
			else
				q = b * c * 0.5;
			printf("%d", q);
		} else
			printf("normal");
	} else
		printf("no");
	return 0;
}