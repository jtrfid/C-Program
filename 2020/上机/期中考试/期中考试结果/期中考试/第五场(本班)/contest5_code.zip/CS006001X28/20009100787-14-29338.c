#include <stdio.h>

int main(void) {
	char n;
	int a = 0, b = 0, c = 0;
	while (1) {
		scanf("%c", &n);
		if (n == '!')
			break;
		else if (n >= 'A' && n <= 'Z')
			a++;
		else if (n >= 'a' && n <= 'z')
			b++;
		else if (n >= '0' && n <= '9')
			c++;
	}
	printf("%d %d %d", a, b, c);
	return 0;
}