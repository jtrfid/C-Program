#include <stdio.h>

int main() {

	int d = 0, x = 0, s = 0;
	char c = '?';
	for (; c != '!'; ) {
		scanf("%c", &c);
		if (c >= 'a' && c <= 'z')
			x = x + 1;
		else if (c >= 'A' && c <= 'Z')
			d = d + 1;
		else if (c >= '0' && c <= '9')
			s = s + 1;


	}
	printf("%d %d %d", d, x, s);








	return 0;
}
