#include <stdio.h>

int main() {
	int a[1000];
	char x;
	int n;
	int i = 0, j = 0, k = 0;
	for (n = 0; x != '!'; n++) {
		scanf("%c", x);
		a[n] = x;
		if (a[n] >= 0 && a[n] <= 9) {
			i++;
		} else if (a[n] <= 'Z' && a[n] >= 'A') {
			j++;
		} else if (a[n] <= 'z' && a[n] >= 'a') {
			k++;
		}
	}
	printf("%d %d %d", j, k, i);

	return 0;
}