#include <stdio.h>

int main () {
	char k;
	int i, n, a, A, num;
	n = 0;
	a = 0;
	A = 0;
	num = 0;
	for (i = 0; i <= 9999; i++) {
		scanf ("%c", &k);
		if (k == '!')
			break;
		else if (k >= 'a' && k <= 'z')
			a = a + 1;
		else if (k >= 'A' && k <= 'Z')
			A = A + 1;
		else if (k >= '0' && k <= '9')
			num = num + 1;

	}

	printf("%d %d %d", A, a, num);
	return 0;

}



