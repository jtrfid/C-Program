# include <stdio.h>
# include <math.h>
int main() 
{
	int m,i,j,flag,flag2,a,b,t,s,min=1000;
	scanf("%d",&m);
	for(i=2;i<m;i++)
	{
		flag=1;
		for(j=2;j<i;j++)
		{
			if(i%j==0) {flag=0;break;}
		}
		if(flag) 
		{
			a=i;b=m-a;
			flag2=1;
			for(j=2;j<b;j++)
			{
				if(b%j==0) {flag2=0;break;}
			}		
			if(flag2!=0&&(a-b)<min)
			{
				min=fabs(a-b);t=a;s=b;
			}
		}
		else continue;
	}	
	printf("%d %d",t,s);
	return 0;
}