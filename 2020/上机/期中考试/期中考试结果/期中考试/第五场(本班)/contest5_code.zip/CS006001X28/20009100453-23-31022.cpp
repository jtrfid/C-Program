#include <stdio.h>

int main() {
	int a, c, m, n, i, j;
	scanf("%d", &m);
	a = m / 2;
	for (i = a; i <= m; i++) {
		n = 1;
		c = 1;
		for (j = 2; j < i; j++) {
			if (i % j == 0) {
				n = 0;
			}
		}
		for (j = 2; j < m - i; j++) {
			if ((m - i) % j == 0) {
				c = 0;
			}
		}
		if (n == 1 && c == 1) {
			printf("%d %d", m - i, i);
			break;
		}
	}
	return 0;
}