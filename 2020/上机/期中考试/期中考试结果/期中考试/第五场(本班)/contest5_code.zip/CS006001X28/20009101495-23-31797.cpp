#include <stdio.h>

int f(int n) {
	int i, flag = 1;
	for (i = 2; i <= n / 2; i++)
		if (n % i == 0)
			flag = 0;
	if (flag == 1)
		return flag;
}

int main() {
	int a, i;
	scanf("%d", &a);
	for (i = a / 2; i > 0; i--)
		if (f(i) && f(a - i))
			break;
	printf("%d %d", i, a - i);
	return 0;

}

