#include <stdio.h>

int main() {
	int i, d = 0, x = 0, n = 0;
	char a[100];
	scanf("%s", &a[100]);
	printf("%s", a[100]);
	for (i = 0; i < 100; i++) {
		if (a[i] == '!')
			break;
		if (a[i] <= 'Z' && a[i] >= 'A')
			d += 1;
		if (a[i] <= 'z' && a[i] >= 'a')
			x += 1;
		if (a[i] <= '0' && a[i] >= '1')
			n += 1;
	}
	printf("%d %d %d", d, x, n);
	return 0;
}