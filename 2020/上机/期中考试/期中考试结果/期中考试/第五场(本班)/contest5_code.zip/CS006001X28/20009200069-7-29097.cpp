#include <stdio.h>

int main() {
	int n, i, a, b;
	scanf("%d", &n);
	for (i = 2; i <= n; i++) {
		if (i % 2 == 0) {
			a = i;
			b = i * i;
			printf("%d %d\n", a, b);
		} else
			continue;
	}












	return 0;
}