#include <stdio.h>

int main() {
	int i, n, j, flag, m;
	flag = 1;
	scanf("%d", &n);
	for (i = 2; i <= n / 2; i++) {
		for (j = 2; j <= i / 2; j++) {
			if (i % j == 0 || (n - i) % j == 0)
				flag = 0;
		}
		if (flag == 1)
			m = i;

	}
	printf("%d %d", m, n - m);

	return 0;
}