#include <stdio.h>

int main() {


	int n, i, j, c, t, x = 0, y = 0;
	scanf("%d", &n);
	int m(int n);
	for (i = 2, c = 10000; i <= n / 2; i++) {
		if (m(i) == 1) {
			j = n - i;
			if (m(j) == 1) {
				t = j - i;
				if (t < c) {
					c = t;
					x = i;
					y = j;

				} else
					continue;
			} else
				continue;
		}

	}
	printf("%d %d", x, y);
	return 0;
}

int m(int n) {
	int i, t;
	for (i = 2; i < n; i++) {
		if (n % i == 0) {
			t = 0;
			break;
		} else if (i == n - 1 && n % (n - 1) != 0)
			t = 1;
		else if (n % i != 0)
			continue;
	}






	return t;
}