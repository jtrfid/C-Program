#include <stdio.h>

int main() {
	int a, i, f1 = 1, f2 = 1, m, n;
	scanf("%d", &a);
	for (m = a / 2; m > 0; m--) {
		f1 = 1;
		f2 = 1;
		n = a - m;
		for (i = 2; i < m - 1; i++) {
			if (m % i == 0)
				f1 = 0;


		}
		if (f1 == 1) {
			for (i = 2; i < n - 1; i++) {
				if (n % i == 0)
					f2 = 0;


			}
			if ( f2 == 1)
				break;
		}
	}
	printf("%d %d", m, a - m);
	return 0;
}