#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
	int i, j, flag, count = 0;
	int an[1000] = {0};
	for (i = 1; i < 1000; i++) {
		flag = 1;
		for (j = 2; j < i / 2; j++) {
			if (i % j == 0) {
				flag = 0;
				break;
			}
		}
		if (flag == 1) {
			an[count] = i;
			count++;
		}
	}
//	for (i = 0; i <= count; i++)
//		printf("%d\n", an[i]);
	int a, min = 1000, temp1, temp2;
	scanf("%d", &a);
	for (i = 0; i < count; i++) {
		for (j = i; j < count; j++) {
			if ((an[i] + an[j]) == a) {
				if ((an[j] - an[i]) < min) {
					min = an[j] - an[i];
					temp1 = i;
					temp2 = j;
				}
			}
		}
	}
	printf("%d %d", an[temp1], an[temp2]);
	return 0;
}