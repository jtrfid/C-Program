#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, sum = 0;
	for (i = 1; i <= n; i++) {
		sum = 0;
		if (i % 2 == 0) {
			sum += i * i;
			printf("%d %d\n", i, sum);
		}
	}


	return 0;
}