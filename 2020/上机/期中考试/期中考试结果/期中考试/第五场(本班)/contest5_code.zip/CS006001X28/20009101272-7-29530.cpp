#include <stdio.h>

int main() {
	int n, m;
	scanf("%d", &n);
	for (m; m <= n; m++) {
		if (m % 2 == 0)
			printf("%d %d\n", m, m * m);
	}
	return 0;
}