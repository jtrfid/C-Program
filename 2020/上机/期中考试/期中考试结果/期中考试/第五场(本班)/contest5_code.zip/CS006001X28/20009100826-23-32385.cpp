#include <stdio.h>

int main() {
	int n, m, a, b, i, j;
	char flag1, flag2, flag;
	scanf("%d", &n);
	m = n / 2;
	i = 0;
	flag1 = '1';
	flag2 = '1';
	flag = '0';
	while (flag != '1') {
		flag1 = '1';
		flag2 = '1';
		a = m - i;
		b = m + i;
		for (j = 2; j < a; j++) {
			if (a % j == 0) {
				flag1 = '0';
			}
		}
		for (j = 2; j < b; j++) {
			if (b % j == 0) {
				flag2 = '0';
			}
		}
		if (flag1 == '1' && flag2 == '1') {
			flag = '1';
		}
		i = i + 1;
	}
	printf("%d %d", a, b);
	return 0;
}