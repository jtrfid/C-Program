#include <stdio.h>

int main() {
	char n;
	int m;
	int a, b, c;
	a = 0;
	b = 0;
	c = 0;
	scanf("%c", &n);
	printf("%d\n", '1');
	while (n != '!') {
		scanf("%c", &n);
		if (n < 60 )
			c++;
		else if (n > 60 && n < 91 )
			b++;
		else if (n > 123)
			a++;
	}



	printf("%d %d %d", c, a, b);
	return 0;
}