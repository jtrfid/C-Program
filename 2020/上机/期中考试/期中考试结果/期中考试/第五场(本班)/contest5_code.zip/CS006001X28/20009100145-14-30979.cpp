#include <stdio.h>

int main() {
	int x = 0, y = 0, z = 0;
	char ch;
	for (; ch != '!';) {
		scanf("%c", &ch);
		if ('A' <= ch && ch <= 'Z') {
			x = x + 1;
		} else if ('a' <= ch && ch <= 'z') {
			y = y + 1;
		} else if ('0' <= ch && ch <= '9') {
			z = z + 1;
		}
	}
	printf("%d %d %d", x, y, z);
	return 0;
}