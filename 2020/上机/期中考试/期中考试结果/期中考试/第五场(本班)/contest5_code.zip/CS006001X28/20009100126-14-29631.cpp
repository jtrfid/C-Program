#include <stdio.h>
#include <math.h>

int main() {
	char n;
	int d = 0, x = 0, s = 0;
	while (n != '!') {
		scanf("%c", &n);
		if (n >= 'A' && n <= 'Z')
			d++;
		else if (n >= 'a' && n <= 'z')
			x++;
		else if (n >= '0' && n <= '9')
			s++;
	}
	printf("%d %d %d", d, x, s);
	return 0;
}