#include <stdio.h>

int main() {

	int sum1 = 0, sum2 = 0, sum3 = 0, i;
	char ch;
	for (i = 1; ch != '!'; i++) {
		scanf("%c", &ch);
		if (ch >= 'A' && ch <= 'Z')
			sum1++;
		else if (ch >= 'a' && ch <= 'z')
			sum2++;
		else if (ch >= '0' && ch <= '9')
			sum3++;
		else
			continue;
	}
	printf("%d %d %d", sum1, sum2, sum3);


	return 0;
}