#include <stdio.h>

int main() {
	int a, i, x, j, p, q, b, flag1 = 1, flag2 = 1;
	scanf("%d", &a);
	x = 0.5 * a;
	for (j = 0; j <= x; j++)\
	{
		p = x + j;
		q = x - j;
		for (b = 2; b <= p - 1; b++) {
			if (p % b == 0)
				flag1 = 0;
		}
		for (i = 2; i <= q - 1; b++) {
			if (q % i == 0) {
				flag2 = 0;
			}
		}
		if (flag1 == 1 && flag2 == 1) {
			printf("%d %d", q, p);
			break;
		}
	}

	return 0;
}