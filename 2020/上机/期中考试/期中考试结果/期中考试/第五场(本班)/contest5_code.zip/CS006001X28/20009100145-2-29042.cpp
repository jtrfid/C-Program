#include <stdio.h>

int main() {
	int x, y, z;
	float s;
	scanf("%d %d %d", &x, &y, &z);
	if (x + y <= z || x + z <= y || y + z <= x) {
		printf("no");
	} else if (x * x + y * y == z * z) {
		s = 0.5 * x * y;
		printf("%f", s);
	} else if (z * z + y * y == x * x) {
		s = 0.5 * z * y;
		printf("%f", s);
	} else if (z * z + x * x == y * y) {
		s = 0.5 * z * x;
		printf("%f", s);
	} else
		printf("normal");
	return 0;
}