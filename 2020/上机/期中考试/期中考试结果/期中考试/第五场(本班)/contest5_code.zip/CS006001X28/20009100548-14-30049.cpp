#include <stdio.h>

int main() {
	int i = 0, b[3] = {0};
	char a[1000];
	do {
		scanf("%c", &a[i]);
		i++;
	} while (a[i - 1] != '!');
	for (int j = 0; j < i - 1; j++ ) {
		if (a[j] >= 65 && a[j] <= 91) {
			b[0]++;
		} else if (a[j] >= 97 && a[j] <= 122) {
			b[1]++;
		} else if (a[j] >= 48 && a[j] <= 57) {
			b[2]++;
		}
	}
	printf("%d %d %d", b[0], b[1], b[2]);
	return 0;
}