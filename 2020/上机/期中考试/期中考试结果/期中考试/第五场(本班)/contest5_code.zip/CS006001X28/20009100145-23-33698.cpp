#include <stdio.h>

int main() {
	int a, x, m, n, i, flag1 = 0, flag2 = 0, p, q;
	scanf("%d", &a);
	x = 0.5 * a;
	for (i = 0; i <= x; i++) {
		p = x - i;
		q = x + i;
		for (m = 2; m <= p - 1; m++) {
			if (p % m == 0) {
				flag1 = 1;
				break;
			}
		}
		for (n = 2; n <= q - 1; n++) {
			if (q % n == 0) {
				flag2 = 1;
				break;
			}
		}
		if (flag1 == 0 && flag2 == 0) {
			printf("%d %d", p, q);
		}
	}
	return 0;
}