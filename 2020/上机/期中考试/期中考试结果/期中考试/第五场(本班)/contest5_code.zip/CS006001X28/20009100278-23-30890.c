#include <stdio.h>

int main() {
	int i, j, k, a, b, flag = 0;
	scanf("%d", &a);
	b = a / 2;
	for (i = b; i < a - 1; i++) {
		for (j = 2; j < i; j++)
			if (i % j == 0) {
				flag = 1;
			}
		flag = 0;
		k = a - i;
		for (j = 2; j < k; j++)
			if (k % j == 0) {
				flag = 1;
			}
		if (flag == 0) {
			printf("%d %d", k, i);
			break;
		}
		flag = 0;
	}
	return 0;
}