#include <stdio.h>

int main() {
	int a, b, c;
	int sum;
	scanf("%d%d%d", &a, &b, &c);
	if ((a + b) > c && (b + c) > a && (c + a) > b) {
		if (a * a + b * b == c * c) {
			sum = 0.5 * a * b;
			printf("%d", sum);
		} else if (a * a + c * c == b * b) {
			sum = 0.5 * a * c;
			printf("%d", sum);
		} else if (b * b + c * c == a * a) {
			sum = 0.5 * b * c;
			printf("%d", sum);
		} else
			printf("normal");

	} else
		printf("no");


	return 0;
}