#include <stdio.h>

int main() {
	int a = 0, b = 0, c = 0, i = 0;
	char s[10000];
	scanf("%s", &s);
	for (i = 0; i < 10000; i++) {
		if (s[i] <= 'Z' && s[i] >= 'A')
			a++;
		if (s[i] <= 'z' && s[i] >= 'a')
			b++;
		if (s[i] <= '9' && s[i] >= '0')
			c++;
		if (s[i] == '!')
			break;
	}

	printf("%d %d %d", a, b, c);
	return 0;
}