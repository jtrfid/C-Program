#include <stdio.h>

int main() {
	int a, b, c, m, t = 0, x, y;
	scanf("%d%d%d", &a, &b, &c);
	if (a + b > c && a + c > b && b + c > a) {
		if (a > b && a > c) {
			t = a;
			x = b;
			y = c;
		} else if (b > a && b > c) {
			t = b;
			x = a;
			y = c;
		} else if (c > a && c > b) {
			t = c;
			x = a;
			y = b;
		}
		if (x * x + y * y == t * t)
			printf("%d", x * y);
		else
			printf("normal");
	} else
		printf("no");









	return 0;
}