#include <stdio.h>

int main() {
	int a, b, c, s;
	scanf("%d%d%d", &a, &b, & c);
	if (a + b > c && a + c > b && b + c > a) {
		if (a * a == b * b + c * c) {
			s = b * c / 2;
			printf("%d", s);
		}
		if (b * b == c * c + a * a) {
			s = a * c / 2;
			printf("%d", s);
		}
		if (c * c == b * b + a * a) {
			s = a * b / 2;
			printf("%d", s);
		} else
			printf("normal");
	} else
		printf("no");
	return 0;
}