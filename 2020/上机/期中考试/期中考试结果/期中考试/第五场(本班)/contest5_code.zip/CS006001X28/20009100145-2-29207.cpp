#include <stdio.h>

int main() {
	int x, y, z;
	int s;
	scanf("%d %d %d", &x, &y, &z);
	if (x + y <= z || x + z <= y || y + z <= x) {
		printf("no");
	} else if (x * x + y * y == z * z) {
		s = 0.5 * x * y;
		printf("%d", s);
	} else if (z * z + y * y == x * x) {
		s = 0.5 * z * y;
		printf("%d", s);
	} else if (z * z + x * x == y * y) {
		s = 0.5 * z * x;
		printf("%d", s);
	} else
		printf("normal");
	return 0;
}