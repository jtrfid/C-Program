#include <stdio.h>
#include <math.h>

int main() {
	int a, b, c, m, t, A, B, M;
	int s;
	scanf("%d%d%d", &a, &b, &c);
	m = a;
	if (b > m)
		m = b;
	if (c > m)
		m = c;
	if (m == a)
		a = c;
	if (m == b)
		b = c;
	A = pow(a, 2);
	B = pow(b, 2);
	M = pow(m, 2);
	if (M == A + B) {
		s = (int)(a * b / 2);
		printf("%f", s);
	} else if (m >= a + b)
		printf("no");
	else
		printf("normal");
	return 0;
}