#include <stdio.h>

int main() {
	int a, b, c, d, e, f, g, h, i, j;
	d = 1;
	e = 1;
	f = 1;
	g = 1;
	h = 1;
	i = 1;
	scanf("%d%d%d", &a, &b, &c);
	if (a + b <= c)
		d = 0;
	if (b + c <= a)
		e = 0;
	if (c + a <= b)
		f = 0;
	if (d * e * f == 0) {
		printf("no");
		return 0;
	}

	if (a ^ 2 + b ^ 2 == c ^ 2)
		printf("%d", a * b / 2.0);
	g = 0;
	if (c ^ 2 + b ^ 2 == a ^ 2)
		printf("%d", c * b / 2.0);
	h = 0;
	if (a ^ 2 + c ^ 2 == b ^ 2)
		printf("%d", a * b / 2.0);
	i = 0;
	if (g * h * i == 0)
		printf("normal");


}