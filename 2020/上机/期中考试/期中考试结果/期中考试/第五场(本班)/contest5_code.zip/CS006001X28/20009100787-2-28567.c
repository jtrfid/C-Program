#include <stdio.h>

int main(void) {
	int a, b, c;
	scanf("%d %d %d", &a, &b, &c);
	if (a + b <= c || b + c <= a || a + c <= b)
		printf("no");
	else if (a * a + b * b == c * c)
		printf("%d", a * b / 2);
	else if (a * a + c * c == b * b)
		printf("%d", a * c / 2);
	else if (c * c + b * b == a * a)
		printf("%d", b * c / 2);
	else
		printf("normal");
	return 0;
}