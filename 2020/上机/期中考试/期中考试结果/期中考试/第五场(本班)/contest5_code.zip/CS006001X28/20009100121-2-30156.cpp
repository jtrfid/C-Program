#include <stdio.h>

int main() {
	int a, b, c;
	int x, y, z;

	scanf("%d%d%d", &x, &y, &z);

	if (x > y && y > z) {
		a = z;
		b = y;
		c = x;
	} else if (x > z && z > y) {
		a = y;
		b = z;
		c = x;
	} else if (y > z && z > x) {
		a = x;
		b = z;
		c = y;
	} else if (y > x && x > z) {
		a = z;
		b = x;
		c = y;
	} else if (z > x && x > y) {
		a = y;
		b = x;
		c = z;
	} else if (z > y && y > x) {
		a = x;
		b = y;
		c = z;
	}






	if (a + b > c) {
		if (a * a + b * b == c * c) {
			printf("%d", a * b / 2);
		} else {
			printf("normal");
		}
	} else {
		printf("no");
	}


	return 0;
}