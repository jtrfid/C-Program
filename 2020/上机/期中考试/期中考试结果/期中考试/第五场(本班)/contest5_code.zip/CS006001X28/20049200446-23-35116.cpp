#include <stdio.h>

int main() {
	int n, i, j, a, b;
	int x, y;
	scanf("%d", &n);
	n = n * 0.5;
	x = n;
	y = n;
	for (i = 0; i < n; i = i + 2) {
		x = x - i;
		y = y + i;
		for (j = 2; j < x; j++) {
			if (x % j == 0) {
				a++;
			}
		}
		if (a == 0) {
			for (j = 2; j < y; j++) {
				if (y % j == 0) {
					b++;
				}
			}

			if (b == 0) {

			}
		}
		printf("%d %d", x, y);
		return 0;
	}


	return 0;
}