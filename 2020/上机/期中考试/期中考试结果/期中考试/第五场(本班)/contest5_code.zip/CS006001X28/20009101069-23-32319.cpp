#include <stdio.h>

int fact(int a) {
	int i, count;
	for (i = 0, count = 0; i <= a; i++) {
		if (a % i == 0)
			count++;
	}
	if (count == 0)
		return 0;
	else
		return 1;
}

int main() {
	int a, b, N, i, m = 10000, t, p, q;
	scanf("%d", &N);
	for (i = 2; i <= N; i++) {
		if (fact(i) == 0 && fact(N - i) == 0) {
			a = i;
			b = N - i;
			if (a > b) {
				t = a;
				a = b;
				b = t;

			}
			if (b - a < m) {
				m = b - a;
				p = a;
				q = b;
			}
		}
	}
	printf("%d %d", p, q);
	return 0;

}