#include <stdio.h>

int main () {
	int a, b, c, t;
	scanf ("%d%d%d", &a, &b, &c);
	if (a > b) {
		t = a;
		a = b;
		b = t;
	}
	if (b > c) {
		t = b;
		b = c;
		c = t;
	}
	if (a + b <= c)
		printf ("no");
	else if (a * a + b * b == c * c)
		printf("%d", a * b / 2);
	else
		printf ("normal");



	return 0;
}