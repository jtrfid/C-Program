#include <stdio.h>

int main() {
	int i, t, n1 = 0, n2 = 0, n3 = 0;
	char a[10000];
	scanf("%s", a);
	for (i = 0; a[i] != '!'; i++) {
		t = a[i] + 0;
		if (t >= 65 && t <= 90)
			n1 = n1 + 1;
		else if (t >= 97 && t <= 122)
			n2 = n2 + 1;
		else if (t >= 48 && t <= 57)
			n3 = n3 + 1;
	}
	printf("%d %d %d", n1, n2, n3);
	return 0;
}