#include <stdio.h>

int main() {
	int a, b, N, i, j, k, count1, count2, m = 10000, t, p = 0, q = 0;
	scanf("%d", &N);
	for (i = 3; i <= N; i++) {
		for (j = 2, count1 = 0; j < i; j++) {
			if (i % j == 0)
				count1++;
			if (i == 2)
				count1 == 0;
		}
		for (k = i - 1, count2 = 0; k >= 2; k--) {
			if (i % k == 0)
				count2++;
		}
		if (count1 == 0 && count2 == 0) {
			a = i;
			b = N - i;
			if (a > b) {
				t = a;
				a = b;
				b = t;

			}
			if (b - a < m) {
				m = b - a;
				p = a;
				q = b;
			}
		}

	}
	printf ("%d %d", p, q);
	return 0;
}