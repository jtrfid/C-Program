#include <stdio.h>

int main() {
	int a, b, c, i, j;
	char arr[100];
	a = b = c = 0;
	i = -1;
	do {
		i++;
		scanf("%c", &arr[i]);
	} while (arr[i] != '!');
	j = 0;
	while (arr[j] != '!') {
		if (arr[j] >= 'A' && arr[j] <= 'Z') {
			a++;
		} else if (arr[j] >= 'a' && arr[j] <= 'z') {
			b++;
		} else {
			c++;
		}
		j++;
	}
	printf("%d %d %d", a, b, c);
}