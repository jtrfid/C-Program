# include <stdio.h>
# include <string.h>

int main (void) {
	char str[1000];
	int a = 0, b = 0, c = 0, i;
	gets(str);
	for (i = 0; ; i++) {
		if (str[i] >= 65 && str[i] <= 90)
			a++;
		if (str[i] >= 97 && str[i] <= 122)
			b++;
		if (str[i] >= 48 && str[i] <= 57)
			c++;
		if (str[i] == 33)
			break;
	}
	printf("%d %d %d\n", a, b, c);
	return 0;
}