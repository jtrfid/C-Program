#include <stdio.h>

int main() {
	char c;
	int i, num1 = 0, num2 = 0, num3 = 0;
	for (i = 0;; i++) {
		scanf("%c", &c);
		if (c > 'A' - 1 && c < 'Z' + 1)
			num1++;
		else if (c > 'a' - 1 && c < 'z' + 1)
			num2++;
		else if (c > '0' - 1 && c < '9' + 1)
			num3++;
		if (c == '!')
			break;
	}
	printf("%d %d %d", num1, num2, num3);
	return 0;
}