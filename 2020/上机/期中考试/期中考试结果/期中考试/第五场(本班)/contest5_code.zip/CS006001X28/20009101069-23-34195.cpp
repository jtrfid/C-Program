#include <stdio.h>

int main() {
	int a, b, i, max, min, sum = 0, j = 1, x;
	scanf("%d%d", &a, &b);
	{
		if (a > b) {
			max = a;
			min = b;
		} else {
			max = b;
			min = a;
		}
	}
	{
		for (i = min; i <= max; i++) {
			for (x = i; x >= 1; x/10) {
				sum = sum + x % 10;
				j = j * (x % 10);
			}

			if (sum == j) {
				sum = 0;
				j = 1;
				printf("%d ", i);

			}
		}
	}

	return 0;
}
