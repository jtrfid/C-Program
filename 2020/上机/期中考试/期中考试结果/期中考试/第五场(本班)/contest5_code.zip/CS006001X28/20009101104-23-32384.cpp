#include <stdio.h>

int ip(int a) {
	int is = 0;
	if (a == 2) {
		is = 1;
	} else {

		for (int i = 2; i < a; i++) {
			if (a % i == 0) {
				is = 0;
				break;
			} else {
				is = 1;
			}
		}
	}
	return is;
}

int main() {
	int n;
	scanf("%d", &n);
	if (n % 2 == 0 && n != 2) {
		for (int i = n / 2; i >=  2; i--) {
			if (ip(i) == 1 && ip(n - i) == 1) {
				printf("%d %d", i, n - i);
				break;
			}
		}
	}
	return 0;
}