#include <stdio.h>
#include <math.h>

int main() {
	int n, k, t, T, i;
	scanf("%d", &n);
	k = n / 2;
	for (i = 1; i <= k; i++) {
		t = 2 * i;
		T = pow(t, 2);
		printf("%d %d\n", t, T);
	}
	return 0;
}