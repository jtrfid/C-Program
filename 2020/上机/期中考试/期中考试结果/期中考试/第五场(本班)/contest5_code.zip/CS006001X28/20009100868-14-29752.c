#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
	char str;
	int num1 = 0, num2 = 0, num3 = 0;
	while (scanf("%c", &str)) {
		if (isupper(str))
			num1++;
		if (islower(str))
			num2++;
		if (isdigit(str))
			num3++;
		if (str == '!')
			break;
	}
	printf("%d %d %d", num1, num2, num3);
	return 0;
}