#include <stdio.h>

int main() {
	int i, n, m;
	scanf("%d", &n);
	for (i = 2; i <= n; i += 2) {
		m = i * i;
		printf("%d %d\n", i, m);
	}
	return 0;

}