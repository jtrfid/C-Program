#include <stdio.h>

int main() {
	int count = 0, count_1 = 0, count_2 = 0;
	char a = '?';
	while (a != '!') {
		a = getchar();
		if (a >= 'A' && a <= 'Z')
			count++;
		if (a >= 'a' && a <= 'z')
			count_1++;
		if (a >= '0' && a <= '9')
			count_2++;
	}
	printf("%d %d %d", count, count_1, count_2);
	return 0;
}