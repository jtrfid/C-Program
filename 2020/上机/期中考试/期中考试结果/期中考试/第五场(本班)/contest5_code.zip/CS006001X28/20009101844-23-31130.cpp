#include <stdio.h>
#include <math.h>

int main() {
	int a, flag, b, c, d;
	scanf("%d", &a);
	int min = a;
	for (int i = a; i > 1; i--) {
		flag = 0;
		for (int j = 2; j < i; j++) {
			if (i % j == 0) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			d = abs(2 * i - a);
			if (d < min) {
				b = i;
				c = a - i;
				min = d;
			}
		}
	}
	printf("%d %d", b, c);
	return 0;
}