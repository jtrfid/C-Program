#include <stdio.h>

int main() {
	int n1 = 0, n2 = 0, n3 = 0, i;
	char ch;
	for (i = 1; ; i++) {
		scanf("%c", &ch);
		if (ch >= 'A' && ch <= 'Z') {
			n1++;
			continue;
		}
		if (ch >= 'a' && ch <= 'z')	{
			n2++;
			continue;
		}
		if (ch >= '0' && ch <= '9')	{
			n3++;
			continue;
		}
		if (ch = '!')
			break;

	}

	printf("%d %d %d", n1, n2, n3);













	return 0;
}