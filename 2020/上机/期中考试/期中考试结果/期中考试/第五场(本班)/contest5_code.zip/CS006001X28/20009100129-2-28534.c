#include <stdio.h>

int main() {
	int a, b, c, temp;
	scanf("%d %d %d", &a, &b, &c);
	if (c < a) {
		temp = a;
		a = c;
		c = temp;
	}
	if (c < b) {
		temp = b;
		b = c;
		c = temp;
	}
	if (a + b > c) {
		if (a * a + b * b == c * c) {
			printf("%d", a * b / 2);
		} else {
			printf("normal");
		}
	} else {
		printf("no");
	}
	return 0;
}