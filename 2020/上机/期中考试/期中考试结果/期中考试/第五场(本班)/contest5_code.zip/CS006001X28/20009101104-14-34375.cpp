#include <stdio.h>

int main() {
	char x;
	int i = 0, j = 0, k = 0;
	while (x != '!') {
		scanf("%c", x);
		if (x >= '0' && x <= '9') {
			i++;
		} else if (x <= 'Z' && x >= 'A') {
			j++;
		} else if (x <= 'z' && x >= 'a') {
			k++;
		}
	} ;
	printf("%d %d %d", j, k, i);
	return 0;
}