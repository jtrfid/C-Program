#include <stdio.h>

int main() {
	char ch;
	int daxie = 0, xiaoxie = 0, shuzi = 0;
	while ((ch = getchar()) != '!') {
		if (ch >= 'A' && ch <= 'Z') {
			daxie++;
		} else if (ch >= 'a' && ch <= 'z') {
			xiaoxie++;
		} else if (ch >= '0' && ch <= '9') {
			shuzi++;
		}
	}
	printf("%d %d %d", daxie, xiaoxie, shuzi);
	return 0;
}