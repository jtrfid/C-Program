#include <stdio.h>

int main () {
	int a, b, c, j, i, n, min, t, mina, minb, flag, k, s;
	scanf("%d", &n);
	k = n / 2;
	mina = n;
	minb = 0;
	flag = 0;
	for (i = 0; i <= k; i++) {
		for (j = 2; j < (k + i); j++) {
			if ((k + i) % j == 0 )

				flag = 1;
			if ((k - i) % j == 0)
				flag = 1;
		}




		t = mina - minb;
		s = 2 * i;
		if ( flag == 0 && s < t) {

			mina = k + i;

			minb = k - i;
		}
	}
	printf("%d %d", minb, mina);
	return 0;
}