#include <stdio.h>

int main() {
	int n;
	int i;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		if (i % 2 == 0) {
			printf("%d %d\n", i, i * i);
		}
	}
	return 0;
}