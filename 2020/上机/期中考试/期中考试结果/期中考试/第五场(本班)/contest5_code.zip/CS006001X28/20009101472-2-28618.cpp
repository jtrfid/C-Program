#include <stdio.h>
#include <math.h>

int main() {
	int a, b, c;
	scanf("%d %d %d", &a, &b, &c);
	if (a + b > c && a + c > b && b + c > a) {
		if (pow(a, 2) + pow(b, 2) == pow(c, 2)) {
			printf("%d", a * b);
		} else if (pow(a, 2) + pow(c, 2) == pow(b, 2)) {
			printf("%d", a * c);
		} else if (pow(b, 2) + pow(c, 2) == pow(a, 2)) {
			printf("%d", b * c);
		} else {

			printf("normal");
		}
	} else {
		printf("no");
	}
	return 0;
}