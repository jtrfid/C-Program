#include <stdio.h>
#include <math.h>

int main() {
	int a, b, c, min, mid, max;
	scanf("%d %d %d", &a, &b, &c);
	min = a;
	if (a > b) {
		min = b;
	}
	if (min > c) {
		min = c;
	}
	max = a;
	if (a < b) {
		max = b;
	}
	if (max < c) {
		max = c;
	}
	mid = a + b + c - max - min;
	if (a + b > c && abs(a - b) < c && a + c > b && abs(a - c)) {
		if (pow(min, 2) + pow(mid, 2) == pow(max, 2)) {
			printf("%d", min * mid / 2);
		} else
			printf("normal");
	} else {
		printf("no");
	}
	return 0;
}