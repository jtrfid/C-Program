#include <stdio.h>

int main() {
	int a, b, c, m, n;
	scanf("%d%d%d", &a, &b, &c);
	if (b > a) {
		m = a;
		a = b;
		b = m;
	}
	if (c > a) {
		m = a;
		a = c;
		c = m;
	}
	if (a + b > c && a - b < c) {
		if (b * b + c * c == a * a)
			printf("%d", b * c / 2);
		else
			printf("normal");
	} else
		printf("no");

	return 0;

}