#include <stdio.h>

int main() {
	int a;
	bool b = true, n = false, c = true;
	scanf("%d", &a);
	for (int i = a / 2; i < a && (!n); i++) {
		b = true;
		for (int k = 2; k < i; k++) {
			if (i % k == 0)
				b = false;
		}
		for (int j = a / 2; j > 0 ; j--) {
			c = true;
			for (int k = 2; k < j; k++) {
				if (j % k == 0) {
					c = false;
				}
			}
			if (!c) {
				continue;
			}
			if (i + j == a && b) {
				printf("%d %d", j, i);
				n = true;
			}
		}
	}
	return 0;
}