#include <stdio.h>

int main() {
	char x;
	int i = 0, j = 0, k = 0;
	do {
		scanf("%c", x);
		if (x >= 0 && x <= 9) {
			i++;
		} else if (x <= 'Z' && x >= 'A') {
			j++;
		} else if (x <= 'z' && x >= 'a') {
			k++;
		}
	} while (x != '!');
	printf("%d %d %d", j, k, i);
	return 0;
}