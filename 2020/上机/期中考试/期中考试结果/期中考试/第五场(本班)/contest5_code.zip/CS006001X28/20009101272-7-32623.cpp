#include <stdio.h>

int main() {
	int a;
	int b;
	scanf("%d", &a);
	for (b = 1; b < a; b++) {
		if (b % 2 == 0)
			printf("%d %d", b, b * b);
	}
	return 0;

}