#include <stdio.h>

int main() {
	int n, i, j, x;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		if (i % 2 == 0) {
			x = i * i;
			printf("%d %d\n", i, x);
		}
	}
	return 0;
}