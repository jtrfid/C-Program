#include <stdio.h>
#include <math.h>

int main() {
	int a, b, c, flag, i;
	scanf("%d", &a);
	for (b = a / 2; b >= 2; b--) {
		c = a - b;
		flag = 0;
		for (i = 3; i < b; i++) {
			if (b % i == 0) {
				flag = 1;
				break;
			}
		}
		if (flag == 0)
			for (i = 3; i < c; i++) {
				if (c % i == 0) {
					flag = 2;
					break;
				}
			}
		if (flag == 0) {
			printf("%d %d", b, c);
			break;
		}
	}

	return 0;
}