#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int i, j, k, l, flag = 0, flag1 = 0, a[1000] = {0}, b[1000] = {0};
	int x = 0, count1 = 0, count2 = 0;
	for (i = 2; i <= n / 2; i++) {
		flag = 0;
		for (j = 2; j <= i - 1; j++) {
			if (i % j == 0) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			a[x] = i;
			x++;
			count1++;
		}
	}
	int y = 0, set = 0;
	for (k = n / 2; k < n; k++) {
		flag1 = 0;
		for (l = 2; l <= k - 1; l++) {
			if (k % l == 0) {
				flag1 = 1;
				break;
			}
		}
		if (flag1 == 0) {
			count2++;
			b[y] = k;
			y++;
		}
	}
	for (y = 0; y <= count2 - 1; y++) {
		for (x = count1 - 1; x >= 0; x--) {
			if ((a[x] + b[y]) == n) {
				printf("%d %d\n", a[x], b[y]);
				set = 2;
				break;

			}
			if (set == 2)
				break;

		}
	}
	return 0;
}