#include <stdio.h>

int main() {
	char a;
	int n = 0, m = 0, l = 0;
	for (int i = 1;; i++) {
		scanf("%c", &a);
		if (a != '!') {
			if (a >= 'A' && a <= 'Z')
				l++;
			else if (a >= 'a' && a <= 'z')
				m++;
			else if (a >= '0' && a <= '9')
				n++;
		} else if (a == '!')
			break;
	}
	printf("%d %d %d", l, m, n);
	return 0;
}