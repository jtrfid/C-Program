#include <stdio.h>
int judge(int x);

int main() {
	int n;
	scanf("%d", &n);
	for (int i = n / 2; i < n; i++) {
		if (judge(i) && judge(n - i)) {
			printf("%d %d", n - i, i);
			break;
		}
	}

	return 0;
}

int judge(int x) {
	int j, d = 1;

	for (j = 2; j < x; j++) {
		if (x % j == 0)
			d = 0;
	}
	return d;
}