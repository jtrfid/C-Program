#include <stdio.h>

int main() {
	int c1 = 0, c2 = 0, c3 = 0, i;
	char x;
	for (i = 1; ; i++) {
		scanf("%c", &x);
		if (x <= 'Z' && x >= 'A') {
			c1++;
		} else if (x <= 'z' && x >= 'a') {
			c2++;
		} else if (x <= '9' && x >= '0') {
			c3++;
		} else if (x == '!') {
			break;
		}
	}
	printf("%d %d %d", c1, c2, c3);
	return 0;
}