#include <stdio.h>

int main() {
	int N, i, sum = 0;
	scanf("%d", &N);
	for (i = 1; i <= N; i++) {
		if (i % 2 == 0) {
			sum += i * i;
			printf("%d %d\n", i, sum);
			sum = 0;
		}

	}

	return 0;
}