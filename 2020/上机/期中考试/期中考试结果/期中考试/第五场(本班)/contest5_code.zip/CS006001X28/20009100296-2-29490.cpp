#include <stdio.h>

int main() {
	float a[3], t;
	int i, j;
	scanf("%f%f%f", &a[0], &a[1], &a[2]);
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 2 - i; j++) {
			if (a[j] > a[j + 1]) {
				t = a[j];
				a[j] = a[j + 1];
				a[j + 1] = t;
			}
		}
	}
	if (a[0] + a[1] <= a[2])
		printf("no");
	else if (a[0]*a[0] + a[1]*a[1] == a[2]*a[2])
		printf("%f", 0.5 * a[0]*a[1]);
	else
		printf("normal");
	return 0;
}