#include <stdio.h>

int main() {
	int n, i, m;
	i = 2;
	scanf("%d", &n);
	while (i <= n) {
		printf("%d %d\n", i, i * i);
		i += 2;
	}
	return 0;
}