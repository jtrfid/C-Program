#include <stdio.h>

int main() {
	int n, i, j, flag, cnt = 0, a = 0;
	int sushu[1000];
	scanf("%d", &n);

	for (i = 2; i < n; i++) {
		flag = 1;
		for (j = 2; j < i; j++) {
			if (i % j == 0) {
				flag = 0;
				break;
			}
		}
		if (flag == 1) {

			sushu[cnt] = i;
			cnt++;
		}
	}

	for (i = cnt / 2; i > 0; i--) {
		for (j = cnt / 2; j < cnt; j++) {
			if (sushu[i] + sushu[j] == n) {
				printf("%d %d", sushu[i], sushu[j]);
				a = 1;
				break;
			}
			if (a)
				break;
		}
		if (a)
			break;
	}

	return 0;
}