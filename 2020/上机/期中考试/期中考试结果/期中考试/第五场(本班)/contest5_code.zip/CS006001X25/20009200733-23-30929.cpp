#include <stdio.h>
#include <string.h>

int main(){
	int n,i,j;
	scanf("%d",&n);
	if (n<4){
		return 0;
	}
	char map[n+1];
	memset(map,0,(n+1)*sizeof (char));
	for (i=2;i<=n;i++){
		if (map[i]==0){
			for (j=i+i;j<=n;j+=i){
				map[j]=1;
			}
		}
	}
	for (i=j=n/2;i>=2;i--,j++){
		if (map[i]==0&&map[j]==0){
			printf("%d %d\n",i,j);
			return 0;
		}
	}
	return 0;
}
