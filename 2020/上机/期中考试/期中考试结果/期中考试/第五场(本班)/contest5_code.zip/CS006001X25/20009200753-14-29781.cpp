#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
  int a=0,b=0,d=0;
  char c=getchar();
  while(c!='!')
  {
     if(c>='A'&&c<='Z') a++;
     if(c>='a'&&c<='z') b++;
     if(c>='0'&&c<='9') d++;
     c=getchar();
  }
  printf("%d %d %d",a,b,d);
  return 0;
}
