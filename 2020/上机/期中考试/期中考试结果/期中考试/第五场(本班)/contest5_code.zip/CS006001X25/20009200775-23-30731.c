#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,cha=1000,c,p,q;
	scanf("%d",&n);
	for(i=2;i<n;i++)
	{
		if(sushu(i)&&sushu(n-i))
		 {
		 c=cha;
		 cha=fabs(n-2*i);
		 if(cha<c)
		 {
		 	p=i,q=n-i;
		 }
		 }
	}
	printf("%d %d",p,q);
}
int sushu(int n)
{
	int i,c=1;
	for(i=2;i<n;i++)
	{
		if(n%i==0)
		{
			c=0;
			break;
		}
	}
	return c;
}
