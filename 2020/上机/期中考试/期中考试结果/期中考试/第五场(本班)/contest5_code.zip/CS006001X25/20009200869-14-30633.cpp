#include<stdio.h>
int main()
{
	int a=0,b=0,c=0;
	char s;
	for(;;)
	{
		scanf("%c",&s);
		if(s>='A'&&s<='Z')	a++;
		if(s>='a'&&s<='z')	b++;
		if(s>='0'&&s<='9')	c++;
		if(s=='!')	break;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
