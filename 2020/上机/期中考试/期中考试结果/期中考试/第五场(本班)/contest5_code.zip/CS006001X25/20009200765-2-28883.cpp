#include <stdio.h>

int main ()
{
	int a=0,b=0,c=0;
	scanf ("%d",&a);
	scanf ("%d",&b);
	scanf ("%d",&c);
	
	int t=0;
	if (b>a){
		t=a;
		a=b;
		b=t;
	}
	if (c>a){
		t=a;
		a=c;
		c=t;	
	}
	if (b+c<=a){
		printf ("no");
	}
	
	if (b*b+c*c==a*a){
		printf ("%d",b*c/2);
	}
	
	if (b+c>a && b*b+c*c!=a*a){
		printf ("normal");
	}
	
	return 0;
}
