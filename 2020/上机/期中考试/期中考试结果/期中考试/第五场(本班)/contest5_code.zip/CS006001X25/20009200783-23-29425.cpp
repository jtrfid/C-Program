#include<cstdio>
int n;bool flag[1005];
int main()
{
	scanf("%d",&n);
	for(int i=2;i<=n;i++)
	 for(int j=2;j<i;j++)
	  if(i%j==0){flag[i]=1;break;}
	for(int i=n>>1;i;i--)
		if(!flag[i]&&!flag[n-i])
		{
			printf("%d %d\n",i,n-i);
			break;
		}
}
