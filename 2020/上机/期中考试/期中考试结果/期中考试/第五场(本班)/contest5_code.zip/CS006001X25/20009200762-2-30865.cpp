#include<stdio.h>
#include<math.h>

int main()
{
	int a,b,c,S;
	scanf("%d%d%d",&a,&b,&c);
	if(a*a+b*b==c*c)
	printf("%.0f",0.5*a*b);
	else if(b*b+c*c==a*a)
	printf("%.0f",0.5*c*b);
	else if(a*a+c*c==b*b)
	printf("%.0f",0.5*c*a);
	else if(a+b>c&&b+c>a&&a+c>b)
	printf("normal");
	else
	printf("no");
	return 0;
}



