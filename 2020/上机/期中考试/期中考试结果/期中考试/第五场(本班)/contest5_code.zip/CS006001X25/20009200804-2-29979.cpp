#include<stdio.h>;
{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	while a+b<c;
	printf("no");
	while a*a+b*b=c*c;
	int s;
	s=a*b;
	printf("%d",s);
	eals;
	printf("normal");
	return 0;





}
