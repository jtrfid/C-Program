#include<iostream>
using namespace std;
int main
{	int n,t;
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		if(i%2==0){
			t=n*n;
			printf("%d %d/n",n,t);
		}
	}
	return 0;
}
