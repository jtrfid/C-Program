#include <stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	if(n%2==0)
	{
		for(i=2;i<=n;i=i+2)
		{
			printf("%d %d\n",i,i*i);
		}
	}
	if(n%2==1)
	{
		for(i=2;i<=n-1;i=i+2)
		{
			printf("%d %d\n",i,i*i);
		}
	}
	
	
	return 0;
}
