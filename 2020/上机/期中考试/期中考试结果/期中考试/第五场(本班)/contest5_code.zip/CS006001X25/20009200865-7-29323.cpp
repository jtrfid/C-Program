#include<stdio.h>
int main()
{
	int sum,i,n;
	scanf("%d",&n);
	for(i=1,sum=0;i<=n;i++)
	{
		if(i%2==0)
		    printf("%d %d\n",i,i*i);
		    
	}
	return 0;
}
