#include<stdio.h>
int main()
{
	int n,a;
	scanf("%d",&n);
	for(a=1;a<=n;a++){
		if(a%2==0){
		    printf("%d %d\n",a,a*a);
		}
    }
	return 0;
}
