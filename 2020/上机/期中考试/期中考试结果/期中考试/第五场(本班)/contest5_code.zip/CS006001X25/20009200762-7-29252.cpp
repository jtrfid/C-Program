#include<stdio.h>
#include<math.h>

int main()
{
	int n,sum=0;
	scanf("%d",&n);
	for(int i=2;i<=n;i+=2)
	{
		printf("%d ",i);
		printf("%d",i*i);
		printf("\n");
		
	}
	
	return 0;
}
