#include<stdio.h>
int main (){
	char A[1000];
	int a=0,b=0,c=0,i;
	for(int i=0;i<=1000;i++){
		scanf("%s",&A[i]);
	}
	while(A[i]!='!'){
		if (A[i]>='A'&&A[i]<='Z'){
			a++;
		
		} 
		else if(A[i]>='a'&&A[i]<='z'){
			b++;
		
		}
		else if(A[i]>='0'&&A[i]<='9'){
			c++;
		
		}
		break;
	}
	printf("%d %d %d",a,b,c);
	
	
	return 0;
} 
