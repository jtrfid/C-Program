#include <stdio.h>
int main()
{
	int a,m,n,i,j,k;
	scanf("%d",&a);
	m=a/2,n=a/2;
	for(j=2;j<a;++j)
{
	for(i=2;i<n;++i)
	{
		if(i<m&&m%i==0||n%i==0)
		{
			m=m-1;n=n+1;break;
		}
		if(i>=m&&n%i==0)
		{
			m=m-1;n=n+1;break;
		}
	}
}
	
	printf("%d %d",m,n);
	return 0;
}
