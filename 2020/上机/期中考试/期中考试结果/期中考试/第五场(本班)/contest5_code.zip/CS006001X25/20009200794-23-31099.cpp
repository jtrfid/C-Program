#include<stdio.h>
int main(){
	int flag1,a,j=2,k=2,flag2;
	scanf("%d",&a);
	for(int i=a/2;i>=2;i--){
		flag1=0;
		do{
			if(i%j==0){
				flag1++;
				j++;
				break;
			}
			if(i%j!=0){
				j++;
				continue;
			}
		}
		while(j!=i);
		if(flag1==0){
			int b=a-i;
			flag2=0;
			do{
				if(b%k==0){
					flag2++;
					k++;
					break;
				}
				if(b%k!=0){
					k++;
					continue;
				}
			}
			while(k!=b);
			if(flag2==0){
				printf("%d %d",i,b);
				break;
			}
		}
		break;
	}
	return 0;
}
