#include<stdio.h>
int main()
{
	int a, b;
	scanf("%d",&a);
	b=a/2;
	printf("%d %d",b,b);
	return 0;
}
