#include<stdio.h>
int main()
{int a,b,c;
scanf("%d %d %d",&a,&b,&c);
if((a+b<=c)||(a+c<=b)||(b+c<=a))
printf("no");
else if((a*a+b*b==c*c)||(b*b+c*c==a*a)||(c*c+a*a==b*b))
printf("%d",a*b/2);
else printf("normal");
	return 0;
}
