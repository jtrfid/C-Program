#include<stdio.h>
#include<math.h>

int main()
{
	int caps=0,xiao=0,num=0;
	int n;
	char x;
	for(int i=0;i<=n;i++)
	{
		while(x!='!'){
		
		scanf("%c",x);
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
	}
	}
	printf("%d %d %d",caps,xiao,num);
	return 0;
}
