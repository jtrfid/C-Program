#include<stdio.h>
int main()
{
	char x;
	int a=0,b=0,c=0;
	while(1){
	    scanf("%c",&x);
		if(65<=x&&x<=90) a++;
		else if(97<=x&&x<=122) b++;
		else if('0'<=x&&x<='9') c++;
	    else break;
		}
	printf("%d %d %d",a,b,c);    
	return 0;
}
