#include <stdio.h>

int sushu (int a)
{
	int i=0;
	int judge=1;
	for (i=2;i<a;i++){
		if (a%i==0){
			judge=0;
		}
	}
	
	return judge;
}

int main ()
{
	int n=0;
	scanf ("%d",&n);
	int i=0;
	for (i=0;i<n/2;i++){
		if (sushu(n/2-i)==1 && sushu(n/2+i)==1){
			printf ("%d %d",n/2-i,n/2+i);
			break;
		}
	}
	
	return 0;
}
