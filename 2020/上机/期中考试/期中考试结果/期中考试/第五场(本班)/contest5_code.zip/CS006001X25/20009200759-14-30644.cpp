#include<stdio.h>
#include<ctype.h>
int main()
{
	int n1=0,n2=0,n3=0;
	char a,b;
	
	while(1)
	{scanf("%c",&a);
		if(a=='!') break;
		if(isupper(a)) n1++;
		if(islower(a)) n2++;
		if(a>=48&&a<=57) n3++;
	}
	printf("%d %d %d",n1,n2,n3);
	return 0;
}
