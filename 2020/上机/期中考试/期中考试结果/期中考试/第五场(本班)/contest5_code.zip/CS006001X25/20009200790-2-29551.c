#include<stdio.h>
int main(void)
{
    float a,b,c,s;
    scanf("%f %f %f",&a,&b,&c);
    if(a+b>c&&a+c>b&&b+c>a)
    {
        if(a*a+b*b==c*c)
        {
            s=1/2*a*b;
            printf("%f",s);
        }
        else if(a*a+c*c==b*b)
        {
            s=1/2*a*c;
            printf("%f",s);
        }
        else if(b*b+c*c==a*a)
        {
            s=1/2*b*c;
            printf("%f",s);
        }
        else
        {
            printf("normal");
        }
    }
    else
    {
        printf("no");
    }

    return 0;
}
