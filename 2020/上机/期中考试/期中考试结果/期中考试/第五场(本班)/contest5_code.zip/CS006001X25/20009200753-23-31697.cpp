#include<stdio.h>
using namespace std;
int zs(int x)
{
    int flag=0; 
	if(x==1||x==0) return 3;
	if(x==2) return 1;
	if(x>2)
	{
		for(int i=2;i<=x-1;i++)
		if(x%i==0) flag++;
	}
	if(flag==0) return 1;
	else return 2;
}
int main()
{
   int a,m=0;
   scanf("%d",&a);
   for(int i=1;i<=a/2;i++)
   if(zs(i)==1&&zs(a-i)==1)
   {
      m=i;
   }
   printf("%d %d",m,a-m);
   return 0;
}
