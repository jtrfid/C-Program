#include<stdio.h>
int main(){
	int n,i,m;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		if(i%2==0){
			m=i*i;
			printf("%d %d",i,m);     
		    printf("\n");
		}
	}
	return 0;
}
