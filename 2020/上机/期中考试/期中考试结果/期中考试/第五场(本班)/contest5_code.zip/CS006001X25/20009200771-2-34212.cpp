#include<stdio.h>
#include<math.h>

int main()
{
	int a,b,c;
	double s;
	double p;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b>c&&a+c>b&&b+c>a){
		if(a*a+b*b==c*c||a*a+c*c==b*b||b*b+c*c==a*a){
			p=(a+b+c)/2.0;
	        s=sqrt(p*(p-a)*(p-b)*(p-c));
	        printf("%f",s);
		}
		else{
			printf("normal");
		}
	}
	else{
		printf("no");
	}
	return 0;
}
