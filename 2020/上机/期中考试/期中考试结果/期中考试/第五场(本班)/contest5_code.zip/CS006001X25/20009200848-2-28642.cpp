#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c,s,s1;
	scanf("%d%d%d",&a,&b,&c);
	if(a+b<=c||b+c<=a||a+c<=b)
	printf("no");
	else if(a*a+b*b==c*c||b*b+c*c==a*a||a*a+c*c==b*b){
	s=(a+b+c)/2;
	s1=sqrt(s*(s-a)*(s-b)*(s-c));
	printf("%d",s1);}
	else printf("normal");
	return 0;
}
