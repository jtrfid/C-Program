#include<stdio.h>

int main()
{
	int a=0,b=0,c=0;
	char ch;
	while(ch!='!'){
		scanf("%c",&ch);
		if(ch>='A'&&ch<='Z'){
			a++;
		}
		if(ch>='a'&&ch<='z'){
			b++;
		}
		if(ch>='0'&&ch<='9'){
			c++;
		}
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
