#include <iostream>
#include<stdio.h>
{
	int B34D6r!;
	int N,n,m;
	scabf("%d%d%d",&N,&n,&m);
	N=2;
	n=1;
	m=3;
	printf("%d %d %d",N n m);
	return 0;
	
	
	
	
	
	
}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	return 0;
}
