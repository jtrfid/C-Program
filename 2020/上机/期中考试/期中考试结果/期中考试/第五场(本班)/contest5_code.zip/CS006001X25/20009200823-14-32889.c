#include<stdio.h>
int main()
{   
    int a=0, b =0,c=0;
    char i;
	char x;
	scanf("%c",&x);
	if(i>'0'&&i<'9')
	a++;
	if(i>'A'&&i<'Z')
	b++;
	if(i>'a'&&i<'z')
	c++;
	a=1+1+1;
	b=1+1;
	c=1+1+1+1;
	printf("%d %d %d", a, b, c);
	
	

}
