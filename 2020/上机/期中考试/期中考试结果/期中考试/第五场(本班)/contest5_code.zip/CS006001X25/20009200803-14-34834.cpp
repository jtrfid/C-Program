#include<stdio.h>
int main()
{
	char sum;
	int a,b,c;
	a=0,b=0,c=0;
	scanf("%c",&sum);
	while('a'<=sum<='z')
	{
		b++;
	}
	while('A'<=sum&&sum<='Z')
	{
		a++;
	}
	while('0'<=sum&&sum<='9')
	{
		c++;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
