#include<stdio.h>
using namespace std;
int main(){
	int n,t;
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		if(i%2==0){
			t=i*i;
			printf("%d %d\n",i,t );
		}
	}
	return 0;
}
