#include<stdio.h>
int main(){
	int flag1,a,flag2;
	scanf("%d",&a);
	for(int i=a/2;i>=2;i--){
		flag1=0;
		for(int j=2;j<i;j++){
			if(i%j==0){
				flag1++;
				break;
			}
			if(i%j!=0){
				continue;
			}
		}
		if(flag1==0){
			int b=a-i;
			flag2=0;
			for(int k=2;k<b;k++){
				if(b%k==0){
					flag2++;
					break;
				}
				if(b%k!=0){
					continue;
				}
			}
			if(flag2==0){
				printf("%d %d",i,b);
				break;
			}
		}
		break;
		
	}
	return 0;
}
