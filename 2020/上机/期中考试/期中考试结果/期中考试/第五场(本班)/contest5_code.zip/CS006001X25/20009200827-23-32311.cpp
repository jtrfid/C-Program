#include<stdio.h>
int sushu(int n)
{
	int  b=0,i,x;
	for(i=2;i<n;i++)
	{
		x=n%i;
		if(x==0)
		{
			b=1;
			break;
		}
	}
	return b;
}
int main()
{
	int n,i,c,k,f,q;
	scanf("%d",&n);
	q=n/2;
	for(i=q;i>1;i--)
	{
		k=sushu(i);
		if(k==0)
		{
			c=n-i;
			f=sushu(c);
			if(f==0)
			{
				printf("%d %d",i,c);
				break;
			}
		}
	}
	return 0;
}
