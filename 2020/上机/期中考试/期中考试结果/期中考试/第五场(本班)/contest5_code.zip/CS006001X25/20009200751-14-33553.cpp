#include <stdio.h>
int main(){
	int x=0,y=0,z=0;
	char ch;
	scanf("%c",&ch);
	ch=getchar();
	while(ch!='!')
	{
		if(ch='A')x++;
        if(ch='a')y++;
        if(ch='1')z++;
	}
	printf("%d %d %d",x,y,z);
	return 0;
}
