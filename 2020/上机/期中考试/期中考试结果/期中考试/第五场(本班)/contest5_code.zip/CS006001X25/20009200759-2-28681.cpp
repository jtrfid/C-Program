#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c,s,d;
	scanf("%d %d %d",&a,&b,&c);
	if(a>=b+c||b>=a+c||c>=a+b) printf("no");
	else{
		if(a*a==b*b+c*c||b*b==a*a+c*c||c*c==a*a+b*b)
		{
			d=(a+b+c)/2;
			s=sqrt(d*(d-a)*(d-b)*(d-c));
		printf("%d",s);
		
		}
		else printf("normal");
		
	}
	
	return 0;
}
