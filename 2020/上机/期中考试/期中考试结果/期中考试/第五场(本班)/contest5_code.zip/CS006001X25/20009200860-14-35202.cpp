#include<stdio.h>
using namespace std;
int main(){
	char x;
	int ana=0,anb=0,anc=0;
	while(scanf("%s",&x)){
		if(x=='a') ++ana;break;
		return x;
	}
	printf("%d %d %d",ana,anb,anc);
	return 0;
}
