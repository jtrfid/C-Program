#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;
    int i=0,j=0,k=0;
    while(1)
    {
        scanf("%c",&ch);
        if(ch=='!')
        {
            break;
        }
        if('A'<=ch&&ch<='Z');
        {
            i++;
        }
        if('a'<=ch&&ch<='z');
        {
            j++;
        }
        if('0'<=ch&&ch<='9');
        {
            k++;
        }
    }
    printf("%d %d %d",i,j,k);
    return 0;
}
