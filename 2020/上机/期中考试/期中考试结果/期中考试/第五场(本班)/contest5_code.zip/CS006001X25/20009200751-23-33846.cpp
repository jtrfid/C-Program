#include <stdio.h>
int main(){
	int n;
	int num[1000],i,j,p,q;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=2;j<i;)
		{
			if(i%j!=0)
			j++;  
		}
		if(i==j)
		num[i]=j;
	}
	for(p=0;p<n;p++)
	{
		for(q=n;q>p;q--)
		{
			if(num[p]+num[q]==n)
			printf("%d %d\n",num[p],num[q]);
		}
	}
	return 0;
}
