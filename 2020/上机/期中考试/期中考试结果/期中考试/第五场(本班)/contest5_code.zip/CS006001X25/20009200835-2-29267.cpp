#include<stdio.h>
int main()
{double a,b,c;
scanf("%lf %lf %lf",&a,&b,&c);
if((a+b<=c)||(a+c<=b)||(b+c<=a))
printf("no");
else if((a*a+b*b==c*c)||(b*b+c*c==a*a)||(c*c+a*a==b*b))
{
if(c>a&&c>b)
printf("%lf",a*b/2);
else if(b>c&&b>a)
printf("%lf",c*a/2);
else if(a>c&&a>b)
printf("%lf",b*c/2);
}
else printf("normal");
	return 0;
}
