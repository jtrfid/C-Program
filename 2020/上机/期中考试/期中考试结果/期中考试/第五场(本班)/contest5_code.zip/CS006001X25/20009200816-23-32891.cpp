#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	printf("%d %d",a/2,a/2);
	return 0;
}
