#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b<=c||b+c<=a||a+c<=b)
	     printf("no");
	else if(a*a+b*b==c*c)
	    printf("%f",1.0/2*a*b);
	else if(b*b+c*c==a*a)
	    printf("%f",1.0/2*b*c);
	else if(a*a+c*c==b*b)
	   printf("%f",1.0/2*a*c);
	else
	{
		printf("norma");
	}   		     
	return 0;
}
