#include<stdio.h>
int main()
{
	int n,a,b,t,m;
	scanf ("%d",&n);
	int c=n;
	for (int i=2;i<=0.5*n;i++)
	{
		for (t=2;t<i;t++)
		{
			if (i%t==0)
			{
				t=0;
				break;
			}
		}
		for (m=2;m<n-i;m++)
		{
			if ((n-i)%m==0)
			{
				m=0;
				break;
			}
		}
		if (t!=0&&m!=0)
		{
			if (c>=b-a)
			a=i;
			b=n-i;
			c=b-a;
		}
	}
	printf ("%d %d",a,b);	
	return 0;
} 
