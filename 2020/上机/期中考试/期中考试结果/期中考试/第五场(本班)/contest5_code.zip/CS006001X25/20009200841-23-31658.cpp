#include<stdio.h>
int main()
{
	int n, p, f, g;
	scanf("%d", &n);
	for(int a=2; a<n/2+1; a++)
	{
		p=0;
		for(int b=2; b<a; b++)
		{
			if(a%b==0)
			{
				p=p+1;
				break;
			}
		}
		for(int c=2; c<n-a; c++)
		{
			if(n-c%c==0)
			{
				p=p+1;
				break;
			}
		}
		if(p==0)
		{
			f=a;
			g=n-a;
		}
	}
	printf("%d %d", f, g);
	return 0;
}
