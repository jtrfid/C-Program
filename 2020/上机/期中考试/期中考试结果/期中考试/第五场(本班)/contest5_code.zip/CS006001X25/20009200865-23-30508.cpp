#include<stdio.h>
int sushu(int a)
{
	if(a<2)
	    return 0;
	else if(a==2)
	    return 1;
	else
	{
		int i;
		for(i=1;i<=a/2;i++)
		{
			if(a%i==0)
			    return 0;    
		}
		return 1;
	}	    
}
int main()
{
	int a,m,n,i;
	scanf("%d",&a);
	for(i=a/2;;i--)
	{
	    if(sushu(i)&&sushu(a-i))
		{
			m=i;
			n=a-i;
		}    	
		break;
	}
	printf("%d %d",m,n);
	return 0;
}
