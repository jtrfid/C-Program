#include<stdio.h>
int main()
{   
    int a=3, b =2,c=4;
    char i;
	char x;
	scanf("%c",&x);
	if(i>'0'&&i<'9')
	a++;
	if(i>'A'&&i<'Z')
	b++;
	if(i>'a'&&i<'z')
	c++;
	printf("%d %d %d", a, b, c);
	
	

}
