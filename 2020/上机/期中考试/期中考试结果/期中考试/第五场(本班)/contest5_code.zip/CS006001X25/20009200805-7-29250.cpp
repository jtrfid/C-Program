#include<stdio.h>
int main()
{
    int n,i,p;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
    	if(i%2==0)
    	{
    		p=i*i;
    		printf("%d %d\n",i,p);
    	}
    }
	return 0;
}
