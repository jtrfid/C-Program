#include<stdio.h>
int main()
{
    char c;
    int count1=0,count2=0,count3=0;
    while(c!='!')
    {
        c=getchar();
        if(c>='A'&&c<='Z')
        {
            count1++;
        }
        else if(c>='a'&&c<='z')
        {
            count2++;
        }
        else if(c>='0'&&c<='9')
        {
            count3++;
        }
    }
    printf("%d %d %d",count1,count2,count3);
}
