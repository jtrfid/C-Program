#include<stdio.h>
int main()
{
	int i;int a=0,b=0,c=0;char ar[10000];
	for(i=0;i<10000;i++)
	{
		ar[i]=getchar();
		if(ar[i]>='a'&&ar[i]<='z') b++;
		if(ar[i]>='A'&&ar[i]<='Z') a++;
		if(ar[i]>=0&&ar[i]<=9) c++;
		if(ar[i]='!') break;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
