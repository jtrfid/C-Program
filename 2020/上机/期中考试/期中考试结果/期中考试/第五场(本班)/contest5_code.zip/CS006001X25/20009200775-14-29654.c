#include<stdio.h>
int main()
{
	int d=0,x=0,s=0;
	char f;
	while(f!='!')
	{
		scanf("%c",&f);
		if('A'<=f&&f<='Z') d+=1;
		else if('a'<=f&&f<='z') x+=1;
		else s+=1;
	}
	printf("%d %d %d",d,x,s-1);
}
