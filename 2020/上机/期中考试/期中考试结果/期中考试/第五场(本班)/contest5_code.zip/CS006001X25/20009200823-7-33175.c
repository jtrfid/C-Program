#include<stdio.h>
int main()
{
	int a, i, sum;
	scanf("%d",&a);
	i=1;
	if (a!=1)
	{
	while(i<=a)
	{	
		i++;
		if (i%2==0)
		{
		sum=i*i;
		printf("%d %d\n",i,sum);}
	}
}
    return 0;
}
