#include<cstdio>
int n;
int main()
{
	scanf("%d",&n);
	for(int i=2;i<=n;i+=2)
	 printf("%d %d\n",i,i*i);
}
