#include<stdio.h>
int main(){
	char a[1000];
	int d=0,b=0,c=0,i;
	for(i=0;i<=1000;i++){
		scanf("%s",&a[i]);
	}
	while(a[i]!='!'){
	if(a[i]>='A'&&a[i]<='Z') d++,printf("%d",d);
		else{if(a[i]>='a'&&a[i]<='z') b++,printf("%d",b);
		 else if(a[i]>='0'&&a[i]<='9') c++,printf("%d",c);
		}	
		break;
	}
	
	
	
	return 0;
}


