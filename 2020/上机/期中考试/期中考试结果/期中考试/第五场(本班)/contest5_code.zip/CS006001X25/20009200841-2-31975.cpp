#include<stdio.h>
int main()
{
	int a, b, c;
	scanf("%d %d %d", &a, &b, &c);
	if(a+b<=c && a+c<=b && c+b<=a)
		printf("no");
	else if(a*a+b*b==c*c || a*a+c*c==b*b || b*b+c*c==a*a)
	{
		if(c>a && c>b) printf("%f", a*b/2.);
		if(b>a && b>c) printf("%f", a*c/2.);
		if(a>c && a>b) printf("%f", c*b/2.);
	}
	else printf("normal");
	return 0;
}
