#include<stdio.h>
int main()
{
	int n,i,s,m;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(i%2==0)
	    {
	       m=i;
		   s=m*m;
		   printf("%d %d\n",m,s);
	    }
		s=0;
	}
	return 0;
}

