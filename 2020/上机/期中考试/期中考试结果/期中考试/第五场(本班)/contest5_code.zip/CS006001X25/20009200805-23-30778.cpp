#include<stdio.h>
int su(int);
int main()

{
	int n,i,j;
	scanf("%d",&n);
	i=n/2;
	for(;i>=2;i--)
	{
		j=n-i;
		if(su(j)&&su(i))
		{
			break;
		}
	}
	printf("%d %d",i,j);
	return 0;
}
int su(int a)
{
	for(int i=2;i<=a-1;i++)
	{
		if(a%i==0)
		{
			return 0;
		}
	}
	return 1;
}
