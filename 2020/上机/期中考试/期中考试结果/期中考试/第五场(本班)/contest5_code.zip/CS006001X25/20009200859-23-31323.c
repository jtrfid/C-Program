#include<stdio.h>
int isprime(int a){
	int i,jug=1;
	for(i=2;i<a;i++){
		if(a%i==0){
			jug=0;break;
		}
	}
	return jug;
}
int main(){
	int n;
	scanf("%d",&n);
	int i;
	for(i=n/2;i>1;i--){
		if(isprime(i)==1&&isprime(n-i)==1){
			printf("%d %d",i,n-i);
			break;
		}
	}
	return 0;
}
