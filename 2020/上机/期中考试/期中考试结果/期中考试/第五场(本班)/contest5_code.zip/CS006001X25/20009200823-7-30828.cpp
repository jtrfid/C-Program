#include<stdio.h>
int main()
{
	int a, i, sum;
	i=1;
	scanf("%d",&a);
	while(i<=a)
	{	
		i++;
		if (i%2==0)
		{
		sum=i*i;
		printf("%d %d\n",i,sum);}
	}
	return 0;
}
