#include<stdio.h>
int main()
{
	int a,b,c,i,j,n,flag,flag2;
	scanf("%d",&a);
	if(a==2) printf("1 1");
	else{b=a/2;
	for(i=0;i<b-1;i++)
	{
		flag=0;
		for(j=2;j<b;j++)
		{
			if((b-i)%j==0) flag=1;break;
		}
		if(flag==0)
		{
			c=a-(b-i);
			flag2=0;
			for(j=2;j<c;j++)
		{
			if(c%j==0) flag2=1;break;
		}
			if(flag2==0) printf("%d %d",b-i,c); break;
		}
	}
	}
	
	return 0;
}
