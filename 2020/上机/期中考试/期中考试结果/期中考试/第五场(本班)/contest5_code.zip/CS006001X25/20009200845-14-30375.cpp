#include<stdio.h>
int main()
{
	char c;
	int da=0,xiao=0,shu=0;
	while(c!=33)
	{
		scanf("%c",&c);
		if(c>=65&&c<=90)	da++;
		if(c>=97&&c<=122)	xiao++;
		if(c>=48&&c<=57)	shu++;
		
	}
	printf("%d %d %d",da,xiao,shu);
	return 0;
}
