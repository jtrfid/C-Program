#include<stdio.h>
int main()
{int a,b,c,d,e;
scanf("%d",&a);
for(b=2;b<=a-2;b++)
{c=2;
while(c<b)

if(b%c==0)
c=c+1;
else if(c>=b)
break;
printf("%d",b);
}
for(d=2;d<=a-2;d++)
{e=2;
while(e<d)
if(d%e==0)
e=e+1;
else if(e>d)
break;
printf("%d",d);}

return 0;
}
