#include<stdio.h>
int prime(int i)
{
	int j=2,prime=1;
	while(j<i)
	{
		if(i%j==0)	prime=0;
		j++;
	}
	return prime;
}
int main()
{
	int x,k,p;
	scanf("%d",&x);
	for(k=x-3;prime(k);k--)
	{
		p=x-k;
		if(prime(p))	break;

	}
	printf("%d %d",k,p);
	
	return 0;
}
