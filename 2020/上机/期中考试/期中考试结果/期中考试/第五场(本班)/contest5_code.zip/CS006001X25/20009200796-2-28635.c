#include <stdio.h>
int main()
{
	int a,b,c,temp;
	scanf("%d %d %d",&a,&b,&c);
	if(a>b&&a>c)
	{
		temp=a;
		a=c;
		c=temp;
	}
	if(b>a&&b>c)
	{
		temp=b;
		b=c;
		c=temp;
	}
	if(a+b>c&&a+c>b&&b+c>a)
	{
		if(a*a+b*b==c*c)
		printf("%d",a*b/2);
		else
		printf("normal");
	}
	else
	printf("no");	
	return 0;
}
