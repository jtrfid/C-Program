#include<stdio.h>
int main()
{
	char c;
	int p=0,k=0,o=0;
	c=getchar();
	while(c!='!')
	{
		if(c<='z'&&c>='a')
		{
			p++;
		}
		else if(c<='Z'&&c>='A')
		{
			k++;
		}
		else 
		{
			o++;
		}
		
	c=getchar();	
	}
	printf("%d %d %d",k,p,o);
	return 0;
}
