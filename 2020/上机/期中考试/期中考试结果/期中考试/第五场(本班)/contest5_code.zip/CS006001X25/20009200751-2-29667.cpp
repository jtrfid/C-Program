#include <stdio.h>
int main(){
	int a,b,c,temp,s;
	scanf("%d %d %d",&a,&b,&c);
	if(c>b)
	{
		temp=b;
		b=c;
		c=temp;
	}
	if(a<b&&a>c)
	{
		temp=a;
		a=b;
		b=temp;
	}
	if(a<c)
	{
		temp=c;
		c=b;
		b=temp;
		temp=a;
		a=c;
		c=temp;
	}
	
	if(b+c<=a)
	{
		printf("no\n");
	}
	else if(b+c>0)
	{
		if(b*b+c*c==a*a)
		{
			s=b*c/2;
			printf("%d",s);
		}
		else
		printf("normal");
	}
	return 0;
}
