#include<stdio.h>
int main(){
	int a,b,c;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b>c && a+c>b && b+c>a){
		if(a*a + b*b==c*c ){
			printf("%.0f",0.5*a*b);
		}
		if(a*a + c*c ==b*b){
			printf("%.0f",0.5*a*c);
		}
		if(b*b +c*c==a*a){
			printf("%.0f",0.5*b*c);
		}
		else if(a*a + b*b!=c*c && a*a + c*c !=b*b && b*b +c*c!=a*a){
			printf("normal");
		}
	}
	else{
		printf("no");
		
	}
	
	return 0;
}
