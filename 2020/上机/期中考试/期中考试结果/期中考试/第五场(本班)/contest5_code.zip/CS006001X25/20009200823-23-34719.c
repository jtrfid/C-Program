#include<stdio.h>
int main()
{
	int n, i, j, a, b;
	scanf("%d",&n);
	for(i=n/2;i>0;i--)
	{
		for(a=2;a<=i-1;a++)
		if (i%a==0)
		break;
	}
	for(j=n/2;j>0;j++)
	{
		for(b=2;b<=j-1;b++)
		{
			if (j%b==0)
		    break;
		}
		
	}
	scanf("%d %d",i,j);
	return 0;
}
