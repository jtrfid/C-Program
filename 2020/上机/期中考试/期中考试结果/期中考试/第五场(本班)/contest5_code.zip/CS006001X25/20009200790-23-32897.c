#include <stdio.h>
#include <stdlib.h>
int sushu(int x)
{
    int i=2;
    for(i=2;i<=x;i++)
    {
        if(x%i==0)
        {
            break;
        }
    }

    if(i==x)
    {
        return 1;
    }
        else
    {
        return 0;
    }
}
int main()
{
    int a,s1,s2,i,fabs=1000,sll,bgg,min;
    scanf("%d",&a);
    for(i=2;i<=a;i++)
    {
        min=fabs;
        s1=i;
        s2=a-i;
        if((sushu(s1))&&(sushu(s2)))
        {
            if(s1>=s2)
            {
                fabs=s1-s2;
            }
            else
            {
                fabs=s2-s1;
            }
            if(fabs<=min)
            {
                if(s1>=s2)
             {
                sll=s2;
                bgg=s1;
             }
            else
             {
                sll=s1;
                bgg=s2;
             }
            }
        }
    }
    printf("%d %d",sll,bgg);
    return 0;
}
