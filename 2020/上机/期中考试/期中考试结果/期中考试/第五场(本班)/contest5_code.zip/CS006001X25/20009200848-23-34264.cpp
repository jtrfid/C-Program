#include<stdio.h>
#include<stdlib.h>
int mix(int mix)
{int j;int x=0;
for(j=2;j<mix;j++)
{if(mix%j==0)break;
else x=1;
}
return x;}
int main()
{
	int i,n,j;int num,ma,mb,min=1000;
	scanf("%d",&n);
	for(i=n/2;i<1000;i++)
	for(j=n/2;j>0;j--)
	while(i+j==n&&mix(i)==1&&mix(j)==1){
	num=i-j;
	if(num<min){min=num;ma=i;mb=j;
	}
	break;
	}
	printf("%d %d",ma,mb);
	

	return 0;
}
