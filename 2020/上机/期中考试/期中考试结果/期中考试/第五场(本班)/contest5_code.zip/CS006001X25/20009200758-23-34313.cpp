#include<stdio.h>
int main()
{
	int n,a,b,t1,t2,i=0,i1=0,cnt=0,cnt1=0;
	scanf("%d",&n);
	a=n/2;
	b=n/2;
	t1=a;
	t2=b;
	for(i=2;i<a;i++){
		if(a%i==0) cnt++;
	}
    if(cnt==0)
    printf("%d %d",a,b);
    else{
	for(a=n/2,b=n/2;;a--,b++){
		for(i=2;i<b;i++){
			if(a%i==0||b%i==0) cnt++;
		}
		if(cnt==0){
		    printf("%d %d",a,b);
		    goto out;
		}
	}
}out:
	return 0;
}
