#include <stdio.h>
int main()
{
	int a,m,n,i,j;
	scanf("%d",&a);
	m=a/2,n=a/2;
	
	for(j=2;j<a/2;++j)
	{
		if(m%j==0||n%j==0)
		{
			m=m-1;
			n=n+1;
		}
		if(m%j!=0&&n%j!=0)
		{
			break;
		}
	}
	
	printf("%d %d",m,n);
	
	return 0;
}
