#include<stdio.h>
int main()
{
	int a,b,c,s;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b<=c)
	{
		printf("no");
	}
	else if(a+c<=b)
	{
		printf("no");
	}
	else if(b+a<=c)
	{
		printf("no");
	}
	else if(a*a+b*b==c*c)
	{
		s=a*b*1.0/2;
		printf("%d",s);
	}
	else if(a*a+c*c==b*b)
	{
		s=1.0/2*a*c;
		printf("%d",s);
	}
	else if(b*b+c*c==a*a)
	{
		s=1.0/2*b*c;
		printf("%d",s);
	}
	else
	{
		printf("normal");
	}
	return 0;
}
