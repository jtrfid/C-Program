#include"stdio.h"
	int isprime(int x)
	{
		if(x <= 1) return 0;
		if(x = 2) return 1;
		for (int i = 2; i < x; i++)
		  {
			if( x % i ==0)  return 1;
			
	      }
		  return 1;
	    
	
    }
	int main()
	{   int n,dif=1000000,dif1,a=0;
		scanf("%d",&n);
		for (int j = 1; j <= n/2;j++)
		{  
			if (isprime(j)&&isprime(n-j))
			{
				a=j>a?j:a;
		    }
			
		}
	    printf("%d %d",a,n-a);
	return 0;
  }
