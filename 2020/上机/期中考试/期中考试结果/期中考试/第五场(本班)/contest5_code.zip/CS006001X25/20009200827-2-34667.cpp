#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,s,p;
	scanf("%f %f %f",&a,&b,&c);
	if(a<=0||b<=0||c<=0)
	{
		printf("no");
	}
	else if(a+b<c||a+c<b||b+c<a)
	{
		printf("no");
	}
	else if(a*a+b*b==c*c||a*a+c*c==b*b||a*a+c*c==b*b)
	{
		p=(a+b+c)/0.5;
		s=sqrt(p*(p-a)*(p-b)*(p-c));
		printf("%.0f",s);
}
     else
     {
     	printf("normal");
     }
	return 0;
}
