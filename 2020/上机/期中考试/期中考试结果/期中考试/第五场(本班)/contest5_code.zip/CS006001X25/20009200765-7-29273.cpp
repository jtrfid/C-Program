#include <stdio.h>

int main ()
{
	int n=0;
	scanf ("%d",&n);
	int i=0;
	
	for (i=2;i<=n;i=i+2){
		printf ("%d %d\n",i,i*i);
	}
	return 0;
}
