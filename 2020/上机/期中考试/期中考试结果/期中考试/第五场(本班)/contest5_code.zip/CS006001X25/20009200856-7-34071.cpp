#include<stdio.h>
int main(){
	int n,i=0,h=0;
	scanf("%d",&n);
	char a[100000000];
	for(i=0;i<=n;i=i+2){
		h=i;
		a[h]=i*i;
		
		
	}
	printf("%d %c\n",i,a[h]);
	
	
} 
