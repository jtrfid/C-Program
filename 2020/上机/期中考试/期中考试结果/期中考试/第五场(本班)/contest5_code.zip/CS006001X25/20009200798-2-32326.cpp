#include<stdio.h>
int main()
{
	int a,b,c,S;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b>c&&a+c>b&&b+c>a)
	{
		if(a*a+b*b==c*c)
		{
            S=a*b/2;
			printf("%d",S);
		}
		else if(a*a+c*c==b*b)
		{
		    S=a*c/2;
		    printf("%d",S);
		}
		else if(b*b+c*c==a*a)
		{
		    printf("%d",S);
		}
	    else
	    {
	        printf("normal");
	    }
		
    }
    else
    {
    	printf("no");
    }
	return 0;
}

