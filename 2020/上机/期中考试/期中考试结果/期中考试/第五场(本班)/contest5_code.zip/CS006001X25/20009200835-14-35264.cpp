#include<stdio.h>
int main()
{char a,b,c,d;
int h,i,j;
h=i=j=0
	scanf("%c%c%c%c%c%c%c!",&a,&b,&c,&d,&e,&f,&g);
if(a>=48&&a<=57||b>=48&&b<=57||c>=48&&c<=57||d>=48&&d<=57)
h=h+1;
if(a>=58&&a<=83||b>=58&&b<=83||c>=58&&c<=83||d>=58&&d<=83)
i=i+1
	
	
	printf("%d%d%d"h,i,j)
	return 0;
}
