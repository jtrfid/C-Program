#include <iostream>
#include<stdio.h>
{
	int a,n,square;
	0<n<10000;
	O<a<n;
	scanf("%d,%d",&a,&square);
	while a/2=z;
	square=a*a;
	printf("%d %d",a square);
	return 0;
	
	
	
	
	
	
	
}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	return 0;
}
