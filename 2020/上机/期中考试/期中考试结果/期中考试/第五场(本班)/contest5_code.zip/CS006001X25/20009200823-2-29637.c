#include<stdio.h>
int main()
{
	int a, b, c, s;
	scanf("%d %d %d",&a,&b,&c);
	if (a+b>c&&a+c>b&&b+c>a)
	{
	 	if(a*a+b*b==c*c)
		{
	 	s=a*b*1/2;
		 printf("%d",s);}
		 else if (a*a+c*c==b*b)
	 	{
		 s=a*c*1/2;
		 printf("%d",s);}
		 else if(a*a==b*b+c*c)
		 {s=b*c*1/2;
		 printf("%d",s);}
		 else{
	 	printf("normal");	}
	}else
	printf("no");
	return 0;
}
