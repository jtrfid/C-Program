#include<stdio.h>
int main()
{
	int i,s;int a=0,b=0,c=0;
	for(i=0;i<10000;i++)
	{
		s=getchar();
		if(s>='a'&&s<='z') b++;
		else if(s>='A'&&s<='Z') a++;
		else if(s>='0'&&s<='9') c++;
		else if(s='!') break;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
