#include<stdio.h>
int main()
{
	int d=0,x=0,s=0;
	char f;
	while(f!='!')
	{
		scanf("%c",&f);
		if('A'<=f&&f<='Z') d+=1;
		else if('a'<=f&&f<='z') x+=1;
		else if(f=='0'||f=='1'||f=='2'||f=='3'||f=='4'||f=='5'||f=='6'||f=='7'||f=='8'||f=='9') s+=1;
	}
	printf("%d %d %d",d,x,s);
}
