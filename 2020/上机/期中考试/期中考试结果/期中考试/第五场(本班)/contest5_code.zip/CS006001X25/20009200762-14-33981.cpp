#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
	int caps=0,xiao=0,num=0;
	char x;
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		scanf("%c",x);
		while(x!='!')
		{
		if('A'<=x&&x<='Z')
		caps++;
		if('a'<=x&&x<='z')
		xiao++;
		if('0'<=x&&x<='9')
		num++;
		if(x=='!')
		break;
		
		}
		
		printf("%d %d %d",caps,xiao,num);
	return 0;
}
