#include<stdio.h>
using namespace std;
int main(){
	int n,ansa,ansb,z,y;
	scanf("%d",&n);
	int m=n/2;
	for(int i=0;i<m;++i){
		ansa=m+i,ansb=m-i;
		for(int z=2;z<m+i;++z){
			if (ansa%z==0)break;
		}
		for(int y=2;y<m-i;++y){
			if(ansb%y==0)break;
		}
		if(ansa%z!=0&&ansb%y!=0){
			printf("%d %d",ansa,ansb);
			break;
		}
	}
	return 0;	
}
