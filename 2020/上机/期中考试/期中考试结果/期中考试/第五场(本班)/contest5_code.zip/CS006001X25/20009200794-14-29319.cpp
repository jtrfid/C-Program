#include<stdio.h>
int main(){
	char k;
	int cnt_da=0,cnt_xiao=0,cnt_num=0;
	while(k!='!'){
		scanf("%c",&k);
		if(k>='a' && k<='z'){
			cnt_xiao++;
		}	
		else if(k>='A' && k<='Z'){
			cnt_da++;
		}
		else if(k>='0' && k<='9'){
			cnt_num++;
		}
	}
	printf("%d %d %d",cnt_da,cnt_xiao,cnt_num);
	return 0;
}
