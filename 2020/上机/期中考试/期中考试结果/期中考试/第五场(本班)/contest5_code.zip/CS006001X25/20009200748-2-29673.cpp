#include"stdio.h"
int main()
{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);

	if(a + b > c&&a + c > b&&b + c > a)
	{
		if(a*a + b*b == c*c|| b*b + c*c == a*a||a*a +c*c ==b*b)
		{
			a=a<=b? a:b;
			b=b<=c? b:c;
			printf("%.0f",0.5*a*b);
			
		}
		else printf("normal");
		
	}
	else printf("no");
	
	return 0;
}
