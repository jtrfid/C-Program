#include<cstdio>
int t1,t2,t3;
int main()
{
	char c=getchar();
	while(c!='!')
	{
		if(c>='a'&&c<='z')t2++;else
		if(c>='A'&&c<='Z')t1++;else
		if(c>='0'&&c<='9')t3++;
		c=getchar();
	}
	printf("%d %d %d\n",t1,t2,t3);
}
