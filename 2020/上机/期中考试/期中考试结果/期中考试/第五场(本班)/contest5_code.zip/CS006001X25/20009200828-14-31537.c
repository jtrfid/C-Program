#include<stdio.h>
int main()
{
	char ch[1000];int a=0;int b=0;int c=0;int j=0;
	int i=0;
	do{
		scanf("%c",&ch[i]);
		i++;
	}while(ch[i-1]!='!');
	for(j=0;j<i-1;j++)
	{
		if(ch[j]>='A'&&ch[j]<='Z')
		a++;
		else if(ch[j]>='a'&&ch[j]<='z')
		b++;
		else if(ch[j]>='0'&&ch[j]<='9')
		c++;
	}
	printf("%d %d %d",a ,b,c);
	return 0;
}
