#include<stdio.h>

int main()
{
	int a,b,c;
	double s;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b>c&&a+c>b&&b+c>a){
		if(a*a+b*b==c*c){
			s=a*b/2.0;
			printf("%.2f",s);
		}
		else if(a*a+c*c==b*b){
			s=a*c/2.0;
			printf("%.2f",s);
		}
		else if(b*b+c*c==a*a){
			s=b*c/2.0;
			printf("%.2f",s);
		}
		else{
			printf("normal");
		}
	}
	else{
		printf("no");
	}
	return 0;
}
