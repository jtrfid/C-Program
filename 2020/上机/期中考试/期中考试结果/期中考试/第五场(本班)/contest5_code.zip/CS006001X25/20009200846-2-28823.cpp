#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
int A[5];
bool zhijiao(int a,int b,int c)
{
	if(a*a+b*b==c*c)return 1;
	return 0;
}
int a,b,c;
int main()
{
	scanf("%d%d%d",&A[1],&A[2],&A[3]);
	std::sort(A+1,A+4);
	a=A[1],b=A[2],c=A[3];
	if(zhijiao(a,b,c))printf("%d",(a*b)/2);
	else if(a+b>c&&a+c>b&&b+c>a)printf("normal");
	else printf("no");
	return 0;
}
