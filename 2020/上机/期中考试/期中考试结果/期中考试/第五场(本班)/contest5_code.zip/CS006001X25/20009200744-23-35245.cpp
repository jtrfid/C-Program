#include<stdio.h>
int main()
{ 
    int a,b,c,d;
    scanf("%d",&a);
    for(b=1;b<=a;b++)
    {
    	for(c=1;c<=a;c++)
    	{
    		for(d=1;d<=c;d++)
    		{
    			if(c+d==a&&c%b==0&&d%b==0)
    			{
    				printf("%d %d",c,d);
    			}
    		}
    	    
		}
	}
    return 0;
}
