#include<stdio.h>
int main()
{
	int n,i,s;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(i%2==0)
		s=i*i;
		printf("%d %d",i,s);
	}
	return 0;
}
