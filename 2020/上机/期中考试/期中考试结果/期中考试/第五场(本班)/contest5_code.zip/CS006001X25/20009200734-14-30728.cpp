#include <stdio.h>
int main()
{
    int x,y,z;
	char a1;
    for(a1=1,x=0,y=0,z=0;a1!=33;)
    {
    	scanf("%c",&a1);
    	if(a1>=65&&a1<=90)
    	x++;
    	if(a1>=97&&a1<=122)
    	y++;
    	if(a1>=48&&a1<=57)
    	z++;
    }
    printf("%d %d %d",x,y,z);
	return 0;
}
