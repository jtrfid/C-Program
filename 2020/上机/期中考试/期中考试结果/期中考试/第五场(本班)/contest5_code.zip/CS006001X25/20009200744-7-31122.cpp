#include<stdio.h>
int main()
{
	int a,i;
	scanf("%d",&a);
	for(i=1;i<a;i++)
	{
		i%2==0;
		
	}
	printf("%d %d",i,i*i);
	return 0;
}
