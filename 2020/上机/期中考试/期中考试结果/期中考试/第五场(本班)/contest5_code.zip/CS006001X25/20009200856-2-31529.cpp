#include<stdio.h>
#include<math.h>
int main (){
	int a,b,c,p,s;
	scanf("%d %d %d",&a,&b,&c);
    p=1/2*(a+b+c);
	if (a+b<=c||a+c<=b||b+c<=a) printf("no");
	else if(a*a==b*b+c*c||b*b=a*a+c*c||c*c=a*a+b*b)
	s=sqrt(p*(p-a)*(p-b)*(p-c));
	printf("%d",s);
	else printf("normal");
	
	
	
	
	
	
	
	return 0;
}
