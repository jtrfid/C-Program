#include <stdio.h>
int main()
{
    int n,i,s;
    scanf("%d",&n);
    for(i=2;i<=n;i=i+2)
    {
    	s=i*i;
    	printf("%d %d\n",i,s);
    }
	return 0;
}
