#include<stdio.h>
int main (){
	char A[1000];
	int a=0,b=0,c=0,i;
	for(int i=0;i<=1000;i++){
		scanf("%s",&A[i]);
	}
	while(A[i]!='!'){
		if (A[i]>='A'&&A[i]<='Z'){
			a++;
			printf("%d",a); 
		} 
		else if(A[i]>='a'&&A[i]<='z'){
			b++;
			printf("%d",b);
		}
		else if(A[i]>='0'&&A[i]<='9'){
			c++;
			printf("%d",c);
		}
		break;
	}
	
	
	
	return 0;
} 
