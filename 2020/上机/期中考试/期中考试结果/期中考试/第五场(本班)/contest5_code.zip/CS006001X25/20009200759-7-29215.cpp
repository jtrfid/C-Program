#include<stdio.h>
int main()
{
	int n,i,a;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(i%2==0)
		{
			printf("%d %d\n",i,i*i);
		}
		else continue;
	}
	return 0;
}
