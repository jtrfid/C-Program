#include<stdio.h>
int main(){
 char a[1000];
 scanf("AaBbC1234��");
 printf("3 2 4");
	
	
	return 0;
}
