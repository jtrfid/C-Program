#include<stdio.h>
int main()
{
	int n,i,x,k;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		x=i%2;
		if(x==0)
		{
			k=i*i;
			printf("%d %d\n",i,k);
		}
	}
	return 0;
}
