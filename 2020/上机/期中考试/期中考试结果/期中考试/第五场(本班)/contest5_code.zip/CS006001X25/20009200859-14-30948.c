#include<stdio.h>
int main(){
	char a[100];
	int i;
	int x=0,y=0,z=0;
	for(i=0;i<100;i++){
		scanf("%c",&a[i]);
		if((int)(a[i])>64 && (int)(a[i])<91)x++;
		if((int)(a[i])>96 && (int)(a[i])<123)y++;
		else if((int)(a[i])>47 && (int)(a[i])<58)z++;
		if(a[i]=='!')break;
		
	}
	

	printf("%d %d %d",x,y,z);

	return 0;
}
