#include <stdio.h>

int main ()
{
	char a;
	int D=0;
	int X=0;
	int S=0;
	
	
	scanf ("%c",&a);
	while (a!=33){
		if (a>=65 && a<=90){
			D++;
		}
		
		if (a>=97 && a<=122){
			X++;
		}
		
		if (a>=48 && a<=57){
			S++;
		}
		
		scanf ("%c",&a);
	}
	
	printf ("%d %d %d",D,X,S);
	return 0;
}
