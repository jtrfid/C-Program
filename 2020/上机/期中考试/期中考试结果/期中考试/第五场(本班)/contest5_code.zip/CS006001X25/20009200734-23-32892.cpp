#include <stdio.h>
int main()
{
    int a,i1,i2,r1,r2;
	scanf("%d",&a); 
    for(i1=a/2,i2=a/2;i1>0,i2>0;i1++,i2--)
    {
    	for(r1=2;r1<i1;r1++)
		{
			if(i1%r1!=0)
			continue;
			else  
			break;
			for(r2=2;r2<i2;r2++)
			{
			if(i2%r2!=0)
			continue;
			else
			break;
			}
		}
		printf("%d %d",i2,i1);
		break;
    }
	return 0;
}
