#include<stdio.h>
int main()
{
	char a='0';
	int b=0, c=0, d=0;
	while(a!='!')
	{
		scanf("%c", &a);
		if(a>=97 && a<=122) b=b+1;
		if(a>=65 && a<=90) c=c+1;
		if(a>=48 && a<=57) d=d+1;		
	}
	printf("%d %d %d", c, b, d);
	return 0;
}
