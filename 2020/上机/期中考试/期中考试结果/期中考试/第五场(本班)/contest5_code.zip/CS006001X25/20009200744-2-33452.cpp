#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b<=c||a+c<=b||b+c<=a)
	{ 
	    printf("no");
	}
	
	else if(a*a+b*b==c*c)
	{
		printf("%.0f",a*b*1.0/2);
		
	}
	else if(a*a+c*c==b*b)
	{
		printf("%.0f",1.0*a*c/2);
		
	}
	else if(c*c+b*b==a*a)
	{
		printf("%.0f",1.0*c*b/2);
		
	}
	else
	{
		printf("normal");
	}
	return 0;
}
