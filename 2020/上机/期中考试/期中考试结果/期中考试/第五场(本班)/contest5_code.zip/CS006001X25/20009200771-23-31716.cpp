#include<stdio.h>

int main()
{
	int n,i,j,a,m;
	scanf("%d",&n);
	for(i=n/2;i>=1;i--){
		for(j=2;j<i;j++){					//�ж�i�ǲ������� 
			if(i%j==0){
				break;
			}
		}
		if(j==i){							//˵��i������ 
			a=n-i;
			for(m=2;m<a;m++){
				if(a%m==0){
				break;
			   }
			}
			if(m=a){
				printf("%d %d\n",i,a);
				break;
			}
		}
	}
	return 0;
}
