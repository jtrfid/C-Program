#include<stdio.h>
int main()
{
	int d=0,x=0,s=0;
	char a;
	while(1)
	{
		scanf("%c",&a);
		if(a=='!')
	        break;
		if(a<58)
		    x++;
		if(a>=58&&a<108)
		    d++;
		if(a>=108)
		    s++;		      
	}
	printf("%d %d %d",d,x,s);
	return 0;
}
