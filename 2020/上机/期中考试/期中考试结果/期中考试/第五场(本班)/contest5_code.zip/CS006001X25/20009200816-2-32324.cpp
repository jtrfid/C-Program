#include<math.h>
#include<stdio.h>
int main()
{
	int a,b,c;
	float p,area;
    scanf("%d%d%d",&a,&b,&c);
    p=(a+b+c)/2.0;
	if(a+b>c&&a+c>b&&b+c>a&&a-b<c&&a-c<b&&b-c<a)
	{
		if(a*a+b*b==c*c||a*a+c*c==b*b||b*b+c+c==a*a)
		{
			area=sqrt(p*(p-a)*(p-b)*(p-c));
			printf("%f",area);	
		}
		else
		{
			printf("normal");
		}
	}
	else
	{
		printf("no");
	}
	return 0;
}
