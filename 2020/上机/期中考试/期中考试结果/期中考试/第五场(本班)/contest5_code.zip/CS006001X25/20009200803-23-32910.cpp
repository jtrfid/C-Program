#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	b=a/2,c=a/2;
		if(b%2!=0)
		{
			if(b!=1)
			{
			printf("%d %d",b,c);
		    }
		    else
			return 0;
		}
		else if(b==2)
		{
			printf("%d %d",b,c);
		}
		else
		{
			b=b+1;
			c=c-1;
			printf("%d %d",c,b);
	    }
	return 0;
}
