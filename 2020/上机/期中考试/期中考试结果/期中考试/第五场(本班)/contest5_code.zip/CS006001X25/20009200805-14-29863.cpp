#include<stdio.h>
int main()
{
	char ch;
	int a=0,b=0,c=0;
	while(1)
	{
		ch=getchar();
		if(ch>=65&&ch<=90)
		{
			a++;
		}
		if(ch>=97&&ch<=122)
		{
			b++;
		}
		if(ch>='0'&&ch<='9')
		{
			c++;
		}
		if(ch=='!')
		{
			break;
		}
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
