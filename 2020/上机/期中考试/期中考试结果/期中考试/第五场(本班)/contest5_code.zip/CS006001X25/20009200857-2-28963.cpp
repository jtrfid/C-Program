#include<stdio.h>
int main()
{
	int a,b,c;
	scanf ("%d %d %d",&a,&b,&c);
	if (a+b>c&&a+c>b&&b+c>a)
	{
		if (a*a+b*b==c*c)
		{
			printf ("%1.f",0.5*a*b);
		}
		if (a*a+c*c==b*b)
		{
			printf ("%1.f",0.5*a*c);
		}
		if (c*c+b*b==a*a)
		{
			printf ("%1.f",0.5*c*b);
		}
		if (a*a+b*b!=c*c&&a*a+c*c!=b*b&&c*c+b*b!=a*a)
		{
			printf ("normal");
		}
	}
	else
	{
		printf ("no");
	}
	return 0;
}
