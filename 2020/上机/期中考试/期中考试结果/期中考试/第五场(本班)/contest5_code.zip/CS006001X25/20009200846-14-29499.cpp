#include<stdio.h>
#include<stdlib.h>
int ans1,ans2,ans3;
char a;
int main()
{
	while(1)
	{
		scanf("%c",&a);
		if(a=='!')break;
		if(a<='Z'&&a>='A')ans1++;
		else if(a<='z'&&a>='a')ans2++;
		else if(a<='9'&&a>='0')ans3++;
	}
	printf("%d %d %d",ans1,ans2,ans3);
	return 0;
}
