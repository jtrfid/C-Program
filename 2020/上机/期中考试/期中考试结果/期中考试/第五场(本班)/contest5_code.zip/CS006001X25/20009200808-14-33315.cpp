#include<stdio.h>
int main(){
	char n;
	int i,a=0,b=0,c=0;
	scanf("%c",&n);
	for(i=1;i<=n;i++){
		if(i>=65&&1<=90)    a=a+1;
		if(i>=97&&i<=122)    b=b+1;
		if(i>=0&&i<=9)    c=c+1;
	}
	printf("%d %d %d",a,b,c);
	return 0;
}
