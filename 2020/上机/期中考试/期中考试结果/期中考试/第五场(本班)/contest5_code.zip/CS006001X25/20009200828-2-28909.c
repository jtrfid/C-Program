#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d %d %d",&a,&b,&c);
	if(a+b>c&&a+c>b&&b+c>a)
	{
		if(a*a+b*b==c*c)
		printf("%d",a*b/2);
		else if(a*a+c*c==b*b)
		printf("%d",a*c/2);
		else if(b*b+c*c==a*a)
		printf("%d",b*c/2);
		else
		printf("normal");
	}
	else
	printf("no");
	return 0;
}
