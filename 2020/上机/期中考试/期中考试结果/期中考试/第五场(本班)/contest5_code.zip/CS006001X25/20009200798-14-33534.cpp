#include<stdio.h>
int main()
{
	int x,i,m,p,q;
	char n;
	for(i=1;i<=x;i++)
	{
		scanf("%c",&n);
		if(n>26&&n<54)
		m++;
		if(n>1&&n<26)
		p++;
		if(n>84&&n<116)
		q++;	
	}
	printf("%d %d %d",m,p,q);
	return 0;
}
