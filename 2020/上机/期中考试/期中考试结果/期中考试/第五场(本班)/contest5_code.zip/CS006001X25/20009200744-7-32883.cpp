#include<stdio.h>
int main()
{
	int a,i;
	0<=a&&a<=1000;
	scanf("%d",&a);
	for(i=2;i<=a;i++)
	{
		i%2==0;
		printf("%d %d\n",i,i*i);
	}
	return 0;
}
