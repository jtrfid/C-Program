#include<stdio.h>
#include<stdlib.h>
int n;
int main()
{
	scanf("%d",&n);
	for(int i=n/2;i>1;i--)
	{
		bool pr=0;
		for(int j=2;j<i;j++)
		  if(i%j==0){pr=1;break;}
		if(pr)continue;
		for(int j=2;j<n-i;j++)
		  if((n-i)%j==0){pr=1;break;}
		if(pr)continue;
		printf("%d %d",i,n-i);
		break;
	}
	return 0;
}
