#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;int a,b;
	for(i=n/2;i>0;i--)
	{
		for(j=1,a=0;j<i;j++)
		{
			if(i%j==0)
			a++;
		}
		for(j=1,b=0;j<n-i;j++)
		{
			if((n-i)%j==0)
			b++;
		}	
		if(a==1&&b==1)
		break;
	}
	printf("%d %d",i,n-i);
	return 0;
}
