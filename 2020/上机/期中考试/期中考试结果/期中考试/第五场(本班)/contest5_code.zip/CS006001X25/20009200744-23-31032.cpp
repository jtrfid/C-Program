#include<stdio.h>
int main()
{ 
    int a,b,c,d;
    scanf("%d",&a);
    for(b=1;b<=a;b++)
    {
    	c%b!=0;
    	d%c!=0;
    	c+d==a;
    }
    printf("%d %d",c,d);
    return 0;
}
