#include<stdio.h>
int main()
{
    int n,a,b,i,j;
    scanf("%d",&n);
    a=n/2;
    b=n/2;
    for(;;a--,b++)
    {
        for(i=a/2;i>0;i--)
        {
            if(a%i==0)
            {
                break;
            }
        }
        for(j=b/2;j>0;j--)
        {
            if(b%j==0)
            {
                break;
            }
        }
        if(i==1&&j==1)
        {
            printf("%d %d",a,b);
            break;
        }
    }
    return 0;
}
