#include<stdio.h>
int main(){
	int n,a,b,i,j;
	scanf("%d",&n);
	for(i=2;i<=n;i++){
		for(j=2;j<=i;j++){
			if(i%j==0)    a=j;
			if(i=j)    a=i;
		}
	}
	b=n-i;
	if(a>b)    printf("%d %d",b,a);
	else    printf("%d %d",a,b);
	return 0;
}
