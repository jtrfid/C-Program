#include<stdio.h>
int mix(int mix)
{int j;int x=0;
for(j=2;j<mix;j++)
{if(mix%j==0)break;
else x=1;
}
return x;}
int main()
{
	int i,n,j;
	j=n/2;
	scanf("%d",&n);
	for(i=n/2;i<1000;i++)
	while(j>0){j--;
	
	if(i+j==n&&mix(i)==1&&mix(j)==1)
	
	{
	printf("%d %d\n",j,i);
	break;
}}
	return 0;
}
