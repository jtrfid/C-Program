#include <stdio.h>

char __get(){
	char c;
	scanf("%c",&c);
	return c;
}

int main(){
	char ch;
	int a=0,b=0,c=0;
	while ((ch=__get())!='!'){
		if (ch>='A'&&ch<='Z'){
			a++;
		}else if (ch>='a'&&ch<='z'){
			b++;
		}else if (ch>='0'&&ch<='9'){
			c++;
		}
	}
	printf("%d %d %d\n",a,b,c);
	return 0;
}
