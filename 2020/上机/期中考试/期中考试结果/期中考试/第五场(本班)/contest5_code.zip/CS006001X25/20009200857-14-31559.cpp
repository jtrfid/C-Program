#include<stdio.h>
int main()
{
	int a=0,b=0,c=0;
	char n;
	for (int i=0;;i++)
	{
		scanf ("%c",&n);
		if (n=='!')
		{
			break;
		}
		if ('A'<=n&&n<='Z')
		{
			a=a+1;
		}
		if ('a'<=n&&n<='z')
		{
			b=b+1;
		}
		if ('0'<=n&&n<='9')
		{
			c=c+1;
		}
	}
	printf ("%d %d %d",a,b,c);
	return 0;
} 
