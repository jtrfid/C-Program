#include <stdio.h>
int main()
{int i,max;
for(i=1;i<=max;i++)
{
scanf("%d",&max);
if(i%2==0)
printf("%d %d\n",i,i*i);
}
return 0;
}
