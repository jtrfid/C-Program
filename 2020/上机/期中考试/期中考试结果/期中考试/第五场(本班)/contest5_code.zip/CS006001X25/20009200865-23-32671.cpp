#include<stdio.h>
int sushu(int a)
{
	if(a==2)
	    return 1;
	if(a>2)
	{
		int i;
		for(i=2;i<a;i++)
		{
			if(a%i==0)
			{
			    return 0;
			}    
			break;
		}
		return 1;
	}	    
}
int main()
{
	int a,m,n,i;
	scanf("%d",&a);
	for(i=a/2;i>=2;i--)
	{
	    if(sushu(i))
		{
			int c=a-i;
			if(sushu(c))
			{
				m=i;
				n=c;
				break;
			}
		}    	
	}
	printf("%d %d",m,n);
	return 0;
}



