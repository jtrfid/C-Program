#include<stdio.h>
int main()
{
	char ch;
	int b,c,d,a;
	b=0;c=0;d=0;
	while(a!=33)
	{
		scanf("%c",&ch);
		a=(int)ch;
		if(a>=65&&a<=90)
		{
			b++;
		}
		else if(a>=97&&a<=122)
		c++;
		else
		d++;
	}
	printf("%d %d %d",b,c,d-1);
}
