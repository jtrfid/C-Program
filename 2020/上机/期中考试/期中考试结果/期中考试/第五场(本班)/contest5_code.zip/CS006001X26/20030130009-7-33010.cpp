#include<stdio.h>
int main()
{
	int x,y,n;
	scanf("%d",&n);
	for(x=2;x<=n;x+=2)
	{
		y=x*x;
		printf("%d %d\n",x,y);
	}
}
