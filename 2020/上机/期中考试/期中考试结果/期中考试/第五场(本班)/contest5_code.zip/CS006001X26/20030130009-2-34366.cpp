#include<stdio.h>
int main()
{
	int x,y,z,d;
	scanf("%d%d%d",&x,&y,&z);
	
	if(x+y>z&&x+z>y&&y+z>x)
	{
		if(x*x+y*y==z*z)
		printf("%d",x*y/2);
		else if(x*x+z*z==y*y)
		printf("%d",x*z/2);
		else if(z*z+y*y==x*x)
		printf("%d",z*y/2);
		else
		printf("normal");
		
	}
	else printf("no");
}
