#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c;
	scanf("%d%d%d",a,b,c);
	if(a+b>c,a-b<c)
	{
		if(a*a+b*b==c*c)
		{
			printf("%d",a*b/2);
		}
		else
		{
			printf("normal");
		}
	}
	else
	{
		printf("no");
	}
}
