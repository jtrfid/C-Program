#include <stdio.h>

int main() {
	char x;
	int y, z = 0;
	while ((x = getchar()) != '!') {
		if (x >= '0'&x <= '9') {
			z += (x - 48);
		}

	}
	if (z != 0) {
		printf("%d", z );
	} else {
		printf("NAN");
	}
	return 0;
}