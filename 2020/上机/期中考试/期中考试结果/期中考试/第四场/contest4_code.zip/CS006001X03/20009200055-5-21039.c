#include <stdio.h>

int main() {
	float money = 0.0;
	float pay = 0.0;
	scanf("%f", &money);
	if (money <= 3000) {
		pay = money * 0.005;
	} else {
		if (money <= 5000) {
			pay = money * 0.01;
		} else {
			if (money <= 10000) {
				pay = money * 0.015;
			} else
				pay = money * 0.02;
		}
	}
	printf("%.1f", pay);
	return 0;
}
