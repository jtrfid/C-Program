#include <stdio.h>
int main() {
  float s,m;
  scanf("%f",&s);
  if (s>0&&s<50000)	{
  	if (s<=3000)
	m=0.005*s;
	else if (s<=5000)
	     m=0.01*s;
	     else if (s<=10000)
	          m=0.015*s;
	          else m=0.02*s;
	printf("%.1f",m);
	return 0;          
}



