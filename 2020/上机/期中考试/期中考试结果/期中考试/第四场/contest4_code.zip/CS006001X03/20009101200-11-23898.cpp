#include <stdio.h>

int main() {
	int n, z = 0;
	scanf("%d", &n);
	for (; n > 0;) {

		if (n > 0) {
			z++;
		}
		n /= 10;
	}

	printf("%d", z  );
	return 0;
}