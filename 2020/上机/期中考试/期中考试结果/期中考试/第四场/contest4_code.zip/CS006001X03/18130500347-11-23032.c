#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a, b, c, d = 0;
	scanf("%d", &a);
	if (a==0)
	{
		d=1;
		printf ("%d",d);
	}
	else
	{
	for (b = 1; b <= 1000000000; b *= 10) {
		c = a / b;
		if (c >= 1)
			d++;
	}
	
	printf("%d", d);
	}
	return 0;
}