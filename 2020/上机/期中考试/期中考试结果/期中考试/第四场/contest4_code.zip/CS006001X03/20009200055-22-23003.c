#include <stdio.h>

int main() {
	int a = 0, b = 0;
	scanf("%d %d", &a, &b);
	if (a > b) {
		a = a ^ b;
		b = a ^ b;
		a = a ^ b;
	}
	if (a < 0)
		a = 0;
	int i = 0;
	for (i = a; i <= b; ++i) {
		int product = 1;
		int sum = 0;
		if (i == 0) {
			printf("0 ");
			continue;
		}
//		int isReq = 1;
		int p = i;
		while (p) {
			sum += p % 10;
			p /= 10;
		}
		p = i;
		while (p) {
			product *= p % 10;
			p /= 10;
		}
		if (sum == product)
			printf("%d ", i);
	}
	return 0;
}
