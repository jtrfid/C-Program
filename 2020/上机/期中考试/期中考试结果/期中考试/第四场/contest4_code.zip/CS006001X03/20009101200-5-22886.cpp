#include <stdio.h>

int main() {
	int x, y = 1, z = 1;
	scanf("%d", &x);
	for (; x > 0; x /= 10) {
		if (x > 0) {
			z++;
		}
	}

	printf("%d", z - 1 );
	return 0;
}