#include <stdio.h>

int main() {
	int x, y;
	scanf("%d", &x);
	if (x < 10) {
		y = 1;
	} else {
		for (y = 1; x >= 10; y++) {
			x /= 10;
		}
	}
	printf("%d", y);
	return 0;
}