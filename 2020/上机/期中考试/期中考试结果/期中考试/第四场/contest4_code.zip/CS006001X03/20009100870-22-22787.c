#include <stdio.h>

int main() {
	int ss = 0, ms = 1, a, b, te;
	scanf("%d%d", &a, &b);
	int max = a > b ? a : b, min = a < b ? a : b;
	for (int i = min; i < max + 1; i++) {
		te = i;
		while (te) {
			ss += (te % 10);
			ms *= (te % 10);
			te /= 10;
		}
		if (ss == ms)
			printf("%d ", i);
		ss = 0;
		ms = 1;
	}
}