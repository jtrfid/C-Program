#include <stdio.h>

int c(int t) {
	int  k;
	if (t < 10) {
		return t;
	} else {
		for (k = 1; t > 0; t /= 10) {
			k *= (t % 10);
		}
		return k;
	}
}

int h(int t) {
	int k;
	if (t < 10) {
		return t;
	} else {
		for (k = 0; t > 0; t /= 10) {
			k += (t % 10);
		}
		return k;
	}
}

void d(int t) {
	if (c(t) == h(t)) {
		printf("%d ", t);
	}
}

int main() {
	int a, b, x, y, t;
	scanf("%d %d", &x, &y);
	a = x > y ? y : x;
	b = x > y ? x : y;
	for (t = a; t <= b; t++) {
		d(t);
	}
	return 0;
}