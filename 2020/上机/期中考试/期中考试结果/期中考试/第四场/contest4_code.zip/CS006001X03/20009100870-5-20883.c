#include <stdio.h>

int main() {
	float fee;
	scanf("%f", &fee);
	if (fee > 10000)
		printf("%.1f", 0.02 * fee);
	else if (fee > 5000)
		printf("%.1f", 0.015 * fee);
	else if (fee > 3000)
		printf("%.1f", 0.01 * fee);
	else
		printf("%.1f", 0.005 * fee);
}