#include <stdio.h>

int main() {
	double x, t;
	scanf("%lf", &x);
	if (x >= 0.0 && x <= 3000.0) {
		t = x * 0.005;
		printf("%.1f", t);
	} else if (x > 3000.0 && x <= 5000.0) {
		t = 0.01 * x;
		printf("%.1f", t);
	} else if (x > 5000.0 && x <= 10000.0) {
		t = 0.015 * x;
		printf("%.1f", t);
	} else {

		t = 0.02 * x;
		printf("%.1f", t);
	}
	return 0;
}