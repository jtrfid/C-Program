#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a, b, min, max, c, d, h1, h2, h3, h4, h5, h6, h7, h8, h9;
	scanf("%d %d", &a, &b);
	max = (a > b ? a : b);
	min = (a > b ? b : a);
	for (c = min; c <= max; c++) {
		printf("%d ", c);
		if (c == 9)
			break;
	}												//1-10


	return 0;
}