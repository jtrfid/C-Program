#include <stdio.h>

int main() {
	int n, y = 1, z = 1;
	scanf("%d", &n);
	for (; n > 0;) {
		n /= 10;
		if (n > 0) {
			z++;
		}
	}

	printf("%d", z );
	return 0;
}