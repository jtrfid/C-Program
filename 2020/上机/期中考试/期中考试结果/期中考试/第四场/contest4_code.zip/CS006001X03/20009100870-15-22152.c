#include <stdio.h>
#include <ctype.h>

int main() {
	char ch;
	int flag = 0, sum = 0;
	scanf("%c", &ch);
	while (ch != '!') {
		if (isdigit(ch)) {
			sum += (ch - '0');
			flag = 1;
		}
		scanf("%c", &ch);
	}
	if (!flag)
		printf("NAN");
	else
		printf("%d", sum);
}