#include <stdio.h>

int main() {
	double x, y;
	scanf("%lf", &x);
	if (x <= 3000) {
		y = x * 0.005;
	} else if (x > 3000 && x <= 5000) {
		y = x * 0.01;
	} else if (x > 5000 && x <= 10000) {
		y = x * 0.015;
	} else if (x > 10000) {
		y = x * 0.02;
	}
	printf("%.1f", y);
	return 0;
}
