#include <iostream>
using namespace std;
char x;
int ans = 0;

int main() {
	while (cin >> x) {
		ans++;
	}
	cout << ans;
	return 0;
}