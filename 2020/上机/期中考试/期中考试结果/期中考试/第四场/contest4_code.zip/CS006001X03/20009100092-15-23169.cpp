#include <stdio.h>

int main() {
	char x[1000];
	int t, k, m = 0, sum = 0;
	for (t = 0; t <= 1000; t++) {
		scanf("%c", &x[t]);
		if (x[t] >= 48 && x[t] <= 57) {
			k = x[t] - 48;
			sum += k;
			m++;
		} else if (x[t] == '!') {
			break;
		} else
			continue;
	}
	if (m == 0) {
		printf("NAN");
	} else
		printf("%d", sum);
	return 0;
}