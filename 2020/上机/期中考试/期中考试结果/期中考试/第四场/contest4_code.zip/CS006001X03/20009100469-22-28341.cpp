#include <stdio.h>
int main() {
	int a, b, t, i, sum = 0, mul = 1, l, j;
	scanf("%d %d", &a, &b);
	if (a > b) {
		t = b;
		b = a;
		a = t;
	}
	for (i = a; i < b; i++) {
		for (j = 0; j < 10; j++) {
			l = i % 10;
			i = i / 10;
			if (l == 0)
				break;
			sum =sum+ l;
			mul =mul*l;
			
		}
		if (sum == mul)
			printf("%d ", i);
	}
	return 0;
}

