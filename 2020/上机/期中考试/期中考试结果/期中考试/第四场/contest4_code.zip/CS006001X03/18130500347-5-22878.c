#include <stdio.h>
#include <stdlib.h>


int main() {
	float fee, df;
	scanf("%f", &fee);
	if (fee <= 3000) {
		df = fee * 0.005;
	} else if (fee <= 5000) {
		df = fee * 0.01;
	} else if (fee <= 10000) {
		df = fee * 0.015;
	} else {
		df = fee * 0.02;
	}
	printf("%0.1f", df);

	return 0;
}