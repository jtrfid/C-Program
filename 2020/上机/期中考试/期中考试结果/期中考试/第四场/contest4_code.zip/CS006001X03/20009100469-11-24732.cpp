#include <stdio.h>

int main() {
	int n, count, i;
	scanf("%d", &n);
	if (n >= 0 && n <= 100000000) {
		for (i = 0, count = 0; i < 10; i++) {
			n = n / 10;
			count = count + 1;
			if (n == 0)
				break;
		}
		printf("%d", count);
	}
	return 0;
}