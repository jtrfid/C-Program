#include <stdio.h>
#include <stdlib.h>

int main() {
	int b, sum = 0, sum2 = 0;
	char a[100];
	for (b = 0; ; b++) {
		scanf("%c", &a[b]);
		if (a[b] == 33)
			break;
		else if (a[b] >= 48 && a[b] <= 57) {
			sum += (a[b] - 48);
			sum2 += 1;
		} else
			sum += 0;

	}
	if (sum2 == 0)
		printf("NAN");
	else
		printf("%d", sum);
	return 0;
}