#include <stdio.h>

int main() {
	int num = 0;
	int wei = 0;
	scanf("%d", &num);
	if (num == 0) {
		printf("1");
	} else {
		while (num) {
			num /= 10;
			++wei;
		}
		printf("%d", wei);
	}

	return 0;
}
