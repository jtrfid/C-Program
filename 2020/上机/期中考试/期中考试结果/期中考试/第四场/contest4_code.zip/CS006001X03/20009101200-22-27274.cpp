#include <stdio.h>

int main() {
	int a, b;
	scanf("%d %d", &a, &b);
	if (a > b) {
		int i = a;
		for (; i >= b; i--) {
			int j, z = 0, w = 1, t = 0;
			while (i > 0) {
				int m;
				m = i % 10;
				i  /= 10;
				w *= m;
				z += m;
			}
			if (w == z) {
				printf("%d\t", &i);
			}
		}
	} else {
		int i = b;
		for (; i >= a; i--) {
			int j, z = 0, w = 1, t = 0;
			while (i > 0) {
				int m;
				m = i % 10;
				i  /= 10;
				w *= m;
				z += m;
			}
			if (w == z) {
				printf("%d\t", &i);
			}

		}
	}
	return 0;
}