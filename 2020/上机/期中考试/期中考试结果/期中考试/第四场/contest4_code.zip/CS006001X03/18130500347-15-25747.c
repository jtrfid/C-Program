#include <stdio.h>
#include <stdlib.h>

int main() {
	int b, sum = 0, sum2 = 0;
	char a[100];
	for (b = 0; ; b++) {
		scanf("%c", &a[b]);
		sum += 0;
		sum2 += 1;
	} else if (a[b] >= 49 && a[b] <= 57) {
		sum += (a[b] - 48);
		sum2 += 1;
	} else
		sum += 0;
	if (a[b] == 33)
		break;
}
if (sum2 == 0)
	printf("NAN");
else
	printf("%d", sum);
return 0;
}