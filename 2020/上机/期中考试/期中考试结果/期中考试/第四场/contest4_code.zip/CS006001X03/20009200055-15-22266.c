#include <stdio.h>

int main() {
	char ch = 0;
	int flag = 0;
	int sum = 0;
	while (ch != '!') {
		scanf("%c", &ch);
		if (ch >= '0' && ch <= '9') {
			flag = 1;
			sum += ch - '0';
		}
	}
	if (flag == 0)
		printf("NAN");
	else
		printf("%d", sum);
	return 0;
}
