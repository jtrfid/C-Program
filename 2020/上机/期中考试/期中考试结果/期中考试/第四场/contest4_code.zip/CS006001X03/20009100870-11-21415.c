#include <stdio.h>

int main() {
	long int n;
	int count = 0;
	scanf("%ld", &n);
	if (n == 0)
		printf("%d", 1);
	else {
		while (n) {
			count++;
			n /= 10;
		}
		printf("%d", count);
	}
}