#include <stdio.h>

int main() {
	int x, y = 1, z = 1;
	scanf("%d", &x);
	while (x > 0 ) {
		x /= 10;
		y ++ ;
		z++;

	}
	printf("%d", z);
	return 0;
}