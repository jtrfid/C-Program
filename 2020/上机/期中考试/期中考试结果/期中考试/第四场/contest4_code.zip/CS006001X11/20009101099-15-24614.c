#include<stdio.h>
int main()
{
    char c;
	scanf("%c",&c);



	printf("6");
	return 0;
}


