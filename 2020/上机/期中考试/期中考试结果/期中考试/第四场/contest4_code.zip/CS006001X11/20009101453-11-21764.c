#include<stdio.h>
int main()
{
	int n,ws;
	scanf("%d",&n);
	for(ws=1;;ws++)
	{
		n=n/10;
		if(n==0)
			break;
	}
	printf("%d",ws);
	return 0;
}