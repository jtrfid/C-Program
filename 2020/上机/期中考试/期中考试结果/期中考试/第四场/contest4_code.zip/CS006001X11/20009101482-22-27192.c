#include<stdio.h>
int main()
{
	long a,b,t,i,x,y,temp,c;
	scanf("%d%d",&a,&b);
	if(b<a)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		temp=i;
		x=0;
		y=1;
		while(temp>0)
		{
			c=temp%10;
			x=x+c;
			y=y*c;
			temp=temp/10;
		}
		if(x==y&&i>=0)printf("%d ",i);
	}





}