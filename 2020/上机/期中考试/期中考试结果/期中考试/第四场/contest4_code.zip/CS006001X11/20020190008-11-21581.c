#include<stdio.h>
int main()
{
	int a,i;
	scanf("%d",&a);
	i=0;
	if(a==0)
		i=1;
	else
	{
	while(a!=0)
	{
		a=a/10;
		i++;
	}
	}


	printf("%d\n",i);
	return 0;
}