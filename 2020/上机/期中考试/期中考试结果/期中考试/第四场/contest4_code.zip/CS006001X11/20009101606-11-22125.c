#include<stdio.h>

int main()
{
	int a;
	int c=0;
	scanf("%d",&a);
	do
	{
		a=a/10;
		c++;
	}while(a!=0);
	printf("%d",c);
	return 0;
}