#include<stdio.h>
int main()
{
	float a;
	scanf("%f",&a);
	if(a<=3000)
		printf("%.1f",0.005*a);
	else if(a<=5000)
		printf("%.1f",0.01*a);
	else if(a<=10000)
		printf("%.1f",0.015*a);
	else
		printf("%.1f",0.02*a);


return 0;
}