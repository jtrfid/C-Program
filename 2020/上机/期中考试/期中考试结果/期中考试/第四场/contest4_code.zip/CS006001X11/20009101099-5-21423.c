#include<stdio.h>
int main()
{
	double n,m;
	scanf("%lf",&n);
	if(n<=3000)
	{
		m=n*0.005;
	}
	else if(n<=5000)
	{
		m=n*0.01;
	}
	else if(n<=10000)
	{
		m=n*0.015;
	}
	else
	{
		m=n*0.02;
	}
	printf("%.1f",m);
	return 0;
}

