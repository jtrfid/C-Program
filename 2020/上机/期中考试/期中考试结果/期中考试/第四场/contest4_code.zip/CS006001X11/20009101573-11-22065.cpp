#include<stdio.h>
#include<math.h>
int main(){
    int n,i,count=0,e=10;
	scanf("%d",&n);
    while(1){
	    i=n%e;
		e=e*10;
		count++;
		if(i==n)
			break;

	}
	printf("%d",count);
}