#include <stdio.h>
int main()
{
	float money,fee;
	scanf("%f",&money);
	if(money<=3000)
		fee=money*0.005;
	else if(money<=5000)
		fee=money*0.01;
	else if(money<=10000)
		fee=money*0.015;
	else
		fee=money*0.02;
	printf("%.1f",fee);
	return 0;
}
