#include<stdio.h>
#include<string.h>
int main()
{
	char str[100];
	int sum=0,i;
	scanf("%s!",&str[100]);
	for(i=0;i<100;i++)
	{
		if(str[i]>=48&&str[i]<=58)
		{
			str[i]=str[i]-48;
			sum=sum+str[i];
		}
	}
	if(sum==0)
		printf("NAA");
	else
		printf("%d",sum);
}
