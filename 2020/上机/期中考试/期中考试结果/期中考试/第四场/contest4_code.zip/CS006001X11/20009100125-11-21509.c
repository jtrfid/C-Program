#include<stdio.h>
int main()
{
	int n,d=0;
	scanf("%d",&n);
	if (n==0) d=1;
	while (n)
	{
		d++;
		n/=10;
	}
	printf("%d",d);
}