#include<stdio.h>
int main()
{
	int a,b,t,k,i,jia[100000],chen[100000];
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		k=i;
		jia[i]=k%10;
		while(k/10!=0)
		{
			jia[i]=jia[i]+k/10%10;
			k=k/10;
		}
	}
	for(i=a;i<=b;i++)
	{
		k=i;
		chen[i]=k%10;
		while(k/10!=0)
		{
			chen[i]=chen[i]*(k/10%10);
			k=k/10;
		}
	}
	for(i=a;i<=b;i++)
	{
		if(chen[i]==jia[i]&&i>=0)
			printf("%d ",i);
		else ;
	}
	return 0;
}


