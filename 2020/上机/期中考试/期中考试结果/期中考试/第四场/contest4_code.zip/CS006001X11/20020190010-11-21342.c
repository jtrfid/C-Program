#include<stdio.h>
int main()
{
	int n,w;
	scanf("%d",&n);
	w=0;
	if(n==0) w=1;
	else while(n>0)
	{
		n=n/10;
		w=w+1;
	}
	printf("%d",w);
}
