#include<stdio.h>
#include<math.h>
int main()
{
	char c;
	scanf("%c",&c);
	printf("%d",c);
}