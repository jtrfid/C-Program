#include <stdio.h>
int main()
{
	int a,b=0,c,d;
	scanf("%d",&a);
	do
	{
		a=a/10;
		b++;
	}while(a>0);
	printf("%d",b);
}
