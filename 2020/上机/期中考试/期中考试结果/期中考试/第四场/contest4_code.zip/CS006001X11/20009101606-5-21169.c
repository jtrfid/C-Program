#include<stdio.h>

int main()
{
	float m,n;
	scanf("%f",&m);
	if(m<=3000)
		n=m/200;
	else if(m>=3000 && m<=5000)
		n=m/100;
	else if(m>=5000 && m<=10000)
		n=(m*3)/200;
	else
		n=m/50;
	printf("%.1f",n);
	return 0;

}