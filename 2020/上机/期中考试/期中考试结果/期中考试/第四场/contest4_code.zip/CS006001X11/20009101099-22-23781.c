#include<stdio.h>
int main()
{
	int a,b,i,j,temp,k=0,c[100],m,n;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	for(i=a;i<=b;i++)
	{
		temp=i;
		k=0;
		while(temp>0)
		{
			k++;
			temp=temp/10;
		}
		temp=i;
		for(j=0;j<k;j++)
		{
			c[j]=temp%10;
			temp=temp/10;
		}
		m=1;
		n=0;
		for(j=0;j<k;j++)
		{
			m=m*c[j];
			n=n+c[j];
		}
		if(m==n)
		{
			printf("%d ",i);
		}
	}
	return 0;
}


