#include<stdio.h>
int main()
{	
	char a;
	int i,sum;
	for(i=1;;i++)
	{
	scanf("%c",&a);
	sum=sum+a;
	}
	printf("%d",sum);
	return 0;
}