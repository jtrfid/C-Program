#include<stdio.h>
int main()
{
	float a,b,c;
	scanf("%f",&a);
	if(a<=3000)
		b=a*0.005;
	if(a>3000&&a<=5000)
		b=a*0.01;
	if(a>5000&&a<=10000)
		b=a*0.015;
	if(a>10000)
		b=a*0.02;
	printf("%.1f",b);
	return 0;
}