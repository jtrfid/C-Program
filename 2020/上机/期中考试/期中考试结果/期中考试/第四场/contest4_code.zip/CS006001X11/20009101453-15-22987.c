#include<stdio.h>
int main()
{
	char a,n=0,i,j=0;
	for(i=1;;)
	{
		scanf("%c",&a);
		if(a<='9'&&a>='0')
		{
			n=n+a-'0';
			j=j-1;
		}
		if(a=='!')
			break;
		j++;
		i++;
	}
	if(j!=i)
		printf("%d",n);
	else 
		printf("NAN");
	return 0;
}