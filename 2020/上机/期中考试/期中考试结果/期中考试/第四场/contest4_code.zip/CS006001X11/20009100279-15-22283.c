#include <stdio.h>

void main()
{
	int sum=0, flag = 0; 
	char this_;

	do{
		scanf("%c", &this_);
		if ((this_ >= '0')&&(this_ <= '9'))
		{sum += (this_ - '0');	flag = 1;}
	}while (this_ != '!');
	
	if (!flag)	printf("NAN");
	else printf("%d", sum);
}