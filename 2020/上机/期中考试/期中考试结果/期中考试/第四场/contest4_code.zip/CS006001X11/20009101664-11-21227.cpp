#include<stdio.h>
int main()
{
	int a,i=0;
	scanf("%d",&a);
	for(;a!=0;a=a/10)
	{i++;
	}
	printf("%d",i);
return 0;
}