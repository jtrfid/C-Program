#include <stdio.h>
int main()
{
	int n,w=1;
	scanf("%d",&n);
	while(n/10!=0)
	{
		w=w+1;
		n=n/10;
		
	}
	printf("%d",w);
	return 0;
}

		