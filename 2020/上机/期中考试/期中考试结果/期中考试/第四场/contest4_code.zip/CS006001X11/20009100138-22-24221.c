#include <stdio.h>
int main ()
{
	int a,b,c,i,j,e[10]={0},sum=0,ji=1,d;
	scanf ("%d%d",&a,&b);
	if (a>b)
	{
		c=a;
		a=b;
		b=c;
	}
	for (i=a;i<=b;i++)
	{
		d=i;	
		if (d==0) printf ("0");
		for (j=0;d>=1;j++)
		{
			e[j]=d%10;
			d=d/10;
			sum=sum+e[j];
			ji=ji*e[j];
		}
		if (sum==ji)
		{
			printf ("%d ",i);
		}
		sum=0;
		ji=1;
	}
	return 0;
}