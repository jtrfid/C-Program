#include <stdio.h>
int main()
{
	float a;
	float b;
	scanf("%f",&a);
	if(a<=3000)
		b=0.005*a;
	if(a>3000&&a<=5000)
		b=0.01*a;
	if(a>5000&&a<=10000)
		b=0.015*a;
	if(a>10000)
		b=0.02*a;
	printf("%.1f",b);
	return 0;
}
