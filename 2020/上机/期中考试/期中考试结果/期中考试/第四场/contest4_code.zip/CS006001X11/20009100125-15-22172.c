#include<stdio.h>
int main()
{
	int sum=0,t=0;
	char m;
	while (1)
	{
		scanf("%c",&m);
		if (m=='!') break;
		if (m>='0'&&m<='9') {sum+=m-'0';t=1;}
	}
	if(t) printf("%d",sum);
	else printf("NAN");
}