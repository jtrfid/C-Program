#include <stdio.h>
int main ()
{
	int a,m;
	scanf ("%d",&a);
	if (a==0)
	{
		m=1;
	}
	else{
	for (m=0;a>=1;m++)
	{
		a=a/10;
	}}
	printf ("%d",m);
	return 0;
}