#include <stdio.h>
int main()
{
	long int a;
	int i=0;
	scanf("%ld",&a);
	while(a>0)
	{
		a/=10;
		i++;
	}
	printf("%d\n",i);
	return 0;
}