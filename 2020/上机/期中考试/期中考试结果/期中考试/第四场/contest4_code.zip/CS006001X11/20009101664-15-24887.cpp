#include<stdio.h>
int main()
{
	char a,y;
	int sum=0,i;
for(i=0;i<1000;i++)
{scanf("%c",&a);
		if(a>='0'&&a<='9')
			sum+=a-48;
		if(a=='!')
			break;
}
printf("%d",sum);
return 0;
}
