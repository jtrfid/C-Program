#include <stdio.h>
int main()
{
	int a,b;
	int n;
	int m;
	int p,q;
	int i=10;
	scanf("%d %d",&a,&b);
	if(a<b)
	{
		for(n=a;n<=b;n++)
		{
			while(n!=0)
			{
				m=n%i;
				i=i*10;
				q+=m;
				p*=m;
			}
			if(p==q)
				printf("%d ",n);
		}
	}
	return 0;
}



