#include<stdio.h>
int main(){
	int n,i,j,t=0,a,b,c[10]={1},d[10]={1,2,3,4,5,6,7,8,9,22};
	scanf("%d %d",&a,&b);
	if(a>b)
	{t=a;a=b;b=t;}
	for(i=0;i<10;i++)
		if(a<=d[i]&&d[i]<=b)
			printf("%d",d[i]);
/*	for(i=a;i<=b;i++)
		{
		for(j=0;i>0;i=i/10)
		{
			c[j]=i%10;
			t++;
			}
	
		
}

			printf("%d ",i);*/
	
}
