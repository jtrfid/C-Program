#include<stdio.h>
int main()
{
    char c[100];
    int i,sum=0;
    while(c[i]!='!'){ 
    	scanf("%c",&c[i]);
    	if((int)c[i]>47 && (int)c[i]<58) sum=sum+(int)c[i]-48;
    }
    if(sum==0) printf("NAN");
    else
    printf("%d",sum);
    return 0;
}

