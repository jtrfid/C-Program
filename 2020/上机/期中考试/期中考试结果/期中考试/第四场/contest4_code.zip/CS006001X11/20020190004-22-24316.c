#include<stdio.h>
int main(){
	int n,i,j,t=0,a,b,he=0,ji=1;
	scanf("%d %d",&a,&b);
	if(a>b)
	{t=a;a=b;b=t;}
	for(i=a;i<=b;i++)
		{t=i;he=0,ji=1;
		for(j=0;t>0;t=t/10)
		{
			he=he+t%10;
			ji=ji*(t%10);
			}
		if(he==ji)
		printf("%d ",i);
		}

			
	
}
