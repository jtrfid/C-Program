#include<stdio.h>
int main()
{
   float a,b;
   scanf("%f",&a);
   if(a<=3000.0) b=a*0.005;
   if(3000.0<a&&a<=5000.0) b=a*0.01;
   if(5000.0<a&&a<=10000.0) b=a*0.015;
   if(10000.0<a) b=a*0.02;
   printf("%.1f",b);
   return 0;
}