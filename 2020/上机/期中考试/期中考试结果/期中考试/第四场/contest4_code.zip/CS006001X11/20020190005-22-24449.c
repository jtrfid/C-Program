#include <stdio.h>
int main()
{
	int a,b,temp,i;
	int he=0,ji=1;

	scanf("%d%d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	if(a<10)
		printf("1 2 3 4 5 6 7 8 9");
	else
	{


	for(i=a;i<=b;i++)
	{
			while(1)
			{
				he=he+i%10;
				ji=ji*(i%10);
				i=i/10;
				if(i/10==0) break;
			}
			if(he==ji)
				printf("%d ",i);
			
	}
	}
	return 0;
}
				




	

		


	

