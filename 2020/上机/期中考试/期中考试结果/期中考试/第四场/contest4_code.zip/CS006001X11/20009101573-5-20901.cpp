#include<stdio.h>
#include<math.h>
int main(){
   float pay,mon;
   scanf("%f",&pay);
   if(pay<=3000)
	   mon=0.5*pay/100.0;
   else if(pay<=5000)
	   mon=1.0*pay/100.0;
   else if(pay<=10000)
	   mon=1.5*pay/100.0;
   else 
	   mon=2.0*pay/100.0;
   printf("%.1f",mon);
}