#include <stdio.h>
int main()
{
	int a,b,c,i,ji=1,he=0,shu;
	scanf("%d%d",&a,&b); 
	if(a>b)
	{c=a;a=b;b=c;}


	for(i=a;i<=b;i++)
	{
		
		shu=i;
		while(shu!=0)
		{
			
		he=he+shu%10;
		ji=ji*shu%10;
		shu=shu/10;
		
		
		}
		if (ji==he)
		printf("%d",i);
		else 
			continue;

		

		
	}

	






	return 0;
}
