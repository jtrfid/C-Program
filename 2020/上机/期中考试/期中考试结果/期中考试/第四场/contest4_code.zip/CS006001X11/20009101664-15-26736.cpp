#include<stdio.h>
int main()
{
	char a,y;
	int sum=0,i,u=0;
for(i=0;i<1000;i++)
{scanf("%c",&a);
		if(a=='0')
			u++;
if(a>'0'&&a<='9')
			sum+=a-48;
		if(a=='!')
			break;
		
}
if(sum!=0||sum==0&&u!=0)
printf("%d",sum);
else
printf("NAN");

return 0;
}
