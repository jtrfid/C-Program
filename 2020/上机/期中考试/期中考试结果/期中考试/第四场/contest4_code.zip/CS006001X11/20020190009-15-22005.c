#include<stdio.h>
int main()
{
	char a;
	int i,b=0,c=-1;
	for(i=0;;i++)
	{
		scanf("%c",&a);
		if(a=='!')
		break;
		else
		{
			switch(a)
			{
			case'0':b+=0;c++;break;
			case'1':b+=1;c++;break;
				case'2':b+=2;c++;break;
					case'3':b+=3;c++;break;
						case'4':b+=4;c++;break;
							case'5':b+=5;c++;break;
								case'6':b+=6;c++;break;
									case'7':b+=7;c++;break;
										case'8':b+=8;c++;break;
											case'9':b+=9;c++;break;}
		}
	}
	if(c==-1)
	printf("NAN");
	else
	printf("%d",b);
	return 0;
}
