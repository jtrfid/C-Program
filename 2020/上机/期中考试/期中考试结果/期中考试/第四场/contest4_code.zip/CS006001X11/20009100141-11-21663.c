#include<stdio.h>
int main()
{
   long int n;
   int weishu=0;
   scanf("%d",&n);
   if(n==0) printf("1");
   else
   {
	   while(n!=0)
	   {
		   n=n/10;
		   weishu++;
	   }
	   printf("%d",weishu);
   
   }

   return 0;
}