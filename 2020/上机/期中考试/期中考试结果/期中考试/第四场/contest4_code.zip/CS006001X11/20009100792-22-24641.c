#include<stdio.h>
int main()
{
	int he,ji,a,b,temp,i,j;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	if(a==0)
		printf("0 ");
	for(i=a;i<=b;++i)
	{
		temp=i;
		he=0;
		ji=1;
		while(temp>0)
		{
			he=he+temp%10;
			temp=temp/10;
		}
		temp=i;
		while(temp>0)
		{
			ji=ji*(temp%10);
			temp=temp/10;
		}
		if(he==ji)
			printf("%d ",i);
	}
	return 0;
}