#include<stdio.h>
int main()
{
	int n,a,b,c,m,i,l;
	scanf("%d%d",&n,l);

	

for(i=n;i<=l;i++)
{
m=i;
b=0;
	while(i>0)
	{
		a=i%10;
		i=i/10;
		b=b+a;
	}
	c=1;

while(m>0)
	{
		a=m%10;
		m=m/10;
		c=c*a;
	}
if(b==c)
printf("%d",i);}
}



