#include<stdio.h>
int main()
{
	long long int a,b,c,i,j,k;
	long long int x=1,y=0;
	scanf("%lld %lld",&a,&b);
	if(a>b)
	{
		c=a;
		a=b;
		b=c;
	}
	if(a==0)
	printf("0 ");
	if(a<0)
	a=0;
	for(i=a;i<=b;i++)
	{
		j=i;
		for(k=0;;k++)
		{
			if(j==0)
			break;
			x=x*(j%10);
			y=y+(j%10);
			j=j/10;
			
		}
		if(x==y)
		printf("%lld ",i);
		x=1;
		y=0;
    }
	return 0;
}
