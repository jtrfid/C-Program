#include<stdio.h>
int main()
{
	int a,b,i,j,t,sum,p;
    scanf("%d %d",&a,&b);
	if(a>0)
	{
		for(i=a;i<=b;i++)
		{
		 sum=0;
		 p=1;
		 t=i;
		 while(t!=0)
		 {
			sum=sum+t%10;
			p=p*(t%10);
			t=t/10;
		 }
		 if(sum==p)
			printf("%d ",i);
		}
	}
	if(a<=0)
	{
		for(i=1;i<=b;i++)
		{
		 sum=0;
		 p=1;
		 t=i;
		 while(t!=0)
		 {
			sum=sum+t%10;
			p=p*(t%10);
			t=t/10;
		 }
		 if(sum==p)
			printf("%d ",i);
		}
	}

	
	return 0;
}