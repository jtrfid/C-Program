#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int len,i,temp=0,n=0;
	char a[100];
	gets(a);
	len=strlen(a);
	for(i=0;i<len-1;i++)
	{
		if(a[i]>=48&&a[i]<=57)
		{
			n=n-48+a[i];
			temp=1;
		}
	}
    if(temp==1)
	printf("%d",n);
	else printf("NAN");
}
