#include <stdio.h>

int main(){
	double n,m;
	scanf("%lf",&n);
	if(n<=3000) m=0.005*n;
	else{
		if(n<=5000) m=0.01*n;
		else{
			if(n<=10000) m=0.015*n;
			else m=0.02*n;
		}
	}
	printf("%.1lf",m);
}
