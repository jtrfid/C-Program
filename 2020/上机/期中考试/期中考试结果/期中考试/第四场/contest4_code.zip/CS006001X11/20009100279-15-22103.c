#include <stdio.h>

void main()
{
	int sum=0; 
	char this_;

	do{
		scanf("%c", &this_);
		if ((this_ >= '0')&&(this_ <= '9'))
			sum += (this_ - '0');
	}while (this_ != '!');
	printf("%d", sum);
}