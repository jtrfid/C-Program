#include <stdio.h>

int main(){
	char c='0';
	int sum=0;
	int temp=0;
	while(c!='!'){
		scanf("%c",&c);
		if(c>=49&&c<=57) sum=sum+c-48;
		else {
		   if(c==48){
			sum=sum;
			temp=1;}
		else sum=sum;
		}
		
	}
	if(sum==0&&temp==0) printf("NAN");
	else printf("%d",sum);
	return 0;
}
