#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	printf("NAN");
}
