#include<stdio.h>
int main()
{
	int n,i,b;
	scanf("%d",&n);
	b=n;
	i=1;
	if(n==0) printf("%d",i);
	else
	{for(i=1;b>0;i++)
		b=b/10;
	printf("%d",i-1);}
	return 0;
}
