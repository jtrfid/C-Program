#include<stdio.h>
#include<string.h>
int main()
{
   char str[100000];
   int i=0,j=0,sum=0,count=0;
   for(i=0;;i++)
   {
	   scanf("%c",&str[i]);
	   if(str[i]=='!') break;
   }
   for(j=0;j<i;j++)
   {
	   if('0'<=str[j]&&str[j]<='9')
   {
		   sum=sum+str[j]-48;
		   count++;
   }
   }
   if(count==0) printf("NAN");
   else{
	   printf("%d",sum);
   
   }


   return 0;
}