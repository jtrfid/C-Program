#include<stdio.h>
#include<string.h>
int main(){
	char a[1000];
	int i,t=0,n,s=0;
	gets(a);
	n=strlen(a);
	for(i=0;i<n;i++)
		{
		if('1'<=a[i]&&a[i]<='9')
			t=t+a[i]-'0';
		if(a[i]=='0')
			s++;	}
	if(t!=0)	
		printf("%d ",t);
	else if (t==0&&s!=0)
	printf("0");
	else printf("NAN");
	
}
