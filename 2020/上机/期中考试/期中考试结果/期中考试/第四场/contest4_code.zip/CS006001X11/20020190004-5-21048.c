#include<stdio.h>
int main(){
	float n;
	scanf("%f",&n);
	/*3000 5000 10000*/
	if(n<=3000)
		printf("%.1f",n*0.005);
	else if(n<=5000)
		printf("%.1f",n*0.001);
	else if(n<=10000)
		printf("%.1f",n*0.015);
	else 
		printf("%.1f",n*0.02);
}
