#include<stdio.h>
int main()
{
	char c[10000]={""};
	int sum,i,bo,e;
	sum=0;
	bo=0;
	e=0;
	for(i=0;;++i)
	{
		scanf("%c",&c[i]);
		if(c[i]=='!')
		{
			e=i;
			break;
		}
	}
	for(i=0;i<=e;++i)
	{
		if(c[i]>='0'&&c[i]<='9')
		{
			bo=1;
			sum=sum+c[i]-48;
		}
	}
	if(bo==1)
		printf("%d",sum);
	else if(bo==0)
		printf("NAN");
	return 0;
}