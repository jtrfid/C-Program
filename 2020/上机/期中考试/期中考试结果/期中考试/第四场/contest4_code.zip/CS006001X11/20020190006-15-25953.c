#include<stdio.h>
int main()
{
	char c;
	int sum=0,leap;
	while(1)
	{
		scanf("%c",&c);
		if(c>='0'&&c<='9')
		{
			sum=sum+c-'0';
			leap=1;
		}
		else if(c=='!')
			break;
		else
			continue;
	}
	if(leap)
		printf("%d",sum);
	else
		printf("NAN");
	return 0;
}