#include<stdio.h>
int main()
{
	char a[100];
	int k,i,n;
	k=0;
	n=0;
	for(i=0;i<=100;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!')break;
	}
	for(i=0;i<=100;i++)
	{
		if(a[i]>='0'&&a[i]<='9')
			k=k+a[i]-'0';
		if(a[i]==0)
			n++;
	}
	if(k==0&&n==0)
		printf("NAN");
	else
		printf("%d",k);
	return 0;
}
