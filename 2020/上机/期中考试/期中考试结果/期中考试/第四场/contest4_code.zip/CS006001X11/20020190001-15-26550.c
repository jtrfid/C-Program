#include<stdio.h>
int main()
{
	char number;
	int s=0,flag=1;
	while(number!='!')
	{
		scanf("%c",&number);
		if((number>'0'||number=='0')&&(number<'9'||number=='9'))
		{
			s=s+number-48;
			flag=0;
		}
	}
	if(flag)
	{printf("NAN");}
	else
		printf("%d",s);

	return 0;
}
