#include <stdio.h>
int main()
{
	
	int a[10],i,sum=0,temp;
	for(i=0;i<10;i++)
		scanf("%d",&a[i]);
	for(i=0;i<10;i++)
	{
		if(a[i]==1||a[i]==2||a[i]==3||a[i]==4||a[i]==5||a[i]==6||a[i]==7||a[i]==8||a[i]==9||a[i]==0)
		{
			sum=sum+a[i];
			temp=1;
		}
		else temp=0;
	}
	if(temp==0) printf("NAN");
	else
	printf("%d",sum);
	return 0;
}
		
		
			
	