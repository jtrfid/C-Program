#include<stdio.h>
int main()
{
	long a,b,t,i,x,y,temp;
	scanf("%d%d",&a,&b);
	if(b<a)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		temp=i;
		x=0;
		y=1;
		while(temp>0)
		{
			x=x+temp%10;
			y=y*temp%10;
			temp=temp/10;
		}
		if(x==y&&i>=0)printf("%d ",i);
	}





}