#include <stdio.h>
int main()
{
	int a,b,sum=0,ji=1,i,t;
	scanf("%d%d",&a,&b);
	if (a<0) a=0;
	if (a==0)
	{
		printf("0 ");
		a=1;
	}
	if (a>=1)
	{
		for (i=a;i<=b;i++)
		{
			sum=0;
			ji=1;
			t=i;
			while(t!=0)
			{
				sum=sum+(t%10);
				ji=ji*(t%10);
				t=t/10;
			}
			if (sum==ji) printf("%d ",i);
		}
	}
}










