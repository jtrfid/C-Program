#include<stdio.h>
int main()
{
	int a,b,j,h,l,i,k;
	scanf("%d%c%d",&a,&l,&b);
	if(a>b)
	{
		h=a;
		a=b;
		b=h;
	}
		for(i=a;i<=b;i++)
		{
			h=0;
			j=1;
			for(k=i;k>0;)
			{
				h=h+k%10;
				j=j*(k%10);
				k=k/10;
			}
			if(h==j)
				printf("%d ",i);
		}
		return 0;
}