#include<stdio.h>
int main()
{
	int n,k;
	scanf("%d",&n);
	k=0;
	while(n>0)
	{
		k++;
		n=n/10;
	}
		
	printf("%d",k);
	return 0;
}

