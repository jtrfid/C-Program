#include <stdio.h>
int main()
{
	int i,p=0,sum=0;
	char a[100];
	for(i=0;i<100;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]=='!') break;
	}
	for(p=0;p<100;p++)
	{
		if(a[p]=='1'||a[p]=='2'||a[p]=='3'||a[p]=='4'||a[p]=='5'||a[p]=='6'||a[p]=='7'||a[p]=='8'||a[p]=='9')
			sum=sum+a[p];
		if(a[p]=='!') break;
	}
	if(sum!=0)
	printf("%d",sum);
	if(sum==0) printf("NAN");
}


