#include <stdio.h>
int main()
{
	int a,b,i,t,sum=0,m,x=1;
	scanf("%d%d",&a,&b);
	for(i=a;i<=b;i++)
	{
	       while(i!=0)
			{t=i%10;
		     i=(i-t)/10;
			 x=x*t;
			 sum=sum+t;
		   }
		   if(x==sum)
			   printf("%d",i);
	}
}
		   
			

	



			

