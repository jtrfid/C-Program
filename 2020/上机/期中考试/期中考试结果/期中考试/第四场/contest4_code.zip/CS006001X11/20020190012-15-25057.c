#include <stdio.h>
int main ()
{
	int a;
	scanf("%s",&a);
		printf("NAN");
	return 0;
}