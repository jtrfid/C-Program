#include<stdio.h>
#include<string.h>
int main()
{
	char str[100];
	int sum=0,i,num;
	scanf("%s",&str[100]);
	for(i=0;i<100;i++)
	{
		num=str[i];
		if(num>=48&&num<=58)
		{
			num=num-48;
			sum=sum+num;
		}
	}
	if(sum==0)
		printf("NAN");
	else
		printf("%d",sum);
}
