#include <stdio.h>
int main()
{
	int a,b,mid,he=0,chengji=1,x;
	scanf("%d %d",&a,&b);
	if(a<b) ;
	else
	{
		mid=a;
		a=b;
		b=mid;
	}
	for(a;a<=b;a++)
	{
		x=a;
		while(x>=1)
		{
			he=he+x%10;
			chengji=chengji*(x%10);
			x=x/10;
		}
		if(he==chengji) printf("%d ",a);
		he=0;
		chengji=1;
	}
}



		


			


	

