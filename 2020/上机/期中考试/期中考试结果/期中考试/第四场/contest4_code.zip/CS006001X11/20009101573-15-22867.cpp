#include<stdio.h>
#include<math.h>
int main(){
	char a;
	int sum=0,count=0;
	while(1){
	    scanf("%c",&a);
		if(a=='!')
			break;
        if(a-'0'<=9&&a-'0'>=0){
			sum=sum+((int)a-48);
			count++;
		}
	}
	if(count==0)
		printf("NAN");
	else
		printf("%d",sum);
}