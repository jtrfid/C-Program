#include<stdio.h>
int main()
{
	int a,b,i,p,q,t;
	scanf("%d%d",&a,&b);
	if(a>b) {t=a;a=b;b=t;}
	for (i=a;i<=b;i++)
	{
		t=i;
		p=0;
		q=1;
		if (t==0) printf("0 ");
		else
		{
		while(t)
		{
			p+=t%10;
			q*=t%10;
			t/=10;
		}
		if(p==q&&i>0) printf("%d ",i);
		}
	}
	
}