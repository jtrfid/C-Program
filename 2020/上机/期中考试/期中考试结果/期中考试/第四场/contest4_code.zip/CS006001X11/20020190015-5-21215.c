#include<stdio.h>
int main()
{
	float s,d;
	scanf("%f",&s);
	if(s<=3000)
		d=0.005*s;
	else if(s<=5000)
		d=0.01*s;
	else if(s<=10000)
		d=0.015*s;
	else
		d=0.02*s;
	printf("%.1f\n",d);
	return 0;
}