#include<stdio.h>
int main()
{
    char c[100];


	printf("NAN");
	return 0;
}


