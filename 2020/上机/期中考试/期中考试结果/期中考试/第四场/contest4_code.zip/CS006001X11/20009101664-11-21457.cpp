#include<stdio.h>
int main()
{
	int a,i=0;
	scanf("%d",&a);
	if(a==0)
		printf("1");
	else
	{
	for(;a!=0;a=a/10)
	{i++;
	}
	printf("%d",i);
	}
return 0;
}