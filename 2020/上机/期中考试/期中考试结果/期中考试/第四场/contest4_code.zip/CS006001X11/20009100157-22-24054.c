#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	 long long int a,b,i,he,ji,tmp;
	scanf("%d%d",&a,&b);
	if(a<=b&&a>0)
	{
		for(i=a;i<=b;i++)
		{
			he=0;ji=1;tmp=i;
			while(tmp!=0)
			{
				he=he+tmp%10;
				ji=ji*tmp%10;
				tmp=tmp/10;	
			}
			if(he==ji)
			{
				printf("%d ",i);
			}
		}
	} 
	if(a<=b&&a==0)
	{
		printf("%d ",0);
		for(i=1;i<=b;i++)
		{
			he=0;ji=1;tmp=i;
			while(tmp!=0)
			{
				he=he+tmp%10;
				ji=ji*tmp%10;
				tmp=tmp/10;	
			}
			if(he==ji)
			{
				printf("%d ",i);
			}
		}
	} 
	if(a<=b&&a<0)
	{
		printf("%d ",0);
		for(i=1;i<=b;i++)
		{
			he=0;ji=1;tmp=i;
			while(tmp!=0)
			{
				he=he+tmp%10;
				ji=ji*tmp%10;
				tmp=tmp/10;	
			}
			if(he==ji)
			{
				printf("%d ",i);
			}
		}
	} 
	if(b<=a&&b>0)
	{
		for(i=b;i<=a;i++)
		{
			he=0;ji=1;tmp=i;
			while(tmp!=0)
			{
				he=he+tmp%10;
				ji=ji*tmp%10;
				tmp=tmp/10;	
			}
			if(he==ji)
			{
				printf("%d ",i);
			}
		}
	} 
	if(b<=a&&b==0)
	{
		printf("%d ");
		for(i=1;i<=a;i++)
		{
			he=0;ji=1;tmp=i;
			while(tmp!=0)
			{
				he=he+tmp%10;
				ji=ji*tmp%10;
				tmp=tmp/10;	
			}
			if(he==ji)
			{
				printf("%d ",i);
			}
		}
	} 
	if(b<=a&&b<0)
	{
		printf("%d ",0);
		for(i=1;i<=a;i++)
		{
			he=0;ji=1;tmp=i;
			while(tmp!=0)
			{
				he=he+tmp%10;
				ji=ji*tmp%10;
				tmp=tmp/10;	
			}
			if(he==ji)
			{
				printf("%d ",i);
			}
		}
	} 
	return 0;
}
