#include<stdio.h>
#include<math.h>
int main()
{
	float w;
	scanf("%f",&w);
	if(w<=3000)
		printf("%.1f",0.005*w);
	else if(w<=5000)
		printf("%.1f",0.01*w);
	else if(w<=10000)
		printf("%.1f",0.015*w);
	else 
		printf("%.1f",0.02*w);



}
