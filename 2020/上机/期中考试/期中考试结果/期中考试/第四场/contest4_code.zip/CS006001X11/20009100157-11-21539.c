#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	int n,weishu=0;
	scanf("%d",&n);
	if(n==0)
	{
		weishu=1;
	}
	else
	{
	
	while(n!=0)
	{
		weishu=weishu+1;
		n=n/10;
	}
	}
	printf("%d",weishu);
	return 0;
}
