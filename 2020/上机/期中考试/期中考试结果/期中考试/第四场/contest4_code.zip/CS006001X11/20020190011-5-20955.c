#include<stdio.h>
int main()
{
	float a,b,c;
	scanf("%f",&a);
	if(a<=3000)
		b=0.5/100;
	else if(a<=5000)
		b=1/100;
	else if(a<=10000)
		b=1.5/100;
	else
		b=2/100;
	c=a*b;
	printf("%.1f",c);
}



