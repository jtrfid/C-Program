#include <stdio.h>
int main()
{
	double a,b;
	scanf ("%lf",&a);
	if (a<=3000)
	{
		b=a/200;
	}
	else 
	{
		if (a<=5000)
		{
			b=a/100;
		}
		else 
		{
			if (a<=10000)
			{
				b=a/100*1.5;
			}
			else 
			{
				b=a/50;
			}
		}
	}
	printf ("%.1lf",b);
	return 0;
}