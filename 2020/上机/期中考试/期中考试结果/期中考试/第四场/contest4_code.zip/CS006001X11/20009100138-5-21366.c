#include <stdio.h>
int main ()
{
	int a,m;
	scanf ("%d",&a);
	for (m=1;a>=1;m++)
	{
		a=a/10;
	}
	printf ("%d",m-1);
	return 0;
}