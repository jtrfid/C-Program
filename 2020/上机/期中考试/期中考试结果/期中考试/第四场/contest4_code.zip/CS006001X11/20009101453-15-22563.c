#include<stdio.h>
int main()
{
	char a,n=0;
	for(;;)
	{
		scanf("%c",&a);
		if(a<='9'&&a>='0')
			n=n+a-'0';
		if(a=='!')
			break;
	}
	if(n!=0)
		printf("%d",n);
	else 
		printf("NAN");
	return 0;
}