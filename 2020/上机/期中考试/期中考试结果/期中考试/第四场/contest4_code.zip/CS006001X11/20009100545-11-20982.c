#include<stdio.h>
int main()
{
	int n,i,j,weishu=0;
	scanf("%d",&n);
	do
	{
		n=n/10;
		weishu++;
	}
	while(n>=1);
	printf("%d",weishu);
	return 0;
}