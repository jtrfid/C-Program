#include <stdio.h>

void main()
{
	int num, count=1;
	scanf("%d", &num);

	while((num/10) != 0)
	{
		num /= 10;
		count += 1;
	}
	if (num == 0)	count = 1;
	printf("%d", count);
}