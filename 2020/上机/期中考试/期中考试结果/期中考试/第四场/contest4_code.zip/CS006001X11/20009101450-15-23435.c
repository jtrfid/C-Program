#include<stdio.h>
int main()
{
	char a;
	int n=0,i=0;
	for(i=0;a!='!';i++)
	{
		scanf("%c",&a);
		if(a>=48&&a<=57)
			n=n+a-48;
	}
	if(n=0)
		printf("NAN");
	else
		printf("%d",n);
}
