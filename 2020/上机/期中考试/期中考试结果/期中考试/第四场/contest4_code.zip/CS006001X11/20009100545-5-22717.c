#include<stdio.h>
int main()
{	
	float n;
	scanf("%f",&n);
	if(n<=3000)
	{
		printf("%.1f",0.005*n);
	}
	if(n>3000&&n<=5000)
	{
		printf("%.1f",0.01*n);
	}
	if(n>5000&&n<=10000)
	{
		printf("%.1f",0.015*n);
	}
	if(n>10000)
	{
		printf("%.1f",0.02*n);
	}
	return 0;
}