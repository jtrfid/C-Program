#include<stdio.h>
#include<math.h>
int bits(int n){
	long p,E=10,Count=0;
    while(1){
	    p=n%E;
		E=E*10;
		Count++;
		if(p==n)
			break;
	}
	return Count;
}
int main(){
    int e,temp,i,j,bit,lef,rig,culs=1,sums=0,bit_1;
	scanf("%d%d",&lef,&rig);
	if(lef>rig){
	    temp=rig;
		rig=lef;
		lef=temp;
	}
	for(i=lef;i<=rig+1;i++){
	    bit=bits(i);
		e=1;
		culs=1;
		sums=0;
		for(j=0;j<bit;j++){
			bit_1=(i/e)%10;
		    culs=culs*bit_1;
			sums=sums+bit_1;
			e=e*10;
		}
		if(culs==sums)
			printf("%d ",i);
	}

	
}
