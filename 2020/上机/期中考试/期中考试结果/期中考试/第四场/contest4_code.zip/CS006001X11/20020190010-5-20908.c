#include<stdio.h>
int main()
{
	float gz,m;
	scanf("%f",&gz);
	if(gz<=3000) m=gz*0.005;
	else if(gz<=5000) m=gz*0.01;
	else if(gz<=10000) m=gz*0.015;
	else m=gz*0.02;
	printf("%.1f",m);
	return 0;
}
