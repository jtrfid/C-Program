#include<stdio.h>
int main()
{
	int ws,a,b,i,j,sum,cj,n;
	scanf("%d%d",&a,&b);
	if(a<=0||b<=0)
	printf("0 ");
	if(a>b)
	{
		i=a;
		a=b;
		b=i;
	}
	for(i=a;i<=b;i++)
	{
		int mw[10]={0};
		n=i;
		ws=0;
		sum=0;
		cj=1;
	for(j=0;n!=0;j++)
	{
		mw[j]=n%10;
		n=n/10;
		ws=ws+1;
	}
	for(j=0;j<ws;j++)
	{
		sum=mw[j]+sum;
		cj=cj*mw[j];
	}
	if(cj==sum&&cj!=0) printf("%d ",i);
    }

}
