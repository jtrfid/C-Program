#include<stdio.h>
int main()
{
	int a,b,c,m=0,n=1,k;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		c=a;
		a=b;
		b=c;
	}


    for(;a<=b;a++)
	{
		k=a;
	for(;k>0;)
	{
		m=m+k%10;
		n=n*(k%10);
		k=k/10;
		
	}
        if(m==n&&a>=0)
			printf("%d ",a);
		m=0;
		n=1;
	}
	
}
