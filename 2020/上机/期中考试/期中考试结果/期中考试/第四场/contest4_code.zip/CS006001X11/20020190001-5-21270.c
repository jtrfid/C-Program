#include<stdio.h>
int main()
{
    float n,m;
	scanf("%f",&n);
	if(n<3000||n==3000)
	{m=0.005*n;}
	else if(n>3000&&(n<5000||n==5000))
	{m=0.01*n;}
	else if(n>5000&&(n<10000||n==10000))
	{m=0.015*n;}
	else if(n>10000)
	{m=0.02*n;}
	printf("%.1f",m);
	return 0;
}