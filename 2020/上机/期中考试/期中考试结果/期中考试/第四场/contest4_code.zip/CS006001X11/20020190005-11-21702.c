#include <stdio.h>
int main()
{
	int n,w=0;
	scanf("%d",&n);
	while(1)
	{
		w=w+1;
		n=n/10;
		if(n%10==0) break;
	}
	printf("%d",w);
	return 0;
}

		