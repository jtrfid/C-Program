#include<stdio.h>
int main()
{
	int a,b,i,t,s=0,c=1;
	int h[10000],g[10000]={0};
	scanf("%d%d",&a,&b);
	if(a>b)
	{t=a;a=b;b=t;}
	for(i=a;i<=b;i++)
		h[i]=i;
	for(i=a;i<=b;)
	{
		g[i]=h[i]%10;
		s=s+g[i];
		c=c*g[i];
	    h[i]=h[i]/10;
		if(h[i]==0)
		{
			if(s==c)
			{printf("%d ",i);s=0;c=1;}
			s=0;c=1;
			i++;
		}
	}
return 0;
}

