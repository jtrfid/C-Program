#include <stdio.h>
int main()
{
	int a,b,c,i,ji=1,he=0;
	scanf("%d%d",&a,&b); 
	if(a>b)
	{c=a;a=b;b=c;}
	

	do
	{
		i=a;
		do
		{
		he=he+i%10;
		ji=ji*i%10;
		i=i/10;
		}
		while(i!=0);
		if(ji=he)
		printf("%d",i);
		else 
			i=i+1;

		
	}
while (i<=b);




	return 0;
}
