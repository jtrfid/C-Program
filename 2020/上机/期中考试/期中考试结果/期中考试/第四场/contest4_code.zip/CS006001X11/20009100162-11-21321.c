#include <stdio.h>

int main(){
	int n,t,m=0,temp;
	scanf("%d",&n);
	temp=1;
	t=10;
	while(temp!=0){
		temp=n/t;
		m++;
		t=10*t;
	}
	printf("%d",m);
}
