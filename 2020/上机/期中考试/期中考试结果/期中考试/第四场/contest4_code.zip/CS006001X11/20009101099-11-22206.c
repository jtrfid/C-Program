#include<stdio.h>
int main()
{
	int n,k;
	scanf("%d",&n);
	if(n==0)
	{
		k=1;
	}
	else
	{
	k=0;
	}
	while(n>0)
	{
		k++;
		n=n/10;
	}
		
	printf("%d",k);
	return 0;
}

