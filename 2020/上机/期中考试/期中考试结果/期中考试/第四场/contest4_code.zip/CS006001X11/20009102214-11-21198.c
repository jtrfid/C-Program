#include<stdio.h>
#include<math.h>
int main()
{
	int n,temp=0;
	scanf("%d",&n);
	if(n=0)
		temp=1;
	while(n!=0)
	{
		n=n/10;
		temp=temp+1;
	}
	printf("%d",temp);




}
