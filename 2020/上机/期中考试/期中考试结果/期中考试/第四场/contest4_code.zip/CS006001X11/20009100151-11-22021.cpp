#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	if(n<10)
		i=1;
	else if(n<100)
		i=2;
	else if(n<1000)
		i=3;
	else if(n<10000)
		i=4;
		else if(n<100000)
		i=5;
			else if(n<1000000)
		i=6;
				else if(n<10000000)
		i=7;
					else if(n<100000000)
		i=8;
						else if(n<1000000000)
		i=9;
						if(n==1000000000)
							i=10;
						printf("%d",i);
}