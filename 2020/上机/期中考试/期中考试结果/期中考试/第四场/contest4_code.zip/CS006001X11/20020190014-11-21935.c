#include <stdio.h>
int main()
{
	int n,weishu=0;
	scanf("%d",&n);
	while(n!=0)
	{
		n=n/10;
		weishu++;
	}
	printf("%d",weishu);
}
