#include <stdio.h>
int main()
{
	int num,weishu=0;
	scanf("%d",&num);
	do
	{
		num=num/10;
		weishu=weishu+1;
	}
	while (num!=0);
	printf("%d",weishu);





	return 0;
}
