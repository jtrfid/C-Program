#include<stdio.h>
int main(){
	int n,i,t=0;
	scanf("%d",&n);
	if(n==0)
	printf("1");
	else {
	for(i=n;i>0;i=i/10)
		if(i/10>0)
			t++;
	printf("%d ",t+1);}
	
}
