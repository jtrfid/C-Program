#include<stdio.h>
int main()
{
	int a,b,c,i,j,k;
	int x=1,y=0;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		c=a;
		a=b;
		b=c;
	}
	if(a==0)
	printf("0 ");
	if(a<0)
	a=0;
	for(i=a;i<=b;i++)
	{
		x=1;
		y=0;
		j=i;
		for(k=0;;k++)
		{
			if(j==0)
			break;
			x=x*(j%10);
			y=y+(j%10);
			j=j/10;
			
		}
		if(x==y)
		printf("%d ",i);
    }
	return 0;
}
