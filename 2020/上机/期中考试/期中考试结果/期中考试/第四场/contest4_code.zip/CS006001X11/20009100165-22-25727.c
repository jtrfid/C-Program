#include<stdio.h>
int main()
{
	int a,b,t,k,m,i,jia,chen;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		k=i;
		m=i;
		jia=k%10;
		while(k/10!=0)
		{
			jia=jia+k/10%10;
			k=k/10;
		}
		chen=m%10;
		while(m/10!=0)
		{
			chen=chen*(m/10%10);
			m=m/10;
		}
		if(chen==jia&&i>=0)
			printf("%d ",i);
		else ;
	}
	return 0;
}


