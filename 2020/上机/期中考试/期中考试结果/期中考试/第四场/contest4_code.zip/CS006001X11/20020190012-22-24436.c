#include <stdio.h>
int main ()
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("1 2 3 4 5 6 7 8 9 22");
	return 0;
}