#include<stdio.h>
int main()
{
	int a,weishu=0;
	scanf("%d",&a);
	do
	{
		weishu++;
		a=a/10;
	}while(a!=0);
	printf("%d",weishu);
	return 0;
}