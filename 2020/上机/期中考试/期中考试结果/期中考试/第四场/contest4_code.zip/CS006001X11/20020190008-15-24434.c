#include<stdio.h>
int main()
{
	char a[100];
	int i,j,t;
	i=0;
	t=0;
	while(a[i]='!')
	{
		scanf("%c",a[i]);
		i++;
	}
	for(j=0;j<=i;j++)
	{
		if(a[j]>=0&&a[j]<=9)
			t=t+a[j];
	}
	if(t!=0)
      printf("%d",t);
	if(t==0)
		printf("NAN");
	return 0;
}




	

	

