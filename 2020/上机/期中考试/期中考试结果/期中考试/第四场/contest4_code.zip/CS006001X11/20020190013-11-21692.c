#include <stdio.h>
int main()
{
	int n,weishu=0;
	scanf("%d",&n);
	if(n==0) printf("1");
	else
	{
		for(n;n>0;n=n/10)
	{
		weishu++;
	}
	printf("%d\n",weishu);
	}
}

	

