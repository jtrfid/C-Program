#include<stdio.h>
int main()
{
	int a,b,c,i,j;
	int x=1,y=0;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		c=a;
		a=b;
		b=c;
	}
	for(i=a;i<=b;i++)
	{
		j=i;
		while(j!=0)
		{
			x=x*(j%10);
			y=y+(j%10);
			j=j/10;
		}
		if(x==y)
		printf("%d ",i);
		x=1;
		y=0;
	}
	return 0;
}
