#include <stdio.h>
int main()
{
	int a,b,i,ji=1,he=0,t,w,x;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		x=i;
		ji=1;
		he=0;
		while(x!=0)
		{
			w=x%10;
			x/=10;
			he+=w;
			ji*=w;
		}
		if(he==ji)
			printf("%d ",i);
	}
	return 0;
}