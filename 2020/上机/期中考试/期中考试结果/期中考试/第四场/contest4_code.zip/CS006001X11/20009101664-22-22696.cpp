#include<stdio.h>
int main()
{
	int i,m,n,x,y,z,l,j,s;
	scanf("%d %d",&m,&n);
	if(m<n){
	for(i=m;i<=n;i++)
	{j=1;s=0;
			z=i;l=i;
		do{x=z%10;
		s+=x;
		z=z/10;
		}while(z!=0);

		do{y=l%10;
			j=j*y;
			l=l/10;
		}while(l!=0);

		if(s==j)
			printf("%d ",i);
	}}
	else
{
	for(i=n;i<=m;i++)
	{j=1;s=0;
			z=i;l=i;
		do{x=z%10;
		s+=x;
		z=z/10;
		}while(z!=0);

		do{y=l%10;
			j=j*y;
			l=l/10;
		}while(l!=0);

		if(s==j)
			printf("%d ",i);
	}}
return 0;
}