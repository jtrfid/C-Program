#include<stdio.h>
int main()
{
	int a,b,temp,i,m,n;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	for(i=a;i<=b;++i)
	{
		m=0;
		n=1;
		temp=i;
		while(temp>0)
		{
			m=m+(temp%10);
			n=n*(temp%10);
			temp=temp/10;
		}
		if(m==n)
			printf("%d ",i);
	}
	return 0;
}