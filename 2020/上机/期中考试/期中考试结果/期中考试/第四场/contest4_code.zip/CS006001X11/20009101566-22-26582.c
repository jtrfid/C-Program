#include <stdio.h>
int main()
{
	int a,b,t,c,d,e,f,sum=0,x=1,r,s;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	c=a;
	for(c=a;c<b;c++)
	{
		e=c;
		f=c;
		for(;c>0;)
		{
			d=c%10;
			sum=sum+d;
			c=(c-d)/10;
		}
		for(;e>0;)
		{
			r=e%10;
			x=x*r;
			e=(e-r)/10;
		}
		if(x==sum)
			printf("%d",f);
	}
}



	


