#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int i=0,j,sum=0,a=0;
	char str[100];
	for(i=0;;i++)
	{
		scanf("%c",&str[i]);
		if(str[i]=='!')
			break;
	}
	for(j=0,j<i;j++)
	{
		if(str[j]<='9'&&str[j]>='0')
		{
			sum=sum-48+str[i];
			a=1;
		}
	}
	if(a==1)
		printf("%d",n);
	if(a==0)
		printf("NAN");
}
