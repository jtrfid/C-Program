#include<stdio.h>
int main()
{
	int a,b,weishu=0,k,t,i,he=0,ji=1;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		t=i;
		do
		{
			weishu++;
			t=t/10;
		}while(t!=0);
		t=i;
		do
		{
			k=t%10;
			t=t/10;
			he=he+k;
			ji=ji*k;
			weishu--;
		}while(weishu!=0);
		if(he==ji)
			printf("%d ",i);
		he=0;
		ji=1;
	}
	return 0;
}