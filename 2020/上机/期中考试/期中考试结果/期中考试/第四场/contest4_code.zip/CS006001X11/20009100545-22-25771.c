#include<stdio.h>
int main()
{
	int a,b,i,sum,t,cheng,m;
	scanf("%d %d",&a,&b);
	for(i=a;i<=b;i++)
	{	
		m=i;
		sum=0;cheng=1;
		do
		{
			t=m%10;
			sum=sum+t;
			cheng=cheng*t;
			m=m/10;
		}
		while(m>0);
		//printf("%d %d",sum,cheng);
		if(sum==cheng)
		{
			printf("%d ",i);
		}
	}
	return 0;
}
		
	