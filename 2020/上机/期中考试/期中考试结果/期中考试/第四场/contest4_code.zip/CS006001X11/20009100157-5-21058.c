#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	float x,shui;
	scanf("%f",&x);
	if(x<=3000)
	{
		shui=x*0.005;
	}
	else if(x>3000&&x<=5000)
	{
		shui=x*0.01;
	}
	else if(x>5000&&x<=10000)
	{
		shui=x*0.015;
	}
	else
	shui=x*0.02;
	printf("%.1f",shui);
	return 0;
}
