#include<stdio.h>
int main()
{
	char a,y;
	int sum=0;
	do{scanf("%c",&a);
		if(a>='0'&&a<='9')
			sum+=a-48;
	}while(y=getchar()!='\n');
if(sum==0)
printf("NAN");
else
printf("%d",sum);
return 0;
}