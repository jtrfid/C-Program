#include<stdio.h>
int main()
{
	float x;
	float y=0;
	scanf("%f",&x);
	if(x<=3000.0)
		y=0.005*x;
	else if(x>3000.0&&x<=5000.0)
		y=0.01*x;
	else if(x<=10000.0&&x>5000.0)
		y=0.015*x;
	else if(x>10000.0)
		y=0.02*x;
	printf("%.1f\n",y);
	return 0;
}
