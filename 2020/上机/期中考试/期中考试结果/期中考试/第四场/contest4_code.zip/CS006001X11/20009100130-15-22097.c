#include <stdio.h>
int main()
{
	char a;


	int sum=0,t=0;
	while((a=getchar())!='!')
	{
		if(a>='0'&&a<='9')
		{
			sum=sum+a-48;
			t=1;
		}
	}
	if (t==1) printf("%d",sum);
	if (t==0) printf("NAN");
}


