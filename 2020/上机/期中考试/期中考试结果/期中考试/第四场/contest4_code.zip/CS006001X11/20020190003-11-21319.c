#include <stdio.h>
#include <math.h>
int main()
{
	int n,weishu,i;
	scanf("%d",&n);
	for(i=0;n>=1;i++){
		n=n/10;
	}
	printf("%d",i);
	return 0;
}
