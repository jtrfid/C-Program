#include<stdio.h>
#include<math.h>
int main()
{
	int x;
	int temp=0;
	scanf("%d",&x);
	while(x/10!=0)
	{
		temp++;
		x=x/10;
	}
	printf("%d\n",temp+1);
	return 0;
}
