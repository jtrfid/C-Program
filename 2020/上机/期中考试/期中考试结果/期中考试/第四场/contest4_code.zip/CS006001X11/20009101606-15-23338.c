#include<stdio.h>

int main()
{
	int n=0;
	char c;
	while((c=getchar()) && c!='!')
	{
	
		if(c<=9)
			n=n+c;
	}
	if(n==0)
		printf("NAN");
	else
		printf("%d",n);
	return 0;

}