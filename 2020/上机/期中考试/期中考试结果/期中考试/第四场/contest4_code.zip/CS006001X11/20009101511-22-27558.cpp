#include<stdio.h>
int main()
{
	char a[10000];
	for(i=0;a[i]='!';i++)
	scanf("%c",&a[i]);
	
}
