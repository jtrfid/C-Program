#include<stdio.h>
 main()
 {  int a[1000]={0},i,b[1000]={0},s;
  
	  for(i=0;i<1000;i++)
	  {
		  scanf("%c",&a[i]);
		  if(a[i]=='!')
		  {
			  break;
		  }
	  
	  }
	
	  s=0;
for(i=0;i<1000;i++)
{
	if((a[i]=='0')||(a[i]=='1')||(a[i]=='2')||(a[i]=='3')||(a[i]=='4')||(a[i]=='5')||(a[i]=='6')||(a[i]=='7')||(a[i]=='8')||(a[i]=='9'))
	{
		b[i]=a[i]-48;
	}
}

for(i=0;i<1000;i++)
s=s+b[i];
if(s==0)
printf("NAN");
else
printf("%d",s);
 }
