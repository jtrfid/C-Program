#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int n=0,len,i,temp=0;
	char a[100];
	gets(a);
	len=strlen(a);
	for(i=0;i<len-1;i++)
	{
		if(a[i]>48&&a[i]<68)
		{
			n=n+a[i]-48;
			temp=1;
		}
	}
    if(temp==1)
	printf("%d",n);
	else printf("NAN");
}
