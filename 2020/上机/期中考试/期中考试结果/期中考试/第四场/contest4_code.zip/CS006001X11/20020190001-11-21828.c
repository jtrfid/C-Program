#include<stdio.h>
int main()
{
	int n,s=0;
	scanf("%d",&n);
	while(n!=0)
	{
		s++;
		n=n/10;
	}
	if(n==0)
		s=1;
	printf("%d",s);
	return 0;
}
