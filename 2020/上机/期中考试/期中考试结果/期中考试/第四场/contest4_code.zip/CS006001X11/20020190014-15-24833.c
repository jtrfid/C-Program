#include <stdio.h>
int main()
{
	char x;
	int i,n,sum=0;
	for(i=1; ;i++)
	{
		scanf("%c",&x);
		if(x=='!')
			break;
	}
	if(x>=0&&x<=10000)
	{for(i=1; ;i++)
	sum=sum+x;
	printf("%d",sum);}
	else
		printf("NAN");
}


