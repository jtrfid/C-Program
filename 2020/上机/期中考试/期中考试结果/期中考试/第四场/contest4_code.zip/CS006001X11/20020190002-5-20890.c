#include<stdio.h>
int main()
{
	float df;
	float gz;
	scanf("%f",&gz);
	if(gz<=3000)
		df=gz*0.005;
	else if(gz<=5000)
		df=gz*0.01;
	else if(gz<=10000)
		df=gz*0.015;
	else
		df=gz*0.02;
	printf("%.1f",df);
		return 0;


}