#include<stdio.h>
int main()
{
	int n,i,b;
	scanf("%d",&n);
	i=0;
	b=n;
	if(n=0)printf("%d",i);
	else
	{
	for(i=1;b>1;i++)
	{
		b=b/10;
	}
	printf("%d",i);}
	return 0;
}
