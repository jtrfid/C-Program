#include <stdio.h>
int main()
{
	char a;
	int sum=0,i=0;
	while(a!='!')
	{
		scanf("%c",&a);
		if(a>='0'&&a<='9')
		{
			sum+=a-'0';
			i++;
		}
	}
	if(i==0)
		printf("NAN\n");
	else
	 printf("%d\n",sum);
	return 0;
}