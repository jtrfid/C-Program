#include <stdio.h>
int main()
{
	float m,n;
	scanf("%f",&m);
	if(m<=3000) printf("%.1f",0.005*m);
	if(m>3000&&m<=5000) printf("%.1f",0.01*m);
	if(m>5000&&m<=10000) printf("%.1f",0.015*m);
	if(m>10000) printf("%.1f",0.02*m);
}
