#include <stdio.h>
int main()
{
	int n;
	int sum=0;
	int i=1;
	scanf("%d",&n);
	if(n==0)
		printf("1");
	if(n!=0)
	{
		while(n/i!=0)
		{
			sum++;
			i=i*10;
		}
		printf("%d",sum);
	}
	return 0;
}
