#include<stdio.h>
int main()
{
	int n,a=0,i;
	scanf("%d",&n);
	if(n==0)
	printf("1");
	else
	{
	while(n!=0)
	{
		n=n/10;
		a++;
	}
	printf("%d",a);
}
return 0;
}
