#include<stdio.h>
int main()
{
    char c[100];
    int i,sum=0;
    for(i=0;c[i]=='!';i++){
    	scanf("%c",&c[i]);
    	if(47<(int)c[i]<58) sum=sum+(int)c[i];
    }
    if(sum==0) printf("NAN");
    else
    printf("%d",sum);
    return 0;
}
