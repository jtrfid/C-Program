#include<stdio.h>
int main()
{
	int i=0,t=0;
	char a[1000];
	gets(a);
	do
	{
		if(a[i]>='0'&&a[i]<='9')t=t+a[i]-'3'+3;
		i=i+1;
	}while(a[i]!='!');
	if(t==0)printf("NAN");
	else printf("%d",t);
}


