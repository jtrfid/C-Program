#include <stdio.h>
int main()
{

	int a,sum=0;
	scanf("%d",&a);
	if (a==0) sum=1;
	else 
	{
		while (a!=0)
		{
			sum=sum+1;
			a=a/10;
		}
	}
	printf("%d",sum);


}
