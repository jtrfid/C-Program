#include<stdio.h>
int main()
{
	int i,a;
	scanf("%d",&a);
	i=1;
	while(a/10!=0)
	{
		i++;
		a=a/10;
	}
	printf("%d",i);
	return 0;
}