#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	if(n!=0)
	{
	for(i=0;n>0;i++)
		n=n/10;
	printf("%d",i);
	}
	else
		printf("1");
}