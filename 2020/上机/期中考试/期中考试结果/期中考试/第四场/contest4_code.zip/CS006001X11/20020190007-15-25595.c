#include<stdio.h>
int main()
{
	char a;
	int sum=0,i;
	a=0;
	while(a!='!')
	{
		scanf("%c",&a);
		if(a>47&&a<58)
		{
			i=1;
			sum=sum+a-48;
		}
	}
	if(i==0)
		printf("NAN");
	else
		printf("%d",sum);
	return 0;
}