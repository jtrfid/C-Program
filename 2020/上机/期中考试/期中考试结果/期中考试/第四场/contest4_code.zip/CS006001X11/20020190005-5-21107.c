#include <stdio.h>
int main()
{
	float m,n;
	scanf("%f",&m);
	if(m<=3000) n=m*0.005;
	else if(m<=5000) n=m*0.01;
	else if(m<=10000) n=m*0.015;
	else n=m*0.02;
	printf("%.1f",n);
	return 0;
}
