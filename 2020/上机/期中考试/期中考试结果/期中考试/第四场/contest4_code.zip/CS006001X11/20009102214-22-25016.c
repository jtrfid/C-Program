#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,sum=0,mul=1,temp,i,num,num1;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		for(i=b;i<=a;i++)
		{
			num=i;
			num1=i;
			sum=0;
			mul=1;
			while(num!=0)
			{
				temp=num%10;
				num=num/10;
				sum=sum+temp;
				mul=mul*temp;
			}
			if(mul==fabs(sum))
				printf("%d ",num1);
			if(num1==0)
				printf("0 ");
		}
	}
	if(a<b)
	{
		for(i=a;i<=b;i++)
		{
			num=i;
			num1=i;
			sum=0;
			mul=1;
			while(num!=0)
			{
				temp=num%10;
				num=num/10;
				sum=sum+temp;
				mul=mul*temp;
			}
			if(mul==fabs(sum))
				printf("%d ",num1);
					if(num1==0)
				printf("0 ");
		}
	}
	if(a=b)
	{

			num=a;
			num1=a;
			sum=0;
			mul=1;
			while(num!=0)
			{
				temp=num%10;
				num=num/10;
				sum=sum+temp;
				mul=mul*temp;
			}
			if(mul==fabs(sum))
				printf("%d ",num1);
					if(num1==0)
				printf("0 ");
		
	}
	
}
				
