#include <stdio.h>

void main()
{
	int a, b, min, max;
	int sum=0, multi=1;
	scanf("%d%d", &a, &b);

	min = (a < b) ? a : b;
	max = (a > b) ? a : b;
//	printf("%d %d", min, max);

	for (a = min; a <= max; a++)
	{
		sum = 0; multi = 1; b = a;
		if (a == 0)	printf("0 ");
		while (b != 0)
		{
			sum += b % 10;
			multi *= b % 10;
			b /= 10;
		}
		if (sum == multi)
			printf("%d ", a);
	}
}