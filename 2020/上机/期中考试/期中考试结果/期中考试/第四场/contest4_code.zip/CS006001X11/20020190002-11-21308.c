#include<stdio.h>
int main()
{
	int zs;
	int ws=0;
	int i;
	scanf("%d",&zs);
	for(i=1;zs/i!=0;i=i*10)
		ws++;
	printf("%d",ws);
	return 0;
}