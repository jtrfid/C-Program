#include<stdio.h>
int main()
{
	char a[10000];
	int sum=0;
	int i,flag=0,c;

	for(i=0;i<10000;i++)
    {
		scanf("%c",&a[i]);
		 if(a[i]=='!')
		{
			 c=i;
			break;
		}
		
	   
	}
	for(i=0;i<c;i++)
	{
		if(a[i]>=48&&a[i]<=58)
		{   
			flag=1;
			sum=sum+a[i]-48;
		}
	}
	if(sum==0&&flag==0)
	printf("NAN");
	else
	printf("%d",sum);
}