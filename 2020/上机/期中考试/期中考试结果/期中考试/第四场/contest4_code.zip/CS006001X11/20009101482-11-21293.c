#include<stdio.h>
int main()
{
	long n,i=0;
	scanf("%d",&n);
	do{
		i++;
		n=n/10;
	}while(n>0);
	printf("%d",i);

}