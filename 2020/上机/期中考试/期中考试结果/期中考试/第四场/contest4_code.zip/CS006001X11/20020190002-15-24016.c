#include<stdio.h>
int main()
{
	char a[1000];
	int sum=0;
	int i;

	for(i=0;i<1000;i++)
    {
		scanf("%c",&a[i]);
	    if(a[i]=='!')
		{
			break;
		}
	}
	for(i=0;i<1000;i++)
	{
		if(a[i]>=48&&a[i]<=58)
			sum=sum+a[i]-48;
	}
	if(sum==0)
	printf("NAN");
	else
	printf("%d",sum);
}