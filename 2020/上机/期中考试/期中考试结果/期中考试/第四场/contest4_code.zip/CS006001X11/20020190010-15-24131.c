#include<stdio.h>
int main()
{
	char a;
	int sum=0,c=0;
	for(;;)
	{
		scanf("%c",&a);
		if('0'<=a&&a<='9')
		{
			sum=sum+a-48;
			c=c+1;
		}
		if(a=='!') break;
	}
	if(c!=0) printf("%d\n",sum);
	else printf("NAN");
	return 0;
}
