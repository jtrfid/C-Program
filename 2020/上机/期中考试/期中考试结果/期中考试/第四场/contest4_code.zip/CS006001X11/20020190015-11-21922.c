#include<stdio.h>
int main()
{
	int n,i,p;
	i=0;
	scanf("%d",&n);
	do
	{
		n=n/10;
		p=n%10;
		i++;
	}
	while(p!=0);
	printf("%d\n",i);
	return 0;
		
}