#include<stdio.h>
int main()
{
	char a[100];
	int b[100],c[100],sum;
	int i,j;
	i=0;j=0;sum=0;
	do
	{
		scanf("%c",&a[i]);
		b[i]=a[i];
		if(b[i]>=48&&b[i]<=57)
		{
			c[j]=b[i]-48;
			j++;
		}
		if(b[i]==33)
			break;
		i++;
	}
	while(i<1000);
	for(i=0;i<j;i++)
		sum=sum+c[i];
	if(j==0)
		printf("NAN\n");
	else
		printf("%d\n",sum);
	return 0;
}