#include <stdio.h>

int main(){
	char c='0';
	int sum=0;
	while(c!='!'){
		scanf("%c",&c);
		if(c>=49&&c<=57) sum=sum+c-48;
		else sum=sum;
	}
	if(sum==0) printf("NAA");
	else printf("%d",sum);
}
