#include<stdio.h>
int main(){
	int n,i,j,t=0,a,b,he=0,ji=1,s=0;
	scanf("%d %d",&a,&b);
	if(a>b)
	{t=a;a=b;b=t;}
	for(i=a;i<=b;i++)
		{t=i;he=0,ji=1;
		for(j=0;t>0;t=t/10)
		{
			he=he+t%10;
			ji=ji*(t%10);
			}
		if(he==ji&&i>0)
		printf("%d ",i);
		else s++;
		}
	if(s==b-a+1)
	printf("NO");

}
