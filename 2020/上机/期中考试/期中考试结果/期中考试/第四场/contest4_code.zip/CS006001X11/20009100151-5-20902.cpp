#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	float n,a;
	scanf("%d",&n);
	if(n<=3000.0)
	{
		a=0.005*n;
	}
	else if(n<=5000)
	{
		a=3000*0.005+(n-3000)*0.01;
	}
	else if(n<=10000)
	{
		a=3000*0.005+2000*0.01+(n-5000)*0.015;
	}
	else a=3000*0.005+2000*0.01+5000*0.015+(n-10000)*0.02;
	printf("%.1f",a);
}

