#include <stdio.h>
int main()
{
	char a[100];
	int i,sum=0,b=0;
	for (i=0;;i++)
	{
		scanf ("%c",&a[i]);
		if (a[i]>=48&&a[i]<=57)
		{
			sum=sum+a[i]-48;
			b++;
		}
		if (a[i]=='!')
			break;
	}
	if (b==0)
	{
		printf ("NAN");
	}
	else 
	{
		printf ("%d",sum);
	}
	return 0;
}