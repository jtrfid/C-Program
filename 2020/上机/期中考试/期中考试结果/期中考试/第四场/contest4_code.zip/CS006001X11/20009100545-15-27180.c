#include<stdio.h>
int main()
{	
	char a[100];

	int i,j,b[100],sum=0;
	for(i=0;;i++)
	{
		scanf("%c",&a[i]);
		if(a[i]<'48')
		{
		a[i]=a[i]-48;
		}
		if(a[i]>49)
		{
			a[i]=0;
		}	
	//	printf("%d ",a[i]);
	}
	for(i=0;;i++)
	{
		b[i]='a[i]';
		if(b[i]>=1&&b[i]<=10)
		{
			sum=sum+b[i];
		}
	}
	printf("NAN");	
	return 0;
}