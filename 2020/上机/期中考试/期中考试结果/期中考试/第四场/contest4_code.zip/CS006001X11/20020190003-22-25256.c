#include <stdio.h>
#include <math.h>
int main()
{
int a,b,sum,mu;
	int temp;
	//int a,sum,mu;
	//scanf("%d",&a);
	scanf("%d%d",&a,&b);
    if(a>b) {temp=a;a=b;b=temp; }
    while(a<=b){
    temp=a;sum=0;mu=1;
    	while(temp>=1){
    		sum=sum+temp%10;
    		mu=mu*(temp%10);
    		temp=temp/10;
    }
   	if((sum==mu && a>0)||a==0) printf("%d ",a);//printf("%d %d\n",sum,mu); 
   	a++;
}
	return 0;
}
