#include <stdio.h>
int main()
{
	int a,b;
	int i,ji=1,he=0,t,w,x;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	if(a<0)
		a=0;
	if(a==0)
		printf("0 ");
		for(i=a;i<=b;i++)
		{
			x=i;
			ji=1;
			he=0;
			while(x!=0)
			{
				w=x%10;
				x/=10;
				he+=w;
				ji*=w;
			}
			if(he==ji)
				printf("%d ",i);
		}
	return 0;
}