#include<stdio.h>
#include<string.h>
int main(){
	char a[100];
	int i,t=0,n;
	gets(a);
	n=strlen(a);
	for(i=0;i<n;i++)
		if('1'<=a[i]&&a[i]<='9')
			t=t+a[i]-'0';
	if(t!=0)	
		printf("%d ",t);
	else printf("NAN");
}
