#include<stdio.h>
int main()
{
	float in;
	scanf("%f",&in);
	if(in<=3000)
		printf("%.1f",in*0.005);
	else if(in>3000&&in<=5000)
		printf("%.1f",in*0.01);
	else if(in>5000&&in<=10000)
		printf("%.1f",in*0.015);
	else if(in>10000)
		printf("%.1f",in*0.02);
	return 0;
}