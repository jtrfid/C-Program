#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c,d,e=0,f,j,i,t;
	int h=0,k=0;
	scanf("%d %d",&a,&b);
	if(a<b)
	{
		c=a;
		d=b;
	}
	else
	{
		c=b;
		d=a;
	}
	for(i=c;i<=d;i++)
	{
		t=i;
		do
		{
			t=t/10;
			e++;
		}while(t!=0);
		for(j=e;j>=1;j--)
		{
			f=t/(10^j);
			h=h+f;
			k=k*f;
			t=t%(10^j);
		}
		if(h==k)
			printf("%d ",i);
	}
	return 0;
}