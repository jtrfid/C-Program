#include<stdio.h>
#include<string.h>
int main()
{
	char c;
	int sum=0,leap;
	while(1)
	{
		scanf("%c",&c);
		if(c>='0'&&c<='9')
		{
			sum+=c;
			leap=1;
		}
		if(c=='!')
			break;
	}
	if(leap)
		printf("%d",sum-48);
	else
		printf("NAN");
	return 0;
}