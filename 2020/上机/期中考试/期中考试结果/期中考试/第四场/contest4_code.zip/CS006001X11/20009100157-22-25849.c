#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	 int a,b,i,he,ji,tmp1,weishu,j,tmp2;
	 int s[100];
	scanf("%d%d",&a,&b);
	if(a<=b&&a>0)
	{
		for(i=a;i<=b;i++)
		{
			he=0;weishu=0;tmp1=i;tmp2=i,ji=1;
			while(tmp1!=0)
			{
				he=he+tmp1%10;
				weishu=weishu+1;
				tmp1=tmp1/10;	
			}
			for(j=0;j<=weishu-1;j++)
			{
				s[j]=tmp2%10;
				tmp2=tmp2/10;
			}
			for(j=0;j<=weishu-1;j++)
			{
				ji=ji*s[j];
			}
			if(he==ji)
			printf("%d ",i);
		}
	} 
	if(a<=b&&a==0)
	{
		printf("0 ");
		for(i=1;i<=b;i++)
		{
			he=0;weishu=0;tmp1=i;tmp2=i,ji=1;
			while(tmp1!=0)
			{
				he=he+tmp1%10;
				weishu=weishu+1;
				tmp1=tmp1/10;	
			}
			for(j=0;j<=weishu-1;j++)
			{
				s[j]=tmp2%10;
				tmp2=tmp2/10;
			}
			for(j=0;j<=weishu-1;j++)
			{
				ji=ji*s[j];
			}
			if(he==ji)
			printf("%d ",i);
		}
	} 
	if(a<=b&&a<0)
	{
		printf("0 ");
		for(i=1;i<=b;i++)
		{
			he=0;weishu=0;tmp1=i;tmp2=i,ji=1;
			while(tmp1!=0)
			{
				he=he+tmp1%10;
				weishu=weishu+1;
				tmp1=tmp1/10;	
			}
			for(j=0;j<=weishu-1;j++)
			{
				s[j]=tmp2%10;
				tmp2=tmp2/10;
			}
			for(j=0;j<=weishu-1;j++)
			{
				ji=ji*s[j];
			}
			if(he==ji)
			printf("%d ",i);
		}
	} 
	if(b<=a&&b>0)
	{
		for(i=b;i<=a;i++)
		{
			he=0;weishu=0;tmp1=i;tmp2=i,ji=1;
			while(tmp1!=0)
			{
				he=he+tmp1%10;
				weishu=weishu+1;
				tmp1=tmp1/10;	
			}
			for(j=0;j<=weishu-1;j++)
			{
				s[j]=tmp2%10;
				tmp2=tmp2/10;
			}
			for(j=0;j<=weishu-1;j++)
			{
				ji=ji*s[j];
			}
			if(he==ji)
			printf("%d ",i);
		}
	} 
	if(b<=a&&b==0)
	{
		printf("0 ");
		for(i=1;i<=a;i++)
		{
			he=0;weishu=0;tmp1=i;tmp2=i,ji=1;
			while(tmp1!=0)
			{
				he=he+tmp1%10;
				weishu=weishu+1;
				tmp1=tmp1/10;	
			}
			for(j=0;j<=weishu-1;j++)
			{
				s[j]=tmp2%10;
				tmp2=tmp2/10;
			}
			for(j=0;j<=weishu-1;j++)
			{
				ji=ji*s[j];
			}
			if(he==ji)
			printf("%d ",i);
		}
	} 
	if(b<=a&&b<0)
	{
		printf("0 ");
		for(i=1;i<=a;i++)
		{
			he=0;weishu=0;tmp1=i;tmp2=i,ji=1;
			while(tmp1!=0)
			{
				he=he+tmp1%10;
				weishu=weishu+1;
				tmp1=tmp1/10;	
			}
			for(j=0;j<=weishu-1;j++)
			{
				s[j]=tmp2%10;
				tmp2=tmp2/10;
			}
			for(j=0;j<=weishu-1;j++)
			{
				ji=ji*s[j];
			}
			if(he==ji)
			printf("%d ",i);
		}
	} 
	return 0;
}
