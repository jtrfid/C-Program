#include<stdio.h>
 main()
{
	double a,b,c;
	scanf("%lf",&a);
	if(a<=3000)
		b=0.5/100.0;
	else if(a<=5000)
		b=1.0/100.0;
	else if(a<=10000)
		b=1.5/100.0;
	else if(a>10000)
		b=2.0/100.0;

	c=a*b;
	printf("%.1lf",c);
}

