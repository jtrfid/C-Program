#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	char a[100];
	int i,sum=0,tmp,flag=0;
	for(i=0;;i++)
	{
		scanf("%c",&a[i]);
		tmp=i;
		if(a[i]=='!') break;
	}
	for(i=0;i<=tmp;i++)
	{
		if(a[i]=='1') 
		{
			sum=sum+1;
			flag=flag+1;
		}
		
		if(a[i]=='2') 
		{
			sum=sum+2;
			flag=flag+1;
		}
		if(a[i]=='3') 
		{
			sum=sum+3;
			flag=flag+1;
		}
		if(a[i]=='4') 
		{
			sum=sum+4;
			flag=flag+1;
		}
		if(a[i]=='5') 
		{
			sum=sum+5;
			flag=flag+1;
		}
		if(a[i]=='6') 
		{
			sum=sum+6;
			flag=flag+1;
		}
		if(a[i]=='7') 
		{
			sum=sum+7;
			flag=flag+1;
		}
		if(a[i]=='8') 
		{
			sum=sum+8;
			flag=flag+1;
		}
		if(a[i]=='9') 
		{
			sum=sum+9;
			flag=flag+1;
		}
		if(a[i]=='0') 
		{
			sum=sum+0;
			flag=flag+1;
		}
		
	}
	if(flag==0)
		{
			printf("NAN");
		}
		else
		{
			printf("%d",sum);
		}
	return 0;
}
