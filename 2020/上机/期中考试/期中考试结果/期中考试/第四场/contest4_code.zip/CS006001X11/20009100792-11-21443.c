#include<stdio.h>
int main()
{
	int in,cnt;
	cnt=0;
	scanf("%d",&in);
	if(in==0)
		cnt=cnt+1;
	while(in>0)
	{
		++cnt;
		in=in/10;
	}
	printf("%d",cnt);
	return 0;
}