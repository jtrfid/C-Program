#include<stdio.h>
int main()
{
	int a,b,i,t,s=0,c=1;
	int j[100000],g;
	scanf("%d%d",&a,&b);
	if(a>b)
	{t=a;a=b;b=t;}	
	for(i=a;i<=b;i++)
	{
		j[i]=i;
	}


	for(i=a;i<=b;)
	{
		g=j[i]%10;
		s=s+g;
		c=c*g;
	    j[i]=j[i]/10;
		if(j[i]==0)
		{
			if(s==c)
			{printf("%d ",i);}
			s=0;c=1;
			i++;
		}
	}
return 0;
}