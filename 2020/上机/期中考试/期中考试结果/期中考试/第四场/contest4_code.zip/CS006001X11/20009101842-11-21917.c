#include<stdio.h>
int main()
{
	int a,i=1,j;
	scanf("%d",&a);
	for(j=0;a/10!=0;j++)
	{
		a=a/10;
		i++;
	}

	printf("%d",i);
	return 0;
}

