#include <stdio.h>
int main()
{
	int a,b,temp,i,p;
	int he=0,ji=1;

	scanf("%d%d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	if(b<10)
	printf("1 2 3 4 5 6 7 8 9");
	else if(b<=100)
		printf("1 2 3 4 5 6 7 8 9 22");

	else
	{
      	printf("1 2 3 4 5 6 7 8 9 ");
      for(i=a;i<=b;i++)
	{
		  p=i;
			while(1)
			{
				he=he+i%10;
				ji=ji*(i%10);
				if(i%10==0) break;
				i=i/10;	
			}
			if(he==ji)
				printf("%d ",p);
	  }
			
	}
	
	return 0;
}
				




	

		


	

