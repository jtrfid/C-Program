#include<stdio.h>
int main()
{
	long int a,b,i,sum,t,cheng,m,k;
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		k=a;
		a=b;
		b=k;
	}

	for(i=a;i<=b;i++)
	{	
		m=i;
		sum=0;cheng=1;
		do
		{
			t=m%10;
			sum=sum+t;
			cheng=cheng*t;
			m=m/10;
		}
		while(m>0);

		if(sum==cheng)
		{
			printf("%ld ",i);
		}
	}
	return 0;
}
		
	