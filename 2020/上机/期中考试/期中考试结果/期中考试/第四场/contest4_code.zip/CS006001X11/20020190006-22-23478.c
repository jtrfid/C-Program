#include<stdio.h>
int main()
{
	int a,b,t,i,m;
	int cheng,sum,n;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	for(i=a;i<=b;i++)
	{
		cheng=1;
		sum=0;
		n=i;
		while(n>0)
		{
			m=n%10;
			i=n/10;
			cheng*=m;
			sum+=m;
		}
		if(cheng==sum)
			printf("%d ",i);
	}
	return 0;
}