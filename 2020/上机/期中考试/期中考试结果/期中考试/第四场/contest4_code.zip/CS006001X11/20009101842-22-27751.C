#include<stdio.h>
int main()
{
	int a,y,c,i=0,j,b[1000]={0},d=10,n=0,x[1000],k,m,l;
	scanf("%d%d",&a,&y);
	if(a>y)
	{
	
		for(c=y;c!=a;c++)
		{
			if(c<=9&&c>=0)
			{
				i++;
				b[i]=c;
			}
			else if(c>=10)
			{
				for(j=0;c/10!=0;j++)
				{
					x[j]=c%10;
					c/10;
				}
				k=j;
				l=j;
			

				for(;j!=0;j--)
					n+=x[j];
				for(;k!=0;k--)
					m=x[k]*x[k-1];


				if(m==n)
				{
					b[i]=c;
					i++;
				}
			}
		}
		for(l=0;l!=i;l++)
			printf("%d ",b[l]);
		return 0;
	}
}	





