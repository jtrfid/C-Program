#include <stdio.h>
int main()
{
	int i=1;
	char n;
	int m;
	int sum=0;
	int t=0;

	for(i=1;n=='!';i++)
	{
		scanf("%c",&n);
		m=(int)n;
		if(m>=48&&n<=57)
		{
			sum=sum+m-48;
			t=1;
		}
	}
		
	
	
	if(t==1)
		printf("%c",sum);
	if(t==0)
		printf("NAN");
	return 0;
}

