#include<stdio.h>
int main()
{
	int n,i;
	i=0;
	scanf("%d",&n);
	if(n>0)
	{
	while(n>0)
	{
		n=n/10;
		i++;
	}
	}
	else
		i=1;
	
	
	
	printf("%d",i);
}



