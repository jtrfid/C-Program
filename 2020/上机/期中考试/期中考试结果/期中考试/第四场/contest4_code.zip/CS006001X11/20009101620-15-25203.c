#include<stdio.h>
#include<math.h>
int main()
{
	int x[100]={0};
	int z=0,i,temp=0;
	for(i=0;;i++)
	{
		scanf("%c",&x[i]);
		if(x[i]=='!')
			break;
	}
	i=0;
	while(x[i]!='!')
	{
		if(x[i]<'A'||x[i]>'Z')
		{
			z+=x[i]-48;
			temp++;
		}
		i++;
	}
	if(temp==0)
		printf("NAA\n");
	else
		printf("%d\n",z);
	return 0;
}
