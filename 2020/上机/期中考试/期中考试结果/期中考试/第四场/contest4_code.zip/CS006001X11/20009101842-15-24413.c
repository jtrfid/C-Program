#include<stdio.h>
int main()
{
	char m,a[1000],b[1000],x;
	int i,j,k=0,sum=0;
	for(i=0;i<=1000;i++)
	{
		scanf("%c",&a[i]);
	    if(a[i]==33)
			break;
	}
	for(j=0;a[j]!=33;j++)
	{
		if(a[j]<='9'&&a[j]>='0')
		{
			b[k]=a[j];
			sum+=b[k];
			k++;
		}
		
	}
	if(k!=0)
	{
	
		printf("%d",sum-k*48);
	}
	else
		printf("NAN");
	return 0;
}


		
