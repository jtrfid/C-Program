#include<stdio.h>
int main()
{
	char a;
	int sum=0;
	for(;;)
	{
		scanf("%c",&a);
		if(49<=a&&a<=57)
		sum=sum+a-48;
		if(a=='!') break;
	}
	if(sum!=0) printf("%d\n",sum);
	else printf("NAA");
	return 0;
}
