#include<stdio.h>
int main()
{
	long int a,b,c;
	long int i,j;
	long int wsj=1;
	long int wsh=0;
	scanf("%ld %ld",&a,&b);
	if(a>b)
	{
		c=b;
		b=a;
		a=c;
	}
	for(i=a;i<=b;i++)
	{
		for(j=1;i/j!=0;j=j*10)
		{
			
			wsj=wsj*(i/j%10);
			wsh=wsh+(i/j%10);
		}
		if(i==0)
			{
				wsj=0;
				wsh=0;
			}
		if(wsh==wsj&&i>=0)
			printf("%ld ",i);
		wsh=0;
		wsj=1;
	}
	printf("\b");

}