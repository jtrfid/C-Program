#include <stdio.h>
int main()
{
	int a,b,temp,c,d,e,f,sum=0,x=1,m,n,z;
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	c=a;
	for(c=a;c<b;c++)
	{
		z=c;
		e=c;
		for(;c>0;)
		{
			d=c%10;                 
			sum=sum+d;
			c=(c-d)/10;
		}
		for(;e>0;)
		{
			m=e%10;
			x=x*m;
			e=(e-m)/10;
		}
		if(sum==x)
			printf("%d",z);
	}
}




		