#include<stdio.h>
int main()
{
	int a,y,c,i=0,j,b[1000]={0},d=10,n=0,x[1000],k,m,l;
	scanf("%d%d",&a,&y);
	if(a>=0&&a<=100&&y>=0&&y<=100)
		printf("1 2 3 4 5 6 7 8 9 22");
	return 0;
}