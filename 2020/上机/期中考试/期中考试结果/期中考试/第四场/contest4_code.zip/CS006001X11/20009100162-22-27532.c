#include <stdio.h>

int we(int n);
int main(){
	int a,b,temp,i;
	scanf("%d %d",&a,&b);
	if(a>b){
		temp=a;
		a=b;
		b=temp;
	}
	int sum1,sum2;
	for(i=a;i<=b;i++){
		sum1=(i/100000000)%10+(i/10000000)%10+(i/1000000)%10+(i/100000)%10+(i/10000)%10+(i/1000)%10+(i/100)%10+(i/10)%10+i%10;
		sum2=we(i);
		if(sum1==sum2) printf("%d ",i);
	}
	
}

int we(int n){
	int i,sum=1;
	scanf("%d",&n);
	int a[9];
	a[0]=n%10;
	a[1]=(n/10)%10;
	a[2]=(n/100)%10;
	a[3]=(n/1000)%10;
	a[4]=(n/10000)%10;
	a[5]=(n/100000)%10;
	a[6]=(n/1000000)%10;
	a[7]=(n/10000000)%10;
	a[8]=(n/100000000)%10;
	for(i=0;i<9;i++){
		if(a[i]==0) a[i]=1;
	}
	for(i=0;i<9;i++) sum=sum*a[i];
	return sum;
}



