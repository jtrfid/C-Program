#include<stdio.h>
int main()
{
   long int a,b;
   int temp,i,t,m,sum=0,ji=1;
   scanf("%d %d",&a,&b);
   if(a>b) {
	   temp=a;
	   a=b;
	   b=temp;
   }
   for(i=a;i<=b;i++)
   {
	   if(1<=i&&i<=9) printf("%d ",i);
	   else{
		   t=i;
		   m=i;
		   while(t!=0)
		   {
			   sum=sum+t%10;
			   t=t/10;
		   }
		   while(m>10)
		   {
			   ji=ji*(m%10);
			   m=m/10;
		   }
		   ji=ji*(m%10);
		   if(sum==ji) printf("%d ",i);
		   sum=0;
		   ji=1;
	   }
   }
   return 0;
}